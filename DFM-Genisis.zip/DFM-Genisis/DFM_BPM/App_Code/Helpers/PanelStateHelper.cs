using System.Web;

namespace DFM_BPM.App_Code.Helpers
{
    /// <summary>Persists simple collapsed/expanded UI toggle state (sidebar, dashboard sections) in
    /// Session so it survives across full postbacks/page navigations until the session expires, per the
    /// "stays collapsed/expanded until session expiry" requirement. No DB storage needed for this.</summary>
    public static class PanelStateHelper
    {
        private const string KeyPrefix = "panelstate_";

        public static bool IsCollapsed(string key, bool defaultCollapsed)
        {
            var val = HttpContext.Current.Session[KeyPrefix + key] as string;
            return string.IsNullOrEmpty(val) ? defaultCollapsed : val == "1";
        }

        public static void SetCollapsed(string key, bool collapsed)
        {
            HttpContext.Current.Session[KeyPrefix + key] = collapsed ? "1" : "0";
        }
    }
}
