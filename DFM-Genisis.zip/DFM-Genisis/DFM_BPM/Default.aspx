﻿<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="Default.aspx.cs" Inherits="DFM_BPM.DefaultPage" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
<style>
/* ── sec toggle ── */
.dash-section { margin-bottom:14px; border:1px solid #e2e8f0; border-radius:10px; overflow:hidden; background:#fff; }
.dash-sec-hdr  { padding:10px 16px;
                 cursor:pointer; display:flex; justify-content:space-between; align-items:center;
                 font-weight:700; font-size:.9em; user-select:none; border-bottom:1px solid #e2e8f0; }
.dash-sec-toggle { transition:transform .2s; }
.dash-sec-body { padding:0; }
.dash-section.collapsed .dash-sec-body { display:none; }
.dash-section.collapsed .dash-sec-toggle { transform:rotate(-90deg); }
/* Section header colors — light bg, dark colorful text */
#sec-filters .dash-sec-hdr  { background:#f8fafc; color:#475569; }
#sec-projects .dash-sec-hdr { background:#F3F9FD; color:#1F4E78; }
#sec-portfolio .dash-sec-hdr { background:#F5F9FF; color:#2F5597; }
#sec-myforms .dash-sec-hdr  { background:#F5F9FF; color:#2F5597; }
#sec-budget .dash-sec-hdr   { background:#F6FBF4; color:#548235; }
/* ── filter ── */
.horizontal-filter-panel { padding:14px 16px; }
.filter-grid { display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; }
.filter-grid .form-group { flex:1; min-width:140px; margin:0; }
.filter-actions { display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; }
/* ── KPI ── */
.kpi-row { display:flex; gap:10px; flex-wrap:wrap; padding:14px 0 4px; }
.kpi-card { flex:1; min-width:130px; background:#fff; border:1px solid #e2e8f0; border-radius:10px;
            padding:14px; display:flex; align-items:center; gap:12px; }
.kpi-card .kpi-icon { font-size:1.8em; }
.kpi-label { font-size:.72em; font-weight:700; text-transform:uppercase; color:#64748b; }
.kpi-val   { font-size:1.2em; font-weight:900; color:#1a3c5e; }
.kpi-blue .kpi-icon   { color:#2563eb; } .kpi-green .kpi-icon { color:#059669; }
.kpi-orange .kpi-icon { color:#ea580c; } .kpi-red .kpi-icon   { color:#dc2626; }
.kpi-teal .kpi-icon   { color:#0891b2; } .kpi-slate .kpi-icon { color:#475569; }
/* ── pagination ── */
.page-nav { display:flex; justify-content:center; gap:4px; padding:10px; }
.page-nav .btn { min-width:36px; }
/* ── delete modal ── */
.del-pet-name { font-size:1em; font-weight:800; color:#dc2626; word-break:break-all; }
/* ── card panel (generic container — still used as the portfolio table wrapper) ── */
.card-panel { border-radius:8px; overflow:hidden; border:1px solid #e2e8f0; background:#fff; }
.card-panel-hdr { padding:12px 14px; font-weight:700; font-size:.95em; display:flex; align-items:center; gap:8px; }
.card-panel-body { padding:0; }

/* ══════════════════════════════════════════════════════════════════════
   PROJECT PORTFOLIO HIERARCHY — Project › Spend Requests › CAM/LPO › Invoices
   ══════════════════════════════════════════════════════════════════════ */

/* ── Ribbon toolbar ── */
.hier-toolbar { display:flex; align-items:center; gap:10px; flex-wrap:wrap; padding:12px 14px;
                background:linear-gradient(#fbfcfe,#f1f5f9); border-bottom:1px solid #e2e8f0; }
.hier-search-wrap { position:relative; flex:1; min-width:200px; max-width:340px; }
.hier-search-wrap i { position:absolute; left:10px; top:50%; transform:translateY(-50%); color:#94a3b8; }
.hier-search-wrap input { width:100%; padding:7px 10px 7px 30px; border:1px solid #cbd5e1; border-radius:20px; font-size:.85em; }
.hier-search-wrap input:focus { outline:none; border-color:#2F5597; box-shadow:0 0 0 2px rgba(47,85,151,.15); }
.hier-tool-btn { background:#fff; border:1px solid #cbd5e1; color:#334155; font-size:.8em; font-weight:600;
                 padding:6px 12px; border-radius:6px; cursor:pointer; display:inline-flex; align-items:center; gap:6px; }
.hier-tool-btn:hover { background:#f1f5f9; border-color:#94a3b8; }
.hier-tool-btn.hier-tool-primary { background:#2F5597; border-color:#2F5597; color:#fff; }
.hier-tool-btn.hier-tool-primary:hover { background:#254576; }
.hier-toolbar .hier-spacer { flex:1; }

/* ── Base hierarchy table ── */
.hier-table { width:100%; border-collapse:collapse; font-size:.84em; }
.hier-table th { position:sticky; top:0; z-index:2; text-align:left; padding:9px 10px; font-weight:700;
                 white-space:nowrap; box-shadow:0 1px 0 rgba(0,0,0,.04); }
.hier-table td { padding:8px 10px; vertical-align:middle; border-bottom:1px solid #eef2f7; }
.hier-table .text-right { text-align:right; }
.hier-table-scroll { overflow-x:auto; }
.hier-caret { cursor:pointer; display:inline-block; color:#64748b; transition:transform .18s ease; width:14px; text-align:center; }
.hier-caret.open { transform:rotate(90deg); }
.hier-body { display:none; }
.hier-empty-row td { text-align:center; padding:14px; color:#94a3b8; font-style:italic; }
.hier-ref-link { font-weight:700; text-decoration:none; }
.hier-lvl1-name { font-weight:700; color:#0f2942; }
.hier-lvl1-sub { font-size:.85em; color:#64748b; }

/* Level 1 — Project (Blue theme: blue header, navy border, light blue rows) */
.hier-table-main { border:2px solid #0f2942; border-radius:8px; overflow:hidden; }
table.hier-table-main thead th { background:#2F5597; color:#fff; border-bottom:2px solid #0f2942; }
tr.hier-lvl1-row > td { background:#EAF2FC; border-bottom:1px solid #B4C7E7; }
tr.hier-lvl1-row:hover > td { background:#D6E4F7; }
tr.hier-lvl1-detail > td { background:#fff; }

/* Level 2 — Spend Requests (Green theme: green header, dark green border) */
.hier-lvl2-table { border:2px solid #2d5016; border-radius:6px; overflow:hidden; margin:8px 0 8px 22px; width:calc(100% - 22px); }
.hier-lvl2-table thead th { background:#548235; color:#fff; border-bottom:2px solid #2d5016; }
tr.hier-lvl2-row > td { background:#F0F9EC; border-bottom:1px solid #C6E0B4; }
tr.hier-lvl2-row:hover > td { background:#E1F3D8; }
tr.hier-lvl2-detail > td { background:#fff; }

/* Popup — Spend Items (Purple theme: purple header, violet border) */
.hier-table-popup { border:2px solid #9b59b6; border-radius:6px; overflow:hidden; }
.hier-table-popup thead th { background:#7030A0; color:#fff; border-bottom:2px solid #9b59b6; position:static; }
.hier-table-popup tbody tr:nth-child(odd) td { background:#FAF5FF; }
.hier-table-popup tbody tr:hover td { background:#F0E2FA; }

/* Level 3 — CAM / LPO (Orange theme: orange header, brown border) */
.hier-lvl3-table { border:2px solid #7c3006; border-radius:6px; overflow:hidden; margin:8px 0 8px 22px; width:calc(100% - 22px); }
.hier-lvl3-table thead th { background:#C55A11; color:#fff; border-bottom:2px solid #7c3006; }
tr.hier-lvl3-row > td { background:#FFF3E8; border-bottom:1px solid #F4B183; }
tr.hier-lvl3-row:hover > td { background:#FCE7D2; }
tr.hier-lvl3-detail > td { background:#fff; }

/* Level 4 — Invoices (Grey theme: grey header, dark grey border) */
.hier-lvl4-table { border:2px solid #3a3a3a; border-radius:6px; overflow:hidden; margin:8px 0 8px 22px; width:calc(100% - 22px); }
.hier-lvl4-table thead th { background:#5B5B5B; color:#fff; border-bottom:2px solid #3a3a3a; }
.hier-lvl4-table tbody tr:nth-child(odd) td { background:#F5F5F5; }
.hier-lvl4-table tbody tr:hover td { background:#EDEDED; }

/* ── Status badges (green / orange / red / blue / gray) ── */
.hier-badge { display:inline-block; padding:2px 9px; border-radius:10px; font-size:.78em; font-weight:700; white-space:nowrap; }
.hb-green  { background:#d1fae5; color:#065f46; }
.hb-orange { background:#fef3c7; color:#92400e; }
.hb-red    { background:#fee2e2; color:#991b1b; }
.hb-blue   { background:#dbeafe; color:#1d4ed8; }
.hb-gray   { background:#f1f5f9; color:#475569; }

/* ── Action buttons (used at every level) ── */
.hier-act-btn { font-size:.78em; padding:3px 9px; margin-right:2px; border-radius:5px; font-weight:600;
                cursor:pointer; border:1px solid transparent; display:inline-flex; align-items:center; gap:4px;
                text-decoration:none; white-space:nowrap; }
.hier-act-blue   { background:#E8F0FE; color:#2F5597; border-color:#B4C7E7; }
.hier-act-blue:hover   { background:#D4E4FA; color:#1F4E78; }
.hier-act-green  { background:#F0F9EC; color:#548235; border-color:#C6E0B4; }
.hier-act-green:hover  { background:#E0F3D8; }
.hier-act-purple { background:#F5EBFF; color:#7030A0; border-color:#D9C2E9; }
.hier-act-purple:hover { background:#EBD9FA; }
.hier-act-orange { background:#FFF3E8; color:#C55A11; border-color:#F4B183; }
.hier-act-orange:hover { background:#FFE8D4; }
.hier-act-red    { background:#FEE2E2; color:#b91c1c; border-color:#fca5a5; }
.hier-act-red:hover    { background:#FCA5A5; color:#7f1d1d; }

/* ── Responsive ── */
@media (max-width: 768px) {
    .hier-toolbar { flex-direction:column; align-items:stretch; }
    .hier-search-wrap { max-width:none; }
    .hier-lvl2-table, .hier-lvl3-table, .hier-lvl4-table { margin-left:8px; width:calc(100% - 8px); }
    .hier-table th, .hier-table td { padding:6px 6px; font-size:.92em; }
}
</style>
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
<h1 class="page-title">
    <i class="bi bi-house"></i> Dashboard
    <span style="font-size:.55em;color:#94a3b8;font-weight:400;margin-left:12px;">
        Last Sync: <asp:Literal ID="litLastSync" runat="server" Text="–" />
    </span>
</h1>

<!-- ── FILTER SECTION ── -->
<div class="dash-section" id="sec-filters">
    <div class="dash-sec-hdr" onclick="dfmSecTog('sec-filters')">
        <span><i class="bi bi-funnel"></i> Filters</span>
        <i class="bi bi-chevron-down dash-sec-toggle"></i>
    </div>
    <div class="dash-sec-body">
        <div class="horizontal-filter-panel">
            <div class="filter-grid">
                <div class="form-group">
                    <label>Project</label>
                    <asp:DropDownList ID="ddlProject" runat="server" CssClass="form-control"
                        AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                        <asp:ListItem Text="All Projects" Value="ALL" />
                    </asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>Type</label>
                    <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control no-select2"
                        AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                        <asp:ListItem Text="All" Value="ALL" />
                        <asp:ListItem Text="CAPEX" Value="CAPEX" />
                        <asp:ListItem Text="OPEX" Value="OPEX" />
                    </asp:DropDownList>
                </div>
               <%-- <div class="form-group">
                    <label>Portfolio</label>
                    <asp:DropDownList ID="ddlPortfolioFilter" runat="server" CssClass="form-control"
                        AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                        <asp:ListItem Text="All Portfolios" Value="ALL" />
                    </asp:DropDownList>
                </div>--%>
                <div class="form-group">
                    <label>View</label>
                    <asp:DropDownList ID="ddlView" runat="server" CssClass="form-control no-select2"
                        AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                        <asp:ListItem Text="All Items" Value="ALL" />
                        <asp:ListItem Text="Pending My Action" Value="MYAPPROVAL" />
                        <asp:ListItem Text="My Requests" Value="MYREQUESTS" />
                        
                    </asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <asp:DropDownList ID="ddlStatus" runat="server" CssClass="form-control no-select2"
                        AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                        <asp:ListItem Text="All" Value="ALL" />
                        <asp:ListItem Text="Draft" Value="Draft" />
                        <asp:ListItem Text="Pending Review" Value="PendingReview" />
                        <asp:ListItem Text="Pending Approval" Value="PendingApproval" />
                        <asp:ListItem Text="Approved" Value="Approved" />
                        <asp:ListItem Text="Rejected" Value="Rejected" />
                        <asp:ListItem Text="Sent Back" Value="SentBack" />
                        <asp:ListItem Text="Deleted" Value="Deleted" />
                    </asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>From Date</label>
                    <asp:TextBox ID="txtFromDate" runat="server" CssClass="form-control" TextMode="Date" />
                </div>
                <div class="form-group">
                    <label>To Date</label>
                    <asp:TextBox ID="txtToDate" runat="server" CssClass="form-control" TextMode="Date" />
                </div>
            </div>
            <div class="filter-actions">
                <asp:Button ID="btnApply" runat="server" Text="Apply Filters" CssClass="btn btn-primary"
                    OnClick="Filter_Changed" />
                <asp:Button ID="btnReset" runat="server" Text="Reset" CssClass="btn btn-default"
                    OnClick="btnResetFilters_Click" CausesValidation="false" />
                <asp:Button ID="btnExport" runat="server" Text="Export Excel" CssClass="btn btn-success"
                    OnClick="btnExport_Click" />
            </div>
        </div>
    </div>
</div>

<!-- ── KPI CARDS ── -->
<div class="kpi-row">
    <div class="kpi-card kpi-blue">
        <i class="bi bi-folder2-open kpi-icon"></i>
        <div><div class="kpi-label">Total Projects</div><div class="kpi-val"><asp:Literal ID="litProjects" runat="server" Text="0" /></div></div>
    </div>
    <div class="kpi-card kpi-green">
        <i class="bi bi-file-earmark-text kpi-icon"></i>
        <div><div class="kpi-label">Total Requests</div><div class="kpi-val"><asp:Literal ID="litPET" runat="server" Text="0" /></div></div>
    </div>
    <div class="kpi-card kpi-orange">
        <i class="bi bi-hourglass-split kpi-icon"></i>
        <div><div class="kpi-label">Pending</div><div class="kpi-val"><asp:Literal ID="litPending" runat="server" Text="0" /></div></div>
    </div>
    <div class="kpi-card kpi-teal">
        <i class="bi bi-check2-circle kpi-icon"></i>
        <div><div class="kpi-label">Approved</div><div class="kpi-val"><asp:Literal ID="litApproved" runat="server" Text="0" /></div></div>
    </div>
    <div class="kpi-card kpi-red">
        <i class="bi bi-x-circle kpi-icon"></i>
        <div><div class="kpi-label">Rejected</div><div class="kpi-val"><asp:Literal ID="litRejected" runat="server" Text="0" /></div></div>
    </div>
    <div class="kpi-card kpi-green">
        <i class="bi bi-currency-dollar kpi-icon"></i>
        <div><div class="kpi-label">CAPEX Budget</div><div class="kpi-val"><asp:Literal ID="litCapexBudget" runat="server" Text="0" /></div></div>
    </div>
    <div class="kpi-card kpi-blue">
        <i class="bi bi-receipt kpi-icon"></i>
        <div><div class="kpi-label">OPEX Budget</div><div class="kpi-val"><asp:Literal ID="litOpexBudget" runat="server" Text="0" /></div></div>
    </div>
</div>


    <div style="margin-top:10px;">
    <a href="<%= ResolveUrl("~/Forms/ProjectRegistration.aspx") %>" class="btn btn-default">
        <i class="bi bi-folder-plus"></i> Register New Project
    </a>
    <a href="<%= ResolveUrl("~/Forms/PetWorkflow.aspx") %>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> New Spend Request
    </a>
</div>
<!-- ── PROJECT PORTFOLIO HIERARCHY ── -->
<div class="dash-section" id="sec-portfolio">
    <div class="dash-sec-hdr" onclick="dfmSecTog('sec-portfolio')">
        <span><i class="fa-solid fa-sitemap"></i> Project Portfolio
            <span style="background:#fbbf24;color:#78350f;border-radius:10px;padding:1px 8px;font-size:.8em;margin-left:6px;">
                <asp:Literal ID="litPendingCount" runat="server" Text="0" />
            </span>
        </span>
        <i class="bi bi-chevron-down dash-sec-toggle"></i>
    </div>
    <div class="dash-sec-body">
        <div class="card-panel" style="border-top:none;border-radius:0 0 8px 8px;margin:0;padding:0;">
            <div class="hier-toolbar">
                <div class="hier-search-wrap">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" id="hierSearchBox" placeholder="Search projects, leads, PM..." onkeyup="dfmHierSearch(this.value)" />
                </div>
                <button type="button" class="hier-tool-btn" onclick="dfmExpandAll()"><i class="fa-solid fa-angles-down"></i> Expand All</button>
                <button type="button" class="hier-tool-btn" onclick="dfmCollapseAll()"><i class="fa-solid fa-angles-up"></i> Collapse All</button>
                <span class="hier-spacer"></span>
                <asp:LinkButton ID="btnExportCsv" runat="server" CssClass="hier-tool-btn hier-tool-primary"
                    OnClick="btnExportCsv_Click" CausesValidation="false"><i class="fa-solid fa-file-csv"></i> Export CSV</asp:LinkButton>
            </div>
            <div class="hier-table-scroll">
            <table class="hier-table hier-table-main" style="width:100%;">
                <thead>
                    <tr>
                        <th style="width:26px;"></th>
                        <th>Project</th>
                        <th>Type</th>
                        <th>Accountable Exec Lead</th>
                        <th>SME Lead</th>
                        <th>Size</th>
                        <th>Project Manager</th>
                        <th>Requestor</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th class="text-right">Requests / AED</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <asp:Literal ID="litPendingTree" runat="server" />
                </tbody>
            </table>
            </div>
            <!-- Pagination -->
            <div class="page-nav">
                <asp:LinkButton ID="btnPrevPage" runat="server" CssClass="btn btn-default btn-sm"
                    Text="&#8249; Prev" OnClick="btnPrevPage_Click" CausesValidation="false" />
                <asp:Literal ID="litPageInfo" runat="server" />
                <asp:LinkButton ID="btnNextPage" runat="server" CssClass="btn btn-default btn-sm"
                    Text="Next &#8250;" OnClick="btnNextPage_Click" CausesValidation="false" />
            </div>
        </div>
    </div>
</div>




<!-- ── SPEND ITEMS POPUP (Purple theme) ── -->
<div class="modal fade" id="spendItemsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document" style="max-width:90%;width:90%;">
        <div class="modal-content">
            <div class="modal-header" style="background:#7030A0;color:#fff;">
                <button type="button" class="close" data-dismiss="modal" style="color:#fff;opacity:.8;">&times;</button>
                <h4 class="modal-title"><i class="fa-solid fa-boxes-stacked"></i> Spend Items &mdash; <span id="spendItemsRef"></span></h4>
            </div>
            <div class="modal-body" style="padding:16px;max-height:75vh;overflow-y:auto;">
                <div class="hier-table-scroll">
                <table class="hier-table hier-table-popup" style="width:100%;">
                    <thead>
                        <tr>
                            <th>Head</th><th>Topic</th><th>Vendor</th><th>Cost Type</th>
                            <th class="text-right">Units</th><th class="text-right">Unit Price</th><th>CCY</th>
                            <th class="text-right">FCY Amt</th><th class="text-right">AED Amt</th>
                            <th class="text-right">Cont.%</th><th class="text-right">Final AED</th><th>GL#</th>
                        </tr>
                    </thead>
                    <tbody id="spendItemsBody"></tbody>
                </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="bi bi-x-lg"></i> Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ── PET Delete Hidden Fields + Modal ── -->
<asp:HiddenField ID="hfDeletePetId" runat="server" Value="0" />
<asp:Button ID="btnConfirmDeletePet" runat="server" Text="_del" style="display:none;"
    OnClick="btnConfirmDeletePet_Click" CausesValidation="false" />

<div class="modal fade" id="petDelModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document" style="max-width:460px;">
        <div class="modal-content">
            <div class="modal-header" style="background:#b91c1c;color:#fff;">
                <button type="button" class="close" data-dismiss="modal" style="color:#fff;opacity:.8;">&times;</button>
                <h4 class="modal-title"><i class="bi bi-exclamation-triangle-fill"></i> Confirm Delete Spend Request</h4>
            </div>
            <div class="modal-body" style="padding:24px;text-align:center;">
                <div style="font-size:2.8em;color:#dc2626;margin-bottom:10px;"><i class="bi bi-trash3-fill"></i></div>
                <p style="font-size:.94em;font-weight:600;color:#1e293b;margin-bottom:4px;">Are you sure you want to delete Spend Request</p>
                <p id="petDelRefNo" class="del-pet-name"></p>
                <p style="font-size:.82em;color:#64748b;margin-top:8px;">The Spend Request will be marked as <strong>Deleted</strong> and removed from all views. Workflow history is retained.</p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="bi bi-x-lg"></i> Cancel</button>
                <button type="button" class="btn btn-danger" onclick="dfmPetDelConfirm();"><i class="bi bi-trash"></i> Yes, Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
function dfmSecTog(id) {
    var el = document.getElementById(id);
    if (el) el.classList.toggle('collapsed');
}
function dfmHierToggle(id, el) {
    jQuery('#' + id).stop(true, true).slideToggle(160);
    if (el) el.classList.toggle('open');
}
function dfmPetDel(id, refNo) {
    document.getElementById('<%= hfDeletePetId.ClientID %>').value = id;
    document.getElementById('petDelRefNo').textContent = refNo;
    jQuery('#petDelModal').modal('show');
}
function dfmPetDelConfirm() {
    jQuery('#petDelModal').modal('hide');
    document.getElementById('<%= btnConfirmDeletePet.ClientID %>').click();
}
function dfmExpandAll() {
    jQuery('.hier-body').stop(true, true).slideDown(160);
    var carets = document.querySelectorAll('.hier-caret');
    for (var i = 0; i < carets.length; i++) carets[i].classList.add('open');
}
function dfmCollapseAll() {
    jQuery('.hier-body').stop(true, true).slideUp(160);
    var carets = document.querySelectorAll('.hier-caret');
    for (var i = 0; i < carets.length; i++) carets[i].classList.remove('open');
}
function dfmHierSearch(q) {
    q = (q || '').toLowerCase();
    var rows = document.querySelectorAll('.hier-lvl1-row');
    for (var i = 0; i < rows.length; i++) {
        var show = (q === '' || (rows[i].getAttribute('data-search') || '').indexOf(q) !== -1) ? '' : 'none';
        rows[i].style.display = show;
        var detail = rows[i].nextElementSibling;
        if (detail && detail.classList.contains('hier-lvl1-detail')) detail.style.display = show;
    }
}
function dfmShowSpendItems(petId, refNo) {
    var src = document.getElementById('spitems_' + petId);
    var dest = document.getElementById('spendItemsBody');
    if (src && dest) dest.innerHTML = src.innerHTML;
    document.getElementById('spendItemsRef').textContent = refNo;
    jQuery('#spendItemsModal').modal('show');
}
</script>
</asp:Content>
