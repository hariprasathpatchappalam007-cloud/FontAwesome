using System.Web;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM
{
    /// <summary>Tiny fire-and-forget endpoint used by client-side JS to persist collapse/expand UI state
    /// (sidebar, dashboard Filters/KPI sections) into Session, without a full postback. Uses CodeBehind
    /// (not inline WebHandler code) to avoid the App_Code/dynamic-assembly type-collision gotcha (see repo
    /// notes) since this references PanelStateHelper from App_Code. Restricted to a small known key
    /// allow-list to keep Session usage bounded.</summary>
    public class PanelState : IHttpHandler, System.Web.SessionState.IRequiresSessionState
    {
        private static readonly string[] AllowedKeys = { "sidebar", "filters", "kpi" };

        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext context)
        {
            string key = context.Request.QueryString["key"];
            string collapsed = context.Request.QueryString["collapsed"];

            bool allowed = false;
            if (!string.IsNullOrEmpty(key))
            {
                for (int i = 0; i < AllowedKeys.Length; i++)
                    if (AllowedKeys[i] == key) { allowed = true; break; }
            }
            if (allowed)
                PanelStateHelper.SetCollapsed(key, collapsed == "1");

            context.Response.ContentType = "text/plain";
            context.Response.Write("OK");
        }
    }
}
