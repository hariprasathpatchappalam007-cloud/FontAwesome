﻿using System;
using System.Data;
using System.Text;
using System.Web.UI;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM
{
    public partial class DefaultPage : Page
    {
        protected bool IsAdmin { get { return AuthHelper.IsAdmin; } }

        /// <summary>Filters and KPI sections default to collapsed; once toggled, the chosen state persists
        /// in Session until it expires (see PanelStateHelper).</summary>
        protected string FiltersSecClass { get { return PanelStateHelper.IsCollapsed("filters", true) ? "collapsed" : ""; } }
        protected string KpiSecClass     { get { return PanelStateHelper.IsCollapsed("kpi", true) ? "collapsed" : ""; } }

        private const int PageSize = 15;
        private int CurrentPage
        {
            get { int v; return int.TryParse(ViewState["pendingPage"] as string, out v) ? v : 1; }
            set { ViewState["pendingPage"] = value.ToString(); }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadJiraProjects();
                LoadPortfolioFilter();

                // Support redirect from Portfolio Hierarchy: ?resource=<id> pre-selects that Portfolio filter
                //string qsResource = Request.QueryString["resource"];
                //int qsRid;
                //if (!string.IsNullOrEmpty(qsResource) && int.TryParse(qsResource, out qsRid) && qsRid > 0)
                //{
                //    if (ddlPortfolioFilter.Items.FindByValue(qsRid.ToString()) != null)
                //        ddlPortfolioFilter.SelectedValue = qsRid.ToString();
                //}

                LoadAll();
            }
        }

        private void LoadPortfolioFilter()
        {
            try
            {
                //DataTable dt = PortfolioDAL.GetResourceDropdown();
                //ddlPortfolioFilter.Items.Clear();
                //ddlPortfolioFilter.Items.Add(new System.Web.UI.WebControls.ListItem("All Portfolios", "ALL"));
                //foreach (DataRow r in dt.Rows)
                //    ddlPortfolioFilter.Items.Add(new System.Web.UI.WebControls.ListItem(
                //        r["DisplayName"].ToString(), r["ResourceID"].ToString()));
            }
            catch { /* no Portfolio data yet */ }
        }

        private void LoadJiraProjects()
        {
            try
            {
                DataTable dt = MastersDAL.GetJiraDropdown();
                ddlProject.Items.Clear();
                ddlProject.Items.Add(new System.Web.UI.WebControls.ListItem("All Projects", "ALL"));
                foreach (DataRow r in dt.Rows)
                    ddlProject.Items.Add(new System.Web.UI.WebControls.ListItem(
                        r["DisplayName"].ToString(), r["JiraID"].ToString()));
            }
            catch { /* no JIRA data yet */ }
        }

        private void LoadAll()
        {
            LoadKPIs();
            LoadRegisteredProjects();
            LoadProjectHierarchy();
            LoadMyPet();
            LoadMyBudgetLines();
            LoadLastSync();
        }

        /// <summary>Simple "one row per registered Project" grid shown before Pending Approvals & Requests —
        /// shows every JIRA or Non-JIRA project registered via the Project Registration module, regardless of
        /// whether a Spend Request has ever been submitted/approved for it. Respects the Portfolio filter so
        /// dashboard/reporting can slice by Portfolio Hierarchy ownership.</summary>
        private void LoadRegisteredProjects()
        {
            try
            {
              /*  int? resourceId = null;
                int rid;
                if (int.TryParse(ddlPortfolioFilter.SelectedValue, out rid) && rid > 0) resourceId = rid;

                string search = txtProjectSearch.Text.Trim();
                DataTable dt = ProjectDAL.GetProjects(string.IsNullOrEmpty(search) ? null : search, resourceId);
                gvRegisteredProjects.DataSource = dt;
                gvRegisteredProjects.DataBind();
                litRegisteredProjectsCount.Text = dt.Rows.Count.ToString();*/
            }
            catch { }
        }

        protected void btnProjectSearch_Click(object sender, EventArgs e)
        {
         /*   gvRegisteredProjects.PageIndex = 0;
            LoadRegisteredProjects();*/
        }

        protected void btnProjectSearchReset_Click(object sender, EventArgs e)
        {
           /* txtProjectSearch.Text = "";
            gvRegisteredProjects.PageIndex = 0;
            LoadRegisteredProjects();*/
        }

        private void LoadLastSync()
        {
            try
            {
                var row = Db.QueryRow(
                    "SELECT TOP 1 CONVERT(VARCHAR,EndTime,120) AS T FROM dbo.SyncLog WHERE Status='Success' ORDER BY SyncID DESC");
                litLastSync.Text = row != null ? row["T"].ToString() : "Never";
            }
            catch { litLastSync.Text = "N/A"; }
        }

        private void LoadKPIs()
        {
            try
            {
                DataRow kpi = DashboardDAL.GetDashboardKPIs();
                if (kpi != null)
                {
                    litProjects.Text    = Fmt(kpi, "TotalProjects");
                    litPET.Text         = Fmt(kpi, "TotalPET");
                    litPending.Text     = Fmt(kpi, "TotalPending");
                    litApproved.Text    = Fmt(kpi, "TotalApproved");
                    litRejected.Text    = Fmt(kpi, "TotalRejected");
                    litCapexBudget.Text = FmtAmt(kpi, "TotalCapexBudget");
                    litOpexBudget.Text  = FmtAmt(kpi, "TotalOpexBudget");
                }
            }
            catch { /* data not yet available */ }
        }

        /// <summary>Renders the full Project → Spend Request → CAM/LPO → Invoice hierarchy for the
        /// "Project Portfolio" section. Level 1 (Project, blue) rows come from the dbo.Project master
        /// (ProjectDAL); Level 2 (Spend Requests, green) are grouped from the filtered PetForm rows;
        /// Level 3 (CAM/LPO, orange) and Level 4 (Invoices, grey) are fetched once per visible project
        /// (not per row) and grouped in memory to avoid N+1 queries. The Spend Items popup (purple) is
        /// pre-rendered into a hidden per-request source table that the client-side modal copies from —
        /// the whole tree is otherwise plain client-side show/hide (no UpdatePanel/AJAX in this app).</summary>
        private void LoadProjectHierarchy()
        {
            try
            {
                string jiraFilter = ddlProject.SelectedValue == "ALL" ? null : ddlProject.SelectedValue;
                string typeFilter = ddlType.SelectedValue == "ALL" ? null : ddlType.SelectedValue;
                string statFilter = ddlStatus.SelectedValue == "ALL" ? null : ddlStatus.SelectedValue;
                string viewFilter = ddlView.SelectedValue;
                string viewUser = AuthHelper.CurrentUserShort;
                DateTime? fromDate = null, toDate = null;
                DateTime dt;
                if (DateTime.TryParse(txtFromDate.Text, out dt)) fromDate = dt;
                if (DateTime.TryParse(txtToDate.Text, out dt)) toDate = dt;

                DataTable allForms = WorkflowDAL.GetPetFormsDashboard(
                    jiraFilter, typeFilter, statFilter, fromDate, toDate, viewFilter, viewUser);

                // ── Group Spend Requests by ProjectID ───────────────────────────
                var groupOrder = new System.Collections.Generic.List<string>();
                var groups = new System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<DataRow>>();
                foreach (DataRow r in allForms.Rows)
                {
                    string proj = r["ProjectID"] == DBNull.Value ? "(No Project)" : r["ProjectID"].ToString();
                    if (!groups.ContainsKey(proj)) { groups[proj] = new System.Collections.Generic.List<DataRow>(); groupOrder.Add(proj); }
                    groups[proj].Add(r);
                }

                // Registered-project master metadata (Exec Lead / SME Lead / Size / PM / Status / Created)
                var projectMeta = new System.Collections.Generic.Dictionary<string, DataRow>(StringComparer.OrdinalIgnoreCase);
                foreach (DataRow pr in ProjectDAL.GetProjects().Rows)
                {
                    string pid = pr["ProjectID"].ToString();
                    if (!projectMeta.ContainsKey(pid)) projectMeta[pid] = pr;
                }

                int totalGroups = groupOrder.Count;
                int pages = Math.Max(1, (int)Math.Ceiling(totalGroups / (double)PageSize));
                if (CurrentPage > pages) CurrentPage = pages;
                litPendingCount.Text = allForms.Rows.Count.ToString();
                litPageInfo.Text = string.Format(
                    "<span style='font-size:.85em;color:#64748b;padding:0 8px;'>Page {0} of {1} ({2} project(s), {3} request(s))</span>",
                    CurrentPage, pages, totalGroups, allForms.Rows.Count);
                btnPrevPage.Enabled = CurrentPage > 1;
                btnNextPage.Enabled = CurrentPage < pages;

                int skip = (CurrentPage - 1) * PageSize;
                var sb = new StringBuilder();

                for (int gi = skip; gi < Math.Min(skip + PageSize, groupOrder.Count); gi++)
                {
                    string proj = groupOrder[gi];
                    var petRows = groups[proj];
                    petRows.Sort(delegate (DataRow a, DataRow b) {
                        return Convert.ToInt32(a["PetFormID"]).CompareTo(Convert.ToInt32(b["PetFormID"]));
                    });

                    DataRow meta = projectMeta.ContainsKey(proj) ? projectMeta[proj] : null;
                    string safeId = "p" + Math.Abs(proj.GetHashCode() & 0x7FFFFFFF).ToString();

                    string projName = meta != null ? StrOf(meta, "ProjectName") : "";
                    if (string.IsNullOrEmpty(projName) && petRows.Count > 0 && petRows[0].Table.Columns.Contains("ProjectName"))
                        projName = StrOf(petRows[0], "ProjectName");

                    bool isNonJira = meta != null && meta["IsNonJiraProject"] != DBNull.Value && Convert.ToBoolean(meta["IsNonJiraProject"]);
                    string projType = isNonJira ? "Non-JIRA" : "JIRA";
                    string execLead = meta != null ? StrOf(meta, "AccountableExecLead") : "";
                    string smeLead  = meta != null ? StrOf(meta, "SmeLead") : "";
                    string pSize    = meta != null ? StrOf(meta, "ProjectSize") : "";
                    string pMgr     = meta != null ? StrOf(meta, "ProjectManager") : "";
                    string pReq     = meta != null ? StrOf(meta, "CreatedBy") : "";
                    bool isActive   = meta == null || meta["IsActive"] == DBNull.Value || Convert.ToBoolean(meta["IsActive"]);
                    string pCreated = meta != null && meta["CreatedDate"] != DBNull.Value
                        ? Convert.ToDateTime(meta["CreatedDate"]).ToString("dd-MMM-yy") : "";

                    decimal projTotal = 0m;
                    foreach (DataRow pr in petRows) projTotal += DecOf(pr, "TotalRequestedAED");

                    // Bulk per-project data for Level 3 / Level 4 / the Spend Items popup (1 query each,
                    // grouped in memory) — avoids an N+1 query per Spend Request / Budget Line.
                    var budgetByPet = new System.Collections.Generic.Dictionary<int, System.Collections.Generic.List<DataRow>>();
                    foreach (DataRow br in WorkflowDAL.GetBudgetLinesByProject(proj).Rows)
                    {
                        int bpid = Convert.ToInt32(br["PetFormID"]);
                        if (!budgetByPet.ContainsKey(bpid)) budgetByPet[bpid] = new System.Collections.Generic.List<DataRow>();
                        budgetByPet[bpid].Add(br);
                    }
                    var invByBudgetLine = new System.Collections.Generic.Dictionary<int, System.Collections.Generic.List<DataRow>>();
                    foreach (DataRow ir in WorkflowDAL.GetInvoicesByProject(proj).Rows)
                    {
                        int blid = Convert.ToInt32(ir["BudgetLineID"]);
                        if (!invByBudgetLine.ContainsKey(blid)) invByBudgetLine[blid] = new System.Collections.Generic.List<DataRow>();
                        invByBudgetLine[blid].Add(ir);
                    }
                    var itemsByPet = new System.Collections.Generic.Dictionary<int, System.Collections.Generic.List<DataRow>>();
                    foreach (DataRow lr in WorkflowDAL.GetPetLinesByProject(proj).Rows)
                    {
                        int lpid = Convert.ToInt32(lr["PetFormID"]);
                        if (!itemsByPet.ContainsKey(lpid)) itemsByPet[lpid] = new System.Collections.Generic.List<DataRow>();
                        itemsByPet[lpid].Add(lr);
                    }

                    // ============ LEVEL 1 — Project (blue) ============
                    string searchBlob = (proj + " " + projName + " " + execLead + " " + smeLead + " " + pMgr + " " + pReq).ToLowerInvariant();

                    sb.AppendFormat(
                        "<tr class='hier-lvl1-row' data-search='{0}'>" +
                        "<td><i class='fa-solid fa-chevron-right hier-caret' onclick=\"dfmHierToggle('lvl1b_{1}',this)\"></i></td>" +
                        "<td><i class='fa-solid fa-folder-open' style='color:#16305c;margin-right:6px;'></i><span class='hier-lvl1-name'>{2}</span> <span class='hier-lvl1-sub'>&mdash; {3}</span></td>" +
                        "<td>{4}</td><td>{5}</td><td>{6}</td><td>{7}</td><td>{8}</td><td>{9}</td>" +
                        "<td>{10}</td><td>{11}</td>" +
                        "<td class='text-right'>{12} req(s)</td><td class='text-right'><strong>AED {13}</strong></td>" +
                        "<td><a href='{14}' class='hier-act-btn hier-act-blue'><i class=\"fa-solid fa-arrow-up-right-from-square\"></i> Open</a></td>" +
                        "</tr>",
                        System.Web.HttpUtility.HtmlAttributeEncode(searchBlob),
                        safeId,
                        E(proj),
                        E(projName),
                        projType,
                        E(execLead), E(smeLead), E(pSize), E(pMgr), E(pReq),
                        isActive ? "<span class='hier-badge hb-green'>Active</span>" : "<span class='hier-badge hb-gray'>Inactive</span>",
                        pCreated,
                        petRows.Count, projTotal.ToString("N0"),
                        ResolveUrl("~/Forms/ProjectRegistration.aspx") + "?pid=" + Server.UrlEncode(proj));

                    sb.AppendFormat(
                        "<tr class='hier-lvl1-detail'><td colspan='13' style='padding:0;border:none;'>" +
                        "<div id='lvl1b_{0}' class='hier-body'><table class='hier-table hier-lvl2-table'>" +
                        "<thead><tr><th style='width:26px;'></th><th>Ref No</th><th>Status</th><th>Type</th><th>Budget Source</th>" +
                        "<th class='text-right'>Requested (AED)</th><th>Approver</th><th>Requestor</th><th>Submitted</th><th>Spend Items</th><th>Action</th></tr></thead><tbody>",
                        safeId);

                    // ============ LEVEL 2 — Spend Requests (green) ============
                    if (petRows.Count == 0)
                        sb.Append("<tr class='hier-empty-row'><td colspan='11'>No Spend Requests for this project.</td></tr>");

                    foreach (DataRow pr in petRows)
                    {
                        int petId = Convert.ToInt32(pr["PetFormID"]);
                        string status = StrOf(pr, "Status");
                        string refNo = pr["PetRefNo"] == DBNull.Value ? "#" + petId : pr["PetRefNo"].ToString();
                        string type = StrOf(pr, "CapexOpexType");
                        string src = StrOf(pr, "BudgetSourceID");
                        string approver = StrOf(pr, "ApproverUsername");
                        string by = StrOf(pr, "CreatedBy");
                        decimal reqAmt = DecOf(pr, "TotalRequestedAED");
                        string submitted = pr["SubmittedDate"] == DBNull.Value ? "" : Convert.ToDateTime(pr["SubmittedDate"]).ToString("dd-MMM-yy");
                        string delBtn = WorkflowDAL.IsPetDeletable(status)
                            ? " <button type='button' class='hier-act-btn hier-act-red' onclick=\"dfmPetDel('" + petId + "','" + JE(refNo) + "');\"><i class='fa-solid fa-trash'></i></button>"
                            : "";
                        string petUrl = ResolveUrl("~/Forms/PetWorkflow.aspx") + "?id=" + petId;

                        sb.AppendFormat(
                            "<tr class='hier-lvl2-row'>" +
                            "<td><i class='fa-solid fa-chevron-right hier-caret' onclick=\"dfmHierToggle('lvl2b_{0}',this)\"></i></td>" +
                            "<td><a href='{1}' class='hier-ref-link'>{2}</a></td><td>{3}</td><td>{4}</td><td>{5}</td>" +
                            "<td class='text-right'>{6}</td><td>{7}</td><td>{8}</td><td>{9}</td>" +
                            "<td><button type='button' class='hier-act-btn hier-act-purple' onclick=\"dfmShowSpendItems({0},'{10}');\"><i class='fa-solid fa-boxes-stacked'></i> View</button></td>" +
                            "<td><a href='{1}' class='hier-act-btn hier-act-blue'><i class='fa-solid fa-arrow-up-right-from-square'></i></a>{11}</td>" +
                            "</tr>",
                            petId, petUrl, E(refNo), StatusBadgeHtml(status), E(type), E(src),
                            reqAmt > 0 ? reqAmt.ToString("N0") : "-", E(approver), E(by), submitted, JE(refNo), delBtn);

                        sb.AppendFormat(
                            "<tr class='hier-lvl2-detail'><td colspan='11' style='padding:0;border:none;'>" +
                            "<div id='lvl2b_{0}' class='hier-body'><table class='hier-table hier-lvl3-table'>" +
                            "<thead><tr><th style='width:26px;'></th><th>#</th><th>Vendor</th><th>Justification</th>" +
                            "<th class='text-right'>Cost</th><th>CCY</th><th>GL#</th><th>PET Ref</th><th>CAM ID</th>" +
                            "<th>CAM Status</th><th>CAM Comments</th><th>LPO Request</th><th>LPO Status</th><th>LPO Comments</th>" +
                            "<th>Invoices</th></tr></thead><tbody>",
                            petId);

                        // ============ LEVEL 3 — CAM / LPO (orange) ============
                        System.Collections.Generic.List<DataRow> budgetLines;
                        if (budgetByPet.TryGetValue(petId, out budgetLines) && budgetLines.Count > 0)
                        {
                            foreach (DataRow bl in budgetLines)
                            {
                                int blId = Convert.ToInt32(bl["BudgetLineID"]);
                                int invCount = (int)DecOf(bl, "InvoiceCount");

                                sb.AppendFormat(
                                    "<tr class='hier-lvl3-row'>" +
                                    "<td><i class='fa-solid fa-chevron-right hier-caret' onclick=\"dfmHierToggle('lvl3b_{0}',this)\"></i></td>" +
                                    "<td>{1}</td><td>{2}</td><td>{3}</td><td class='text-right'>{4}</td><td>{5}</td><td>{6}</td>" +
                                    "<td>{7}</td><td>{8}</td><td>{9}</td><td>{10}</td><td>{11}</td><td>{12}</td><td>{13}</td>" +
                                    "<td>{14} invoice(s)</td>" +
                                    "</tr>",
                                    blId, E(StrOf(bl, "SerialNo")), E(StrOf(bl, "VendorName")), E(StrOf(bl, "Justification")),
                                    DecOf(bl, "Cost").ToString("N2"), E(StrOf(bl, "Currency")), E(StrOf(bl, "GLNumber")),
                                    E(StrOf(bl, "PetRef")), E(StrOf(bl, "CamId")), StatusBadgeHtml(StrOf(bl, "CamStatus")),
                                    E(StrOf(bl, "CamComments")), E(StrOf(bl, "LpoRequest")), StatusBadgeHtml(StrOf(bl, "LpoStatus")),
                                    E(StrOf(bl, "LpoComments")), invCount);

                                sb.AppendFormat(
                                    "<tr class='hier-lvl3-detail'><td colspan='15' style='padding:0;border:none;'>" +
                                    "<div id='lvl3b_{0}' class='hier-body'><table class='hier-table hier-lvl4-table'>" +
                                    "<thead><tr><th>Row#</th><th>Vendor Name</th><th>Justification</th><th>GL Number</th>" +
                                    "<th>Invoice ID</th><th>Invoice Number</th><th class='text-right'>Invoice Amount</th>" +
                                    "<th>Invoice Status</th><th>Payment Date</th><th>Action</th></tr></thead><tbody>",
                                    blId);

                                // ============ LEVEL 4 — Invoices (grey) ============
                                System.Collections.Generic.List<DataRow> invRows;
                                if (invByBudgetLine.TryGetValue(blId, out invRows) && invRows.Count > 0)
                                {
                                    int rn = 0;
                                    foreach (DataRow iv in invRows)
                                    {
                                        rn++;
                                        sb.AppendFormat(
                                            "<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td>" +
                                            "<td class='text-right'>{6}</td><td>{7}</td><td>{8}</td>" +
                                            "<td><a href='{9}' class='hier-act-btn hier-act-blue'><i class='fa-solid fa-arrow-up-right-from-square'></i></a></td></tr>",
                                            rn, E(StrOf(iv, "VendorName")), E(StrOf(iv, "Justification")), E(StrOf(iv, "GLNumber")),
                                            StrOf(iv, "InvoiceID"), E(StrOf(iv, "InvoiceNo")), DecOf(iv, "InvoiceAmount").ToString("N2"),
                                            StatusBadgeHtml(StrOf(iv, "InvoiceStatus")),
                                            iv["PaymentDate"] == DBNull.Value ? "" : Convert.ToDateTime(iv["PaymentDate"]).ToString("dd-MMM-yy"),
                                            ResolveUrl("~/Forms/PetWorkflow.aspx") + "?id=" + StrOf(iv, "PetFormID"));
                                    }
                                }
                                else
                                {
                                    sb.Append("<tr class='hier-empty-row'><td colspan='10'>No invoices for this CAM/LPO line.</td></tr>");
                                }
                                sb.Append("</tbody></table></div></td></tr>");
                            }
                        }
                        else
                        {
                            sb.Append("<tr class='hier-empty-row'><td colspan='15'>No CAM/LPO records for this Spend Request.</td></tr>");
                        }
                        sb.Append("</tbody></table></div></td></tr>");

                        // ---- Hidden Spend Items source (feeds the shared purple popup). Wrapped in a
                        // <script type="text/html"> block (NOT a bare <table>) because this markup is
                        // emitted as a sibling of <tr> inside another table's <tbody> — a raw nested
                        // <table> there is invalid HTML and gets foster-parented out by the browser's
                        // parser (closing the enclosing table early); <script> is explicitly allowed as a
                        // tbody child and its contents are never parsed as markup, so it survives intact. ----
                        System.Collections.Generic.List<DataRow> items;
                        sb.AppendFormat("<script type='text/html' id='spitems_{0}'>", petId);
                        if (itemsByPet.TryGetValue(petId, out items) && items.Count > 0)
                        {
                            foreach (DataRow li in items)
                            {
                                sb.AppendFormat(
                                    "<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td class='text-right'>{4}</td>" +
                                    "<td class='text-right'>{5}</td><td>{6}</td><td class='text-right'>{7}</td>" +
                                    "<td class='text-right'>{8}</td><td class='text-right'>{9}</td><td class='text-right'>{10}</td><td>{11}</td></tr>",
                                    E(StrOf(li, "ExpHead")), E(StrOf(li, "Topic")), E(StrOf(li, "VendorName")), E(StrOf(li, "CostType")),
                                    DecOf(li, "Units").ToString("N2"), DecOf(li, "UnitPrice").ToString("N2"), E(StrOf(li, "BaseCurrency")),
                                    DecOf(li, "AmtFCY").ToString("N2"), DecOf(li, "AmtLCY").ToString("N2"), DecOf(li, "ContingencyPct").ToString("N2"),
                                    DecOf(li, "FinalAmtLCY").ToString("N2"), E(StrOf(li, "GLNumber")));
                            }
                        }
                        else
                        {
                            sb.Append("<tr><td colspan='12' style='text-align:center;color:#94a3b8;padding:10px;'>No line items.</td></tr>");
                        }
                        sb.Append("</script>");
                    }

                    sb.Append("</tbody></table></div></td></tr>");
                }

                if (sb.Length == 0)
                    sb.Append("<tr><td colspan='13' style='text-align:center;padding:18px;color:#94a3b8;'>No projects found for the selected filters.</td></tr>");

                litPendingTree.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                litPendingTree.Text = "<tr><td colspan='13' style='padding:14px;color:#dc2626;'>Error loading data: " +
                    System.Web.HttpUtility.HtmlEncode(ex.Message) + "</td></tr>";
            }
        }

        // ===== Small rendering helpers for the Project Portfolio hierarchy =====
        private static string E(object v)
        {
            return v == null || v == DBNull.Value ? "" : System.Web.HttpUtility.HtmlEncode(v.ToString());
        }

        private static string JE(object v)
        {
            return System.Web.HttpUtility.JavaScriptStringEncode(v == null || v == DBNull.Value ? "" : v.ToString());
        }

        private static string StrOf(DataRow r, string col)
        {
            return r.Table.Columns.Contains(col) && r[col] != DBNull.Value ? r[col].ToString() : "";
        }

        private static decimal DecOf(DataRow r, string col)
        {
            return r.Table.Columns.Contains(col) && r[col] != DBNull.Value ? Convert.ToDecimal(r[col]) : 0m;
        }

        /// <summary>Renders a colored status badge (green/orange/red/blue/gray) from free-text status
        /// values (PetForm.Status, CamStatus, LpoStatus, InvoiceStatus all use different vocabularies,
        /// so this matches on common keywords rather than an exact enum).</summary>
        private static string StatusBadgeHtml(string status)
        {
            string s = (status ?? "").Trim();
            string label = string.IsNullOrEmpty(s) ? "-" : s;
            return "<span class='hier-badge " + StatusBadgeClass(s) + "'>" + System.Web.HttpUtility.HtmlEncode(label) + "</span>";
        }

        private static string StatusBadgeClass(string status)
        {
            string s = (status ?? "").ToLowerInvariant();
            if (s.Length == 0) return "hb-gray";
            if (s.Contains("reject") || s.Contains("cancel") || s.Contains("declin")) return "hb-red";
            if (s.Contains("approve") || s.Contains("paid") || s.Contains("issue") || s.Contains("complet") ||
                s.Contains("active") || s.Contains("settle") || s.Contains("archiv")) return "hb-green";
            if (s.Contains("pending") || s.Contains("progress") || s.Contains("review") || s.Contains("wait")) return "hb-orange";
            if (s.Contains("draft")) return "hb-gray";
            if (s.Contains("sent") || s.Contains("open") || s.Contains("new") || s.Contains("generat")) return "hb-blue";
            return "hb-gray";
        }

        private void LoadMyPet()
        {
            try
            {
               /* DataTable dt = WorkflowDAL.GetPetForms(AuthHelper.CurrentUserShort);
                gvMyPet.DataSource = dt;
                gvMyPet.DataBind();*/
            }
            catch { }
        }

        /// <summary>Renders the gvMyPet row's Delete button, but only for Draft / Pending Review / Pending
        /// Approval requests — hidden entirely once Approved (or Rejected/SentBack/Deleted), per the Delete
        /// Button Visibility business rule. Shared status rule lives in WorkflowDAL.IsPetDeletable.</summary>
        protected string DeleteButtonHtml(object petFormId, object petRefNo, object status)
        {
            string statusStr = status == null || status == DBNull.Value ? "" : status.ToString();
            if (!WorkflowDAL.IsPetDeletable(statusStr)) return "";

            string refNo = petRefNo == null || petRefNo == DBNull.Value ? "#" + petFormId : petRefNo.ToString();
            return "<button type='button' class='btn btn-xs btn-danger' onclick=\"dfmPetDel('" + petFormId + "','" +
                   System.Web.HttpUtility.JavaScriptStringEncode(refNo) + "');\"><i class='bi bi-trash'></i> Delete</button>";
        }

        /// <summary>Budget Line Items the current user has added across all of their (Approved) PET forms.</summary>
        private void LoadMyBudgetLines()
        {
            try
            {
                /*DataTable dt = WorkflowDAL.GetBudgetLinesByUser(AuthHelper.CurrentUserShort);
                gvMyBudgetLines.DataSource = dt;
                gvMyBudgetLines.DataBind();*/
            }
            catch { }
        }

        // ===== Events =====
        protected void Filter_Changed(object sender, EventArgs e)
        {
            CurrentPage = 1;
            LoadProjectHierarchy();
            LoadKPIs();
        }

        protected void btnResetFilters_Click(object sender, EventArgs e)
        {
            ddlProject.SelectedValue = "ALL";
            ddlType.SelectedValue    = "ALL";
            //ddlPortfolioFilter.SelectedValue = "ALL";
            ddlStatus.SelectedValue  = "ALL";
            ddlView.SelectedValue    = "MYAPPROVAL";
            txtFromDate.Text = txtToDate.Text = "";
            CurrentPage = 1;
            LoadAll();
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                string jiraFilter = ddlProject.SelectedValue == "ALL" ? null : ddlProject.SelectedValue;
                string typeFilter = ddlType.SelectedValue  == "ALL" ? null : ddlType.SelectedValue;
                string statFilter = ddlStatus.SelectedValue == "ALL" ? null : ddlStatus.SelectedValue;
                DateTime? fromDate = null, toDate = null;
                DateTime dt;
                if (DateTime.TryParse(txtFromDate.Text, out dt)) fromDate = dt;
                if (DateTime.TryParse(txtToDate.Text, out dt))   toDate   = dt;
                DataTable data = WorkflowDAL.GetPetFormsDashboard(jiraFilter, typeFilter, statFilter, fromDate, toDate);
                ExcelHelper.ExportDataTable(data, "PET_Dashboard", Response);
            }
            catch { }
        }

        protected void btnConfirmDeletePet_Click(object sender, EventArgs e)
        {
            int petId;
            if (int.TryParse(hfDeletePetId.Value, out petId) && petId > 0)
            {
                // Server-side guard mirrors the Delete button's visibility rule — re-fetch status fresh
                // from the DB rather than trusting anything client-side.
                DataRow f = WorkflowDAL.GetPetForm(petId);
                string status = f != null && f["Status"] != DBNull.Value ? f["Status"].ToString() : "";
                if (f != null && WorkflowDAL.IsPetDeletable(status))
                    WorkflowDAL.DeletePetForm(petId, AuthHelper.CurrentUserShort);
            }
            hfDeletePetId.Value = "0";
            CurrentPage = 1;
            LoadAll();
        }

        protected void btnExportMyBudgetLines_Click(object sender, EventArgs e)
        {
            ExcelHelper.ExportCsv(WorkflowDAL.GetBudgetLinesByUser(AuthHelper.CurrentUserShort), "My_Budget_Lines", Response);
        }

        protected void btnPrevPage_Click(object sender, EventArgs e)
        {
            if (CurrentPage > 1) { CurrentPage--; LoadProjectHierarchy(); }
        }

        protected void btnNextPage_Click(object sender, EventArgs e)
        {
            CurrentPage++;
            LoadProjectHierarchy();
        }

        protected void gvRegisteredProjects_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
           /* gvRegisteredProjects.PageIndex = e.NewPageIndex;
            LoadRegisteredProjects();*/
        }

        // ===== Export (CSV) =====
        protected void btnExportCsv_Click(object sender, EventArgs e)
        {
            try
            {
                string jiraFilter = ddlProject.SelectedValue == "ALL" ? null : ddlProject.SelectedValue;
                string typeFilter = ddlType.SelectedValue  == "ALL" ? null : ddlType.SelectedValue;
                string statFilter = ddlStatus.SelectedValue == "ALL" ? null : ddlStatus.SelectedValue;
                DateTime? fromDate = null, toDate = null;
                DateTime dt;
                if (DateTime.TryParse(txtFromDate.Text, out dt)) fromDate = dt;
                if (DateTime.TryParse(txtToDate.Text, out dt))   toDate   = dt;
                DataTable data = WorkflowDAL.GetPetFormsDashboard(jiraFilter, typeFilter, statFilter, fromDate, toDate);
                ExcelHelper.ExportCsv(data, "Project_Portfolio_Dashboard", Response);
            }
            catch { }
        }

        private static string Fmt(DataRow r, string col)
        {
            if (r == null || !r.Table.Columns.Contains(col) || r[col] == DBNull.Value) return "0";
            return Convert.ToInt32(r[col]).ToString("N0");
        }

        private static string FmtAmt(DataRow r, string col)
        {
            if (r == null || !r.Table.Columns.Contains(col) || r[col] == DBNull.Value) return "AED 0";
            decimal v = Convert.ToDecimal(r[col]);
            if (v >= 1000000m) return "AED " + (v / 1000000m).ToString("N2") + "M";
            if (v >= 1000m)    return "AED " + (v / 1000m).ToString("N1") + "K";
            return "AED " + v.ToString("N0");
        }
    }
}
