# Microsoft Entra ID SSO setup

## App registration

1. In Microsoft Entra admin center, create a new app registration for the CET portal.
2. Use **Accounts in this organizational directory only** unless the security team specifies otherwise.
3. Add a Web redirect URI:
   - Local: `http://localhost:3000/auth/callback`
   - Server: `https://your-approved-host/auth/callback`
4. Create a client secret for development only, or use the organization's approved certificate/managed-identity pattern for production.
5. Record Tenant ID, Application/Client ID and the secret value.
6. Add the production front-channel/logout URI if required by the identity team.

The current flow requests only `openid`, `profile`, and `email`. Microsoft Graph profile synchronization is deliberately deferred until its exact fields and permissions are approved.

## Local `.env`

```env
AUTH_MODE=entra
APP_BASE_URL=http://localhost:3000
ENTRA_TENANT_ID=<tenant-guid>
ENTRA_CLIENT_ID=<application-guid>
ENTRA_CLIENT_SECRET=<secret-value>
ENTRA_REDIRECT_URI=http://localhost:3000/auth/callback
ENTRA_POST_LOGOUT_REDIRECT_URI=http://localhost:3000
SESSION_SECRET=<long-random-value>
```

Restart `npm start`. Opening the portal will now present Microsoft sign-in instead of the local test entry.

## Portal authorization

Authentication proves identity; it does not automatically grant administrative access. On first successful SSO login, an unknown user is created as a read-only `viewer`. A portal administrator must assign a higher role in `application_users`, or the server phase can map approved Entra security groups to roles.

Recommended groups:

- CET Portal Super Admin
- CET Profile Admin
- CET Governance Editor
- CET Viewer

## Network prerequisites

The server and user browser must be able to reach `login.microsoftonline.com`. Corporate proxy, firewall and SSL-inspection rules should be validated before production testing. A proxy 504 indicates a network tunnel problem, not an application redirect-URI defect.
