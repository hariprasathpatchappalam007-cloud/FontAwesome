# Microsoft SQL Server deployment

## Migration approach

The local SQLite file is for portable PC testing. For the server environment:

1. Create an empty SQL Server database named `CETPortal` or the approved equivalent.
2. Create a least-privilege application account.
3. Configure the `MSSQL_*` environment settings.
4. Set `DB_PROVIDER=mssql`.
5. Run `npm run db:init` once from an authorized deployment account.
6. Start the application and check `/api/v1/health`.

The schema operation is idempotent at the table level and does not drop existing data.

## Production recommendations

- Require TLS encryption and keep `MSSQL_TRUST_SERVER_CERTIFICATE=false` with a trusted certificate.
- Restrict the application account to the CET database.
- Separate schema-deployment rights from runtime data rights.
- Configure database backups, retention and restore testing.
- Enable the organization's approved encryption-at-rest and audit policies.
- Use a migration pipeline for later schema versions instead of making manual table changes.

## Local data transition

Do not copy the SQLite database file to SQL Server. Initialize the SQL Server schema and migrate validated records through a controlled import/export script in the deployment phase. This avoids transferring local simulated seed records into production.
