# CET Command Center architecture — Phase 2A/2B

## Design boundary

The current baseline owns CET people, reporting lines, Units, application roles, profile administration, Platform responsibilities, portfolio governance, demand administration and the Squad operating model. Program records remain the ownership projection for the next delivery slice.

Portfolio records own strategic purpose, business area, accountable owner, Unit, dates, status and RAG health. Demand records link a request to its portfolio, demand owner and accountable manager while capturing classification, priority, stage, status, delivery dates, progress and RAG health. All write operations remain role-controlled and auditable.

Manager administration is derived from the reporting hierarchy rather than duplicated in a separate master table. Each direct reportee beneath the Department/Unit Head receives a live projection of Platforms owned or supported by the reporting subtree, accountable/team-owned demands, programs owned within the reporting subtree, squads led within the subtree, direct reports and all descendant resources. Workforce composition uses the maintained employment type and optional gender attributes.

Platforms are independent governed assets. `platform_assignments` connects each Platform to people using either `Owned` or `Supported`. The API permits one accountable owner and multiple supporters, and validates that every assignment belongs to the manager or a descendant beneath that manager. Portfolio records remain available for demand governance and are not repurposed as Platforms.

Squads and Tracks belong to one Platform and its accountable manager. `squad_staffing_plan` records required headcount by reusable `squad_roles`; `squad_assignments` separately records named resources, roles, allocation percentage, primary/shared status and assignment dates. This separation prevents partially staffed squads from appearing complete. Create and update operations validate the Platform, manager and every assigned person against the same manager administration tree. Delete operations archive the Squad or role instead of removing operational history.

## Request flow

```text
Browser SPA
  -> Express session and role authorization
  -> /api/v1 REST routes
  -> people repository / domain queries
  -> Knex database provider
  -> SQLite (local) or Microsoft SQL Server (server)
```

The browser never receives database credentials or the Entra client secret. Protected services are called only by the Node.js backend.

## Authentication provider

`AUTH_MODE=demo` creates a local super-administrator session solely for PC testing. `AUTH_MODE=entra` activates Microsoft Entra authorization-code login. A random state value protects the callback from cross-site request forgery. Only a minimal identity and portal role are kept in the session.

## Data portability

The application uses Knex schema/query APIs instead of embedding SQLite-specific UI logic. The same repository serves both providers. The provider is selected by environment configuration, so the frontend and API routes remain unchanged during migration.

Core hierarchy:

```text
units (stored in the backward-compatible verticals table) 1 --- * people
people    1 --- * people (manager_id)
people    1 --- * portfolios (owner)
portfolios 1 -- * demands
platforms 1 --- * platform_assignments
people    1 --- * platform_assignments (Owned / Supported)
platforms 1 --- * squads
people    1 --- * squads (manager / lead)
squads    1 --- * squad_staffing_plan
squad_roles 1 -- * squad_staffing_plan
squads    1 --- * squad_assignments
people    1 --- * squad_assignments
squad_roles 1 -- * squad_assignments
people    1 --- * demands (owner / accountable manager)
people    1 --- * programs (owner)
people    * --- * squads (squad_members)
```

## Traceability

Profile, Unit, Platform, portfolio, demand, Squad and Squad-role create/update actions write an audit record containing actor, action, entity and non-sensitive change metadata. Unit deactivation and record archive statuses are used instead of hard deletion.

The public API and interface use **Unit** terminology. The physical `verticals` table and `vertical_id` foreign keys are intentionally retained so installations can move from v2.0.1 to v2.1.0 without renaming tables, breaking Microsoft SQL constraints or losing existing relationships.

## Profile images

For PC testing, images are validated and saved beneath `public/uploads`. Only the relative URL is stored in the database. Production should replace this adapter with approved protected document/blob storage; profile photos should not be stored as large binary columns in the operational SQL tables.

## Expansion path

The next slice can add Major Program administration and capacity analytics without changing the person identity, Platform, portfolio, demand, Squad or reporting models. Jira remains the delivery source of truth and will be consumed through a backend adapter with normalized identifiers.
