const fs = require('node:fs');
const path = require('node:path');
const knex = require('knex');
const config = require('../config');

function createConnection(overrides = {}) {
  const provider = overrides.provider || config.db.provider;

  if (provider === 'sqlite') {
    const filename = overrides.sqliteFile || config.db.sqliteFile;
    if (filename !== ':memory:') fs.mkdirSync(path.dirname(filename), { recursive: true });
    return knex({
      client: 'better-sqlite3',
      connection: { filename },
      useNullAsDefault: true,
      pool: {
        afterCreate: (conn, done) => {
          conn.pragma('foreign_keys = ON');
          done(null, conn);
        }
      }
    });
  }

  const sql = { ...config.db.mssql, ...(overrides.mssql || {}) };
  return knex({
    client: 'mssql',
    connection: {
      server: sql.server,
      port: sql.port,
      database: sql.database,
      user: sql.user,
      password: sql.password,
      options: {
        encrypt: sql.encrypt,
        trustServerCertificate: sql.trustServerCertificate,
        enableArithAbort: true
      }
    },
    pool: { min: 0, max: 10 }
  });
}

module.exports = { createConnection };
