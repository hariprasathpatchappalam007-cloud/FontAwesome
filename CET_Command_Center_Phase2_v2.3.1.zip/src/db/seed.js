async function seedDatabase(db) {
  const existing = await db('verticals').first('id');
  if (existing) {
    await seedPhase2Data(db, { includePlatforms: false });
    return;
  }

  const verticalIds = await insertAndGetIds(db, 'verticals', [
    { name: 'CET Leadership', code: 'CET-LDR', description: 'Department leadership and governance', color: '#d4a72c' },
    { name: 'Digital Experience', code: 'DIG', description: 'Digital channels and customer journeys', color: '#28d7a1' },
    { name: 'Customer Platforms', code: 'CPL', description: 'CRM and customer engagement platforms', color: '#4ba3ff' },
    { name: 'Lending Platforms', code: 'LND', description: 'FinnOne and lending technology', color: '#a78bfa' }
  ]);

  const [leadershipId, digitalId, customerId, lendingId] = verticalIds;
  const people = [
    person('CET-001', 'Amina Rahman', 'Head of Customer Experience Technology', 'Staff', null, leadershipId, true, 'amina.rahman@example.com', 'Executive owner for CET strategy, delivery governance and platform performance.'),
    person('CET-010', 'Omar Farooq', 'Manager – Digital Experience', 'Staff', 1, digitalId, false, 'omar.farooq@example.com', 'Leads mobile, internet banking and digital customer journey delivery.'),
    person('CET-020', 'Leena Joseph', 'Manager – Customer Platforms', 'Staff', 1, customerId, false, 'leena.joseph@example.com', 'Owns CRM, contact centre and customer engagement platforms.'),
    person('CET-030', 'Vikram Nair', 'Manager – Lending Platforms', 'Staff', 1, lendingId, false, 'vikram.nair@example.com', 'Leads lending platforms, regulatory delivery and modernization.'),
    person('CON-101', 'Sara Khan', 'Senior Delivery Manager', 'Consultant', 2, digitalId, false, 'sara.khan@example.com', 'Manages digital delivery planning and squad execution.'),
    person('CET-011', 'Naveed Ali', 'Engineering Lead', 'Staff', 2, digitalId, false, 'naveed.ali@example.com', 'Engineering lead for digital channels and integration.'),
    person('CET-021', 'Maya Thomas', 'CRM Platform Lead', 'Staff', 3, customerId, false, 'maya.thomas@example.com', 'Platform lead for CRM and customer engagement solutions.'),
    person('CON-202', 'Rohit Menon', 'Genesys Solution Architect', 'Consultant', 3, customerId, false, 'rohit.menon@example.com', 'Solution architecture and release assurance for contact centre.'),
    person('CET-031', 'Fatima Zahra', 'FinnOne Delivery Lead', 'Staff', 4, lendingId, false, 'fatima.zahra@example.com', 'Delivery lead for lending platform initiatives.'),
    person('CON-303', 'Arjun Das', 'Senior QA Engineer', 'Consultant', 4, lendingId, false, 'arjun.das@example.com', 'Quality engineering and release validation for lending platforms.')
  ];
  await db('people').insert(people);

  await db('application_users').insert({
    email: 'admin@cet.local', display_name: 'CET Local Administrator', role: 'super_admin', is_active: true
  });

  await db('portfolios').insert([
    { name: 'Digital Channels Portfolio', code: 'PORT-DIG', owner_person_id: 2, vertical_id: digitalId, status: 'Active' },
    { name: 'Customer Engagement Portfolio', code: 'PORT-CX', owner_person_id: 3, vertical_id: customerId, status: 'Active' },
    { name: 'Lending Transformation Portfolio', code: 'PORT-LND', owner_person_id: 4, vertical_id: lendingId, status: 'Active' }
  ]);
  await db('programs').insert([
    { name: 'Digital Journey Modernization', code: 'PRG-DJM', owner_person_id: 2, status: 'In Progress' },
    { name: 'Contact Centre Transformation', code: 'PRG-CCT', owner_person_id: 3, status: 'In Progress' },
    { name: 'Lending Platform Upgrade', code: 'PRG-LPU', owner_person_id: 4, status: 'In Progress' }
  ]);
  await db('squads').insert([
    { name: 'Mobile Banking Squad', code: 'SQ-MB', lead_person_id: 6, vertical_id: digitalId, status: 'Active' },
    { name: 'CRM & Engagement Squad', code: 'SQ-CRM', lead_person_id: 7, vertical_id: customerId, status: 'Active' },
    { name: 'FinnOne Squad', code: 'SQ-FIN', lead_person_id: 9, vertical_id: lendingId, status: 'Active' }
  ]);
  await db('squad_members').insert([
    { squad_id: 1, person_id: 5, role: 'Delivery Manager' },
    { squad_id: 1, person_id: 6, role: 'Engineering Lead' },
    { squad_id: 2, person_id: 7, role: 'Platform Lead' },
    { squad_id: 2, person_id: 8, role: 'Solution Architect' },
    { squad_id: 3, person_id: 9, role: 'Delivery Lead' },
    { squad_id: 3, person_id: 10, role: 'QA Lead' }
  ]);
  await seedPhase2Data(db, { includePlatforms: true });
}

async function seedPhase2Data(db, { includePlatforms = false } = {}) {
  await seedProfileDemographics(db);
  await seedSquadRoles(db);
  if (includePlatforms) {
    await seedPlatforms(db);
    await seedSquadOperatingModel(db);
  }
  const portfolios = await db('portfolios').select('id', 'code');
  const portfolioByCode = new Map(portfolios.map((row) => [row.code, row.id]));
  const portfolioEnhancements = [
    ['PORT-DIG', 'Digital banking channels, customer journeys and secure self-service capabilities.', 'Digital Banking', 'Green', '2026-01-01', '2027-12-31', 'Increase digital adoption and reduce assisted-service dependency.'],
    ['PORT-CX', 'CRM, contact centre and omnichannel customer engagement capabilities.', 'Customer Experience', 'Amber', '2026-01-01', '2027-06-30', 'Create connected, compliant and measurable customer conversations.'],
    ['PORT-LND', 'Modernization of lending origination and servicing platforms.', 'Lending Technology', 'Green', '2026-02-01', '2028-03-31', 'Improve lending agility, control and customer turnaround time.']
  ];
  for (const [code, description, businessArea, health, startDate, targetEndDate, objectives] of portfolioEnhancements) {
    if (!portfolioByCode.has(code)) continue;
    await db('portfolios').where({ code }).update({
      description, business_area: businessArea, health, start_date: startDate, target_end_date: targetEndDate,
      strategic_objectives: objectives, is_active: true, updated_by: 'system'
    });
  }

  if (await db('demands').first('id')) return;
  await db('demands').insert([
    demand('DMGT-1201', 'Digital onboarding journey optimization', 'Customer Journey', 'Strategic', 'High', 'Assessment', 'In Progress', 2, 2, portfolioByCode.get('PORT-DIG'), 'Green', 35, '2026-05-01', '2026-12-15'),
    demand('DMGT-1244', 'Contact centre interaction analytics uplift', 'Customer Experience', 'Strategic', 'High', 'Technology Review', 'At Risk', 3, 3, portfolioByCode.get('PORT-CX'), 'Amber', 50, '2026-03-15', '2026-11-30'),
    demand('DMGT-1278', 'Lending customer notification controls', 'Regulatory', 'Regulatory', 'Critical', 'Delivery', 'In Progress', 4, 4, portfolioByCode.get('PORT-LND'), 'Green', 70, '2026-02-10', '2026-09-30'),
    demand('DMGT-1302', 'Authenticated servicing through digital channels', 'Digital Banking', 'Fast Track', 'Medium', 'Intake', 'New', 2, 2, portfolioByCode.get('PORT-DIG'), 'Green', 5, null, '2027-02-28'),
    demand('DMGT-1316', 'Conversation routing resilience improvements', 'Platform Resilience', 'Mandatory', 'High', 'Planning', 'On Hold', 3, 3, portfolioByCode.get('PORT-CX'), 'Red', 20, '2026-06-01', '2026-10-31')
  ].filter((row) => row.portfolio_id));
}

async function seedSquadRoles(db) {
  if (await db('squad_roles').first('id')) return;
  await db('squad_roles').insert([
    { code: 'RTE', name: 'Senior Delivery Manager / RTE', description: 'Technology programme delivery and release-train coordination.', category: 'Leadership', display_order: 10, is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'ENG', name: 'Engineering Lead', description: 'Engineering execution leadership and technical governance.', category: 'Engineering', display_order: 20, is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'TDM', name: 'Technical Delivery Manager', description: 'Agile delivery planning, dependency management and execution control.', category: 'Delivery', display_order: 30, is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'ONSITE', name: 'Onsite Lead', description: 'Onsite technical direction, coordination and mentoring.', category: 'Engineering', display_order: 40, is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'APPDEV', name: 'Application Developer', description: 'Application feature design and development.', category: 'Engineering', display_order: 50, is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'INTDEV', name: 'Integration Developer', description: 'API, middleware and integration delivery.', category: 'Engineering', display_order: 60, is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'QA', name: 'QA Engineer', description: 'Quality engineering, test automation and release assurance.', category: 'Quality', display_order: 70, is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'FUNC', name: 'Functional Lead', description: 'Product and platform functional leadership.', category: 'Functional', display_order: 80, is_active: true, created_by: 'system', updated_by: 'system' }
  ]);
}

async function seedSquadOperatingModel(db) {
  if (await db('squad_staffing_plan').first('id')) return;
  const [squads, platforms, people, roles] = await Promise.all([
    db('squads').select('id', 'code'), db('platforms').select('id', 'code', 'manager_person_id'),
    db('people').select('id', 'employee_id'), db('squad_roles').select('id', 'code')
  ]);
  const squadByCode = new Map(squads.map((row) => [row.code, row]));
  const platformByCode = new Map(platforms.map((row) => [row.code, row]));
  const personByCode = new Map(people.map((row) => [row.employee_id, row.id]));
  const roleByCode = new Map(roles.map((row) => [row.code, row.id]));
  const definitions = [
    { squad: 'SQ-MB', platform: 'PLT-MOB', name: 'Mobile Banking – Onboarding', description: 'Cross-functional squad delivering mobile onboarding and lifecycle capabilities.', order: 10,
      plan: { RTE: 1, ENG: 1, TDM: 1, ONSITE: 1, APPDEV: 3, INTDEV: 1, QA: 1 },
      assignments: [['CON-101', 'RTE', 100, true], ['CET-011', 'ENG', 100, true]] },
    { squad: 'SQ-CRM', platform: 'PLT-CRM', name: 'CRM & Engagement', description: 'Customer engagement platform delivery and operational improvement squad.', order: 10,
      plan: { RTE: 1, ENG: 1, TDM: 1, APPDEV: 2, INTDEV: 1, QA: 1, FUNC: 1 },
      assignments: [['CET-021', 'FUNC', 100, true], ['CON-202', 'ENG', 75, true]] },
    { squad: 'SQ-FIN', platform: 'PLT-FIN', name: 'FinnOne – Lending Delivery', description: 'Lending origination delivery, quality and platform modernization squad.', order: 10,
      plan: { ENG: 1, TDM: 1, ONSITE: 1, APPDEV: 4, INTDEV: 1, QA: 1, FUNC: 1 },
      assignments: [['CET-031', 'TDM', 100, true], ['CON-303', 'QA', 100, true]] }
  ];
  for (const definition of definitions) {
    const squad = squadByCode.get(definition.squad); const platform = platformByCode.get(definition.platform);
    if (!squad || !platform) continue;
    await db('squads').where({ id: squad.id }).update({
      name: definition.name, description: definition.description, platform_id: platform.id,
      manager_person_id: platform.manager_person_id, track_type: 'Delivery Squad', display_order: definition.order,
      is_active: true, updated_by: 'system'
    });
    const plan = Object.entries(definition.plan).map(([roleCode, requiredCount]) => ({
      squad_id: squad.id, role_id: roleByCode.get(roleCode), required_count: requiredCount
    })).filter((row) => row.role_id);
    if (plan.length) await db('squad_staffing_plan').insert(plan);
    const assignments = definition.assignments.map(([employeeId, roleCode, allocationPercent, isPrimary]) => ({
      squad_id: squad.id, person_id: personByCode.get(employeeId), role_id: roleByCode.get(roleCode),
      allocation_percent: allocationPercent, is_primary: isPrimary
    })).filter((row) => row.person_id && row.role_id);
    if (assignments.length) await db('squad_assignments').insert(assignments);
  }
}

async function seedPlatforms(db) {
  if (await db('platforms').first('id')) return;
  const people = await db('people').whereIn('employee_id', ['CET-010', 'CON-101', 'CET-011', 'CET-020', 'CET-021', 'CON-202', 'CET-030', 'CET-031', 'CON-303']).select('id', 'employee_id');
  const personByEmployeeId = new Map(people.map((personRecord) => [personRecord.employee_id, personRecord.id]));
  const platformIds = await insertAndGetIds(db, 'platforms', [
    { code: 'PLT-MOB', name: 'Mobile Banking', description: 'Retail mobile banking application and supporting customer services.', category: 'Digital Channel', vendor: 'In-house', manager_person_id: personByEmployeeId.get('CET-010'), status: 'Active', criticality: 'Critical', is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'PLT-WEB', name: 'Internet Banking', description: 'Retail web banking and authenticated servicing capabilities.', category: 'Digital Channel', vendor: 'In-house', manager_person_id: personByEmployeeId.get('CET-010'), status: 'Active', criticality: 'High', is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'PLT-CRM', name: 'Customer Relationship Management', description: 'Customer relationship, lead and engagement management platform.', category: 'Customer Platform', vendor: 'Enterprise CRM', manager_person_id: personByEmployeeId.get('CET-020'), status: 'Active', criticality: 'High', is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'PLT-GEN', name: 'Contact Centre Platform', description: 'Voice, routing and agent experience capabilities.', category: 'Customer Platform', vendor: 'Genesys', manager_person_id: personByEmployeeId.get('CET-020'), status: 'Active', criticality: 'Critical', is_active: true, created_by: 'system', updated_by: 'system' },
    { code: 'PLT-FIN', name: 'Lending Origination Platform', description: 'Retail lending origination and servicing capabilities.', category: 'Lending', vendor: 'FinnOne', manager_person_id: personByEmployeeId.get('CET-030'), status: 'Active', criticality: 'Critical', is_active: true, created_by: 'system', updated_by: 'system' }
  ]);
  const [mobileId, webId, crmId, contactId, lendingId] = platformIds;
  const assignment = (platformId, employeeId, relationship) => ({ platform_id: platformId, person_id: personByEmployeeId.get(employeeId), relationship });
  await db('platform_assignments').insert([
    assignment(mobileId, 'CET-010', 'Owned'), assignment(mobileId, 'CET-011', 'Supported'), assignment(mobileId, 'CON-101', 'Supported'),
    assignment(webId, 'CET-010', 'Owned'), assignment(webId, 'CET-011', 'Supported'),
    assignment(crmId, 'CET-020', 'Owned'), assignment(crmId, 'CET-021', 'Supported'),
    assignment(contactId, 'CET-020', 'Owned'), assignment(contactId, 'CON-202', 'Supported'),
    assignment(lendingId, 'CET-030', 'Owned'), assignment(lendingId, 'CET-031', 'Supported'), assignment(lendingId, 'CON-303', 'Supported')
  ].filter((record) => record.platform_id && record.person_id));
}

async function seedProfileDemographics(db) {
  const genders = {
    'CET-001': 'Female', 'CET-010': 'Male', 'CET-020': 'Female', 'CET-030': 'Male', 'CON-101': 'Female',
    'CET-011': 'Male', 'CET-021': 'Female', 'CON-202': 'Male', 'CET-031': 'Female', 'CON-303': 'Male'
  };
  for (const [employeeId, gender] of Object.entries(genders)) {
    await db('people').where({ employee_id: employeeId }).whereNull('gender').update({ gender });
  }
}

function demand(demandId, title, category, classification, priority, stage, status, ownerId, managerId, portfolioId, health, progress, startDate, endDate) {
  return {
    demand_id: demandId, title, category, classification, priority, stage, status,
    description: `${title} governed through the CET demand portfolio.`, requesting_department: 'Consumer Banking',
    requestor_name: 'Business Product Owner', owner_person_id: ownerId, accountable_manager_id: managerId,
    portfolio_id: portfolioId, health, progress_percent: progress, planned_start_date: startDate,
    planned_end_date: endDate, is_active: true, created_by: 'system', updated_by: 'system'
  };
}

function person(employeeId, fullName, designation, employmentType, managerId, verticalId, isHead, email, summary) {
  return {
    employee_id: employeeId,
    full_name: fullName,
    display_name: fullName,
    email,
    designation,
    functional_role: designation,
    employment_type: employmentType,
    employer: employmentType === 'Consultant' ? 'Strategic Technology Partner' : 'CET',
    location: 'Dubai',
    manager_id: managerId,
    vertical_id: verticalId,
    profile_summary: summary,
    skills: 'Delivery, Technology Governance, Stakeholder Management',
    is_vertical_head: isHead,
    is_active: true,
    created_by: 'system',
    updated_by: 'system'
  };
}

async function insertAndGetIds(db, table, rows) {
  const ids = [];
  for (const row of rows) {
    const result = await db(table).insert(row);
    if (Array.isArray(result) && result[0] && typeof result[0] === 'object') ids.push(result[0].id);
    else if (Array.isArray(result)) ids.push(Number(result[0]));
  }
  if (ids.length === rows.length && ids.every(Number.isFinite)) return ids;
  const records = await db(table).whereIn('code', rows.map((row) => row.code)).select('id', 'code');
  const map = new Map(records.map((row) => [row.code, row.id]));
  return rows.map((row) => map.get(row.code));
}

module.exports = { seedDatabase };
