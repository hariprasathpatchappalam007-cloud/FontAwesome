async function createSchema(db) {
  if (!(await db.schema.hasTable('verticals'))) {
    await db.schema.createTable('verticals', (table) => {
      table.increments('id').primary();
      table.string('name', 120).notNullable().unique();
      table.string('code', 30).notNullable().unique();
      table.string('description', 600);
      table.string('color', 20).notNullable().defaultTo('#20c997');
      table.boolean('is_active').notNullable().defaultTo(true);
      table.timestamps(true, true);
    });
  }

  if (!(await db.schema.hasTable('people'))) {
    await db.schema.createTable('people', (table) => {
      table.increments('id').primary();
      table.string('employee_id', 50).notNullable().unique();
      table.string('entra_object_id', 80).unique().nullable();
      table.string('full_name', 160).notNullable();
      table.string('display_name', 120).notNullable();
      table.string('email', 180).notNullable().unique();
      table.string('phone', 40);
      table.string('designation', 140).notNullable();
      table.string('functional_role', 140);
      table.string('employment_type', 20).notNullable();
      table.string('employer', 160);
      table.string('grade', 40);
      table.string('location', 100);
      table.string('gender', 20);
      table.string('cost_center', 50);
      table.date('joining_date');
      table.date('contract_end_date');
      table.integer('manager_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.integer('vertical_id').unsigned().references('id').inTable('verticals').onDelete('SET NULL');
      table.string('photo_url', 500);
      table.text('profile_summary');
      table.text('skills');
      table.text('certifications');
      table.boolean('is_vertical_head').notNullable().defaultTo(false);
      table.boolean('is_active').notNullable().defaultTo(true);
      table.string('created_by', 180);
      table.string('updated_by', 180);
      table.timestamps(true, true);
      table.index(['manager_id']);
      table.index(['vertical_id']);
      table.index(['employment_type']);
    });
  } else {
    await addMissingColumns(db, 'people', [
      ['gender', (table) => table.string('gender', 20)]
    ]);
  }

  if (!(await db.schema.hasTable('application_users'))) {
    await db.schema.createTable('application_users', (table) => {
      table.increments('id').primary();
      table.string('entra_object_id', 80).unique().nullable();
      table.string('email', 180).notNullable().unique();
      table.string('display_name', 160).notNullable();
      table.string('role', 40).notNullable().defaultTo('viewer');
      table.integer('person_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.boolean('is_active').notNullable().defaultTo(true);
      table.timestamp('last_login_at');
      table.timestamps(true, true);
    });
  }

  if (!(await db.schema.hasTable('platforms'))) {
    await db.schema.createTable('platforms', (table) => {
      table.increments('id').primary();
      table.string('code', 40).notNullable().unique();
      table.string('name', 180).notNullable();
      table.text('description');
      table.string('category', 100);
      table.string('vendor', 140);
      table.integer('manager_person_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.string('status', 30).notNullable().defaultTo('Active');
      table.string('criticality', 20).notNullable().defaultTo('Medium');
      table.boolean('is_active').notNullable().defaultTo(true);
      table.string('created_by', 180);
      table.string('updated_by', 180);
      table.timestamps(true, true);
      table.index(['manager_person_id']);
      table.index(['status', 'criticality']);
    });
  } else {
    await addMissingColumns(db, 'platforms', [
      ['manager_person_id', (table) => table.integer('manager_person_id').unsigned().references('id').inTable('people').onDelete('SET NULL')]
    ]);
  }

  if (!(await db.schema.hasTable('platform_assignments'))) {
    await db.schema.createTable('platform_assignments', (table) => {
      table.increments('id').primary();
      table.integer('platform_id').unsigned().notNullable().references('id').inTable('platforms').onDelete('CASCADE');
      table.integer('person_id').unsigned().notNullable().references('id').inTable('people').onDelete('CASCADE');
      table.string('relationship', 20).notNullable();
      table.timestamps(true, true);
      table.unique(['platform_id', 'person_id']);
      table.index(['person_id', 'relationship']);
    });
  }

  if (!(await db.schema.hasTable('portfolios'))) {
    await db.schema.createTable('portfolios', (table) => {
      table.increments('id').primary();
      table.string('name', 160).notNullable();
      table.string('code', 40).notNullable().unique();
      table.text('description');
      table.string('business_area', 120);
      table.integer('owner_person_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.integer('vertical_id').unsigned().references('id').inTable('verticals').onDelete('SET NULL');
      table.string('status', 30).notNullable().defaultTo('Active');
      table.string('health', 20).notNullable().defaultTo('Green');
      table.date('start_date');
      table.date('target_end_date');
      table.text('strategic_objectives');
      table.boolean('is_active').notNullable().defaultTo(true);
      table.string('created_by', 180);
      table.string('updated_by', 180);
      table.timestamps(true, true);
      table.index(['owner_person_id']);
      table.index(['vertical_id']);
      table.index(['status', 'health']);
    });
  } else {
    await addMissingColumns(db, 'portfolios', [
      ['description', (table) => table.text('description')],
      ['business_area', (table) => table.string('business_area', 120)],
      ['health', (table) => table.string('health', 20).notNullable().defaultTo('Green')],
      ['start_date', (table) => table.date('start_date')],
      ['target_end_date', (table) => table.date('target_end_date')],
      ['strategic_objectives', (table) => table.text('strategic_objectives')],
      ['is_active', (table) => table.boolean('is_active').notNullable().defaultTo(true)],
      ['created_by', (table) => table.string('created_by', 180)],
      ['updated_by', (table) => table.string('updated_by', 180)]
    ]);
  }

  if (!(await db.schema.hasTable('programs'))) {
    await db.schema.createTable('programs', (table) => {
      table.increments('id').primary();
      table.string('name', 180).notNullable();
      table.string('code', 40).notNullable().unique();
      table.integer('owner_person_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.string('status', 30).notNullable().defaultTo('In Progress');
      table.timestamps(true, true);
    });
  }

  if (!(await db.schema.hasTable('squads'))) {
    await db.schema.createTable('squads', (table) => {
      table.increments('id').primary();
      table.string('name', 160).notNullable();
      table.string('code', 40).notNullable().unique();
      table.text('description');
      table.integer('platform_id').unsigned().references('id').inTable('platforms').onDelete('SET NULL');
      table.integer('manager_person_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.integer('lead_person_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.integer('vertical_id').unsigned().references('id').inTable('verticals').onDelete('SET NULL');
      table.string('track_type', 30).notNullable().defaultTo('Delivery Squad');
      table.string('status', 30).notNullable().defaultTo('Active');
      table.integer('display_order').notNullable().defaultTo(0);
      table.boolean('is_active').notNullable().defaultTo(true);
      table.string('created_by', 180);
      table.string('updated_by', 180);
      table.timestamps(true, true);
      table.index(['platform_id', 'display_order']);
      table.index(['manager_person_id']);
    });
  } else {
    await addMissingColumns(db, 'squads', [
      ['description', (table) => table.text('description')],
      ['platform_id', (table) => table.integer('platform_id').unsigned().references('id').inTable('platforms').onDelete('SET NULL')],
      ['manager_person_id', (table) => table.integer('manager_person_id').unsigned().references('id').inTable('people').onDelete('SET NULL')],
      ['track_type', (table) => table.string('track_type', 30).notNullable().defaultTo('Delivery Squad')],
      ['display_order', (table) => table.integer('display_order').notNullable().defaultTo(0)],
      ['is_active', (table) => table.boolean('is_active').notNullable().defaultTo(true)],
      ['created_by', (table) => table.string('created_by', 180)],
      ['updated_by', (table) => table.string('updated_by', 180)]
    ]);
  }

  if (!(await db.schema.hasTable('squad_members'))) {
    await db.schema.createTable('squad_members', (table) => {
      table.increments('id').primary();
      table.integer('squad_id').unsigned().notNullable().references('id').inTable('squads').onDelete('CASCADE');
      table.integer('person_id').unsigned().notNullable().references('id').inTable('people').onDelete('CASCADE');
      table.string('role', 100);
      table.boolean('is_primary').notNullable().defaultTo(true);
      table.unique(['squad_id', 'person_id']);
    });
  }

  if (!(await db.schema.hasTable('squad_roles'))) {
    await db.schema.createTable('squad_roles', (table) => {
      table.increments('id').primary();
      table.string('code', 30).notNullable().unique();
      table.string('name', 120).notNullable().unique();
      table.string('description', 400);
      table.string('category', 50).notNullable().defaultTo('Delivery');
      table.integer('display_order').notNullable().defaultTo(0);
      table.boolean('is_active').notNullable().defaultTo(true);
      table.string('created_by', 180);
      table.string('updated_by', 180);
      table.timestamps(true, true);
    });
  }

  if (!(await db.schema.hasTable('squad_staffing_plan'))) {
    await db.schema.createTable('squad_staffing_plan', (table) => {
      table.increments('id').primary();
      table.integer('squad_id').unsigned().notNullable().references('id').inTable('squads').onDelete('CASCADE');
      table.integer('role_id').unsigned().notNullable().references('id').inTable('squad_roles').onDelete('CASCADE');
      table.integer('required_count').notNullable().defaultTo(0);
      table.timestamps(true, true);
      table.unique(['squad_id', 'role_id']);
    });
  }

  if (!(await db.schema.hasTable('squad_assignments'))) {
    await db.schema.createTable('squad_assignments', (table) => {
      table.increments('id').primary();
      table.integer('squad_id').unsigned().notNullable().references('id').inTable('squads').onDelete('CASCADE');
      table.integer('person_id').unsigned().notNullable().references('id').inTable('people').onDelete('CASCADE');
      table.integer('role_id').unsigned().notNullable().references('id').inTable('squad_roles').onDelete('CASCADE');
      table.integer('allocation_percent').notNullable().defaultTo(100);
      table.boolean('is_primary').notNullable().defaultTo(true);
      table.date('start_date');
      table.date('end_date');
      table.timestamps(true, true);
      table.unique(['squad_id', 'person_id', 'role_id']);
      table.index(['person_id', 'role_id']);
    });
  }

  if (!(await db.schema.hasTable('demands'))) {
    await db.schema.createTable('demands', (table) => {
      table.increments('id').primary();
      table.string('demand_id', 50).notNullable().unique();
      table.string('title', 220).notNullable();
      table.text('description');
      table.string('category', 80);
      table.string('classification', 40).notNullable().defaultTo('Strategic');
      table.string('priority', 20).notNullable().defaultTo('Medium');
      table.string('stage', 50).notNullable().defaultTo('Intake');
      table.string('status', 40).notNullable().defaultTo('New');
      table.string('requesting_department', 140);
      table.string('requestor_name', 160);
      table.integer('owner_person_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.integer('accountable_manager_id').unsigned().references('id').inTable('people').onDelete('SET NULL');
      table.integer('portfolio_id').unsigned().references('id').inTable('portfolios').onDelete('SET NULL');
      table.integer('program_id').unsigned().references('id').inTable('programs').onDelete('SET NULL');
      table.integer('squad_id').unsigned().references('id').inTable('squads').onDelete('SET NULL');
      table.date('planned_start_date');
      table.date('planned_end_date');
      table.string('health', 20).notNullable().defaultTo('Green');
      table.integer('progress_percent').notNullable().defaultTo(0);
      table.boolean('is_active').notNullable().defaultTo(true);
      table.string('created_by', 180);
      table.string('updated_by', 180);
      table.timestamps(true, true);
      table.index(['portfolio_id']);
      table.index(['owner_person_id']);
      table.index(['accountable_manager_id']);
      table.index(['status', 'health']);
    });
  }

  if (!(await db.schema.hasTable('audit_logs'))) {
    await db.schema.createTable('audit_logs', (table) => {
      table.increments('id').primary();
      table.string('actor_email', 180).notNullable();
      table.string('action', 60).notNullable();
      table.string('entity_type', 60).notNullable();
      table.string('entity_id', 80).notNullable();
      table.text('details');
      table.timestamp('created_at').notNullable().defaultTo(db.fn.now());
      table.index(['entity_type', 'entity_id']);
    });
  }
}

async function addMissingColumns(db, tableName, columns) {
  for (const [columnName, addColumn] of columns) {
    if (await db.schema.hasColumn(tableName, columnName)) continue;
    await db.schema.alterTable(tableName, addColumn);
  }
}

module.exports = { createSchema };
