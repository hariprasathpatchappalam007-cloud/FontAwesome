const { createConnection } = require('./connection');
const { createSchema } = require('./schema');
const { seedDatabase } = require('./seed');

async function initializeDatabase(overrides = {}) {
  const db = createConnection(overrides);
  await createSchema(db);
  if (overrides.seed !== false) await seedDatabase(db);
  await normalizeHierarchyRoles(db);
  return db;
}

async function normalizeHierarchyRoles(db) {
  if (!(await db.schema.hasTable('people'))) return;
  await db('people').whereNull('manager_id').update({ is_vertical_head: true });
  await db('people').whereNotNull('manager_id').update({ is_vertical_head: false });
}

module.exports = { initializeDatabase };
