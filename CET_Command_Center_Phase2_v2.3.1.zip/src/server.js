const config = require('./config');
const { createApp } = require('./app');

(async () => {
  const app = await createApp();
  const server = app.listen(config.port, () => {
    console.log(`CET Portal running at ${config.appBaseUrl}`);
    console.log(`Authentication mode: ${config.authMode}; database: ${config.db.provider}`);
  });

  async function shutdown() {
    server.close(async () => {
      await app.locals.db.destroy();
      process.exit(0);
    });
  }
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
