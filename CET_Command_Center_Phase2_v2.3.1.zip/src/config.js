const path = require('node:path');
require('dotenv').config();

const rootDir = path.resolve(__dirname, '..');
const authMode = (process.env.AUTH_MODE || 'demo').toLowerCase();
const dbProvider = (process.env.DB_PROVIDER || 'sqlite').toLowerCase();
const nodeEnv = process.env.NODE_ENV || 'development';

if (!['demo', 'entra'].includes(authMode)) {
  throw new Error('AUTH_MODE must be either demo or entra.');
}

if (!['sqlite', 'mssql'].includes(dbProvider)) {
  throw new Error('DB_PROVIDER must be either sqlite or mssql.');
}

if (nodeEnv === 'production' && authMode === 'demo') {
  throw new Error('AUTH_MODE=demo is prohibited in production. Configure Microsoft Entra ID.');
}

if (nodeEnv === 'production' && !process.env.SESSION_SECRET) {
  throw new Error('SESSION_SECRET is required in production.');
}

module.exports = {
  rootDir,
  port: Number(process.env.PORT || 3000),
  nodeEnv,
  appBaseUrl: process.env.APP_BASE_URL || 'http://localhost:3000',
  sessionSecret: process.env.SESSION_SECRET || 'local-development-change-me',
  authMode,
  entra: {
    tenantId: process.env.ENTRA_TENANT_ID || '',
    clientId: process.env.ENTRA_CLIENT_ID || '',
    clientSecret: process.env.ENTRA_CLIENT_SECRET || '',
    redirectUri: process.env.ENTRA_REDIRECT_URI || 'http://localhost:3000/auth/callback',
    postLogoutRedirectUri: process.env.ENTRA_POST_LOGOUT_REDIRECT_URI || 'http://localhost:3000'
  },
  db: {
    provider: dbProvider,
    sqliteFile: path.resolve(rootDir, process.env.SQLITE_FILE || './data/cet-portal.db'),
    mssql: {
      server: process.env.MSSQL_SERVER || '',
      port: Number(process.env.MSSQL_PORT || 1433),
      database: process.env.MSSQL_DATABASE || 'CETPortal',
      user: process.env.MSSQL_USER || '',
      password: process.env.MSSQL_PASSWORD || '',
      encrypt: process.env.MSSQL_ENCRYPT !== 'false',
      trustServerCertificate: process.env.MSSQL_TRUST_SERVER_CERTIFICATE === 'true'
    }
  },
  uploadsDir: path.resolve(rootDir, 'public/uploads'),
  maxProfilePhotoBytes: Number(process.env.MAX_PROFILE_PHOTO_MB || 3) * 1024 * 1024
};
