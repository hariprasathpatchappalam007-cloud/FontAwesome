const PERSON_COLUMNS = [
  'p.id', 'p.employee_id', 'p.entra_object_id', 'p.full_name', 'p.display_name', 'p.email', 'p.phone',
  'p.designation', 'p.functional_role', 'p.employment_type', 'p.employer', 'p.grade', 'p.location',
  'p.cost_center', 'p.joining_date', 'p.contract_end_date', 'p.gender', 'p.manager_id', 'p.vertical_id',
  'p.photo_url', 'p.profile_summary', 'p.skills', 'p.certifications', 'p.is_vertical_head',
  'p.is_active', 'p.created_at', 'p.updated_at'
];

function createPeopleRepository(db) {
  function baseQuery() {
    return db('people as p')
      .leftJoin('people as m', 'p.manager_id', 'm.id')
      .leftJoin('verticals as v', 'p.vertical_id', 'v.id')
      .select([...PERSON_COLUMNS, 'm.display_name as manager_name', 'v.name as vertical_name', 'v.color as vertical_color']);
  }

  async function list(filters = {}) {
    const query = baseQuery().orderBy('p.display_name');
    if (filters.search) {
      const term = `%${filters.search}%`;
      query.where((builder) => builder
        .whereLike('p.full_name', term)
        .orWhereLike('p.employee_id', term)
        .orWhereLike('p.email', term)
        .orWhereLike('p.designation', term));
    }
    if (filters.verticalId) query.where('p.vertical_id', filters.verticalId);
    if (filters.employmentType) query.where('p.employment_type', filters.employmentType);
    if (filters.active !== undefined) query.where('p.is_active', filters.active);
    return query;
  }

  async function getById(id) {
    const person = await baseQuery().where('p.id', id).first();
    if (!person) return null;
    const [portfolios, programs, squads] = await Promise.all([
      db('portfolios').where('owner_person_id', id).select('id', 'name', 'code', 'status'),
      db('programs').where('owner_person_id', id).select('id', 'name', 'code', 'status'),
      db('squad_members as sm').join('squads as s', 'sm.squad_id', 's.id')
        .where('sm.person_id', id).select('s.id', 's.name', 's.code', 's.status', 'sm.role', 'sm.is_primary')
    ]);
    return { ...person, portfolios, programs, squads };
  }

  async function create(payload, actorEmail) {
    const record = normalizePayload(payload, actorEmail, true);
    const result = await db('people').insert(record);
    let id = Array.isArray(result) ? result[0] : result;
    if (id && typeof id === 'object') id = id.id;
    if (!Number.isFinite(Number(id))) {
      const saved = await db('people').where('employee_id', record.employee_id).first('id');
      id = saved.id;
    }
    await audit(actorEmail, 'CREATE', id, { employee_id: record.employee_id, full_name: record.full_name });
    return getById(id);
  }

  async function update(id, payload, actorEmail) {
    const existing = await db('people').where('id', id).first();
    if (!existing) return null;
    const record = normalizePayload(payload, actorEmail, false);
    await db('people').where('id', id).update(record);
    await audit(actorEmail, 'UPDATE', id, { changed_fields: Object.keys(record) });
    return getById(id);
  }

  async function getOrganization() {
    const people = await list({ active: true });
    const byId = new Map(people.map((person) => [person.id, { ...person, children: [] }]));
    const roots = [];
    for (const person of byId.values()) {
      const manager = byId.get(person.manager_id);
      if (manager && manager.id !== person.id) manager.children.push(person);
      else roots.push(person);
    }
    return roots;
  }

  async function listVerticals() {
    return db('verticals').where('is_active', true).orderBy('name');
  }

  async function stats() {
    const [totalResult, staffResult, consultantResult, verticalResult, platformResult, portfolioResult, demandResult, programResult, squadResult] = await Promise.all([
      db('people').where('is_active', true).count({ count: '*' }).first(),
      db('people').where({ is_active: true, employment_type: 'Staff' }).count({ count: '*' }).first(),
      db('people').where({ is_active: true, employment_type: 'Consultant' }).count({ count: '*' }).first(),
      db('verticals').where('is_active', true).count({ count: '*' }).first(),
      db('platforms').where('is_active', true).count({ count: '*' }).first(),
      db('portfolios').where('status', 'Active').count({ count: '*' }).first(),
      db('demands').where('is_active', true).count({ count: '*' }).first(),
      db('programs').where('status', 'In Progress').count({ count: '*' }).first(),
      db('squads').where('status', 'Active').count({ count: '*' }).first()
    ]);
    return {
      people: Number(totalResult.count), staff: Number(staffResult.count), consultants: Number(consultantResult.count),
      verticals: Number(verticalResult.count), platforms: Number(platformResult.count), portfolios: Number(portfolioResult.count),
      demands: Number(demandResult.count), programs: Number(programResult.count), squads: Number(squadResult.count)
    };
  }

  async function dashboardOwnership() {
    const heads = await db('people').whereNull('manager_id').where('is_active', true).pluck('id');
    const leaders = heads.length
      ? await baseQuery().whereIn('p.manager_id', heads).where('p.is_active', true).orderBy('p.display_name')
      : [];
    for (const leader of leaders) {
      const [team, platforms, portfolios, programs, squads] = await Promise.all([
        db('people').where({ manager_id: leader.id, is_active: true }).count({ count: '*' }).first(),
        db('platforms').where({ manager_person_id: leader.id, is_active: true }).select('id', 'name', 'code', 'status'),
        db('portfolios').where('owner_person_id', leader.id).select('id', 'name', 'code', 'status'),
        db('programs').where('owner_person_id', leader.id).select('id', 'name', 'code', 'status'),
        db('squads').where((builder) => builder.where('manager_person_id', leader.id).orWhere('lead_person_id', leader.id)).where('is_active', true).select('id', 'name', 'code', 'status')
      ]);
      leader.direct_reports = Number(team.count);
      leader.platforms = platforms;
      leader.portfolios = portfolios;
      leader.programs = programs;
      leader.squads = squads;
    }
    return leaders;
  }

  async function audit(actorEmail, action, entityId, details) {
    await db('audit_logs').insert({
      actor_email: actorEmail,
      action,
      entity_type: 'person',
      entity_id: String(entityId),
      details: JSON.stringify(details)
    });
  }

  return { list, getById, create, update, getOrganization, listVerticals, stats, dashboardOwnership };
}

function normalizePayload(payload, actorEmail, isCreate) {
  const fields = [
    'employee_id', 'entra_object_id', 'full_name', 'display_name', 'email', 'phone', 'designation',
    'functional_role', 'employment_type', 'employer', 'grade', 'location', 'cost_center', 'joining_date', 'gender',
    'contract_end_date', 'manager_id', 'vertical_id', 'photo_url', 'profile_summary', 'skills',
    'certifications', 'is_vertical_head', 'is_active'
  ];
  const record = {};
  for (const field of fields) {
    if (payload[field] !== undefined) record[field] = emptyToNull(payload[field]);
  }
  if (record.full_name && !record.display_name) record.display_name = record.full_name;
  for (const field of ['manager_id', 'vertical_id']) {
    if (record[field] !== undefined && record[field] !== null) record[field] = Number(record[field]);
  }
  for (const field of ['is_vertical_head', 'is_active']) {
    if (record[field] !== undefined) record[field] = Boolean(record[field]);
  }
  if (record.manager_id !== undefined) record.is_vertical_head = record.manager_id === null;
  record.updated_by = actorEmail;
  record.updated_at = new Date();
  if (isCreate) {
    record.created_by = actorEmail;
    record.created_at = new Date();
    if (record.is_active === undefined) record.is_active = true;
    if (record.is_vertical_head === undefined) record.is_vertical_head = false;
  }
  return record;
}

function emptyToNull(value) {
  return typeof value === 'string' && value.trim() === '' ? null : value;
}

module.exports = { createPeopleRepository };
