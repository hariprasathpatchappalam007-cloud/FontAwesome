const PORTFOLIO_FIELDS = [
  'name', 'code', 'description', 'business_area', 'owner_person_id', 'vertical_id', 'status', 'health',
  'start_date', 'target_end_date', 'strategic_objectives', 'is_active'
];

const DEMAND_FIELDS = [
  'demand_id', 'title', 'description', 'category', 'classification', 'priority', 'stage', 'status',
  'requesting_department', 'requestor_name', 'owner_person_id', 'accountable_manager_id', 'portfolio_id',
  'program_id', 'squad_id', 'planned_start_date', 'planned_end_date', 'health', 'progress_percent', 'is_active'
];

const UNIT_FIELDS = ['name', 'code', 'description', 'color', 'is_active'];
const PLATFORM_FIELDS = ['name', 'code', 'description', 'category', 'vendor', 'manager_person_id', 'status', 'criticality', 'is_active'];

function createWorkRepository(db) {
  async function listUnits(filters = {}) {
    const query = db('verticals').select('*').orderBy('name');
    if (filters.active !== undefined) query.where('is_active', filters.active);
    return query;
  }

  async function getUnit(id) {
    return db('verticals').where({ id }).first();
  }

  async function saveUnit(id, payload, actorEmail) {
    const record = normalize(payload, UNIT_FIELDS);
    record.code = record.code ? String(record.code).toUpperCase() : record.code;
    record.color = record.color || '#087a59';
    record.updated_at = new Date();
    if (id) {
      const exists = await db('verticals').where({ id }).first('id');
      if (!exists) return null;
      await db('verticals').where({ id }).update(record);
      await audit(actorEmail, 'UPDATE', 'unit', id, { changed_fields: Object.keys(record) });
      return getUnit(id);
    }
    record.created_at = new Date();
    if (record.is_active === undefined) record.is_active = true;
    const insertedId = await insertAndResolveId('verticals', record, 'code');
    await audit(actorEmail, 'CREATE', 'unit', insertedId, { code: record.code, name: record.name });
    return getUnit(insertedId);
  }

  async function listPlatforms(filters = {}) {
    const query = db('platforms as plt').select('plt.*').orderBy('plt.name');
    if (filters.active !== undefined) query.where('plt.is_active', filters.active);
    if (filters.managerPersonId) query.where('plt.manager_person_id', Number(filters.managerPersonId));
    if (filters.personIds?.length) {
      query.whereIn('plt.id', db('platform_assignments').select('platform_id').whereIn('person_id', filters.personIds));
    }
    const platforms = await query;
    for (const platform of platforms) platform.assignments = await platformAssignments(platform.id);
    return platforms;
  }

  async function getPlatform(id) {
    const platform = await db('platforms').where({ id }).first();
    if (!platform) return null;
    platform.assignments = await platformAssignments(id);
    return platform;
  }

  async function platformAssignments(platformId) {
    return db('platform_assignments as pa')
      .join('people as p', 'pa.person_id', 'p.id')
      .where('pa.platform_id', platformId)
      .select('pa.id', 'pa.person_id', 'pa.relationship', 'p.display_name', 'p.designation', 'p.photo_url')
      .orderByRaw("case when pa.relationship = 'Owned' then 0 else 1 end")
      .orderBy('p.display_name');
  }

  async function platformAssignmentsWithinManager(managerId, personIds) {
    const manager = await db('people').where({ id: Number(managerId), is_active: true }).first('id', 'manager_id');
    if (!manager || !manager.manager_id) return false;
    const parent = await db('people').where({ id: manager.manager_id, is_active: true }).first('manager_id');
    if (!parent || parent.manager_id !== null) return false;
    const activePeople = await db('people').where('is_active', true).select('id', 'manager_id');
    const allowed = new Set([Number(manager.id), ...collectDescendants(manager.id, activePeople)]);
    return personIds.length > 0 && personIds.every((personId) => allowed.has(Number(personId)));
  }

  async function savePlatform(id, payload, actorEmail) {
    const record = normalize(payload, PLATFORM_FIELDS);
    record.code = String(record.code || '').toUpperCase();
    record.manager_person_id = Number(payload.manager_context_id);
    record.is_active = record.status !== 'Retired';
    record.updated_by = actorEmail;
    record.updated_at = new Date();
    const ownerId = payload.owner_person_id ? Number(payload.owner_person_id) : null;
    const supporterIds = [...new Set((payload.support_person_ids || []).map(Number))].filter((personId) => personId !== ownerId);
    const assignments = [
      ...(ownerId ? [{ person_id: ownerId, relationship: 'Owned' }] : []),
      ...supporterIds.map((personId) => ({ person_id: personId, relationship: 'Supported' }))
    ];
    const savedId = await db.transaction(async (trx) => {
      let platformId = id ? Number(id) : null;
      if (platformId) {
        const exists = await trx('platforms').where({ id: platformId }).first('id');
        if (!exists) return null;
        await trx('platforms').where({ id: platformId }).update(record);
        await trx('platform_assignments').where({ platform_id: platformId }).del();
      } else {
        record.created_by = actorEmail;
        record.created_at = new Date();
        const result = await trx('platforms').insert(record);
        platformId = Array.isArray(result) ? result[0] : result;
        if (platformId && typeof platformId === 'object') platformId = platformId.id;
        if (!Number.isFinite(Number(platformId))) platformId = (await trx('platforms').where({ code: record.code }).first('id')).id;
        platformId = Number(platformId);
      }
      if (assignments.length) await trx('platform_assignments').insert(assignments.map((assignment) => ({ ...assignment, platform_id: platformId })));
      await audit(actorEmail, id ? 'UPDATE' : 'CREATE', 'platform', platformId, {
        code: record.code, assignment_count: assignments.length, manager_context_id: Number(payload.manager_context_id)
      }, trx);
      return platformId;
    });
    return savedId ? getPlatform(savedId) : null;
  }

  function portfolioQuery() {
    return db('portfolios as pf')
      .leftJoin('people as owner', 'pf.owner_person_id', 'owner.id')
      .leftJoin('verticals as v', 'pf.vertical_id', 'v.id')
      .select(
        'pf.*', 'owner.display_name as owner_name', 'owner.designation as owner_designation',
        'owner.photo_url as owner_photo_url', 'v.name as vertical_name', 'v.color as vertical_color'
      )
      .select(db.raw('(select count(*) from demands d where d.portfolio_id = pf.id and d.is_active = ?) as demand_count', [true]));
  }

  function demandQuery() {
    return db('demands as d')
      .leftJoin('people as owner', 'd.owner_person_id', 'owner.id')
      .leftJoin('people as manager', 'd.accountable_manager_id', 'manager.id')
      .leftJoin('portfolios as pf', 'd.portfolio_id', 'pf.id')
      .leftJoin('programs as prg', 'd.program_id', 'prg.id')
      .leftJoin('squads as sq', 'd.squad_id', 'sq.id')
      .select(
        'd.*', 'owner.display_name as owner_name', 'manager.display_name as accountable_manager_name',
        'pf.name as portfolio_name', 'pf.code as portfolio_code', 'prg.name as program_name', 'sq.name as squad_name'
      );
  }

  async function listPortfolios(filters = {}) {
    const query = portfolioQuery().orderBy('pf.name');
    if (filters.search) {
      const term = `%${filters.search}%`;
      query.where((builder) => builder.whereLike('pf.name', term).orWhereLike('pf.code', term).orWhereLike('pf.business_area', term));
    }
    if (filters.status) query.where('pf.status', filters.status);
    if (filters.health) query.where('pf.health', filters.health);
    if (filters.ownerPersonId) query.where('pf.owner_person_id', filters.ownerPersonId);
    if (filters.active !== undefined) query.where('pf.is_active', filters.active);
    return query;
  }

  async function getPortfolio(id) {
    const portfolio = await portfolioQuery().where('pf.id', id).first();
    if (!portfolio) return null;
    portfolio.demands = await demandQuery().where('d.portfolio_id', id).where('d.is_active', true).orderBy('d.priority').orderBy('d.title');
    portfolio.demand_count = Number(portfolio.demand_count || portfolio.demands.length);
    return portfolio;
  }

  async function savePortfolio(id, payload, actorEmail) {
    const record = normalize(payload, PORTFOLIO_FIELDS);
    record.updated_by = actorEmail;
    record.updated_at = new Date();
    if (id) {
      const exists = await db('portfolios').where({ id }).first('id');
      if (!exists) return null;
      await db('portfolios').where({ id }).update(record);
      await audit(actorEmail, 'UPDATE', 'portfolio', id, { changed_fields: Object.keys(record) });
      return getPortfolio(id);
    }
    record.created_by = actorEmail;
    record.created_at = new Date();
    if (record.is_active === undefined) record.is_active = true;
    const insertedId = await insertAndResolveId('portfolios', record, 'code');
    await audit(actorEmail, 'CREATE', 'portfolio', insertedId, { code: record.code, name: record.name });
    return getPortfolio(insertedId);
  }

  async function listDemands(filters = {}) {
    const query = demandQuery().orderBy('d.updated_at', 'desc').orderBy('d.demand_id');
    if (filters.search) {
      const term = `%${filters.search}%`;
      query.where((builder) => builder.whereLike('d.demand_id', term).orWhereLike('d.title', term).orWhereLike('d.category', term));
    }
    if (filters.status) query.where('d.status', filters.status);
    if (filters.health) query.where('d.health', filters.health);
    if (filters.priority) query.where('d.priority', filters.priority);
    if (filters.portfolioId) query.where('d.portfolio_id', filters.portfolioId);
    if (filters.ownerPersonId) query.where('d.owner_person_id', filters.ownerPersonId);
    if (filters.active !== undefined) query.where('d.is_active', filters.active);
    return query;
  }

  async function getDemand(id) {
    return demandQuery().where('d.id', id).first();
  }

  async function saveDemand(id, payload, actorEmail) {
    const record = normalize(payload, DEMAND_FIELDS);
    record.updated_by = actorEmail;
    record.updated_at = new Date();
    if (record.progress_percent !== undefined && record.progress_percent !== null) record.progress_percent = Number(record.progress_percent);
    if (id) {
      const exists = await db('demands').where({ id }).first('id');
      if (!exists) return null;
      await db('demands').where({ id }).update(record);
      await audit(actorEmail, 'UPDATE', 'demand', id, { changed_fields: Object.keys(record) });
      return getDemand(id);
    }
    record.created_by = actorEmail;
    record.created_at = new Date();
    if (record.is_active === undefined) record.is_active = true;
    const insertedId = await insertAndResolveId('demands', record, 'demand_id');
    await audit(actorEmail, 'CREATE', 'demand', insertedId, { demand_id: record.demand_id, title: record.title });
    return getDemand(insertedId);
  }

  async function workSummary() {
    const [platforms, portfolios, demands, green, amber, red, critical] = await Promise.all([
      db('platforms').where({ is_active: true }).count({ count: '*' }).first(),
      db('portfolios').where({ is_active: true }).count({ count: '*' }).first(),
      db('demands').where({ is_active: true }).count({ count: '*' }).first(),
      db('demands').where({ is_active: true, health: 'Green' }).count({ count: '*' }).first(),
      db('demands').where({ is_active: true, health: 'Amber' }).count({ count: '*' }).first(),
      db('demands').where({ is_active: true, health: 'Red' }).count({ count: '*' }).first(),
      db('demands').where({ is_active: true, priority: 'Critical' }).count({ count: '*' }).first()
    ]);
    return {
      platforms: Number(platforms.count), portfolios: Number(portfolios.count), demands: Number(demands.count), green: Number(green.count),
      amber: Number(amber.count), red: Number(red.count), critical: Number(critical.count)
    };
  }

  async function listPortfolioManagers() {
    const rootIds = await db('people').whereNull('manager_id').where('is_active', true).pluck('id');
    if (!rootIds.length) return [];
    const managers = await managerQuery().whereIn('p.manager_id', rootIds).where('p.is_active', true).orderBy('p.display_name');
    const results = [];
    for (const manager of managers) results.push(await buildManagerAdministration(manager));
    return results;
  }

  async function getPortfolioManager(id) {
    const manager = await managerQuery().where('p.id', id).where('p.is_active', true).first();
    if (!manager) return null;
    const parent = manager.manager_id ? await db('people').where({ id: manager.manager_id }).first('manager_id') : null;
    if (!parent || parent.manager_id !== null) return null;
    return buildManagerAdministration(manager, true);
  }

  function managerQuery() {
    return db('people as p')
      .leftJoin('verticals as v', 'p.vertical_id', 'v.id')
      .select(
        'p.id', 'p.employee_id', 'p.display_name', 'p.designation', 'p.functional_role', 'p.employment_type',
        'p.photo_url', 'p.profile_summary', 'p.manager_id', 'p.vertical_id', 'v.name as vertical_name', 'v.color as vertical_color'
      );
  }

  async function buildManagerAdministration(manager, includeDetails = false) {
    const people = await db('people').where('is_active', true)
      .select('id', 'employee_id', 'display_name', 'designation', 'employment_type', 'gender', 'photo_url', 'manager_id');
    const descendantIds = collectDescendants(manager.id, people);
    const administrationIds = [Number(manager.id), ...descendantIds];
    const team = people.filter((person) => descendantIds.includes(Number(person.id)));
    const directReports = team.filter((person) => Number(person.manager_id) === Number(manager.id));
    const [portfolios, programs, squads, platforms] = await Promise.all([
      portfolioQuery().where('pf.owner_person_id', manager.id).where('pf.is_active', true).orderBy('pf.name'),
      db('programs as prg').leftJoin('people as owner', 'prg.owner_person_id', 'owner.id')
        .whereIn('prg.owner_person_id', administrationIds).whereNot('prg.status', 'Archived')
        .select('prg.*', 'owner.display_name as owner_name').orderBy('prg.name'),
      db('squads as sq').leftJoin('people as lead', 'sq.lead_person_id', 'lead.id')
        .leftJoin('platforms as plt', 'sq.platform_id', 'plt.id')
        .where((builder) => builder.where('sq.manager_person_id', manager.id).orWhereIn('sq.lead_person_id', administrationIds))
        .whereNot('sq.status', 'Archived')
        .select('sq.*', 'lead.display_name as lead_name', 'plt.name as platform_name', 'plt.code as platform_code').orderBy('sq.name'),
      listPlatforms({ managerPersonId: manager.id, personIds: administrationIds, active: true })
    ]);
    const portfolioIds = portfolios.map((portfolio) => Number(portfolio.id));
    const demandsQuery = demandQuery().where('d.is_active', true).where((builder) => {
      builder.where('d.accountable_manager_id', manager.id).orWhereIn('d.owner_person_id', administrationIds);
      if (portfolioIds.length) builder.orWhereIn('d.portfolio_id', portfolioIds);
    });
    const demands = await demandsQuery.orderBy('d.priority').orderBy('d.demand_id');
    const workforce = {
      total_resources: team.length,
      direct_reports: directReports.length,
      staff: team.filter((person) => person.employment_type === 'Staff').length,
      consultants: team.filter((person) => person.employment_type === 'Consultant').length,
      male: team.filter((person) => person.gender === 'Male').length,
      female: team.filter((person) => person.gender === 'Female').length,
      not_specified: team.filter((person) => !['Male', 'Female'].includes(person.gender)).length
    };
    const health = {
      green: demands.filter((demand) => demand.health === 'Green').length,
      amber: demands.filter((demand) => demand.health === 'Amber').length,
      red: demands.filter((demand) => demand.health === 'Red').length
    };
    const platformOwnedCount = platforms.filter((platform) => platform.assignments.some((assignment) => administrationIds.includes(Number(assignment.person_id)) && assignment.relationship === 'Owned')).length;
    const platformSupportedCount = platforms.filter((platform) => platform.assignments.some((assignment) => administrationIds.includes(Number(assignment.person_id)) && assignment.relationship === 'Supported')).length;
    return {
      ...manager, workforce, health,
      portfolio_count: portfolios.length, platform_count: platforms.length, platform_owned_count: platformOwnedCount, platform_supported_count: platformSupportedCount,
      demand_count: demands.length, program_count: programs.length, squad_count: squads.length,
      platforms,
      portfolios: includeDetails ? portfolios : portfolios.map(compactPortfolio),
      demands: includeDetails ? demands : demands.slice(0, 4).map(compactDemand),
      programs: includeDetails ? programs : programs.map(compactRecord),
      squads: includeDetails ? squads : squads.map(compactRecord),
      team: includeDetails ? team : directReports
    };
  }

  async function insertAndResolveId(table, record, uniqueColumn) {
    const result = await db(table).insert(record);
    let id = Array.isArray(result) ? result[0] : result;
    if (id && typeof id === 'object') id = id.id;
    if (!Number.isFinite(Number(id))) id = (await db(table).where(uniqueColumn, record[uniqueColumn]).first('id')).id;
    return Number(id);
  }

  async function audit(actorEmail, action, entityType, entityId, details, executor = db) {
    await executor('audit_logs').insert({
      actor_email: actorEmail, action, entity_type: entityType, entity_id: String(entityId), details: JSON.stringify(details)
    });
  }

  return {
    listPortfolios, getPortfolio, savePortfolio, listDemands, getDemand, saveDemand, workSummary,
    listPortfolioManagers, getPortfolioManager, listUnits, getUnit, saveUnit,
    listPlatforms, getPlatform, savePlatform, platformAssignmentsWithinManager
  };
}

function collectDescendants(managerId, people) {
  const descendants = [];
  const queue = [Number(managerId)];
  while (queue.length) {
    const parentId = queue.shift();
    const children = people.filter((person) => Number(person.manager_id) === parentId && Number(person.id) !== Number(managerId));
    for (const child of children) {
      const childId = Number(child.id);
      if (descendants.includes(childId)) continue;
      descendants.push(childId); queue.push(childId);
    }
  }
  return descendants;
}

function compactPortfolio(record) {
  return { id: record.id, code: record.code, name: record.name, status: record.status, health: record.health, demand_count: Number(record.demand_count || 0) };
}

function compactDemand(record) {
  return { id: record.id, demand_id: record.demand_id, title: record.title, status: record.status, health: record.health, priority: record.priority, progress_percent: Number(record.progress_percent || 0) };
}

function compactRecord(record) {
  return { id: record.id, code: record.code, name: record.name, status: record.status, owner_name: record.owner_name, lead_name: record.lead_name };
}

function normalize(payload, allowedFields) {
  const record = {};
  for (const field of allowedFields) {
    if (payload[field] === undefined) continue;
    const value = typeof payload[field] === 'string' ? payload[field].trim() : payload[field];
    record[field] = value === '' ? null : value;
  }
  for (const field of ['owner_person_id', 'vertical_id', 'accountable_manager_id', 'portfolio_id', 'program_id', 'squad_id']) {
    if (record[field] !== undefined && record[field] !== null) record[field] = Number(record[field]);
  }
  if (record.is_active !== undefined) record.is_active = Boolean(record.is_active);
  return record;
}

module.exports = { createWorkRepository };
