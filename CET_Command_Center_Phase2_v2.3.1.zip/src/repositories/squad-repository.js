const SQUAD_FIELDS = [
  'code', 'name', 'description', 'platform_id', 'manager_person_id', 'lead_person_id', 'vertical_id',
  'track_type', 'status', 'display_order', 'is_active'
];
const ROLE_FIELDS = ['code', 'name', 'description', 'category', 'display_order', 'is_active'];

function createSquadRepository(db) {
  function baseQuery() {
    return db('squads as sq')
      .leftJoin('platforms as plt', 'sq.platform_id', 'plt.id')
      .leftJoin('people as manager', 'sq.manager_person_id', 'manager.id')
      .leftJoin('people as lead', 'sq.lead_person_id', 'lead.id')
      .select(
        'sq.*', 'plt.name as platform_name', 'plt.code as platform_code', 'plt.category as platform_category',
        'manager.display_name as manager_name', 'lead.display_name as lead_name'
      );
  }

  async function listSquads(filters = {}) {
    const query = baseQuery().orderBy('plt.name').orderBy('sq.display_order').orderBy('sq.name');
    if (filters.active !== undefined) query.where('sq.is_active', filters.active);
    if (filters.platformId) query.where('sq.platform_id', Number(filters.platformId));
    if (filters.managerPersonId) query.where('sq.manager_person_id', Number(filters.managerPersonId));
    if (filters.search) {
      const term = `%${filters.search}%`;
      query.where((builder) => builder.whereLike('sq.name', term).orWhereLike('sq.code', term).orWhereLike('plt.name', term));
    }
    const squads = await query;
    for (const squad of squads) await hydrate(squad);
    return squads;
  }

  async function getSquad(id) {
    const squad = await baseQuery().where('sq.id', Number(id)).first();
    if (!squad) return null;
    await hydrate(squad);
    return squad;
  }

  async function hydrate(squad) {
    const [staffingPlan, assignments] = await Promise.all([
      db('squad_staffing_plan as sp').join('squad_roles as sr', 'sp.role_id', 'sr.id')
        .where('sp.squad_id', squad.id)
        .select('sp.id', 'sp.role_id', 'sp.required_count', 'sr.code as role_code', 'sr.name as role_name', 'sr.display_order')
        .orderBy('sr.display_order').orderBy('sr.name'),
      db('squad_assignments as sa').join('squad_roles as sr', 'sa.role_id', 'sr.id').join('people as p', 'sa.person_id', 'p.id')
        .where('sa.squad_id', squad.id)
        .select(
          'sa.id', 'sa.person_id', 'sa.role_id', 'sa.allocation_percent', 'sa.is_primary', 'sa.start_date', 'sa.end_date',
          'sr.code as role_code', 'sr.name as role_name', 'p.display_name', 'p.designation', 'p.employment_type', 'p.photo_url'
        ).orderBy('sr.display_order').orderBy('p.display_name')
    ]);
    squad.staffing_plan = staffingPlan;
    squad.assignments = assignments;
    squad.required_total = staffingPlan.reduce((sum, row) => sum + Number(row.required_count || 0), 0);
    squad.assigned_resources = new Set(assignments.map((row) => Number(row.person_id))).size;
    squad.allocated_fte = Number((assignments.reduce((sum, row) => sum + Number(row.allocation_percent || 0), 0) / 100).toFixed(2));
    squad.capacity_gap = Number(Math.max(0, squad.required_total - squad.allocated_fte).toFixed(2));
    return squad;
  }

  async function summary() {
    const squads = await listSquads({ active: true });
    const assignedPeople = new Set();
    let required = 0; let allocated = 0;
    for (const squad of squads) {
      required += squad.required_total;
      allocated += squad.allocated_fte;
      squad.assignments.forEach((assignment) => assignedPeople.add(Number(assignment.person_id)));
    }
    return {
      squads: squads.length,
      platforms: new Set(squads.map((squad) => Number(squad.platform_id)).filter(Boolean)).size,
      required_headcount: required,
      assigned_resources: assignedPeople.size,
      allocated_fte: Number(allocated.toFixed(2)),
      capacity_gap: Number(Math.max(0, required - allocated).toFixed(2))
    };
  }

  async function saveSquad(id, payload, actorEmail) {
    const record = normalize(payload, SQUAD_FIELDS);
    record.code = String(record.code || '').toUpperCase();
    record.is_active = record.status !== 'Archived';
    record.updated_by = actorEmail;
    record.updated_at = new Date();
    const staffingPlan = (payload.staffing_plan || []).filter((row) => Number(row.required_count) > 0).map((row) => ({
      role_id: Number(row.role_id), required_count: Number(row.required_count)
    }));
    const assignments = (payload.assignments || []).map((row) => ({
      person_id: Number(row.person_id), role_id: Number(row.role_id), allocation_percent: Number(row.allocation_percent),
      is_primary: Boolean(row.is_primary), start_date: clean(row.start_date), end_date: clean(row.end_date)
    }));
    const savedId = await db.transaction(async (trx) => {
      let squadId = id ? Number(id) : null;
      if (squadId) {
        const exists = await trx('squads').where({ id: squadId }).first('id');
        if (!exists) return null;
        await trx('squads').where({ id: squadId }).update(record);
        await trx('squad_staffing_plan').where({ squad_id: squadId }).del();
        await trx('squad_assignments').where({ squad_id: squadId }).del();
      } else {
        record.created_by = actorEmail;
        record.created_at = new Date();
        const result = await trx('squads').insert(record);
        squadId = resolveInsertedId(result);
        if (!Number.isFinite(squadId)) squadId = Number((await trx('squads').where({ code: record.code }).first('id')).id);
      }
      if (staffingPlan.length) await trx('squad_staffing_plan').insert(staffingPlan.map((row) => ({ ...row, squad_id: squadId })));
      if (assignments.length) await trx('squad_assignments').insert(assignments.map((row) => ({ ...row, squad_id: squadId })));
      await audit(trx, actorEmail, id ? 'UPDATE' : 'CREATE', 'squad', squadId, {
        code: record.code, required_roles: staffingPlan.length, assignment_count: assignments.length
      });
      return squadId;
    });
    return savedId ? getSquad(savedId) : null;
  }

  async function archiveSquad(id, actorEmail) {
    const squad = await db('squads').where({ id: Number(id) }).first('id', 'code');
    if (!squad) return null;
    await db('squads').where({ id: Number(id) }).update({ status: 'Archived', is_active: false, updated_by: actorEmail, updated_at: new Date() });
    await audit(db, actorEmail, 'ARCHIVE', 'squad', id, { code: squad.code });
    return getSquad(id);
  }

  async function listRoles(filters = {}) {
    const query = db('squad_roles').select('*').orderBy('display_order').orderBy('name');
    if (filters.active !== undefined) query.where('is_active', filters.active);
    return query;
  }

  async function getRole(id) { return db('squad_roles').where({ id: Number(id) }).first(); }

  async function saveRole(id, payload, actorEmail) {
    const record = normalize(payload, ROLE_FIELDS);
    record.code = String(record.code || '').toUpperCase();
    record.updated_by = actorEmail;
    record.updated_at = new Date();
    if (id) {
      const exists = await db('squad_roles').where({ id: Number(id) }).first('id');
      if (!exists) return null;
      await db('squad_roles').where({ id: Number(id) }).update(record);
      await audit(db, actorEmail, 'UPDATE', 'squad_role', id, { changed_fields: Object.keys(record) });
      return getRole(id);
    }
    record.created_by = actorEmail; record.created_at = new Date();
    if (record.is_active === undefined) record.is_active = true;
    const result = await db('squad_roles').insert(record);
    let roleId = resolveInsertedId(result);
    if (!Number.isFinite(roleId)) roleId = Number((await db('squad_roles').where({ code: record.code }).first('id')).id);
    await audit(db, actorEmail, 'CREATE', 'squad_role', roleId, { code: record.code, name: record.name });
    return getRole(roleId);
  }

  async function archiveRole(id, actorEmail) {
    const role = await getRole(id);
    if (!role) return null;
    await db('squad_roles').where({ id: Number(id) }).update({ is_active: false, updated_by: actorEmail, updated_at: new Date() });
    await audit(db, actorEmail, 'ARCHIVE', 'squad_role', id, { code: role.code });
    return getRole(id);
  }

  async function validateScope(managerId, platformId, personIds = []) {
    const manager = await db('people').where({ id: Number(managerId), is_active: true }).first('id', 'manager_id');
    if (!manager || !manager.manager_id) return false;
    const parent = await db('people').where({ id: manager.manager_id, is_active: true }).first('manager_id');
    if (!parent || parent.manager_id !== null) return false;
    const platform = await db('platforms').where({ id: Number(platformId), manager_person_id: Number(managerId), is_active: true }).first('id');
    if (!platform) return false;
    const people = await db('people').where('is_active', true).select('id', 'manager_id');
    const allowed = new Set([Number(managerId), ...collectDescendants(managerId, people)]);
    return personIds.every((personId) => allowed.has(Number(personId)));
  }

  return { listSquads, getSquad, saveSquad, archiveSquad, summary, listRoles, getRole, saveRole, archiveRole, validateScope };
}

function normalize(payload, allowedFields) {
  const record = {};
  for (const field of allowedFields) {
    if (payload[field] === undefined) continue;
    const value = typeof payload[field] === 'string' ? payload[field].trim() : payload[field];
    record[field] = value === '' ? null : value;
  }
  for (const field of ['platform_id', 'manager_person_id', 'lead_person_id', 'vertical_id', 'display_order']) {
    if (record[field] !== undefined && record[field] !== null) record[field] = Number(record[field]);
  }
  if (record.is_active !== undefined) record.is_active = Boolean(record.is_active);
  return record;
}

function clean(value) { return value ? String(value).slice(0, 10) : null; }

function resolveInsertedId(result) {
  let id = Array.isArray(result) ? result[0] : result;
  if (id && typeof id === 'object') id = id.id;
  return Number(id);
}

function collectDescendants(managerId, people) {
  const descendants = []; const queue = [Number(managerId)];
  while (queue.length) {
    const parentId = queue.shift();
    for (const child of people.filter((person) => Number(person.manager_id) === parentId)) {
      const childId = Number(child.id);
      if (descendants.includes(childId)) continue;
      descendants.push(childId); queue.push(childId);
    }
  }
  return descendants;
}

async function audit(executor, actorEmail, action, entityType, entityId, details) {
  await executor('audit_logs').insert({
    actor_email: actorEmail, action, entity_type: entityType, entity_id: String(entityId), details: JSON.stringify(details)
  });
}

module.exports = { createSquadRepository };
