function validatePerson(payload, { partial = false } = {}) {
  const errors = [];
  const required = ['employee_id', 'full_name', 'email', 'designation', 'employment_type'];
  if (!partial) {
    for (const field of required) if (!String(payload[field] || '').trim()) errors.push({ field, message: 'Required field.' });
  }
  if (payload.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email)) errors.push({ field: 'email', message: 'Enter a valid email address.' });
  if (payload.employment_type && !['Staff', 'Consultant'].includes(payload.employment_type)) {
    errors.push({ field: 'employment_type', message: 'Employee type must be Staff or Consultant.' });
  }
  if (payload.gender && !['Male', 'Female'].includes(payload.gender)) errors.push({ field: 'gender', message: 'Gender must be Male, Female or left unspecified.' });
  if (payload.manager_id && Number(payload.manager_id) === Number(payload.id)) errors.push({ field: 'manager_id', message: 'A person cannot report to themselves.' });
  return errors;
}

function validatePortfolio(payload, { partial = false } = {}) {
  const errors = [];
  if (!partial) requireFields(payload, ['name', 'code', 'owner_person_id', 'vertical_id', 'status', 'health'], errors);
  enumField(payload, 'status', ['Active', 'On Hold', 'Completed', 'Archived'], errors);
  enumField(payload, 'health', ['Green', 'Amber', 'Red'], errors);
  if (payload.start_date && payload.target_end_date && payload.start_date > payload.target_end_date) {
    errors.push({ field: 'target_end_date', message: 'Target end date must be after the start date.' });
  }
  return errors;
}

function validateDemand(payload, { partial = false } = {}) {
  const errors = [];
  if (!partial) requireFields(payload, ['demand_id', 'title', 'classification', 'priority', 'stage', 'status', 'owner_person_id', 'accountable_manager_id', 'portfolio_id', 'health'], errors);
  enumField(payload, 'classification', ['Strategic', 'Fast Track', 'Regulatory', 'Mandatory', 'Operational'], errors);
  enumField(payload, 'priority', ['Low', 'Medium', 'High', 'Critical'], errors);
  enumField(payload, 'status', ['New', 'In Progress', 'At Risk', 'On Hold', 'Completed', 'Cancelled', 'Archived'], errors);
  enumField(payload, 'health', ['Green', 'Amber', 'Red'], errors);
  const progress = Number(payload.progress_percent);
  if (payload.progress_percent !== undefined && (!Number.isFinite(progress) || progress < 0 || progress > 100)) {
    errors.push({ field: 'progress_percent', message: 'Progress must be between 0 and 100.' });
  }
  if (payload.planned_start_date && payload.planned_end_date && payload.planned_start_date > payload.planned_end_date) {
    errors.push({ field: 'planned_end_date', message: 'Planned end date must be after the start date.' });
  }
  return errors;
}

function validateUnit(payload, { partial = false } = {}) {
  const errors = [];
  if (!partial) requireFields(payload, ['name', 'code'], errors);
  if (payload.code && !/^[A-Z0-9][A-Z0-9-]{1,29}$/i.test(String(payload.code).trim())) {
    errors.push({ field: 'code', message: 'Use 2–30 letters, numbers or hyphens.' });
  }
  if (payload.color && !/^#[0-9a-f]{6}$/i.test(String(payload.color).trim())) {
    errors.push({ field: 'color', message: 'Choose a valid six-digit colour.' });
  }
  return errors;
}

function validatePlatform(payload, { partial = false } = {}) {
  const errors = [];
  if (!partial) requireFields(payload, ['name', 'code', 'status', 'criticality', 'manager_context_id'], errors);
  if (payload.code && !/^[A-Z0-9][A-Z0-9-]{1,39}$/i.test(String(payload.code).trim())) {
    errors.push({ field: 'code', message: 'Use 2–40 letters, numbers or hyphens.' });
  }
  enumField(payload, 'status', ['Active', 'Planned', 'Under Review', 'Retiring', 'Retired'], errors);
  enumField(payload, 'criticality', ['Low', 'Medium', 'High', 'Critical'], errors);
  const supporters = Array.isArray(payload.support_person_ids) ? payload.support_person_ids : [];
  if (!payload.owner_person_id && supporters.length === 0) {
    errors.push({ field: 'assignments', message: 'Choose an owner or at least one supporting person.' });
  }
  if (payload.owner_person_id && !Number.isInteger(Number(payload.owner_person_id))) errors.push({ field: 'owner_person_id', message: 'Choose a valid platform owner.' });
  if (supporters.some((id) => !Number.isInteger(Number(id)))) errors.push({ field: 'support_person_ids', message: 'Choose valid supporting people.' });
  return errors;
}

function validateSquad(payload, { partial = false } = {}) {
  const errors = [];
  if (!partial) requireFields(payload, ['code', 'name', 'platform_id', 'manager_person_id', 'track_type', 'status'], errors);
  if (payload.code && !/^[A-Z0-9][A-Z0-9-]{1,39}$/i.test(String(payload.code).trim())) errors.push({ field: 'code', message: 'Use 2–40 letters, numbers or hyphens.' });
  enumField(payload, 'track_type', ['Delivery Squad', 'Track', 'Supporting Squad'], errors);
  enumField(payload, 'status', ['Active', 'Planned', 'On Hold', 'Archived'], errors);
  const plan = Array.isArray(payload.staffing_plan) ? payload.staffing_plan : [];
  const assignments = Array.isArray(payload.assignments) ? payload.assignments : [];
  const planKeys = new Set();
  for (const row of plan) {
    if (!Number.isInteger(Number(row.role_id))) errors.push({ field: 'staffing_plan', message: 'Every staffing requirement needs a valid role.' });
    const required = Number(row.required_count);
    if (!Number.isInteger(required) || required < 0 || required > 999) errors.push({ field: 'staffing_plan', message: 'Required headcount must be between 0 and 999.' });
    if (planKeys.has(Number(row.role_id))) errors.push({ field: 'staffing_plan', message: 'A role can appear only once in the staffing plan.' });
    planKeys.add(Number(row.role_id));
  }
  const assignmentKeys = new Set();
  for (const row of assignments) {
    if (!Number.isInteger(Number(row.person_id)) || !Number.isInteger(Number(row.role_id))) errors.push({ field: 'assignments', message: 'Every assignment needs a person and role.' });
    const allocation = Number(row.allocation_percent);
    if (!Number.isInteger(allocation) || allocation < 1 || allocation > 100) errors.push({ field: 'assignments', message: 'Allocation must be between 1 and 100 percent.' });
    if (row.start_date && row.end_date && row.start_date > row.end_date) errors.push({ field: 'assignments', message: 'Assignment end date must be after the start date.' });
    const key = `${Number(row.person_id)}:${Number(row.role_id)}`;
    if (assignmentKeys.has(key)) errors.push({ field: 'assignments', message: 'The same person and role cannot be assigned twice.' });
    assignmentKeys.add(key);
  }
  return errors;
}

function validateSquadRole(payload, { partial = false } = {}) {
  const errors = [];
  if (!partial) requireFields(payload, ['code', 'name', 'category'], errors);
  if (payload.code && !/^[A-Z0-9][A-Z0-9-]{1,29}$/i.test(String(payload.code).trim())) errors.push({ field: 'code', message: 'Use 2–30 letters, numbers or hyphens.' });
  enumField(payload, 'category', ['Leadership', 'Delivery', 'Engineering', 'Quality', 'Functional', 'Support'], errors);
  return errors;
}

function requireFields(payload, fields, errors) {
  for (const field of fields) if (!String(payload[field] ?? '').trim()) errors.push({ field, message: 'Required field.' });
}

function enumField(payload, field, values, errors) {
  if (payload[field] !== undefined && !values.includes(payload[field])) errors.push({ field, message: `Choose a valid ${field.replaceAll('_', ' ')}.` });
}

module.exports = { validatePerson, validatePortfolio, validateDemand, validateUnit, validatePlatform, validateSquad, validateSquadRole };
