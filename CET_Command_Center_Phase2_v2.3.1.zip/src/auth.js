const crypto = require('node:crypto');
const express = require('express');
const msal = require('@azure/msal-node');

function createAuthRouter({ config, db }) {
  const router = express.Router();
  let client = null;

  if (config.authMode === 'entra') {
    const missing = ['tenantId', 'clientId', 'clientSecret'].filter((key) => !config.entra[key]);
    if (missing.length) throw new Error(`Entra configuration missing: ${missing.join(', ')}`);
    client = new msal.ConfidentialClientApplication({
      auth: {
        clientId: config.entra.clientId,
        authority: `https://login.microsoftonline.com/${config.entra.tenantId}`,
        clientSecret: config.entra.clientSecret
      }
    });
  }

  router.get('/login', async (req, res, next) => {
    try {
      if (config.authMode === 'demo') {
        req.session.user = {
          id: 'demo-admin', email: 'admin@cet.local', displayName: 'CET Local Administrator', role: 'super_admin', authMode: 'demo'
        };
        return res.redirect('/');
      }
      const state = crypto.randomBytes(24).toString('hex');
      req.session.authState = state;
      const url = await client.getAuthCodeUrl({
        scopes: ['openid', 'profile', 'email'],
        redirectUri: config.entra.redirectUri,
        state,
        prompt: 'select_account'
      });
      res.redirect(url);
    } catch (error) { next(error); }
  });

  router.get('/callback', async (req, res, next) => {
    try {
      if (config.authMode !== 'entra') return res.redirect('/');
      if (!req.query.state || req.query.state !== req.session.authState) return res.status(400).send('Invalid authentication state.');
      const result = await client.acquireTokenByCode({
        code: req.query.code,
        scopes: ['openid', 'profile', 'email'],
        redirectUri: config.entra.redirectUri
      });
      const claims = result.idTokenClaims || {};
      const email = String(claims.preferred_username || claims.email || '').toLowerCase();
      const userRecord = await db('application_users').whereRaw('LOWER(email) = ?', [email]).first();
      const role = userRecord?.is_active ? userRecord.role : 'viewer';
      req.session.user = {
        id: claims.oid || result.account?.homeAccountId,
        email,
        displayName: claims.name || result.account?.name || email,
        role,
        authMode: 'entra'
      };
      const loginRecord = { entra_object_id: claims.oid || null, display_name: req.session.user.displayName, last_login_at: new Date() };
      if (userRecord) {
        await db('application_users').where('id', userRecord.id).update(loginRecord);
      } else {
        await db('application_users').insert({ ...loginRecord, email, role, is_active: true });
      }
      delete req.session.authState;
      res.redirect('/');
    } catch (error) { next(error); }
  });

  router.post('/logout', (req, res, next) => {
    const wasEntra = req.session.user?.authMode === 'entra';
    req.session.destroy((error) => {
      if (error) return next(error);
      res.clearCookie('cet.sid');
      if (wasEntra) {
        const url = `https://login.microsoftonline.com/${config.entra.tenantId}/oauth2/v2.0/logout?post_logout_redirect_uri=${encodeURIComponent(config.entra.postLogoutRedirectUri)}`;
        return res.json({ redirectUrl: url });
      }
      res.json({ redirectUrl: '/' });
    });
  });

  return router;
}

function requireAuth(req, res, next) {
  if (!req.session?.user) return res.status(401).json({ error: { code: 'AUTH_REQUIRED', message: 'Sign in is required.' } });
  next();
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session?.user) return res.status(401).json({ error: { code: 'AUTH_REQUIRED', message: 'Sign in is required.' } });
    if (!roles.includes(req.session.user.role)) return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'You do not have permission for this action.' } });
    next();
  };
}

module.exports = { createAuthRouter, requireAuth, requireRole };
