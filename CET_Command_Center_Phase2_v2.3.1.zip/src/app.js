const fs = require('node:fs');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const config = require('./config');
const { initializeDatabase } = require('./db');
const { createAuthRouter } = require('./auth');
const { createApiRouter } = require('./routes/api');

async function createApp(options = {}) {
  const runtimeConfig = options.config || config;
  const db = options.db || await initializeDatabase(options.dbOverrides || {});
  fs.mkdirSync(runtimeConfig.uploadsDir, { recursive: true });

  const app = express();
  app.disable('x-powered-by');
  app.use(helmet({ contentSecurityPolicy: false }));
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: false }));
  app.use(session({
    name: 'cet.sid',
    secret: runtimeConfig.sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: runtimeConfig.nodeEnv === 'production',
      maxAge: 8 * 60 * 60 * 1000
    }
  }));

  app.use('/auth', createAuthRouter({ config: runtimeConfig, db }));
  app.use('/api/v1', createApiRouter({ config: runtimeConfig, db }));
  app.use(express.static(`${runtimeConfig.rootDir}/public`, { index: 'index.html', maxAge: runtimeConfig.nodeEnv === 'production' ? '1h' : 0 }));
  app.use('/api', (_req, res) => res.status(404).json({ error: { code: 'NOT_FOUND', message: 'API endpoint not found.' } }));
  app.get('*splat', (_req, res) => res.sendFile(`${runtimeConfig.rootDir}/public/index.html`));

  app.use((error, _req, res, _next) => {
    console.error(error);
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE' || error.number === 2627 || error.number === 2601) {
      return res.status(409).json({ error: { code: 'DUPLICATE_RECORD', message: 'A record with the same unique code, employee ID or email already exists.' } });
    }
    if (error.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: { code: 'FILE_TOO_LARGE', message: 'Profile photo exceeds the configured size limit.' } });
    res.status(500).json({ error: { code: 'INTERNAL_ERROR', message: 'An unexpected error occurred.' } });
  });

  app.locals.db = db;
  return app;
}

module.exports = { createApp };
