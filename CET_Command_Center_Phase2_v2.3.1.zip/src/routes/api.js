const path = require('node:path');
const express = require('express');
const multer = require('multer');
const { requireAuth, requireRole } = require('../auth');
const { validatePerson, validatePortfolio, validateDemand, validateUnit, validatePlatform, validateSquad, validateSquadRole } = require('../validation');
const { createPeopleRepository } = require('../repositories/people-repository');
const { createWorkRepository } = require('../repositories/work-repository');
const { createSquadRepository } = require('../repositories/squad-repository');

function createApiRouter({ db, config }) {
  const router = express.Router();
  const people = createPeopleRepository(db);
  const work = createWorkRepository(db);
  const squads = createSquadRepository(db);
  const editors = requireRole('super_admin', 'profile_admin', 'governance_editor');
  const storage = multer.diskStorage({
    destination: config.uploadsDir,
    filename: (_req, file, callback) => {
      const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
      callback(null, `profile-${Date.now()}-${Math.random().toString(16).slice(2)}${ext}`);
    }
  });
  const upload = multer({
    storage,
    limits: { fileSize: config.maxProfilePhotoBytes },
    fileFilter: (_req, file, callback) => callback(null, ['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype))
  });

  router.get('/health', async (_req, res, next) => {
    try {
      await db.raw('select 1 as ok');
      res.json({ status: 'ok', database: config.db.provider, authMode: config.authMode, timestamp: new Date().toISOString() });
    } catch (error) { next(error); }
  });

  router.get('/auth/me', (req, res) => {
    res.json({ authenticated: Boolean(req.session?.user), user: req.session?.user || null, authMode: config.authMode });
  });

  router.use(requireAuth);

  router.get('/dashboard/stats', async (_req, res, next) => {
    try { res.json(await people.stats()); } catch (error) { next(error); }
  });
  router.get('/dashboard/ownership', async (_req, res, next) => {
    try { res.json(await people.dashboardOwnership()); } catch (error) { next(error); }
  });
  router.get('/organization', async (_req, res, next) => {
    try { res.json(await people.getOrganization()); } catch (error) { next(error); }
  });
  router.get('/verticals', async (_req, res, next) => {
    try { res.json(await people.listVerticals()); } catch (error) { next(error); }
  });
  router.get('/units', async (req, res, next) => {
    try {
      const active = req.query.active === undefined ? undefined : req.query.active === 'true';
      res.json(await work.listUnits({ active }));
    } catch (error) { next(error); }
  });
  router.get('/units/:id', async (req, res, next) => {
    try {
      const unit = await work.getUnit(Number(req.params.id));
      if (!unit) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Unit not found.' } });
      res.json(unit);
    } catch (error) { next(error); }
  });
  router.post('/units', editors, async (req, res, next) => {
    try {
      const errors = validateUnit(req.body);
      if (errors.length) return validationError(res, errors);
      res.status(201).json(await work.saveUnit(null, req.body, req.session.user.email));
    } catch (error) { next(error); }
  });
  router.put('/units/:id', editors, async (req, res, next) => {
    try {
      const errors = validateUnit(req.body);
      if (errors.length) return validationError(res, errors);
      const unit = await work.saveUnit(Number(req.params.id), req.body, req.session.user.email);
      if (!unit) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Unit not found.' } });
      res.json(unit);
    } catch (error) { next(error); }
  });
  router.get('/work/summary', async (_req, res, next) => {
    try { res.json(await work.workSummary()); } catch (error) { next(error); }
  });
  router.get('/portfolio-managers', async (_req, res, next) => {
    try { res.json(await work.listPortfolioManagers()); } catch (error) { next(error); }
  });
  router.get('/portfolio-managers/:id', async (req, res, next) => {
    try {
      const manager = await work.getPortfolioManager(Number(req.params.id));
      if (!manager) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Portfolio manager not found.' } });
      res.json(manager);
    } catch (error) { next(error); }
  });
  router.get('/platforms', async (req, res, next) => {
    try {
      res.json(await work.listPlatforms({ active: req.query.active === undefined ? undefined : req.query.active === 'true' }));
    } catch (error) { next(error); }
  });
  router.get('/platforms/:id', async (req, res, next) => {
    try {
      const platform = await work.getPlatform(Number(req.params.id));
      if (!platform) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Platform not found.' } });
      res.json(platform);
    } catch (error) { next(error); }
  });
  router.post('/platforms', editors, async (req, res, next) => {
    try {
      const errors = validatePlatform(req.body);
      if (errors.length) return validationError(res, errors);
      const personIds = assignmentPersonIds(req.body);
      if (!(await work.platformAssignmentsWithinManager(req.body.manager_context_id, personIds))) {
        return validationError(res, [{ field: 'assignments', message: 'Platform responsibility must remain within the selected manager’s team.' }]);
      }
      res.status(201).json(await work.savePlatform(null, req.body, req.session.user.email));
    } catch (error) { next(error); }
  });
  router.put('/platforms/:id', editors, async (req, res, next) => {
    try {
      const errors = validatePlatform(req.body);
      if (errors.length) return validationError(res, errors);
      const personIds = assignmentPersonIds(req.body);
      if (!(await work.platformAssignmentsWithinManager(req.body.manager_context_id, personIds))) {
        return validationError(res, [{ field: 'assignments', message: 'Platform responsibility must remain within the selected manager’s team.' }]);
      }
      const platform = await work.savePlatform(Number(req.params.id), req.body, req.session.user.email);
      if (!platform) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Platform not found.' } });
      res.json(platform);
    } catch (error) { next(error); }
  });
  router.get('/squads/summary', async (_req, res, next) => {
    try { res.json(await squads.summary()); } catch (error) { next(error); }
  });
  router.get('/squads', async (req, res, next) => {
    try {
      res.json(await squads.listSquads({
        search: req.query.search,
        active: req.query.active === undefined ? undefined : req.query.active === 'true',
        platformId: req.query.platformId ? Number(req.query.platformId) : undefined,
        managerPersonId: req.query.managerPersonId ? Number(req.query.managerPersonId) : undefined
      }));
    } catch (error) { next(error); }
  });
  router.get('/squads/:id', async (req, res, next) => {
    try {
      const squad = await squads.getSquad(Number(req.params.id));
      if (!squad) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Squad not found.' } });
      res.json(squad);
    } catch (error) { next(error); }
  });
  router.post('/squads', editors, async (req, res, next) => {
    try {
      const errors = validateSquad(req.body);
      if (errors.length) return validationError(res, errors);
      const personIds = (req.body.assignments || []).map((assignment) => Number(assignment.person_id));
      if (!(await squads.validateScope(req.body.manager_person_id, req.body.platform_id, personIds))) {
        return validationError(res, [{ field: 'assignments', message: 'Platform, manager and resources must belong to the same administration tree.' }]);
      }
      res.status(201).json(await squads.saveSquad(null, req.body, req.session.user.email));
    } catch (error) { next(error); }
  });
  router.put('/squads/:id', editors, async (req, res, next) => {
    try {
      const errors = validateSquad(req.body);
      if (errors.length) return validationError(res, errors);
      const personIds = (req.body.assignments || []).map((assignment) => Number(assignment.person_id));
      if (!(await squads.validateScope(req.body.manager_person_id, req.body.platform_id, personIds))) {
        return validationError(res, [{ field: 'assignments', message: 'Platform, manager and resources must belong to the same administration tree.' }]);
      }
      const squad = await squads.saveSquad(Number(req.params.id), req.body, req.session.user.email);
      if (!squad) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Squad not found.' } });
      res.json(squad);
    } catch (error) { next(error); }
  });
  router.delete('/squads/:id', editors, async (req, res, next) => {
    try {
      const squad = await squads.archiveSquad(Number(req.params.id), req.session.user.email);
      if (!squad) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Squad not found.' } });
      res.json(squad);
    } catch (error) { next(error); }
  });
  router.get('/squad-roles', async (req, res, next) => {
    try { res.json(await squads.listRoles({ active: req.query.active === undefined ? undefined : req.query.active === 'true' })); } catch (error) { next(error); }
  });
  router.post('/squad-roles', editors, async (req, res, next) => {
    try {
      const errors = validateSquadRole(req.body);
      if (errors.length) return validationError(res, errors);
      res.status(201).json(await squads.saveRole(null, req.body, req.session.user.email));
    } catch (error) { next(error); }
  });
  router.put('/squad-roles/:id', editors, async (req, res, next) => {
    try {
      const errors = validateSquadRole(req.body);
      if (errors.length) return validationError(res, errors);
      const role = await squads.saveRole(Number(req.params.id), req.body, req.session.user.email);
      if (!role) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Squad role not found.' } });
      res.json(role);
    } catch (error) { next(error); }
  });
  router.delete('/squad-roles/:id', editors, async (req, res, next) => {
    try {
      const role = await squads.archiveRole(Number(req.params.id), req.session.user.email);
      if (!role) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Squad role not found.' } });
      res.json(role);
    } catch (error) { next(error); }
  });
  router.get('/portfolios', async (req, res, next) => {
    try {
      res.json(await work.listPortfolios({
        search: req.query.search, status: req.query.status, health: req.query.health,
        ownerPersonId: req.query.ownerPersonId ? Number(req.query.ownerPersonId) : undefined,
        active: req.query.active === undefined ? undefined : req.query.active === 'true'
      }));
    } catch (error) { next(error); }
  });
  router.get('/portfolios/:id', async (req, res, next) => {
    try {
      const portfolio = await work.getPortfolio(Number(req.params.id));
      if (!portfolio) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Portfolio not found.' } });
      res.json(portfolio);
    } catch (error) { next(error); }
  });
  router.post('/portfolios', editors, async (req, res, next) => {
    try {
      const errors = validatePortfolio(req.body);
      if (errors.length) return validationError(res, errors);
      res.status(201).json(await work.savePortfolio(null, req.body, req.session.user.email));
    } catch (error) { next(error); }
  });
  router.put('/portfolios/:id', editors, async (req, res, next) => {
    try {
      const errors = validatePortfolio(req.body);
      if (errors.length) return validationError(res, errors);
      const portfolio = await work.savePortfolio(Number(req.params.id), req.body, req.session.user.email);
      if (!portfolio) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Portfolio not found.' } });
      res.json(portfolio);
    } catch (error) { next(error); }
  });
  router.get('/demands', async (req, res, next) => {
    try {
      res.json(await work.listDemands({
        search: req.query.search, status: req.query.status, health: req.query.health, priority: req.query.priority,
        portfolioId: req.query.portfolioId ? Number(req.query.portfolioId) : undefined,
        ownerPersonId: req.query.ownerPersonId ? Number(req.query.ownerPersonId) : undefined,
        active: req.query.active === undefined ? undefined : req.query.active === 'true'
      }));
    } catch (error) { next(error); }
  });
  router.get('/demands/:id', async (req, res, next) => {
    try {
      const demand = await work.getDemand(Number(req.params.id));
      if (!demand) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Demand not found.' } });
      res.json(demand);
    } catch (error) { next(error); }
  });
  router.post('/demands', editors, async (req, res, next) => {
    try {
      const errors = validateDemand(req.body);
      if (errors.length) return validationError(res, errors);
      res.status(201).json(await work.saveDemand(null, req.body, req.session.user.email));
    } catch (error) { next(error); }
  });
  router.put('/demands/:id', editors, async (req, res, next) => {
    try {
      const errors = validateDemand(req.body);
      if (errors.length) return validationError(res, errors);
      const demand = await work.saveDemand(Number(req.params.id), req.body, req.session.user.email);
      if (!demand) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Demand not found.' } });
      res.json(demand);
    } catch (error) { next(error); }
  });
  router.get('/people', async (req, res, next) => {
    try {
      res.json(await people.list({
        search: req.query.search,
        verticalId: req.query.verticalId ? Number(req.query.verticalId) : undefined,
        employmentType: req.query.employmentType,
        active: req.query.active === undefined ? true : req.query.active === 'true'
      }));
    } catch (error) { next(error); }
  });
  router.get('/people/:id', async (req, res, next) => {
    try {
      const person = await people.getById(Number(req.params.id));
      if (!person) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Person not found.' } });
      res.json(person);
    } catch (error) { next(error); }
  });
  router.post('/people', editors, async (req, res, next) => {
    try {
      const errors = validatePerson(req.body);
      if (errors.length) return res.status(422).json({ error: { code: 'VALIDATION_ERROR', message: 'Please correct the highlighted fields.', details: errors } });
      const saved = await people.create(req.body, req.session.user.email);
      res.status(201).json(saved);
    } catch (error) { next(error); }
  });
  router.put('/people/:id', editors, async (req, res, next) => {
    try {
      const payload = { ...req.body, id: Number(req.params.id) };
      const errors = validatePerson(payload, { partial: true });
      if (errors.length) return res.status(422).json({ error: { code: 'VALIDATION_ERROR', message: 'Please correct the highlighted fields.', details: errors } });
      const saved = await people.update(Number(req.params.id), payload, req.session.user.email);
      if (!saved) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Person not found.' } });
      res.json(saved);
    } catch (error) { next(error); }
  });
  router.post('/uploads/profile-photo', editors, upload.single('photo'), (req, res) => {
    if (!req.file) return res.status(422).json({ error: { code: 'INVALID_FILE', message: 'Choose a JPG, PNG or WebP image.' } });
    res.status(201).json({ url: `/uploads/${req.file.filename}` });
  });

  return router;
}

function validationError(res, errors) {
  return res.status(422).json({ error: { code: 'VALIDATION_ERROR', message: 'Please correct the highlighted fields.', details: errors } });
}

function assignmentPersonIds(payload) {
  return [...new Set([
    ...(payload.owner_person_id ? [Number(payload.owner_person_id)] : []),
    ...(Array.isArray(payload.support_person_ids) ? payload.support_person_ids.map(Number) : [])
  ])];
}

module.exports = { createApiRouter };
