@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or later is required. Install it from https://nodejs.org and run this file again.
  pause
  exit /b 1
)

if not exist .env copy .env.example .env >nul
if not exist node_modules (
  echo Installing application packages...
  call npm install
  if errorlevel 1 goto :error
)

echo Initializing the portable database...
call npm run db:init
if errorlevel 1 goto :error

start "" http://localhost:3000
echo Starting CET Command Center at http://localhost:3000
call npm start
exit /b 0

:error
echo.
echo Setup failed. Review the message above.
pause
exit /b 1
