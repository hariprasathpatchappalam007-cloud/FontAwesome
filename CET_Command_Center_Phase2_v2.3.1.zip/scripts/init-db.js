const { initializeDatabase } = require('../src/db');

(async () => {
  const db = await initializeDatabase();
  console.log('CET Portal database initialized successfully.');
  await db.destroy();
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
