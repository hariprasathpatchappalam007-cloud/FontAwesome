const test = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const fs = require('node:fs');
const path = require('node:path');
const baseConfig = require('../src/config');
const { initializeDatabase } = require('../src/db');
const { createApp } = require('../src/app');

let app;
let db;

test.before(async () => {
  db = await initializeDatabase({ provider: 'sqlite', sqliteFile: ':memory:' });
  app = await createApp({ db, config: { ...baseConfig, nodeEnv: 'test', authMode: 'demo', sessionSecret: 'test-secret' } });
});

test.after(async () => {
  await db.destroy();
});

test('health endpoint reports portable SQLite provider', async () => {
  const response = await request(app).get('/api/v1/health').expect(200);
  assert.equal(response.body.status, 'ok');
  assert.equal(response.body.database, 'sqlite');
  assert.equal(response.body.authMode, 'demo');
});

test('protected APIs reject unauthenticated callers', async () => {
  const response = await request(app).get('/api/v1/people').expect(401);
  assert.equal(response.body.error.code, 'AUTH_REQUIRED');
});

test('demo login creates an authenticated role-based session', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login').expect(302).expect('Location', '/');
  const me = await agent.get('/api/v1/auth/me').expect(200);
  assert.equal(me.body.authenticated, true);
  assert.equal(me.body.user.role, 'super_admin');
  const stats = await agent.get('/api/v1/dashboard/stats').expect(200);
  assert.equal(stats.body.people, 10);
  assert.equal(stats.body.staff, 7);
  assert.equal(stats.body.consultants, 3);
  assert.equal(stats.body.platforms, 5);
});

test('organization API returns a nested hierarchy', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login');
  const response = await agent.get('/api/v1/organization').expect(200);
  assert.equal(response.body.length, 1);
  assert.equal(response.body[0].employee_id, 'CET-001');
  assert.equal(Boolean(response.body[0].is_vertical_head), true);
  assert.equal(response.body[0].employment_type, 'Staff');
  assert.equal(response.body[0].children.length, 3);
  assert.ok(response.body[0].children.every((person) => !Boolean(person.is_vertical_head)));

  const ownership = await agent.get('/api/v1/dashboard/ownership').expect(200);
  assert.equal(ownership.body.length, 3);
  assert.ok(ownership.body.every((person) => Number(person.manager_id) === Number(response.body[0].id)));
});

test('profile API validates and creates an auditable consultant profile', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login');
  const invalid = await agent.post('/api/v1/people').send({ full_name: 'Incomplete Profile' }).expect(422);
  assert.equal(invalid.body.error.code, 'VALIDATION_ERROR');

  const created = await agent.post('/api/v1/people').send({
    employee_id: 'CON-999',
    full_name: 'Test Consultant',
    email: 'test.consultant@example.com',
    designation: 'Integration Consultant',
    employment_type: 'Consultant',
    manager_id: 2,
    vertical_id: 2,
    location: 'Dubai',
    is_active: true
  }).expect(201);
  assert.equal(created.body.employee_id, 'CON-999');
  assert.equal(created.body.manager_name, 'Omar Farooq');

  const audit = await db('audit_logs').where({ entity_type: 'person', entity_id: String(created.body.id), action: 'CREATE' }).first();
  assert.equal(audit.actor_email, 'admin@cet.local');
});

test('Phase 2 portfolio and demand APIs expose governed ownership data', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login');
  const portfolios = await agent.get('/api/v1/portfolios').expect(200);
  const demands = await agent.get('/api/v1/demands').expect(200);
  const summary = await agent.get('/api/v1/work/summary').expect(200);
  assert.equal(portfolios.body.length, 3);
  assert.equal(demands.body.length, 5);
  assert.equal(summary.body.portfolios, 3);
  assert.equal(summary.body.demands, 5);
  assert.ok(portfolios.body.every((portfolio) => ['Green', 'Amber', 'Red'].includes(portfolio.health)));
  assert.ok(demands.body.every((demand) => demand.portfolio_name && demand.owner_name));
});

test('portfolio managers expose administration and workforce composition under the Unit Head', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login');
  const managers = await agent.get('/api/v1/portfolio-managers').expect(200);
  assert.equal(managers.body.length, 3);
  assert.ok(managers.body.every((manager) => manager.manager_id === 1));
  assert.ok(managers.body.every((manager) => manager.portfolio_count >= 1));
  assert.ok(managers.body.every((manager) => manager.platform_count >= 1));
  assert.ok(managers.body.every((manager) => manager.workforce.total_resources >= 2));

  const customerManager = managers.body.find((manager) => manager.employee_id === 'CET-020');
  assert.equal(customerManager.workforce.staff, 1);
  assert.equal(customerManager.workforce.consultants, 1);
  assert.equal(customerManager.workforce.male, 1);
  assert.equal(customerManager.workforce.female, 1);
  const detail = await agent.get(`/api/v1/portfolio-managers/${customerManager.id}`).expect(200);
  assert.equal(detail.body.portfolios.length, 1);
  assert.equal(detail.body.platforms.length, 2);
  assert.equal(detail.body.platform_owned_count, 2);
  assert.equal(detail.body.platform_supported_count, 2);
  assert.equal(detail.body.programs.length, 1);
  assert.equal(detail.body.squads.length, 1);
  assert.equal(detail.body.team.length, 2);
  assert.ok(detail.body.demands.length >= 2);
});

test('Platform administration assigns owned and supported responsibilities within a manager team', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login');
  await agent.post('/api/v1/platforms').send({ code: 'BAD', name: 'Outside scope', status: 'Active', criticality: 'High', manager_context_id: 3, owner_person_id: 2 }).expect(422);
  const created = await agent.post('/api/v1/platforms').send({
    code: 'PLT-TEST', name: 'Test Engagement Platform', description: 'Governed platform test fixture.', category: 'Customer Platform',
    vendor: 'Internal', status: 'Active', criticality: 'High', manager_context_id: 3, owner_person_id: 3, support_person_ids: [7, 8]
  }).expect(201);
  assert.equal(created.body.assignments.filter((assignment) => assignment.relationship === 'Owned').length, 1);
  assert.equal(created.body.assignments.filter((assignment) => assignment.relationship === 'Supported').length, 2);
  const updated = await agent.put(`/api/v1/platforms/${created.body.id}`).send({
    code: 'PLT-TEST', name: 'Test Engagement Platform', category: 'Customer Platform', vendor: 'Internal',
    status: 'Under Review', criticality: 'Critical', manager_context_id: 3, owner_person_id: 7, support_person_ids: [3, 8]
  }).expect(200);
  assert.equal(updated.body.status, 'Under Review');
  assert.equal(updated.body.criticality, 'Critical');
  assert.equal(updated.body.assignments.find((assignment) => assignment.relationship === 'Owned').person_id, 7);
  const manager = await agent.get('/api/v1/portfolio-managers/3').expect(200);
  assert.ok(manager.body.platforms.some((platform) => platform.code === 'PLT-TEST'));
  const audit = await db('audit_logs').where({ entity_type: 'platform', entity_id: String(created.body.id), action: 'UPDATE' }).first();
  assert.equal(audit.actor_email, 'admin@cet.local');
});

test('Squad operating model governs roles, required capacity and named resource allocations', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login');
  const roles = await agent.get('/api/v1/squad-roles').expect(200);
  const squads = await agent.get('/api/v1/squads?active=true').expect(200);
  const summary = await agent.get('/api/v1/squads/summary').expect(200);
  assert.equal(roles.body.length, 8);
  assert.equal(squads.body.length, 3);
  assert.equal(summary.body.platforms, 3);
  assert.ok(summary.body.required_headcount > summary.body.assigned_resources);
  assert.ok(squads.body.every((squad) => Array.isArray(squad.staffing_plan) && Array.isArray(squad.assignments)));

  const mobile = (await agent.get('/api/v1/platforms?active=true').expect(200)).body.find((platform) => platform.code === 'PLT-MOB');
  const rte = roles.body.find((role) => role.code === 'RTE');
  const qa = roles.body.find((role) => role.code === 'QA');
  await agent.post('/api/v1/squads').send({ name: 'Incomplete squad' }).expect(422);
  const created = await agent.post('/api/v1/squads').send({
    code: 'SQ-MOB-LCM', name: 'Mobile Lifecycle Management', description: 'Lifecycle delivery track.',
    platform_id: mobile.id, manager_person_id: 2, lead_person_id: 5, vertical_id: 2,
    track_type: 'Track', status: 'Active', display_order: 20,
    staffing_plan: [{ role_id: rte.id, required_count: 1 }, { role_id: qa.id, required_count: 2 }],
    assignments: [
      { person_id: 5, role_id: rte.id, allocation_percent: 50, is_primary: false },
      { person_id: 6, role_id: qa.id, allocation_percent: 100, is_primary: true }
    ]
  }).expect(201);
  assert.equal(created.body.required_total, 3);
  assert.equal(created.body.assigned_resources, 2);
  assert.equal(created.body.allocated_fte, 1.5);
  assert.equal(created.body.capacity_gap, 1.5);

  const updated = await agent.put(`/api/v1/squads/${created.body.id}`).send({
    code: 'SQ-MOB-LCM', name: 'Mobile Lifecycle Management', description: 'Updated lifecycle delivery track.',
    platform_id: mobile.id, manager_person_id: 2, lead_person_id: 6, vertical_id: 2,
    track_type: 'Delivery Squad', status: 'Planned', display_order: 25,
    staffing_plan: [{ role_id: rte.id, required_count: 1 }],
    assignments: [{ person_id: 6, role_id: rte.id, allocation_percent: 75, is_primary: true }]
  }).expect(200);
  assert.equal(updated.body.status, 'Planned');
  assert.equal(updated.body.assignments.length, 1);
  await agent.delete(`/api/v1/squads/${created.body.id}`).expect(200);
  const archived = await agent.get(`/api/v1/squads/${created.body.id}`).expect(200);
  assert.equal(archived.body.status, 'Archived');
  assert.equal(Boolean(archived.body.is_active), false);
  const audit = await db('audit_logs').where({ entity_type: 'squad', entity_id: String(created.body.id), action: 'ARCHIVE' }).first();
  assert.equal(audit.actor_email, 'admin@cet.local');
});

test('Unit reference data can be added, edited and deactivated without deleting relationships', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login');
  const initial = await agent.get('/api/v1/units').expect(200);
  assert.equal(initial.body.length, 4);
  await agent.post('/api/v1/units').send({ name: '', code: 'bad code' }).expect(422);

  const created = await agent.post('/api/v1/units').send({
    code: 'ARCH', name: 'Architecture Unit', description: 'Enterprise architecture governance.', color: '#10483b', is_active: true
  }).expect(201);
  assert.equal(created.body.code, 'ARCH');
  assert.equal(Boolean(created.body.is_active), true);

  const updated = await agent.put(`/api/v1/units/${created.body.id}`).send({
    code: 'ARCH', name: 'Architecture & Engineering', description: 'Architecture and engineering governance.', color: '#a71930', is_active: false
  }).expect(200);
  assert.equal(updated.body.name, 'Architecture & Engineering');
  assert.equal(Boolean(updated.body.is_active), false);
  const activeOnly = await agent.get('/api/v1/units?active=true').expect(200);
  assert.ok(activeOnly.body.every((unit) => Boolean(unit.is_active)));
  assert.ok(!activeOnly.body.some((unit) => unit.id === created.body.id));
  const audit = await db('audit_logs').where({ entity_type: 'unit', entity_id: String(created.body.id), action: 'UPDATE' }).first();
  assert.equal(audit.actor_email, 'admin@cet.local');
});

test('Phase 2 administration validates, creates and audits portfolios and demands', async () => {
  const agent = request.agent(app);
  await agent.get('/auth/login');
  await agent.post('/api/v1/demands').send({ title: 'Incomplete demand' }).expect(422);

  const portfolio = await agent.post('/api/v1/portfolios').send({
    code: 'PORT-TEST', name: 'Test Governance Portfolio', owner_person_id: 2, vertical_id: 2,
    status: 'Active', health: 'Green', business_area: 'Architecture', is_active: true
  }).expect(201);
  assert.equal(portfolio.body.code, 'PORT-TEST');

  const demand = await agent.post('/api/v1/demands').send({
    demand_id: 'DMGT-9999', title: 'Test governed demand', classification: 'Strategic', priority: 'High',
    stage: 'Intake', status: 'New', owner_person_id: 2, accountable_manager_id: 2,
    portfolio_id: portfolio.body.id, health: 'Green', progress_percent: 10, is_active: true
  }).expect(201);
  assert.equal(demand.body.portfolio_code, 'PORT-TEST');
  const audit = await db('audit_logs').where({ entity_type: 'demand', entity_id: String(demand.body.id), action: 'CREATE' }).first();
  assert.equal(audit.actor_email, 'admin@cet.local');
});

test('single-page application is served with the CET shell', async () => {
  const response = await request(app).get('/').expect(200);
  assert.match(response.text, /CET Command Center/);
  assert.match(response.text, /Organization Explorer|Organization/);
});

test('edit-profile identity fields use the corrected wide layout and labels', () => {
  const html = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  const css = fs.readFileSync(path.join(__dirname, '../public/styles.css'), 'utf8');
  assert.match(html, /Staff \/ Consultant ID \*/);
  assert.match(html, /Employee full name \*/);
  assert.match(css, /\.identity-section \{ grid-template-columns:45px 185px 205px minmax\(0,1fr\); \}/);
  assert.match(css, /\.identity-section \.form-fields \{ grid-column:4; width:100%; \}/);
  assert.match(html, /identity-section[\s\S]*?<\/section>\s*<section class="content-panel form-section">\s*<div class="section-number">02<\/div>/);
  assert.match(html, /<span>Gender<\/span><select name="gender">/);
  assert.match(css, /\.profile-form > \.form-section \{ flex:0 0 auto;width:100%;min-height:0/);
});

test('profile-photo editor crops locally and compresses before API upload', () => {
  const html = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  const javascript = fs.readFileSync(path.join(__dirname, '../public/app.js'), 'utf8');
  assert.match(html, /id="photoEditorModal"/);
  assert.match(html, /id="photoZoom"/);
  assert.match(html, /Crop, compress & use photo/);
  assert.match(javascript, /const PHOTO_OUTPUT_WIDTH = 640/);
  assert.match(javascript, /const PHOTO_OUTPUT_HEIGHT = 800/);
  assert.match(javascript, /const PHOTO_BASE_OVERSCAN = 1\.1/);
  assert.match(javascript, /function renderPhotoCanvas/);
  assert.match(javascript, /async function createCompressedPhoto/);
  assert.match(javascript, /body\.append\('photo', blob/);
  assert.match(javascript, /'image\/webp', quality/);
});

test('organization hierarchy uses the compact fitted photo-led card design', () => {
  const css = fs.readFileSync(path.join(__dirname, '../public/styles.css'), 'utf8');
  const javascript = fs.readFileSync(path.join(__dirname, '../public/app.js'), 'utf8');
  assert.match(css, /\.org-canvas \{ min-width:1430px;min-height:650px/);
  assert.match(css, /\.org-card \{ width:220px;height:116px;min-height:116px/);
  assert.match(css, /\.org-card \.avatar \{ grid-column:1;grid-row:1\/3;width:76px;height:116px/);
  assert.match(css, /\.org-card\.head \.avatar \{ width:82px;height:122px/);
  assert.match(css, /\.avatar\[style\*="background-image"\] \{ background-size:cover; \}/);
  assert.match(javascript, /class="org-card-copy"/);
});

test('hierarchy roles and connectors remain independent from employment type and visual scaling', () => {
  const html = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  const css = fs.readFileSync(path.join(__dirname, '../public/styles.css'), 'utf8');
  const javascript = fs.readFileSync(path.join(__dirname, '../public/app.js'), 'utf8');
  assert.match(html, /Department \/ Unit Head/);
  assert.match(html, /Manager \/ Direct Reportee/);
  assert.match(javascript, /function hierarchyRoleForPerson/);
  assert.match(javascript, /function displayRoleForHierarchy/);
  assert.match(javascript, /designation\.replace\(\/\^vertical head/);
  assert.match(javascript, /function offsetWithin/);
  assert.match(javascript, /canvas\.style\.transform = `scale\(\$\{state\.orgScale\}\)`/);
  assert.match(javascript, /depth === 0 \? 'head' : depth === 1 \? 'manager' : 'member'/);
  assert.match(html, /id="orgScaleShell"/);
  assert.doesNotMatch(html, /id="fitOrg"/);
  assert.match(css, /\.org-stage \{ overflow:hidden; \}/);
  assert.match(javascript, /new ResizeObserver/);
  assert.match(javascript, /naturalWidth \* state\.orgScale/);
  assert.match(javascript, /naturalHeight \* state\.orgScale/);
});

test('Phase 2 UI activates portfolio and demand administration with the DIB-inspired identity', () => {
  const html = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  const css = fs.readFileSync(path.join(__dirname, '../public/styles.css'), 'utf8');
  const javascript = fs.readFileSync(path.join(__dirname, '../public/app.js'), 'utf8');
  assert.match(html, /data-view="portfolios"/);
  assert.match(html, /data-view="demands"/);
  assert.match(html, /id="portfolioForm"/);
  assert.match(html, /id="demandForm"/);
  assert.match(html, /class="light dib-theme"/);
  assert.match(css, /--maroon:#a71930/);
  assert.match(css, /--heritage-green:#10483b/);
  assert.match(css, /--governance-gold:#c5a75d/);
  assert.match(javascript, /function renderPortfolios/);
  assert.match(javascript, /function renderDemands/);
  assert.match(javascript, /async function savePortfolio/);
  assert.match(javascript, /async function saveDemand/);
  assert.match(html, /id="portfolioManagerView"/);
  assert.match(html, /data-view="units"/);
  assert.match(html, /id="unitForm"/);
  assert.match(html, /Select unit/);
  assert.match(javascript, /function renderUnits/);
  assert.match(javascript, /async function saveUnit/);
  assert.match(html, /id="platformEditorModal"/);
  assert.match(html, /Supporting manager \/ reportees/);
  assert.match(javascript, /function managerPlatformItem/);
  assert.match(javascript, /async function savePlatform/);
  assert.doesNotMatch(javascript, /Owned portfolios/);
  assert.match(javascript, /async function openPortfolioManager/);
  assert.match(javascript, /function renderPortfolioManager/);
  assert.match(css, /\.manager-admin-grid/);
  assert.match(css, /body\.light \.hero-panel \.hero-date \{ position:absolute;right:238px/);
});

test('Squad UI exposes the operating model, capacity matrix and Platform counts', () => {
  const html = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
  const css = fs.readFileSync(path.join(__dirname, '../public/styles.css'), 'utf8');
  const javascript = fs.readFileSync(path.join(__dirname, '../public/app.js'), 'utf8');
  assert.match(html, /data-view="squads"/);
  assert.match(html, /id="squadForm"/);
  assert.match(html, /id="squadStaffingPlan"/);
  assert.match(html, /id="squadAssignmentRows"/);
  assert.match(html, /id="squadMatrix"/);
  assert.match(html, /id="squadRoleForm"/);
  assert.match(javascript, /function renderSquads/);
  assert.match(javascript, /function squadRegisterRow/);
  assert.doesNotMatch(javascript, /function squadCard/);
  assert.match(javascript, /async function saveSquad/);
  assert.match(javascript, /async function archiveSquad/);
  assert.match(javascript, /\['platforms', 'Platforms'/);
  assert.match(javascript, /\$\{manager\.platform_count\}<\/strong>Platforms/);
  assert.doesNotMatch(javascript, /\$\{manager\.portfolio_count\}<\/strong>Portfolios/);
  assert.match(css, /\.squad-board/);
  assert.match(css, /\.squad-register-table/);
  assert.match(css, /\.squad-platform-band/);
  assert.match(css, /\.squad-matrix/);
});
