# CET Command Center — Phase 2A/2B

Current baseline: **v2.3.1**

### v2.3.1 scalable Squad operating register

- Replaces the Platform and Squad card board with a compact row-and-column operating register.
- Groups rows by Platform and shows Platform-level required capacity, allocated FTE and gap rollups.
- Shows Squad/Track, lead, accountable manager, required role mix, required headcount, assigned resources, allocated FTE, gap and status in aligned columns.
- Keeps role plans compact with overflow counts and hover detail, so large Squad inventories remain easy to scan.
- Preserves the detailed cross-Squad role matrix as a separate view.
- Adds keyboard-accessible Squad row editing for authorized administrators.

### v2.3.0 Squad operating model and Platform statistics

- Activates a governed Squad module using the hierarchy **Unit → Manager → Platform → Squad/Track → Required Roles → Actual Assignments**.
- Adds a DIB-inspired platform-grouped operating-model board and a cross-squad resource matrix.
- Separates required headcount from named people assignments so required capacity, allocated FTE and capacity gaps remain visible.
- Supports configurable Squad roles, allocation percentages, primary/shared assignments, assignment dates and controlled archive actions.
- Adds audited Squad and role create/update/archive APIs with manager-tree scope validation.
- Replaces the Portfolio count on manager administration cards with Platform count and adds Total Platforms to Executive Home statistics.
- Upgrades existing portable databases in place; standard Squad roles are added without creating sample operational staffing records in an existing database.

### v2.2.0 manager Platform administration

- Replaces **Owned Portfolios** on the individual manager page with a dedicated **Platforms** panel.
- Adds governed Platform records with code, name, category, vendor/product, lifecycle status, business criticality and description.
- Supports one accountable **Owned** assignment and multiple **Supported** assignments for the manager or reportees under that manager.
- Restricts Platform assignments at the API layer to the selected manager’s administration tree.
- Adds role-controlled Platform create/edit workflows, assignment summaries, audit records and portable SQLite/Microsoft SQL tables.

### v2.1.0 Unit reference-data administration

- Renames the portal's user-facing **Vertical** terminology to **Unit**, including profiles, portfolios, filters, hierarchy roles and executive summaries.
- Adds a responsive Units administration page with search, status filter, linked people/portfolio counts and DIB-inspired green, maroon and gold styling.
- Allows authorized administrators to add, edit, activate and deactivate Units through audited APIs.
- Keeps the underlying `verticals` table and `vertical_id` relationships for backward compatibility, so existing databases upgrade without a destructive migration.
- Keeps inactive Units linked to historical profiles and portfolios while removing them from new-entry selection.

### v2.0.1 profile integrity and manager administration

- Repairs the Add/Edit Profile HTML section boundary and locks the three form sections into independent responsive rows.
- Adds an optional Gender field so workforce composition can report Men, Women and Not Specified without inference.
- Rebuilds Portfolios as a manager-centric view of every direct reportee under the Unit Head.
- Adds manager drill-down pages covering owned portfolios, demands, major programs, squads, direct reports and total resources.
- Adds workforce metrics for Staff, Consultants, Men, Women and hierarchy-aware team strength.
- Makes Executive Home leadership cards open the selected manager's administration page.
- Moves the Executive Home date into a protected content panel and confines the maroon/green circles to a separate visual zone.

### v2.0.0 portfolio and demand administration

- Activates governed Portfolio and Demand modules with responsive administration views.
- Adds portable portfolio metadata for ownership, business area, strategic objectives, dates, status and RAG health.
- Adds a portable demand registry linked to portfolio, demand owner and accountable manager, with classification, priority, stage, status, schedule, RAG health and progress.
- Provides role-controlled create and edit workflows, read-only detail drawers, archive-ready status handling and audit evidence.
- Introduces a DIB-inspired CET intranet identity using heritage green, maroon and restrained governance gold.
- Adds executive portfolio cards, operational demand tables, registry filters and ownership summaries.
- Preserves the existing people hierarchy, photo editor, Entra SSO path and SQLite/Microsoft SQL portability.

### v1.4.2 automatic hierarchy fitting

- Automatically measures and scales the complete hierarchy to stay inside the white organization window.
- Uses a dimensioned scale wrapper so the unscaled canvas can no longer create horizontal overflow or clip edge profiles.
- Re-fits when the organization page opens, the browser window changes size or the application panel width changes.
- Removes the manual **Fit to view** button and redraws connectors before applying the calculated scale.

### v1.4.1 legacy designation display correction

- Displays old direct-reportee designations beginning with “Vertical Head” as “Manager” in the organization and profile views without destructively rewriting stored profile data.

### v1.4.0 stable fitted hierarchy and corrected role model

- Fits the three-level organization structure within a standard 100% desktop view using 220 × 116 px team cards and a 1430 px hierarchy canvas.
- Enlarges names and designations at natural browser zoom while reducing unused card width.
- Calculates connectors from unscaled element offsets, preventing misalignment after page switching, fitting or window resizing.
- Separates hierarchy role from employment type: Department/Unit Head → Manager/Direct Reportee → Team Member, independently of Staff or Consultant.
- Automatically marks only root profiles as Department/Unit Head and treats their direct reportees as managers.
- Updates legends, profile badges, form wording, seed data and leadership ownership queries to follow the corrected model.

### v1.3.0 compact portrait-panel hierarchy

- Rebuilds organization cards as shorter, wider landscape cards based on the supplied reference.
- Uses a full-height 118 px portrait panel on team cards and 126 px on leadership cards.
- Keeps name, designation, Staff/Consultant type and report count in a compact details panel.
- Changes the optimized upload master to a full-bleed 640 × 800 portrait WebP so it can support both rectangular organization panels and CSS-clipped circular avatars.
- Adds a 90% zoom-out option for full-body composition while retaining movement space at the default 100%.

### v1.2.0 photo-led organization cards

- Enlarges organization portraits to 76 px for team members and 86 px for leadership profiles.
- Redesigns hierarchy cards with more width, height, designation space and a clearer footer.
- Slightly overscans displayed profile images to hide legacy transparent-edge artefacts.
- Expands the organization canvas and connection spacing to suit the larger cards.
- Uses the full 720 px circle in new photo exports so no transparent ring remains at the four sides.

### v1.1.1 circular crop correction

- Exports a true circular WebP with transparent corners instead of placing a rounded rectangle inside the avatar.
- Adds 14% composition overscan at the default 100% setting, allowing horizontal and vertical repositioning without first increasing zoom.
- Uses a circular editor workspace so the preview matches the final profile avatar.

### v1.1.0 profile-photo editor

- Opens high-resolution profile photos in a movable crop workspace before upload.
- Supports drag-to-position, zoom, reset and a face-safe circular guide.
- Adds a consistent outer margin so the head stays visible in circular profile cards.
- Resizes output to 720 × 720 and automatically compresses it as JPEG before the API upload.
- Keeps the original high-resolution file on the user's PC; only the optimized result is uploaded.

### v1.0.1 refinement

- Corrected the Edit Profile identity layout so Staff/Consultant ID, employee full name, email and contact number remain fully visible.
- Improved identity-field wording and placeholders.
- Introduced a darker DIB-inspired emerald theme with controlled gold accents in both light and dark modes.

An API-first CET department portal for secure people-profile administration, reporting hierarchy, leadership ownership and an interactive organization explorer.

## Current features

- Microsoft Entra ID SSO using OpenID Connect and OAuth 2.0.
- Explicit local development login for testing without corporate credentials.
- Executive workforce and ownership landing page.
- Staff and consultant directory with search and filters.
- Add/edit profile form with reporting line, Unit, employee type, role and photo upload.
- Unit reference-data maintenance with audited add, edit, activation and deactivation.
- Interactive fiber-style organization hierarchy.
- Leadership profile drawer with linked portfolio, program and squad assignments.
- Portfolio registry with ownership, strategic purpose, dates, status and RAG health.
- Demand registry with portfolio linkage, accountable ownership, classification, priority, progress and RAG health.
- Manager Platform administration with owned/supported responsibility assignments across the reporting team.
- Squad/Track administration with reusable role catalogue, staffing plans, named resource allocations and capacity-gap reporting.
- Add/edit forms and read-only detail views for CET staff, consultants, managers and heads.
- Role-based API authorization and audit logging.
- Portable data layer: SQLite locally and Microsoft SQL Server for deployment.
- Responsive dark/light user interface with no CDN dependency.

## Quick start on Windows

Prerequisites: install Node.js 20 LTS or later.

1. Extract the project ZIP.
2. Double-click `start-local.bat`.
3. Open `http://localhost:3000` if it does not open automatically.
4. Select **Enter local development portal**.

The first run installs packages, creates `data/cet-portal.db`, and loads clearly simulated CET sample profiles.

## Command-line start

```bash
copy .env.example .env
npm install
npm run db:init
npm start
```

On macOS/Linux, replace `copy` with `cp`.

## Configuration

Runtime settings are held in `.env`. Never commit a real client secret.

### Local test mode

```env
AUTH_MODE=demo
DB_PROVIDER=sqlite
SQLITE_FILE=./data/cet-portal.db
```

Demo mode is intentionally visible in the login screen and session header. It must not be used on a deployed server.

### Microsoft Entra ID mode

```env
AUTH_MODE=entra
ENTRA_TENANT_ID=your-tenant-guid
ENTRA_CLIENT_ID=your-app-registration-client-id
ENTRA_CLIENT_SECRET=your-secret-from-a-secure-secret-store
ENTRA_REDIRECT_URI=http://localhost:3000/auth/callback
```

See `docs/ENTRA-SSO-SETUP.md` for the app-registration steps.

### Microsoft SQL Server mode

```env
DB_PROVIDER=mssql
MSSQL_SERVER=sql-server-host
MSSQL_PORT=1433
MSSQL_DATABASE=CETPortal
MSSQL_USER=service-account
MSSQL_PASSWORD=use-a-secure-secret-store
MSSQL_ENCRYPT=true
MSSQL_TRUST_SERVER_CERTIFICATE=false
```

Run `npm run db:init` after creating an empty database. The same schema builder creates or upgrades all current tables. See `docs/SQL-SERVER-DEPLOYMENT.md`.

## API structure

All functional endpoints are under `/api/v1`.

| Endpoint | Method | Purpose |
|---|---:|---|
| `/api/v1/health` | GET | Runtime, authentication and database health |
| `/api/v1/auth/me` | GET | Current session and role |
| `/api/v1/dashboard/stats` | GET | Executive workforce totals |
| `/api/v1/dashboard/ownership` | GET | Leadership ownership summary |
| `/api/v1/work/summary` | GET | Active portfolio and demand health summary |
| `/api/v1/portfolio-managers` | GET | Direct-reportee administration and workforce summaries |
| `/api/v1/portfolio-managers/:id` | GET | Full manager portfolio, demand, program, squad and team view |
| `/api/v1/platforms` | GET/POST | List or create governed Platforms |
| `/api/v1/platforms/:id` | GET/PUT | Read or update a Platform and its responsibility assignments |
| `/api/v1/squads/summary` | GET | Squad, connected Platform, required-capacity, allocation and gap totals |
| `/api/v1/squads` | GET/POST | Search or create governed Squads and Tracks |
| `/api/v1/squads/:id` | GET/PUT/DELETE | Read, update or archive a Squad/Track |
| `/api/v1/squad-roles` | GET/POST | List or create reusable Squad roles |
| `/api/v1/squad-roles/:id` | PUT/DELETE | Update or archive a Squad role |
| `/api/v1/organization` | GET | Nested active reporting hierarchy |
| `/api/v1/people` | GET/POST | Search or create profiles |
| `/api/v1/people/:id` | GET/PUT | Read or update a profile |
| `/api/v1/portfolios` | GET/POST | Search or create governed portfolios |
| `/api/v1/portfolios/:id` | GET/PUT | Read or update a portfolio and its connected demands |
| `/api/v1/demands` | GET/POST | Search or register demands |
| `/api/v1/demands/:id` | GET/PUT | Read or update a demand |
| `/api/v1/units` | GET/POST | List or create Unit reference data |
| `/api/v1/units/:id` | GET/PUT | Read or update a Unit, including active status |
| `/api/v1/verticals` | GET | Legacy-compatible active Unit reference-data endpoint |
| `/api/v1/uploads/profile-photo` | POST | Validated profile-image upload |

Write actions require `super_admin`, `profile_admin`, or `governance_editor`.

## Validation

```bash
npm test
```

The test suite checks health, authentication enforcement, demo login, dashboard Platform counts, hierarchy nesting, profile administration, Platform scope, Squad staffing and assignment scope, portfolio and demand APIs, validation, archive controls and audit evidence.

## Important production controls

- Set `AUTH_MODE=entra`; do not expose demo mode.
- Use HTTPS and update `APP_BASE_URL` and redirect URIs.
- Store Entra and SQL secrets in the approved enterprise secret store.
- Replace the local in-memory Express session store with a shared approved session store before multi-instance deployment.
- Store profile photos in an approved object/document repository and retain only the returned reference in SQL Server.
- Map Entra security groups to portal roles during the server-deployment phase.
- Run the application through the bank's reverse proxy/WAF and approved logging/monitoring controls.

## Project layout

```text
public/                 Browser application and local upload folder
src/auth.js             Demo and Microsoft Entra authentication provider
src/routes/api.js       Versioned REST API
src/repositories/       Data access and domain queries
src/db/                 Portable connection, schema and sample seed
test/                   Automated API and security tests
docs/                   Architecture and deployment guidance
```

## Next planned slice

The next slice can activate Major Program administration and executive capacity analytics. Jira integration remains a separate adapter so the portal does not duplicate Jira as the delivery system of record.
