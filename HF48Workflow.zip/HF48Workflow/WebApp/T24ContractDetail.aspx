<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="T24ContractDetail.aspx.cs" Inherits="HF48Workflow.T24ContractDetail" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>T24 Contract Detail</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; padding: 0; background-color: #ccccff; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; border-radius: 4px 4px 0 0; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 160px; font-weight: bold; font-size: 13px; color: #333; vertical-align: top; }
        .form-group input, .form-group textarea { padding: 5px 8px; border: 1px solid #ccc; border-radius: 3px; font-size: 13px; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-primary { background-color: #003366; color: white; }
        .btn-primary:hover { background-color: #004488; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-success:hover { background-color: #218838; }
        .btn-info { background-color: #17a2b8; color: white; }
        .btn-info:hover { background-color: #138496; }
        .btn-secondary { background-color: #6c757d; color: white; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error   { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; }
        .gridview th { background-color: #507CD1; color: white; padding: 7px 10px; text-align: left; white-space: nowrap; }
        .gridview td { padding: 5px 10px; border-bottom: 1px solid #eee; }
        .gridview tr:nth-child(even) td { background-color: #EFF3FB; }
        .gridview tr:hover td { background-color: #f5f5f5; }
        .info-box { background: #fff3cd; border: 1px solid #ffc107; padding: 8px 12px; border-radius: 3px; margin-bottom: 10px; font-size: 12px; color: #856404; }
        .stat-bar { background: #e7f3ff; border: 1px solid #bee5eb; padding: 8px 14px; border-radius: 3px; font-size: 13px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <form id="form1" runat="server">

        <div class="header">
            <h1>T24 Contract Detail</h1>
            <h2>Finance / Contract enquiry response &rarr; T24_Contract_Detail table</h2>
        </div>

        <div class="container">

            <asp:Panel ID="pnlMessage" runat="server" Visible="false">
                <asp:Label ID="lblMessage" runat="server" />
            </asp:Panel>

            <!-- STEP 1: Request context -->
            <div class="panel">
                <div class="panel-header">Step 1 &mdash; Request Context</div>
                <div class="panel-body">
                    <div class="info-box">
                        Enter the identifiers used to call the T24 contract enquiry service, then paste the
                        JSON response returned by the service below.
                    </div>
                    <div class="form-group">
                        <label>Contract ID:</label>
                        <asp:TextBox ID="txtContractID" runat="server" Width="360px"
                            placeholder="e.g. 997HF52220260201?cif=2598452_branch=997" />
                    </div>
                    <div class="form-group">
                        <label>Application Ref No:</label>
                        <asp:TextBox ID="txtApplicationRefNo" runat="server" Width="180px" placeholder="e.g. MF123" />
                        &nbsp;&nbsp;
                        <label style="width:auto;">Branch Code:</label>
                        <asp:TextBox ID="txtBranchCode" runat="server" Width="100px" placeholder="e.g. 997" />
                    </div>
                </div>
            </div>

            <!-- STEP 2: Paste service response -->
            <div class="panel">
                <div class="panel-header">Step 2 &mdash; Service Response (JSON)</div>
                <div class="panel-body">
                    <div class="form-group" style="margin-bottom:6px;">
                        <label style="vertical-align:top;">Response JSON:</label>
                        <asp:TextBox ID="txtResponseJson" runat="server" Width="700px" Height="220px"
                            TextMode="MultiLine" style="font-family:Consolas,monospace;font-size:12px;" />
                    </div>
                    <div>
                        <asp:Button ID="btnParse" runat="server" Text="Parse Response" CssClass="btn btn-primary"
                            OnClick="btnParse_Click" />
                        <asp:Button ID="btnClear" runat="server" Text="Clear" CssClass="btn btn-secondary"
                            OnClick="btnClear_Click" CausesValidation="false" />
                    </div>
                </div>
            </div>

            <!-- STEP 3: Preview parsed finance information -->
            <asp:Panel ID="pnlPreview" runat="server" Visible="false" CssClass="panel">
                <div class="panel-header">Step 3 &mdash; Preview &amp; Save</div>
                <div class="panel-body">
                    <div class="stat-bar">
                        CIF: <strong><asp:Label ID="lblParsedCif" runat="server" /></strong>
                        &nbsp;|&nbsp; Finance rows found: <strong><asp:Label ID="lblParsedCount" runat="server" /></strong>
                        &nbsp;|&nbsp; API Status: <strong><asp:Label ID="lblParsedApiStatus" runat="server" /></strong>
                    </div>

                    <asp:GridView ID="gvPreview" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False"
                        EmptyDataText="No finance information rows parsed.">
                        <Columns>
                            <asp:BoundField DataField="ContractReferenceNumber" HeaderText="Contract Ref No" />
                            <asp:BoundField DataField="UserReferenceNumber"     HeaderText="User Ref No" />
                            <asp:BoundField DataField="FinanceCurrency"         HeaderText="Ccy" />
                            <asp:BoundField DataField="FinanceAmount"           HeaderText="Finance Amount" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="CurrentBalance"          HeaderText="Current Balance" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="OutstandingBalanceAmount" HeaderText="Outstanding" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="ModuleCode"              HeaderText="Module" />
                            <asp:BoundField DataField="ProductCode"             HeaderText="Product" />
                            <asp:BoundField DataField="ContractStatus"          HeaderText="Status" />
                            <asp:BoundField DataField="ProfitRate"              HeaderText="Profit Rate" DataFormatString="{0:N5}" />
                            <asp:BoundField DataField="BookingDate"             HeaderText="Booking Date"  DataFormatString="{0:dd/MM/yyyy}" />
                            <asp:BoundField DataField="MaturityDate"            HeaderText="Maturity Date" DataFormatString="{0:dd/MM/yyyy}" />
                        </Columns>
                    </asp:GridView>

                    <div style="margin-top:12px;">
                        <asp:Button ID="btnSave" runat="server" Text="&#9654; Save to Database" CssClass="btn btn-success"
                            OnClick="btnSave_Click"
                            OnClientClick="return confirm('Save the parsed finance information into T24_Contract_Detail?');" />
                    </div>
                </div>
            </asp:Panel>

            <!-- Search / view existing records -->
            <div class="panel">
                <div class="panel-header">View Saved Records &mdash; Proc_T24_ContractDetail_Select</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>CIF:</label>
                        <asp:TextBox ID="txtSearchCif" runat="server" Width="120px" />
                        &nbsp;
                        <label style="width:auto;">App Ref No:</label>
                        <asp:TextBox ID="txtSearchAppRef" runat="server" Width="140px" />
                        &nbsp;
                        <label style="width:auto;">Contract Ref No:</label>
                        <asp:TextBox ID="txtSearchContractRef" runat="server" Width="160px" />
                        &nbsp;
                        <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-info"
                            OnClick="btnSearch_Click" />
                    </div>
                    <div style="overflow-x:auto;">
                        <asp:GridView ID="gvSearch" runat="server" CssClass="gridview"
                            AutoGenerateColumns="False"
                            EmptyDataText="No records found."
                            AllowPaging="True" PageSize="15"
                            OnPageIndexChanging="gvSearch_PageIndexChanging">
                            <Columns>
                                <asp:BoundField DataField="SRNo"                     HeaderText="SRNo" />
                                <asp:BoundField DataField="ContractID"               HeaderText="Contract ID" />
                                <asp:BoundField DataField="ApplicationRefNo"         HeaderText="App Ref No" />
                                <asp:BoundField DataField="CIF"                      HeaderText="CIF" />
                                <asp:BoundField DataField="ContractReferenceNumber"  HeaderText="Contract Ref No" />
                                <asp:BoundField DataField="FinanceCurrency"          HeaderText="Ccy" />
                                <asp:BoundField DataField="FinanceAmount"            HeaderText="Finance Amount" DataFormatString="{0:N2}" />
                                <asp:BoundField DataField="OutstandingBalanceAmount" HeaderText="Outstanding" DataFormatString="{0:N2}" />
                                <asp:BoundField DataField="ProductCode"              HeaderText="Product" />
                                <asp:BoundField DataField="ContractStatus"           HeaderText="Status" />
                                <asp:BoundField DataField="MaturityDate"             HeaderText="Maturity Date" DataFormatString="{0:dd/MM/yyyy}" />
                                <asp:BoundField DataField="CreatedBy"                HeaderText="Created By" />
                                <asp:BoundField DataField="CreatedOn"                HeaderText="Created On" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            </Columns>
                        </asp:GridView>
                    </div>
                </div>
            </div>

        </div>
    </form>
</body>
</html>
