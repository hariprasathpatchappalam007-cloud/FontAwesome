<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="HF48DisbursementMonitor.aspx.cs" Inherits="HF48Workflow.HF48DisbursementMonitor" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HF48 Disbursement Monitoring &amp; Notifications</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; padding: 0; background-color: #ccccff; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #003366; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; border-radius: 4px 4px 0 0; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 140px; font-weight: bold; font-size: 13px; color: #333; }
        .form-group input, .form-group select { padding: 5px 8px; border: 1px solid #ccc; border-radius: 3px; font-size: 13px; }
        .btn { padding: 5px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 0; }
        .btn-primary { background-color: #003366; color: white; }
        .btn-primary:hover { background-color: #004488; }
        .btn-warning { background-color: #FF6600; color: white; }
        .btn-warning:hover { background-color: #e65c00; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-success:hover { background-color: #218838; }
        .btn-danger { background-color: #dc3545; color: white; }
        .btn-danger:hover { background-color: #c82333; }
        .btn-info { background-color: #17a2b8; color: white; }
        .btn-info:hover { background-color: #138496; }
        .ticket-classification { display: inline-block; border: 1px dashed #999; border-radius: 4px; padding: 4px 6px; margin-left: 4px; background: #fff8f0; }
        .ticket-classification-label { font-size: 11px; font-weight: bold; color: #555; margin-right: 4px; vertical-align: middle; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px 10px; text-align: left; font-size: 12px; }
        .gridview td { padding: 6px 10px; border-bottom: 1px solid #eee; }
        .gridview tr:hover { background-color: #f5f5f5; }
        .gridview tr.alt { background-color: #EFF3FB; }
        .section-title { font-size: 16px; font-weight: bold; color: #003366; margin: 15px 0 10px 0; border-bottom: 2px solid #003366; padding-bottom: 5px; }
        .action-buttons { margin-top: 10px; }
        .tab-container { margin-bottom: 15px; border-bottom: 2px solid #003366; }
        .tab-container .tab { display: inline-block; padding: 8px 20px; cursor: pointer; background-color: #e0e0e0; border: 1px solid #ccc; border-bottom: none; border-radius: 4px 4px 0 0; margin-right: 2px; font-size: 13px; text-decoration: none; color: #333; }
        .tab-container .tab.active { background-color: #003366; color: white; border-color: #003366; }
/* ---- Grid pager ---- */
.dfm-pager td { padding: 8px 14px; background: #f8fafc; border-top: 1px solid #e2e8f0; text-align: center; }
.dfm-pager span { display: inline-block; padding: 5px 11px; margin: 0 2px; border-radius: 4px; font-size: .85em; font-weight: 700; background: #1a3c5e; color: #fff; }
.dfm-pager a { display: inline-block; padding: 5px 11px; margin: 0 2px; border-radius: 4px; font-size: .85em; font-weight: 600; background: #fff; color: #1a3c5e; border: 1px solid #cbd5e1; text-decoration: none; }
.dfm-pager a:hover { background: #dbeafe; border-color: #93c5fd; }

    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h1>HF48 Disbursement Monitoring &amp; Notifications</h1>
            <h2>Manual Trigger Interface - Pre-Disbursement Workflow Management</h2>
        </div>

        <div class="container">
            <!-- Status Message -->
            <asp:Panel ID="pnlMessage" runat="server" Visible="false">
                <asp:Label ID="lblMessage" runat="server" />
            </asp:Panel>

            <div class="tab-container">
                <asp:HiddenField ID="hfActiveTab" runat="server" Value="Disbursements" />
                <asp:LinkButton ID="lnkTabDisbursements" runat="server" CssClass="tab active" OnClick="lnkTabDisbursements_Click">Pending Disbursements (HF48) + Search Disbursements</asp:LinkButton>
                <asp:LinkButton ID="lnkTabTasks" runat="server" CssClass="tab" OnClick="lnkTabTasks_Click">Open Service Tickets</asp:LinkButton>
                <asp:LinkButton ID="lnkTabAudit" runat="server" CssClass="tab" OnClick="lnkTabAudit_Click">Audit Log</asp:LinkButton>
            </div>

            <asp:Panel ID="pnlDisbursementsTab" runat="server">

            <!-- ============================================= -->
            <!-- SECTION 1: Search / Filter Disbursements -->
            <!-- ============================================= -->
            <div class="panel">
                <div class="panel-header">Search Disbursements</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>Application No:</label>
                        <asp:TextBox ID="txtAppRefNo" runat="server" Width="200px" />
                        &nbsp;&nbsp;
                        <label>Lead No:</label>
                        <asp:TextBox ID="txtLeadNo" runat="server" Width="200px" />
<label>Developer Name:</label>
                        <asp:TextBox ID="txtDeveloperName" runat="server" Width="200px" />
                        &nbsp;&nbsp;
                        <label>Project Name:</label>
                        <asp:TextBox ID="txtProjectName" runat="server" Width="200px" />
                    </div>

                    <div class="form-group">
                        <label>Disb. Date From:</label>
                        <asp:TextBox ID="txtDateFrom" runat="server" Width="120px" placeholder="dd/MM/yyyy" MaxLength="10" />
                        &nbsp;&nbsp;
                        <label>Disb. Date To:</label>
                        <asp:TextBox ID="txtDateTo" runat="server" Width="120px" placeholder="dd/MM/yyyy" MaxLength="10" />
                        &nbsp;&nbsp;
                        <label>Developer Tier:</label>
                        <asp:DropDownList ID="ddlTier" runat="server" Width="200px">
                            <asp:ListItem Text="-- All --" Value="" />
                            <asp:ListItem Text="Tier 1" Value="Tier 1" />
                            <asp:ListItem Text="Tier 2" Value="Tier 2" />
                        </asp:DropDownList>
                         &nbsp;&nbsp;
                          <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-primary" OnClick="btnSearch_Click" />
                        <asp:Button ID="btnClear" runat="server" Text="Clear" CssClass="btn btn-info" OnClick="btnClear_Click" />
                    </div>

                </div>
            </div>

            <!-- ============================================= -->
            <!-- SECTION 2: Disbursement Grid -->
            <!-- ============================================= -->
            <div class="panel">
                <div class="panel-header">Pending Disbursements (HF48)</div>
                <div class="panel-body">
                    <asp:GridView ID="gvDisbursements" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False" DataKeyNames="APP_REF_NO,Lead_No,Disb_Date"
                        AllowPaging="True" PageSize="10"
                        OnPageIndexChanging="gvDisbursements_PageIndexChanging"
                        OnRowCommand="gvDisbursements_RowCommand"
                        EmptyDataText="No disbursement records found."

                        AlternatingRowStyle-CssClass="alt">
<PagerStyle CssClass="dfm-pager" HorizontalAlign="Center" />
                <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                        <Columns>
                            <asp:BoundField DataField="APP_REF_NO" HeaderText="App Ref No" />
                            <asp:BoundField  Visible="false" DataField="Lead_No" HeaderText="Lead No" />
                           <%-- <asp:BoundField DataField="Customer_name" HeaderText="Customer" />--%>
                            <asp:BoundField DataField="Disb_Date" HeaderText="Disb. Date" DataFormatString="{0:dd/MM/yyyy}" />
                            <asp:BoundField DataField="Disb_amount" HeaderText="Disb Amount" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="Property_DeveloperName" HeaderText="Developer" />
                            <asp:BoundField DataField="dev_tier" HeaderText="Tier" />
                            <asp:BoundField DataField="Property_ProjectName" HeaderText="Project" />
                            <asp:BoundField DataField="value_tranche" HeaderText="Tranche" />
                            <asp:BoundField DataField="MilestonePaymentPct" HeaderText="Mlestne %" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="PropertyPaymentPct" HeaderText="Prop Pymnt %" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="FinancePaymentPct" HeaderText="Fnce Pymnt %" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="Disb_Status" HeaderText="Disb. Status" />
                            <asp:BoundField DataField="DaysRemaining" HeaderText="Days Left" />
                            <asp:BoundField DataField="CLM_Ticket_RefNo" HeaderText="CLM Ticket" />
                            <asp:BoundField DataField="ENG_Ticket_RefNo" HeaderText="Eng. Ticket" />
                            <asp:TemplateField HeaderText="Actions">
                                <ItemTemplate>
                                    <asp:Button ID="btn60Day" runat="server" Text="60-Day" CssClass="btn btn-primary" CommandName="Send60Day"
                                        CommandArgument='<%# Eval("APP_REF_NO") + "|" + Eval("Lead_No") + "|" + Eval("Disb_Date") %>'
                                        OnClientClick="return confirm('Send 60-Day notification for this disbursement?');" />
                                    <asp:Button ID="btn30Day" runat="server" Text="30-Day" CssClass="btn btn-warning" CommandName="Send30Day"
                                        CommandArgument='<%# Eval("APP_REF_NO") + "|" + Eval("Lead_No") + "|" + Eval("Disb_Date") %>'
                                        OnClientClick="return confirm('Send 30-Day notification for this disbursement?');" />
                                  <%--  <asp:Button ID="btn5Day" runat="server" Text="5-Day" CssClass="btn btn-success" CommandName="Send5Day"
                                        CommandArgument='<%# Eval("APP_REF_NO") + "|" + Eval("Lead_No") + "|" + Eval("Disb_Date") %>'
                                        OnClientClick="return confirm('Send 5-Day notification for this disbursement?');" />--%>


                                        <asp:Button ID="btnCreateCLMTicket" runat="server" Text="Ops" CssClass="btn btn-success" CommandName="CreateCLMTicket"
                                            CommandArgument='<%# Eval("APP_REF_NO") + "|" + Eval("Lead_No") + "|" + Eval("Disb_Date") %>'
                                            OnClientClick="return confirm('Create an Operations service ticket for this disbursement?');" />
                                        <asp:Button ID="btnCreateENGTicket" runat="server" Text="Eng." CssClass="btn btn-danger" CommandName="CreateENGTicket"
                                            CommandArgument='<%# Eval("APP_REF_NO") + "|" + Eval("Lead_No") + "|" + Eval("Disb_Date") %>'
                                            OnClientClick="return confirm('Create an Engineering ticket for this disbursement?');" />

                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>
            </div>

            </asp:Panel>

            <asp:Panel ID="pnlTasksTab" runat="server" Visible="false">
            <!-- ============================================= -->
            <!-- SECTION 3: Open Service Tickets -->
            <!-- ============================================= -->
            <div class="panel">
                <div class="panel-header">Open Service Tickets</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>App Ref No:</label>
                        <asp:TextBox ID="txtTaskAppRefNo" runat="server" Width="180px" />
                        &nbsp;&nbsp;
                        <label>Ticket Ref:</label>
                        <asp:TextBox ID="txtTaskCaseRefNo" runat="server" Width="180px" />
                        &nbsp;&nbsp;
                        <label>Task Type:</label>
                        <asp:DropDownList ID="ddlTaskType" runat="server" Width="200px">
                            <asp:ListItem Text="-- All --" Value="" />
                            <asp:ListItem Text="Operations" Value="CLM Service Ticket" />
                            <asp:ListItem Text="Engineering" Value="Engineering Task" />
                        </asp:DropDownList>
                        &nbsp;&nbsp;
                        <asp:Button ID="btnTaskFilter" runat="server" Text="Filter" CssClass="btn btn-primary" OnClick="btnTaskFilter_Click" />
                        <asp:Button ID="btnTaskClear" runat="server" Text="Clear" CssClass="btn btn-info" OnClick="btnTaskClear_Click" />
                    </div>
                    <asp:GridView ID="gvTasks" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False" DataKeyNames="TaskID"
                        AllowPaging="True" PageSize="10"
                        OnPageIndexChanging="gvTasks_PageIndexChanging"
                        OnRowCommand="gvTasks_RowCommand"
                        EmptyDataText="No open service tickets."
                        AlternatingRowStyle-CssClass="alt">
                        <PagerStyle CssClass="dfm-pager" HorizontalAlign="Center" />
                        <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                        <Columns>
                            <asp:BoundField DataField="TaskID" HeaderText="Task ID" />
                            <asp:BoundField DataField="APP_REF_NO" HeaderText="App Ref No" />
                            <%--<asp:BoundField DataField="Lead_No" HeaderText="Lead No" />
                            <asp:BoundField DataField="Customer_Name" HeaderText="Customer" />--%>
                            <asp:BoundField DataField="Disb_Date" HeaderText="Disb Dt" DataFormatString="{0:dd/MM/yyyy}" />
                            <asp:BoundField DataField="Disb_Amount" HeaderText="Disb. Amnt" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="DeveloperName" HeaderText="Developer" />
                            <asp:BoundField DataField="DevTier" HeaderText="Tier" />
                            <asp:BoundField DataField="ProjectName" HeaderText="Project" />
                            <asp:BoundField DataField="ProjectStatus" HeaderText="Tranche" />
                            <asp:BoundField DataField="MilestonePaymentPct" HeaderText="Milstne %" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="PropertyPaymentPct" HeaderText="Prop Pymnt%" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="FinancePaymentPct" HeaderText="Fnce Pymnt%" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="Disb_Status" HeaderText="Disb Sts" />
                            <asp:BoundField DataField="DaysLeft" HeaderText="Days Left" />
                            <asp:BoundField DataField="Case_RefNo" HeaderText="Svc Tckt (Ops/Eng)" />
                            <asp:TemplateField HeaderText="Type">
                                <ItemTemplate><%# FormatTaskType(Eval("TaskType")) %></ItemTemplate>
                            </asp:TemplateField>
                            <asp:BoundField DataField="TicketCurrentStatus" HeaderText="Ticket Status" />
                            <%--<asp:BoundField DataField="AssignedTeam" HeaderText="Asgned To" />--%>
                            <asp:BoundField DataField="Status" HeaderText="Status" />
                            <asp:BoundField DataField="CreatedBy" HeaderText="Created By" />
                            <asp:BoundField DataField="CreatedOn" HeaderText="Created On" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
            </asp:Panel>

            <asp:Panel ID="pnlAuditTab" runat="server" Visible="false">

            <!-- ============================================= -->
            <!-- SECTION 4: Audit Log -->
            <!-- ============================================= -->
            <div class="panel">
                <div class="panel-header">Audit Log</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>Filter App No:</label>
                        <asp:TextBox ID="txtAuditAppNo" runat="server" Width="200px" />
                        <asp:Button ID="btnAuditSearch" runat="server" Text="Filter Audit" CssClass="btn btn-primary" OnClick="btnAuditSearch_Click" />
                        <asp:Button ID="btnAuditAll" runat="server" Text="Show All" CssClass="btn btn-info" OnClick="btnAuditAll_Click" />
                    </div>
                    <asp:GridView ID="gvAuditLog" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False"
                        AllowPaging="True" PageSize="10"
                        OnPageIndexChanging="gvAuditLog_PageIndexChanging"
                        EmptyDataText="No audit records found."
                        AlternatingRowStyle-CssClass="alt">
                        <PagerStyle CssClass="dfm-pager" HorizontalAlign="Center" />
                        <PagerSettings Mode="NumericFirstLast" PageButtonCount="10" FirstPageText="&amp;laquo;" LastPageText="&amp;raquo;" />
                        <Columns>
                            <asp:BoundField DataField="AuditID" HeaderText="ID" />
                            <asp:BoundField DataField="APP_REF_NO" HeaderText="App Ref No" />
                            <asp:BoundField DataField="Lead_No" HeaderText="Lead No" />
                            <asp:BoundField DataField="Disb_Date" HeaderText="Disb. Date" DataFormatString="{0:dd/MM/yyyy}" />
                            <asp:BoundField DataField="DaysBefore" HeaderText="Days" />
                            <asp:TemplateField HeaderText="Action Type">
                                <ItemTemplate><%# FormatActionType(Eval("ActionType")) %></ItemTemplate>
                            </asp:TemplateField>
                            <asp:BoundField DataField="ActionResult" HeaderText="Result" />
                            <asp:BoundField DataField="NotificationSentTo" HeaderText="Notified To" />
                            <asp:BoundField DataField="CreatedBy" HeaderText="By" />
                            <asp:BoundField DataField="CreatedOn" HeaderText="Date" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
            </asp:Panel>
        </div>
    </form>
</body>
</html>
 