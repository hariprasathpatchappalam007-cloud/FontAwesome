using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class HF48BulkPostponement : System.Web.UI.Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                if (System.Web.HttpContext.Current.User != null &&
                    System.Web.HttpContext.Current.User.Identity != null &&
                    !string.IsNullOrEmpty(System.Web.HttpContext.Current.User.Identity.Name))
                    return System.Web.HttpContext.Current.User.Identity.Name;
                return "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                hfDraftId.Value = Guid.NewGuid().ToString("N");
                hfMode.Value = "Hold";

                LoadProjects();
                LoadActiveHolds();
                LoadPending();
                LoadHistory();
                ApplyTabVisibility();
            }
        }

        #region Tab switch

        protected void lnkTabHold_Click(object sender, EventArgs e)
        {
            hfMode.Value = "Hold";
            ApplyTabVisibility();
        }

        protected void lnkTabUnhold_Click(object sender, EventArgs e)
        {
            hfMode.Value = "Unhold";
            ApplyTabVisibility();
        }

        private void ApplyTabVisibility()
        {
            bool hold = (hfMode.Value ?? "Hold") == "Hold";
            pnlHoldMaker.Visible = hold;
            pnlUnholdMaker.Visible = !hold;
            lnkTabHold.CssClass   = hold  ? "tab active"        : "tab";
            lnkTabUnhold.CssClass = !hold ? "tab unhold active" : "tab unhold";
            btnSubmit.Text = hold ? "Submit Hold for Approval" : "Submit Unhold for Approval";
            btnSubmit.CssClass = hold ? "btn btn-success" : "btn btn-warning";
        }

        #endregion

        #region Maker — Hold

        private DataRow _projectsCache;
        private DataTable _projectsCacheTable;

        private void LoadProjects()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetProjects", null);
            _projectsCacheTable = dt;
            ddlProject.Items.Clear();
            ddlProject.Items.Add(new ListItem("-- Select a project --", ""));
            foreach (DataRow r in dt.Rows)
            {
                string id = Convert.ToString(r["Property_ProjectID"]);
                string label = string.Format("{0}  -  {1}  ({2} app(s) | Tier: {3} | Tranche: {4})",
                    r["Property_ProjectName"], r["Property_DeveloperName"],
                    r["AppCount"], r["dev_tier"], r["value_tranche"]);
                ddlProject.Items.Add(new ListItem(label, id));
            }
            ViewState["ProjectsTable"] = dt;
        }

        protected void btnRefreshProjects_Click(object sender, EventArgs e)
        {
            LoadProjects();
            gvPreview.DataSource = null; gvPreview.DataBind();
            lblPreviewSummary.Text = "";
            ResetProjectMeta();
        }

        protected void ddlProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateProjectMeta();
            RunPreview();
        }

        protected void btnPreview_Click(object sender, EventArgs e)
        {
            UpdateProjectMeta();
            RunPreview();
        }

        private void ResetProjectMeta()
        {
            lblProjTier.Text = "-";
            lblProjTranche.Text = "-";
            lblProjPending.Text = "0";
            lblProjHeld.Text = "0";
        }

        private void UpdateProjectMeta()
        {
            DataTable dt = ViewState["ProjectsTable"] as DataTable;
            string id = ddlProject.SelectedValue;
            if (dt == null || string.IsNullOrEmpty(id)) { ResetProjectMeta(); return; }
            DataRow[] rows = dt.Select("Property_ProjectID='" + id.Replace("'", "''") + "'");
            if (rows.Length == 0) { ResetProjectMeta(); return; }
            DataRow r = rows[0];
            lblProjTier.Text    = Convert.ToString(r["dev_tier"]);
            lblProjTranche.Text = Convert.ToString(r["value_tranche"]);
            lblProjPending.Text = Convert.ToString(r["PendingRows"]);
            lblProjHeld.Text    = Convert.ToString(r["HoldRows"]);
        }

        private void RunPreview()
        {
            string projectId = ddlProject.SelectedValue;
            if (string.IsNullOrEmpty(projectId))
            {
                gvPreview.DataSource = null; gvPreview.DataBind();
                lblPreviewSummary.Text = "";
                return;
            }
            int shiftDays;
            if (!int.TryParse((txtShiftDays.Text ?? "").Trim(), out shiftDays) || shiftDays < 0)
            {
                ShowMessage("Shift days must be a non-negative integer (0 = Hold without shifting dates).", false);
                return;
            }

            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_Preview", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Property_ProjectID", projectId);
                c.Parameters.AddWithValue("@ShiftDays", shiftDays);
                c.Parameters.AddWithValue("@AppRefNo",
                    string.IsNullOrEmpty(txtAppRefNo.Text) ? (object)DBNull.Value : txtAppRefNo.Text.Trim());
                c.Parameters.AddWithValue("@DisbStatus",
                    string.IsNullOrEmpty(ddlDisbStatus.SelectedValue) ? (object)DBNull.Value : ddlDisbStatus.SelectedValue);
            });

            gvPreview.DataSource = dt;
            gvPreview.DataBind();

            int distinctApps = 0; decimal totalImpacted = 0m; int holdableRows = 0;
            if (dt.Rows.Count > 0)
            {
                System.Collections.Generic.HashSet<string> apps = new System.Collections.Generic.HashSet<string>();
                foreach (DataRow r in dt.Rows)
                {
                    apps.Add(Convert.ToString(r["APP_REF_NO"]));
                    string ds = Convert.ToString(r["disb_status"]);
                    if (ds == "Not Disbursed")
                    {
                        holdableRows++;
                        if (r["Disb_amount"] != DBNull.Value) totalImpacted += Convert.ToDecimal(r["Disb_amount"]);
                    }
                }
                distinctApps = apps.Count;
            }

            lblPreviewSummary.Text = string.Format(
                "Preview: {0} row(s) shown across {1} app(s). Holdable (Not Disbursed): {2} row(s), total impacted amount: {3:N2}. Shift: {4} day(s).",
                dt.Rows.Count, distinctApps, holdableRows, totalImpacted, shiftDays);
        }

        protected void gvPreview_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                int grp = 0;
                int.TryParse(Convert.ToString(DataBinder.Eval(e.Row.DataItem, "GroupIndex")), out grp);
                e.Row.CssClass = "grp-" + (((grp - 1) % 6) + 1);
            }
        }

        #endregion

        #region Maker — Unhold

        private void LoadActiveHolds()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetActiveHolds", null);
            ddlActiveHold.Items.Clear();
            ddlActiveHold.Items.Add(new ListItem("-- Select an Approved Hold to release --", ""));
            foreach (DataRow r in dt.Rows)
            {
                string lbl = string.Format("Req #{0}  -  {1}  ({2} app(s), {3} row(s), shift +{4}d, by {5} on {6:dd/MM/yyyy})",
                    r["RequestID"], r["Property_ProjectName"], r["AffectedAppCount"], r["AffectedRowCount"],
                    r["ShiftDays"], r["MakerUser"],
                    r["CheckerOn"] == DBNull.Value ? r["MakerOn"] : r["CheckerOn"]);
                ddlActiveHold.Items.Add(new ListItem(lbl, Convert.ToString(r["RequestID"])));
            }
        }

        protected void btnRefreshHolds_Click(object sender, EventArgs e)
        {
            LoadActiveHolds();
        }

        #endregion

        #region Maker — Submit (both modes)

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            bool isHold = (hfMode.Value ?? "Hold") == "Hold";

            if (string.IsNullOrEmpty((txtReason.Text ?? "").Trim()))
            {
                ShowMessage("Reason is required.", false);
                return;
            }

            int shiftDays = 0;
            string projectId = null;
            int sourceId = 0;

            if (isHold)
            {
                projectId = ddlProject.SelectedValue;
                if (string.IsNullOrEmpty(projectId))
                {
                    ShowMessage("Pick a project first.", false);
                    return;
                }
                if (!int.TryParse((txtShiftDays.Text ?? "0").Trim(), out shiftDays) || shiftDays < 0)
                {
                    ShowMessage("Shift days must be a non-negative integer.", false);
                    return;
                }
            }
            else
            {
                if (!int.TryParse(ddlActiveHold.SelectedValue, out sourceId) || sourceId == 0)
                {
                    ShowMessage("Pick an Approved Hold to release.", false);
                    return;
                }
            }

            string status, message; int requestId;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_Submit", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestType", isHold ? "Hold" : "Unhold");
                cmd.Parameters.AddWithValue("@Property_ProjectID", (object)projectId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ShiftDays", shiftDays);
                cmd.Parameters.AddWithValue("@SourceRequestID", sourceId == 0 ? (object)DBNull.Value : sourceId);
                cmd.Parameters.AddWithValue("@Reason", txtReason.Text.Trim());
                cmd.Parameters.AddWithValue("@MakerUser", CurrentUser);
                cmd.Parameters.AddWithValue("@DraftID", hfDraftId.Value);

                SqlParameter pId = cmd.Parameters.Add("@RequestID", SqlDbType.Int);
                pId.Direction = ParameterDirection.Output;
                SqlParameter pSt = cmd.Parameters.Add("@Status",  SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();

                requestId = pId.Value == DBNull.Value ? 0 : Convert.ToInt32(pId.Value);
                status    = Convert.ToString(pSt.Value);
                message   = Convert.ToString(pMs.Value);
            }

            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS")
            {
                txtReason.Text = "";
                hfDraftId.Value = Guid.NewGuid().ToString("N"); // fresh draft for next submission
                gvPreview.DataSource = null; gvPreview.DataBind();
                lblPreviewSummary.Text = "";
                LoadPending();
                LoadActiveHolds();
            }
        }

        #endregion

        #region Checker

        private void LoadPending()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Status", "Pending Approval");
            });
            gvPending.DataSource = dt;
            gvPending.DataBind();
        }

        protected void gvPending_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ViewRequest")
            {
                int reqId;
                if (!int.TryParse(Convert.ToString(e.CommandArgument), out reqId))
                {
                    ShowMessage("Invalid Request ID.", false);
                    return;
                }
                LoadDetail(reqId);
            }
        }

        private void LoadDetail(int requestId)
        {
            DataTable header = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Status", "Pending Approval");
            });
            DataRow hRow = null;
            foreach (DataRow r in header.Rows)
            {
                if (Convert.ToInt32(r["RequestID"]) == requestId) { hRow = r; break; }
            }
            if (hRow == null)
            {
                ShowMessage("Request is no longer pending (it may have just been actioned).", false);
                pnlDetail.Visible = false;
                LoadPending(); LoadHistory(); LoadActiveHolds();
                return;
            }

            hfSelectedRequestId.Value = requestId.ToString();
            lblReqId.Text      = requestId.ToString();
            lblReqType.Text    = "  -  " + Convert.ToString(hRow["RequestType"]);
            lblReqProject.Text = Convert.ToString(hRow["Property_ProjectName"]);
            lblReqMaker.Text   = Convert.ToString(hRow["MakerUser"]);
            lblReqShift.Text   = Convert.ToString(hRow["ShiftDays"]);
            lblReqReason.Text  = Server.HtmlEncode(Convert.ToString(hRow["Reason"]));
            txtCheckerRemarks.Text = "";

            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequestDetail", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@RequestID", requestId);
            });
            gvDetail.DataSource = dt;
            gvDetail.DataBind();

            DataTable docs = ExecuteReader("Proc_HF48_BulkPostpone_GetDocs", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@DraftID", DBNull.Value);
                c.Parameters.AddWithValue("@RequestID", requestId);
            });
            rptDocs.DataSource = docs; rptDocs.DataBind();
            lblNoDocs.Visible = (docs.Rows.Count == 0);
            rptDocs.Visible = (docs.Rows.Count > 0);

            pnlDetail.Visible = true;
        }

        protected void gvDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                int grp = 0;
                int.TryParse(Convert.ToString(DataBinder.Eval(e.Row.DataItem, "GroupIndex")), out grp);
                e.Row.CssClass = "grp-" + (((grp - 1) % 6) + 1);
            }
        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            int requestId = ParseSelectedRequestId();
            if (requestId == 0) return;

            string status, message;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_Approve", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestID", requestId);
                cmd.Parameters.AddWithValue("@CheckerUser", CurrentUser);
                cmd.Parameters.AddWithValue("@CheckerRemarks",
                    string.IsNullOrEmpty(txtCheckerRemarks.Text) ? (object)DBNull.Value : txtCheckerRemarks.Text.Trim());

                SqlParameter pSt = cmd.Parameters.Add("@Status",  SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();
                status  = Convert.ToString(pSt.Value);
                message = Convert.ToString(pMs.Value);
            }
            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS")
            {
                pnlDetail.Visible = false;
                LoadPending(); LoadHistory(); LoadProjects(); LoadActiveHolds();
            }
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            int requestId = ParseSelectedRequestId();
            if (requestId == 0) return;

            if (string.IsNullOrEmpty((txtCheckerRemarks.Text ?? "").Trim()))
            {
                ShowMessage("Rejection requires Checker remarks.", false);
                return;
            }

            string status, message;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_Reject", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestID", requestId);
                cmd.Parameters.AddWithValue("@CheckerUser", CurrentUser);
                cmd.Parameters.AddWithValue("@CheckerRemarks", txtCheckerRemarks.Text.Trim());

                SqlParameter pSt = cmd.Parameters.Add("@Status",  SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();
                status  = Convert.ToString(pSt.Value);
                message = Convert.ToString(pMs.Value);
            }
            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS")
            {
                pnlDetail.Visible = false;
                LoadPending(); LoadHistory(); LoadActiveHolds();
            }
        }

        protected void btnCloseDetail_Click(object sender, EventArgs e) { pnlDetail.Visible = false; }

        private int ParseSelectedRequestId()
        {
            int reqId;
            if (!int.TryParse(hfSelectedRequestId.Value, out reqId) || reqId == 0)
            {
                ShowMessage("No request selected.", false);
                return 0;
            }
            return reqId;
        }

        #endregion

        #region History

        private void LoadHistory()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Status", DBNull.Value);
            });
            DataView dv = dt.DefaultView;
            dv.RowFilter = "Status <> 'Pending Approval'";
            gvHistory.DataSource = dv;
            gvHistory.DataBind();
        }

        protected void gvHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvHistory.PageIndex = e.NewPageIndex;
            LoadHistory();
        }

        #endregion

        #region Misc

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            ShowMessage("Acting user set to: " + CurrentUser, true);
            LoadPending(); LoadHistory();
        }

        private DataTable ExecuteReader(string procName, Action<SqlCommand> bindParams)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (bindParams != null) bindParams(cmd);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    conn.Open();
                    da.Fill(dt);
                }
            }
            return dt;
        }

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible = true;
            lblMessage.Text = Server.HtmlEncode(message);
            pnlMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }

        #endregion
    }
}
