using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class HF48BulkPostponement : System.Web.UI.Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                if (Session["UserID"] != null)
                    return Session["UserID"].ToString();
                return System.Web.HttpContext.Current.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPostponementLog("");
            }
        }

        #region Data Loading

        private void LoadDisbursements()
        {
            LoadDisbursements(
                txtAppRefNo.Text.Trim(),
                ParseDate(txtDisbDateFrom.Text),
                ParseDate(txtDisbDateTo.Text));
        }

        private void LoadDisbursements(string appRefNo, DateTime? dateFrom, DateTime? dateTo)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                // Reuse the existing Proc_HF48_Get_Disbursements which already returns
                // PropertyPaymentPct and FinancePaymentPct
                SqlCommand cmd = new SqlCommand("Proc_HF48_Get_Disbursements", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AppRefNo",      string.IsNullOrEmpty(appRefNo) ? (object)DBNull.Value : appRefNo);
                cmd.Parameters.AddWithValue("@LeadNo",        (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@DeveloperName", (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ProjectName",   (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@DateFrom",      dateFrom.HasValue ? (object)dateFrom.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@DateTo",        dateTo.HasValue   ? (object)dateTo.Value   : DBNull.Value);
                cmd.Parameters.AddWithValue("@Tier",          (object)DBNull.Value);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                // Store in ViewState so paging and checkbox state survive postbacks
                ViewState["DisbData"] = dt;

                gvDisbursements.DataSource = dt;
                gvDisbursements.DataBind();
            }
        }

        private void LoadPostponementLog(string appRefNo)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_GetPostponementLog", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefNo) ? (object)DBNull.Value : appRefNo);
                cmd.Parameters.AddWithValue("@DateFrom", (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@DateTo",   (object)DBNull.Value);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvPostponeLog.DataSource = dt;
                gvPostponeLog.DataBind();
            }
        }

        protected void gvDisbursements_DataBound(object sender, EventArgs e)
        {
            // Nothing extra needed; checkboxes bind themselves
        }

        #endregion

        #region Search & Filter

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            gvDisbursements.PageIndex = 0;
            LoadDisbursements(
                txtAppRefNo.Text.Trim(),
                ParseDate(txtDisbDateFrom.Text),
                ParseDate(txtDisbDateTo.Text));
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtAppRefNo.Text    = "";
            txtDisbDateFrom.Text = "";
            txtDisbDateTo.Text   = "";
            gvDisbursements.PageIndex = 0;
            gvDisbursements.DataSource = null;
            gvDisbursements.DataBind();
        }

        #endregion

        #region GridView Paging

        protected void gvDisbursements_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvDisbursements.PageIndex = e.NewPageIndex;
            // Re-bind from ViewState so filter is preserved
            if (ViewState["DisbData"] != null)
            {
                gvDisbursements.DataSource = (DataTable)ViewState["DisbData"];
                gvDisbursements.DataBind();
            }
            else
            {
                LoadDisbursements();
            }
        }

        protected void gvPostponeLog_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvPostponeLog.PageIndex = e.NewPageIndex;
            LoadPostponementLog(txtLogAppRefNo.Text.Trim());
        }

        #endregion

        #region Bulk Postponement

        protected void btnPostponeNoHold_Click(object sender, EventArgs e)
        {
            ExecuteBulkPostponement(applyHold: false);
        }

        protected void btnPostponeWithHold_Click(object sender, EventArgs e)
        {
            ExecuteBulkPostponement(applyHold: true);
        }

        private void ExecuteBulkPostponement(bool applyHold)
        {
            // Validate shift days — accept negative (preponment)
            int shiftDays;
            if (!int.TryParse(txtShiftDays.Text.Trim(), out shiftDays))
            {
                ShowMessage("Please enter a valid integer for Shift Days. Use negative values for preponment (e.g. -10).", false);
                return;
            }

            if (shiftDays == 0)
            {
                ShowMessage("Shift Days cannot be zero.", false);
                return;
            }

            // Collect selected rows
            StringBuilder selectedKeys = new StringBuilder();
            int selectedCount = 0;

            foreach (GridViewRow row in gvDisbursements.Rows)
            {
                if (row.RowType != DataControlRowType.DataRow) continue;

                CheckBox chk = (CheckBox)row.FindControl("chkSelect");
                if (chk == null || !chk.Checked) continue;

                object appRefObj = gvDisbursements.DataKeys[row.RowIndex]["APP_REF_NO"];
                object leadNoObj = gvDisbursements.DataKeys[row.RowIndex]["Lead_No"];
                object disbDateObj = gvDisbursements.DataKeys[row.RowIndex]["Disb_Date"];

                if (appRefObj == null || leadNoObj == null || disbDateObj == null) continue;

                string appRef   = appRefObj.ToString();
                string leadNo   = leadNoObj.ToString();
                string disbDate = Convert.ToDateTime(disbDateObj).ToString("yyyy-MM-dd");

                if (selectedKeys.Length > 0) selectedKeys.Append(",");
                selectedKeys.AppendFormat("{0}|{1}|{2}", appRef, leadNo, disbDate);
                selectedCount++;
            }

            if (selectedCount == 0)
            {
                ShowMessage("No records selected. Please tick the checkboxes for the disbursements you want to process.", false);
                return;
            }

            string actionLabel = shiftDays >= 0 ? "Postponement" : "Preponment";
            string holdLabel   = applyHold ? "with Hold" : "without Hold";

            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostponement", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@SelectedKeys", selectedKeys.ToString());
                cmd.Parameters.AddWithValue("@ShiftDays",    shiftDays);
                cmd.Parameters.AddWithValue("@ApplyHold",    applyHold ? 1 : 0);
                cmd.Parameters.AddWithValue("@UserID",       CurrentUser);
                cmd.Parameters.AddWithValue("@Remarks",
                    string.Format("Bulk {0} {1} of {2} day(s) by {3}",
                        actionLabel, holdLabel, Math.Abs(shiftDays), CurrentUser));

                SqlParameter pStatus  = new SqlParameter("@Status",         SqlDbType.NVarChar, 50);
                SqlParameter pMessage = new SqlParameter("@Message",        SqlDbType.NVarChar, 500);
                SqlParameter pCount   = new SqlParameter("@ProcessedCount", SqlDbType.Int);
                pStatus.Direction  = ParameterDirection.Output;
                pMessage.Direction = ParameterDirection.Output;
                pCount.Direction   = ParameterDirection.Output;
                cmd.Parameters.Add(pStatus);
                cmd.Parameters.Add(pMessage);
                cmd.Parameters.Add(pCount);

                conn.Open();
                cmd.ExecuteNonQuery();

                bool success = pStatus.Value.ToString() == "SUCCESS";
                ShowMessage(pMessage.Value.ToString(), success);
            }

            // Refresh grids
            txtShiftDays.Text = "";
            LoadDisbursements();
            LoadPostponementLog(txtLogAppRefNo.Text.Trim());
        }

        #endregion

        #region Log Filter

        protected void btnFilterLog_Click(object sender, EventArgs e)
        {
            gvPostponeLog.PageIndex = 0;
            LoadPostponementLog(txtLogAppRefNo.Text.Trim());
        }

        protected void btnClearLog_Click(object sender, EventArgs e)
        {
            txtLogAppRefNo.Text = "";
            gvPostponeLog.PageIndex = 0;
            LoadPostponementLog("");
        }

        #endregion

        #region Helper

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible  = true;
            lblMessage.Text     = message;
            lblMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }

        private DateTime? ParseDate(string text)
        {
            if (string.IsNullOrEmpty(text)) return null;
            DateTime dt;
            return DateTime.TryParse(text, out dt) ? (DateTime?)dt : null;
        }

        #endregion
    }
}
