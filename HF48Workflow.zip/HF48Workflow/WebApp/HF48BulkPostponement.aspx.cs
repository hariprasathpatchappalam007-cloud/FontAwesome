using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class HF48BulkPostponement : System.Web.UI.Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                if (System.Web.HttpContext.Current.User != null &&
                    System.Web.HttpContext.Current.User.Identity != null &&
                    !string.IsNullOrEmpty(System.Web.HttpContext.Current.User.Identity.Name))
                    return System.Web.HttpContext.Current.User.Identity.Name;
                return "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null)
                    txtCurrentUser.Text = Session["UserID"].ToString();

                LoadProjects();
                LoadPending();
                LoadHistory();
            }
        }

        #region Maker

        private void LoadProjects()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetProjects", null);
            ddlProject.Items.Clear();
            ddlProject.Items.Add(new ListItem("-- Select a project --", ""));
            foreach (DataRow r in dt.Rows)
            {
                string id   = Convert.ToString(r["Property_ProjectID"]);
                string name = Convert.ToString(r["Property_ProjectName"]);
                string dev  = Convert.ToString(r["Property_DeveloperName"]);
                string apps = Convert.ToString(r["AppCount"]);
                ddlProject.Items.Add(new ListItem(
                    string.Format("{0}  -  {1}  ({2} app(s))", name, dev, apps), id));
            }
        }

        protected void btnRefreshProjects_Click(object sender, EventArgs e)
        {
            LoadProjects();
            gvPreview.DataSource = null; gvPreview.DataBind();
            lblPreviewSummary.Text = "";
        }

        protected void ddlProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Auto-preview when a project is picked, using whatever shift days the user has typed.
            RunPreview();
        }

        protected void btnPreview_Click(object sender, EventArgs e)
        {
            RunPreview();
        }

        private void RunPreview()
        {
            string projectId = ddlProject.SelectedValue;
            if (string.IsNullOrEmpty(projectId))
            {
                gvPreview.DataSource = null; gvPreview.DataBind();
                lblPreviewSummary.Text = "";
                return;
            }

            int shiftDays;
            if (!int.TryParse((txtShiftDays.Text ?? "").Trim(), out shiftDays) || shiftDays <= 0)
            {
                ShowMessage("Shift days must be a positive integer.", false);
                return;
            }

            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_Preview", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Property_ProjectID", projectId);
                c.Parameters.AddWithValue("@ShiftDays", shiftDays);
            });

            gvPreview.DataSource = dt;
            gvPreview.DataBind();

            int distinctApps = 0;
            decimal totalAmount = 0m;
            if (dt.Rows.Count > 0)
            {
                System.Collections.Generic.HashSet<string> apps = new System.Collections.Generic.HashSet<string>();
                foreach (DataRow r in dt.Rows)
                {
                    apps.Add(Convert.ToString(r["APP_REF_NO"]));
                    if (r["Disb_amount"] != DBNull.Value)
                        totalAmount += Convert.ToDecimal(r["Disb_amount"]);
                }
                distinctApps = apps.Count;
            }

            lblPreviewSummary.Text = string.Format(
                "Preview: {0} schedule row(s) across {1} application(s), shifting forward by {2} day(s). Total impacted amount: {3:N2}",
                dt.Rows.Count, distinctApps, shiftDays, totalAmount);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string projectId = ddlProject.SelectedValue;
            if (string.IsNullOrEmpty(projectId))
            {
                ShowMessage("Pick a project first.", false);
                return;
            }
            int shiftDays;
            if (!int.TryParse((txtShiftDays.Text ?? "").Trim(), out shiftDays) || shiftDays <= 0)
            {
                ShowMessage("Shift days must be a positive integer.", false);
                return;
            }
            if (string.IsNullOrEmpty((txtReason.Text ?? "").Trim()))
            {
                ShowMessage("Postponement reason is required.", false);
                return;
            }

            string status, message;
            int requestId;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_Submit", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Property_ProjectID", projectId);
                cmd.Parameters.AddWithValue("@ShiftDays", shiftDays);
                cmd.Parameters.AddWithValue("@Reason", txtReason.Text.Trim());
                cmd.Parameters.AddWithValue("@MakerUser", CurrentUser);

                SqlParameter pId = cmd.Parameters.Add("@RequestID", SqlDbType.Int);
                pId.Direction = ParameterDirection.Output;
                SqlParameter pSt = cmd.Parameters.Add("@Status",  SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();

                requestId = pId.Value == DBNull.Value ? 0 : Convert.ToInt32(pId.Value);
                status    = Convert.ToString(pSt.Value);
                message   = Convert.ToString(pMs.Value);
            }

            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS")
            {
                txtReason.Text = "";
                gvPreview.DataSource = null; gvPreview.DataBind();
                lblPreviewSummary.Text = "";
                LoadPending();
            }
        }

        #endregion

        #region Checker

        private void LoadPending()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Status", "Pending Approval");
            });
            gvPending.DataSource = dt;
            gvPending.DataBind();
        }

        protected void gvPending_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ViewRequest")
            {
                int reqId;
                if (!int.TryParse(Convert.ToString(e.CommandArgument), out reqId))
                {
                    ShowMessage("Invalid Request ID.", false);
                    return;
                }
                LoadDetail(reqId);
            }
        }

        private void LoadDetail(int requestId)
        {
            // Header
            DataTable header = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Status", "Pending Approval");
            });
            DataRow hRow = null;
            foreach (DataRow r in header.Rows)
            {
                if (Convert.ToInt32(r["RequestID"]) == requestId) { hRow = r; break; }
            }
            if (hRow == null)
            {
                ShowMessage("Request is no longer pending (it may have just been actioned).", false);
                pnlDetail.Visible = false;
                LoadPending();
                LoadHistory();
                return;
            }

            hfSelectedRequestId.Value = requestId.ToString();
            lblReqId.Text       = requestId.ToString();
            lblReqProject.Text  = Convert.ToString(hRow["Property_ProjectName"]);
            lblReqMaker.Text    = Convert.ToString(hRow["MakerUser"]);
            lblReqShift.Text    = Convert.ToString(hRow["ShiftDays"]);
            lblReqReason.Text   = Server.HtmlEncode(Convert.ToString(hRow["Reason"]));
            txtCheckerRemarks.Text = "";

            // Detail
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequestDetail", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@RequestID", requestId);
            });
            gvDetail.DataSource = dt;
            gvDetail.DataBind();

            pnlDetail.Visible = true;
        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            int requestId = ParseSelectedRequestId();
            if (requestId == 0) return;

            string status, message;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_Approve", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestID", requestId);
                cmd.Parameters.AddWithValue("@CheckerUser", CurrentUser);
                cmd.Parameters.AddWithValue("@CheckerRemarks",
                    string.IsNullOrEmpty(txtCheckerRemarks.Text) ? (object)DBNull.Value : txtCheckerRemarks.Text.Trim());

                SqlParameter pSt = cmd.Parameters.Add("@Status",  SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();

                status  = Convert.ToString(pSt.Value);
                message = Convert.ToString(pMs.Value);
            }

            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS")
            {
                pnlDetail.Visible = false;
                LoadPending();
                LoadHistory();
                LoadProjects(); // pending counts may shrink
            }
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            int requestId = ParseSelectedRequestId();
            if (requestId == 0) return;

            if (string.IsNullOrEmpty((txtCheckerRemarks.Text ?? "").Trim()))
            {
                ShowMessage("Rejection requires Checker remarks.", false);
                return;
            }

            string status, message;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_Reject", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestID", requestId);
                cmd.Parameters.AddWithValue("@CheckerUser", CurrentUser);
                cmd.Parameters.AddWithValue("@CheckerRemarks", txtCheckerRemarks.Text.Trim());

                SqlParameter pSt = cmd.Parameters.Add("@Status",  SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();

                status  = Convert.ToString(pSt.Value);
                message = Convert.ToString(pMs.Value);
            }

            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS")
            {
                pnlDetail.Visible = false;
                LoadPending();
                LoadHistory();
            }
        }

        protected void btnCloseDetail_Click(object sender, EventArgs e)
        {
            pnlDetail.Visible = false;
        }

        private int ParseSelectedRequestId()
        {
            int reqId;
            if (!int.TryParse(hfSelectedRequestId.Value, out reqId) || reqId == 0)
            {
                ShowMessage("No request selected.", false);
                return 0;
            }
            return reqId;
        }

        #endregion

        #region History

        private void LoadHistory()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                // pull everything; ordering is handled in the proc
                c.Parameters.AddWithValue("@Status", DBNull.Value);
            });
            // Keep only Approved/Rejected/Cancelled in the History panel
            DataView dv = dt.DefaultView;
            dv.RowFilter = "Status <> 'Pending Approval'";
            gvHistory.DataSource = dv;
            gvHistory.DataBind();
        }

        protected void gvHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvHistory.PageIndex = e.NewPageIndex;
            LoadHistory();
        }

        #endregion

        #region Misc

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            ShowMessage("Acting user set to: " + CurrentUser, true);
            LoadPending();
            LoadHistory();
        }

        private DataTable ExecuteReader(string procName, Action<SqlCommand> bindParams)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (bindParams != null) bindParams(cmd);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    conn.Open();
                    da.Fill(dt);
                }
            }
            return dt;
        }

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible = true;
            lblMessage.Text = Server.HtmlEncode(message);
            pnlMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }

        #endregion
    }
}
