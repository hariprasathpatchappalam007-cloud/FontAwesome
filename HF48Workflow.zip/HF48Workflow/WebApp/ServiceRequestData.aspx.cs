using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class ServiceRequestData : Page
    {
        // ── Connection ──────────────────────────────────────────────────────────
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        // ── TVP column names (must match dbo.TVP_ServiceRequest_Data exactly) ──
        // "ServiceRequestNo" (source alias) is also accepted and mapped to "SRNo".
        private static readonly string[] TvpColumns = new[]
        {
            "SRNo","MOBILENUMBER","PERSONAL_EMAIL","OFFICE_EMAIL",
            "APPLICATIONID","CUSTOMERID",
            "CUSTOMERNAME1","CUSTOMERNAME2","CUSTOMERNAME3","CUSTOMERNAME4",
            "NATIONALITY1","NATIONALITY2","NATIONALITY3","NATIONALITY4",
            "PASSPORTNUMBER",
            "DATEOFBIRTH1","DATEOFBIRTH2","DATEOFBIRTH3","DATEOFBIRTH4",
            "RESIDENCYTYPE",
            "DEVELOPER","PROPERTYNAME","PROPERTYDETAILS","PROPERTYTYPE",
            "ORIGINALPROPERTYVALUE","APPRAISEDPROPERTYVALUE","BUILTUPAREA",
            "ISTISNATENOR","IJARATENOR",
            "EMPLOYMENTTYPE",
            "INCOME1","INCOME2","INCOME3","INCOME4",
            "FINANCEVALUE","DOWNPAYMENT","DSR","FTV","INSTALLMENTAMOUNT",
            "CORPORATECATEGORY",
            "CURRENTEMPLOYER1","CURRENTEMPLOYER2","CURRENTEMPLOYER3","CURRENTEMPLOYER4",
            "DESIGNATION1","DESIGNATION2","DESIGNATION3","DESIGNATION4",
            "CURRENTSTATUS","LASTUPDATED",
            "EDUCATION1","EDUCATION2","EDUCATION3","EDUCATION4",
            "FINALRATE","PREAPPROVALNO","PROFITFEE","PURCHASETYPE","SELLERNAME",
            "ISTISNAPRODUCT","IJARAPRODUCT",
            "MAILING_POBOX","MAILING_CITY","MAILING_COUNTRY",
            "MOBILECODE","MOBILENUMBER1",
            "RESI_TEL_CODE","RESI_TEL_NUM","OFFICE_TEL_CODE","OFFICE_TEL_NUM",
            "HC_TEL_CODE","HC_TEL_NUM",
            "PERSONAL_EMAIL1","OFFICE_EMAIL1","FAX_CODE","FAX_NUMBER",
            "RESI_ADDRESS1","RESI_ADDRESS2","RESI_ADDRESS3","RESI_ADDRESS4",
            "OFFICE_ADDRESS1","OFFICE_ADDRESS2","OFFICE_ADDRESS3",
            "MAKER_ID","MAKER_DT_STAMP","CHECKER_ID","CHECKER_DT_STAMP",
            "MOD_NO","WORKNAME","ALTERNATE_CONTACT","ALTERNATE_CONTACT_CODE",
            "HOMECOUNTRY_ADD1","HOMECOUNTRY_ADD2","HOMECOUNTRY_ADD3",
            "SEC_STATUS","CUSTOMERID2","CUSTOMERID3","CUSTOMERID4",
            "PASSPORTNUMBER2","PASSPORTNUMBER3","PASSPORTNUMBER4",
            "BRANCH_CODE","PROPERTY_PHASE","PROPERTYID",
            "OL_GENERATION_DATE","OL_ACCEPTANCE_DATE","APP_START_DATE",
            "SALES_OFFICER","CHANNEL","CASE_SUBMISSION_DATE",
            "SPREAD","CARPORATE_CATEGORY","PSF","EXPECTED_COMPLETION_DATE",
            "DELAYCHARGESYN","LEAD_NO","STAFF_DISCOUNT","STAFF_ID",
            "LIFEINSURANCECOVER","PORTFOLIO","PRODUCT_TYPE","MA_NAME","PRODUCT_SUB_TYPE",
            "STAFF_YN","MILESTONE_PROJECT","A_Value",
            "CUSTOMERID1","CUSTOMER_CATEGORY","CUST_SEGMENT","STAFF_YN1",
            "CURRENTSTATUS1","DATEOFBIRTH11","MAILING_COUNTRY1","MAILING_POBOX1",
            "MOBILECODE1","MOBILENUMBER2","PASSPORTNUMBER1",
            "PERSONAL_EMAIL2","OFFICE_EMAIL2",
            "RESI_ADDRESS11","RESI_ADDRESS21","RESI_ADDRESS31",
            "RESI_TEL_CODE1","RESI_TEL_NUM1",
            "CUSTOMER_PASSPORTNO","EMIRATES_ID",
            "CUSTOMERNAME11","CUSTOMERNAME21","CUSTOMERNAME31",
            "NATIONALITY11","BRANCH_CODE1","TRADE_LIC_NO","RECORD_STAT",
            "CUSTOMER_TYPE","APPLICATION_ID",
            "ACTUAL_BOUNCE","ADR_AMT","ADR_DATE","APP_OFFER_DATE","APP_STRAT_DATE",
            "CONT_STAT","CURR_ACC_BAL","CURR_RATE","DELINQ_BUCKET","DELINQ_STAT",
            "EMI_AMOUNT","EMI_DATE","EMI_FREQUENCY","IJARA_BOOKED","IJARA_BOOKED_DATE",
            "INSTALL_NO","LAND_REG","MATURITY_DATE","PDC_AMOUNT","PDC_NO",
            "PRIN_OS","REM_TENOR_CURR","REPAY_TENOR","RETURN_VALUE","TBR_CURR",
            "TOT_INST_NO","TOTAL_BOUNCE","DQ_TYPE","VALUE_DATE",
            "CONTRACT_STATUS","MASTER_DEV_ID","INSTALLMENT_NO","DR_SETL_AC",
            "contract_ref_no","CIF",
            "Employment_Type","Name_Of_Employer","Add_Of_Employer","Designation",
            "Repayment_Mode","Repayment_AC","Repayment_Bank","Land_Regestration",
            "Alternate_Cont_No","H_Country_Phone"
        };

        // ═══════════════════════════════════════════════════════════════════════
        // PUBLIC STATIC ENTRY POINT
        // Call this from any C# code that already has a DataSet:
        //
        //   DataSet ds = /* your source: SP result, adapter fill, etc. */;
        //   int rows = ServiceRequestData.InsertFromDataSet(ds, connStr, "UserID");
        //
        // The DataSet may contain any DataTable as Tables[0].
        // Columns are mapped by name (case-insensitive).
        // "ServiceRequestNo" is automatically aliased to "SRNo" (the PK).
        // All values are converted to string before insert (table is NVARCHAR(500)).
        // ═══════════════════════════════════════════════════════════════════════
        public static int InsertFromDataSet(DataSet ds, string connStr, string importedBy = "SYSTEM")
        {
            if (ds == null || ds.Tables.Count == 0)
                throw new ArgumentException("DataSet is null or contains no tables.");

            int colsMatched, colsSkipped;
            DataTable tvpTable = ConvertDataSetToTvpTable(ds, out colsMatched, out colsSkipped);

            if (tvpTable.Rows.Count == 0)
                return 0;

            return ExecuteInsertProc(tvpTable, connStr, importedBy);
        }

        // ═══════════════════════════════════════════════════════════════════════
        // CORE CONVERSION  DataSet -> TVP DataTable
        //
        // Takes the first DataTable from the DataSet, maps its columns to the
        // TVP schema (all NVARCHAR(500)), and returns a new DataTable that can
        // be passed directly as a Structured SqlParameter.
        //
        // colsMatched : number of source columns successfully mapped to the TVP
        // colsSkipped : number of source columns with no matching TVP column
        // ═══════════════════════════════════════════════════════════════════════
        public static DataTable ConvertDataSetToTvpTable(
            DataSet ds,
            out int colsMatched,
            out int colsSkipped)
        {
            // 1. Build the empty TVP DataTable (all string columns, matching the TVP type)
            DataTable tvp = new DataTable("TVP_ServiceRequest_Data");
            foreach (string col in TvpColumns)
                tvp.Columns.Add(col, typeof(string));

            // 2. Build a fast lookup:  source column name (upper) -> TVP column index
            Dictionary<string, int> lookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < TvpColumns.Length; i++)
                lookup[TvpColumns[i]] = i;
            // Accept "ServiceRequestNo" as an alias for the PK column "SRNo"
            lookup["SERVICEREQUESTNO"] = lookup["SRNO"];

            // 3. Resolve the source DataTable (Tables[0])
            DataTable source = ds.Tables[0];

            // 4. Pre-compute per-source-column mapping so we only iterate the
            //    lookup once rather than on every row
            int srcCount = source.Columns.Count;
            int[] colMap = new int[srcCount];   // -1 = no matching TVP column
            int matched = 0, skipped = 0;

            for (int c = 0; c < srcCount; c++)
            {
                string srcName = source.Columns[c].ColumnName;
                int tvpIdx;
                if (lookup.TryGetValue(srcName, out tvpIdx))
                {
                    colMap[c] = tvpIdx;
                    matched++;
                }
                else
                {
                    colMap[c] = -1;
                    skipped++;
                }
            }

            colsMatched = matched;
            colsSkipped = skipped;

            // 5. Copy rows: convert every value to string (DBNull -> empty string)
            foreach (DataRow srcRow in source.Rows)
            {
                DataRow tvpRow = tvp.NewRow();
                for (int c = 0; c < srcCount; c++)
                {
                    if (colMap[c] < 0) continue;
                    object val = srcRow[c];
                    tvpRow[colMap[c]] = (val == null || val == DBNull.Value)
                        ? string.Empty
                        : Convert.ToString(val);
                }
                tvp.Rows.Add(tvpRow);
            }

            return tvp;
        }

        // ───────────────────────────────────────────────────────────────────────
        // Calls Proc_ServiceRequest_Data_Insert with the prepared TVP DataTable.
        // Returns the number of rows inserted/updated (@@ROWCOUNT from MERGE).
        // ───────────────────────────────────────────────────────────────────────
        private static int ExecuteInsertProc(DataTable tvpTable, string connStr, string importedBy)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("Proc_ServiceRequest_Data_Insert", conn))
                {
                    cmd.CommandType    = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 300;

                    SqlParameter pData = cmd.Parameters.AddWithValue("@Data", tvpTable);
                    pData.SqlDbType = SqlDbType.Structured;
                    pData.TypeName  = "dbo.TVP_ServiceRequest_Data";

                    cmd.Parameters.AddWithValue("@ImportedBy", importedBy ?? "SYSTEM");

                    SqlParameter pOut = cmd.Parameters.Add("@RowsAffected", SqlDbType.Int);
                    pOut.Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    return pOut.Value == DBNull.Value ? 0 : Convert.ToInt32(pOut.Value);
                }
            }
        }

        // ═══════════════════════════════════════════════════════════════════════
        // PAGE EVENTS  (interactive test harness)
        // ═══════════════════════════════════════════════════════════════════════

        protected void Page_Load(object sender, EventArgs e) { }

        // ── Load from stored procedure (real DataSet source) ─────────────────
        protected void btnLoadFromProc_Click(object sender, EventArgs e)
        {
            string proc = (txtSourceProc.Text ?? "").Trim();
            if (string.IsNullOrEmpty(proc))
            {
                ShowMessage("Enter the stored procedure name that returns your data.", false);
                return;
            }

            try
            {
                // Execute the source SP -> fill a DataSet
                DataSet ds = new DataSet();
                using (SqlConnection conn = new SqlConnection(ConnStr))
                using (SqlCommand cmd = new SqlCommand(proc, conn))
                {
                    cmd.CommandType    = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 120;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    conn.Open();
                    da.Fill(ds);
                }

                if (ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
                {
                    ShowMessage("The stored procedure returned no rows.", false);
                    return;
                }

                LoadDataSetIntoSession(ds);
            }
            catch (Exception ex)
            {
                ShowMessage("Error executing source procedure: " + ex.Message, false);
            }
        }

        // ── Load a 2-row sample DataSet (demo / smoke-test) ──────────────────
        protected void btnLoadSample_Click(object sender, EventArgs e)
        {
            DataSet ds = BuildSampleDataSet();
            LoadDataSetIntoSession(ds);
        }

        // ── Insert cached TVP DataTable -> database ───────────────────────────
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            DataTable tvp = Session["SRD_TvpTable"] as DataTable;
            if (tvp == null || tvp.Rows.Count == 0)
            {
                ShowMessage("No data loaded. Use 'Load DataSet from Proc' or 'Load Sample DataSet' first.", false);
                return;
            }

            try
            {
                string user = Session["UserID"] != null ? Session["UserID"].ToString() : "SYSTEM";
                int rowsAffected = ExecuteInsertProc(tvp, ConnStr, user);

                Session.Remove("SRD_TvpTable");

                lblResult.Text = string.Format(
                    "<span class='msg-success'>&#10003; Import complete. " +
                    "<strong>{0:N0}</strong> row(s) inserted / updated in ServiceRequest_Data.</span>",
                    rowsAffected);
                pnlResult.Visible  = true;
                pnlPreview.Visible = false;
                ShowMessage("Import successful: " + rowsAffected.ToString("N0") + " row(s) processed.", true);
            }
            catch (Exception ex)
            {
                ShowMessage("Insert failed: " + ex.Message, false);
            }
        }

        // ── Clear ─────────────────────────────────────────────────────────────
        protected void btnClear_Click(object sender, EventArgs e)
        {
            Session.Remove("SRD_TvpTable");
            pnlPreview.Visible = false;
            pnlResult.Visible  = false;
            pnlMessage.Visible = false;
            txtSearchSRNo.Text = txtSearchAppId.Text =
                txtSearchName.Text = txtSearchLeadNo.Text = "";
            gvSearch.DataSource = null;
            gvSearch.DataBind();
        }

        // ═══════════════════════════════════════════════════════════════════════
        // SEARCH / VIEW EXISTING RECORDS
        // ═══════════════════════════════════════════════════════════════════════

        protected void btnSearch_Click(object sender, EventArgs e) { LoadSearch(); }

        protected void gvSearch_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvSearch.PageIndex = e.NewPageIndex;
            LoadSearch();
        }

        private void LoadSearch()
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_ServiceRequest_Data_Select", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SRNo",          NullIfEmpty(txtSearchSRNo.Text));
                cmd.Parameters.AddWithValue("@ApplicationID", NullIfEmpty(txtSearchAppId.Text));
                cmd.Parameters.AddWithValue("@CustomerName",  NullIfEmpty(txtSearchName.Text));
                cmd.Parameters.AddWithValue("@LeadNo",        NullIfEmpty(txtSearchLeadNo.Text));

                DataTable dt = new DataTable();
                conn.Open();
                new SqlDataAdapter(cmd).Fill(dt);

                gvSearch.DataSource = dt;
                gvSearch.DataBind();
            }
        }

        // ═══════════════════════════════════════════════════════════════════════
        // PRIVATE HELPERS
        // ═══════════════════════════════════════════════════════════════════════

        // Convert DataSet, cache TVP DataTable in Session, bind preview grid.
        private void LoadDataSetIntoSession(DataSet ds)
        {
            int colsMatched, colsSkipped;
            DataTable tvp = ConvertDataSetToTvpTable(ds, out colsMatched, out colsSkipped);

            if (tvp.Rows.Count == 0)
            {
                ShowMessage("DataSet converted but contains zero rows.", false);
                return;
            }

            Session["SRD_TvpTable"] = tvp;

            lblTotalRows.Text   = tvp.Rows.Count.ToString("N0");
            lblColsMatched.Text = colsMatched.ToString();
            lblColsSkipped.Text = colsSkipped.ToString();

            // Preview: first 10 rows, key columns only
            DataTable display = BuildDisplayTable(tvp, 10);
            gvPreview.DataSource = display;
            gvPreview.DataBind();

            pnlPreview.Visible = true;
            pnlResult.Visible  = false;
            ShowMessage(string.Format(
                "DataSet converted: {0:N0} row(s) ready - {1} column(s) matched, {2} skipped.",
                tvp.Rows.Count, colsMatched, colsSkipped), true);
        }

        // Returns a display DataTable with key columns only (max maxRows rows).
        private static DataTable BuildDisplayTable(DataTable source, int maxRows = 10)
        {
            string[] keyCols = {
                "SRNo","APPLICATIONID","CUSTOMERNAME1","CUSTOMERID",
                "EMIRATES_ID","LEAD_NO","PRODUCT_TYPE","FINANCEVALUE",
                "CURRENTSTATUS","PROPERTYNAME","DEVELOPER"
            };
            DataTable display = new DataTable();
            foreach (string col in keyCols)
                if (source.Columns.Contains(col))
                    display.Columns.Add(col, typeof(string));

            int limit = Math.Min(maxRows, source.Rows.Count);
            for (int i = 0; i < limit; i++)
            {
                DataRow dr = display.NewRow();
                foreach (DataColumn dc in display.Columns)
                    dr[dc.ColumnName] = source.Rows[i][dc.ColumnName];
                display.Rows.Add(dr);
            }
            return display;
        }

        // Builds a 2-row sample DataSet for smoke-testing.
        private static DataSet BuildSampleDataSet()
        {
            DataTable t = new DataTable("ServiceRequestData");
            // Only include a representative subset of columns for the sample
            string[] sampleCols = {
                "ServiceRequestNo","APPLICATIONID","CUSTOMERID",
                "CUSTOMERNAME1","NATIONALITY1","PASSPORTNUMBER",
                "DEVELOPER","PROPERTYNAME","PROPERTYTYPE",
                "FINANCEVALUE","EMPLOYMENTTYPE","CURRENTSTATUS",
                "PRODUCT_TYPE","LEAD_NO","EMIRATES_ID"
            };
            foreach (string c in sampleCols)
                t.Columns.Add(c, typeof(string));

            t.Rows.Add("SAMPLE001","APP001","CUST001",
                "John Sample","UAE","P12345678",
                "Sample Developer","Sample Villa","VILLA",
                "500000","Salaried","OPS_LODGMENT",
                "HF48","LEAD001","784-1990-1234567-1");

            t.Rows.Add("SAMPLE002","APP002","CUST002",
                "Jane Demo","UAE","P87654321",
                "Demo Developer","Demo Apartment","APARTMENT",
                "750000","Self-Employed","OPS_PMU",
                "HF48","LEAD002","784-1985-9876543-2");

            DataSet ds = new DataSet();
            ds.Tables.Add(t);
            return ds;
        }

        private void ShowMessage(string msg, bool success)
        {
            pnlMessage.Visible  = true;
            lblMessage.Text     = Server.HtmlEncode(msg);
            pnlMessage.CssClass = success ? "msg-success" : "msg-error";
        }

        private static object NullIfEmpty(string val)
        {
            return string.IsNullOrWhiteSpace(val) ? (object)DBNull.Value : val.Trim();
        }
    }
}
