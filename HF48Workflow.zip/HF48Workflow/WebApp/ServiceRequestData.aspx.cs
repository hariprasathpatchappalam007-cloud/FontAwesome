using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class ServiceRequestData : Page
    {
        // ── Connection ──────────────────────────────────────────────────────────
        private string ConnStr =>
            ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString;

        // ── Exact column names in TVP_ServiceRequest_Data ───────────────────────
        // "ServiceRequestNo" (CSV header) is mapped to "SRNo" (DB column).
        private static readonly string[] TvpColumns = new[]
        {
            "SRNo","MOBILENUMBER","PERSONAL_EMAIL","OFFICE_EMAIL",
            "APPLICATIONID","CUSTOMERID",
            "CUSTOMERNAME1","CUSTOMERNAME2","CUSTOMERNAME3","CUSTOMERNAME4",
            "NATIONALITY1","NATIONALITY2","NATIONALITY3","NATIONALITY4",
            "PASSPORTNUMBER",
            "DATEOFBIRTH1","DATEOFBIRTH2","DATEOFBIRTH3","DATEOFBIRTH4",
            "RESIDENCYTYPE",
            "DEVELOPER","PROPERTYNAME","PROPERTYDETAILS","PROPERTYTYPE",
            "ORIGINALPROPERTYVALUE","APPRAISEDPROPERTYVALUE","BUILTUPAREA",
            "ISTISNATENOR","IJARATENOR",
            "EMPLOYMENTTYPE",
            "INCOME1","INCOME2","INCOME3","INCOME4",
            "FINANCEVALUE","DOWNPAYMENT","DSR","FTV","INSTALLMENTAMOUNT",
            "CORPORATECATEGORY",
            "CURRENTEMPLOYER1","CURRENTEMPLOYER2","CURRENTEMPLOYER3","CURRENTEMPLOYER4",
            "DESIGNATION1","DESIGNATION2","DESIGNATION3","DESIGNATION4",
            "CURRENTSTATUS","LASTUPDATED",
            "EDUCATION1","EDUCATION2","EDUCATION3","EDUCATION4",
            "FINALRATE","PREAPPROVALNO","PROFITFEE","PURCHASETYPE","SELLERNAME",
            "ISTISNAPRODUCT","IJARAPRODUCT",
            "MAILING_POBOX","MAILING_CITY","MAILING_COUNTRY",
            "MOBILECODE","MOBILENUMBER1",
            "RESI_TEL_CODE","RESI_TEL_NUM","OFFICE_TEL_CODE","OFFICE_TEL_NUM",
            "HC_TEL_CODE","HC_TEL_NUM",
            "PERSONAL_EMAIL1","OFFICE_EMAIL1","FAX_CODE","FAX_NUMBER",
            "RESI_ADDRESS1","RESI_ADDRESS2","RESI_ADDRESS3","RESI_ADDRESS4",
            "OFFICE_ADDRESS1","OFFICE_ADDRESS2","OFFICE_ADDRESS3",
            "MAKER_ID","MAKER_DT_STAMP","CHECKER_ID","CHECKER_DT_STAMP",
            "MOD_NO","WORKNAME","ALTERNATE_CONTACT","ALTERNATE_CONTACT_CODE",
            "HOMECOUNTRY_ADD1","HOMECOUNTRY_ADD2","HOMECOUNTRY_ADD3",
            "SEC_STATUS","CUSTOMERID2","CUSTOMERID3","CUSTOMERID4",
            "PASSPORTNUMBER2","PASSPORTNUMBER3","PASSPORTNUMBER4",
            "BRANCH_CODE","PROPERTY_PHASE","PROPERTYID",
            "OL_GENERATION_DATE","OL_ACCEPTANCE_DATE","APP_START_DATE",
            "SALES_OFFICER","CHANNEL","CASE_SUBMISSION_DATE",
            "SPREAD","CARPORATE_CATEGORY","PSF","EXPECTED_COMPLETION_DATE",
            "DELAYCHARGESYN","LEAD_NO","STAFF_DISCOUNT","STAFF_ID",
            "LIFEINSURANCECOVER","PORTFOLIO","PRODUCT_TYPE","MA_NAME","PRODUCT_SUB_TYPE",
            "STAFF_YN","MILESTONE_PROJECT","A_Value",
            "CUSTOMERID1","CUSTOMER_CATEGORY","CUST_SEGMENT","STAFF_YN1",
            "CURRENTSTATUS1","DATEOFBIRTH11","MAILING_COUNTRY1","MAILING_POBOX1",
            "MOBILECODE1","MOBILENUMBER2","PASSPORTNUMBER1",
            "PERSONAL_EMAIL2","OFFICE_EMAIL2",
            "RESI_ADDRESS11","RESI_ADDRESS21","RESI_ADDRESS31",
            "RESI_TEL_CODE1","RESI_TEL_NUM1",
            "CUSTOMER_PASSPORTNO","EMIRATES_ID",
            "CUSTOMERNAME11","CUSTOMERNAME21","CUSTOMERNAME31",
            "NATIONALITY11","BRANCH_CODE1","TRADE_LIC_NO","RECORD_STAT",
            "CUSTOMER_TYPE","APPLICATION_ID",
            "ACTUAL_BOUNCE","ADR_AMT","ADR_DATE","APP_OFFER_DATE","APP_STRAT_DATE",
            "CONT_STAT","CURR_ACC_BAL","CURR_RATE","DELINQ_BUCKET","DELINQ_STAT",
            "EMI_AMOUNT","EMI_DATE","EMI_FREQUENCY","IJARA_BOOKED","IJARA_BOOKED_DATE",
            "INSTALL_NO","LAND_REG","MATURITY_DATE","PDC_AMOUNT","PDC_NO",
            "PRIN_OS","REM_TENOR_CURR","REPAY_TENOR","RETURN_VALUE","TBR_CURR",
            "TOT_INST_NO","TOTAL_BOUNCE","DQ_TYPE","VALUE_DATE",
            "CONTRACT_STATUS","MASTER_DEV_ID","INSTALLMENT_NO","DR_SETL_AC",
            "contract_ref_no","CIF",
            "Employment_Type","Name_Of_Employer","Add_Of_Employer","Designation",
            "Repayment_Mode","Repayment_AC","Repayment_Bank","Land_Regestration",
            "Alternate_Cont_No","H_Country_Phone"
        };

        // ── Page Load ────────────────────────────────────────────────────────────
        protected void Page_Load(object sender, EventArgs e) { }

        // ── Step 1: Preview ──────────────────────────────────────────────────────
        protected void btnPreview_Click(object sender, EventArgs e)
        {
            if (fuCsv.PostedFile == null || fuCsv.PostedFile.ContentLength == 0)
            {
                ShowMessage("Please select a CSV file first.", false);
                return;
            }

            try
            {
                DataTable full = ParseCsv(fuCsv.PostedFile.InputStream,
                    out int colsMatched, out int colsSkipped);

                if (full.Rows.Count == 0)
                {
                    ShowMessage("The CSV file contains no data rows (only a header was found).", false);
                    return;
                }

                // Cache the full DataTable in Session for the Insert step
                Session["SRD_FullData"]    = full;
                Session["SRD_ColsMatched"] = colsMatched;
                Session["SRD_ColsSkipped"] = colsSkipped;

                // Show stats
                lblTotalRows.Text   = full.Rows.Count.ToString("N0");
                lblColsMatched.Text = colsMatched.ToString();
                lblColsSkipped.Text = colsSkipped.ToString();

                // Show first 10 rows in the preview grid (all TVP columns)
                DataTable preview = full.Clone();
                for (int i = 0; i < Math.Min(10, full.Rows.Count); i++)
                    preview.ImportRow(full.Rows[i]);

                // Only show key columns in the preview grid for readability
                DataTable display = BuildDisplayTable(preview);
                gvPreview.DataSource = display;
                gvPreview.DataBind();

                pnlPreview.Visible = true;
                pnlResult.Visible  = false;
                ShowMessage(
                    string.Format("CSV parsed: {0:N0} row(s) ready to import.", full.Rows.Count),
                    true);
            }
            catch (Exception ex)
            {
                ShowMessage("Error parsing CSV: " + ex.Message, false);
            }
        }

        // ── Step 2: Insert ───────────────────────────────────────────────────────
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            DataTable full = Session["SRD_FullData"] as DataTable;
            if (full == null || full.Rows.Count == 0)
            {
                ShowMessage("No data in memory. Please upload and preview the CSV first.", false);
                return;
            }

            try
            {
                int rowsAffected = 0;
                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("Proc_ServiceRequest_Data_Insert", conn))
                    {
                        cmd.CommandType    = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 300; // 5 minutes for large files

                        SqlParameter pData = cmd.Parameters.AddWithValue("@Data", full);
                        pData.SqlDbType = SqlDbType.Structured;
                        pData.TypeName  = "dbo.TVP_ServiceRequest_Data";

                        cmd.Parameters.AddWithValue("@ImportedBy",
                            (Session["UserID"] != null ? Session["UserID"].ToString() : "SYSTEM"));

                        SqlParameter pOut = cmd.Parameters.Add("@RowsAffected", SqlDbType.Int);
                        pOut.Direction = ParameterDirection.Output;

                        cmd.ExecuteNonQuery();
                        rowsAffected = pOut.Value == DBNull.Value ? 0 : Convert.ToInt32(pOut.Value);
                    }
                }

                // Clear cached data
                Session.Remove("SRD_FullData");

                lblResult.Text = string.Format(
                    "<span class='msg-success'>" +
                    "&#10003; Import complete. <strong>{0:N0}</strong> row(s) inserted / updated in ServiceRequest_Data." +
                    "</span>", rowsAffected);
                pnlResult.Visible = true;
                pnlPreview.Visible = false;
                ShowMessage("Import successful: " + rowsAffected.ToString("N0") + " row(s) processed.", true);
            }
            catch (Exception ex)
            {
                ShowMessage("Import failed: " + ex.Message, false);
            }
        }

        // ── Clear ────────────────────────────────────────────────────────────────
        protected void btnClear_Click(object sender, EventArgs e)
        {
            Session.Remove("SRD_FullData");
            pnlPreview.Visible = false;
            pnlResult.Visible  = false;
            pnlMessage.Visible = false;
            txtSearchSRNo.Text = txtSearchAppId.Text = txtSearchName.Text = txtSearchLeadNo.Text = "";
            gvSearch.DataSource = null;
            gvSearch.DataBind();
        }

        // ── Search / View ────────────────────────────────────────────────────────
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            LoadSearch();
        }

        protected void gvSearch_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvSearch.PageIndex = e.NewPageIndex;
            LoadSearch();
        }

        private void LoadSearch()
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_ServiceRequest_Data_Select", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SRNo",
                    NullIfEmpty(txtSearchSRNo.Text));
                cmd.Parameters.AddWithValue("@ApplicationID",
                    NullIfEmpty(txtSearchAppId.Text));
                cmd.Parameters.AddWithValue("@CustomerName",
                    NullIfEmpty(txtSearchName.Text));
                cmd.Parameters.AddWithValue("@LeadNo",
                    NullIfEmpty(txtSearchLeadNo.Text));

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvSearch.DataSource = dt;
                gvSearch.DataBind();
            }
        }

        // ── CSV Parsing ──────────────────────────────────────────────────────────
        // Builds a DataTable whose columns exactly match TVP_ServiceRequest_Data.
        // CSV header "ServiceRequestNo" is automatically mapped to "SRNo".
        private DataTable ParseCsv(Stream stream, out int colsMatched, out int colsSkipped)
        {
            // Build target DataTable (all string columns matching the TVP)
            DataTable dt = new DataTable();
            foreach (string col in TvpColumns)
                dt.Columns.Add(col, typeof(string));

            using (StreamReader reader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true))
            {
                string headerLine = reader.ReadLine();
                if (string.IsNullOrEmpty(headerLine))
                {
                    colsMatched = colsSkipped = 0;
                    return dt;
                }

                string[] csvHeaders = SplitCsvLine(headerLine);

                // Build column mapping: CSV index → DataTable column index (-1 = skip)
                int[] colMap = new int[csvHeaders.Length];
                int matched = 0, skipped = 0;

                // Build lookup: uppercase TVP column name → index in dt
                var tvpLookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < TvpColumns.Length; i++)
                    tvpLookup[TvpColumns[i]] = i;
                // Also add the CSV alias for the PK
                tvpLookup["SERVICEREQUESTNO"] = tvpLookup["SRNO"];

                for (int i = 0; i < csvHeaders.Length; i++)
                {
                    string h = csvHeaders[i].Trim();
                    if (tvpLookup.TryGetValue(h, out int dtIdx))
                    {
                        colMap[i] = dtIdx;
                        matched++;
                    }
                    else
                    {
                        colMap[i] = -1;
                        skipped++;
                    }
                }

                colsMatched = matched;
                colsSkipped = skipped;

                // Parse data rows
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    string[] values = SplitCsvLine(line);
                    DataRow row = dt.NewRow();
                    for (int i = 0; i < Math.Min(values.Length, csvHeaders.Length); i++)
                    {
                        if (colMap[i] >= 0)
                            row[colMap[i]] = values[i];
                    }
                    dt.Rows.Add(row);
                }
            }
            return dt;
        }

        // Build a display-only DataTable with key columns (for the preview grid)
        private static DataTable BuildDisplayTable(DataTable source)
        {
            string[] keyCols = {
                "SRNo","APPLICATIONID","CUSTOMERNAME1","CUSTOMERID",
                "EMIRATES_ID","LEAD_NO","PRODUCT_TYPE","FINANCEVALUE",
                "CURRENTSTATUS","PROPERTYNAME","DEVELOPER"
            };
            DataTable display = new DataTable();
            foreach (string col in keyCols)
            {
                if (source.Columns.Contains(col))
                    display.Columns.Add(col, typeof(string));
            }
            foreach (DataRow r in source.Rows)
            {
                DataRow dr = display.NewRow();
                foreach (DataColumn dc in display.Columns)
                    dr[dc.ColumnName] = r[dc.ColumnName];
                display.Rows.Add(dr);
            }
            return display;
        }

        // RFC-4180 CSV line splitter (handles quoted fields with embedded commas)
        private static string[] SplitCsvLine(string line)
        {
            var result = new List<string>();
            bool inQ = false;
            var sb = new StringBuilder();
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    if (inQ && i + 1 < line.Length && line[i + 1] == '"')
                    { sb.Append('"'); i++; }
                    else inQ = !inQ;
                }
                else if (c == ',' && !inQ)
                { result.Add(sb.ToString()); sb.Clear(); }
                else
                    sb.Append(c);
            }
            result.Add(sb.ToString());
            return result.ToArray();
        }

        // ── Helpers ──────────────────────────────────────────────────────────────
        private void ShowMessage(string msg, bool success)
        {
            pnlMessage.Visible  = true;
            lblMessage.Text     = Server.HtmlEncode(msg);
            pnlMessage.CssClass = success ? "msg-success" : "msg-error";
        }

        private static object NullIfEmpty(string val) =>
            string.IsNullOrWhiteSpace(val) ? (object)DBNull.Value : val.Trim();
    }
}
