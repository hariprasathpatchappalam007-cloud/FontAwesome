using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class T24ContractDetail : Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                if (System.Web.HttpContext.Current.User != null &&
                    System.Web.HttpContext.Current.User.Identity != null &&
                    !string.IsNullOrEmpty(System.Web.HttpContext.Current.User.Identity.Name))
                    return System.Web.HttpContext.Current.User.Identity.Name;
                return "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        #region Step 2: Parse

        protected void btnParse_Click(object sender, EventArgs e)
        {
            string json = (txtResponseJson.Text ?? "").Trim();
            if (string.IsNullOrEmpty(json))
            {
                ShowMessage("Paste the service response JSON first.", false);
                return;
            }

            T24ContractResponse response;
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                ser.MaxJsonLength = int.MaxValue;
                response = ser.Deserialize<T24ContractResponse>(json);
            }
            catch (Exception ex)
            {
                ShowMessage("Could not parse JSON: " + ex.Message, false);
                pnlPreview.Visible = false;
                return;
            }

            if (response == null || response.Data == null || response.Data.financeInformation == null
                || response.Data.financeInformation.Count == 0)
            {
                ShowMessage("JSON parsed but no financeInformation rows were found.", false);
                pnlPreview.Visible = false;
                return;
            }

            // Cache parsed response + raw JSON for the Save step
            Session["T24_ParsedResponse"] = response;
            Session["T24_RawJson"] = json;

            string cif = (response.Data.customerInformation != null)
                ? response.Data.customerInformation.cif : null;

            lblParsedCif.Text        = string.IsNullOrEmpty(cif) ? "-" : cif;
            lblParsedCount.Text      = response.Data.financeInformation.Count.ToString();
            lblParsedApiStatus.Text  = BuildApiStatusSummary(response.APIStatus);

            // Build a display DataTable (typed dates/decimals for the grid)
            DataTable dt = BuildPreviewTable(response.Data.financeInformation);
            gvPreview.DataSource = dt;
            gvPreview.DataBind();

            pnlPreview.Visible = true;
            ShowMessage("Parsed " + response.Data.financeInformation.Count.ToString() +
                " finance information row(s). Review below, then click Save.", true);
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtContractID.Text = "";
            txtApplicationRefNo.Text = "";
            txtBranchCode.Text = "";
            txtResponseJson.Text = "";
            pnlPreview.Visible = false;
            pnlMessage.Visible = false;
            Session.Remove("T24_ParsedResponse");
            Session.Remove("T24_RawJson");
        }

        #endregion

        #region Step 3: Save

        protected void btnSave_Click(object sender, EventArgs e)
        {
            T24ContractResponse response = Session["T24_ParsedResponse"] as T24ContractResponse;
            string rawJson = Session["T24_RawJson"] as string;

            if (response == null || response.Data == null || response.Data.financeInformation == null
                || response.Data.financeInformation.Count == 0)
            {
                ShowMessage("No parsed data in memory. Please parse the response again before saving.", false);
                return;
            }

            string cif = (response.Data.customerInformation != null)
                ? response.Data.customerInformation.cif : null;

            T24ApiStatus apiStatus = response.APIStatus;
            string appStatusCode = null, appStatusMessage = null, appStatusDescription = null;
            if (apiStatus != null && apiStatus.appStatusDetails != null && apiStatus.appStatusDetails.Count > 0)
            {
                T24AppStatusDetail firstAppStatus = apiStatus.appStatusDetails[0];
                appStatusCode        = firstAppStatus.appStatusCode;
                appStatusMessage     = firstAppStatus.appStatusMessage;
                appStatusDescription = firstAppStatus.appStatusDescription;
            }

            int savedCount = 0;
            List<string> errors = new List<string>();

            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                conn.Open();
                for (int i = 0; i < response.Data.financeInformation.Count; i++)
                {
                    T24FinanceInfo fi = response.Data.financeInformation[i];

                    using (SqlCommand cmd = new SqlCommand("Proc_T24_ContractDetail_Insert", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ContractID", ValueOrDbNull(txtContractID.Text));
                        cmd.Parameters.AddWithValue("@ApplicationRefNo", ValueOrDbNull(txtApplicationRefNo.Text));
                        cmd.Parameters.AddWithValue("@BranchCode", ValueOrDbNull(txtBranchCode.Text));
                        cmd.Parameters.AddWithValue("@CIF", ValueOrDbNull(cif));

                        cmd.Parameters.AddWithValue("@ContractReferenceNumber", ValueOrDbNull(fi.contractReferenceNumber));
                        cmd.Parameters.AddWithValue("@UserReferenceNumber", ValueOrDbNull(fi.userReferenceNumber));
                        cmd.Parameters.AddWithValue("@FinanceCurrency", ValueOrDbNull(fi.financeCurrency));
                        cmd.Parameters.AddWithValue("@FinanceAmount", DecimalOrDbNull(fi.financeAmount));
                        cmd.Parameters.AddWithValue("@AccountNumber", ValueOrDbNull(fi.accountNumber));
                        cmd.Parameters.AddWithValue("@CurrentBalance", DecimalOrDbNull(fi.currentBalance));
                        cmd.Parameters.AddWithValue("@OutstandingBalanceAmount", DecimalOrDbNull(fi.outstandingBalanceAmount));
                        cmd.Parameters.AddWithValue("@ContractAmountPaid", DecimalOrDbNull(fi.contractAmountPaid));
                        cmd.Parameters.AddWithValue("@BalloonAmount", DecimalOrDbNull(fi.balloonAmount));
                        cmd.Parameters.AddWithValue("@BookingDate", DateOrDbNull(fi.bookingDate));
                        cmd.Parameters.AddWithValue("@ValueDate", DateOrDbNull(fi.valueDate));
                        cmd.Parameters.AddWithValue("@LatestActionDate", DateOrDbNull(fi.latestActionDate));
                        cmd.Parameters.AddWithValue("@MaturityDate", DateOrDbNull(fi.maturityDate));

                        string moduleCode = (fi.product != null) ? fi.product.moduleCode : null;
                        string productCode = (fi.product != null) ? fi.product.productCode : null;
                        cmd.Parameters.AddWithValue("@ModuleCode", ValueOrDbNull(moduleCode));
                        cmd.Parameters.AddWithValue("@ProductCode", ValueOrDbNull(productCode));

                        string contractStatus = (fi.statuses != null) ? fi.statuses.contractStatus : null;
                        string initiationStatus = (fi.statuses != null) ? fi.statuses.initiationStatus : null;
                        cmd.Parameters.AddWithValue("@ContractStatus", ValueOrDbNull(contractStatus));
                        cmd.Parameters.AddWithValue("@InitiationStatus", ValueOrDbNull(initiationStatus));

                        decimal? profitRate = (fi.profit != null) ? DecimalOrNull(fi.profit.profitRate) : null;
                        decimal? irr = (fi.profit != null) ? DecimalOrNull(fi.profit.internalRateOfReturn) : null;
                        cmd.Parameters.AddWithValue("@ProfitRate", profitRate.HasValue ? (object)profitRate.Value : DBNull.Value);
                        cmd.Parameters.AddWithValue("@InternalRateOfReturn", irr.HasValue ? (object)irr.Value : DBNull.Value);

                        if (apiStatus != null)
                        {
                            cmd.Parameters.AddWithValue("@APIStatusType", ValueOrDbNull(apiStatus.statusType));
                            cmd.Parameters.AddWithValue("@APIStatusIdentifier", ValueOrDbNull(apiStatus.identifier));
                            cmd.Parameters.AddWithValue("@APIStatusCode", ValueOrDbNull(apiStatus.statusCode));
                            cmd.Parameters.AddWithValue("@APIStatusMessage", ValueOrDbNull(apiStatus.statusMessage));
                            cmd.Parameters.AddWithValue("@APIStatusDescription", ValueOrDbNull(apiStatus.statusDescription));
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@APIStatusType", DBNull.Value);
                            cmd.Parameters.AddWithValue("@APIStatusIdentifier", DBNull.Value);
                            cmd.Parameters.AddWithValue("@APIStatusCode", DBNull.Value);
                            cmd.Parameters.AddWithValue("@APIStatusMessage", DBNull.Value);
                            cmd.Parameters.AddWithValue("@APIStatusDescription", DBNull.Value);
                        }

                        cmd.Parameters.AddWithValue("@AppStatusCode", ValueOrDbNull(appStatusCode));
                        cmd.Parameters.AddWithValue("@AppStatusMessage", ValueOrDbNull(appStatusMessage));
                        cmd.Parameters.AddWithValue("@AppStatusDescription", ValueOrDbNull(appStatusDescription));

                        cmd.Parameters.AddWithValue("@RawResponseJSON", ValueOrDbNull(rawJson));
                        cmd.Parameters.AddWithValue("@CreatedBy", CurrentUser);

                        SqlParameter pSrNo = cmd.Parameters.Add("@NewSRNo", SqlDbType.Int);
                        pSrNo.Direction = ParameterDirection.Output;
                        SqlParameter pStatus = cmd.Parameters.Add("@Status", SqlDbType.NVarChar, 50);
                        pStatus.Direction = ParameterDirection.Output;
                        SqlParameter pMessage = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                        pMessage.Direction = ParameterDirection.Output;

                        cmd.ExecuteNonQuery();

                        string status = Convert.ToString(pStatus.Value);
                        if (status == "SUCCESS")
                        {
                            savedCount++;
                        }
                        else
                        {
                            errors.Add("Row " + (i + 1).ToString() + ": " + Convert.ToString(pMessage.Value));
                        }
                    }
                }
            }

            if (errors.Count == 0)
            {
                ShowMessage("Saved " + savedCount.ToString() + " finance information row(s) to T24_Contract_Detail.", true);
                Session.Remove("T24_ParsedResponse");
                Session.Remove("T24_RawJson");
                pnlPreview.Visible = false;
                txtResponseJson.Text = "";
                LoadSearch();
            }
            else
            {
                ShowMessage("Saved " + savedCount.ToString() + " row(s); " + errors.Count.ToString() +
                    " row(s) failed: " + string.Join(" | ", errors.ToArray()), false);
            }
        }

        #endregion

        #region Search

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            LoadSearch();
        }

        protected void gvSearch_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvSearch.PageIndex = e.NewPageIndex;
            LoadSearch();
        }

        private void LoadSearch()
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_T24_ContractDetail_Select", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CIF", ValueOrDbNull(txtSearchCif.Text));
                cmd.Parameters.AddWithValue("@ApplicationRefNo", ValueOrDbNull(txtSearchAppRef.Text));
                cmd.Parameters.AddWithValue("@ContractReferenceNumber", ValueOrDbNull(txtSearchContractRef.Text));

                DataTable dt = new DataTable();
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);

                gvSearch.DataSource = dt;
                gvSearch.DataBind();
            }
        }

        #endregion

        #region Helpers

        private static DataTable BuildPreviewTable(List<T24FinanceInfo> rows)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ContractReferenceNumber", typeof(string));
            dt.Columns.Add("UserReferenceNumber", typeof(string));
            dt.Columns.Add("FinanceCurrency", typeof(string));
            dt.Columns.Add("FinanceAmount", typeof(decimal));
            dt.Columns.Add("CurrentBalance", typeof(decimal));
            dt.Columns.Add("OutstandingBalanceAmount", typeof(decimal));
            dt.Columns.Add("ModuleCode", typeof(string));
            dt.Columns.Add("ProductCode", typeof(string));
            dt.Columns.Add("ContractStatus", typeof(string));
            dt.Columns.Add("ProfitRate", typeof(decimal));
            dt.Columns.Add("BookingDate", typeof(DateTime));
            dt.Columns.Add("MaturityDate", typeof(DateTime));

            for (int i = 0; i < rows.Count; i++)
            {
                T24FinanceInfo fi = rows[i];
                DataRow row = dt.NewRow();
                row["ContractReferenceNumber"] = ValueOrDbNull(fi.contractReferenceNumber);
                row["UserReferenceNumber"]     = ValueOrDbNull(fi.userReferenceNumber);
                row["FinanceCurrency"]         = ValueOrDbNull(fi.financeCurrency);
                row["FinanceAmount"]           = DecimalOrDbNull(fi.financeAmount);
                row["CurrentBalance"]          = DecimalOrDbNull(fi.currentBalance);
                row["OutstandingBalanceAmount"] = DecimalOrDbNull(fi.outstandingBalanceAmount);
                row["ModuleCode"]  = (fi.product != null) ? ValueOrDbNull(fi.product.moduleCode) : (object)DBNull.Value;
                row["ProductCode"] = (fi.product != null) ? ValueOrDbNull(fi.product.productCode) : (object)DBNull.Value;
                row["ContractStatus"] = (fi.statuses != null) ? ValueOrDbNull(fi.statuses.contractStatus) : (object)DBNull.Value;
                row["ProfitRate"] = (fi.profit != null) ? DecimalOrDbNull(fi.profit.profitRate) : (object)DBNull.Value;
                row["BookingDate"]  = DateOrDbNull(fi.bookingDate);
                row["MaturityDate"] = DateOrDbNull(fi.maturityDate);
                dt.Rows.Add(row);
            }
            return dt;
        }

        private static string BuildApiStatusSummary(T24ApiStatus apiStatus)
        {
            if (apiStatus == null) return "(none)";
            string code = string.IsNullOrEmpty(apiStatus.statusCode) ? "-" : apiStatus.statusCode;
            string msg  = string.IsNullOrEmpty(apiStatus.statusMessage) ? "-" : apiStatus.statusMessage;
            return code + " / " + msg;
        }

        // yyyyMMdd string (T24 date format) -> DateTime, or DBNull if missing/invalid
        private static object DateOrDbNull(string t24Date)
        {
            if (string.IsNullOrEmpty(t24Date)) return DBNull.Value;
            DateTime parsed;
            if (DateTime.TryParseExact(t24Date.Trim(), "yyyyMMdd",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed))
                return parsed;
            return DBNull.Value;
        }

        private static object DecimalOrDbNull(string value)
        {
            decimal? d = DecimalOrNull(value);
            return d.HasValue ? (object)d.Value : DBNull.Value;
        }

        private static decimal? DecimalOrNull(string value)
        {
            if (string.IsNullOrEmpty(value)) return null;
            decimal parsed;
            if (decimal.TryParse(value.Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out parsed))
                return parsed;
            return null;
        }

        private static object ValueOrDbNull(string value)
        {
            return string.IsNullOrEmpty(value) ? (object)DBNull.Value : value.Trim();
        }

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible  = true;
            lblMessage.Text     = Server.HtmlEncode(message);
            pnlMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }

        #endregion
    }

    #region T24 Response DTOs
    // Property names deliberately match the JSON keys exactly (camelCase)
    // so JavaScriptSerializer can map them without custom converters.

    [Serializable]
    public class T24ContractResponse
    {
        public T24Data Data { get; set; }
        public T24ApiStatus APIStatus { get; set; }
    }

    [Serializable]
    public class T24Data
    {
        public T24CustomerInfo customerInformation { get; set; }
        public List<T24FinanceInfo> financeInformation { get; set; }
    }

    [Serializable]
    public class T24CustomerInfo
    {
        public string cif { get; set; }
    }

    [Serializable]
    public class T24FinanceInfo
    {
        public string contractReferenceNumber { get; set; }
        public string userReferenceNumber { get; set; }
        public string financeCurrency { get; set; }
        public string financeAmount { get; set; }
        public string accountNumber { get; set; }
        public string currentBalance { get; set; }
        public string outstandingBalanceAmount { get; set; }
        public string contractAmountPaid { get; set; }
        public string balloonAmount { get; set; }
        public string bookingDate { get; set; }
        public string valueDate { get; set; }
        public string latestActionDate { get; set; }
        public string maturityDate { get; set; }
        public T24Product product { get; set; }
        public T24Statuses statuses { get; set; }
        public T24Profit profit { get; set; }
    }

    [Serializable]
    public class T24Product
    {
        public string moduleCode { get; set; }
        public string productCode { get; set; }
    }

    [Serializable]
    public class T24Statuses
    {
        public string contractStatus { get; set; }
        public string initiationStatus { get; set; }
    }

    [Serializable]
    public class T24Profit
    {
        public string profitRate { get; set; }
        public string internalRateOfReturn { get; set; }
    }

    [Serializable]
    public class T24ApiStatus
    {
        public string statusType { get; set; }
        public string identifier { get; set; }
        public string statusCode { get; set; }
        public string statusMessage { get; set; }
        public string statusDescription { get; set; }
        public List<T24AppStatusDetail> appStatusDetails { get; set; }
    }

    [Serializable]
    public class T24AppStatusDetail
    {
        public string appStatusCode { get; set; }
        public string appStatusMessage { get; set; }
        public string appStatusDescription { get; set; }
    }
    #endregion
}
