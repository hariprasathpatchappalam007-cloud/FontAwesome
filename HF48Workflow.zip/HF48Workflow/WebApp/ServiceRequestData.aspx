<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ServiceRequestData.aspx.cs"
         Inherits="HF48Workflow.ServiceRequestData" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Service Request Data – DataSet Import</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; padding: 0; background: #ccccff; }
        .header { background: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 18px; }
        .panel-header { background: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; border-radius: 4px 4px 0 0; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 160px; font-weight: bold; font-size: 13px; color: #333; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-primary { background: #003366; color: white; }
        .btn-primary:hover { background: #004488; }
        .btn-success { background: #28a745; color: white; }
        .btn-success:hover { background: #218838; }
        .btn-info { background: #17a2b8; color: white; }
        .btn-info:hover { background: #138496; }
        .btn-secondary { background: #6c757d; color: white; }
        .msg-success { color: #155724; background: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error   { color: #721c24; background: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; }
        .gridview th { background: #507CD1; color: white; padding: 7px 10px; text-align: left; white-space: nowrap; }
        .gridview td { padding: 5px 10px; border-bottom: 1px solid #eee; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .gridview tr:nth-child(even) td { background: #EFF3FB; }
        .gridview tr:hover td { background: #f5f5f5; }
        .info-box { background: #fff3cd; border: 1px solid #ffc107; padding: 8px 12px; border-radius: 3px; margin-bottom: 10px; font-size: 12px; color: #856404; }
        .stat-bar { background: #e7f3ff; border: 1px solid #bee5eb; padding: 8px 14px; border-radius: 3px; font-size: 13px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <form id="form1" runat="server">

        <div class="header">
            <h1>Service Request Data</h1>
            <h2>DataSet &rarr; TVP &rarr; Proc_ServiceRequest_Data_Insert</h2>
        </div>

        <div class="container">

            <!-- Status message -->
            <asp:Panel ID="pnlMessage" runat="server" Visible="false">
                <asp:Label ID="lblMessage" runat="server" />
            </asp:Panel>

            <!-- ─── STEP 1: DataSet source ─── -->
            <div class="panel">
                <div class="panel-header">Step 1 &mdash; Provide DataSet</div>
                <div class="panel-body">
                    <div class="info-box">
                        The page receives a <strong>DataSet</strong> from your back-end code (e.g. the result of a stored
                        procedure, an adapter fill, or any data-access layer).<br />
                        Call <code>ServiceRequestData.InsertFromDataSet(yourDataSet, connStr, importedBy)</code>
                        directly from C# &mdash; no browser interaction required.<br />
                        Use the controls below to <strong>test</strong> the flow interactively: supply a stored procedure
                        name that returns data in the ServiceRequest schema, or click
                        <em>Load Sample DataSet</em> to demo with two generated rows.
                    </div>

                    <div class="form-group">
                        <label>Source Stored Proc:</label>
                        <asp:TextBox ID="txtSourceProc" runat="server" Width="320px"
                            placeholder="e.g. Proc_GetServiceRequestData" />
                        &nbsp;
                        <asp:Button ID="btnLoadFromProc" runat="server"
                            Text="Load DataSet from Proc"
                            CssClass="btn btn-primary" OnClick="btnLoadFromProc_Click" />
                    </div>

                    <div class="form-group">
                        <label>&nbsp;</label>
                        <asp:Button ID="btnLoadSample" runat="server"
                            Text="Load Sample DataSet (2 demo rows)"
                            CssClass="btn btn-info" OnClick="btnLoadSample_Click"
                            CausesValidation="false" />
                        &nbsp;
                        <asp:Button ID="btnClear" runat="server" Text="Clear"
                            CssClass="btn btn-secondary"
                            OnClick="btnClear_Click" CausesValidation="false" />
                    </div>
                </div>
            </div>

            <!-- ─── STEP 2: Preview ─── -->
            <asp:Panel ID="pnlPreview" runat="server" Visible="false" CssClass="panel">
                <div class="panel-header">Step 2 &mdash; Preview (showing first 10 rows)</div>
                <div class="panel-body">

                    <div class="stat-bar">
                        Total rows in file: <strong><asp:Label ID="lblTotalRows"   runat="server" Text="0" /></strong>
                        &nbsp;|&nbsp;
                        Columns matched:    <strong><asp:Label ID="lblColsMatched" runat="server" Text="0" /></strong>
                        &nbsp;|&nbsp;
                        Columns skipped (not in table):
                        <strong><asp:Label ID="lblColsSkipped" runat="server" Text="0" /></strong>
                    </div>

                    <div style="overflow-x:auto;">
                        <asp:GridView ID="gvPreview" runat="server" CssClass="gridview"
                            AutoGenerateColumns="True"
                            EmptyDataText="No data to preview." />
                    </div>

                    <div style="margin-top:12px;">
                        <asp:Button ID="btnInsert" runat="server" Text="&#9654; Insert All Rows into ServiceRequest_Data"
                            CssClass="btn btn-success" OnClick="btnInsert_Click"
                            OnClientClick="return confirm('Insert all rows into the database? Existing rows (same SRNo) will be updated.');" />
                    </div>
                </div>
            </asp:Panel>

            <!-- ─── STEP 3: Result ─── -->
            <asp:Panel ID="pnlResult" runat="server" Visible="false" CssClass="panel">
                <div class="panel-header">Step 3 &mdash; Import Result</div>
                <div class="panel-body">
                    <asp:Label ID="lblResult" runat="server" />
                </div>
            </asp:Panel>

            <!-- ─── Quick Search / View existing data ─── -->
            <div class="panel">
                <div class="panel-header">View Existing Records &mdash; Proc_ServiceRequest_Data_Select</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>SRNo / App ID:</label>
                        <asp:TextBox ID="txtSearchSRNo" runat="server" Width="160px" placeholder="SRNo..." />
                        &nbsp;
                        <asp:TextBox ID="txtSearchAppId" runat="server" Width="160px" placeholder="Application ID..." />
                        &nbsp;
                        <asp:TextBox ID="txtSearchName" runat="server" Width="200px" placeholder="Customer name..." />
                        &nbsp;
                        <asp:TextBox ID="txtSearchLeadNo" runat="server" Width="140px" placeholder="Lead No..." />
                        &nbsp;
                        <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-info"
                            OnClick="btnSearch_Click" />
                    </div>
                    <div style="overflow-x:auto;">
                        <asp:GridView ID="gvSearch" runat="server" CssClass="gridview"
                            AutoGenerateColumns="True"
                            EmptyDataText="No records found."
                            AllowPaging="True" PageSize="15"
                            OnPageIndexChanging="gvSearch_PageIndexChanging" />
                    </div>
                </div>
            </div>

        </div>
    </form>
</body>
</html>
