using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class HF48BulkPostponementChecker : Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                if (System.Web.HttpContext.Current.User != null &&
                    System.Web.HttpContext.Current.User.Identity != null &&
                    !string.IsNullOrEmpty(System.Web.HttpContext.Current.User.Identity.Name))
                    return System.Web.HttpContext.Current.User.Identity.Name;
                return "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                hfCheckerTab.Value = "Pending";
                LoadPending();
                LoadHistory();
                ApplyCheckerTabVisibility();
            }
        }

        protected void lnkCheckerTabPending_Click(object sender, EventArgs e)
        {
            hfCheckerTab.Value = "Pending";
            LoadPending();
            ApplyCheckerTabVisibility();
        }

        protected void lnkCheckerTabAction_Click(object sender, EventArgs e)
        {
            hfCheckerTab.Value = "Action";
            ApplyCheckerTabVisibility();
        }

        protected void lnkCheckerTabHistory_Click(object sender, EventArgs e)
        {
            hfCheckerTab.Value = "History";
            LoadHistory();
            ApplyCheckerTabVisibility();
        }

        private void ApplyCheckerTabVisibility()
        {
            string tab = hfCheckerTab.Value ?? "Pending";
            bool isPending = tab == "Pending";
            bool isAction = tab == "Action";
            bool isHistory = tab == "History";

            pnlPendingTab.Visible = isPending;
            pnlActionTab.Visible = isAction;
            pnlHistoryTab.Visible = isHistory;

            lnkCheckerTabPending.CssClass = isPending ? "tab active" : "tab";
            lnkCheckerTabAction.CssClass = isAction ? "tab active" : "tab";
            lnkCheckerTabHistory.CssClass = isHistory ? "tab active" : "tab";
        }

        private void LoadPending()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Status", "Pending Approval");
            });
            gvPending.DataSource = dt;
            gvPending.DataBind();
        }

        protected void gvPending_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ViewRequest")
            {
                int reqId;
                if (!int.TryParse(Convert.ToString(e.CommandArgument), out reqId))
                {
                    ShowMessage("Invalid Request ID.", false);
                    return;
                }
                LoadDetail(reqId);
                hfCheckerTab.Value = "Action";
                ApplyCheckerTabVisibility();
            }
        }

        private void LoadDetail(int requestId)
        {
            DataTable header = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Status", "Pending Approval");
            });

            DataRow hRow = null;
            foreach (DataRow r in header.Rows)
            {
                if (Convert.ToInt32(r["RequestID"]) == requestId)
                {
                    hRow = r;
                    break;
                }
            }

            if (hRow == null)
            {
                ShowMessage("Request is no longer pending.", false);
                LoadPending();
                LoadHistory();
                return;
            }

            hfSelectedRequestId.Value = requestId.ToString();
            hfSelectedRequestType.Value = Convert.ToString(hRow["RequestType"]);
            lblReqId.Text = requestId.ToString();
            lblReqType.Text = " - " + Convert.ToString(hRow["RequestType"]);
            lblReqProject.Text = Convert.ToString(hRow["Property_ProjectName"]);
            lblReqMaker.Text = Convert.ToString(hRow["MakerUser"]);
            lblReqShift.Text = Convert.ToString(hRow["ShiftDays"]);
            lblReqReason.Text = Server.HtmlEncode(Convert.ToString(hRow["Reason"]));
            txtCheckerRemarks.Text = "";

            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequestDetail", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@RequestID", requestId);
            });
            gvDetail.DataSource = dt;
            gvDetail.DataBind();

            DataTable docs = ExecuteReader("Proc_HF48_BulkPostpone_GetDocs", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@DraftID", DBNull.Value);
                c.Parameters.AddWithValue("@RequestID", requestId);
            });
            rptDocs.DataSource = docs;
            rptDocs.DataBind();
            lblNoDocs.Visible = docs.Rows.Count == 0;
            rptDocs.Visible = docs.Rows.Count > 0;
        }

        protected void gvDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                int grp = 0;
                int.TryParse(Convert.ToString(DataBinder.Eval(e.Row.DataItem, "GroupIndex")), out grp);
                e.Row.CssClass = "grp-" + (((grp - 1) % 6) + 1);
            }
        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            int requestId = ParseSelectedRequestId();
            if (requestId == 0) return;

            bool isPostpone = hfSelectedRequestType.Value == "Postpone";
            string approveProc = isPostpone ? "Proc_HF48_PostponeNoHold_Approve" : "Proc_HF48_BulkPostpone_Approve";

            string status;
            string message;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(approveProc, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestID", requestId);
                cmd.Parameters.AddWithValue("@CheckerUser", CurrentUser);
                cmd.Parameters.AddWithValue("@CheckerRemarks", string.IsNullOrEmpty(txtCheckerRemarks.Text) ? (object)DBNull.Value : txtCheckerRemarks.Text.Trim());

                SqlParameter pSt = cmd.Parameters.Add("@Status", SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();
                status = Convert.ToString(pSt.Value);
                message = Convert.ToString(pMs.Value);
            }

            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS")
            {
                hfSelectedRequestId.Value = "";
                hfSelectedRequestType.Value = "";
                hfCheckerTab.Value = "Pending";
                LoadPending();
                LoadHistory();
                ApplyCheckerTabVisibility();
            }
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            int requestId = ParseSelectedRequestId();
            if (requestId == 0) return;

            if (string.IsNullOrEmpty((txtCheckerRemarks.Text ?? "").Trim()))
            {
                ShowMessage("Rejection requires Checker remarks.", false);
                return;
            }

            string status;
            string message;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_Reject", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestID", requestId);
                cmd.Parameters.AddWithValue("@CheckerUser", CurrentUser);
                cmd.Parameters.AddWithValue("@CheckerRemarks", txtCheckerRemarks.Text.Trim());

                SqlParameter pSt = cmd.Parameters.Add("@Status", SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();
                status = Convert.ToString(pSt.Value);
                message = Convert.ToString(pMs.Value);
            }

            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS")
            {
                hfSelectedRequestId.Value = "";
                hfSelectedRequestType.Value = "";
                hfCheckerTab.Value = "Pending";
                LoadPending();
                LoadHistory();
                ApplyCheckerTabVisibility();
            }
        }

        private int ParseSelectedRequestId()
        {
            int reqId;
            if (!int.TryParse(hfSelectedRequestId.Value, out reqId) || reqId == 0)
            {
                ShowMessage("No request selected.", false);
                return 0;
            }
            return reqId;
        }

        private void LoadHistory()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetRequests", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Status", DBNull.Value);
            });

            DataView dv = dt.DefaultView;
            dv.RowFilter = "Status <> 'Pending Approval'";
            gvHistory.DataSource = dv;
            gvHistory.DataBind();
        }

        protected void gvHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvHistory.PageIndex = e.NewPageIndex;
            LoadHistory();
        }

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            ShowMessage("Acting user set to: " + CurrentUser, true);
            LoadPending();
            LoadHistory();
            ApplyCheckerTabVisibility();
        }

        private DataTable ExecuteReader(string procName, Action<SqlCommand> bindParams)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (bindParams != null) bindParams(cmd);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    conn.Open();
                    da.Fill(dt);
                }
            }
            return dt;
        }

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible = true;
            lblMessage.Text = Server.HtmlEncode(message);
            pnlMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }
    }
}
