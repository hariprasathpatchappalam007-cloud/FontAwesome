<%@ WebHandler Language="C#" Class="HF48Workflow.BulkPostponeUploadHandler" %>

using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;

namespace HF48Workflow
{
    public class BulkPostponeUploadHandler : IHttpHandler
    {
        private const long MaxFileBytes = 20L * 1024 * 1024;   // 20 MB per file
        private static readonly string[] AllowedExt =
            { ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".txt" };

        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            var ser = new JavaScriptSerializer();

            try
            {
                string action = (context.Request["action"] ?? "upload").ToLowerInvariant();
                string draftId = context.Request["draftId"] ?? "";

                if (string.IsNullOrEmpty(draftId) || !IsCleanGuidLike(draftId))
                {
                    Write(context, ser, new { success = false, message = "Missing or invalid draftId." });
                    return;
                }

                if (action == "list")
                {
                    Write(context, ser, new { success = true, files = ListDocs(draftId, null) });
                    return;
                }

                if (action == "delete")
                {
                    int docId;
                    if (!int.TryParse(context.Request["docId"], out docId))
                    {
                        Write(context, ser, new { success = false, message = "Invalid docId." });
                        return;
                    }
                    DeleteDoc(docId, draftId);
                    Write(context, ser, new { success = true, files = ListDocs(draftId, null) });
                    return;
                }

                // default: upload
                if (context.Request.Files.Count == 0)
                {
                    Write(context, ser, new { success = false, message = "No file in request." });
                    return;
                }

                string baseFolder = context.Server.MapPath("~/Uploads/BulkPostpone/_draft/" + draftId);
                if (!Directory.Exists(baseFolder)) Directory.CreateDirectory(baseFolder);

                string user = (context.Session != null && context.Session["UserID"] != null)
                    ? context.Session["UserID"].ToString() : "SYSTEM";

                var saved = new System.Collections.Generic.List<object>();
                for (int i = 0; i < context.Request.Files.Count; i++)
                {
                    HttpPostedFile f = context.Request.Files[i];
                    if (f == null || f.ContentLength == 0) continue;

                    string original = Path.GetFileName(f.FileName);
                    string ext = Path.GetExtension(original).ToLowerInvariant();
                    if (Array.IndexOf(AllowedExt, ext) < 0)
                    {
                        saved.Add(new { name = original, success = false, message = "Extension not allowed." });
                        continue;
                    }
                    if (f.ContentLength > MaxFileBytes)
                    {
                        saved.Add(new { name = original, success = false, message = "File exceeds 20 MB." });
                        continue;
                    }

                    string safeName = SanitizeFileName(original);
                    string disk = Path.Combine(baseFolder, DateTime.Now.Ticks + "_" + safeName);
                    f.SaveAs(disk);

                    string relPath = "~/Uploads/BulkPostpone/_draft/" + draftId + "/" + Path.GetFileName(disk);

                    int docId = InsertDoc(draftId, original, relPath, f.ContentType, f.ContentLength, user);
                    saved.Add(new { docId = docId, name = original, size = f.ContentLength, success = true });
                }

                Write(context, ser, new { success = true, uploaded = saved, files = ListDocs(draftId, null) });
            }
            catch (Exception ex)
            {
                Write(context, ser, new { success = false, message = "Server error: " + ex.Message });
            }
        }

        private static int InsertDoc(string draftId, string originalName, string storedPath,
            string contentType, long size, string user)
        {
            using (SqlConnection conn = OpenConn())
            using (SqlCommand cmd = new SqlCommand(
                @"INSERT INTO HF48_BULK_POSTPONE_DOCS (DraftID, OriginalName, StoredPath, ContentType, SizeBytes, UploadedBy)
                  OUTPUT INSERTED.DocID
                  VALUES (@DraftID, @OriginalName, @StoredPath, @ContentType, @SizeBytes, @UploadedBy)", conn))
            {
                cmd.Parameters.AddWithValue("@DraftID", draftId);
                cmd.Parameters.AddWithValue("@OriginalName", originalName);
                cmd.Parameters.AddWithValue("@StoredPath", storedPath);
                cmd.Parameters.AddWithValue("@ContentType", (object)(contentType ?? "") ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@SizeBytes", size);
                cmd.Parameters.AddWithValue("@UploadedBy", user ?? "SYSTEM");
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        private static System.Collections.Generic.List<object> ListDocs(string draftId, int? requestId)
        {
            var list = new System.Collections.Generic.List<object>();
            using (SqlConnection conn = OpenConn())
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_GetDocs", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DraftID", (object)draftId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@RequestID", (object)requestId ?? DBNull.Value);
                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new
                        {
                            docId = Convert.ToInt32(r["DocID"]),
                            name = Convert.ToString(r["OriginalName"]),
                            size = r["SizeBytes"] == DBNull.Value ? 0 : Convert.ToInt64(r["SizeBytes"])
                        });
                    }
                }
            }
            return list;
        }

        private static void DeleteDoc(int docId, string draftId)
        {
            string disk = null;
            using (SqlConnection conn = OpenConn())
            {
                using (SqlCommand cmd = new SqlCommand(
                    @"SELECT StoredPath FROM HF48_BULK_POSTPONE_DOCS
                      WHERE DocID = @DocID AND DraftID = @DraftID AND RequestID IS NULL", conn))
                {
                    cmd.Parameters.AddWithValue("@DocID", docId);
                    cmd.Parameters.AddWithValue("@DraftID", draftId);
                    object o = cmd.ExecuteScalar();
                    if (o != null && o != DBNull.Value) disk = Convert.ToString(o);
                }
                if (disk == null) return;
                using (SqlCommand del = new SqlCommand(
                    @"DELETE FROM HF48_BULK_POSTPONE_DOCS
                      WHERE DocID = @DocID AND DraftID = @DraftID AND RequestID IS NULL", conn))
                {
                    del.Parameters.AddWithValue("@DocID", docId);
                    del.Parameters.AddWithValue("@DraftID", draftId);
                    del.ExecuteNonQuery();
                }
            }
            try
            {
                string physical = HttpContext.Current.Server.MapPath(disk);
                if (File.Exists(physical)) File.Delete(physical);
            }
            catch { }
        }

        private static SqlConnection OpenConn()
        {
            SqlConnection c = new SqlConnection(ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString);
            c.Open();
            return c;
        }

        private static void Write(HttpContext ctx, JavaScriptSerializer ser, object payload)
        {
            ctx.Response.Write(ser.Serialize(payload));
        }

        private static bool IsCleanGuidLike(string s)
        {
            // accept simple GUID/hex/dash strings only — no path traversal
            if (string.IsNullOrEmpty(s) || s.Length > 64) return false;
            foreach (char c in s)
            {
                if (!(char.IsLetterOrDigit(c) || c == '-' || c == '_')) return false;
            }
            return true;
        }

        private static string SanitizeFileName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "file";
            char[] invalid = Path.GetInvalidFileNameChars();
            foreach (char c in invalid) name = name.Replace(c, '_');
            return name;
        }
    }
}
