using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class HF48DisbursementMonitor : System.Web.UI.Page
    {
        private const string TabDisbursements = "Disbursements";
        private const string TabTasks = "Tasks";
        private const string TabAudit = "Audit";

        // Connection string from Web.config
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        // Current logged-in user (adjust based on your auth mechanism)
        private string CurrentUser
        {
            get
            {
                if (Session["UserID"] != null)
                    return Session["UserID"].ToString();
                return System.Web.HttpContext.Current.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                hfActiveTab.Value = TabDisbursements;
                LoadDisbursements();
                LoadOpenTasks();
                LoadAuditLog("");
            }

            ApplyActiveTabVisibility();
        }

        #region Data Loading

        private void LoadDisbursements()
        {
            LoadDisbursements("", "", "", "", null, null, "");
        }

        private void LoadDisbursements(string appRefNo, string leadNo, string developerName,
            string projectName, DateTime? dateFrom, DateTime? dateTo, string tier)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_Get_Disbursements", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefNo) ? (object)DBNull.Value : appRefNo);
                cmd.Parameters.AddWithValue("@LeadNo", string.IsNullOrEmpty(leadNo) ? (object)DBNull.Value : leadNo);
                cmd.Parameters.AddWithValue("@DeveloperName", string.IsNullOrEmpty(developerName) ? (object)DBNull.Value : developerName);
                cmd.Parameters.AddWithValue("@ProjectName", string.IsNullOrEmpty(projectName) ? (object)DBNull.Value : projectName);
                cmd.Parameters.AddWithValue("@DateFrom", dateFrom.HasValue ? (object)dateFrom.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@DateTo", dateTo.HasValue ? (object)dateTo.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@Tier", string.IsNullOrEmpty(tier) ? (object)DBNull.Value : tier);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);
                BindGridWithSafePage(gvDisbursements, dt);
            }
        }

        private void LoadOpenTasks()
        {
            LoadOpenTasks(txtTaskAppRefNo.Text.Trim(), txtTaskCaseRefNo.Text.Trim(), ddlTaskType.SelectedValue, ddlTaskStatus.SelectedValue);
        }

        private void LoadOpenTasks(string appRefNo, string caseRefNo, string taskType, string status)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_Get_OpenTasks", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                DataView dv = dt.DefaultView;
                dv.RowFilter = BuildTasksFilterExpression(appRefNo, caseRefNo, taskType, status);

                BindGridWithSafePage(gvTasks, dv);
            }
        }

        private void LoadAuditLog(string appRefNo)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_Get_AuditLog", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefNo) ? (object)DBNull.Value : appRefNo);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                BindGridWithSafePage(gvAuditLog, dt);
            }
        }

        #endregion

        #region Search & Filter Events

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabDisbursements);
            gvDisbursements.PageIndex = 0;

            DateTime? dateFrom = null;
            DateTime? dateTo = null;

            if (!string.IsNullOrEmpty(txtDateFrom.Text))
                dateFrom = DateTime.Parse(txtDateFrom.Text);
            if (!string.IsNullOrEmpty(txtDateTo.Text))
                dateTo = DateTime.Parse(txtDateTo.Text);

            LoadDisbursements(
                txtAppRefNo.Text.Trim(),
                txtLeadNo.Text.Trim(),
                txtDeveloperName.Text.Trim(),
                txtProjectName.Text.Trim(),
                dateFrom,
                dateTo,
                ddlTier.SelectedValue
            );
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabDisbursements);

            txtAppRefNo.Text = "";
            txtLeadNo.Text = "";
            txtDeveloperName.Text = "";
            txtProjectName.Text = "";
            txtDateFrom.Text = "";
            txtDateTo.Text = "";
            ddlTier.SelectedIndex = 0;
            gvDisbursements.PageIndex = 0;
            LoadDisbursements();
        }

        protected void btnAuditSearch_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabAudit);
            gvAuditLog.PageIndex = 0;
            LoadAuditLog(txtAuditAppNo.Text.Trim());
        }

        protected void btnAuditAll_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabAudit);
            txtAuditAppNo.Text = "";
            gvAuditLog.PageIndex = 0;
            LoadAuditLog("");
        }

        protected void btnTaskFilter_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabTasks);
            gvTasks.PageIndex = 0;
            LoadOpenTasks();
        }

        protected void btnTaskClear_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabTasks);
            txtTaskAppRefNo.Text = "";
            txtTaskCaseRefNo.Text = "";
            ddlTaskType.SelectedIndex = 0;
            ddlTaskStatus.SelectedIndex = 0;
            gvTasks.PageIndex = 0;
            LoadOpenTasks();
        }

        #endregion

        #region GridView Paging

        protected void gvDisbursements_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            SetActiveTab(TabDisbursements);
            gvDisbursements.PageIndex = e.NewPageIndex;

            DateTime? dateFrom = null;
            DateTime? dateTo = null;

            if (!string.IsNullOrEmpty(txtDateFrom.Text))
                dateFrom = DateTime.Parse(txtDateFrom.Text);
            if (!string.IsNullOrEmpty(txtDateTo.Text))
                dateTo = DateTime.Parse(txtDateTo.Text);

            LoadDisbursements(
                txtAppRefNo.Text.Trim(),
                txtLeadNo.Text.Trim(),
                txtDeveloperName.Text.Trim(),
                txtProjectName.Text.Trim(),
                dateFrom,
                dateTo,
                ddlTier.SelectedValue
            );
        }

        protected void gvTasks_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            SetActiveTab(TabTasks);
            gvTasks.PageIndex = e.NewPageIndex;
            LoadOpenTasks();
        }

        protected void gvAuditLog_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            SetActiveTab(TabAudit);
            gvAuditLog.PageIndex = e.NewPageIndex;
            LoadAuditLog(txtAuditAppNo.Text.Trim());
        }

        #endregion

        #region Manual Trigger Actions

        protected void gvDisbursements_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            SetActiveTab(TabDisbursements);

            if (e.CommandName == "Send60Day" || e.CommandName == "Send30Day" ||
                e.CommandName == "Send10Day" || e.CommandName == "CreateCLMTicket" ||
                e.CommandName == "CreateENGTicket")
            {
                string[] args = e.CommandArgument.ToString().Split('|');
                if (args.Length < 3)
                {
                    ShowMessage("Invalid command arguments.", false);
                    return;
                }

                string appRefNo = args[0];
                string leadNo = args[1];
                DateTime disbDate;
                if (!DateTime.TryParse(args[2], out disbDate))
                {
                    ShowMessage("Invalid disbursement date.", false);
                    return;
                }

                string actionType = "";
                string notificationType = "";

                switch (e.CommandName)
                {
                    case "Send60Day":
                        actionType = "SendNotification";
                        notificationType = "60-Day";
                        break;
                    case "Send30Day":
                        actionType = "SendNotification";
                        notificationType = "30-Day";
                        break;
                    case "Send10Day":
                        actionType = "SendNotification";
                        notificationType = "10-Day";
                        break;
                    case "CreateCLMTicket":
                        actionType = "CreateCLMTicket";
                        notificationType = "";
                        break;
                    case "CreateENGTicket":
                        actionType = "CreateENGTicket";
                        notificationType = "";
                        break;
                }

                ExecuteManualTrigger(appRefNo, leadNo, disbDate, actionType, notificationType);
            }
        }

        private void ExecuteManualTrigger(string appRefNo, string leadNo, DateTime disbDate,
            string actionType, string notificationType)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_Manual_Trigger", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@APP_REF_NO", appRefNo);
                cmd.Parameters.AddWithValue("@Lead_No", leadNo);
                cmd.Parameters.AddWithValue("@Disb_Date", disbDate);
                cmd.Parameters.AddWithValue("@ActionType", actionType);
                cmd.Parameters.AddWithValue("@NotificationType", notificationType);
                cmd.Parameters.AddWithValue("@UserID", CurrentUser);
                cmd.Parameters.AddWithValue("@Remarks", "Manual trigger from HF48 Monitor interface");

                SqlParameter pStatus = new SqlParameter("@Status", SqlDbType.NVarChar, 50);
                pStatus.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(pStatus);

                SqlParameter pMessage = new SqlParameter("@Message", SqlDbType.NVarChar, 500);
                pMessage.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(pMessage);

                conn.Open();
                cmd.ExecuteNonQuery();

                string status = pStatus.Value.ToString();
                string message = pMessage.Value.ToString();

                ShowMessage(message, status == "SUCCESS");
            }

            // Refresh all grids
            btnSearch_Click(null, EventArgs.Empty);
            LoadOpenTasks();
            LoadAuditLog(txtAuditAppNo.Text.Trim());
        }

        #endregion

        #region Service Ticket Closure

        protected void gvTasks_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            SetActiveTab(TabTasks);

            if (e.CommandName == "CloseTicket")
            {
                int taskID;
                if (!int.TryParse(e.CommandArgument.ToString(), out taskID))
                {
                    ShowMessage("Invalid Task ID.", false);
                    return;
                }

                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    SqlCommand cmd = new SqlCommand("Proc_HF48_ServiceTicket_Close", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@TaskID", taskID);
                    cmd.Parameters.AddWithValue("@UserID", CurrentUser);
                    cmd.Parameters.AddWithValue("@Remarks", "Closed from HF48 Monitor interface");

                    SqlParameter pStatus = new SqlParameter("@Status", SqlDbType.NVarChar, 50);
                    pStatus.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(pStatus);

                    SqlParameter pMessage = new SqlParameter("@Message", SqlDbType.NVarChar, 500);
                    pMessage.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(pMessage);

                    conn.Open();
                    cmd.ExecuteNonQuery();

                    string status = pStatus.Value.ToString();
                    string message = pMessage.Value.ToString();

                    ShowMessage(message, status == "SUCCESS");
                }

                LoadOpenTasks();
                LoadAuditLog(txtAuditAppNo.Text.Trim());
            }
        }

        #endregion

        #region Tabs

        protected void lnkTabDisbursements_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabDisbursements);
        }

        protected void lnkTabTasks_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabTasks);
        }

        protected void lnkTabAudit_Click(object sender, EventArgs e)
        {
            SetActiveTab(TabAudit);
        }

        private void SetActiveTab(string tab)
        {
            hfActiveTab.Value = tab;
            ApplyActiveTabVisibility();
        }

        private void ApplyActiveTabVisibility()
        {
            string activeTab = hfActiveTab.Value;
            if (activeTab != TabTasks && activeTab != TabAudit)
            {
                activeTab = TabDisbursements;
                hfActiveTab.Value = activeTab;
            }

            bool showDisbursements = activeTab == TabDisbursements;
            bool showTasks = activeTab == TabTasks;
            bool showAudit = activeTab == TabAudit;

            pnlDisbursementsTab.Visible = showDisbursements;
            pnlTasksTab.Visible = showTasks;
            pnlAuditTab.Visible = showAudit;

            lnkTabDisbursements.CssClass = showDisbursements ? "tab active" : "tab";
            lnkTabTasks.CssClass = showTasks ? "tab active" : "tab";
            lnkTabAudit.CssClass = showAudit ? "tab active" : "tab";
        }

        #endregion

        #region Helper

        private void BindGridWithSafePage(GridView grid, object dataSource)
        {
            grid.DataSource = dataSource;
            grid.DataBind();

            if (grid.PageCount > 0 && grid.PageIndex >= grid.PageCount)
            {
                grid.PageIndex = grid.PageCount - 1;
                grid.DataSource = dataSource;
                grid.DataBind();
            }
        }

        private string BuildTasksFilterExpression(string appRefNo, string caseRefNo, string taskType, string status)
        {
            string filter = "";

            if (!string.IsNullOrEmpty(appRefNo))
            {
                filter = AppendRowFilter(filter, string.Format("APP_REF_NO LIKE '%{0}%'", EscapeForRowFilter(appRefNo)));
            }

            if (!string.IsNullOrEmpty(caseRefNo))
            {
                filter = AppendRowFilter(filter, string.Format("Convert(Case_RefNo, 'System.String') LIKE '%{0}%'", EscapeForRowFilter(caseRefNo)));
            }

            if (!string.IsNullOrEmpty(taskType))
            {
                filter = AppendRowFilter(filter, string.Format("TaskType = '{0}'", EscapeForRowFilter(taskType)));
            }

            if (!string.IsNullOrEmpty(status))
            {
                filter = AppendRowFilter(filter, string.Format("Status = '{0}'", EscapeForRowFilter(status)));
            }

            return filter;
        }

        private string AppendRowFilter(string existingFilter, string nextClause)
        {
            if (string.IsNullOrEmpty(existingFilter)) return nextClause;
            return existingFilter + " AND " + nextClause;
        }

        private string EscapeForRowFilter(string input)
        {
            return (input ?? string.Empty).Replace("'", "''");
        }

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible = true;
            lblMessage.Text = Server.HtmlEncode(message);
            pnlMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }

        #endregion
    }
}
