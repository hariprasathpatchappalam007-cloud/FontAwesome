using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class HF48DisbursementMonitor : System.Web.UI.Page
    {
        // Connection string from Web.config
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        // Current logged-in user (adjust based on your auth mechanism)
        private string CurrentUser
        {
            get
            {
                if (Session["UserID"] != null)
                    return Session["UserID"].ToString();
                return System.Web.HttpContext.Current.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDisbursements();
                LoadOpenTasks();
                LoadAuditLog("");
            }
        }

        #region Data Loading

        private void LoadDisbursements()
        {
            LoadDisbursements("", "", "", "", null, null, "");
        }

        private void LoadDisbursements(string appRefNo, string leadNo, string developerName,
            string projectName, DateTime? dateFrom, DateTime? dateTo, string tier)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_Get_Disbursements", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefNo) ? (object)DBNull.Value : appRefNo);
                cmd.Parameters.AddWithValue("@LeadNo", string.IsNullOrEmpty(leadNo) ? (object)DBNull.Value : leadNo);
                cmd.Parameters.AddWithValue("@DeveloperName", string.IsNullOrEmpty(developerName) ? (object)DBNull.Value : developerName);
                cmd.Parameters.AddWithValue("@ProjectName", string.IsNullOrEmpty(projectName) ? (object)DBNull.Value : projectName);
                cmd.Parameters.AddWithValue("@DateFrom", dateFrom.HasValue ? (object)dateFrom.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@DateTo", dateTo.HasValue ? (object)dateTo.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@Tier", string.IsNullOrEmpty(tier) ? (object)DBNull.Value : tier);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvDisbursements.DataSource = dt;
                gvDisbursements.DataBind();
            }
        }

        private void LoadOpenTasks()
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_Get_OpenTasks", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvTasks.DataSource = dt;
                gvTasks.DataBind();
            }
        }

        private void LoadAuditLog(string appRefNo)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_Get_AuditLog", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefNo) ? (object)DBNull.Value : appRefNo);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvAuditLog.DataSource = dt;
                gvAuditLog.DataBind();
            }
        }

        #endregion

        #region Search & Filter Events

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DateTime? dateFrom = null;
            DateTime? dateTo = null;

            if (!string.IsNullOrEmpty(txtDateFrom.Text))
                dateFrom = DateTime.Parse(txtDateFrom.Text);
            if (!string.IsNullOrEmpty(txtDateTo.Text))
                dateTo = DateTime.Parse(txtDateTo.Text);

            LoadDisbursements(
                txtAppRefNo.Text.Trim(),
                txtLeadNo.Text.Trim(),
                txtDeveloperName.Text.Trim(),
                txtProjectName.Text.Trim(),
                dateFrom,
                dateTo,
                ddlTier.SelectedValue
            );
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtAppRefNo.Text = "";
            txtLeadNo.Text = "";
            txtDeveloperName.Text = "";
            txtProjectName.Text = "";
            txtDateFrom.Text = "";
            txtDateTo.Text = "";
            ddlTier.SelectedIndex = 0;
            LoadDisbursements();
        }

        protected void btnAuditSearch_Click(object sender, EventArgs e)
        {
            LoadAuditLog(txtAuditAppNo.Text.Trim());
        }

        protected void btnAuditAll_Click(object sender, EventArgs e)
        {
            txtAuditAppNo.Text = "";
            LoadAuditLog("");
        }

        #endregion

        #region GridView Paging

        protected void gvDisbursements_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvDisbursements.PageIndex = e.NewPageIndex;
            btnSearch_Click(sender, e);
        }

        protected void gvAuditLog_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvAuditLog.PageIndex = e.NewPageIndex;
            LoadAuditLog(txtAuditAppNo.Text.Trim());
        }

        #endregion

        #region Manual Trigger Actions

        protected void gvDisbursements_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Send60Day" || e.CommandName == "Send30Day" ||
                e.CommandName == "Send10Day" || e.CommandName == "CreateTicket")
            {
                string[] args = e.CommandArgument.ToString().Split('|');
                if (args.Length < 3)
                {
                    ShowMessage("Invalid command arguments.", false);
                    return;
                }

                string appRefNo = args[0];
                string leadNo = args[1];
                DateTime disbDate;
                if (!DateTime.TryParse(args[2], out disbDate))
                {
                    ShowMessage("Invalid disbursement date.", false);
                    return;
                }

                string actionType = "";
                string notificationType = "";

                switch (e.CommandName)
                {
                    case "Send60Day":
                        actionType = "SendNotification";
                        notificationType = "60-Day";
                        break;
                    case "Send30Day":
                        actionType = "SendNotification";
                        notificationType = "30-Day";
                        break;
                    case "Send10Day":
                        actionType = "SendNotification";
                        notificationType = "10-Day";
                        break;
                    case "CreateTicket":
                        actionType = "CreateServiceTicket";
                        notificationType = "";
                        break;
                }

                ExecuteManualTrigger(appRefNo, leadNo, disbDate, actionType, notificationType);
            }
        }

        private void ExecuteManualTrigger(string appRefNo, string leadNo, DateTime disbDate,
            string actionType, string notificationType)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_HF48_Manual_Trigger", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@APP_REF_NO", appRefNo);
                cmd.Parameters.AddWithValue("@Lead_No", leadNo);
                cmd.Parameters.AddWithValue("@Disb_Date", disbDate);
                cmd.Parameters.AddWithValue("@ActionType", actionType);
                cmd.Parameters.AddWithValue("@NotificationType", notificationType);
                cmd.Parameters.AddWithValue("@UserID", CurrentUser);
                cmd.Parameters.AddWithValue("@Remarks", "Manual trigger from HF48 Monitor interface");

                SqlParameter pStatus = new SqlParameter("@Status", SqlDbType.NVarChar, 50);
                pStatus.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(pStatus);

                SqlParameter pMessage = new SqlParameter("@Message", SqlDbType.NVarChar, 500);
                pMessage.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(pMessage);

                conn.Open();
                cmd.ExecuteNonQuery();

                string status = pStatus.Value.ToString();
                string message = pMessage.Value.ToString();

                ShowMessage(message, status == "SUCCESS");
            }

            // Refresh all grids
            btnSearch_Click(null, EventArgs.Empty);
            LoadOpenTasks();
            LoadAuditLog(txtAuditAppNo.Text.Trim());
        }

        #endregion

        #region Service Ticket Closure

        protected void gvTasks_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "CloseTicket")
            {
                int taskID;
                if (!int.TryParse(e.CommandArgument.ToString(), out taskID))
                {
                    ShowMessage("Invalid Task ID.", false);
                    return;
                }

                using (SqlConnection conn = new SqlConnection(ConnStr))
                {
                    SqlCommand cmd = new SqlCommand("Proc_HF48_ServiceTicket_Close", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@TaskID", taskID);
                    cmd.Parameters.AddWithValue("@UserID", CurrentUser);
                    cmd.Parameters.AddWithValue("@Remarks", "Closed from HF48 Monitor interface");

                    SqlParameter pStatus = new SqlParameter("@Status", SqlDbType.NVarChar, 50);
                    pStatus.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(pStatus);

                    SqlParameter pMessage = new SqlParameter("@Message", SqlDbType.NVarChar, 500);
                    pMessage.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(pMessage);

                    conn.Open();
                    cmd.ExecuteNonQuery();

                    string status = pStatus.Value.ToString();
                    string message = pMessage.Value.ToString();

                    ShowMessage(message, status == "SUCCESS");
                }

                LoadOpenTasks();
                LoadAuditLog(txtAuditAppNo.Text.Trim());
            }
        }

        #endregion

        #region Helper

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible = true;
            lblMessage.Text = Server.HtmlEncode(message);
            pnlMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }

        #endregion
    }
}
