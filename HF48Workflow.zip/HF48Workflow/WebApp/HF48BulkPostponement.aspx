<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="HF48BulkPostponement.aspx.cs" Inherits="HF48Workflow.HF48BulkPostponement" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HF48 Bulk Schedule Postponement (Maker / Checker)</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; padding: 0; background-color: #ccccff; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; border-radius: 4px 4px 0 0; }
        .panel-header.maker  { background-color: #28a745; }
        .panel-header.checker{ background-color: #FF6600; }
        .panel-header.audit  { background-color: #003366; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 160px; font-weight: bold; font-size: 13px; color: #333; vertical-align: top; }
        .form-group input, .form-group select, .form-group textarea {
            padding: 5px 8px; border: 1px solid #ccc; border-radius: 3px; font-size: 13px;
        }
        .btn { padding: 8px 18px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-primary { background-color: #003366; color: white; }
        .btn-primary:hover { background-color: #004488; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-success:hover { background-color: #218838; }
        .btn-warning { background-color: #FF6600; color: white; }
        .btn-warning:hover { background-color: #e65c00; }
        .btn-danger { background-color: #dc3545; color: white; }
        .btn-danger:hover { background-color: #c82333; }
        .btn-info { background-color: #17a2b8; color: white; }
        .btn-info:hover { background-color: #138496; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error   { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px 10px; text-align: left; font-size: 12px; }
        .gridview td { padding: 6px 10px; border-bottom: 1px solid #eee; }
        .gridview tr:hover { background-color: #f5f5f5; }
        .gridview tr.alt { background-color: #EFF3FB; }
        .new-date { color: #28a745; font-weight: bold; }
        .old-date { color: #999; text-decoration: line-through; }
        .who-bar  { background: #fff8d8; border: 1px dashed #d8b400; padding: 8px 12px; margin-bottom: 15px; font-size: 12px; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h1>HF48 Bulk Schedule Postponement</h1>
            <h2>Project-level disbursement postponement &mdash; Maker submits, Checker approves</h2>
        </div>

        <div class="container">
            <asp:Panel ID="pnlMessage" runat="server" Visible="false">
                <asp:Label ID="lblMessage" runat="server" />
            </asp:Panel>

            <div class="who-bar">
                <strong>Acting As:</strong>
                <asp:TextBox ID="txtCurrentUser" runat="server" Width="180px" />
                <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-info" OnClick="btnSetUser_Click" />
                &nbsp;<em>(In production this comes from <code>Session["UserID"]</code>; the textbox is here to demo Maker / Checker on the same browser.)</em>
            </div>

            <!-- =============================================================== -->
            <!-- MAKER  - Submit a bulk postponement request                     -->
            <!-- =============================================================== -->
            <div class="panel">
                <div class="panel-header maker">Maker &mdash; Submit Postponement Request</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>Project:</label>
                        <asp:DropDownList ID="ddlProject" runat="server" Width="420px"
                            AutoPostBack="True" OnSelectedIndexChanged="ddlProject_SelectedIndexChanged" />
                        <asp:Button ID="btnRefreshProjects" runat="server" Text="Refresh" CssClass="btn btn-info"
                            OnClick="btnRefreshProjects_Click" />
                    </div>
                    <div class="form-group">
                        <label>Shift All Schedules By:</label>
                        <asp:TextBox ID="txtShiftDays" runat="server" Width="80px" Text="30" />
                        <span style="font-size:12px;">days (forward only)</span>
                        <asp:Button ID="btnPreview" runat="server" Text="Preview Impact" CssClass="btn btn-primary"
                            OnClick="btnPreview_Click" />
                    </div>
                    <div class="form-group">
                        <label>Reason:</label>
                        <asp:TextBox ID="txtReason" runat="server" Width="600px" TextMode="MultiLine" Rows="2"
                            placeholder="e.g. Project on hold pending RERA approval" />
                    </div>

                    <h3 style="margin:15px 0 8px 0; color:#003366;">Affected Schedules (Preview)</h3>
                    <asp:GridView ID="gvPreview" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False"
                        EmptyDataText="Pick a project and click 'Preview Impact' to see affected schedules."
                        AlternatingRowStyle-CssClass="alt">
                        <Columns>
                            <asp:BoundField DataField="APP_REF_NO" HeaderText="App Ref No" />
                            <asp:BoundField DataField="Lead_No" HeaderText="Lead No" />
                            <asp:BoundField DataField="Customer_name" HeaderText="Customer" />
                            <asp:TemplateField HeaderText="Old Disb. Date">
                                <ItemTemplate>
                                    <span class="old-date"><%# Eval("OldDisbDate", "{0:dd/MM/yyyy}") %></span>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField HeaderText="New Disb. Date">
                                <ItemTemplate>
                                    <span class="new-date"><%# Eval("NewDisbDate", "{0:dd/MM/yyyy}") %></span>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:BoundField DataField="Disb_amount" HeaderText="Amount" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="disb_status" HeaderText="Status" />
                            <asp:BoundField DataField="MilestonePaymentPct" HeaderText="Milestone %" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="PropertyPaymentPct"  HeaderText="Property %"  DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="FinancePaymentPct"   HeaderText="Finance %"   DataFormatString="{0:N2}" />
                        </Columns>
                    </asp:GridView>

                    <div class="form-group" style="margin-top:15px;">
                        <asp:Label ID="lblPreviewSummary" runat="server" Style="font-size:12px;color:#003366;" />
                    </div>

                    <div style="margin-top:10px;">
                        <asp:Button ID="btnSubmit" runat="server" Text="Submit for Approval" CssClass="btn btn-success"
                            OnClick="btnSubmit_Click"
                            OnClientClick="return confirm('Submit this bulk postponement request for Checker approval?');" />
                    </div>
                </div>
            </div>

            <!-- =============================================================== -->
            <!-- CHECKER - Pending requests queue                                -->
            <!-- =============================================================== -->
            <div class="panel">
                <div class="panel-header checker">Checker &mdash; Pending Approvals</div>
                <div class="panel-body">
                    <asp:GridView ID="gvPending" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False" DataKeyNames="RequestID"
                        OnRowCommand="gvPending_RowCommand"
                        EmptyDataText="No pending bulk postponement requests."
                        AlternatingRowStyle-CssClass="alt">
                        <Columns>
                            <asp:BoundField DataField="RequestID" HeaderText="Req #" />
                            <asp:BoundField DataField="Property_ProjectName" HeaderText="Project" />
                            <asp:BoundField DataField="Property_DeveloperName" HeaderText="Developer" />
                            <asp:BoundField DataField="ShiftDays" HeaderText="Shift (d)" />
                            <asp:BoundField DataField="AffectedAppCount" HeaderText="Apps" />
                            <asp:BoundField DataField="AffectedRowCount" HeaderText="Schedules" />
                            <asp:BoundField DataField="MakerUser" HeaderText="Maker" />
                            <asp:BoundField DataField="MakerOn"   HeaderText="Submitted On" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            <asp:BoundField DataField="Reason"    HeaderText="Reason" />
                            <asp:TemplateField HeaderText="Action">
                                <ItemTemplate>
                                    <asp:Button ID="btnView" runat="server" Text="View" CssClass="btn btn-info"
                                        CommandName="ViewRequest" CommandArgument='<%# Eval("RequestID") %>' />
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>
            </div>

            <!-- =============================================================== -->
            <!-- CHECKER - Selected request detail + Approve/Reject              -->
            <!-- =============================================================== -->
            <asp:Panel ID="pnlDetail" runat="server" Visible="false" CssClass="panel">
                <div class="panel-header checker">
                    Request Detail &mdash; #<asp:Label ID="lblReqId" runat="server" />
                    <span style="float:right;font-weight:normal;">
                        Project: <asp:Label ID="lblReqProject" runat="server" />
                        &nbsp;|&nbsp; Maker: <asp:Label ID="lblReqMaker" runat="server" />
                        &nbsp;|&nbsp; Shift: +<asp:Label ID="lblReqShift" runat="server" /> days
                    </span>
                </div>
                <div class="panel-body">
                    <asp:HiddenField ID="hfSelectedRequestId" runat="server" />

                    <div class="form-group">
                        <label>Maker Reason:</label>
                        <asp:Label ID="lblReqReason" runat="server" />
                    </div>

                    <asp:GridView ID="gvDetail" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False"
                        EmptyDataText="No detail rows."
                        AlternatingRowStyle-CssClass="alt">
                        <Columns>
                            <asp:BoundField DataField="APP_REF_NO" HeaderText="App Ref No" />
                            <asp:BoundField DataField="Lead_No" HeaderText="Lead No" />
                            <asp:BoundField DataField="Customer_Name" HeaderText="Customer" />
                            <asp:TemplateField HeaderText="Old Disb. Date">
                                <ItemTemplate>
                                    <span class="old-date"><%# Eval("OldDisbDate", "{0:dd/MM/yyyy}") %></span>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField HeaderText="New Disb. Date">
                                <ItemTemplate>
                                    <span class="new-date"><%# Eval("NewDisbDate", "{0:dd/MM/yyyy}") %></span>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:BoundField DataField="Disb_Amount" HeaderText="Amount" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="Disb_Status" HeaderText="Status" />
                            <asp:BoundField DataField="Applied"    HeaderText="Applied?" />
                        </Columns>
                    </asp:GridView>

                    <div class="form-group" style="margin-top:15px;">
                        <label>Checker Remarks:</label>
                        <asp:TextBox ID="txtCheckerRemarks" runat="server" Width="600px" TextMode="MultiLine" Rows="2" />
                    </div>
                    <div>
                        <asp:Button ID="btnApprove" runat="server" Text="Approve &amp; Apply Postponement" CssClass="btn btn-success"
                            OnClick="btnApprove_Click"
                            OnClientClick="return confirm('Approve this request? All listed schedules will be moved to the new dates.');" />
                        <asp:Button ID="btnReject" runat="server" Text="Reject" CssClass="btn btn-danger"
                            OnClick="btnReject_Click"
                            OnClientClick="return confirm('Reject this request? Schedules will NOT be moved. Remarks are required.');" />
                        <asp:Button ID="btnCloseDetail" runat="server" Text="Close" CssClass="btn btn-info"
                            OnClick="btnCloseDetail_Click" />
                    </div>
                </div>
            </asp:Panel>

            <!-- =============================================================== -->
            <!-- AUDIT - History of bulk postponement requests                   -->
            <!-- =============================================================== -->
            <div class="panel">
                <div class="panel-header audit">History (Approved / Rejected)</div>
                <div class="panel-body">
                    <asp:GridView ID="gvHistory" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False"
                        AllowPaging="True" PageSize="15"
                        OnPageIndexChanging="gvHistory_PageIndexChanging"
                        EmptyDataText="No closed requests yet."
                        AlternatingRowStyle-CssClass="alt">
                        <Columns>
                            <asp:BoundField DataField="RequestID" HeaderText="Req #" />
                            <asp:BoundField DataField="Property_ProjectName" HeaderText="Project" />
                            <asp:BoundField DataField="ShiftDays" HeaderText="Shift (d)" />
                            <asp:BoundField DataField="AffectedAppCount" HeaderText="Apps" />
                            <asp:BoundField DataField="AffectedRowCount" HeaderText="Schedules" />
                            <asp:BoundField DataField="Status"    HeaderText="Status" />
                            <asp:BoundField DataField="MakerUser" HeaderText="Maker" />
                            <asp:BoundField DataField="MakerOn"   HeaderText="Submitted" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            <asp:BoundField DataField="CheckerUser" HeaderText="Checker" />
                            <asp:BoundField DataField="CheckerOn"   HeaderText="Decided"  DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            <asp:BoundField DataField="CheckerRemarks" HeaderText="Checker Remarks" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
        </div>
    </form>
</body>
</html>
