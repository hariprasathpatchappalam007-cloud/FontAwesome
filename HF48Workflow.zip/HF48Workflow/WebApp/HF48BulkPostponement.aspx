<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="HF48BulkPostponement.aspx.cs" Inherits="HF48Workflow.HF48BulkPostponement" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HF48 Bulk Postponement / Preponment</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; padding: 0; background-color: #ccccff; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; border-radius: 4px 4px 0 0; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; display: inline-block; margin-right: 20px; vertical-align: middle; }
        .form-group label { display: block; font-weight: bold; font-size: 12px; color: #333; margin-bottom: 3px; }
        .form-group input, .form-group select { padding: 5px 8px; border: 1px solid #ccc; border-radius: 3px; font-size: 13px; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-primary  { background-color: #003366; color: white; }
        .btn-primary:hover  { background-color: #004488; }
        .btn-warning  { background-color: #FF6600; color: white; }
        .btn-warning:hover  { background-color: #e65c00; }
        .btn-danger   { background-color: #dc3545; color: white; }
        .btn-danger:hover   { background-color: #c82333; }
        .btn-success  { background-color: #28a745; color: white; }
        .btn-success:hover  { background-color: #218838; }
        .btn-info     { background-color: #17a2b8; color: white; }
        .btn-info:hover     { background-color: #138496; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error   { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px 6px; text-align: left; font-size: 11px; white-space: nowrap; }
        .gridview td { padding: 5px 6px; border-bottom: 1px solid #eee; vertical-align: middle; font-size: 12px; }
        .gridview tr:hover { background-color: #f5f5f5; }
        .gridview tr.alt  { background-color: #EFF3FB; }
        .action-bar { background: #fff8e1; border: 1px solid #ffe082; border-radius: 4px; padding: 12px 16px; margin-bottom: 12px; }
        .action-bar label { font-weight: bold; font-size: 13px; margin-right: 6px; }
        .shift-input { width: 80px; text-align: center; font-size: 14px; font-weight: bold; padding: 5px; border: 2px solid #003366; border-radius: 3px; }
        .info-box { background: #e3f2fd; border: 1px solid #90caf9; padding: 8px 12px; border-radius: 3px; margin-bottom: 10px; font-size: 12px; color: #0d47a1; }
        .selected-count { font-weight: bold; color: #003366; font-size: 13px; }
        .pager a, .pager span { padding: 3px 8px; margin: 1px; border: 1px solid #ccc; border-radius: 2px; font-size: 12px; }
        .section-divider { border: none; border-top: 2px solid #003366; margin: 20px 0; }
    </style>
    <script type="text/javascript">
        // Select / deselect all checkboxes
        function toggleSelectAll(masterChk) {
            var table = document.getElementById('<%= gvDisbursements.ClientID %>');
            if (!table) return;
            var chks = table.getElementsByTagName('input');
            for (var i = 0; i < chks.length; i++) {
                if (chks[i].type === 'checkbox' && chks[i].id !== masterChk.id) {
                    chks[i].checked = masterChk.checked;
                }
            }
            updateSelectedCount();
        }

        // Count selected rows
        function updateSelectedCount() {
            var table = document.getElementById('<%= gvDisbursements.ClientID %>');
            var count = 0;
            if (table) {
                var chks = table.getElementsByTagName('input');
                for (var i = 0; i < chks.length; i++) {
                    if (chks[i].type === 'checkbox' && chks[i].id.indexOf('chkSelect') >= 0 && chks[i].checked) {
                        count++;
                    }
                }
            }
            var lbl = document.getElementById('lblSelCount');
            if (lbl) lbl.innerHTML = count + ' record(s) selected';
        }

        function confirmPostpone(withHold) {
            var shiftBox = document.getElementById('<%= txtShiftDays.ClientID %>');
            var days = shiftBox ? parseInt(shiftBox.value, 10) : NaN;
            if (isNaN(days) || shiftBox.value.trim() === '') {
                alert('Please enter a valid number for Shift Days (use negative for preponment, e.g. -10).');
                shiftBox.focus();
                return false;
            }
            var lbl = document.getElementById('lblSelCount');
            var countText = lbl ? lbl.innerHTML : '';
            var action = (days >= 0) ? 'POSTPONE' : 'PREPONE';
            var holdText = withHold ? '\nProject HOLD will be applied.' : '\nNo hold will be applied.';
            return confirm(action + ' selected disbursements by ' + Math.abs(days) + ' day(s)?' + holdText + '\n\n' + countText);
        }
    </script>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h1>HF48 Bulk Postponement / Preponment</h1>
            <h2>Shift disbursement dates in bulk &mdash; with or without project hold</h2>
        </div>

        <div class="container">

            <!-- Status Message -->
            <asp:Panel ID="pnlMessage" runat="server" Visible="false">
                <asp:Label ID="lblMessage" runat="server" />
            </asp:Panel>

            <!-- ============================================= -->
            <!-- SECTION 1: Filter                             -->
            <!-- ============================================= -->
            <div class="panel">
                <div class="panel-header">Filter Disbursements</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>Application ID:</label>
                        <asp:TextBox ID="txtAppRefNo" runat="server" Width="180px" placeholder="e.g. APP-001234" />
                    </div>
                    <div class="form-group">
                        <label>Disb. Date From:</label>
                        <asp:TextBox ID="txtDisbDateFrom" runat="server" Width="130px" TextMode="Date" />
                    </div>
                    <div class="form-group">
                        <label>Disb. Date To:</label>
                        <asp:TextBox ID="txtDisbDateTo" runat="server" Width="130px" TextMode="Date" />
                    </div>
                    <div style="margin-top:8px;">
                        <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-primary" OnClick="btnSearch_Click" />
                        <asp:Button ID="btnClear"  runat="server" Text="Clear"  CssClass="btn btn-info" OnClick="btnClear_Click" CausesValidation="false" />
                    </div>
                </div>
            </div>

            <!-- ============================================= -->
            <!-- SECTION 2: Disbursement Grid with Checkboxes  -->
            <!-- ============================================= -->
            <div class="panel">
                <div class="panel-header">Pending Disbursements &mdash; Select Records to Process</div>
                <div class="panel-body">
                    <p class="info-box">
                        Use the checkboxes to select the disbursements you want to postpone or prepone.
                        Tick &ldquo;Select All&rdquo; in the header to select all visible records.
                    </p>

                    <asp:GridView ID="gvDisbursements" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False"
                        DataKeyNames="APP_REF_NO,Lead_No,Disb_Date"
                        AllowPaging="True" PageSize="25"
                        OnPageIndexChanging="gvDisbursements_PageIndexChanging"
                        EmptyDataText="No disbursement records found. Use the filter above and click Search."
                        AlternatingRowStyle-CssClass="alt"
                        OnDataBound="gvDisbursements_DataBound">
                        <Columns>
                            <!-- Checkbox column -->
                            <asp:TemplateField>
                                <HeaderTemplate>
                                    <input type="checkbox" id="chkAll" title="Select All"
                                        onclick="toggleSelectAll(this);" />
                                </HeaderTemplate>
                                <ItemTemplate>
                                    <asp:CheckBox ID="chkSelect" runat="server" onclick="updateSelectedCount();" />
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:BoundField DataField="APP_REF_NO"          HeaderText="Application ID" />
                            <asp:BoundField DataField="Lead_No"             HeaderText="Lead No" />
                            <asp:BoundField DataField="Customer_name"       HeaderText="Customer" />
                            <asp:BoundField DataField="Disb_Date"           HeaderText="Disb. Date"   DataFormatString="{0:dd/MM/yyyy}" />
                            <asp:BoundField DataField="Disb_amount"         HeaderText="Amount"       DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="MilestonePaymentPct" HeaderText="Milestone %"  DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="PropertyPaymentPct"  HeaderText="Property %"   DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="FinancePaymentPct"   HeaderText="Finance %"    DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="Property_DeveloperName" HeaderText="Developer" />
                            <asp:BoundField DataField="dev_tier"            HeaderText="Tier" />
                            <asp:BoundField DataField="Property_ProjectName" HeaderText="Project" />
                            <asp:BoundField DataField="value_tranche"       HeaderText="Hold Status" />
                            <asp:BoundField DataField="DaysRemaining"       HeaderText="Days Left" />
                        </Columns>
                    </asp:GridView>

                    <div style="margin-top:8px;">
                        <span id="lblSelCount" class="selected-count">0 record(s) selected</span>
                    </div>
                </div>
            </div>

            <!-- ============================================= -->
            <!-- SECTION 3: Bulk Action Bar                    -->
            <!-- ============================================= -->
            <div class="action-bar">
                <table>
                    <tr>
                        <td style="padding-right:20px;">
                            <label>Shift Days:</label>
                            <asp:TextBox ID="txtShiftDays" runat="server" CssClass="shift-input"
                                placeholder="e.g. 30 or -10" MaxLength="6" />
                            <br />
                            <small style="color:#555;">Positive = postpone &nbsp;|&nbsp; Negative = prepone</small>
                        </td>
                        <td style="padding-right:20px; vertical-align:bottom;">
                            <asp:Button ID="btnPostponeNoHold" runat="server"
                                Text="Postpone / Prepone (No Hold)"
                                CssClass="btn btn-warning"
                                OnClick="btnPostponeNoHold_Click"
                                OnClientClick="return confirmPostpone(false);" />
                        </td>
                        <td style="vertical-align:bottom;">
                            <asp:Button ID="btnPostponeWithHold" runat="server"
                                Text="Postpone / Prepone + Apply Hold"
                                CssClass="btn btn-danger"
                                OnClick="btnPostponeWithHold_Click"
                                OnClientClick="return confirmPostpone(true);" />
                        </td>
                    </tr>
                </table>
            </div>

            <hr class="section-divider" />

            <!-- ============================================= -->
            <!-- SECTION 4: Postponement History Log           -->
            <!-- ============================================= -->
            <div class="panel">
                <div class="panel-header">Postponement / Preponment History Log</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>App Ref No:</label>
                        <asp:TextBox ID="txtLogAppRefNo" runat="server" Width="180px" />
                    </div>
                    <div style="margin-bottom:10px; margin-top:4px;">
                        <asp:Button ID="btnFilterLog"  runat="server" Text="Filter Log" CssClass="btn btn-primary" OnClick="btnFilterLog_Click" />
                        <asp:Button ID="btnClearLog"   runat="server" Text="Show All"   CssClass="btn btn-info"    OnClick="btnClearLog_Click" />
                    </div>
                    <asp:GridView ID="gvPostponeLog" runat="server" CssClass="gridview"
                        AutoGenerateColumns="False"
                        AllowPaging="True" PageSize="20"
                        OnPageIndexChanging="gvPostponeLog_PageIndexChanging"
                        EmptyDataText="No postponement history found."
                        AlternatingRowStyle-CssClass="alt">
                        <Columns>
                            <asp:BoundField DataField="LogID"            HeaderText="Log ID" />
                            <asp:BoundField DataField="APP_REF_NO"       HeaderText="App Ref No" />
                            <asp:BoundField DataField="Lead_No"          HeaderText="Lead No" />
                            <asp:BoundField DataField="OriginalDisbDate" HeaderText="Original Date"    DataFormatString="{0:dd/MM/yyyy}" />
                            <asp:BoundField DataField="NewDisbDate"      HeaderText="New Date"         DataFormatString="{0:dd/MM/yyyy}" />
                            <asp:BoundField DataField="ShiftDays"        HeaderText="Shift Days" />
                            <asp:BoundField DataField="PostponementType" HeaderText="Type" />
                            <asp:TemplateField HeaderText="Hold Applied">
                                <ItemTemplate>
                                    <%# Convert.ToBoolean(Eval("HoldApplied")) ? "Yes" : "No" %>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:BoundField DataField="ProjectName"      HeaderText="Project" />
                            <asp:BoundField DataField="CreatedBy"        HeaderText="By" />
                            <asp:BoundField DataField="CreatedOn"        HeaderText="Date"             DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            <asp:BoundField DataField="Remarks"          HeaderText="Remarks" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>

        </div>
    </form>
</body>
</html>
