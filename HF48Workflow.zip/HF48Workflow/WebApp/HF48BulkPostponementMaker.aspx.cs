using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class HF48BulkPostponementMaker : Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                string fromTextbox = (txtCurrentUser.Text ?? "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null) return Session["UserID"].ToString();
                if (System.Web.HttpContext.Current.User != null &&
                    System.Web.HttpContext.Current.User.Identity != null &&
                    !string.IsNullOrEmpty(System.Web.HttpContext.Current.User.Identity.Name))
                    return System.Web.HttpContext.Current.User.Identity.Name;
                return "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                hfDraftId.Value = Guid.NewGuid().ToString("N");
                hfMode.Value = "Postpone";
                LoadProjects();
                ApplyTabVisibility();
            }
        }

        protected void lnkTabHold_Click(object sender, EventArgs e)
        {
            hfMode.Value = "Hold";
            ApplyTabVisibility();
        }

        protected void lnkTabUnhold_Click(object sender, EventArgs e)
        {
            hfMode.Value = "Unhold";
            ApplyTabVisibility();
        }

        protected void lnkTabReport_Click(object sender, EventArgs e)
        {
            hfMode.Value = "Report";
            ApplyTabVisibility();
        }

        protected void lnkTabHistory_Click(object sender, EventArgs e)
        {
            hfMode.Value = "History";
            ApplyTabVisibility();
        }

        protected void lnkTabPostpone_Click(object sender, EventArgs e)
        {
            hfMode.Value = "Postpone";
            ApplyTabVisibility();
        }

        private void ApplyTabVisibility()
        {
            string mode = hfMode.Value ?? "Postpone";
            bool hold = mode == "Hold";
            bool postpone = mode == "Postpone";
            bool unhold = mode == "Unhold";
            bool report = mode == "Report";
            bool history = mode == "History";

            pnlHoldMaker.Visible = hold || postpone;
            pnlUnholdMaker.Visible = unhold;
            pnlReportTab.Visible = report;
            pnlHistoryTab.Visible = history;
            btnSubmit.Visible = !history && !report;
            txtReason.Enabled = !history && !report;

            lnkTabPostpone.CssClass = postpone ? "tab postpone active" : "tab postpone";
            lnkTabHold.CssClass = hold ? "tab active" : "tab";
            lnkTabUnhold.CssClass = unhold ? "tab unhold active" : "tab unhold";
            lnkTabReport.CssClass = report ? "tab report active" : "tab report";
            lnkTabHistory.CssClass = history ? "tab history active" : "tab history";

            if (hold || postpone)
            {
                ddlDisbStatus.SelectedValue = "Not Disbursed";
                ddlDisbStatus.Enabled = false;
            }

            if (unhold)
            {
                ddlUnholdDisbStatus.SelectedValue = "On hold";
                ddlUnholdDisbStatus.Enabled = false;
            }

            if (hold)
            {
                btnSubmit.Text = "Submit Hold for Approval";
                btnSubmit.CssClass = "btn btn-success";
            }
            else if (postpone)
            {
                btnSubmit.Text = "Submit Postponement / Preponement for Approval";
                btnSubmit.CssClass = "btn btn-primary";
            }
            else
            {
                btnSubmit.Text = "Submit Unhold for Approval";
                btnSubmit.CssClass = "btn btn-warning";
            }
        }

        private void LoadProjects()
        {
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetProjects", null);

            ddlProject.Items.Clear();
            ddlProject.Items.Add(new ListItem("-- All Projects (optional) --", ""));

            ddlUnholdProject.Items.Clear();
            ddlUnholdProject.Items.Add(new ListItem("-- Select Project --", ""));

            ddlReportProject.Items.Clear();
            ddlReportProject.Items.Add(new ListItem("-- All Projects (optional) --", ""));

            foreach (DataRow r in dt.Rows)
            {
                string id = Convert.ToString(r["Property_ProjectID"]);
                string tierRaw = Convert.ToString(r["dev_tier"]);
                string tierDisplay = (string.IsNullOrEmpty(tierRaw) || tierRaw == "-") ? "Tier 2" : tierRaw;
                string label = string.Format("{0} - {1} ({2} app(s) | Tier: {3} | Tranche: {4})",
                    r["Property_ProjectName"], r["Property_DeveloperName"],
                    r["AppCount"], tierDisplay, r["value_tranche"]);

                ddlProject.Items.Add(new ListItem(label, id));
                ddlUnholdProject.Items.Add(new ListItem(label, id));
                ddlReportProject.Items.Add(new ListItem(label, id));
            }

            ViewState["ProjectsTable"] = dt;
        }

        protected void btnRefreshProjects_Click(object sender, EventArgs e)
        {
            LoadProjects();
            gvPreview.DataSource = null;
            gvPreview.DataBind();
            lblPreviewSummary.Text = "";
            ClearMakerPreviewCache();
            ResetProjectMeta();
        }

        protected void ddlProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateProjectMeta();
        }

        protected void btnClearFilters_Click(object sender, EventArgs e)
        {
            ddlProject.SelectedIndex = 0;
            txtAppRefNo.Text = "";
            ddlDisbStatus.SelectedValue = "Not Disbursed";
            txtFromDisbDate.Text = "";
            txtToDisbDate.Text = "";
            txtShiftDays.Text = "0";
            gvPreview.DataSource = null;
            gvPreview.DataBind();
            lblPreviewSummary.Text = "";
            ClearMakerPreviewCache();
            ResetProjectMeta();
        }

        protected void btnPreview_Click(object sender, EventArgs e)
        {
            UpdateProjectMeta();
            RunPreview();
        }

        private void ResetProjectMeta()
        {
            lblProjTier.Text = "-";
            lblProjTranche.Text = "-";
            lblProjPending.Text = "0";
            lblProjHeld.Text = "0";
        }

        private void UpdateProjectMeta()
        {
            DataTable dt = ViewState["ProjectsTable"] as DataTable;
            string id = ddlProject.SelectedValue;
            if (dt == null || string.IsNullOrEmpty(id))
            {
                ResetProjectMeta();
                return;
            }

            DataRow[] rows = dt.Select("Property_ProjectID='" + id.Replace("'", "''") + "'");
            if (rows.Length == 0)
            {
                ResetProjectMeta();
                return;
            }

            DataRow r = rows[0];
            string tierRaw = Convert.ToString(r["dev_tier"]);
            lblProjTier.Text    = (string.IsNullOrEmpty(tierRaw) || tierRaw == "-") ? "Tier 2" : tierRaw;
            lblProjTranche.Text = Convert.ToString(r["value_tranche"]);
            lblProjPending.Text = Convert.ToString(r["PendingRows"]);
            lblProjHeld.Text = Convert.ToString(r["HoldRows"]);
        }

        private void RunPreview()
        {
            string projectId = ddlProject.SelectedValue;
            bool isPostpone = hfMode.Value == "Postpone";
            int shiftDays;
            if (!int.TryParse((txtShiftDays.Text ?? "0").Trim(), out shiftDays))
            {
                ShowMessage("Shift Days must be a valid integer.", false);
                return;
            }
            if (!isPostpone && shiftDays < 0)
            {
                ShowMessage("Negative shift days are only allowed in Postpone mode.", false);
                return;
            }

            string appRefFilter;
            string disbStatusFilter;
            DateTime? fromDate;
            DateTime? toDate;
            string filterError;
            if (!TryGetMakerFilters(out appRefFilter, out disbStatusFilter, out fromDate, out toDate, out filterError))
            {
                ShowMessage(filterError, false);
                return;
            }

            disbStatusFilter = "Not Disbursed";

            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_Preview", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Property_ProjectID", string.IsNullOrEmpty(projectId) ? (object)DBNull.Value : projectId);
                c.Parameters.AddWithValue("@ShiftDays", shiftDays);
                c.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefFilter) ? (object)DBNull.Value : appRefFilter);
                c.Parameters.AddWithValue("@DisbStatus", disbStatusFilter);
                c.Parameters.AddWithValue("@FromDisbDate", fromDate.HasValue ? (object)fromDate.Value : DBNull.Value);
                c.Parameters.AddWithValue("@ToDisbDate", toDate.HasValue ? (object)toDate.Value : DBNull.Value);
            });

            Session["MakerPreviewData"] = dt;
            SaveMakerPreviewCriteria(projectId, shiftDays, appRefFilter, disbStatusFilter, fromDate, toDate, hfMode.Value, dt.Rows.Count);

            gvPreview.DataSource = dt;
            gvPreview.DataBind();

            int distinctApps = 0;
            decimal totalImpacted = 0m;
            int holdableRows = 0;
            HashSet<string> apps = new HashSet<string>();
            foreach (DataRow r in dt.Rows)
            {
                apps.Add(Convert.ToString(r["APP_REF_NO"]));
                string ds = Convert.ToString(r["disb_status"]);
                if (ds == "Not Disbursed")
                {
                    holdableRows++;
                    if (r["Disb_amount"] != DBNull.Value) totalImpacted += Convert.ToDecimal(r["Disb_amount"]);
                }
            }
            distinctApps = apps.Count;

            lblPreviewSummary.Text = string.Format(
                "Preview: {0} row(s), {1} app(s), eligible Not Disbursed: {2}, amount: {3:N2}. Shift: {4} day(s).",
                dt.Rows.Count, distinctApps, holdableRows, totalImpacted, shiftDays);
        }

        private bool TryGetMakerFilters(out string appRefNo, out string disbStatus, out DateTime? fromDate, out DateTime? toDate, out string errorMessage)
        {
            appRefNo = (txtAppRefNo.Text ?? "").Trim();
            disbStatus = "Not Disbursed";
            fromDate = null;
            toDate = null;
            errorMessage = null;

            if (!string.IsNullOrEmpty((txtFromDisbDate.Text ?? "").Trim()))
            {
                fromDate = ParseDate(txtFromDisbDate.Text.Trim());
                if (!fromDate.HasValue) { errorMessage = "Invalid From Disbursement Date (use dd/MM/yyyy)."; return false; }
            }

            if (!string.IsNullOrEmpty((txtToDisbDate.Text ?? "").Trim()))
            {
                toDate = ParseDate(txtToDisbDate.Text.Trim());
                if (!toDate.HasValue) { errorMessage = "Invalid To Disbursement Date (use dd/MM/yyyy)."; return false; }
            }
            return true;
        }

        private void SaveMakerPreviewCriteria(string projectId, int shiftDays, string appRefNo, string disbStatus, DateTime? fromDate, DateTime? toDate, string mode, int rowCount)
        {
            ViewState["MakerPreview_ProjectID"] = projectId ?? "";
            ViewState["MakerPreview_ShiftDays"] = shiftDays;
            ViewState["MakerPreview_AppRefNo"] = appRefNo ?? "";
            ViewState["MakerPreview_DisbStatus"] = disbStatus ?? "";
            ViewState["MakerPreview_FromDisbDate"] = fromDate.HasValue ? fromDate.Value.ToString("yyyy-MM-dd") : "";
            ViewState["MakerPreview_ToDisbDate"] = toDate.HasValue ? toDate.Value.ToString("yyyy-MM-dd") : "";
            ViewState["MakerPreview_Mode"] = mode ?? "";
            ViewState["MakerPreview_RowCount"] = rowCount;
        }

        private bool TryGetSavedMakerPreviewCriteria(out string projectId, out int shiftDays, out string appRefNo, out string disbStatus, out DateTime? fromDate, out DateTime? toDate, out string mode, out int rowCount)
        {
            projectId = Convert.ToString(ViewState["MakerPreview_ProjectID"]);
            appRefNo = Convert.ToString(ViewState["MakerPreview_AppRefNo"]);
            disbStatus = Convert.ToString(ViewState["MakerPreview_DisbStatus"]);
            mode = Convert.ToString(ViewState["MakerPreview_Mode"]);

            shiftDays = 0;
            rowCount = 0;
            fromDate = null;
            toDate = null;

            if (ViewState["MakerPreview_ShiftDays"] == null || ViewState["MakerPreview_RowCount"] == null) return false;
            shiftDays = Convert.ToInt32(ViewState["MakerPreview_ShiftDays"]);
            rowCount = Convert.ToInt32(ViewState["MakerPreview_RowCount"]);

            DateTime d;
            string fromStr = Convert.ToString(ViewState["MakerPreview_FromDisbDate"]);
            if (!string.IsNullOrEmpty(fromStr) && DateTime.TryParse(fromStr, out d)) fromDate = d;

            string toStr = Convert.ToString(ViewState["MakerPreview_ToDisbDate"]);
            if (!string.IsNullOrEmpty(toStr) && DateTime.TryParse(toStr, out d)) toDate = d;

            return true;
        }

        private void ClearMakerPreviewCache()
        {
            Session["MakerPreviewData"] = null;
            ViewState["MakerPreview_ProjectID"] = null;
            ViewState["MakerPreview_ShiftDays"] = null;
            ViewState["MakerPreview_AppRefNo"] = null;
            ViewState["MakerPreview_DisbStatus"] = null;
            ViewState["MakerPreview_FromDisbDate"] = null;
            ViewState["MakerPreview_ToDisbDate"] = null;
            ViewState["MakerPreview_Mode"] = null;
            ViewState["MakerPreview_RowCount"] = null;
        }

        protected void gvPreview_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                int grp = 0;
                int.TryParse(Convert.ToString(DataBinder.Eval(e.Row.DataItem, "GroupIndex")), out grp);
                e.Row.CssClass = "grp-" + (((grp - 1) % 6) + 1);

                string status = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "disb_status"));
                if (string.Equals(status, "Disbursed", StringComparison.OrdinalIgnoreCase))
                    e.Row.CssClass = "row-disbursed";
            }
        }

        protected void gvPreview_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "ViewHistory") return;
            string arg = Convert.ToString(e.CommandArgument);
            string[] parts = arg.Split('|');
            string appRef = parts.Length > 0 ? parts[0] : "";
            string leadNo = parts.Length > 1 ? parts[1] : "";

            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_GetScheduleHistory", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@APP_REF_NO", string.IsNullOrEmpty(appRef) ? (object)DBNull.Value : appRef);
                c.Parameters.AddWithValue("@Lead_No", string.IsNullOrEmpty(leadNo) ? (object)DBNull.Value : leadNo);
            });

            gvScheduleHistory.DataSource = dt;
            gvScheduleHistory.DataBind();
            lblScheduleHistoryTitle.Text = string.Format("Postponement / Hold History - App: {0} | Lead: {1}", appRef, leadNo);

            hfMode.Value = "History";
            ApplyTabVisibility();
        }

        protected void btnExportPreviewCSV_Click(object sender, EventArgs e)
        {
            DataTable dt = Session["MakerPreviewData"] as DataTable;
            if (dt == null || dt.Rows.Count == 0)
            {
                ShowMessage("No preview data to export. Run Preview first.", false);
                return;
            }
            ExportDataTableToCsv(dt, "BulkPostponement_Preview_" + DateTime.Now.ToString("yyyyMMdd") + ".csv");
        }

        protected void btnRefreshHolds_Click(object sender, EventArgs e)
        {
            LoadProjects();
        }

        protected void btnClearUnholdFilters_Click(object sender, EventArgs e)
        {
            ddlUnholdProject.SelectedIndex = 0;
            txtUnholdAppRefNo.Text = "";
            ddlUnholdDisbStatus.SelectedValue = "On hold";
            txtUnholdFromDisbDate.Text = "";
            txtUnholdToDisbDate.Text = "";
            gvUnholdPreview.DataSource = null;
            gvUnholdPreview.DataBind();
            lblUnholdPreviewSummary.Text = "";
            ClearUnholdPreviewCache();
        }

        protected void btnPreviewUnhold_Click(object sender, EventArgs e)
        {
            string projectId;
            string appRefFilter;
            string disbStatusFilter;
            DateTime? fromDate;
            DateTime? toDate;
            string filterError;
            if (!TryGetUnholdFilters(out projectId, out appRefFilter, out disbStatusFilter, out fromDate, out toDate, out filterError))
            {
                ShowMessage(filterError, false);
                return;
            }

            DataTable preview = ExecuteReader("Proc_HF48_BulkPostpone_UnholdPreview", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Property_ProjectID", string.IsNullOrEmpty(projectId) ? (object)DBNull.Value : projectId);
                c.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefFilter) ? (object)DBNull.Value : appRefFilter);
                c.Parameters.AddWithValue("@DisbStatus", disbStatusFilter);
                c.Parameters.AddWithValue("@FromDisbDate", fromDate.HasValue ? (object)fromDate.Value : DBNull.Value);
                c.Parameters.AddWithValue("@ToDisbDate", toDate.HasValue ? (object)toDate.Value : DBNull.Value);
            });

            gvUnholdPreview.DataSource = preview;
            gvUnholdPreview.DataBind();
            lblUnholdPreviewSummary.Text = string.Format("Unhold preview: {0} on-hold row(s) will be sent for approval.", preview.Rows.Count);

            SaveUnholdPreviewCriteria(projectId, appRefFilter, disbStatusFilter, fromDate, toDate, preview.Rows.Count);
        }

        private bool TryGetUnholdFilters(out string projectId, out string appRefNo, out string disbStatus, out DateTime? fromDate, out DateTime? toDate, out string errorMessage)
        {
            projectId = ddlUnholdProject.SelectedValue;
            appRefNo = (txtUnholdAppRefNo.Text ?? "").Trim();
            disbStatus = "On hold";
            fromDate = null;
            toDate = null;
            errorMessage = null;

            if (!string.IsNullOrEmpty((txtUnholdFromDisbDate.Text ?? "").Trim()))
            {
                fromDate = ParseDate(txtUnholdFromDisbDate.Text.Trim());
                if (!fromDate.HasValue) { errorMessage = "Invalid From Held Date (use dd/MM/yyyy)."; return false; }
            }

            if (!string.IsNullOrEmpty((txtUnholdToDisbDate.Text ?? "").Trim()))
            {
                toDate = ParseDate(txtUnholdToDisbDate.Text.Trim());
                if (!toDate.HasValue) { errorMessage = "Invalid To Held Date (use dd/MM/yyyy)."; return false; }
            }
            return true;
        }

        private void SaveUnholdPreviewCriteria(string projectId, string appRefNo, string disbStatus, DateTime? fromDate, DateTime? toDate, int rowCount)
        {
            ViewState["UnholdPreview_ProjectID"] = projectId ?? "";
            ViewState["UnholdPreview_AppRefNo"] = appRefNo ?? "";
            ViewState["UnholdPreview_DisbStatus"] = disbStatus ?? "";
            ViewState["UnholdPreview_FromDisbDate"] = fromDate.HasValue ? fromDate.Value.ToString("yyyy-MM-dd") : "";
            ViewState["UnholdPreview_ToDisbDate"] = toDate.HasValue ? toDate.Value.ToString("yyyy-MM-dd") : "";
            ViewState["UnholdPreview_RowCount"] = rowCount;
        }

        private bool TryGetSavedUnholdPreviewCriteria(out string projectId, out string appRefNo, out string disbStatus, out DateTime? fromDate, out DateTime? toDate, out int rowCount)
        {
            projectId = Convert.ToString(ViewState["UnholdPreview_ProjectID"]);
            appRefNo = Convert.ToString(ViewState["UnholdPreview_AppRefNo"]);
            disbStatus = Convert.ToString(ViewState["UnholdPreview_DisbStatus"]);
            fromDate = null;
            toDate = null;
            rowCount = 0;

            if (ViewState["UnholdPreview_ProjectID"] == null || ViewState["UnholdPreview_RowCount"] == null) return false;
            rowCount = Convert.ToInt32(ViewState["UnholdPreview_RowCount"]);

            DateTime d;
            string fromStr = Convert.ToString(ViewState["UnholdPreview_FromDisbDate"]);
            if (!string.IsNullOrEmpty(fromStr) && DateTime.TryParse(fromStr, out d)) fromDate = d;

            string toStr = Convert.ToString(ViewState["UnholdPreview_ToDisbDate"]);
            if (!string.IsNullOrEmpty(toStr) && DateTime.TryParse(toStr, out d)) toDate = d;

            return true;
        }

        private void ClearUnholdPreviewCache()
        {
            ViewState["UnholdPreview_ProjectID"] = null;
            ViewState["UnholdPreview_AppRefNo"] = null;
            ViewState["UnholdPreview_DisbStatus"] = null;
            ViewState["UnholdPreview_FromDisbDate"] = null;
            ViewState["UnholdPreview_ToDisbDate"] = null;
            ViewState["UnholdPreview_RowCount"] = null;
        }

        protected void btnPreviewReport_Click(object sender, EventArgs e)
        {
            string appRefFilter = (txtReportAppRefNo.Text ?? "").Trim();
            DateTime? fromDate = null;
            DateTime? toDate = null;

            if (!string.IsNullOrEmpty((txtReportFromDisbDate.Text ?? "").Trim()))
            {
                fromDate = ParseDate(txtReportFromDisbDate.Text.Trim());
                if (!fromDate.HasValue) { ShowMessage("Invalid report From Disbursement Date (use dd/MM/yyyy).", false); return; }
            }
            if (!string.IsNullOrEmpty((txtReportToDisbDate.Text ?? "").Trim()))
            {
                toDate = ParseDate(txtReportToDisbDate.Text.Trim());
                if (!toDate.HasValue) { ShowMessage("Invalid report To Disbursement Date (use dd/MM/yyyy).", false); return; }
            }

            string projectId = ddlReportProject.SelectedValue;
            DataTable dt = ExecuteReader("Proc_HF48_BulkPostpone_FullDisbReport", delegate(SqlCommand c)
            {
                c.Parameters.AddWithValue("@Property_ProjectID", string.IsNullOrEmpty(projectId) ? (object)DBNull.Value : projectId);
                c.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefFilter) ? (object)DBNull.Value : appRefFilter);
                c.Parameters.AddWithValue("@FromDisbDate", fromDate.HasValue ? (object)fromDate.Value : DBNull.Value);
                c.Parameters.AddWithValue("@ToDisbDate", toDate.HasValue ? (object)toDate.Value : DBNull.Value);
            });

            Session["MakerReportData"] = dt;
            gvFullReport.DataSource = dt;
            gvFullReport.DataBind();
            lblReportSummary.Text = string.Format("Report: {0} row(s).", dt.Rows.Count);
        }

        protected void btnClearReportFilters_Click(object sender, EventArgs e)
        {
            ddlReportProject.SelectedIndex = 0;
            txtReportAppRefNo.Text = "";
            txtReportFromDisbDate.Text = "";
            txtReportToDisbDate.Text = "";
            gvFullReport.DataSource = null;
            gvFullReport.DataBind();
            lblReportSummary.Text = "";
            Session["MakerReportData"] = null;
        }

        protected void btnExportReportCSV_Click(object sender, EventArgs e)
        {
            DataTable dt = Session["MakerReportData"] as DataTable;
            if (dt == null || dt.Rows.Count == 0)
            {
                ShowMessage("No report data to export. Run report preview first.", false);
                return;
            }
            ExportDataTableToCsv(dt, "BulkPostponement_FullReport_" + DateTime.Now.ToString("yyyyMMdd") + ".csv");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            bool isHold = (hfMode.Value ?? "Hold") == "Hold";
            bool isPostpone = hfMode.Value == "Postpone";

            if (string.IsNullOrEmpty((txtReason.Text ?? "").Trim()))
            {
                ShowMessage("Reason is required.", false);
                return;
            }

            int shiftDays = 0;
            string projectId = null;
            int sourceId = 0;
            string appRefFilter = null;
            string disbStatusFilter = null;
            DateTime? fromDate = null;
            DateTime? toDate = null;

            if (isHold || isPostpone)
            {
                string savedMode;
                int previewRows;
                if (!TryGetSavedMakerPreviewCriteria(out projectId, out shiftDays, out appRefFilter, out disbStatusFilter, out fromDate, out toDate, out savedMode, out previewRows))
                {
                    ShowMessage("Run Preview before submitting.", false);
                    return;
                }
                if (!string.Equals(savedMode, hfMode.Value, StringComparison.OrdinalIgnoreCase))
                {
                    ShowMessage("Mode changed after preview. Click Preview again.", false);
                    return;
                }
                if (previewRows <= 0)
                {
                    ShowMessage("Preview has no rows. Nothing to submit.", false);
                    return;
                }
            }
            else
            {
                int cachedUnholdRows;
                if (!TryGetSavedUnholdPreviewCriteria(out projectId, out appRefFilter, out disbStatusFilter, out fromDate, out toDate, out cachedUnholdRows) || string.IsNullOrEmpty(projectId))
                {
                    ShowMessage("Preview Unhold rows first, then submit.", false);
                    return;
                }

                string currentProjectId;
                string currentAppRef;
                string currentDisbStatus;
                DateTime? currentFrom;
                DateTime? currentTo;
                string currentError;
                if (!TryGetUnholdFilters(out currentProjectId, out currentAppRef, out currentDisbStatus, out currentFrom, out currentTo, out currentError))
                {
                    ShowMessage(currentError, false);
                    return;
                }

                if (cachedUnholdRows <= 0)
                {
                    ShowMessage("Unhold preview has no rows. Nothing to submit.", false);
                    return;
                }

                bool changed = false;
                changed = changed || !string.Equals(projectId ?? "", currentProjectId ?? "", StringComparison.OrdinalIgnoreCase);
                changed = changed || !string.Equals(appRefFilter ?? "", currentAppRef ?? "", StringComparison.OrdinalIgnoreCase);
                changed = changed || !string.Equals(disbStatusFilter ?? "", currentDisbStatus ?? "", StringComparison.OrdinalIgnoreCase);
                changed = changed || (fromDate.HasValue != currentFrom.HasValue) || (fromDate.HasValue && currentFrom.HasValue && fromDate.Value.Date != currentFrom.Value.Date);
                changed = changed || (toDate.HasValue != currentTo.HasValue) || (toDate.HasValue && currentTo.HasValue && toDate.Value.Date != currentTo.Value.Date);

                if (changed)
                {
                    ShowMessage("Unhold filters changed after preview. Click Preview again, then submit.", false);
                    return;
                }

                shiftDays = 0;
            }

            string status;
            string message;
            int requestId;
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand("Proc_HF48_BulkPostpone_Submit", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RequestType", isHold ? "Hold" : (isPostpone ? "Postpone" : "Unhold"));
                cmd.Parameters.AddWithValue("@Property_ProjectID", (object)projectId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ShiftDays", shiftDays);
                cmd.Parameters.AddWithValue("@SourceRequestID", sourceId == 0 ? (object)DBNull.Value : sourceId);
                cmd.Parameters.AddWithValue("@Reason", txtReason.Text.Trim());
                cmd.Parameters.AddWithValue("@MakerUser", CurrentUser);
                cmd.Parameters.AddWithValue("@DraftID", hfDraftId.Value);
                cmd.Parameters.AddWithValue("@AppRefNo", string.IsNullOrEmpty(appRefFilter) ? (object)DBNull.Value : appRefFilter);
                cmd.Parameters.AddWithValue("@DisbStatus", string.IsNullOrEmpty(disbStatusFilter) ? (object)DBNull.Value : disbStatusFilter);
                cmd.Parameters.AddWithValue("@FromDisbDate", fromDate.HasValue ? (object)fromDate.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@ToDisbDate", toDate.HasValue ? (object)toDate.Value : DBNull.Value);

                SqlParameter pId = cmd.Parameters.Add("@RequestID", SqlDbType.Int);
                pId.Direction = ParameterDirection.Output;
                SqlParameter pSt = cmd.Parameters.Add("@Status", SqlDbType.NVarChar, 50);
                pSt.Direction = ParameterDirection.Output;
                SqlParameter pMs = cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 500);
                pMs.Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();

                requestId = pId.Value == DBNull.Value ? 0 : Convert.ToInt32(pId.Value);
                status = Convert.ToString(pSt.Value);
                message = Convert.ToString(pMs.Value);
            }

            ShowMessage(message, status == "SUCCESS");
            if (status == "SUCCESS" && requestId > 0)
            {
                txtReason.Text = "";
                hfDraftId.Value = Guid.NewGuid().ToString("N");
                gvPreview.DataSource = null;
                gvPreview.DataBind();
                gvUnholdPreview.DataSource = null;
                gvUnholdPreview.DataBind();
                lblPreviewSummary.Text = "";
                lblUnholdPreviewSummary.Text = "";
                ClearMakerPreviewCache();
                ClearUnholdPreviewCache();
            }
        }

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            Session["UserID"] = (txtCurrentUser.Text ?? "").Trim();
            ShowMessage("Acting user set to: " + CurrentUser, true);
        }

        private DataTable ExecuteReader(string procName, Action<SqlCommand> bindParams)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConnStr))
            using (SqlCommand cmd = new SqlCommand(procName, conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (bindParams != null) bindParams(cmd);
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    conn.Open();
                    da.Fill(dt);
                }
            }
            return dt;
        }

        private void ExportDataTableToCsv(DataTable dt, string fileName)
        {
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.AddHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if (i > 0) sb.Append(",");
                sb.Append(CsvEscape(dt.Columns[i].ColumnName));
            }
            sb.AppendLine();
            foreach (DataRow row in dt.Rows)
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    sb.Append(CsvEscape(Convert.ToString(row[i])));
                }
                sb.AppendLine();
            }
            Response.Write(sb.ToString());
            Response.End();
        }

        private static string CsvEscape(string v)
        {
            if (string.IsNullOrEmpty(v)) return "";
            if (v.Contains(",") || v.Contains("\"") || v.Contains("\n") || v.Contains("\r"))
                return "\"" + v.Replace("\"", "\"\"") + "\"";
            return v;
        }

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible = true;
            lblMessage.Text = message;
            pnlMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }

        private DateTime? ParseDate(string text)
        {
            if (string.IsNullOrEmpty(text)) return null;
            DateTime d;
            if (DateTime.TryParseExact(text.Trim(), "dd/MM/yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out d)) return d;
            if (DateTime.TryParseExact(text.Trim(), "yyyy-MM-dd",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out d)) return d;
            if (DateTime.TryParse(text.Trim(), out d)) return d;
            return null;
        }

        protected void gvFullReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvFullReport.PageIndex = e.NewPageIndex;
            DataTable dt = Session["MakerReportData"] as DataTable;
            if (dt == null)
            {
                ShowMessage("Session expired. Run Preview again.", false);
                return;
            }
            gvFullReport.DataSource = dt;
            gvFullReport.DataBind();
        }
            pnlMessage.Visible = true;
            lblMessage.Text = Server.HtmlEncode(message);
            pnlMessage.CssClass = isSuccess ? "msg-success" : "msg-error";
        }
    }
}
