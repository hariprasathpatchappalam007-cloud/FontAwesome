<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="HF48BulkPostponementChecker.aspx.cs" Inherits="HF48Workflow.HF48BulkPostponementChecker" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HF48 Bulk Hold / Unhold - Checker</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; padding: 0; background-color: #ccccff; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; border-radius: 4px 4px 0 0; }
        .panel-header.checker { background-color: #FF6600; }
        .panel-header.audit { background-color: #003366; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 160px; font-weight: bold; font-size: 13px; color: #333; vertical-align: top; }
        .form-group input, .form-group select, .form-group textarea { padding: 5px 8px; border: 1px solid #ccc; border-radius: 3px; font-size: 13px; }
        .btn { padding: 8px 18px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-success { background-color: #28a745; color: white; }
        .btn-success:hover { background-color: #218838; }
        .btn-danger { background-color: #dc3545; color: white; }
        .btn-danger:hover { background-color: #c82333; }
        .btn-info { background-color: #17a2b8; color: white; }
        .btn-info:hover { background-color: #138496; }
        .btn-sm  { padding: 3px 8px; font-size: 11px; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px 10px; text-align: left; font-size: 12px; }
        .gridview td { padding: 6px 10px; border-bottom: 1px solid #eee; }
        .gridview tr:hover { background-color: #f5f5f5 !important; }
        .grp-1 { background-color: #fff3cd; }
        .grp-2 { background-color: #d1ecf1; }
        .grp-3 { background-color: #d4edda; }
        .grp-4 { background-color: #f8d7da; }
        .grp-5 { background-color: #e2d6f3; }
        .grp-6 { background-color: #ffe5cc; }
        .new-date { color: #28a745; font-weight: bold; }
        .old-date { color: #999; text-decoration: line-through; }
        .status-pill { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: bold; color: white; }
        .status-Disbursed { background-color: #28a745; }
        .status-NotDisbursed { background-color: #6c757d; }
        .status-Hold { background-color: #FF6600; }
        .who-bar { background: #fff8d8; border: 1px dashed #d8b400; padding: 8px 12px; margin-bottom: 15px; font-size: 12px; }
        .action-tabs { margin-bottom: 10px; }
        .action-tabs .tab { display: inline-block; padding: 6px 18px; cursor: pointer; background: #e0e0e0; border: 1px solid #ccc; border-bottom: none; border-radius: 4px 4px 0 0; margin-right: 2px; font-size: 13px; }
        .action-tabs .tab.active { background: #FF6600; color: white; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h1>HF48 Bulk Postponement / Hold / Unhold</h1>
            <h2>Checker action console</h2>
        </div>

        <div class="container">
            <asp:Panel ID="pnlMessage" runat="server" Visible="false">
                <asp:Label ID="lblMessage" runat="server" />
            </asp:Panel>

            <div class="who-bar">
                <strong>Acting As:</strong>
                <asp:TextBox ID="txtCurrentUser" runat="server" Width="180px" />
                <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-info" OnClick="btnSetUser_Click" />
                &nbsp;|&nbsp;<a href="HF48BulkPostponementMaker.aspx" style="font-weight:bold;color:#003366;">Go to Maker Page</a>
            </div>

            <div class="action-tabs">
                <asp:HiddenField ID="hfCheckerTab" runat="server" Value="Pending" />
                <asp:LinkButton ID="lnkCheckerTabPending" runat="server" CssClass="tab active" OnClick="lnkCheckerTabPending_Click">Pending Approvals</asp:LinkButton>
                <asp:LinkButton ID="lnkCheckerTabAction" runat="server" CssClass="tab" OnClick="lnkCheckerTabAction_Click">Action</asp:LinkButton>
                <asp:LinkButton ID="lnkCheckerTabHistory" runat="server" CssClass="tab" OnClick="lnkCheckerTabHistory_Click">History</asp:LinkButton>
            </div>

            <asp:Panel ID="pnlPendingTab" runat="server" CssClass="panel">
                <div class="panel-header checker">Pending Approvals</div>
                <div class="panel-body">
                    <asp:GridView ID="gvPending" runat="server" CssClass="gridview" AutoGenerateColumns="False" DataKeyNames="RequestID" OnRowCommand="gvPending_RowCommand" EmptyDataText="No pending requests.">
                        <Columns>
                            <asp:BoundField DataField="RequestID" HeaderText="Req #" />
                            <asp:BoundField DataField="RequestType" HeaderText="Type" />
                            <asp:BoundField DataField="Property_ProjectName" HeaderText="Project" />
                            <asp:BoundField DataField="Property_DeveloperName" HeaderText="Developer" />
                            <asp:BoundField DataField="ShiftDays" HeaderText="Shift (d)" />
                            <asp:BoundField DataField="AffectedAppCount" HeaderText="Apps" />
                            <asp:BoundField DataField="AffectedRowCount" HeaderText="Schedules" />
                            <asp:BoundField DataField="MakerUser" HeaderText="Maker" />
                            <asp:BoundField DataField="MakerOn" HeaderText="Submitted" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            <asp:BoundField DataField="Reason" HeaderText="Reason" />
                            <asp:TemplateField HeaderText="Action">
                                <ItemTemplate>
                                    <asp:Button ID="btnView" runat="server" Text="View" CssClass="btn btn-info btn-sm" CommandName="ViewRequest" CommandArgument='<%# Eval("RequestID") %>' />
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>
            </asp:Panel>

            <asp:Panel ID="pnlActionTab" runat="server" Visible="false" CssClass="panel">
                <div class="panel-header checker">
                    Request #<asp:Label ID="lblReqId" runat="server" />
                    <asp:Label ID="lblReqType" runat="server" />
                    <span style="float:right;font-weight:normal;">
                        Project: <asp:Label ID="lblReqProject" runat="server" />
                        &nbsp;|&nbsp; Maker: <asp:Label ID="lblReqMaker" runat="server" />
                        &nbsp;|&nbsp; Shift: <asp:Label ID="lblReqShift" runat="server" /> days
                    </span>
                </div>
                <div class="panel-body">
                    <asp:HiddenField ID="hfSelectedRequestId" runat="server" />
                    <asp:HiddenField ID="hfSelectedRequestType" runat="server" />

                    <div class="form-group"><label>Maker Reason:</label><asp:Label ID="lblReqReason" runat="server" /></div>

                    <div class="form-group">
                        <label>Attached Documents:</label>
                        <asp:Repeater ID="rptDocs" runat="server">
                            <HeaderTemplate><ul style="display:inline-block;margin:0;padding-left:18px;"></HeaderTemplate>
                            <ItemTemplate>
                                <li><a href='<%# ResolveUrl((string)Eval("StoredPath")) %>' target="_blank"><%# Eval("OriginalName") %></a>
                                    <small style="color:#888;"> (<%# String.Format("{0:N0}", Eval("SizeBytes")) %> bytes)</small></li>
                            </ItemTemplate>
                            <FooterTemplate></ul></FooterTemplate>
                        </asp:Repeater>
                        <asp:Label ID="lblNoDocs" runat="server" Text="(none)" Visible="false" />
                    </div>

                    <asp:GridView ID="gvDetail" runat="server" CssClass="gridview" AutoGenerateColumns="False" OnRowDataBound="gvDetail_RowDataBound" EmptyDataText="No detail rows.">
                        <Columns>
                            <asp:BoundField DataField="APP_REF_NO" HeaderText="App Ref No" />
                            <asp:BoundField DataField="Lead_No" HeaderText="Lead No" />
                            <asp:BoundField DataField="Customer_Name" HeaderText="Customer" />
                            <asp:BoundField DataField="lead_stage" HeaderText="Lead Stage" />
                            <asp:BoundField DataField="ProductCode" HeaderText="Product Code" />
                            <asp:TemplateField HeaderText="Inception Date">
                                <ItemTemplate>
                                    <span style="color:#888;font-style:italic;">
                                        <%# (Eval("InceptionDisbDate") == DBNull.Value || Eval("InceptionDisbDate") == null) ? "-" : string.Format("{0:dd/MM/yyyy}", Eval("InceptionDisbDate")) %>
                                    </span>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField HeaderText="Old Disb. Date"><ItemTemplate><span class="old-date"><%# Eval("OldDisbDate", "{0:dd/MM/yyyy}") %></span></ItemTemplate></asp:TemplateField>
                            <asp:TemplateField HeaderText="New Disb. Date"><ItemTemplate><span class="new-date"><%# Eval("NewDisbDate", "{0:dd/MM/yyyy}") %></span></ItemTemplate></asp:TemplateField>
                            <asp:BoundField DataField="Disb_amount" HeaderText="Disb Amount" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="finance_amount" HeaderText="Finance Amount" DataFormatString="{0:N2}" />
                            <asp:TemplateField HeaderText="Status (at submission)"><ItemTemplate><span class='status-pill status-<%# Eval("disb_status").ToString().Replace(" ","") %>'><%# Eval("disb_status") %></span></ItemTemplate></asp:TemplateField>
                            <asp:BoundField DataField="PropertyPaymentPct" HeaderText="Property Pmt %" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="FinancePaymentPct" HeaderText="Finance Pmt %" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="MilestonePaymentPct" HeaderText="Milestone %" DataFormatString="{0:N2}" />
                            <asp:BoundField DataField="dev_tier" HeaderText="Tier" />
                            <asp:BoundField DataField="value_tranche" HeaderText="Project Status" />
                            <asp:TemplateField HeaderText="Applied?">
                                <ItemTemplate>
                                    <span style='color:<%# Convert.ToBoolean(Eval("Applied")) ? "#28a745" : "#999" %>;font-weight:bold;'>
                                        <%# Convert.ToBoolean(Eval("Applied")) ? "Yes" : "Pending" %>
                                    </span>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>

                    <div class="form-group" style="margin-top:15px;">
                        <label>Checker Remarks:</label>
                        <asp:TextBox ID="txtCheckerRemarks" runat="server" Width="700px" TextMode="MultiLine" Rows="2" />
                    </div>
                    <div>
                        <asp:Button ID="btnApprove" runat="server" Text="Approve and Apply" CssClass="btn btn-success" OnClick="btnApprove_Click" OnClientClick="return confirm('Approve this request?');" />
                        <asp:Button ID="btnReject" runat="server" Text="Reject" CssClass="btn btn-danger" OnClick="btnReject_Click" OnClientClick="return confirm('Reject this request? Remarks are required.');" />
                    </div>
                </div>
            </asp:Panel>

            <asp:Panel ID="pnlHistoryTab" runat="server" Visible="false" CssClass="panel">
                <div class="panel-header audit">History (Approved / Rejected / Released)</div>
                <div class="panel-body">
                    <asp:GridView ID="gvHistory" runat="server" CssClass="gridview" AutoGenerateColumns="False" AllowPaging="True" PageSize="15" OnPageIndexChanging="gvHistory_PageIndexChanging" EmptyDataText="No closed requests yet.">
                        <Columns>
                            <asp:BoundField DataField="RequestID" HeaderText="Req #" />
                            <asp:BoundField DataField="RequestType" HeaderText="Type" />
                            <asp:BoundField DataField="Property_ProjectName" HeaderText="Project" />
                            <asp:BoundField DataField="ShiftDays" HeaderText="Shift (d)" />
                            <asp:BoundField DataField="AffectedAppCount" HeaderText="Apps" />
                            <asp:BoundField DataField="AffectedRowCount" HeaderText="Schedules" />
                            <asp:BoundField DataField="Status" HeaderText="Status" />
                            <asp:BoundField DataField="MakerUser" HeaderText="Maker" />
                            <asp:BoundField DataField="MakerOn" HeaderText="Submitted" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            <asp:BoundField DataField="CheckerUser" HeaderText="Checker" />
                            <asp:BoundField DataField="CheckerOn" HeaderText="Decided" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            <asp:BoundField DataField="CheckerRemarks" HeaderText="Checker Remarks" />
                        </Columns>
                    </asp:GridView>
                </div>
            </asp:Panel>
        </div>
    </form>
</body>
</html>
