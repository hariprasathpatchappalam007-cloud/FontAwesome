<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="TakafulProductMaster.aspx.cs" Inherits="HF48Workflow.TakafulProductMaster" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Takaful Product Master - Maker Checker</title>
    <style type="text/css">
        body { font-family: Segoe UI, Arial, sans-serif; margin: 0; padding: 0; background-color: #ccccff; }
        .header { background-color: #003366; color: white; padding: 15px 30px; }
        .header h1 { margin: 0; font-size: 20px; }
        .header h2 { margin: 2px 0 0 0; font-size: 13px; font-weight: normal; color: #99ccff; }
        .container { padding: 20px 30px; }
        .panel { background: #e6e6fa; border: 1px solid #b0b0d6; border-radius: 4px; margin-bottom: 20px; }
        .panel-header { background-color: #6c7ae0; color: white; padding: 10px 15px; font-weight: bold; font-size: 14px; border-radius: 4px 4px 0 0; }
        .panel-body { padding: 15px; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: inline-block; width: 150px; font-weight: bold; font-size: 13px; color: #333; vertical-align: top; padding-top: 4px; }
        .form-group input, .form-group select, .form-group textarea { padding: 5px 8px; border: 1px solid #ccc; border-radius: 3px; font-size: 13px; }
        .btn { padding: 7px 16px; border: none; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: bold; margin-right: 5px; }
        .btn-primary  { background-color: #003366; color: white; }
        .btn-primary:hover  { background-color: #004488; }
        .btn-success  { background-color: #28a745; color: white; }
        .btn-success:hover  { background-color: #218838; }
        .btn-danger   { background-color: #dc3545; color: white; }
        .btn-danger:hover   { background-color: #c82333; }
        .btn-warning  { background-color: #FF6600; color: white; }
        .btn-warning:hover  { background-color: #e65c00; }
        .btn-info     { background-color: #17a2b8; color: white; }
        .btn-info:hover     { background-color: #138496; }
        .btn-secondary{ background-color: #6c757d; color: white; }
        .btn-secondary:hover{ background-color: #545b62; }
        .msg-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .msg-error   { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 3px; margin-bottom: 10px; }
        .gridview { width: 100%; border-collapse: collapse; font-size: 12px; }
        .gridview th { background-color: #507CD1; color: white; padding: 8px 10px; text-align: left; font-size: 12px; white-space: nowrap; }
        .gridview td { padding: 6px 10px; border-bottom: 1px solid #eee; vertical-align: middle; }
        .gridview tr:hover { background-color: #f5f5f5; }
        .gridview tr.alt  { background-color: #EFF3FB; }
        .tab-bar { margin-bottom: 0; border-bottom: 2px solid #003366; }
        .tab-bar input[type=button] { padding: 8px 20px; cursor: pointer; background-color: #e0e0e0; border: 1px solid #ccc; border-bottom: none; border-radius: 4px 4px 0 0; margin-right: 2px; font-size: 13px; font-weight: bold; }
        .tab-bar input.tab-active { background-color: #003366; color: white; border-color: #003366; }
        .required { color: red; font-weight: bold; }
        .badge-pending  { background: #ffc107; color: #333; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: bold; }
        .badge-approved { background: #28a745; color: white; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: bold; }
        .badge-rejected { background: #dc3545; color: white; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: bold; }
        .rate-new  { color: #003366; font-weight: bold; }
        .rate-diff { color: #FF6600; font-weight: bold; }
        .info-box { background: #fff3cd; border: 1px solid #ffc107; padding: 8px 12px; border-radius: 3px; margin-bottom: 10px; font-size: 12px; color: #856404; }
        .who-bar  { background: #fff8d8; border: 1px dashed #d8b400; padding: 8px 14px; margin-bottom: 15px; font-size: 12px; border-radius: 3px; }
    </style>
    <script type="text/javascript">
        function showTab(tabName) {
            var tabs = ['tabMaker', 'tabChecker', 'tabAllProducts', 'tabHistory'];
            for (var i = 0; i < tabs.length; i++) {
                var pnl = document.getElementById(tabs[i]);
                var btn = document.getElementById('btn_' + tabs[i]);
                if (pnl) pnl.style.display = (tabs[i] === tabName) ? 'block' : 'none';
                if (btn) {
                    if (tabs[i] === tabName) btn.className = 'tab-active';
                    else btn.className = '';
                }
            }
            var hf = document.getElementById('<%= hfActiveTab.ClientID %>');
            if (hf) hf.value = tabName;
        }

        function confirmReject(btn) {
            var row = btn.parentNode;
            while (row && row.tagName.toUpperCase() !== 'TR') { row = row.parentNode; }
            if (!row) { alert('Please enter rejection remarks.'); return false; }
            var inputs = row.getElementsByTagName('textarea');
            var remarks = '';
            for (var i = 0; i < inputs.length; i++) {
                if (inputs[i].id && inputs[i].id.indexOf('txtCheckerRowRemarks') >= 0) {
                    remarks = inputs[i].value;
                    break;
                }
            }
            if (!remarks || !remarks.trim()) {
                alert('Rejection remarks are mandatory. Please enter remarks before rejecting.');
                return false;
            }
            return confirm('Are you sure you want to REJECT this product?');
        }

        function confirmApprove() {
            return confirm('Are you sure you want to APPROVE this product?\nThis will update the live Takaful_Vendor_Master rates.');
        }

        window.onload = function () {
            var hf = document.getElementById('<%= hfActiveTab.ClientID %>');
            var tab = (hf && hf.value) ? hf.value : 'tabMaker';
            showTab(tab);
        };
    </script>
</head>
<body>
    <form id="form1" runat="server">
        <div class="header">
            <h1>Takaful Product Master</h1>
            <h2>Maker-Checker Workflow | Rate Management</h2>
        </div>

        <div class="container">

            <!-- Switch User bar (for testing Maker/Checker on same browser) -->
            <div class="who-bar">
                <strong>Acting As:</strong>
                <asp:TextBox ID="txtCurrentUser" runat="server" Width="180px" />
                <asp:Button ID="btnSetUser" runat="server" Text="Switch User" CssClass="btn btn-info"
                    OnClick="btnSetUser_Click" />
                &nbsp;<em style="color:#777;">(Production uses <code>Session[&quot;UserID&quot;]</code> — use this textbox to swap between Maker and Checker roles in testing.)</em>
            </div>

            <!-- Status Message -->
            <asp:Panel ID="pnlMessage" runat="server" Visible="false">
                <asp:Label ID="lblMessage" runat="server" />
            </asp:Panel>

            <!-- Hidden fields -->
            <asp:HiddenField ID="hfActiveTab" runat="server" Value="tabMaker" />
            <asp:HiddenField ID="hfSRNO"      runat="server" Value="0" />

            <!-- ======================================= -->
            <!-- TAB BAR                                 -->
            <!-- ======================================= -->
            <div class="tab-bar">
                <input type="button" id="btn_tabMaker"       value="Maker - Submit Product"  onclick="showTab('tabMaker')" />
                <input type="button" id="btn_tabChecker"     value="Checker - Pending Approvals" onclick="showTab('tabChecker')" />
                <input type="button" id="btn_tabAllProducts" value="All Products"            onclick="showTab('tabAllProducts')" />
                <input type="button" id="btn_tabHistory"     value="Change History"          onclick="showTab('tabHistory')" />
            </div>

            <!-- ======================================= -->
            <!-- TAB 1: MAKER                            -->
            <!-- ======================================= -->
            <div id="tabMaker" style="display:none;">

                <div class="panel" style="margin-top:0; border-top-left-radius:0;">
                    <div class="panel-header">Submit Product Rate (Maker)</div>
                    <div class="panel-body">
                        <div class="info-box">
                            You are logged in as: <strong><asp:Label ID="lblCurrentUser" runat="server" /></strong> (Maker).
                            <br />
                            &bull; <strong>Create new product:</strong> fill the form below with a new Product Code and click <em>Submit for Approval</em>.<br />
                            &bull; <strong>Update existing rate:</strong> click <strong>Propose Rate Change</strong> on any approved product in the grid below, adjust the rate, then click <em>Submit for Approval</em>. The live rate stays unchanged until the Checker approves.
                        </div>

                        <div class="form-group">
                            <label>Product Code <span class="required">*</span></label>
                            <asp:TextBox ID="txtProductCode" runat="server" Width="180px" MaxLength="50" />
                            &nbsp;<small style="color:#666;">(e.g. Tkfl011 &mdash; must be unique for new; auto-filled when proposing a change)</small>
                        </div>
                        <div class="form-group">
                            <label>Vendor Name <span class="required">*</span></label>
                            <asp:TextBox ID="txtVendorName" runat="server" Width="300px" MaxLength="200" />
                        </div>
                        <div class="form-group">
                            <label>Product Type <span class="required">*</span></label>
                            <asp:DropDownList ID="ddlProductType" runat="server" Width="130px">
                                <asp:ListItem Text="-- Select --" Value="" />
                                <asp:ListItem Text="DIB"   Value="DIB" />
                                <asp:ListItem Text="Staff" Value="Staff" />
                                <asp:ListItem Text="GHP"   Value="GHP" />
                                <asp:ListItem Text="SZHP"  Value="SZHP" />
                            </asp:DropDownList>
                        </div>
                        <div class="form-group">
                            <label>Rate <span class="required">*</span></label>
                            <asp:TextBox ID="txtRate" runat="server" Width="180px" MaxLength="20" />
                            &nbsp;<small style="color:#666;">(e.g. 0.0001849)</small>
                        </div>
                        <div style="margin-top:12px;">
                            <asp:Button ID="btnSaveProduct" runat="server" Text="Submit for Approval"
                                CssClass="btn btn-primary" OnClick="btnSaveProduct_Click" />
                            <asp:Button ID="btnClearForm" runat="server" Text="Clear" CssClass="btn btn-secondary"
                                OnClick="btnClearForm_Click" CausesValidation="false" />
                        </div>
                    </div>
                </div>

                <!-- Approved Products Grid (for proposing rate changes) -->
                <div class="panel">
                    <div class="panel-header">Existing Approved Products &mdash; Click &ldquo;Propose Rate Change&rdquo; to update a rate</div>
                    <div class="panel-body">
                        <p style="font-size:12px;color:#555;margin:0 0 8px 0;">
                            Selecting a product loads it into the form above. Only the <strong>Rate</strong> field is editable; the Product Code is locked.
                            The current live rate is preserved until the Checker approves your change.
                        </p>
                        <asp:GridView ID="gvApprovedProducts" runat="server" CssClass="gridview"
                            AutoGenerateColumns="False"
                            DataKeyNames="SRNO"
                            OnRowCommand="gvApprovedProducts_RowCommand"
                            EmptyDataText="No approved products found."
                            AlternatingRowStyle-CssClass="alt">
                            <Columns>
                                <asp:BoundField DataField="ProductCode" HeaderText="Product Code" />
                                <asp:BoundField DataField="VendorName"  HeaderText="Vendor" />
                                <asp:BoundField DataField="ProductType" HeaderText="Type" />
                                <asp:BoundField DataField="Rate"        HeaderText="Current Live Rate" DataFormatString="{0:N10}" ItemStyle-CssClass="rate-new" />
                                <asp:BoundField DataField="CheckerID"   HeaderText="Approved By" />
                                <asp:BoundField DataField="CheckerDate" HeaderText="Approved On" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                                <asp:BoundField DataField="UpdatedOn_Date" HeaderText="Last Updated" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                                <asp:TemplateField HeaderText="Action">
                                    <ItemTemplate>
                                        <asp:Button ID="btnProposeChange" runat="server"
                                            Text="Propose Rate Change"
                                            CssClass="btn btn-warning"
                                            CommandName="ProposeChange"
                                            CommandArgument='<%# Eval("SRNO") %>'
                                            OnClientClick="return confirm('Load this product into the form to propose a rate change?');" />
                                        &nbsp;
                                        <asp:Button ID="btnViewHistory" runat="server"
                                            Text="History"
                                            CssClass="btn btn-info"
                                            CommandName="ViewHistory"
                                            CommandArgument='<%# Eval("ProductCode") %>' />
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                        </asp:GridView>
                    </div>
                </div>

                <!-- My Submissions Grid -->
                <div class="panel">
                    <div class="panel-header">My Submissions (Pending / Rejected)</div>
                    <div class="panel-body">
                        <asp:GridView ID="gvMySubmissions" runat="server" CssClass="gridview"
                            AutoGenerateColumns="False"
                            OnRowCommand="gvMySubmissions_RowCommand"
                            EmptyDataText="No submissions found."
                            AlternatingRowStyle-CssClass="alt">
                            <Columns>
                                <asp:BoundField DataField="SRNO"        HeaderText="No" />
                                <asp:BoundField DataField="ProductCode" HeaderText="Product Code" />
                                <asp:BoundField DataField="VendorName"  HeaderText="Vendor" />
                                <asp:BoundField DataField="ProductType" HeaderText="Type" />
                                <asp:BoundField DataField="Rate"        HeaderText="Rate" DataFormatString="{0:N10}" />
                                <asp:BoundField DataField="StatusDesc"  HeaderText="Status" />
                                <asp:BoundField DataField="MakerDate"   HeaderText="Submitted On" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                                <asp:BoundField DataField="CheckerID"   HeaderText="Checker" />
                                <asp:BoundField DataField="CheckerRemarks" HeaderText="Checker Remarks" />
                                <asp:TemplateField HeaderText="Action">
                                    <ItemTemplate>
                                        <asp:Button ID="btnLoadEdit" runat="server"
                                            Text="Edit / Re-Submit"
                                            CssClass="btn btn-warning"
                                            CommandName="LoadEdit"
                                            CommandArgument='<%# Eval("SRNO") %>'
                                            Visible='<%# Eval("Status").ToString() == "R" || Eval("Status").ToString() == "P" %>' />
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                        </asp:GridView>
                    </div>
                </div>
            </div>

            <!-- ======================================= -->
            <!-- TAB 2: CHECKER                          -->
            <!-- ======================================= -->
            <div id="tabChecker" style="display:none;">
                <div class="panel" style="margin-top:0; border-top-left-radius:0;">
                    <div class="panel-header">Pending Approvals (Checker)</div>
                    <div class="panel-body">
                        <div class="info-box">
                            You are logged in as: <strong><asp:Label ID="lblCurrentUserChecker" runat="server" /></strong> (Checker).
                            Review each pending submission. Enter remarks before Rejecting. Maker and Checker <strong>cannot</strong> be the same user.
                        </div>
                        <asp:GridView ID="gvPendingApprovals" runat="server" CssClass="gridview"
                            AutoGenerateColumns="False"
                            OnRowCommand="gvPendingApprovals_RowCommand"
                            EmptyDataText="No pending approvals."
                            AlternatingRowStyle-CssClass="alt">
                            <Columns>
                                <asp:BoundField DataField="SRNO"               HeaderText="No" />
                                <asp:BoundField DataField="ProductCode"        HeaderText="Product Code" />
                                <asp:BoundField DataField="VendorName"         HeaderText="Vendor" />
                                <asp:BoundField DataField="ProductType"        HeaderText="Type" />
                                <asp:TemplateField HeaderText="Current Live Rate">
                                    <HeaderStyle ForeColor="White" BackColor="#507CD1" />
                                    <ItemTemplate>
                                        <span style="color:#999;text-decoration:line-through;font-size:12px;">
                                            <%# (Eval("CurrentApprovedRate") == DBNull.Value || Eval("CurrentApprovedRate") == null)
                                                ? "(New Vendor)"
                                                : string.Format("{0:N10}", Eval("CurrentApprovedRate")) %>
                                        </span>
                                    </ItemTemplate>
                                </asp:TemplateField>
                                <asp:TemplateField HeaderText="Proposed Rate">
                                    <HeaderStyle ForeColor="White" BackColor="#507CD1" />
                                    <ItemTemplate>
                                        <span style="color:#28a745;font-weight:bold;font-size:12px;">
                                            <%# string.Format("{0:N10}", Eval("ProposedRate")) %>
                                        </span>
                                    </ItemTemplate>
                                </asp:TemplateField>
                                <asp:TemplateField HeaderText="Change">
                                    <HeaderStyle ForeColor="White" BackColor="#507CD1" />
                                    <ItemTemplate>
                                        <span style="font-weight:bold;color:#FF6600;"><%# Eval("ChangeType") %></span>
                                    </ItemTemplate>
                                </asp:TemplateField>
                                <asp:BoundField DataField="MakerID"            HeaderText="Maker" />
                                <asp:BoundField DataField="MakerDate"          HeaderText="Submitted On" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                                <asp:TemplateField HeaderText="Checker Remarks">
                                    <ItemTemplate>
                                        <asp:TextBox ID="txtCheckerRowRemarks" runat="server"
                                            Width="160px" TextMode="MultiLine" Rows="2"
                                            placeholder="Enter remarks (required for Reject)" />
                                    </ItemTemplate>
                                </asp:TemplateField>
                                <asp:TemplateField HeaderText="Action">
                                    <ItemTemplate>
                                        <asp:Button ID="btnRowApprove" runat="server"
                                            Text="Approve" CssClass="btn btn-success"
                                            CommandName="ApproveProduct"
                                            CommandArgument='<%# Eval("SRNO") %>'
                                            OnClientClick="return confirmApprove();" />
                                        &nbsp;
                                        <asp:Button ID="btnRowReject" runat="server"
                                            Text="Reject" CssClass="btn btn-danger"
                                            CommandName="RejectProduct"
                                            CommandArgument='<%# Eval("SRNO") %>'
                                            OnClientClick="return confirmReject(this);" />
                                    </ItemTemplate>
                                </asp:TemplateField>
                            </Columns>
                        </asp:GridView>
                    </div>
                </div>
            </div>

            <!-- ======================================= -->
            <!-- TAB 3: ALL PRODUCTS                     -->
            <!-- ======================================= -->
            <div id="tabAllProducts" style="display:none;">
                <div class="panel" style="margin-top:0; border-top-left-radius:0;">
                    <div class="panel-header">All Products - Filter</div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label>Product Type:</label>
                            <asp:DropDownList ID="ddlFilterType" runat="server" Width="130px">
                                <asp:ListItem Text="-- All --" Value="" />
                                <asp:ListItem Text="DIB"   Value="DIB" />
                                <asp:ListItem Text="Staff" Value="Staff" />
                                <asp:ListItem Text="GHP"   Value="GHP" />
                                <asp:ListItem Text="SZHP"  Value="SZHP" />
                            </asp:DropDownList>
                            &nbsp;&nbsp;
                            <label>Status:</label>
                            <asp:DropDownList ID="ddlFilterStatus" runat="server" Width="150px">
                                <asp:ListItem Text="-- All --"        Value="" />
                                <asp:ListItem Text="Approved"         Value="A" />
                                <asp:ListItem Text="Pending Approval" Value="P" />
                                <asp:ListItem Text="Rejected"         Value="R" />
                            </asp:DropDownList>
                            &nbsp;&nbsp;
                            <asp:Button ID="btnFilterProducts" runat="server" Text="Filter"
                                CssClass="btn btn-primary" OnClick="btnFilterProducts_Click" />
                            <asp:Button ID="btnClearFilter" runat="server" Text="Show All"
                                CssClass="btn btn-info" OnClick="btnClearFilter_Click" />
                        </div>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-header">Product Listing</div>
                    <div class="panel-body">
                        <asp:GridView ID="gvAllProducts" runat="server" CssClass="gridview"
                            AutoGenerateColumns="False"
                            EmptyDataText="No products found."
                            AlternatingRowStyle-CssClass="alt">
                            <Columns>
                                <asp:BoundField DataField="ProductCode" HeaderText="Product Code" />
                                <asp:BoundField DataField="VendorName"  HeaderText="Vendor" />
                                <asp:BoundField DataField="ProductType" HeaderText="Type" />
                                <asp:BoundField DataField="Rate"        HeaderText="Rate" DataFormatString="{0:N10}" />
                                <asp:BoundField DataField="StatusDesc"  HeaderText="Status" />
                                <asp:BoundField DataField="MakerID"     HeaderText="Maker" />
                                <asp:BoundField DataField="MakerDate"   HeaderText="Maker Date" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                                <asp:BoundField DataField="CheckerID"   HeaderText="Checker" />
                                <asp:BoundField DataField="CheckerDate" HeaderText="Checker Date" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                                <asp:BoundField DataField="CheckerRemarks" HeaderText="Checker Remarks" />
                                <asp:BoundField DataField="UpdatedOn_Date" HeaderText="Last Updated" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                            </Columns>
                        </asp:GridView>
                    </div>
                </div>
            </div>

            <!-- ======================================= -->
            <!-- TAB 4: HISTORY                          -->
            <!-- ======================================= -->
            <div id="tabHistory" style="display:none;">
                <div class="panel" style="margin-top:0; border-top-left-radius:0;">
                    <div class="panel-header">Change History - Filter</div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label>Product Code:</label>
                            <asp:TextBox ID="txtHistProductCode" runat="server" Width="160px" />
                            &nbsp;&nbsp;
                            <label>Vendor Name:</label>
                            <asp:TextBox ID="txtHistVendorName" runat="server" Width="220px" />
                            &nbsp;&nbsp;
                            <asp:Button ID="btnFilterHistory" runat="server" Text="Filter"
                                CssClass="btn btn-primary" OnClick="btnFilterHistory_Click" />
                            <asp:Button ID="btnClearHistory" runat="server" Text="Show All"
                                CssClass="btn btn-info" OnClick="btnClearHistory_Click" />
                        </div>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-header">Complete Tracking History (last 500 records)</div>
                    <div class="panel-body">
                        <asp:GridView ID="gvHistory" runat="server" CssClass="gridview"
                            AutoGenerateColumns="False"
                            EmptyDataText="No history records found."
                            AlternatingRowStyle-CssClass="alt">
                            <Columns>
                                <asp:BoundField DataField="HistoryID"    HeaderText="ID" />
                                <asp:BoundField DataField="ProductCode"  HeaderText="Product Code" />
                                <asp:BoundField DataField="VendorName"   HeaderText="Vendor" />
                                <asp:BoundField DataField="ProductType"  HeaderText="Type" />
                                <asp:BoundField DataField="OldRate"      HeaderText="Old Rate" DataFormatString="{0:N10}" NullDisplayText="--" />
                                <asp:BoundField DataField="NewRate"      HeaderText="New Rate" DataFormatString="{0:N10}" />
                                <asp:BoundField DataField="OldStatusDesc" HeaderText="From Status" />
                                <asp:BoundField DataField="NewStatusDesc" HeaderText="To Status" />
                                <asp:BoundField DataField="ActionType"   HeaderText="Action" />
                                <asp:BoundField DataField="ActionBy"     HeaderText="By" />
                                <asp:BoundField DataField="ActionDate"   HeaderText="Date" DataFormatString="{0:dd/MM/yyyy HH:mm}" />
                                <asp:BoundField DataField="MakerID"      HeaderText="Maker" />
                                <asp:BoundField DataField="CheckerID"    HeaderText="Checker" />
                                <asp:BoundField DataField="Remarks"      HeaderText="Remarks" />
                            </Columns>
                        </asp:GridView>
                    </div>
                </div>
            </div>

        </div>
    </form>
</body>
</html>
