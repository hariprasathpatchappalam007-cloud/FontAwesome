using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HF48Workflow
{
    public partial class TakafulProductMaster : System.Web.UI.Page
    {
        private string ConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["LMS_DEV"].ConnectionString; }
        }

        private string CurrentUser
        {
            get
            {
                // txtCurrentUser allows role-switching in test/UAT environments
                string fromTextbox = (txtCurrentUser != null ? txtCurrentUser.Text : "").Trim();
                if (!string.IsNullOrEmpty(fromTextbox)) return fromTextbox;
                if (Session["UserID"] != null)
                    return Session["UserID"].ToString();
                return System.Web.HttpContext.Current.User.Identity.Name ?? "SYSTEM";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null) txtCurrentUser.Text = Session["UserID"].ToString();
                lblCurrentUser.Text        = CurrentUser;
                lblCurrentUserChecker.Text = CurrentUser;
                LoadApprovedProducts();
                LoadMySubmissions();
                LoadPendingApprovals();
                LoadAllProducts("", "", "");
                LoadHistory("", "");
            }
            else
            {
                lblCurrentUser.Text        = CurrentUser;
                lblCurrentUserChecker.Text = CurrentUser;
                ReapplyVendorColors();
            }
        }

        #region Data Loading

        private void LoadApprovedProducts()
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_Takaful_GetProducts", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Status", "A");

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvApprovedProducts.DataSource = dt;
                gvApprovedProducts.DataBind();
            }
        }

        private void LoadMySubmissions()
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_Takaful_GetMySubmissions", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MakerID", CurrentUser);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvMySubmissions.DataSource = dt;
                gvMySubmissions.DataBind();
            }
        }

        private void LoadPendingApprovals()
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_Takaful_GetPendingForChecker", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvPendingApprovals.DataSource = dt;
                gvPendingApprovals.DataBind();
            }
        }

        private void LoadAllProducts(string productType, string applicantType, string status)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_Takaful_GetProducts", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductType",   string.IsNullOrEmpty(productType)   ? (object)DBNull.Value : productType);
                cmd.Parameters.AddWithValue("@ApplicantType", string.IsNullOrEmpty(applicantType) ? (object)DBNull.Value : applicantType);
                cmd.Parameters.AddWithValue("@Status",        string.IsNullOrEmpty(status)        ? (object)DBNull.Value : status);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvAllProducts.DataSource = dt;
                gvAllProducts.DataBind();
            }
        }

        private void LoadHistory(string productCode, string vendorName)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_Takaful_GetHistory", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductCode", string.IsNullOrEmpty(productCode) ? (object)DBNull.Value : productCode);
                cmd.Parameters.AddWithValue("@VendorName",  string.IsNullOrEmpty(vendorName)  ? (object)DBNull.Value : vendorName);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);

                gvHistory.DataSource = dt;
                gvHistory.DataBind();
            }
        }

        #endregion

        #region Maker Actions

        protected void btnSaveProduct_Click(object sender, EventArgs e)
        {
            if (!ValidateMakerForm()) return;

            decimal rate;
            if (!decimal.TryParse(txtRate.Text.Trim(), out rate) || rate <= 0)
            {
                ShowMessage("Rate must be a valid positive decimal number (e.g. 0.0001849).", false);
                hfActiveTab.Value = "tabMaker";
                return;
            }

            int srno;
            if (!int.TryParse(hfSRNO.Value, out srno)) srno = 0;

            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_Takaful_SaveProduct", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@SRNO",          srno);
                cmd.Parameters.AddWithValue("@ProductCode",   txtProductCode.Text.Trim().ToUpper());
                cmd.Parameters.AddWithValue("@VendorName",    txtVendorName.Text.Trim());
                cmd.Parameters.AddWithValue("@ProductType",   ddlProductType.SelectedValue);
                cmd.Parameters.AddWithValue("@ApplicantType", ddlApplicantType.SelectedValue);
                cmd.Parameters.AddWithValue("@Rate",          rate);
                cmd.Parameters.AddWithValue("@MakerID",       CurrentUser);

                SqlParameter pStatus  = new SqlParameter("@Status",  SqlDbType.NVarChar, 50);
                SqlParameter pMessage = new SqlParameter("@Message", SqlDbType.NVarChar, 500);
                pStatus.Direction  = ParameterDirection.Output;
                pMessage.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(pStatus);
                cmd.Parameters.Add(pMessage);

                conn.Open();
                cmd.ExecuteNonQuery();

                bool success = pStatus.Value.ToString() == "SUCCESS";
                ShowMessage(pMessage.Value.ToString(), success);

                if (success)
                {
                    ClearMakerForm();
                    LoadApprovedProducts();
                }
            }

            hfActiveTab.Value = "tabMaker";
            LoadMySubmissions();
            ReapplyVendorColors();
        }

        protected void btnClearForm_Click(object sender, EventArgs e)
        {
            ClearMakerForm();
            hfActiveTab.Value = "tabMaker";
        }

        private void ClearMakerForm()
        {
            hfSRNO.Value           = "0";
            txtProductCode.Text    = "";
            txtVendorName.Text     = "";
            ddlProductType.SelectedIndex    = 0;
            ddlApplicantType.SelectedIndex  = 0;
            txtRate.Text           = "";
            txtProductCode.Enabled = true;
        }

        private bool ValidateMakerForm()
        {
            if (string.IsNullOrEmpty(txtProductCode.Text.Trim()))
            { ShowMessage("Product Code is required.", false); hfActiveTab.Value = "tabMaker"; return false; }
            if (string.IsNullOrEmpty(txtVendorName.Text.Trim()))
            { ShowMessage("Vendor Name is required.", false); hfActiveTab.Value = "tabMaker"; return false; }
            if (string.IsNullOrEmpty(ddlProductType.SelectedValue))
            { ShowMessage("Product Type must be selected.", false); hfActiveTab.Value = "tabMaker"; return false; }
            if (string.IsNullOrEmpty(ddlApplicantType.SelectedValue))
            { ShowMessage("Applicant Type must be selected.", false); hfActiveTab.Value = "tabMaker"; return false; }
            if (string.IsNullOrEmpty(txtRate.Text.Trim()))
            { ShowMessage("Rate is required.", false); hfActiveTab.Value = "tabMaker"; return false; }
            return true;
        }

        // Loads any product (by SRNO) into the Maker form.
        private void LoadProductIntoForm(int srno, string contextMessage)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand(
                    "SELECT SRNO, ProductCode, VendorName, ProductType, ApplicantType, Rate FROM Takaful_Product_Master WHERE SRNO=@SRNO AND IsActive=1",
                    conn);
                cmd.Parameters.AddWithValue("@SRNO", srno);
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    hfSRNO.Value                      = dr["SRNO"].ToString();
                    txtProductCode.Text               = dr["ProductCode"].ToString();
                    txtVendorName.Text                = dr["VendorName"].ToString();
                    ddlProductType.SelectedValue      = dr["ProductType"].ToString();
                    ddlApplicantType.SelectedValue    = dr["ApplicantType"].ToString();
                    txtRate.Text                      = dr["Rate"].ToString();
                    txtProductCode.Enabled            = false; // Product Code is locked on edit
                    hfActiveTab.Value                 = "tabMaker";
                    ShowMessage(contextMessage, true);
                }
            }
        }

        protected void gvMySubmissions_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "LoadEdit")
            {
                int srno;
                if (!int.TryParse(e.CommandArgument.ToString(), out srno)) return;
                LoadProductIntoForm(srno,
                    "Record loaded. Update the Rate and click 'Submit for Approval' to re-submit.");
            }
        }

        protected void gvApprovedProducts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ProposeChange")
            {
                int srno;
                if (!int.TryParse(e.CommandArgument.ToString(), out srno)) return;
                LoadProductIntoForm(srno,
                    "Approved product loaded. Update the Rate field and click 'Submit for Approval'. " +
                    "The current live rate will remain unchanged until the Checker approves your change.");
            }
            else if (e.CommandName == "ViewHistory")
            {
                string productCode = e.CommandArgument.ToString();
                txtHistProductCode.Text = productCode;
                txtHistVendorName.Text  = "";
                LoadHistory(productCode, "");
                hfActiveTab.Value = "tabHistory";
            }
        }

        #endregion

        #region Checker Actions

        protected void gvPendingApprovals_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "ApproveProduct" && e.CommandName != "RejectProduct") return;

            int srno;
            if (!int.TryParse(e.CommandArgument.ToString(), out srno))
            {
                ShowMessage("Invalid record reference.", false);
                hfActiveTab.Value = "tabChecker";
                return;
            }

            // Retrieve checker remarks from the row's TextBox
            GridViewRow row    = (GridViewRow)((Button)e.CommandSource).NamingContainer;
            TextBox txtRemarks = (TextBox)row.FindControl("txtCheckerRowRemarks");
            string  remarks    = (txtRemarks != null) ? txtRemarks.Text.Trim() : "";

            string action = (e.CommandName == "ApproveProduct") ? "APPROVE" : "REJECT";

            if (action == "REJECT" && string.IsNullOrEmpty(remarks))
            {
                ShowMessage("Rejection remarks are mandatory. Please enter remarks before rejecting.", false);
                hfActiveTab.Value = "tabChecker";
                return;
            }

            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                SqlCommand cmd = new SqlCommand("Proc_Takaful_CheckerAction", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@SRNO",           srno);
                cmd.Parameters.AddWithValue("@Action",         action);
                cmd.Parameters.AddWithValue("@CheckerID",      CurrentUser);
                cmd.Parameters.AddWithValue("@CheckerRemarks", string.IsNullOrEmpty(remarks) ? (object)DBNull.Value : remarks);

                SqlParameter pStatus  = new SqlParameter("@Status",  SqlDbType.NVarChar, 50);
                SqlParameter pMessage = new SqlParameter("@Message", SqlDbType.NVarChar, 500);
                pStatus.Direction  = ParameterDirection.Output;
                pMessage.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(pStatus);
                cmd.Parameters.Add(pMessage);

                conn.Open();
                cmd.ExecuteNonQuery();

                bool success = pStatus.Value.ToString() == "SUCCESS";
                ShowMessage(pMessage.Value.ToString(), success);
            }

            hfActiveTab.Value = "tabChecker";
            LoadPendingApprovals();
            LoadApprovedProducts();
            LoadMySubmissions();
            LoadAllProducts(ddlFilterType.SelectedValue, ddlFilterApplicantType.SelectedValue, ddlFilterStatus.SelectedValue);
            ReapplyVendorColors();
        }

        #endregion

        #region All Products Tab

        protected void btnFilterProducts_Click(object sender, EventArgs e)
        {
            LoadAllProducts(ddlFilterType.SelectedValue, ddlFilterApplicantType.SelectedValue, ddlFilterStatus.SelectedValue);
            hfActiveTab.Value = "tabAllProducts";
            ReapplyVendorColors();
        }

        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            ddlFilterType.SelectedIndex          = 0;
            ddlFilterApplicantType.SelectedIndex = 0;
            ddlFilterStatus.SelectedIndex        = 0;
            LoadAllProducts("", "", "");
            hfActiveTab.Value = "tabAllProducts";
            ReapplyVendorColors();
        }

        #endregion

        #region History Tab

        protected void btnFilterHistory_Click(object sender, EventArgs e)
        {
            LoadHistory(txtHistProductCode.Text.Trim(), txtHistVendorName.Text.Trim());
            hfActiveTab.Value = "tabHistory";
        }

        protected void btnClearHistory_Click(object sender, EventArgs e)
        {
            txtHistProductCode.Text = "";
            txtHistVendorName.Text  = "";
            LoadHistory("", "");
            hfActiveTab.Value = "tabHistory";
        }

        #endregion

        #region Switch User

        protected void btnSetUser_Click(object sender, EventArgs e)
        {
            string newUser = (txtCurrentUser.Text ?? "").Trim();
            if (string.IsNullOrEmpty(newUser))
            {
                ShowMessage("Please enter a user ID.", false);
                return;
            }
            Session["UserID"]          = newUser;
            lblCurrentUser.Text        = CurrentUser;
            lblCurrentUserChecker.Text = CurrentUser;
            ShowMessage("Acting user switched to: <strong>" + Server.HtmlEncode(newUser) + "</strong>", true);
            LoadMySubmissions();
            LoadPendingApprovals();
        }

        #endregion

        #region Helper

        private void ShowMessage(string message, bool isSuccess)
        {
            pnlMessage.Visible   = true;
            lblMessage.Text      = message;
            lblMessage.CssClass  = isSuccess ? "msg-success" : "msg-error";
        }

        private void ReapplyVendorColors()
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "vendorColors",
                "applyVendorColors();", true);
        }

        #endregion
    }
}
