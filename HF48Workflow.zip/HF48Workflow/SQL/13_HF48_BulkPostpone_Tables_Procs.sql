USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Script 13: HF48 Bulk Postponement
--   Core tables and all procedures required
--   by HF48BulkPostponement.aspx
--
-- Tables:
--   1. HF48_BulkPostpone_Requests        (maker-checker request header)
--   2. HF48_BulkPostpone_RequestDetail   (per-schedule snapshot)
--   3. HF48_BulkPostpone_Docs            (supporting documents)
--
-- Procedures:
--   4.  Proc_HF48_BulkPostpone_GetProjects
--   5.  Proc_HF48_BulkPostpone_GetActiveHolds
--   6.  Proc_HF48_BulkPostpone_Submit
--   7.  Proc_HF48_BulkPostpone_GetRequests
--   8.  Proc_HF48_BulkPostpone_GetRequestDetail
--   9.  Proc_HF48_BulkPostpone_GetDocs
--   10. Proc_HF48_BulkPostpone_Approve   (Hold and Unhold)
--   11. Proc_HF48_BulkPostpone_Reject
-- =============================================

-- =============================================
-- 1. HF48_BulkPostpone_Requests
--    One row per maker submission
-- =============================================
IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BulkPostpone_Requests]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[HF48_BulkPostpone_Requests]
    (
        RequestID              INT IDENTITY(1,1)   NOT NULL,
        RequestType            NVARCHAR(50)        NOT NULL,   -- Hold | Unhold | Postpone
        Property_ProjectID     NVARCHAR(100)       NULL,
        Property_ProjectName   NVARCHAR(200)       NULL,
        Property_DeveloperName NVARCHAR(200)       NULL,
        ShiftDays              INT                 NOT NULL    DEFAULT 0,
        AffectedAppCount       INT                 NOT NULL    DEFAULT 0,
        AffectedRowCount       INT                 NOT NULL    DEFAULT 0,
        SourceRequestID        INT                 NULL,       -- Unhold: FK → original Hold request
        Reason                 NVARCHAR(MAX)       NULL,
        MakerUser              NVARCHAR(100)       NOT NULL,
        MakerOn                DATETIME            NOT NULL    DEFAULT GETDATE(),
        CheckerUser            NVARCHAR(100)       NULL,
        CheckerOn              DATETIME            NULL,
        CheckerRemarks         NVARCHAR(500)       NULL,
        [Status]               NVARCHAR(50)        NOT NULL    DEFAULT 'Pending Approval',
        -- Pending Approval | Approved | Rejected | Released
        DraftID                NVARCHAR(100)       NULL,       -- links uploaded docs before approval

        CONSTRAINT PK_HF48_BulkPostpone_Requests PRIMARY KEY CLUSTERED (RequestID ASC)
    )
    PRINT 'Table HF48_BulkPostpone_Requests created.'
END
ELSE
    PRINT 'Table HF48_BulkPostpone_Requests already exists - skipped.'
GO

-- =============================================
-- 2. HF48_BulkPostpone_RequestDetail
--    Per-schedule snapshot captured at Submit
-- =============================================
IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BulkPostpone_RequestDetail]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[HF48_BulkPostpone_RequestDetail]
    (
        DetailID      INT IDENTITY(1,1)   NOT NULL,
        RequestID     INT                 NOT NULL,
        APP_REF_NO    NVARCHAR(50)        NULL,
        Lead_No       NVARCHAR(50)        NULL,
        Customer_Name NVARCHAR(200)       NULL,
        OldDisbDate   DATETIME            NULL,
        NewDisbDate   DATETIME            NULL,
        OldDisbStatus NVARCHAR(50)        NULL,
        NewDisbStatus NVARCHAR(50)        NULL,
        Disb_Amount   DECIMAL(18, 4)      NULL,
        Applied       BIT                 NOT NULL    DEFAULT 0,
        GroupIndex    INT                 NULL,

        CONSTRAINT PK_HF48_BulkPostpone_RequestDetail PRIMARY KEY CLUSTERED (DetailID ASC)
    )
    CREATE NONCLUSTERED INDEX IX_BulkPostponeDetail_RequestID
        ON [dbo].[HF48_BulkPostpone_RequestDetail] (RequestID)
    PRINT 'Table HF48_BulkPostpone_RequestDetail created.'
END
ELSE
    PRINT 'Table HF48_BulkPostpone_RequestDetail already exists - skipped.'
GO

-- =============================================
-- 3. HF48_BulkPostpone_Docs
--    Supporting documents per request
-- =============================================
IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BulkPostpone_Docs]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[HF48_BulkPostpone_Docs]
    (
        DocID        INT IDENTITY(1,1)   NOT NULL,
        DraftID      NVARCHAR(100)       NULL,   -- pre-approval draft key
        RequestID    INT                 NULL,   -- set once request is submitted
        OriginalName NVARCHAR(500)       NULL,
        StoredPath   NVARCHAR(1000)      NULL,
        SizeBytes    BIGINT              NULL,
        UploadedBy   NVARCHAR(100)       NULL,
        UploadedOn   DATETIME            NOT NULL    DEFAULT GETDATE(),

        CONSTRAINT PK_HF48_BulkPostpone_Docs PRIMARY KEY CLUSTERED (DocID ASC)
    )
    PRINT 'Table HF48_BulkPostpone_Docs created.'
END
ELSE
    PRINT 'Table HF48_BulkPostpone_Docs already exists - skipped.'
GO

-- =============================================
-- 4. Proc_HF48_BulkPostpone_GetProjects
--    Project list with pending/held counts
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_GetProjects]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetProjects]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetProjects]
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        ldp.Property_ProjectID,
        ldp.Property_ProjectName,
        ldp.Property_DeveloperName,
        COUNT(DISTINCT ld.APP_REF_NO)                                        AS AppCount,
        ISNULL(MAX(ldm.dev_tier),        '-')                                AS dev_tier,
        ISNULL(MAX(lproj.value_tranche), '-')                                AS value_tranche,
        SUM(CASE WHEN ldd.disb_status = 'Not Disbursed' THEN 1 ELSE 0 END)  AS PendingRows,
        SUM(CASE WHEN ldd.disb_status = 'Hold'          THEN 1 ELSE 0 END)  AS HoldRows
    FROM [dbo].[LEAD_DETAILS_Property] ldp
    INNER JOIN [dbo].[LEAD_DETAILS] ld
        ON ld.lead_no = ldp.lead_no
    INNER JOIN [dbo].[LEAD_DETAILS_DISB] ldd
        ON ldd.lead_no = ldp.lead_no
    INNER JOIN [dbo].[LEAD_DETAILS_FINANCE] ldf
        ON ldf.lead_no = ldp.lead_no
    LEFT JOIN [dbo].[LEAD_DEVELOPER_MASTER] ldm
        ON ldm.DEVELOPERNAME = ldp.Property_DeveloperName
       AND ISNULL(ldm.Status, '') = 'A'
    LEFT JOIN [dbo].[lead_project] lproj
        ON lproj.PROJECTNAME = ldp.Property_ProjectName
       AND ISNULL(lproj.status, '') = 'A'
    WHERE ldp.Property_ProjectID IS NOT NULL
      AND ld.lead_stage IN ('END_OF_PROCESS','OPS_PMU','OPS_LODGMENT','OPS_LODGEMENT','Disbursed')
      AND ISNULL(ldd.Disb_Status, '') <> ''
      AND ISNULL(ldd.Status, '') = 'A'
      AND ISNULL(ld.APP_REF_NO, '') <> ''
      AND ISNULL(ldf.LEAD_Product_ISTINSNA, '') = 'HF48'
    GROUP BY ldp.Property_ProjectID, ldp.Property_ProjectName, ldp.Property_DeveloperName
    HAVING COUNT(*) > 0
    ORDER BY ldp.Property_ProjectName
END
GO

-- =============================================
-- 5. Proc_HF48_BulkPostpone_GetActiveHolds
--    Approved Hold requests available for Unhold
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_GetActiveHolds]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetActiveHolds]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetActiveHolds]
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        r.RequestID,
        r.Property_ProjectName,
        r.Property_DeveloperName,
        COUNT(DISTINCT d.APP_REF_NO) AS AffectedAppCount,
        COUNT(*)                     AS AffectedRowCount,
        r.ShiftDays,
        r.MakerUser,
        r.MakerOn,
        r.CheckerUser,
        r.CheckerOn
    FROM [dbo].[HF48_BulkPostpone_Requests] r
    INNER JOIN [dbo].[HF48_BulkPostpone_RequestDetail] d
        ON d.RequestID = r.RequestID
    INNER JOIN [dbo].[LEAD_DETAILS_DISB] ldd
        ON ldd.lead_no = d.Lead_No
       AND CAST(ldd.Disb_Date AS DATE) = CAST(d.NewDisbDate AS DATE)
    INNER JOIN [dbo].[LEAD_DETAILS] ld
        ON ld.lead_no = d.Lead_No
    INNER JOIN [dbo].[LEAD_DETAILS_FINANCE] ldf
        ON ldf.lead_no = d.Lead_No
    WHERE r.RequestType = 'Hold'
      AND r.[Status]    = 'Approved'
      AND ISNULL(ldd.Status, '') = 'A'
      AND ISNULL(ldd.disb_status, '') = 'Hold'
      AND ISNULL(ld.APP_REF_NO, '') <> ''
      AND ISNULL(ldf.LEAD_Product_ISTINSNA, '') = 'HF48'
      AND NOT EXISTS
      (
          SELECT 1
          FROM [dbo].[HF48_BulkPostpone_Requests] ru
          WHERE ru.SourceRequestID = r.RequestID
            AND ru.RequestType = 'Unhold'
            AND ru.[Status] IN ('Pending Approval', 'Approved')
      )
    GROUP BY
        r.RequestID,
        r.Property_ProjectName,
        r.Property_DeveloperName,
        r.ShiftDays,
        r.MakerUser,
        r.MakerOn,
        r.CheckerUser,
        r.CheckerOn
    HAVING COUNT(*) > 0
    ORDER BY r.MakerOn DESC
END
GO

-- =============================================
-- 6. Proc_HF48_BulkPostpone_Submit
--    Maker: create request + snapshot detail
--    Hold/Postpone : captures live DISB rows
--    Unhold        : copies from source Hold (reversing dates)
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_Submit]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Submit]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Submit]
    @RequestType        NVARCHAR(50),
    @Property_ProjectID NVARCHAR(100) = NULL,
    @ShiftDays          INT           = 0,
    @SourceRequestID    INT           = NULL,
    @Reason             NVARCHAR(MAX) = NULL,
    @MakerUser          NVARCHAR(100),
    @DraftID            NVARCHAR(100) = NULL,
    @RequestID          INT           OUTPUT,
    @Status             NVARCHAR(50)  OUTPUT,
    @Message            NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    -- ── Validation ──────────────────────────────────────────────────────────
    IF @RequestType NOT IN ('Hold','Unhold','Postpone')
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Invalid RequestType. Use Hold, Unhold or Postpone.'
        SET @RequestID = 0
        RETURN
    END

    IF @RequestType = 'Unhold'
       AND (ISNULL(@SourceRequestID, 0) = 0)
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'SourceRequestID is required for Unhold.'
        SET @RequestID = 0
        RETURN
    END

    IF @RequestType IN ('Hold','Postpone')
       AND ISNULL(@Property_ProjectID, '') = ''
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Property_ProjectID is required for Hold / Postpone.'
        SET @RequestID = 0
        RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_SUBMIT

        DECLARE @ProjName    NVARCHAR(200) = NULL
        DECLARE @DevName     NVARCHAR(200) = NULL
        DECLARE @AppCount    INT           = 0
        DECLARE @RowCount    INT           = 0

        -- ── Resolve project name / counts ────────────────────────────────────
        IF @RequestType IN ('Hold', 'Postpone')
        BEGIN
            SELECT TOP 1
                @ProjName = ldp.Property_ProjectName,
                @DevName  = ldp.Property_DeveloperName
            FROM [dbo].[LEAD_DETAILS_Property] ldp
            WHERE ldp.Property_ProjectID = @Property_ProjectID

            SELECT
                @AppCount = COUNT(DISTINCT ld.APP_REF_NO),
                @RowCount = COUNT(*)
                        FROM [dbo].[LEAD_DETAILS_DISB] ldd
            INNER JOIN [dbo].[LEAD_DETAILS] ld
                ON ld.lead_no = ldd.lead_no
                        INNER JOIN [dbo].[LEAD_DETAILS_FINANCE] ldf
                                ON ldf.lead_no = ldd.lead_no
            INNER JOIN [dbo].[LEAD_DETAILS_Property] ldp
                ON ldp.lead_no = ldd.lead_no
            WHERE ldp.Property_ProjectID = @Property_ProjectID
              AND ldd.disb_status IN ('Not Disbursed', 'Hold')
                            AND ISNULL(ldd.Status, '') = 'A'
                            AND ISNULL(ld.APP_REF_NO, '') <> ''
                            AND ISNULL(ldf.LEAD_Product_ISTINSNA, '') = 'HF48'
              AND ld.lead_stage IN ('END_OF_PROCESS','OPS_PMU',
                                    'OPS_LODGMENT','OPS_LODGEMENT','Disbursed')
        END
        ELSE -- Unhold: inherit from source request
        BEGIN
            SELECT
                @ProjName = Property_ProjectName,
                @DevName  = Property_DeveloperName,
                @AppCount = AffectedAppCount,
                @RowCount = AffectedRowCount,
                @Property_ProjectID = Property_ProjectID
            FROM [dbo].[HF48_BulkPostpone_Requests]
            WHERE RequestID = @SourceRequestID
        END

        -- ── Insert request header ────────────────────────────────────────────
        INSERT INTO [dbo].[HF48_BulkPostpone_Requests]
            (RequestType, Property_ProjectID, Property_ProjectName, Property_DeveloperName,
             ShiftDays, AffectedAppCount, AffectedRowCount,
             SourceRequestID, Reason, MakerUser, MakerOn, [Status], DraftID)
        VALUES
            (@RequestType, @Property_ProjectID, @ProjName, @DevName,
             @ShiftDays, @AppCount, @RowCount,
             @SourceRequestID, @Reason, @MakerUser, GETDATE(), 'Pending Approval', @DraftID)

        SET @RequestID = SCOPE_IDENTITY()

        -- ── Insert detail snapshot ───────────────────────────────────────────
        IF @RequestType IN ('Hold', 'Postpone')
        BEGIN
            INSERT INTO [dbo].[HF48_BulkPostpone_RequestDetail]
                (RequestID, APP_REF_NO, Lead_No, Customer_Name,
                 OldDisbDate, NewDisbDate, OldDisbStatus, NewDisbStatus,
                 Disb_Amount, Applied, GroupIndex)
            SELECT
                @RequestID,
                ld.APP_REF_NO,
                ldd.lead_no,
                ld.Customer_name,
                ldd.Disb_Date,                              -- current date (will become OldDisbDate)
                DATEADD(DAY, @ShiftDays, ldd.Disb_Date),   -- shifted date
                ldd.disb_status,
                CASE
                    WHEN @RequestType = 'Hold'
                        THEN 'Hold'
                    ELSE ldd.disb_status                    -- Postpone keeps same status label
                END,
                ldd.Disb_amount,
                0,
                DENSE_RANK() OVER (ORDER BY ld.APP_REF_NO)
                        FROM [dbo].[LEAD_DETAILS_DISB] ldd
            INNER JOIN [dbo].[LEAD_DETAILS] ld
                ON ld.lead_no = ldd.lead_no
                        INNER JOIN [dbo].[LEAD_DETAILS_FINANCE] ldf
                                ON ldf.lead_no = ldd.lead_no
            INNER JOIN [dbo].[LEAD_DETAILS_Property] ldp
                ON ldp.lead_no = ldd.lead_no
            WHERE ldp.Property_ProjectID = @Property_ProjectID
              AND ldd.disb_status IN ('Not Disbursed', 'Hold')
                            AND ISNULL(ldd.Status, '') = 'A'
                            AND ISNULL(ld.APP_REF_NO, '') <> ''
                            AND ISNULL(ldf.LEAD_Product_ISTINSNA, '') = 'HF48'
              AND ld.lead_stage IN ('END_OF_PROCESS','OPS_PMU',
                                    'OPS_LODGMENT','OPS_LODGEMENT','Disbursed')
        END
        ELSE -- Unhold: swap OldDisbDate / NewDisbDate from source Hold
        BEGIN
            INSERT INTO [dbo].[HF48_BulkPostpone_RequestDetail]
                (RequestID, APP_REF_NO, Lead_No, Customer_Name,
                 OldDisbDate, NewDisbDate, OldDisbStatus, NewDisbStatus,
                 Disb_Amount, Applied, GroupIndex)
            SELECT
                @RequestID,
                d.APP_REF_NO,
                d.Lead_No,
                d.Customer_Name,
                d.NewDisbDate,      -- current (held) date is now Old
                d.OldDisbDate,      -- original pre-hold date is now New (restore)
                d.NewDisbStatus,    -- current status (Hold) is now Old
                d.OldDisbStatus,    -- original status is now New (restore)
                d.Disb_Amount,
                0,
                d.GroupIndex
            FROM [dbo].[HF48_BulkPostpone_RequestDetail] d
            WHERE d.RequestID = @SourceRequestID
        END

        -- ── Link uploaded draft documents to this RequestID ──────────────────
        IF ISNULL(@DraftID, '') <> ''
        BEGIN
            UPDATE [dbo].[HF48_BulkPostpone_Docs]
            SET RequestID = @RequestID
            WHERE DraftID = @DraftID
              AND RequestID IS NULL
        END

    COMMIT TRANSACTION T_SUBMIT

    SET @Status  = 'SUCCESS'
    SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) +
                   ' submitted for approval. Type: ' + @RequestType + '.'

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_SUBMIT
        SET @RequestID = 0
        SET @Status    = 'FAILURE'
        SET @Message   = 'Error: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- =============================================
-- 7. Proc_HF48_BulkPostpone_GetRequests
--    Returns request list (all or filtered)
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_GetRequests]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetRequests]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetRequests]
    @Status NVARCHAR(50) = NULL   -- NULL = return all statuses
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        RequestID,
        RequestType,
        Property_ProjectName,
        Property_DeveloperName,
        ShiftDays,
        AffectedAppCount,
        AffectedRowCount,
        MakerUser,
        MakerOn,
        Reason,
        CheckerUser,
        CheckerOn,
        CheckerRemarks,
        [Status]
    FROM [dbo].[HF48_BulkPostpone_Requests]
    WHERE ISNULL(@Status, '') = '' OR [Status] = @Status
    ORDER BY MakerOn DESC
END
GO

-- =============================================
-- 8. Proc_HF48_BulkPostpone_GetRequestDetail
--    Detail rows for the Checker view
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]
    @RequestID INT
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        APP_REF_NO,
        Lead_No,
        Customer_Name,
        OldDisbDate,
        NewDisbDate,
        OldDisbStatus,
        NewDisbStatus,
        Disb_Amount,
        Applied,
        GroupIndex
    FROM [dbo].[HF48_BulkPostpone_RequestDetail]
    WHERE RequestID = @RequestID
    ORDER BY APP_REF_NO, OldDisbDate
END
GO

-- =============================================
-- 9. Proc_HF48_BulkPostpone_GetDocs
--    Documents for a DraftID or RequestID
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_GetDocs]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetDocs]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetDocs]
    @DraftID   NVARCHAR(100) = NULL,
    @RequestID INT           = NULL
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        DocID,
        DraftID,
        RequestID,
        OriginalName,
        StoredPath,
        SizeBytes,
        UploadedBy,
        UploadedOn
    FROM [dbo].[HF48_BulkPostpone_Docs]
    WHERE (ISNULL(@DraftID,'')   = '' OR DraftID   = @DraftID)
      AND (@RequestID IS NULL           OR RequestID = @RequestID)
    ORDER BY UploadedOn
END
GO

-- =============================================
-- 10. Proc_HF48_BulkPostpone_Approve
--     Handles Hold and Unhold approvals.
--     Postpone requests use Proc_HF48_PostponeNoHold_Approve (Script 10).
--
--     Hold approve  : shifts dates + sets disb_status='Hold'
--                     + sets lead_project.value_tranche='Hold'
--     Unhold approve: restores dates + restores disb_status
--                     + restores lead_project.value_tranche
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_Approve]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Approve]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Approve]
    @RequestID      INT,
    @CheckerUser    NVARCHAR(100),
    @CheckerRemarks NVARCHAR(500) = NULL,
    @Status         NVARCHAR(50)  OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @RequestType  NVARCHAR(50)
    DECLARE @ReqStatus    NVARCHAR(50)
    DECLARE @MakerUser    NVARCHAR(100)
    DECLARE @ShiftDays    INT
    DECLARE @ProjName     NVARCHAR(200)
    DECLARE @SrcReqID     INT
    DECLARE @AffRows      INT

    SELECT
        @RequestType = RequestType,
        @ReqStatus   = [Status],
        @MakerUser   = MakerUser,
        @ShiftDays   = ShiftDays,
        @ProjName    = Property_ProjectName,
        @SrcReqID    = SourceRequestID,
        @AffRows     = AffectedRowCount
    FROM [dbo].[HF48_BulkPostpone_Requests]
    WHERE RequestID = @RequestID

    IF @RequestType IS NULL
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) + ' not found.'
        RETURN
    END

    IF @RequestType = 'Postpone'
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Postpone requests must be approved via Proc_HF48_PostponeNoHold_Approve.'
        RETURN
    END

    IF @ReqStatus <> 'Pending Approval'
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request is not Pending Approval (current: ' + @ReqStatus + ').'
        RETURN
    END

    IF UPPER(@MakerUser) = UPPER(@CheckerUser)
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Maker and Checker cannot be the same user (' + @MakerUser + ').'
        RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_APPROVE

        -- ── Apply date shifts from pre-computed detail ───────────────────────
        UPDATE ldd
        SET ldd.Disb_Date = d.NewDisbDate
        FROM [dbo].[LEAD_DETAILS_DISB] ldd
        INNER JOIN [dbo].[HF48_BulkPostpone_RequestDetail] d
            ON  d.Lead_No = ldd.lead_no
            AND CAST(ldd.Disb_Date AS DATE) = CAST(d.OldDisbDate AS DATE)
        WHERE d.RequestID = @RequestID
          AND d.Applied   = 0

        -- ── Update disb_status ───────────────────────────────────────────────
        UPDATE ldd
        SET ldd.disb_status = CASE
                                WHEN @RequestType = 'Unhold' AND ISNULL(d.NewDisbStatus, '') IN ('', 'Hold')
                                    THEN 'Not Disbursed'
                                ELSE d.NewDisbStatus
                              END
        FROM [dbo].[LEAD_DETAILS_DISB] ldd
        INNER JOIN [dbo].[HF48_BulkPostpone_RequestDetail] d
            ON  d.Lead_No = ldd.lead_no
            AND CAST(ldd.Disb_Date AS DATE) = CAST(d.NewDisbDate AS DATE)
        WHERE d.RequestID = @RequestID
          AND d.Applied   = 0
          AND ISNULL(d.NewDisbStatus, '') <> ''

        -- ── Update lead_project tranche (Hold sets 'Hold'; Unhold restores) ──
        IF @RequestType = 'Hold'
        BEGIN
            UPDATE lproj
            SET lproj.value_tranche = 'Hold'
            FROM [dbo].[lead_project] lproj
            INNER JOIN [dbo].[LEAD_DETAILS_Property] ldp
                ON ldp.Property_ProjectName = lproj.PROJECTNAME
            INNER JOIN [dbo].[HF48_BulkPostpone_RequestDetail] d
                ON d.Lead_No = ldp.lead_no
            WHERE d.RequestID = @RequestID
              AND d.Applied   = 0
        END
        ELSE IF @RequestType = 'Unhold'
        BEGIN
            -- Restore value_tranche from the source Hold request context
            -- Use the original project status (before the Hold) if stored,
            -- otherwise set to 'Active' as a safe default.
            UPDATE lproj
            SET lproj.value_tranche = 'Active'
            FROM [dbo].[lead_project] lproj
            INNER JOIN [dbo].[LEAD_DETAILS_Property] ldp
                ON ldp.Property_ProjectName = lproj.PROJECTNAME
            INNER JOIN [dbo].[HF48_BulkPostpone_RequestDetail] d
                ON d.Lead_No = ldp.lead_no
            WHERE d.RequestID = @RequestID
              AND d.Applied   = 0
              AND lproj.value_tranche = 'Hold'
        END

        -- ── Mark detail rows applied ─────────────────────────────────────────
        UPDATE [dbo].[HF48_BulkPostpone_RequestDetail]
        SET Applied = 1
        WHERE RequestID = @RequestID

        -- ── Mark request Approved ────────────────────────────────────────────
        UPDATE [dbo].[HF48_BulkPostpone_Requests]
        SET [Status]       = 'Approved',
            CheckerUser    = @CheckerUser,
            CheckerOn      = GETDATE(),
            CheckerRemarks = @CheckerRemarks
        WHERE RequestID = @RequestID

        -- ── Audit log ────────────────────────────────────────────────────────
        INSERT INTO [dbo].[HF48_DISB_AUDIT_LOG]
            (APP_REF_NO, Lead_No, Disb_Date, DaysBefore,
             ActionType, ActionResult, NotificationSentTo,
             CreatedBy, CreatedOn, Remarks)
        SELECT
            d.APP_REF_NO,
            d.Lead_No,
            d.OldDisbDate,
            @ShiftDays,
            CASE
                WHEN @RequestType = 'Hold'   THEN 'BulkHold'
                WHEN @RequestType = 'Unhold' THEN 'BulkUnhold'
                ELSE @RequestType
            END,
            'Date: ' + CONVERT(NVARCHAR(20), d.OldDisbDate, 103) +
                ' → ' + CONVERT(NVARCHAR(20), d.NewDisbDate, 103),
            NULL,
            @CheckerUser,
            GETDATE(),
            'Req #' + CAST(@RequestID AS NVARCHAR(10)) + ' approved.' +
                CASE WHEN ISNULL(@CheckerRemarks,'') <> ''
                     THEN ' ' + @CheckerRemarks ELSE '' END
        FROM [dbo].[HF48_BulkPostpone_RequestDetail] d
        WHERE d.RequestID = @RequestID

    COMMIT TRANSACTION T_APPROVE

    SET @Status  = 'SUCCESS'
    SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) + ' APPROVED. ' +
                   CAST(@AffRows AS NVARCHAR(10)) + ' schedule(s) updated. ' +
                   'Project: ' + ISNULL(@ProjName, 'N/A') + '.'

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_APPROVE
        SET @Status  = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- =============================================
-- 11. Proc_HF48_BulkPostpone_Reject
--     Sets request status to Rejected
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_Reject]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Reject]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Reject]
    @RequestID      INT,
    @CheckerUser    NVARCHAR(100),
    @CheckerRemarks NVARCHAR(500),
    @Status         NVARCHAR(50)  OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    IF ISNULL(@CheckerRemarks, '') = ''
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Rejection remarks are mandatory.'
        RETURN
    END

    DECLARE @ReqStatus NVARCHAR(50)
    DECLARE @MakerUser NVARCHAR(100)
    DECLARE @ProjName  NVARCHAR(200)

    SELECT
        @ReqStatus = [Status],
        @MakerUser = MakerUser,
        @ProjName  = Property_ProjectName
    FROM [dbo].[HF48_BulkPostpone_Requests]
    WHERE RequestID = @RequestID

    IF @ReqStatus IS NULL
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) + ' not found.'
        RETURN
    END

    IF @ReqStatus <> 'Pending Approval'
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request is not Pending Approval (current: ' + @ReqStatus + ').'
        RETURN
    END

    IF UPPER(@MakerUser) = UPPER(@CheckerUser)
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Maker and Checker cannot be the same user.'
        RETURN
    END

    UPDATE [dbo].[HF48_BulkPostpone_Requests]
    SET [Status]       = 'Rejected',
        CheckerUser    = @CheckerUser,
        CheckerOn      = GETDATE(),
        CheckerRemarks = @CheckerRemarks
    WHERE RequestID = @RequestID

    SET @Status  = 'SUCCESS'
    SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) +
                   ' REJECTED. Project: ' + ISNULL(@ProjName,'N/A') +
                   '. Reason: ' + @CheckerRemarks
END
GO

PRINT '== Script 13: HF48_BulkPostpone tables and all procedures created successfully. =='
GO
