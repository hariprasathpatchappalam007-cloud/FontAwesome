USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_Get_Disbursements
-- Search/filter pending HF48 disbursements
-- Called from the ASP.NET Web Forms interface
-- =============================================
USE [LMS_DEV]
GO
/****** Object:  StoredProcedure [dbo].[Proc_HF48_Get_Disbursements]    Script Date: 16/07/2026 10:10:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_Get_Disbursements
-- Search/filter pending HF48 disbursements
-- Called from the ASP.NET Web Forms interface
-- =============================================
Create PROC [dbo].[Proc_HF48_Get_Disbursements]
    @AppRefNo NVARCHAR(50) = NULL,
    @LeadNo NVARCHAR(50) = NULL,
    @DeveloperName NVARCHAR(200) = NULL,
    @ProjectName NVARCHAR(200) = NULL,
    @DateFrom DATETIME = NULL,
    @DateTo DATETIME = NULL,
    @Tier NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON

    SELECT 
        ld.APP_REF_NO, 
        ldd.Lead_No, 
        ld.Customer_name, 
        ldd.Status, 
        ldd.Disb_Date, 
        ldd.Disb_amount, 
        ldd.DISB_PAYMENT_FROM, 
        ldd.Payment_To, 
        ldd.MilestonePaymentPct, 
        ldd.PropertyPaymentPct,  
        ldd.FinancePaymentPct, 
        ldd.Disb_Status,
        ldf.LEAD_Product_ISTINSNA,
        ldp.Property_DeveloperName, 
        ldp.Property_DeveloperID,
        ldp.Property_ProjectName, 
        ldp.Property_ProjectID,
        ldp.ConstructionType,
        ISNULL(ldm.dev_tier,'Tier 2') AS dev_tier,
        ISNULL(lpm.value_tranche,'No-Hold') AS value_tranche,
        DATEDIFF(DAY, GETDATE(), ldd.Disb_Date) AS DaysRemaining,
        clm_task.Case_RefNo AS CLM_Ticket_RefNo,
        eng_task.Case_RefNo AS ENG_Ticket_RefNo
    FROM LEAD_DETAILS_DISB ldd 
    INNER JOIN LEAD_DETAILS_FINANCE ldf ON ldd.lead_no = ldf.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldf.lead_no
    INNER JOIN LEAD_DETAILS ld ON ld.lead_no = ldf.lead_no
    LEFT JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName and ldm.developerid=ldp.Property_DeveloperID and ldm.Status='A'
    LEFT JOIN lead_project lpm ON lpm.PROJECTNAME = ldp.Property_ProjectName and lpm.PROJECTID = ldp.Property_ProjectID and lpm.status='A'
    OUTER APPLY (
        SELECT TOP 1 t.Case_RefNo
        FROM HF48_DISB_TASKS t
        WHERE t.APP_REF_NO = ld.APP_REF_NO
          AND t.Lead_No = ldd.Lead_No
          AND t.Disb_Date = ldd.Disb_Date
          AND t.TaskType = 'CLM Service Ticket'
        ORDER BY CASE WHEN ISNULL(t.Status,'') <> 'Closed' THEN 0 ELSE 1 END, t.TaskID DESC
    ) clm_task
    OUTER APPLY (
        SELECT TOP 1 t.Case_RefNo
        FROM HF48_DISB_TASKS t
        WHERE t.APP_REF_NO = ld.APP_REF_NO
          AND t.Lead_No = ldd.Lead_No
          AND t.Disb_Date = ldd.Disb_Date
          AND t.TaskType = 'Engineering Task'
        ORDER BY CASE WHEN ISNULL(t.Status,'') <> 'Closed' THEN 0 ELSE 1 END, t.TaskID DESC
    ) eng_task
    WHERE ldf.LEAD_Product_ISTINSNA = 'HF48' 
      AND ISNULL(ldd.Status, '') = 'A'
      AND (ISNULL(@AppRefNo, '') = '' OR ld.APP_REF_NO LIKE '%' + @AppRefNo + '%')
      AND (ISNULL(@LeadNo, '') = '' OR ldd.Lead_No LIKE '%' + @LeadNo + '%')
      AND (ISNULL(@DeveloperName, '') = '' OR ldp.Property_DeveloperName LIKE '%' + @DeveloperName + '%')
      AND (ISNULL(@ProjectName, '') = '' OR ldp.Property_ProjectName LIKE '%' + @ProjectName + '%')
      AND (@DateFrom IS NULL OR ldd.Disb_Date >= @DateFrom)
      AND (@DateTo IS NULL OR ldd.Disb_Date <= @DateTo)
      AND (ISNULL(@Tier, '') = '' OR ISNULL(ldm.dev_tier,'') = @Tier)
   and ISNULL(ldd.Disb_Status,'')='Not Disbursed'
    ORDER BY ldd.Disb_Date ASC
END
 
GO

-- =============================================
-- Proc_HF48_Get_OpenTasks
-- Fetch all open/non-closed service tickets
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_Get_OpenTasks]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_Get_OpenTasks]
GO

CREATE PROC [dbo].[Proc_HF48_Get_OpenTasks]
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        t.TaskID, t.Case_RefNo, t.APP_REF_NO, t.Lead_No, t.Customer_Name,
        t.Disb_Date, t.Disb_Amount,
        t.DeveloperName, t.DevTier, t.ProjectName, t.ProjectStatus,
        t.MilestonePaymentPct, t.PropertyPaymentPct, t.FinancePaymentPct,
        t.Disb_Status, t.DaysLeft,
        t.TaskType, t.AssignedTeam, t.AssignedTo, t.Status,
        t.CreatedBy, t.CreatedOn, t.Remarks,
        -- Live ticket status from CLM system; NULL for Engineering tasks
        ISNULL(fsr.cas_stage, '') AS TicketCurrentStatus
    FROM HF48_DISB_TASKS t
    LEFT JOIN FRM_SERVICE_REQUEST fsr
        ON t.TaskType = 'CLM Service Ticket'
        AND ISNUMERIC(t.Case_RefNo) = 1
        AND fsr.SRNO = CONVERT(INT, t.Case_RefNo)
    WHERE t.Status <> 'Closed'
    ORDER BY t.CreatedOn DESC
END
GO

-- =============================================
-- Proc_HF48_Get_AuditLog
-- Fetch audit log, optionally filtered by App Ref No
-- =============================================
CREATE PROC [dbo].[Proc_HF48_Get_AuditLog]
    @AppRefNo NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON

    SELECT TOP 200 
        AuditID, APP_REF_NO, Lead_No, Disb_Date, DaysBefore,
        ActionType, ActionResult, NotificationSentTo, CreatedBy, CreatedOn
    FROM HF48_DISB_AUDIT_LOG
    WHERE (ISNULL(@AppRefNo, '') = '' OR APP_REF_NO LIKE '%' + @AppRefNo + '%')
    ORDER BY CreatedOn DESC
END
GO

PRINT 'Proc_HF48_Get_Disbursements, Proc_HF48_Get_OpenTasks, Proc_HF48_Get_AuditLog created successfully.'
GO
