USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Script 11: Preview and Schedule History procs
--   for HF48 Bulk Postponement page
--
-- Proc_HF48_BulkPostpone_Preview
--   - Returns eligible schedules for a project
--   - Shows InceptionDisbDate (first-ever date,
--     tracked through HF48_POSTPONEMENT_LOG)
--   - Accepts optional date-range filter
--     (@FromDisbDate / @ToDisbDate)
--   - Negative @ShiftDays = preponment
--
-- Proc_HF48_BulkPostpone_GetScheduleHistory
--   - Returns full postponement/hold history
--     for a specific APP_REF_NO / Lead_No
-- =============================================

-- =============================================
-- 1. Proc_HF48_BulkPostpone_Preview
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_Preview]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Preview]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Preview]
    @Property_ProjectID NVARCHAR(100),
    @ShiftDays          INT            = 0,
    @AppRefNo           NVARCHAR(50)   = NULL,   -- optional app ref filter
    @DisbStatus         NVARCHAR(50)   = NULL,   -- optional disb_status filter
    @FromDisbDate       DATETIME       = NULL,   -- optional: only schedules >= this date
    @ToDisbDate         DATETIME       = NULL    -- optional: only schedules <= this date
AS
BEGIN
    SET NOCOUNT ON

    -- ---- Eligible lead stages -----------------------------------------------
    -- Disbursed rows are included for visibility but will NOT be modified.
    -- -------------------------------------------------------------------------

    SELECT
        ld.APP_REF_NO,
        ldd.lead_no                                  AS Lead_No,
        ld.Customer_name,
        ld.lead_stage,
        -- Inception date = earliest OriginalDisbDate in the postponement log
        -- (i.e. the very first date before any shift was ever applied).
        -- If no history exists the current Disb_Date is the inception date.
        ISNULL(
            (
                SELECT MIN(pl.OriginalDisbDate)
                FROM [dbo].[HF48_POSTPONEMENT_LOG] pl
                WHERE pl.Lead_No = ldd.lead_no
                  AND CAST(pl.OriginalDisbDate AS DATE) <= CAST(ldd.Disb_Date AS DATE)
            ),
            ldd.Disb_Date
        )                                            AS InceptionDisbDate,
        ldd.Disb_Date                                AS OldDisbDate,
        DATEADD(DAY, @ShiftDays, ldd.Disb_Date)      AS NewDisbDate,
        ldd.Disb_amount,
        ldf.finance_amount,
        --ldd.DisbursedToDate,
        ldd.disb_status,
        ldd.MilestonePaymentPct,
        ldm.dev_tier,
        ISNULL(lproj.value_tranche, '-')             AS value_tranche,
        -- GroupIndex for row colour banding by application
        DENSE_RANK() OVER (ORDER BY ld.APP_REF_NO)  AS GroupIndex
    FROM [dbo].[LEAD_DETAILS_DISB] ldd
    INNER JOIN [dbo].[LEAD_DETAILS] ld
        ON ld.lead_no = ldd.lead_no
 INNER JOIN [dbo].[LEAD_DETAILS_FINANCE] ldf
        ON ldf.lead_no = ldd.lead_no

    LEFT JOIN [dbo].[LEAD_DETAILS_Property] ldp
        ON ldp.lead_no = ldd.lead_no
 LEFT JOIN [dbo].[LEAD_DEVELOPER_MASTER] ldm
     ON ldm.DEVELOPERNAME = ldp.Property_DeveloperName
    AND ISNULL(ldm.Status, '') = 'A'

        LEFT JOIN [dbo].[lead_project] lproj
                ON lproj.PROJECTNAME = ldp.Property_ProjectName
             AND ISNULL(lproj.status, '') = 'A'
    WHERE ldp.Property_ProjectID = @Property_ProjectID
      AND ld.lead_stage IN ('END_OF_PROCESS', 'OPS_PMU', 'OPS_LODGMENT',
                             'OPS_LODGEMENT', 'Disbursed')
            AND ISNULL(ldd.Disb_Status, '') <> ''
            AND ISNULL(ldd.Status, '') = 'A'
            AND ISNULL(ld.APP_REF_NO, '') <> ''
            AND ISNULL(ldf.LEAD_Product_ISTINSNA, '') = 'HF48'
 
      -- Optional filters
      AND (ISNULL(@AppRefNo,'') = '' OR ld.APP_REF_NO LIKE '%' + @AppRefNo + '%')
      AND (ISNULL(@DisbStatus,'') = '' OR ldd.disb_status = @DisbStatus)
      -- Date range: only schedules whose current Disb_Date falls within the range
      AND (@FromDisbDate IS NULL OR CAST(ldd.Disb_Date AS DATE) >= CAST(@FromDisbDate AS DATE))
      AND (@ToDisbDate   IS NULL OR CAST(ldd.Disb_Date AS DATE) <= CAST(@ToDisbDate   AS DATE))
    ORDER BY ld.APP_REF_NO, ldd.Disb_Date
END
GO

-- =============================================
-- 2. Proc_HF48_BulkPostpone_GetScheduleHistory
--    Returns the complete postponement/hold
--    history for a single schedule (app+lead).
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_GetScheduleHistory]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetScheduleHistory]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetScheduleHistory]
    @APP_REF_NO NVARCHAR(50)  = NULL,
    @Lead_No    NVARCHAR(50)  = NULL
AS
BEGIN
    SET NOCOUNT ON

    -- Join the bulk-request detail table to the request header to get
    -- the full workflow context (maker, checker, reason, dates).
    SELECT
        d.APP_REF_NO,
        d.RequestID,
        r.RequestType,
        d.OldDisbDate,
        d.NewDisbDate,
        r.ShiftDays,
        d.OldDisbStatus,
        d.NewDisbStatus,
        r.MakerUser,
        r.MakerOn,
        r.CheckerUser,
        r.CheckerOn,
        r.[Status]   AS RequestStatus,
        r.Reason,
        r.CheckerRemarks
    FROM [dbo].[HF48_BulkPostpone_RequestDetail] d
    INNER JOIN [dbo].[HF48_BulkPostpone_Requests] r
        ON r.RequestID = d.RequestID
    WHERE r.[Status] IN ('Approved', 'Released')
      AND (ISNULL(@APP_REF_NO,'') = '' OR d.APP_REF_NO = @APP_REF_NO)
      AND (ISNULL(@Lead_No,'') = '' OR d.Lead_No = @Lead_No)
    ORDER BY r.CheckerOn DESC, r.MakerOn DESC
END
GO

PRINT '== Script 11: Proc_HF48_BulkPostpone_Preview and GetScheduleHistory created. =='
GO
 