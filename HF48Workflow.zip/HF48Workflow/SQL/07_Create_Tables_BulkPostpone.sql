USE [LMS_DEV]
GO

-- =============================================
-- HF48 Bulk Postponement - Maker/Checker tables
-- =============================================

-- 1. Postponement Request Header (one row per Maker submission)
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BULK_POSTPONE_REQUEST]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[HF48_BULK_POSTPONE_REQUEST]
    (
        RequestID         INT IDENTITY(1,1) PRIMARY KEY,
        Property_ProjectID    NVARCHAR(50)  NOT NULL,
        Property_ProjectName  NVARCHAR(200) NOT NULL,
        Property_DeveloperName NVARCHAR(200),
        ShiftDays         INT NOT NULL,                    -- e.g. 30, 60, 90
        Reason            NVARCHAR(1000) NOT NULL,
        Status            NVARCHAR(30) NOT NULL DEFAULT 'Pending Approval',
                                                          -- 'Pending Approval','Approved','Rejected','Cancelled'
        AffectedAppCount  INT NOT NULL DEFAULT 0,
        AffectedRowCount  INT NOT NULL DEFAULT 0,
        MakerUser         NVARCHAR(100) NOT NULL,
        MakerOn           DATETIME      NOT NULL DEFAULT GETDATE(),
        CheckerUser       NVARCHAR(100),
        CheckerOn         DATETIME,
        CheckerRemarks    NVARCHAR(1000)
    )
END
GO

-- 2. Postponement Request Detail (one row per pending schedule snapshot)
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BULK_POSTPONE_DETAIL]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[HF48_BULK_POSTPONE_DETAIL]
    (
        DetailID        INT IDENTITY(1,1) PRIMARY KEY,
        RequestID       INT NOT NULL
            CONSTRAINT FK_HF48_BULK_POSTPONE_DETAIL_REQ
            FOREIGN KEY REFERENCES [dbo].[HF48_BULK_POSTPONE_REQUEST](RequestID),
        APP_REF_NO      NVARCHAR(50)  NOT NULL,
        Lead_No         NVARCHAR(50)  NOT NULL,
        Customer_Name   NVARCHAR(200),
        OldDisbDate     DATETIME      NOT NULL,
        NewDisbDate     DATETIME      NOT NULL,
        Disb_Amount     DECIMAL(18,2),
        Disb_Status     NVARCHAR(30),    -- Hold / Not Disbursed (snapshot)
        Applied         BIT NOT NULL DEFAULT 0,
        AppliedOn       DATETIME
    )
END
GO

PRINT 'HF48_BULK_POSTPONE_REQUEST and HF48_BULK_POSTPONE_DETAIL created successfully.'
GO
