USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_BulkPostpone_GetProjects
-- Distinct HF48 projects that currently have at least one
-- pending (non-disbursed) schedule. Feeds the Maker dropdown.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_GetProjects]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_GetProjects]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_GetProjects]
AS
BEGIN
    SET NOCOUNT ON

    SELECT DISTINCT
        ldp.Property_ProjectID,
        ldp.Property_ProjectName,
        ldp.Property_DeveloperName,
        ISNULL(lpm.value_tranche,'No-Hold') AS value_tranche,
        COUNT(DISTINCT ld.APP_REF_NO) OVER (PARTITION BY ldp.Property_ProjectID) AS AppCount
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS_FINANCE ldf  ON ldd.lead_no = ldf.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldf.lead_no
    INNER JOIN LEAD_DETAILS ld           ON ld.lead_no  = ldf.lead_no
    LEFT  JOIN lead_project lpm          ON lpm.PROJECTNAME = ldp.Property_ProjectName
    WHERE ldf.LEAD_Product_ISTINSNA = 'HF48'
      AND ISNULL(ldd.Status,'') = 'A'
      AND ISNULL(ldd.disb_status,'') IN ('Hold','Not Disbursed')
    ORDER BY ldp.Property_ProjectName
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_Preview
-- Given a Project + ShiftDays, returns the list of
-- pending schedules with old vs new dates so the Maker
-- can review impact before submitting.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_Preview]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_Preview]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_Preview]
    @Property_ProjectID NVARCHAR(50),
    @ShiftDays          INT
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        ld.APP_REF_NO,
        ldd.Lead_No,
        ld.Customer_name,
        ldd.Disb_Date                          AS OldDisbDate,
        DATEADD(DAY, @ShiftDays, ldd.Disb_Date) AS NewDisbDate,
        ldd.Disb_amount,
        ldd.disb_status,
        ldd.MilestonePaymentPct,
        ldd.PropertyPaymentPct,
        ldd.FinancePaymentPct,
        ldp.Property_ProjectName,
        ldp.Property_DeveloperName,
        ISNULL(ldm.dev_tier,'Tier 2') AS dev_tier
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS_FINANCE ldf  ON ldd.lead_no = ldf.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldf.lead_no
    INNER JOIN LEAD_DETAILS ld           ON ld.lead_no  = ldf.lead_no
    LEFT  JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName
    WHERE ldf.LEAD_Product_ISTINSNA = 'HF48'
      AND ISNULL(ldd.Status,'') = 'A'
      AND ISNULL(ldd.disb_status,'') IN ('Hold','Not Disbursed')
      AND ldp.Property_ProjectID = @Property_ProjectID
    ORDER BY ld.APP_REF_NO, ldd.Disb_Date
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_GetRequests
-- Lists requests (default = Pending Approval). Used by the
-- Checker queue and the Audit panel.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_GetRequests]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_GetRequests]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_GetRequests]
    @Status NVARCHAR(30) = NULL  -- NULL = all
AS
BEGIN
    SET NOCOUNT ON

    SELECT TOP 200
        RequestID, Property_ProjectID, Property_ProjectName, Property_DeveloperName,
        ShiftDays, Reason, Status, AffectedAppCount, AffectedRowCount,
        MakerUser, MakerOn, CheckerUser, CheckerOn, CheckerRemarks
    FROM HF48_BULK_POSTPONE_REQUEST
    WHERE (ISNULL(@Status,'') = '' OR Status = @Status)
    ORDER BY MakerOn DESC
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_GetRequestDetail
-- Returns the line items for a single request, so the
-- Checker can see exactly what will move.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]
    @RequestID INT
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        DetailID, RequestID, APP_REF_NO, Lead_No, Customer_Name,
        OldDisbDate, NewDisbDate, Disb_Amount, Disb_Status,
        Applied, AppliedOn
    FROM HF48_BULK_POSTPONE_DETAIL
    WHERE RequestID = @RequestID
    ORDER BY APP_REF_NO, OldDisbDate
END
GO

PRINT 'BulkPostpone lookup procs (GetProjects, Preview, GetRequests, GetRequestDetail) created.'
GO
