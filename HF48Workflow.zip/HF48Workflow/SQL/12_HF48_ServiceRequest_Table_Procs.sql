-- =============================================================
-- DEPRECATED: All objects renamed.
-- See 12_ServiceRequest_Data_Table_Procs.sql for current version.
-- =============================================================


-- =============================================
-- 1. Table
-- =============================================
IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_Service_Request]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[HF48_Service_Request]
    (
        -- Primary key (ServiceRequestNo from CSV)
        SRNo                    INT               NOT NULL,

        -- Contact
        MOBILENUMBER            NVARCHAR(50)      NULL,
        PERSONAL_EMAIL          NVARCHAR(200)     NULL,
        OFFICE_EMAIL            NVARCHAR(200)     NULL,

        -- Application
        APPLICATIONID           NVARCHAR(50)      NULL,
        CUSTOMERID              NVARCHAR(50)      NULL,
        CUSTOMERNAME1           NVARCHAR(200)     NULL,
        CUSTOMERNAME2           NVARCHAR(200)     NULL,
        CUSTOMERNAME3           NVARCHAR(200)     NULL,
        CUSTOMERNAME4           NVARCHAR(200)     NULL,
        NATIONALITY1            NVARCHAR(100)     NULL,
        NATIONALITY2            NVARCHAR(100)     NULL,
        NATIONALITY3            NVARCHAR(100)     NULL,
        NATIONALITY4            NVARCHAR(100)     NULL,
        PASSPORTNUMBER          NVARCHAR(50)      NULL,
        DATEOFBIRTH1            DATETIME          NULL,
        DATEOFBIRTH2            DATETIME          NULL,
        DATEOFBIRTH3            DATETIME          NULL,
        DATEOFBIRTH4            DATETIME          NULL,
        RESIDENCYTYPE           NVARCHAR(50)      NULL,

        -- Property
        DEVELOPER               NVARCHAR(200)     NULL,
        PROPERTYNAME            NVARCHAR(200)     NULL,
        PROPERTYDETAILS         NVARCHAR(500)     NULL,
        PROPERTYTYPE            NVARCHAR(50)      NULL,
        ORIGINALPROPERTYVALUE   NUMERIC(18,4)     NULL,
        APPRAISEDPROPERTYVALUE  NUMERIC(18,4)     NULL,
        BUILTUPAREA             NUMERIC(18,4)     NULL,
        ISTISNATENOR            INT               NULL,
        IJARATENOR              INT               NULL,

        -- Employment & Finance
        EMPLOYMENTTYPE          NVARCHAR(100)     NULL,
        INCOME1                 NUMERIC(18,4)     NULL,
        INCOME2                 NUMERIC(18,4)     NULL,
        INCOME3                 NUMERIC(18,4)     NULL,
        INCOME4                 NUMERIC(18,4)     NULL,
        FINANCEVALUE            NUMERIC(18,4)     NULL,
        DOWNPAYMENT             NUMERIC(18,4)     NULL,
        DSR                     NUMERIC(18,4)     NULL,
        FTV                     NUMERIC(18,4)     NULL,
        INSTALLMENTAMOUNT       NUMERIC(18,4)     NULL,
        CORPORATECATEGORY       NVARCHAR(100)     NULL,
        CURRENTEMPLOYER1        NVARCHAR(200)     NULL,
        CURRENTEMPLOYER2        NVARCHAR(200)     NULL,
        CURRENTEMPLOYER3        NVARCHAR(200)     NULL,
        CURRENTEMPLOYER4        NVARCHAR(200)     NULL,
        DESIGNATION1            NVARCHAR(200)     NULL,
        DESIGNATION2            NVARCHAR(200)     NULL,
        DESIGNATION3            NVARCHAR(200)     NULL,
        DESIGNATION4            NVARCHAR(200)     NULL,
        CURRENTSTATUS           NVARCHAR(100)     NULL,
        LASTUPDATED             DATETIME          NULL,
        EDUCATION1              NVARCHAR(100)     NULL,
        EDUCATION2              NVARCHAR(100)     NULL,
        EDUCATION3              NVARCHAR(100)     NULL,
        EDUCATION4              NVARCHAR(100)     NULL,
        FINALRATE               NUMERIC(18,6)     NULL,
        PREAPPROVALNO           NVARCHAR(50)      NULL,
        PROFITFEE               NUMERIC(18,4)     NULL,
        PURCHASETYPE            NVARCHAR(50)      NULL,
        SELLERNAME              NVARCHAR(200)     NULL,
        ISTISNAPRODUCT          NVARCHAR(50)      NULL,
        IJARAPRODUCT            NVARCHAR(50)      NULL,

        -- Mailing / Contact details
        MAILING_POBOX           NVARCHAR(50)      NULL,
        MAILING_CITY            NVARCHAR(100)     NULL,
        MAILING_COUNTRY         NVARCHAR(100)     NULL,
        MOBILECODE              NVARCHAR(10)      NULL,
        MOBILENUMBER1           NVARCHAR(50)      NULL,
        RESI_TEL_CODE           NVARCHAR(10)      NULL,
        RESI_TEL_NUM            NVARCHAR(50)      NULL,
        OFFICE_TEL_CODE         NVARCHAR(10)      NULL,
        OFFICE_TEL_NUM          NVARCHAR(50)      NULL,
        HC_TEL_CODE             NVARCHAR(10)      NULL,
        HC_TEL_NUM              NVARCHAR(50)      NULL,
        PERSONAL_EMAIL1         NVARCHAR(200)     NULL,
        OFFICE_EMAIL1           NVARCHAR(200)     NULL,
        FAX_CODE                NVARCHAR(10)      NULL,
        FAX_NUMBER              NVARCHAR(50)      NULL,
        RESI_ADDRESS1           NVARCHAR(500)     NULL,
        RESI_ADDRESS2           NVARCHAR(500)     NULL,
        RESI_ADDRESS3           NVARCHAR(500)     NULL,
        RESI_ADDRESS4           NVARCHAR(500)     NULL,
        OFFICE_ADDRESS1         NVARCHAR(500)     NULL,
        OFFICE_ADDRESS2         NVARCHAR(500)     NULL,
        OFFICE_ADDRESS3         NVARCHAR(500)     NULL,

        -- Workflow audit
        MAKER_ID                NVARCHAR(100)     NULL,
        MAKER_DT_STAMP          DATETIME          NULL,
        CHECKER_ID              NVARCHAR(100)     NULL,
        CHECKER_DT_STAMP        DATETIME          NULL,
        MOD_NO                  INT               NULL,
        WORKNAME                NVARCHAR(200)     NULL,
        ALTERNATE_CONTACT       NVARCHAR(50)      NULL,
        ALTERNATE_CONTACT_CODE  NVARCHAR(10)      NULL,
        HOMECOUNTRY_ADD1        NVARCHAR(500)     NULL,
        HOMECOUNTRY_ADD2        NVARCHAR(500)     NULL,
        HOMECOUNTRY_ADD3        NVARCHAR(500)     NULL,
        SEC_STATUS              NVARCHAR(50)      NULL,

        -- Co-applicants
        CUSTOMERID2             NVARCHAR(50)      NULL,
        CUSTOMERID3             NVARCHAR(50)      NULL,
        CUSTOMERID4             NVARCHAR(50)      NULL,
        PASSPORTNUMBER2         NVARCHAR(50)      NULL,
        PASSPORTNUMBER3         NVARCHAR(50)      NULL,
        PASSPORTNUMBER4         NVARCHAR(50)      NULL,

        -- Property / Project metadata
        BRANCH_CODE             NVARCHAR(10)      NULL,
        PROPERTY_PHASE          NVARCHAR(100)     NULL,
        PROPERTYID              NVARCHAR(50)      NULL,
        OL_GENERATION_DATE      DATETIME          NULL,
        OL_ACCEPTANCE_DATE      DATETIME          NULL,
        APP_START_DATE          DATETIME          NULL,
        SALES_OFFICER           NVARCHAR(100)     NULL,
        CHANNEL                 NVARCHAR(50)      NULL,
        CASE_SUBMISSION_DATE    DATETIME          NULL,
        SPREAD                  NUMERIC(18,6)     NULL,
        CARPORATE_CATEGORY      NVARCHAR(100)     NULL,
        PSF                     NVARCHAR(50)      NULL,
        EXPECTED_COMPLETION_DATE DATETIME         NULL,
        DELAYCHARGESYN          NVARCHAR(5)       NULL,
        LEAD_NO                 NVARCHAR(50)      NULL,
        STAFF_DISCOUNT          NUMERIC(18,4)     NULL,
        STAFF_ID                NVARCHAR(50)      NULL,
        LIFEINSURANCECOVER      NVARCHAR(50)      NULL,
        PORTFOLIO               NVARCHAR(100)     NULL,
        PRODUCT_TYPE            NVARCHAR(100)     NULL,
        MA_NAME                 NVARCHAR(200)     NULL,
        PRODUCT_SUB_TYPE        NVARCHAR(100)     NULL,
        STAFF_YN                NCHAR(1)          NULL,
        MILESTONE_PROJECT       NVARCHAR(200)     NULL,
        A_Value                 NUMERIC(18,4)     NULL,

        -- Customer detail copy / extended
        CUSTOMERID1             NVARCHAR(50)      NULL,
        CUSTOMER_CATEGORY       NVARCHAR(100)     NULL,
        CUST_SEGMENT            NVARCHAR(100)     NULL,
        STAFF_YN1               NCHAR(1)          NULL,
        CURRENTSTATUS1          NVARCHAR(100)     NULL,
        DATEOFBIRTH11           DATETIME          NULL,
        MAILING_COUNTRY1        NVARCHAR(100)     NULL,
        MAILING_POBOX1          NVARCHAR(50)      NULL,
        MOBILECODE1             NVARCHAR(10)      NULL,
        MOBILENUMBER2           NVARCHAR(50)      NULL,
        PASSPORTNUMBER1         NVARCHAR(50)      NULL,
        PERSONAL_EMAIL2         NVARCHAR(200)     NULL,
        OFFICE_EMAIL2           NVARCHAR(200)     NULL,
        RESI_ADDRESS11          NVARCHAR(500)     NULL,
        RESI_ADDRESS21          NVARCHAR(500)     NULL,
        RESI_ADDRESS31          NVARCHAR(500)     NULL,
        RESI_TEL_CODE1          NVARCHAR(10)      NULL,
        RESI_TEL_NUM1           NVARCHAR(50)      NULL,
        CUSTOMER_PASSPORTNO     NVARCHAR(50)      NULL,
        EMIRATES_ID             NVARCHAR(50)      NULL,
        CUSTOMERNAME11          NVARCHAR(200)     NULL,
        CUSTOMERNAME21          NVARCHAR(200)     NULL,
        CUSTOMERNAME31          NVARCHAR(200)     NULL,
        NATIONALITY11           NVARCHAR(100)     NULL,
        BRANCH_CODE1            NVARCHAR(10)      NULL,
        TRADE_LIC_NO            NVARCHAR(50)      NULL,
        RECORD_STAT             NVARCHAR(10)      NULL,
        CUSTOMER_TYPE           NVARCHAR(50)      NULL,
        APPLICATION_ID          NVARCHAR(50)      NULL,

        -- Loan / account data
        ACTUAL_BOUNCE           NUMERIC(18,4)     NULL,
        ADR_AMT                 NUMERIC(18,4)     NULL,
        ADR_DATE                DATETIME          NULL,
        APP_OFFER_DATE          DATETIME          NULL,
        APP_STRAT_DATE          DATETIME          NULL,
        CONT_STAT               NVARCHAR(50)      NULL,
        CURR_ACC_BAL            NUMERIC(18,4)     NULL,
        CURR_RATE               NUMERIC(18,6)     NULL,
        DELINQ_BUCKET           NVARCHAR(20)      NULL,
        DELINQ_STAT             NVARCHAR(20)      NULL,
        EMI_AMOUNT              NUMERIC(18,4)     NULL,
        EMI_DATE                DATETIME          NULL,
        EMI_FREQUENCY           NVARCHAR(20)      NULL,
        IJARA_BOOKED            NVARCHAR(20)      NULL,
        IJARA_BOOKED_DATE       DATETIME          NULL,
        INSTALL_NO              INT               NULL,
        LAND_REG                NVARCHAR(100)     NULL,
        MATURITY_DATE           DATETIME          NULL,
        PDC_AMOUNT              NUMERIC(18,4)     NULL,
        PDC_NO                  NVARCHAR(50)      NULL,
        PRIN_OS                 NUMERIC(18,4)     NULL,
        REM_TENOR_CURR          INT               NULL,
        REPAY_TENOR             INT               NULL,
        RETURN_VALUE            NUMERIC(18,4)     NULL,
        TBR_CURR                NVARCHAR(50)      NULL,
        TOT_INST_NO             INT               NULL,
        TOTAL_BOUNCE            INT               NULL,
        DQ_TYPE                 NVARCHAR(50)      NULL,
        VALUE_DATE              DATETIME          NULL,
        CONTRACT_STATUS         NVARCHAR(50)      NULL,
        MASTER_DEV_ID           NVARCHAR(50)      NULL,
        INSTALLMENT_NO          INT               NULL,
        DR_SETL_AC              NVARCHAR(50)      NULL,
        contract_ref_no         NVARCHAR(50)      NULL,
        CIF                     NVARCHAR(50)      NULL,

        -- Employment extended
        Employment_Type         NVARCHAR(100)     NULL,
        Name_Of_Employer        NVARCHAR(200)     NULL,
        Add_Of_Employer         NVARCHAR(500)     NULL,
        Designation             NVARCHAR(200)     NULL,
        Repayment_Mode          NVARCHAR(100)     NULL,
        Repayment_AC            NVARCHAR(50)      NULL,
        Repayment_Bank          NVARCHAR(200)     NULL,
        Land_Regestration       NVARCHAR(100)     NULL,
        Alternate_Cont_No       NVARCHAR(50)      NULL,
        H_Country_Phone         NVARCHAR(50)      NULL,

        -- Standard audit columns added at import time
        ImportedBy              NVARCHAR(100)     NULL    DEFAULT 'SYSTEM',
        ImportedOn              DATETIME          NULL    DEFAULT GETDATE(),
        UpdatedBy               NVARCHAR(100)     NULL,
        UpdatedOn               DATETIME          NULL,

        CONSTRAINT PK_HF48_Service_Request PRIMARY KEY CLUSTERED (SRNo ASC)
    )
    PRINT 'Table HF48_Service_Request created.'
END
ELSE
    PRINT 'Table HF48_Service_Request already exists - skipped.'
GO

-- =============================================
-- 2. Table-Valued Parameter type
--    Used by Proc_HF48_ServiceRequest_Insert
--    to receive a DataTable from C# / ASP.NET
-- =============================================
IF NOT EXISTS (
    SELECT 1 FROM sys.types WHERE is_table_type = 1 AND name = 'TVP_HF48_ServiceRequest'
)
BEGIN
    -- Create a UDTT with the same columns as the table (excluding audit cols)
    EXEC ('
    CREATE TYPE [dbo].[TVP_HF48_ServiceRequest] AS TABLE
    (
        SRNo                    INT               NOT NULL,
        MOBILENUMBER            NVARCHAR(50)      NULL,
        PERSONAL_EMAIL          NVARCHAR(200)     NULL,
        OFFICE_EMAIL            NVARCHAR(200)     NULL,
        APPLICATIONID           NVARCHAR(50)      NULL,
        CUSTOMERID              NVARCHAR(50)      NULL,
        CUSTOMERNAME1           NVARCHAR(200)     NULL,
        CUSTOMERNAME2           NVARCHAR(200)     NULL,
        CUSTOMERNAME3           NVARCHAR(200)     NULL,
        CUSTOMERNAME4           NVARCHAR(200)     NULL,
        NATIONALITY1            NVARCHAR(100)     NULL,
        NATIONALITY2            NVARCHAR(100)     NULL,
        NATIONALITY3            NVARCHAR(100)     NULL,
        NATIONALITY4            NVARCHAR(100)     NULL,
        PASSPORTNUMBER          NVARCHAR(50)      NULL,
        DATEOFBIRTH1            DATETIME          NULL,
        DATEOFBIRTH2            DATETIME          NULL,
        DATEOFBIRTH3            DATETIME          NULL,
        DATEOFBIRTH4            DATETIME          NULL,
        RESIDENCYTYPE           NVARCHAR(50)      NULL,
        DEVELOPER               NVARCHAR(200)     NULL,
        PROPERTYNAME            NVARCHAR(200)     NULL,
        PROPERTYDETAILS         NVARCHAR(500)     NULL,
        PROPERTYTYPE            NVARCHAR(50)      NULL,
        ORIGINALPROPERTYVALUE   NUMERIC(18,4)     NULL,
        APPRAISEDPROPERTYVALUE  NUMERIC(18,4)     NULL,
        BUILTUPAREA             NUMERIC(18,4)     NULL,
        ISTISNATENOR            INT               NULL,
        IJARATENOR              INT               NULL,
        EMPLOYMENTTYPE          NVARCHAR(100)     NULL,
        INCOME1                 NUMERIC(18,4)     NULL,
        INCOME2                 NUMERIC(18,4)     NULL,
        INCOME3                 NUMERIC(18,4)     NULL,
        INCOME4                 NUMERIC(18,4)     NULL,
        FINANCEVALUE            NUMERIC(18,4)     NULL,
        DOWNPAYMENT             NUMERIC(18,4)     NULL,
        DSR                     NUMERIC(18,4)     NULL,
        FTV                     NUMERIC(18,4)     NULL,
        INSTALLMENTAMOUNT       NUMERIC(18,4)     NULL,
        CORPORATECATEGORY       NVARCHAR(100)     NULL,
        CURRENTEMPLOYER1        NVARCHAR(200)     NULL,
        CURRENTEMPLOYER2        NVARCHAR(200)     NULL,
        CURRENTEMPLOYER3        NVARCHAR(200)     NULL,
        CURRENTEMPLOYER4        NVARCHAR(200)     NULL,
        DESIGNATION1            NVARCHAR(200)     NULL,
        DESIGNATION2            NVARCHAR(200)     NULL,
        DESIGNATION3            NVARCHAR(200)     NULL,
        DESIGNATION4            NVARCHAR(200)     NULL,
        CURRENTSTATUS           NVARCHAR(100)     NULL,
        LASTUPDATED             DATETIME          NULL,
        EDUCATION1              NVARCHAR(100)     NULL,
        EDUCATION2              NVARCHAR(100)     NULL,
        EDUCATION3              NVARCHAR(100)     NULL,
        EDUCATION4              NVARCHAR(100)     NULL,
        FINALRATE               NUMERIC(18,6)     NULL,
        PREAPPROVALNO           NVARCHAR(50)      NULL,
        PROFITFEE               NUMERIC(18,4)     NULL,
        PURCHASETYPE            NVARCHAR(50)      NULL,
        SELLERNAME              NVARCHAR(200)     NULL,
        ISTISNAPRODUCT          NVARCHAR(50)      NULL,
        IJARAPRODUCT            NVARCHAR(50)      NULL,
        MAILING_POBOX           NVARCHAR(50)      NULL,
        MAILING_CITY            NVARCHAR(100)     NULL,
        MAILING_COUNTRY         NVARCHAR(100)     NULL,
        MOBILECODE              NVARCHAR(10)      NULL,
        MOBILENUMBER1           NVARCHAR(50)      NULL,
        RESI_TEL_CODE           NVARCHAR(10)      NULL,
        RESI_TEL_NUM            NVARCHAR(50)      NULL,
        OFFICE_TEL_CODE         NVARCHAR(10)      NULL,
        OFFICE_TEL_NUM          NVARCHAR(50)      NULL,
        HC_TEL_CODE             NVARCHAR(10)      NULL,
        HC_TEL_NUM              NVARCHAR(50)      NULL,
        PERSONAL_EMAIL1         NVARCHAR(200)     NULL,
        OFFICE_EMAIL1           NVARCHAR(200)     NULL,
        FAX_CODE                NVARCHAR(10)      NULL,
        FAX_NUMBER              NVARCHAR(50)      NULL,
        RESI_ADDRESS1           NVARCHAR(500)     NULL,
        RESI_ADDRESS2           NVARCHAR(500)     NULL,
        RESI_ADDRESS3           NVARCHAR(500)     NULL,
        RESI_ADDRESS4           NVARCHAR(500)     NULL,
        OFFICE_ADDRESS1         NVARCHAR(500)     NULL,
        OFFICE_ADDRESS2         NVARCHAR(500)     NULL,
        OFFICE_ADDRESS3         NVARCHAR(500)     NULL,
        MAKER_ID                NVARCHAR(100)     NULL,
        MAKER_DT_STAMP          DATETIME          NULL,
        CHECKER_ID              NVARCHAR(100)     NULL,
        CHECKER_DT_STAMP        DATETIME          NULL,
        MOD_NO                  INT               NULL,
        WORKNAME                NVARCHAR(200)     NULL,
        ALTERNATE_CONTACT       NVARCHAR(50)      NULL,
        ALTERNATE_CONTACT_CODE  NVARCHAR(10)      NULL,
        HOMECOUNTRY_ADD1        NVARCHAR(500)     NULL,
        HOMECOUNTRY_ADD2        NVARCHAR(500)     NULL,
        HOMECOUNTRY_ADD3        NVARCHAR(500)     NULL,
        SEC_STATUS              NVARCHAR(50)      NULL,
        CUSTOMERID2             NVARCHAR(50)      NULL,
        CUSTOMERID3             NVARCHAR(50)      NULL,
        CUSTOMERID4             NVARCHAR(50)      NULL,
        PASSPORTNUMBER2         NVARCHAR(50)      NULL,
        PASSPORTNUMBER3         NVARCHAR(50)      NULL,
        PASSPORTNUMBER4         NVARCHAR(50)      NULL,
        BRANCH_CODE             NVARCHAR(10)      NULL,
        PROPERTY_PHASE          NVARCHAR(100)     NULL,
        PROPERTYID              NVARCHAR(50)      NULL,
        OL_GENERATION_DATE      DATETIME          NULL,
        OL_ACCEPTANCE_DATE      DATETIME          NULL,
        APP_START_DATE          DATETIME          NULL,
        SALES_OFFICER           NVARCHAR(100)     NULL,
        CHANNEL                 NVARCHAR(50)      NULL,
        CASE_SUBMISSION_DATE    DATETIME          NULL,
        SPREAD                  NUMERIC(18,6)     NULL,
        CARPORATE_CATEGORY      NVARCHAR(100)     NULL,
        PSF                     NVARCHAR(50)      NULL,
        EXPECTED_COMPLETION_DATE DATETIME         NULL,
        DELAYCHARGESYN          NVARCHAR(5)       NULL,
        LEAD_NO                 NVARCHAR(50)      NULL,
        STAFF_DISCOUNT          NUMERIC(18,4)     NULL,
        STAFF_ID                NVARCHAR(50)      NULL,
        LIFEINSURANCECOVER      NVARCHAR(50)      NULL,
        PORTFOLIO               NVARCHAR(100)     NULL,
        PRODUCT_TYPE            NVARCHAR(100)     NULL,
        MA_NAME                 NVARCHAR(200)     NULL,
        PRODUCT_SUB_TYPE        NVARCHAR(100)     NULL,
        STAFF_YN                NCHAR(1)          NULL,
        MILESTONE_PROJECT       NVARCHAR(200)     NULL,
        A_Value                 NUMERIC(18,4)     NULL,
        CUSTOMERID1             NVARCHAR(50)      NULL,
        CUSTOMER_CATEGORY       NVARCHAR(100)     NULL,
        CUST_SEGMENT            NVARCHAR(100)     NULL,
        STAFF_YN1               NCHAR(1)          NULL,
        CURRENTSTATUS1          NVARCHAR(100)     NULL,
        DATEOFBIRTH11           DATETIME          NULL,
        MAILING_COUNTRY1        NVARCHAR(100)     NULL,
        MAILING_POBOX1          NVARCHAR(50)      NULL,
        MOBILECODE1             NVARCHAR(10)      NULL,
        MOBILENUMBER2           NVARCHAR(50)      NULL,
        PASSPORTNUMBER1         NVARCHAR(50)      NULL,
        PERSONAL_EMAIL2         NVARCHAR(200)     NULL,
        OFFICE_EMAIL2           NVARCHAR(200)     NULL,
        RESI_ADDRESS11          NVARCHAR(500)     NULL,
        RESI_ADDRESS21          NVARCHAR(500)     NULL,
        RESI_ADDRESS31          NVARCHAR(500)     NULL,
        RESI_TEL_CODE1          NVARCHAR(10)      NULL,
        RESI_TEL_NUM1           NVARCHAR(50)      NULL,
        CUSTOMER_PASSPORTNO     NVARCHAR(50)      NULL,
        EMIRATES_ID             NVARCHAR(50)      NULL,
        CUSTOMERNAME11          NVARCHAR(200)     NULL,
        CUSTOMERNAME21          NVARCHAR(200)     NULL,
        CUSTOMERNAME31          NVARCHAR(200)     NULL,
        NATIONALITY11           NVARCHAR(100)     NULL,
        BRANCH_CODE1            NVARCHAR(10)      NULL,
        TRADE_LIC_NO            NVARCHAR(50)      NULL,
        RECORD_STAT             NVARCHAR(10)      NULL,
        CUSTOMER_TYPE           NVARCHAR(50)      NULL,
        APPLICATION_ID          NVARCHAR(50)      NULL,
        ACTUAL_BOUNCE           NUMERIC(18,4)     NULL,
        ADR_AMT                 NUMERIC(18,4)     NULL,
        ADR_DATE                DATETIME          NULL,
        APP_OFFER_DATE          DATETIME          NULL,
        APP_STRAT_DATE          DATETIME          NULL,
        CONT_STAT               NVARCHAR(50)      NULL,
        CURR_ACC_BAL            NUMERIC(18,4)     NULL,
        CURR_RATE               NUMERIC(18,6)     NULL,
        DELINQ_BUCKET           NVARCHAR(20)      NULL,
        DELINQ_STAT             NVARCHAR(20)      NULL,
        EMI_AMOUNT              NUMERIC(18,4)     NULL,
        EMI_DATE                DATETIME          NULL,
        EMI_FREQUENCY           NVARCHAR(20)      NULL,
        IJARA_BOOKED            NVARCHAR(20)      NULL,
        IJARA_BOOKED_DATE       DATETIME          NULL,
        INSTALL_NO              INT               NULL,
        LAND_REG                NVARCHAR(100)     NULL,
        MATURITY_DATE           DATETIME          NULL,
        PDC_AMOUNT              NUMERIC(18,4)     NULL,
        PDC_NO                  NVARCHAR(50)      NULL,
        PRIN_OS                 NUMERIC(18,4)     NULL,
        REM_TENOR_CURR          INT               NULL,
        REPAY_TENOR             INT               NULL,
        RETURN_VALUE            NUMERIC(18,4)     NULL,
        TBR_CURR                NVARCHAR(50)      NULL,
        TOT_INST_NO             INT               NULL,
        TOTAL_BOUNCE            INT               NULL,
        DQ_TYPE                 NVARCHAR(50)      NULL,
        VALUE_DATE              DATETIME          NULL,
        CONTRACT_STATUS         NVARCHAR(50)      NULL,
        MASTER_DEV_ID           NVARCHAR(50)      NULL,
        INSTALLMENT_NO          INT               NULL,
        DR_SETL_AC              NVARCHAR(50)      NULL,
        contract_ref_no         NVARCHAR(50)      NULL,
        CIF                     NVARCHAR(50)      NULL,
        Employment_Type         NVARCHAR(100)     NULL,
        Name_Of_Employer        NVARCHAR(200)     NULL,
        Add_Of_Employer         NVARCHAR(500)     NULL,
        Designation             NVARCHAR(200)     NULL,
        Repayment_Mode          NVARCHAR(100)     NULL,
        Repayment_AC            NVARCHAR(50)      NULL,
        Repayment_Bank          NVARCHAR(200)     NULL,
        Land_Regestration       NVARCHAR(100)     NULL,
        Alternate_Cont_No       NVARCHAR(50)      NULL,
        H_Country_Phone         NVARCHAR(50)      NULL,
        PRIMARY KEY (SRNo)
    )')
    PRINT 'Type TVP_HF48_ServiceRequest created.'
END
ELSE
    PRINT 'Type TVP_HF48_ServiceRequest already exists - skipped.'
GO

-- =============================================
-- 3. Proc_HF48_ServiceRequest_Insert
--    Bulk MERGE (upsert) from TVP.
--    Called from ASP.NET C# with SqlBulkCopy
--    or a Structured TVP parameter.
--
-- C# Usage Example:
-- -----------------------------------------------
-- // Build a DataTable matching TVP column list
-- DataTable dt = BuildServiceRequestDataTable(dataSet);
--
-- using (SqlConnection conn = new SqlConnection(connStr))
-- {
--     conn.Open();
--     using (SqlCommand cmd = new SqlCommand(
--         "Proc_HF48_ServiceRequest_Insert", conn))
--     {
--         cmd.CommandType = CommandType.StoredProcedure;
--         SqlParameter p = cmd.Parameters.AddWithValue(
--             "@ServiceRequestData", dt);
--         p.SqlDbType = SqlDbType.Structured;
--         p.TypeName  = "dbo.TVP_HF48_ServiceRequest";
--
--         SqlParameter pOut = cmd.Parameters.Add(
--             "@RowsAffected", SqlDbType.Int);
--         pOut.Direction = ParameterDirection.Output;
--
--         cmd.ExecuteNonQuery();
--         int rows = (int)pOut.Value;
--     }
-- }
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_ServiceRequest_Insert]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_ServiceRequest_Insert]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_ServiceRequest_Insert]
    @ServiceRequestData [dbo].[TVP_HF48_ServiceRequest] READONLY,
    @ImportedBy         NVARCHAR(100) = 'SYSTEM',
    @RowsAffected       INT           OUTPUT
AS
BEGIN
    SET NOCOUNT ON
    SET @RowsAffected = 0

    MERGE [dbo].[HF48_Service_Request] AS target
    USING @ServiceRequestData             AS source
        ON target.SRNo = source.SRNo
    WHEN MATCHED THEN
        UPDATE SET
            MOBILENUMBER            = source.MOBILENUMBER,
            PERSONAL_EMAIL          = source.PERSONAL_EMAIL,
            OFFICE_EMAIL            = source.OFFICE_EMAIL,
            APPLICATIONID           = source.APPLICATIONID,
            CUSTOMERID              = source.CUSTOMERID,
            CUSTOMERNAME1           = source.CUSTOMERNAME1,
            CUSTOMERNAME2           = source.CUSTOMERNAME2,
            CUSTOMERNAME3           = source.CUSTOMERNAME3,
            CUSTOMERNAME4           = source.CUSTOMERNAME4,
            NATIONALITY1            = source.NATIONALITY1,
            NATIONALITY2            = source.NATIONALITY2,
            NATIONALITY3            = source.NATIONALITY3,
            NATIONALITY4            = source.NATIONALITY4,
            PASSPORTNUMBER          = source.PASSPORTNUMBER,
            DATEOFBIRTH1            = source.DATEOFBIRTH1,
            DATEOFBIRTH2            = source.DATEOFBIRTH2,
            DATEOFBIRTH3            = source.DATEOFBIRTH3,
            DATEOFBIRTH4            = source.DATEOFBIRTH4,
            RESIDENCYTYPE           = source.RESIDENCYTYPE,
            DEVELOPER               = source.DEVELOPER,
            PROPERTYNAME            = source.PROPERTYNAME,
            PROPERTYDETAILS         = source.PROPERTYDETAILS,
            PROPERTYTYPE            = source.PROPERTYTYPE,
            ORIGINALPROPERTYVALUE   = source.ORIGINALPROPERTYVALUE,
            APPRAISEDPROPERTYVALUE  = source.APPRAISEDPROPERTYVALUE,
            BUILTUPAREA             = source.BUILTUPAREA,
            ISTISNATENOR            = source.ISTISNATENOR,
            IJARATENOR              = source.IJARATENOR,
            EMPLOYMENTTYPE          = source.EMPLOYMENTTYPE,
            INCOME1                 = source.INCOME1,
            INCOME2                 = source.INCOME2,
            INCOME3                 = source.INCOME3,
            INCOME4                 = source.INCOME4,
            FINANCEVALUE            = source.FINANCEVALUE,
            DOWNPAYMENT             = source.DOWNPAYMENT,
            DSR                     = source.DSR,
            FTV                     = source.FTV,
            INSTALLMENTAMOUNT       = source.INSTALLMENTAMOUNT,
            FINALRATE               = source.FINALRATE,
            LEAD_NO                 = source.LEAD_NO,
            PRODUCT_TYPE            = source.PRODUCT_TYPE,
            CONTRACT_STATUS         = source.CONTRACT_STATUS,
            CIF                     = source.CIF,
            EMIRATES_ID             = source.EMIRATES_ID,
            UpdatedBy               = @ImportedBy,
            UpdatedOn               = GETDATE()
    WHEN NOT MATCHED BY TARGET THEN
        INSERT (
            SRNo, MOBILENUMBER, PERSONAL_EMAIL, OFFICE_EMAIL,
            APPLICATIONID, CUSTOMERID,
            CUSTOMERNAME1, CUSTOMERNAME2, CUSTOMERNAME3, CUSTOMERNAME4,
            NATIONALITY1, NATIONALITY2, NATIONALITY3, NATIONALITY4,
            PASSPORTNUMBER,
            DATEOFBIRTH1, DATEOFBIRTH2, DATEOFBIRTH3, DATEOFBIRTH4,
            RESIDENCYTYPE, DEVELOPER, PROPERTYNAME, PROPERTYDETAILS, PROPERTYTYPE,
            ORIGINALPROPERTYVALUE, APPRAISEDPROPERTYVALUE, BUILTUPAREA,
            ISTISNATENOR, IJARATENOR,
            EMPLOYMENTTYPE, INCOME1, INCOME2, INCOME3, INCOME4,
            FINANCEVALUE, DOWNPAYMENT, DSR, FTV, INSTALLMENTAMOUNT,
            CORPORATECATEGORY,
            CURRENTEMPLOYER1, CURRENTEMPLOYER2, CURRENTEMPLOYER3, CURRENTEMPLOYER4,
            DESIGNATION1, DESIGNATION2, DESIGNATION3, DESIGNATION4,
            CURRENTSTATUS, LASTUPDATED,
            EDUCATION1, EDUCATION2, EDUCATION3, EDUCATION4,
            FINALRATE, PREAPPROVALNO, PROFITFEE, PURCHASETYPE, SELLERNAME,
            ISTISNAPRODUCT, IJARAPRODUCT,
            MAILING_POBOX, MAILING_CITY, MAILING_COUNTRY,
            MOBILECODE, MOBILENUMBER1,
            RESI_TEL_CODE, RESI_TEL_NUM, OFFICE_TEL_CODE, OFFICE_TEL_NUM,
            HC_TEL_CODE, HC_TEL_NUM,
            PERSONAL_EMAIL1, OFFICE_EMAIL1, FAX_CODE, FAX_NUMBER,
            RESI_ADDRESS1, RESI_ADDRESS2, RESI_ADDRESS3, RESI_ADDRESS4,
            OFFICE_ADDRESS1, OFFICE_ADDRESS2, OFFICE_ADDRESS3,
            MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP,
            MOD_NO, WORKNAME, ALTERNATE_CONTACT, ALTERNATE_CONTACT_CODE,
            HOMECOUNTRY_ADD1, HOMECOUNTRY_ADD2, HOMECOUNTRY_ADD3,
            SEC_STATUS, CUSTOMERID2, CUSTOMERID3, CUSTOMERID4,
            PASSPORTNUMBER2, PASSPORTNUMBER3, PASSPORTNUMBER4,
            BRANCH_CODE, PROPERTY_PHASE, PROPERTYID,
            OL_GENERATION_DATE, OL_ACCEPTANCE_DATE, APP_START_DATE,
            SALES_OFFICER, CHANNEL, CASE_SUBMISSION_DATE,
            SPREAD, CARPORATE_CATEGORY, PSF, EXPECTED_COMPLETION_DATE,
            DELAYCHARGESYN, LEAD_NO, STAFF_DISCOUNT, STAFF_ID,
            LIFEINSURANCECOVER, PORTFOLIO, PRODUCT_TYPE, MA_NAME, PRODUCT_SUB_TYPE,
            STAFF_YN, MILESTONE_PROJECT, A_Value,
            CUSTOMERID1, CUSTOMER_CATEGORY, CUST_SEGMENT, STAFF_YN1,
            CURRENTSTATUS1, DATEOFBIRTH11, MAILING_COUNTRY1, MAILING_POBOX1,
            MOBILECODE1, MOBILENUMBER2, PASSPORTNUMBER1,
            PERSONAL_EMAIL2, OFFICE_EMAIL2,
            RESI_ADDRESS11, RESI_ADDRESS21, RESI_ADDRESS31,
            RESI_TEL_CODE1, RESI_TEL_NUM1,
            CUSTOMER_PASSPORTNO, EMIRATES_ID,
            CUSTOMERNAME11, CUSTOMERNAME21, CUSTOMERNAME31,
            NATIONALITY11, BRANCH_CODE1, TRADE_LIC_NO, RECORD_STAT,
            CUSTOMER_TYPE, APPLICATION_ID,
            ACTUAL_BOUNCE, ADR_AMT, ADR_DATE, APP_OFFER_DATE, APP_STRAT_DATE,
            CONT_STAT, CURR_ACC_BAL, CURR_RATE, DELINQ_BUCKET, DELINQ_STAT,
            EMI_AMOUNT, EMI_DATE, EMI_FREQUENCY, IJARA_BOOKED, IJARA_BOOKED_DATE,
            INSTALL_NO, LAND_REG, MATURITY_DATE, PDC_AMOUNT, PDC_NO,
            PRIN_OS, REM_TENOR_CURR, REPAY_TENOR, RETURN_VALUE, TBR_CURR,
            TOT_INST_NO, TOTAL_BOUNCE, DQ_TYPE, VALUE_DATE,
            CONTRACT_STATUS, MASTER_DEV_ID, INSTALLMENT_NO, DR_SETL_AC,
            contract_ref_no, CIF, Employment_Type, Name_Of_Employer,
            Add_Of_Employer, Designation, Repayment_Mode, Repayment_AC,
            Repayment_Bank, Land_Regestration, Alternate_Cont_No, H_Country_Phone,
            ImportedBy, ImportedOn
        )
        VALUES (
            source.SRNo, source.MOBILENUMBER, source.PERSONAL_EMAIL, source.OFFICE_EMAIL,
            source.APPLICATIONID, source.CUSTOMERID,
            source.CUSTOMERNAME1, source.CUSTOMERNAME2, source.CUSTOMERNAME3, source.CUSTOMERNAME4,
            source.NATIONALITY1, source.NATIONALITY2, source.NATIONALITY3, source.NATIONALITY4,
            source.PASSPORTNUMBER,
            source.DATEOFBIRTH1, source.DATEOFBIRTH2, source.DATEOFBIRTH3, source.DATEOFBIRTH4,
            source.RESIDENCYTYPE, source.DEVELOPER, source.PROPERTYNAME,
            source.PROPERTYDETAILS, source.PROPERTYTYPE,
            source.ORIGINALPROPERTYVALUE, source.APPRAISEDPROPERTYVALUE, source.BUILTUPAREA,
            source.ISTISNATENOR, source.IJARATENOR,
            source.EMPLOYMENTTYPE, source.INCOME1, source.INCOME2, source.INCOME3, source.INCOME4,
            source.FINANCEVALUE, source.DOWNPAYMENT, source.DSR, source.FTV, source.INSTALLMENTAMOUNT,
            source.CORPORATECATEGORY,
            source.CURRENTEMPLOYER1, source.CURRENTEMPLOYER2, source.CURRENTEMPLOYER3, source.CURRENTEMPLOYER4,
            source.DESIGNATION1, source.DESIGNATION2, source.DESIGNATION3, source.DESIGNATION4,
            source.CURRENTSTATUS, source.LASTUPDATED,
            source.EDUCATION1, source.EDUCATION2, source.EDUCATION3, source.EDUCATION4,
            source.FINALRATE, source.PREAPPROVALNO, source.PROFITFEE, source.PURCHASETYPE, source.SELLERNAME,
            source.ISTISNAPRODUCT, source.IJARAPRODUCT,
            source.MAILING_POBOX, source.MAILING_CITY, source.MAILING_COUNTRY,
            source.MOBILECODE, source.MOBILENUMBER1,
            source.RESI_TEL_CODE, source.RESI_TEL_NUM, source.OFFICE_TEL_CODE, source.OFFICE_TEL_NUM,
            source.HC_TEL_CODE, source.HC_TEL_NUM,
            source.PERSONAL_EMAIL1, source.OFFICE_EMAIL1, source.FAX_CODE, source.FAX_NUMBER,
            source.RESI_ADDRESS1, source.RESI_ADDRESS2, source.RESI_ADDRESS3, source.RESI_ADDRESS4,
            source.OFFICE_ADDRESS1, source.OFFICE_ADDRESS2, source.OFFICE_ADDRESS3,
            source.MAKER_ID, source.MAKER_DT_STAMP, source.CHECKER_ID, source.CHECKER_DT_STAMP,
            source.MOD_NO, source.WORKNAME, source.ALTERNATE_CONTACT, source.ALTERNATE_CONTACT_CODE,
            source.HOMECOUNTRY_ADD1, source.HOMECOUNTRY_ADD2, source.HOMECOUNTRY_ADD3,
            source.SEC_STATUS, source.CUSTOMERID2, source.CUSTOMERID3, source.CUSTOMERID4,
            source.PASSPORTNUMBER2, source.PASSPORTNUMBER3, source.PASSPORTNUMBER4,
            source.BRANCH_CODE, source.PROPERTY_PHASE, source.PROPERTYID,
            source.OL_GENERATION_DATE, source.OL_ACCEPTANCE_DATE, source.APP_START_DATE,
            source.SALES_OFFICER, source.CHANNEL, source.CASE_SUBMISSION_DATE,
            source.SPREAD, source.CARPORATE_CATEGORY, source.PSF, source.EXPECTED_COMPLETION_DATE,
            source.DELAYCHARGESYN, source.LEAD_NO, source.STAFF_DISCOUNT, source.STAFF_ID,
            source.LIFEINSURANCECOVER, source.PORTFOLIO, source.PRODUCT_TYPE, source.MA_NAME, source.PRODUCT_SUB_TYPE,
            source.STAFF_YN, source.MILESTONE_PROJECT, source.A_Value,
            source.CUSTOMERID1, source.CUSTOMER_CATEGORY, source.CUST_SEGMENT, source.STAFF_YN1,
            source.CURRENTSTATUS1, source.DATEOFBIRTH11, source.MAILING_COUNTRY1, source.MAILING_POBOX1,
            source.MOBILECODE1, source.MOBILENUMBER2, source.PASSPORTNUMBER1,
            source.PERSONAL_EMAIL2, source.OFFICE_EMAIL2,
            source.RESI_ADDRESS11, source.RESI_ADDRESS21, source.RESI_ADDRESS31,
            source.RESI_TEL_CODE1, source.RESI_TEL_NUM1,
            source.CUSTOMER_PASSPORTNO, source.EMIRATES_ID,
            source.CUSTOMERNAME11, source.CUSTOMERNAME21, source.CUSTOMERNAME31,
            source.NATIONALITY11, source.BRANCH_CODE1, source.TRADE_LIC_NO, source.RECORD_STAT,
            source.CUSTOMER_TYPE, source.APPLICATION_ID,
            source.ACTUAL_BOUNCE, source.ADR_AMT, source.ADR_DATE, source.APP_OFFER_DATE, source.APP_STRAT_DATE,
            source.CONT_STAT, source.CURR_ACC_BAL, source.CURR_RATE, source.DELINQ_BUCKET, source.DELINQ_STAT,
            source.EMI_AMOUNT, source.EMI_DATE, source.EMI_FREQUENCY, source.IJARA_BOOKED, source.IJARA_BOOKED_DATE,
            source.INSTALL_NO, source.LAND_REG, source.MATURITY_DATE, source.PDC_AMOUNT, source.PDC_NO,
            source.PRIN_OS, source.REM_TENOR_CURR, source.REPAY_TENOR, source.RETURN_VALUE, source.TBR_CURR,
            source.TOT_INST_NO, source.TOTAL_BOUNCE, source.DQ_TYPE, source.VALUE_DATE,
            source.CONTRACT_STATUS, source.MASTER_DEV_ID, source.INSTALLMENT_NO, source.DR_SETL_AC,
            source.contract_ref_no, source.CIF, source.Employment_Type, source.Name_Of_Employer,
            source.Add_Of_Employer, source.Designation, source.Repayment_Mode, source.Repayment_AC,
            source.Repayment_Bank, source.Land_Regestration, source.Alternate_Cont_No, source.H_Country_Phone,
            @ImportedBy, GETDATE()
        );

    SET @RowsAffected = @@ROWCOUNT
END
GO

-- =============================================
-- 4. Proc_HF48_ServiceRequest_Select
--    Flexible query with common filter params.
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_ServiceRequest_Select]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_ServiceRequest_Select]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_ServiceRequest_Select]
    @SRNo                INT           = NULL,
    @ApplicationID       NVARCHAR(50)  = NULL,
    @CustomerID          NVARCHAR(50)  = NULL,
    @CustomerName        NVARCHAR(200) = NULL,   -- partial match on CUSTOMERNAME1
    @LeadNo              NVARCHAR(50)  = NULL,
    @EmiratesID          NVARCHAR(50)  = NULL,
    @ProductType         NVARCHAR(100) = NULL,
    @ContractStatus      NVARCHAR(50)  = NULL,
    @ImportedFrom        DATETIME      = NULL,   -- ImportedOn >= this date
    @ImportedTo          DATETIME      = NULL,   -- ImportedOn <= this date
    @TopN                INT           = 500     -- max rows returned
AS
BEGIN
    SET NOCOUNT ON

    SELECT TOP (@TopN)
        SRNo,
        APPLICATIONID,
        CUSTOMERNAME1, CUSTOMERNAME2, CUSTOMERNAME3, CUSTOMERNAME4,
        CUSTOMERID, EMIRATES_ID,
        LEAD_NO,
        PRODUCT_TYPE,
        CONTRACT_STATUS,
        FINANCEVALUE,
        FINALRATE,
        INSTALLMENTAMOUNT,
        MATURITY_DATE,
        CURRENTSTATUS,
        PROPERTYNAME,
        PROPERTYTYPE,
        DEVELOPER,
        BRANCH_CODE,
        MAKER_ID, MAKER_DT_STAMP,
        CHECKER_ID, CHECKER_DT_STAMP,
        ImportedBy, ImportedOn,
        UpdatedBy, UpdatedOn
    FROM [dbo].[HF48_Service_Request]
    WHERE
        (@SRNo          IS NULL OR SRNo          = @SRNo)
      AND (@ApplicationID IS NULL OR APPLICATIONID LIKE '%' + @ApplicationID + '%')
      AND (@CustomerID    IS NULL OR CUSTOMERID    LIKE '%' + @CustomerID    + '%')
      AND (@CustomerName  IS NULL OR CUSTOMERNAME1 LIKE '%' + @CustomerName  + '%')
      AND (@LeadNo        IS NULL OR LEAD_NO       LIKE '%' + @LeadNo        + '%')
      AND (@EmiratesID    IS NULL OR EMIRATES_ID   LIKE '%' + @EmiratesID    + '%')
      AND (@ProductType   IS NULL OR PRODUCT_TYPE  = @ProductType)
      AND (@ContractStatus IS NULL OR CONTRACT_STATUS = @ContractStatus)
      AND (@ImportedFrom  IS NULL OR ImportedOn    >= @ImportedFrom)
      AND (@ImportedTo    IS NULL OR ImportedOn    <= @ImportedTo)
    ORDER BY SRNo
END
GO

PRINT '== Script 12: HF48_Service_Request table, TVP, Insert and Select procs created. =='
GO
