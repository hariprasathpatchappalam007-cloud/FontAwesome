USE [LMS_DEV]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Script 14: HF48 Bulk Postponement – Migrations
--
-- 1. Add InceptionDisbDate to LEAD_DETAILS_DISB
--    (never changes after initial population)
-- 2. Add ContentType to HF48_BulkPostpone_Docs
--    (fixes file-upload INSERT)
-- 3. Add snapshot columns to RequestDetail
--    (enables checker grid = maker grid replica)
-- 4. Rebuild Proc_HF48_BulkPostpone_Preview
--    - Excludes Disbursed rows
--    - Returns InceptionDisbDate, PropertyPaymentPct,
--      FinancePaymentPct, ProductCode
-- 5. Rebuild Proc_HF48_BulkPostpone_Submit
--    - Captures new snapshot columns
-- 6. Rebuild Proc_HF48_BulkPostpone_GetRequestDetail
--    - Returns all snapshot columns (checker = maker)
-- =============================================

-- ============================================================
-- 1. InceptionDisbDate on LEAD_DETAILS_DISB
--    Set once from Disb_Date; application never updates it.
-- ============================================================
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[LEAD_DETAILS_DISB]')
      AND name = 'InceptionDisbDate'
)
BEGIN
    ALTER TABLE [dbo].[LEAD_DETAILS_DISB]
        ADD InceptionDisbDate DATETIME NULL
    -- Seed existing rows: InceptionDisbDate = current Disb_Date
    UPDATE [dbo].[LEAD_DETAILS_DISB]
    SET InceptionDisbDate = Disb_Date
    WHERE InceptionDisbDate IS NULL
    PRINT 'Column InceptionDisbDate added and seeded on LEAD_DETAILS_DISB.'
END
ELSE
    PRINT 'Column InceptionDisbDate already exists on LEAD_DETAILS_DISB - skipped.'
GO

-- ============================================================
-- 2. ContentType on HF48_BulkPostpone_Docs
--    Required by BulkPostponeUploadHandler.ashx INSERT
-- ============================================================
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BulkPostpone_Docs]')
      AND name = 'ContentType'
)
BEGIN
    ALTER TABLE [dbo].[HF48_BulkPostpone_Docs]
        ADD ContentType NVARCHAR(200) NULL
    PRINT 'Column ContentType added to HF48_BulkPostpone_Docs.'
END
ELSE
    PRINT 'Column ContentType already exists on HF48_BulkPostpone_Docs - skipped.'
GO

-- ============================================================
-- 3. Snapshot columns on HF48_BulkPostpone_RequestDetail
--    Stored at Submit time so Checker grid = Maker grid
-- ============================================================
DECLARE @addCols TABLE (ColName NVARCHAR(100), ColDef NVARCHAR(200))
INSERT INTO @addCols VALUES
    ('InceptionDisbDate', 'DATETIME      NULL'),
    ('PropertyPaymentPct','DECIMAL(18,4) NULL'),
    ('FinancePaymentPct', 'DECIMAL(18,4) NULL'),
    ('MilestonePaymentPct','DECIMAL(18,4) NULL'),
    ('FinanceAmount',     'DECIMAL(18,4) NULL'),
    ('LeadStage',         'NVARCHAR(100) NULL'),
    ('DevTier',           'NVARCHAR(50)  NULL'),
    ('ValueTranche',      'NVARCHAR(100) NULL'),
    ('ProductCode',       'NVARCHAR(100) NULL')

DECLARE @col NVARCHAR(100), @def NVARCHAR(200)
DECLARE c CURSOR LOCAL FAST_FORWARD FOR
    SELECT ColName, ColDef FROM @addCols

OPEN c
FETCH NEXT FROM c INTO @col, @def
WHILE @@FETCH_STATUS = 0
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM sys.columns
        WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BulkPostpone_RequestDetail]')
          AND name = @col
    )
    BEGIN
        EXEC('ALTER TABLE [dbo].[HF48_BulkPostpone_RequestDetail] ADD [' + @col + '] ' + @def)
        PRINT 'Added column ' + @col + ' to HF48_BulkPostpone_RequestDetail.'
    END
    FETCH NEXT FROM c INTO @col, @def
END
CLOSE c; DEALLOCATE c
GO

-- ============================================================
-- 4. Proc_HF48_BulkPostpone_Preview  (full rebuild)
--    Changes:
--      - Excludes disb_status = 'Disbursed'
--      - Returns ldd.InceptionDisbDate (never changes)
--      - Returns PropertyPaymentPct, FinancePaymentPct
--      - Returns ProductCode from LEAD_Product_ISTINSNA
-- ============================================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_Preview]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Preview]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Preview]
    @Property_ProjectID NVARCHAR(100),
    @ShiftDays          INT            = 0,
    @AppRefNo           NVARCHAR(50)   = NULL,
    @DisbStatus         NVARCHAR(50)   = NULL,
    @FromDisbDate       DATETIME       = NULL,
    @ToDisbDate         DATETIME       = NULL
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        ld.APP_REF_NO,
        ldd.lead_no                                        AS Lead_No,
        ld.Customer_name,
        ld.lead_stage,
        -- NOTE: LEAD_Product_ISTINSNA column name may need adjustment
        --       for your environment (common: PRODUCTCODE, Product_Code, ISTINSNA_PRODUCT)
        ISNULL(lpi.PRODUCTCODE, '-')                       AS ProductCode,
        -- Inception date is stored on LEAD_DETAILS_DISB and never updated
        ldd.InceptionDisbDate,
        ldd.Disb_Date                                      AS OldDisbDate,
        DATEADD(DAY, @ShiftDays, ldd.Disb_Date)            AS NewDisbDate,
        ldd.Disb_amount,
        ldf.finance_amount,
        ldd.disb_status,
        ldd.PropertyPaymentPct,
        ldd.FinancePaymentPct,
        ldd.MilestonePaymentPct,
        ISNULL(ldm.dev_tier,        '-')                   AS dev_tier,
        ISNULL(lproj.value_tranche, '-')                   AS value_tranche,
        DENSE_RANK() OVER (ORDER BY ld.APP_REF_NO)         AS GroupIndex
    FROM [dbo].[LEAD_DETAILS_DISB] ldd
    INNER JOIN [dbo].[LEAD_DETAILS] ld
        ON ld.lead_no = ldd.lead_no
    INNER JOIN [dbo].[LEAD_DETAILS_FINANCE] ldf
        ON ldf.lead_no = ldd.lead_no
    LEFT JOIN [dbo].[LEAD_DETAILS_Property] ldp
        ON ldp.lead_no = ldd.lead_no
    LEFT JOIN [dbo].[LEAD_DEVELOPER_MASTER] ldm
        ON ldm.DEVELOPERNAME = ldp.Property_DeveloperName
    LEFT JOIN [dbo].[lead_project] lproj
        ON lproj.PROJECTNAME = ldp.Property_ProjectName
    LEFT JOIN [dbo].[LEAD_Product_ISTINSNA] lpi
        ON lpi.lead_no = ldd.lead_no
    WHERE ldp.Property_ProjectID = @Property_ProjectID
      -- Disbursed schedules cannot be postponed / held
      AND ldd.disb_status <> 'Disbursed'
      AND ld.lead_stage IN ('END_OF_PROCESS','OPS_PMU','OPS_LODGMENT','OPS_LODGEMENT')
      AND (ISNULL(@AppRefNo,'')  = '' OR ld.APP_REF_NO LIKE '%' + @AppRefNo + '%')
      AND (ISNULL(@DisbStatus,'')= '' OR ldd.disb_status = @DisbStatus)
      AND (@FromDisbDate IS NULL  OR CAST(ldd.Disb_Date AS DATE) >= CAST(@FromDisbDate AS DATE))
      AND (@ToDisbDate   IS NULL  OR CAST(ldd.Disb_Date AS DATE) <= CAST(@ToDisbDate   AS DATE))
    ORDER BY ld.APP_REF_NO, ldd.Disb_Date
END
GO

-- ============================================================
-- 5. Proc_HF48_BulkPostpone_Submit  (full rebuild)
--    Captures all snapshot columns into RequestDetail
-- ============================================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_Submit]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Submit]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Submit]
    @RequestType        NVARCHAR(50),
    @Property_ProjectID NVARCHAR(100) = NULL,
    @ShiftDays          INT           = 0,
    @SourceRequestID    INT           = NULL,
    @Reason             NVARCHAR(MAX) = NULL,
    @MakerUser          NVARCHAR(100),
    @DraftID            NVARCHAR(100) = NULL,
    @RequestID          INT           OUTPUT,
    @Status             NVARCHAR(50)  OUTPUT,
    @Message            NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    IF @RequestType NOT IN ('Hold','Unhold','Postpone')
    BEGIN
        SET @Status = 'FAILURE'; SET @Message = 'Invalid RequestType.'; SET @RequestID = 0; RETURN
    END
    IF @RequestType = 'Unhold' AND ISNULL(@SourceRequestID,0) = 0
    BEGIN
        SET @Status = 'FAILURE'; SET @Message = 'SourceRequestID required for Unhold.'; SET @RequestID = 0; RETURN
    END
    IF @RequestType IN ('Hold','Postpone') AND ISNULL(@Property_ProjectID,'') = ''
    BEGIN
        SET @Status = 'FAILURE'; SET @Message = 'Property_ProjectID required for Hold/Postpone.'; SET @RequestID = 0; RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_SUBMIT

        DECLARE @ProjName  NVARCHAR(200) = NULL
        DECLARE @DevName   NVARCHAR(200) = NULL
        DECLARE @AppCount  INT = 0
        DECLARE @RowCount  INT = 0

        IF @RequestType IN ('Hold','Postpone')
        BEGIN
            SELECT TOP 1 @ProjName = ldp.Property_ProjectName,
                         @DevName  = ldp.Property_DeveloperName
            FROM [dbo].[LEAD_DETAILS_Property] ldp
            WHERE ldp.Property_ProjectID = @Property_ProjectID

            SELECT @AppCount = COUNT(DISTINCT ld.APP_REF_NO), @RowCount = COUNT(*)
            FROM [dbo].[LEAD_DETAILS_DISB] ldd
            INNER JOIN [dbo].[LEAD_DETAILS] ld ON ld.lead_no = ldd.lead_no
            INNER JOIN [dbo].[LEAD_DETAILS_Property] ldp ON ldp.lead_no = ldd.lead_no
            WHERE ldp.Property_ProjectID = @Property_ProjectID
              AND ldd.disb_status IN ('Not Disbursed','Hold')
              AND ld.lead_stage IN ('END_OF_PROCESS','OPS_PMU','OPS_LODGMENT','OPS_LODGEMENT')
        END
        ELSE
        BEGIN
            SELECT @ProjName = Property_ProjectName, @DevName = Property_DeveloperName,
                   @AppCount = AffectedAppCount,     @RowCount = AffectedRowCount,
                   @Property_ProjectID = Property_ProjectID
            FROM [dbo].[HF48_BulkPostpone_Requests]
            WHERE RequestID = @SourceRequestID
        END

        INSERT INTO [dbo].[HF48_BulkPostpone_Requests]
            (RequestType, Property_ProjectID, Property_ProjectName, Property_DeveloperName,
             ShiftDays, AffectedAppCount, AffectedRowCount,
             SourceRequestID, Reason, MakerUser, MakerOn, [Status], DraftID)
        VALUES
            (@RequestType, @Property_ProjectID, @ProjName, @DevName,
             @ShiftDays, @AppCount, @RowCount,
             @SourceRequestID, @Reason, @MakerUser, GETDATE(), 'Pending Approval', @DraftID)

        SET @RequestID = SCOPE_IDENTITY()

        IF @RequestType IN ('Hold','Postpone')
        BEGIN
            INSERT INTO [dbo].[HF48_BulkPostpone_RequestDetail]
                (RequestID, APP_REF_NO, Lead_No, Customer_Name,
                 InceptionDisbDate, OldDisbDate, NewDisbDate,
                 OldDisbStatus, NewDisbStatus,
                 Disb_Amount, FinanceAmount, Applied, GroupIndex,
                 PropertyPaymentPct, FinancePaymentPct, MilestonePaymentPct,
                 LeadStage, DevTier, ValueTranche, ProductCode)
            SELECT
                @RequestID,
                ld.APP_REF_NO,
                ldd.lead_no,
                ld.Customer_name,
                ldd.InceptionDisbDate,              -- from LEAD_DETAILS_DISB (never changes)
                ldd.Disb_Date,
                DATEADD(DAY, @ShiftDays, ldd.Disb_Date),
                ldd.disb_status,
                CASE WHEN @RequestType = 'Hold' THEN 'Hold' ELSE ldd.disb_status END,
                ldd.Disb_amount,
                ldf.finance_amount,
                0,
                DENSE_RANK() OVER (ORDER BY ld.APP_REF_NO),
                ldd.PropertyPaymentPct,
                ldd.FinancePaymentPct,
                ldd.MilestonePaymentPct,
                ld.lead_stage,
                ISNULL(ldm.dev_tier, '-'),
                ISNULL(lproj.value_tranche, '-'),
                ISNULL(lpi.PRODUCTCODE, '-')
            FROM [dbo].[LEAD_DETAILS_DISB] ldd
            INNER JOIN [dbo].[LEAD_DETAILS] ld ON ld.lead_no = ldd.lead_no
            INNER JOIN [dbo].[LEAD_DETAILS_FINANCE] ldf ON ldf.lead_no = ldd.lead_no
            INNER JOIN [dbo].[LEAD_DETAILS_Property] ldp ON ldp.lead_no = ldd.lead_no
            LEFT JOIN [dbo].[LEAD_DEVELOPER_MASTER] ldm ON ldm.DEVELOPERNAME = ldp.Property_DeveloperName
            LEFT JOIN [dbo].[lead_project] lproj ON lproj.PROJECTNAME = ldp.Property_ProjectName
            LEFT JOIN [dbo].[LEAD_Product_ISTINSNA] lpi ON lpi.lead_no = ldd.lead_no
            WHERE ldp.Property_ProjectID = @Property_ProjectID
              AND ldd.disb_status IN ('Not Disbursed','Hold')
              AND ld.lead_stage IN ('END_OF_PROCESS','OPS_PMU','OPS_LODGMENT','OPS_LODGEMENT')
        END
        ELSE -- Unhold: reverse from source Hold detail
        BEGIN
            INSERT INTO [dbo].[HF48_BulkPostpone_RequestDetail]
                (RequestID, APP_REF_NO, Lead_No, Customer_Name,
                 InceptionDisbDate, OldDisbDate, NewDisbDate,
                 OldDisbStatus, NewDisbStatus,
                 Disb_Amount, FinanceAmount, Applied, GroupIndex,
                 PropertyPaymentPct, FinancePaymentPct, MilestonePaymentPct,
                 LeadStage, DevTier, ValueTranche, ProductCode)
            SELECT
                @RequestID,
                d.APP_REF_NO, d.Lead_No, d.Customer_Name,
                d.InceptionDisbDate,
                d.NewDisbDate,      -- current (held) date is now Old
                d.OldDisbDate,      -- original date is restored as New
                d.NewDisbStatus,
                d.OldDisbStatus,
                d.Disb_Amount, d.FinanceAmount,
                0, d.GroupIndex,
                d.PropertyPaymentPct, d.FinancePaymentPct, d.MilestonePaymentPct,
                d.LeadStage, d.DevTier, d.ValueTranche, d.ProductCode
            FROM [dbo].[HF48_BulkPostpone_RequestDetail] d
            WHERE d.RequestID = @SourceRequestID
        END

        IF ISNULL(@DraftID,'') <> ''
            UPDATE [dbo].[HF48_BulkPostpone_Docs]
            SET RequestID = @RequestID
            WHERE DraftID = @DraftID AND RequestID IS NULL

    COMMIT TRANSACTION T_SUBMIT

    SET @Status  = 'SUCCESS'
    SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) +
                   ' submitted for approval. Type: ' + @RequestType + '.'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_SUBMIT
        SET @RequestID = 0; SET @Status = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- ============================================================
-- 6. Proc_HF48_BulkPostpone_GetRequestDetail  (full rebuild)
--    Returns all snapshot columns — checker grid = maker grid
-- ============================================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]
    @RequestID INT
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        APP_REF_NO,
        Lead_No,
        Customer_Name,
        LeadStage         AS lead_stage,
        ProductCode,
        InceptionDisbDate,
        OldDisbDate,
        NewDisbDate,
        Disb_Amount       AS Disb_amount,
        FinanceAmount     AS finance_amount,
        OldDisbStatus     AS disb_status,    -- status at submission time
        NewDisbStatus,
        PropertyPaymentPct,
        FinancePaymentPct,
        MilestonePaymentPct,
        DevTier           AS dev_tier,
        ValueTranche      AS value_tranche,
        Applied,
        GroupIndex
    FROM [dbo].[HF48_BulkPostpone_RequestDetail]
    WHERE RequestID = @RequestID
    ORDER BY APP_REF_NO, OldDisbDate
END
GO

PRINT '== Script 14: Migrations and rebuilt procedures completed. =='
GO
