USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Script 09: HF48 Bulk Postponement / Preponment
-- Supports:
--   - Bulk postponement WITHOUT hold
--   - Bulk postponement WITH hold (project level)
--   - Negative ShiftDays = preponment
-- =============================================

-- =============================================
-- 1. HF48_POSTPONEMENT_LOG (audit table)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HF48_POSTPONEMENT_LOG]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[HF48_POSTPONEMENT_LOG]
    (
        LogID             INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        APP_REF_NO        NVARCHAR(50)      NULL,
        Lead_No           NVARCHAR(50)      NULL,
        OriginalDisbDate  DATETIME          NULL,
        NewDisbDate       DATETIME          NULL,
        ShiftDays         INT               NULL,
        PostponementType  NVARCHAR(50)      NULL,  -- 'WithHold', 'WithoutHold'
        HoldApplied       BIT               NULL   DEFAULT 0,
        ProjectName       NVARCHAR(200)     NULL,
        CreatedBy         NVARCHAR(100)     NULL,
        CreatedOn         DATETIME          NULL   DEFAULT GETDATE(),
        Remarks           NVARCHAR(MAX)     NULL
    )
    PRINT 'Table HF48_POSTPONEMENT_LOG created.'
END
ELSE
    PRINT 'Table HF48_POSTPONEMENT_LOG already exists - skipped.'
GO

-- =============================================
-- 2. Proc_HF48_BulkPostponement
--    ShiftDays accepts negative (preponment)
--    SelectedKeys format: "APP_REF|LEAD_NO|YYYY-MM-DD,..."
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_BulkPostponement]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_BulkPostponement]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_BulkPostponement]
    @SelectedKeys    NVARCHAR(MAX),   -- comma-separated "APP_REF|LEAD_NO|YYYY-MM-DD"
    @ShiftDays       INT,             -- negative = preponment, positive = postponement
    @ApplyHold       BIT,             -- 1 = apply project hold, 0 = no hold
    @HoldTranche     NVARCHAR(100) = 'Hold',
    @UserID          NVARCHAR(100),
    @Remarks         NVARCHAR(MAX) = NULL,
    @Status          NVARCHAR(50)  OUTPUT,
    @Message         NVARCHAR(500) OUTPUT,
    @ProcessedCount  INT           OUTPUT
AS
BEGIN
    SET NOCOUNT ON
    SET @ProcessedCount = 0

    IF ISNULL(@SelectedKeys, '') = ''
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'No records selected for processing.'
        RETURN
    END

    -- Parse CSV into temp table
    CREATE TABLE #SelectedItems
    (
        APP_REF_NO NVARCHAR(50),
        Lead_No    NVARCHAR(50),
        Disb_Date  DATETIME
    )

    DECLARE @Keys     NVARCHAR(MAX) = LTRIM(RTRIM(@SelectedKeys)) + ','
    DECLARE @Pos      INT           = 1
    DECLARE @DelimPos INT
    DECLARE @Item     NVARCHAR(500)
    DECLARE @Bar1     INT
    DECLARE @Bar2     INT
    DECLARE @P1       NVARCHAR(50)
    DECLARE @P2       NVARCHAR(50)
    DECLARE @P3       NVARCHAR(30)

    WHILE @Pos <= LEN(@Keys)
    BEGIN
        SET @DelimPos = CHARINDEX(',', @Keys, @Pos)
        IF @DelimPos = 0 BREAK
        SET @Item = LTRIM(RTRIM(SUBSTRING(@Keys, @Pos, @DelimPos - @Pos)))
        SET @Pos  = @DelimPos + 1

        IF LEN(@Item) > 0
        BEGIN
            SET @Bar1 = CHARINDEX('|', @Item)
            SET @Bar2 = CHARINDEX('|', @Item, @Bar1 + 1)
            IF @Bar1 > 0 AND @Bar2 > 0
            BEGIN
                SET @P1 = LTRIM(RTRIM(SUBSTRING(@Item, 1, @Bar1 - 1)))
                SET @P2 = LTRIM(RTRIM(SUBSTRING(@Item, @Bar1 + 1, @Bar2 - @Bar1 - 1)))
                SET @P3 = LTRIM(RTRIM(SUBSTRING(@Item, @Bar2 + 1, LEN(@Item))))
                IF ISDATE(@P3) = 1
                    INSERT INTO #SelectedItems VALUES (@P1, @P2, CAST(@P3 AS DATETIME))
            END
        END
    END

    IF NOT EXISTS (SELECT TOP 1 1 FROM #SelectedItems)
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'No valid records could be parsed from the selection.'
        DROP TABLE #SelectedItems
        RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_POSTPONE

        DECLARE @APP_REF_NO  NVARCHAR(50)
        DECLARE @Lead_No     NVARCHAR(50)
        DECLARE @Disb_Date   DATETIME
        DECLARE @NewDate     DATETIME
        DECLARE @ProjectName NVARCHAR(200)

        DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
            SELECT APP_REF_NO, Lead_No, Disb_Date FROM #SelectedItems

        OPEN cur
        FETCH NEXT FROM cur INTO @APP_REF_NO, @Lead_No, @Disb_Date

        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @NewDate     = DATEADD(DAY, @ShiftDays, @Disb_Date)
            SET @ProjectName = NULL

            -- Get project name for hold
            SELECT @ProjectName = ldp.Property_ProjectName
            FROM LEAD_DETAILS_Property ldp
            WHERE ldp.lead_no = @Lead_No

            -- Shift the disbursement date
            UPDATE LEAD_DETAILS_DISB
            SET Disb_Date = @NewDate
            WHERE lead_no = @Lead_No
              AND CAST(Disb_Date AS DATE) = CAST(@Disb_Date AS DATE)

            -- Apply project-level hold if requested
            IF @ApplyHold = 1 AND ISNULL(@ProjectName, '') <> ''
            BEGIN
                UPDATE lead_project
                SET value_tranche = @HoldTranche
                WHERE PROJECTNAME = @ProjectName
            END

            -- Log to postponement log
            INSERT INTO [dbo].[HF48_POSTPONEMENT_LOG]
                (APP_REF_NO, Lead_No, OriginalDisbDate, NewDisbDate,
                 ShiftDays, PostponementType, HoldApplied, ProjectName,
                 CreatedBy, CreatedOn, Remarks)
            VALUES (
                @APP_REF_NO, @Lead_No, @Disb_Date, @NewDate,
                @ShiftDays,
                CASE WHEN @ApplyHold = 1 THEN 'WithHold' ELSE 'WithoutHold' END,
                @ApplyHold, @ProjectName,
                @UserID, GETDATE(), @Remarks
            )

            -- Also log to main HF48 audit log
            INSERT INTO [dbo].[HF48_DISB_AUDIT_LOG]
                (APP_REF_NO, Lead_No, Disb_Date, DaysBefore,
                 ActionType, ActionResult, NotificationSentTo,
                 CreatedBy, CreatedOn, Remarks)
            VALUES (
                @APP_REF_NO, @Lead_No, @Disb_Date, @ShiftDays,
                CASE WHEN @ShiftDays >= 0 THEN 'BulkPostponement' ELSE 'BulkPreponment' END,
                'Date shifted from ' + CONVERT(NVARCHAR(20),@Disb_Date,103) +
                    ' to ' + CONVERT(NVARCHAR(20),@NewDate,103),
                NULL,
                @UserID, GETDATE(),
                ISNULL(@Remarks,'') +
                    CASE WHEN @ApplyHold = 1
                         THEN ' | Hold applied on project: ' + ISNULL(@ProjectName,'N/A')
                         ELSE '' END
            )

            SET @ProcessedCount = @ProcessedCount + 1
            FETCH NEXT FROM cur INTO @APP_REF_NO, @Lead_No, @Disb_Date
        END

        CLOSE cur
        DEALLOCATE cur

    COMMIT TRANSACTION T_POSTPONE
    DROP TABLE #SelectedItems

    SET @Status  = 'SUCCESS'
    SET @Message = CAST(@ProcessedCount AS NVARCHAR(10)) + ' disbursement(s) ' +
                   CASE WHEN @ShiftDays >= 0 THEN 'postponed' ELSE 'preponed' END +
                   ' by ' + CAST(ABS(@ShiftDays) AS NVARCHAR(10)) + ' day(s).' +
                   CASE WHEN @ApplyHold = 1 THEN ' Project hold applied.' ELSE '' END

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_POSTPONE
        IF OBJECT_ID('tempdb..#SelectedItems') IS NOT NULL DROP TABLE #SelectedItems
        IF CURSOR_STATUS('local','cur') >= 0 BEGIN CLOSE cur; DEALLOCATE cur; END
        SET @Status         = 'FAILURE'
        SET @Message        = 'Error: ' + ERROR_MESSAGE()
        SET @ProcessedCount = 0
    END CATCH
END
GO

-- =============================================
-- 3. Proc_HF48_GetPostponementLog
--    Retrieve postponement history with filters
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_GetPostponementLog]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_GetPostponementLog]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_GetPostponementLog]
    @AppRefNo NVARCHAR(50) = NULL,
    @DateFrom DATETIME     = NULL,
    @DateTo   DATETIME     = NULL
AS
BEGIN
    SET NOCOUNT ON

    SELECT TOP 500
        LogID, APP_REF_NO, Lead_No,
        OriginalDisbDate, NewDisbDate, ShiftDays,
        PostponementType, HoldApplied,
        ProjectName, CreatedBy, CreatedOn, Remarks
    FROM [dbo].[HF48_POSTPONEMENT_LOG]
    WHERE (ISNULL(@AppRefNo,'') = '' OR APP_REF_NO LIKE '%' + @AppRefNo + '%')
      AND (@DateFrom IS NULL OR CreatedOn >= @DateFrom)
      AND (@DateTo   IS NULL OR CreatedOn <  DATEADD(DAY, 1, @DateTo))
    ORDER BY CreatedOn DESC
END
GO

-- =============================================
-- 4. Update Proc_HF48_Get_Disbursements
--    Add Disb Date filter support (already exists)
--    and ensure PropertyPaymentPct, FinancePaymentPct
--    are returned (already in existing proc - no change)
-- =============================================
-- NOTE: Proc_HF48_Get_Disbursements already returns
-- PropertyPaymentPct and FinancePaymentPct per the
-- existing Script 06. No update required.

PRINT '== Script 09: HF48 Bulk Postponement procedures created successfully. =='
GO
