USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_BulkPostpone_Submit
-- Maker action: snapshot all affected pending schedules
-- into HF48_BULK_POSTPONE_DETAIL and create the request
-- header in 'Pending Approval' state. Schedules are NOT
-- moved yet -- that happens at approval time.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_Submit]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_Submit]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_Submit]
    @Property_ProjectID NVARCHAR(50),
    @ShiftDays          INT,
    @Reason             NVARCHAR(1000),
    @MakerUser          NVARCHAR(100),
    @RequestID          INT OUTPUT,
    @Status             NVARCHAR(50)  OUTPUT,
    @Message            NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    SET @RequestID = 0

    IF @ShiftDays IS NULL OR @ShiftDays <= 0
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Shift days must be a positive integer.'
        RETURN
    END

    IF ISNULL(@Reason,'') = ''
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Postponement reason is required.'
        RETURN
    END

    -- Resolve project meta + count of impacted rows
    DECLARE @ProjectName NVARCHAR(200), @DeveloperName NVARCHAR(200)
    DECLARE @Affected INT, @Apps INT

    SELECT TOP 1
        @ProjectName   = ldp.Property_ProjectName,
        @DeveloperName = ldp.Property_DeveloperName
    FROM LEAD_DETAILS_Property ldp
    WHERE ldp.Property_ProjectID = @Property_ProjectID

    IF @ProjectName IS NULL
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Project not found: ' + @Property_ProjectID
        RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_BPSUB

        INSERT INTO HF48_BULK_POSTPONE_REQUEST
            (Property_ProjectID, Property_ProjectName, Property_DeveloperName,
             ShiftDays, Reason, Status, MakerUser)
        VALUES
            (@Property_ProjectID, @ProjectName, @DeveloperName,
             @ShiftDays, @Reason, 'Pending Approval', @MakerUser)

        SET @RequestID = SCOPE_IDENTITY()

        ;WITH Pending AS (
            SELECT
                ld.APP_REF_NO,
                ldd.Lead_No,
                ld.Customer_name,
                ldd.Disb_Date,
                ldd.Disb_amount,
                ldd.disb_status
            FROM LEAD_DETAILS_DISB ldd
            INNER JOIN LEAD_DETAILS_FINANCE ldf  ON ldd.lead_no = ldf.lead_no
            INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldf.lead_no
            INNER JOIN LEAD_DETAILS ld           ON ld.lead_no  = ldf.lead_no
            WHERE ldf.LEAD_Product_ISTINSNA = 'HF48'
              AND ISNULL(ldd.Status,'') = 'A'
              AND ISNULL(ldd.disb_status,'') IN ('Hold','Not Disbursed')
              AND ldp.Property_ProjectID = @Property_ProjectID
        )
        INSERT INTO HF48_BULK_POSTPONE_DETAIL
            (RequestID, APP_REF_NO, Lead_No, Customer_Name,
             OldDisbDate, NewDisbDate, Disb_Amount, Disb_Status)
        SELECT
            @RequestID, APP_REF_NO, Lead_No, Customer_name,
            Disb_Date, DATEADD(DAY, @ShiftDays, Disb_Date), Disb_amount, disb_status
        FROM Pending

        SELECT @Affected = COUNT(*),
               @Apps     = COUNT(DISTINCT APP_REF_NO)
        FROM HF48_BULK_POSTPONE_DETAIL WHERE RequestID = @RequestID

        IF @Affected = 0
        BEGIN
            ROLLBACK TRANSACTION T_BPSUB
            SET @RequestID = 0
            SET @Status  = 'FAILURE'
            SET @Message = 'No pending (Hold / Not Disbursed) schedules found for this project.'
            RETURN
        END

        UPDATE HF48_BULK_POSTPONE_REQUEST
           SET AffectedRowCount = @Affected,
               AffectedAppCount = @Apps
         WHERE RequestID = @RequestID

        INSERT INTO HF48_DISB_AUDIT_LOG
            (APP_REF_NO, Lead_No, Disb_Date, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES
            ('BULK#' + CONVERT(VARCHAR(10), @RequestID), @ProjectName, GETDATE(),
             'BulkPostpone-Submitted',
             'Request #' + CONVERT(VARCHAR(10), @RequestID) +
                ' submitted: ' + CONVERT(VARCHAR(10), @Apps) + ' app(s), ' +
                CONVERT(VARCHAR(10), @Affected) + ' schedule(s), shift +' +
                CONVERT(VARCHAR(10), @ShiftDays) + 'd',
             @MakerUser,
             @Reason)

    COMMIT TRANSACTION T_BPSUB

    SET @Status  = 'SUCCESS'
    SET @Message = 'Request #' + CONVERT(VARCHAR(10), @RequestID) +
                   ' submitted for Checker approval (' +
                   CONVERT(VARCHAR(10), @Apps) + ' application(s), ' +
                   CONVERT(VARCHAR(10), @Affected) + ' schedule row(s)).'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_BPSUB
        SET @RequestID = 0
        SET @Status  = 'FAILURE'
        SET @Message = 'Submit failed: ' + ERROR_MESSAGE()
    END CATCH
END
GO

PRINT 'Proc_HF48_BulkPostpone_Submit created.'
GO
