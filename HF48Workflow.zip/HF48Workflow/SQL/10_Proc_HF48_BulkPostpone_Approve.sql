USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_BulkPostpone_Approve
-- Checker action: applies the snapshotted shift to
-- LEAD_DETAILS_DISB for every detail line, marks the
-- request 'Approved', logs to audit. Maker != Checker.
--
-- A uniform forward shift preserves the schedule order
-- so the existing MilestonePaymentPct cumulative ranking
-- (see usp_Calc_Disbursements_Grid) stays valid; the
-- per-row Property/Finance % depend on amount only and
-- are also unaffected.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_Approve]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_Approve]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_Approve]
    @RequestID      INT,
    @CheckerUser    NVARCHAR(100),
    @CheckerRemarks NVARCHAR(1000) = NULL,
    @Status         NVARCHAR(50)  OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @MakerUser NVARCHAR(100), @ReqStatus NVARCHAR(30)
    DECLARE @ShiftDays INT, @ProjectID NVARCHAR(50), @ProjectName NVARCHAR(200)
    DECLARE @AppliedRows INT

    SELECT @MakerUser = MakerUser,
           @ReqStatus = Status,
           @ShiftDays = ShiftDays,
           @ProjectID = Property_ProjectID,
           @ProjectName = Property_ProjectName
    FROM HF48_BULK_POSTPONE_REQUEST
    WHERE RequestID = @RequestID

    IF @MakerUser IS NULL
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request not found: ' + CONVERT(VARCHAR(10), @RequestID)
        RETURN
    END

    IF @ReqStatus <> 'Pending Approval'
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request is in status "' + @ReqStatus + '" and cannot be approved.'
        RETURN
    END

    IF UPPER(LTRIM(RTRIM(@MakerUser))) = UPPER(LTRIM(RTRIM(ISNULL(@CheckerUser,''))))
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Maker-Checker violation: the Maker (' + @MakerUser + ') cannot approve their own request.'
        RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_BPAPP

        -- Apply the date shift on the live schedule rows.
        -- Match on (Lead_No, OldDisbDate) which uniquely identifies
        -- a schedule line in LEAD_DETAILS_DISB for an active record.
        UPDATE ldd
           SET ldd.Disb_Date = d.NewDisbDate
        FROM LEAD_DETAILS_DISB ldd
        INNER JOIN HF48_BULK_POSTPONE_DETAIL d
                ON d.Lead_No     = ldd.Lead_No
               AND d.OldDisbDate = ldd.Disb_Date
        WHERE d.RequestID = @RequestID
          AND ISNULL(ldd.Status,'') = 'A'
          AND ISNULL(ldd.disb_status,'') IN ('Hold','Not Disbursed')

        SET @AppliedRows = @@ROWCOUNT

        UPDATE HF48_BULK_POSTPONE_DETAIL
           SET Applied = 1, AppliedOn = GETDATE()
         WHERE RequestID = @RequestID

        UPDATE HF48_BULK_POSTPONE_REQUEST
           SET Status = 'Approved',
               CheckerUser = @CheckerUser,
               CheckerOn = GETDATE(),
               CheckerRemarks = @CheckerRemarks
         WHERE RequestID = @RequestID

        -- Per-application audit lines so the existing audit screen
        -- shows the move on each affected app.
        INSERT INTO HF48_DISB_AUDIT_LOG
            (APP_REF_NO, Lead_No, Disb_Date, DaysBefore,
             ActionType, ActionResult, CreatedBy, Remarks)
        SELECT
            d.APP_REF_NO, d.Lead_No, d.NewDisbDate, @ShiftDays,
            'BulkPostpone-Approved',
            'Disb_Date moved from ' + CONVERT(VARCHAR(10), d.OldDisbDate, 103) +
                ' to ' + CONVERT(VARCHAR(10), d.NewDisbDate, 103) +
                ' (Request #' + CONVERT(VARCHAR(10), @RequestID) + ')',
            @CheckerUser,
            'Project: ' + @ProjectName +
                ' / Maker: ' + @MakerUser +
                ISNULL(' / Checker remarks: ' + @CheckerRemarks, '')
        FROM HF48_BULK_POSTPONE_DETAIL d
        WHERE d.RequestID = @RequestID

    COMMIT TRANSACTION T_BPAPP

    SET @Status  = 'SUCCESS'
    SET @Message = 'Request #' + CONVERT(VARCHAR(10), @RequestID) +
                   ' approved. ' + CONVERT(VARCHAR(10), @AppliedRows) +
                   ' schedule row(s) postponed.'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_BPAPP
        SET @Status  = 'FAILURE'
        SET @Message = 'Approve failed: ' + ERROR_MESSAGE()
    END CATCH
END
GO

PRINT 'Proc_HF48_BulkPostpone_Approve created.'
GO
