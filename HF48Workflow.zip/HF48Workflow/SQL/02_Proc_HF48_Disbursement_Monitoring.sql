USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_Disbursement_Monitoring
-- Main stored procedure for 60/30/10 day checks
-- Schedule via SQL Agent Job to run daily
-- =============================================
CREATE PROC [dbo].[Proc_HF48_Disbursement_Monitoring]
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @MAIL_TO NVARCHAR(1000)
    DECLARE @MAIL_CC NVARCHAR(1000)
    DECLARE @MAIL_SUBJECT NVARCHAR(500)
    DECLARE @MAIL_BODY NVARCHAR(MAX)
    DECLARE @EvalTeamEmail NVARCHAR(500)
    DECLARE @EnggTeamEmail NVARCHAR(500)
    DECLARE @OpsTeamEmail NVARCHAR(500)
    DECLARE @CLMTeamEmail NVARCHAR(500)

    -- Fetch distribution list emails from config
    SELECT @EvalTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam'
    SELECT @EnggTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EngineeringTeam'
    SELECT @OpsTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam'
    SELECT @CLMTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam'

    -- =============================================
    -- Cursor variables
    -- =============================================
    DECLARE @APP_REF_NO NVARCHAR(50)
    DECLARE @Lead_No NVARCHAR(50)
    DECLARE @Customer_Name NVARCHAR(200)
    DECLARE @Disb_Date DATETIME
    DECLARE @Disb_Amount DECIMAL(18,2)
    DECLARE @Status NVARCHAR(10)
    DECLARE @DeveloperName NVARCHAR(200)
    DECLARE @DeveloperID NVARCHAR(50)
    DECLARE @ProjectName NVARCHAR(200)
    DECLARE @ProjectID NVARCHAR(50)
    DECLARE @DevTier NVARCHAR(50)
    DECLARE @ValueTranche NVARCHAR(50)
    DECLARE @ProductCode NVARCHAR(50)
    DECLARE @MilestonePaymentPct DECIMAL(18,2)
    DECLARE @PropertyPaymentPct DECIMAL(18,2)
    DECLARE @FinancePaymentPct DECIMAL(18,2)
    DECLARE @DISB_PAYMENT_FROM NVARCHAR(100)
    DECLARE @Payment_To NVARCHAR(100)
    DECLARE @DaysBefore INT
    DECLARE @TaskID INT

    -- =============================================
    -- Process 60-day, 30-day, and 10-day intervals
    -- =============================================
    DECLARE @DayIntervals TABLE (DayInterval INT)
    INSERT INTO @DayIntervals VALUES (60), (30), (10)

    DECLARE @CurrentInterval INT

    DECLARE interval_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT DayInterval FROM @DayIntervals

    OPEN interval_cursor
    FETCH NEXT FROM interval_cursor INTO @CurrentInterval

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- =============================================
        -- Cursor: fetch all pending disbursements 
        -- where Disb_Date is exactly @CurrentInterval days from today
        -- =============================================
        DECLARE disb_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT 
                ld.APP_REF_NO,
                ldd.Lead_No,
                ld.Customer_name,
                ldd.Disb_Date,
                ldd.Disb_amount,
                ldd.Status,
                ldd.DISB_PAYMENT_FROM,
                ldd.Payment_To,
                ldd.MilestonePaymentPct,
                ldd.PropertyPaymentPct,
                ldd.FinancePaymentPct,
                ldf.LEAD_Product_ISTINSNA,
                ldp.Property_DeveloperName,
                ldp.Property_DeveloperID,
                ldp.Property_ProjectName,
                ldp.Property_ProjectID,
                ISNULL(ldm.dev_tier, 'Tier 2') AS dev_tier,
                ISNULL(lpm.value_tranche, 'No-Hold') AS value_tranche
            FROM LEAD_DETAILS_DISB ldd
            INNER JOIN LEAD_DETAILS_FINANCE ldf ON ldd.lead_no = ldf.lead_no
            INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldf.lead_no
            INNER JOIN LEAD_DETAILS ld ON ld.lead_no = ldf.lead_no
            LEFT JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName
            LEFT JOIN lead_project lpm ON lpm.PROJECTNAME = ldp.Property_ProjectName
            WHERE ldf.LEAD_Product_ISTINSNA = 'HF48'
              AND ISNULL(ldd.Status, '') = 'A'
              AND CAST(ldd.Disb_Date AS DATE) = CAST(DATEADD(DAY, @CurrentInterval, GETDATE()) AS DATE)

        OPEN disb_cursor
        FETCH NEXT FROM disb_cursor INTO 
            @APP_REF_NO, @Lead_No, @Customer_Name, @Disb_Date, @Disb_Amount,
            @Status, @DISB_PAYMENT_FROM, @Payment_To, @MilestonePaymentPct,
            @PropertyPaymentPct, @FinancePaymentPct, @ProductCode,
            @DeveloperName, @DeveloperID, @ProjectName, @ProjectID,
            @DevTier, @ValueTranche

        WHILE @@FETCH_STATUS = 0
        BEGIN
            BEGIN TRY
                -- =============================================
                -- Exception Check 1: Already Disbursed
                -- If Disb_Amount > 0 and status indicates disbursed
                -- =============================================
                IF @Status <> 'A'
                BEGIN
                    INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
                    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @CurrentInterval, 
                            CONVERT(VARCHAR(10), @CurrentInterval) + '-Day Check',
                            'Skipped - Amount already disbursed', 'SYSTEM',
                            'Disbursement status: ' + ISNULL(@Status,''))
                    
                    GOTO NextRecord
                END

                -- =============================================
                -- Exception Check 2: Tier 1 Developer
                -- =============================================
                IF @DevTier = 'Tier 1' AND @CurrentInterval IN (60, 30)
                BEGIN
                    INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
                    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @CurrentInterval, 
                            CONVERT(VARCHAR(10), @CurrentInterval) + '-Day Check',
                            'Skipped - Tier 1 developer', 'SYSTEM',
                            'Developer: ' + ISNULL(@DeveloperName,'') + ' | Tier: ' + ISNULL(@DevTier,''))
                    
                    GOTO NextRecord
                END

                -- =============================================
                -- Exception Check 3: Project on Hold
                -- =============================================
                IF @ValueTranche = 'Hold' OR @ValueTranche LIKE '%Hold%'
                BEGIN
                    INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
                    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @CurrentInterval, 
                            CONVERT(VARCHAR(10), @CurrentInterval) + '-Day Check',
                            'Skipped - Project on hold', 'SYSTEM',
                            'Project: ' + ISNULL(@ProjectName,'') + ' | Status: ' + ISNULL(@ValueTranche,''))
                    
                    GOTO NextRecord
                END

                -- =============================================
                -- 60-Day and 30-Day: Notify Evaluation Team
                -- =============================================
                IF @CurrentInterval IN (60, 30)
                BEGIN
                    SET @MAIL_TO = @EvalTeamEmail
                    SET @MAIL_CC = ''
                    SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Disbursement ' + CONVERT(VARCHAR(10), @CurrentInterval) + '-Day Pre-Check Notification'

                    SET @MAIL_BODY = 'Dear Evaluation Team,<br><br>'
                    SET @MAIL_BODY = @MAIL_BODY + 'This is a ' + CONVERT(VARCHAR(10), @CurrentInterval) + '-day pre-disbursement notification. Please review the following application:<br><br>'
                    SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#000066><td colspan=2><font color=white><b>Disbursement Details</b></font></td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + ' (' + ISNULL(@DevTier,'') + ')</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Milestone Payment %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@MilestonePaymentPct,0)) + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Property Payment %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@PropertyPaymentPct,0)) + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Finance Payment %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@FinancePaymentPct,0)) + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Days Before Due</font></td><td>' + CONVERT(VARCHAR(10), @CurrentInterval) + '</td></tr>'
                    SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
                    SET @MAIL_BODY = @MAIL_BODY + 'Please take necessary action.<br><br>Regards,<br>HF48 Automated Monitoring System'

                    -- Insert into FRM_MESSAGES for email dispatch
                    INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
                    VALUES (@APP_REF_NO, 'N', 'HF48 Disbursement Monitoring', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

                    -- Audit Log
                    INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
                    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @CurrentInterval,
                            CONVERT(VARCHAR(10), @CurrentInterval) + '-Day Notification',
                            'Notification sent to Evaluation Team', @EvalTeamEmail, 'SYSTEM',
                            'Pre-disbursement check completed. Email queued.')
                END

                -- =============================================
                -- 10-Day: Create Task + Notify Engineering (CC Operations)
                -- =============================================
                IF @CurrentInterval = 10
                BEGIN
                    -- Handle Tier 1 Developer special case at 10 days
                    IF @DevTier = 'Tier 1'
                    BEGIN
                        -- Create CLM Service Ticket for Tier 1
                        INSERT INTO HF48_DISB_TASKS (APP_REF_NO, Lead_No, Disb_Date, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks)
                        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, 'CLM Service Ticket', 'CLM Team', 'Operations Team', 'Open', 'SYSTEM',
                                'Tier 1 developer - 10 day special case. Service ticket created under CLM Team, assigned to Operations.')

                        SET @TaskID = SCOPE_IDENTITY()

                        -- Notify Evaluation, Operations, and CLM Teams
                        SET @MAIL_TO = @EvalTeamEmail
                        SET @MAIL_CC = @OpsTeamEmail + ';' + @CLMTeamEmail
                        SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Tier 1 Developer - CLM Service Ticket Created (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

                        SET @MAIL_BODY = 'Dear Team,<br><br>'
                        SET @MAIL_BODY = @MAIL_BODY + 'A CLM Service Ticket has been created for a Tier 1 developer application at 10-day pre-disbursement.<br><br>'
                        SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#000066><td colspan=2><font color=white><b>Task Details</b></font></td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + ' (Tier 1)</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Assigned To</font></td><td>Operations Team (CLM)</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
                        SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

                        INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
                        VALUES (@APP_REF_NO, 'N', 'HF48 Disbursement Monitoring', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

                        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
                        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, 10,
                                '10-Day Tier1 CLM Ticket',
                                'CLM Service Ticket created (Task #' + CONVERT(VARCHAR(10), @TaskID) + '). Notified Evaluation, Operations, CLM Teams.',
                                @MAIL_TO + ';' + @MAIL_CC, 'SYSTEM',
                                'Tier 1 developer special case at 10 days.')
                    END
                    ELSE
                    BEGIN
                        -- Standard 10-day: Create Engineering Task
                        INSERT INTO HF48_DISB_TASKS (APP_REF_NO, Lead_No, Disb_Date, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks)
                        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, 'Engineering Task', 'Engineering Team', 'Engineering Team', 'Open', 'SYSTEM',
                                '10-day pre-disbursement task for engineering review.')

                        SET @TaskID = SCOPE_IDENTITY()

                        -- Notify Engineering Team, CC Operations
                        SET @MAIL_TO = @EnggTeamEmail
                        SET @MAIL_CC = @OpsTeamEmail
                        SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 10-Day Pre-Disbursement Task (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

                        SET @MAIL_BODY = 'Dear Engineering Team,<br><br>'
                        SET @MAIL_BODY = @MAIL_BODY + 'A task has been created for 10-day pre-disbursement review. Please find the details below:<br><br>'
                        SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#000066><td colspan=2><font color=white><b>Task Details</b></font></td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + ' (' + ISNULL(@DevTier,'') + ')</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Milestone %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@MilestonePaymentPct,0)) + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Property Payment %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@PropertyPaymentPct,0)) + '</td></tr>'
                        SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
                        SET @MAIL_BODY = @MAIL_BODY + 'Please take necessary action.<br><br>Regards,<br>HF48 Automated Monitoring System'

                        INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
                        VALUES (@APP_REF_NO, 'N', 'HF48 Disbursement Monitoring', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

                        -- Audit Log
                        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
                        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, 10,
                                '10-Day Task Created',
                                'Engineering task created (Task #' + CONVERT(VARCHAR(10), @TaskID) + '). Notification sent to Engineering Team.',
                                @MAIL_TO + ';CC:' + @MAIL_CC, 'SYSTEM',
                                '10-day pre-disbursement engineering task.')
                    END
                END

            END TRY
            BEGIN CATCH
                INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
                VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @CurrentInterval,
                        CONVERT(VARCHAR(10), @CurrentInterval) + '-Day Check ERROR',
                        'Error occurred during processing',
                        'SYSTEM',
                        'Error: ' + ERROR_MESSAGE())
            END CATCH

            NextRecord:
            FETCH NEXT FROM disb_cursor INTO 
                @APP_REF_NO, @Lead_No, @Customer_Name, @Disb_Date, @Disb_Amount,
                @Status, @DISB_PAYMENT_FROM, @Payment_To, @MilestonePaymentPct,
                @PropertyPaymentPct, @FinancePaymentPct, @ProductCode,
                @DeveloperName, @DeveloperID, @ProjectName, @ProjectID,
                @DevTier, @ValueTranche
        END

        CLOSE disb_cursor
        DEALLOCATE disb_cursor

        FETCH NEXT FROM interval_cursor INTO @CurrentInterval
    END

    CLOSE interval_cursor
    DEALLOCATE interval_cursor
END
GO

PRINT 'Proc_HF48_Disbursement_Monitoring created successfully.'
GO
