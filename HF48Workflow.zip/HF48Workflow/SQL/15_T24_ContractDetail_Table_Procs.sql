USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Script 15: T24_Contract_Detail
--   Stores the finance/contract data returned by
--   the T24 core-banking contract enquiry service.
--
-- Sample request context:
--   ContractID = 997HF52220260201?cif=2598452_branch=997
--   ApplicationRefNo = MF123
--
-- Sample response shape (Data.financeInformation is
-- an array — one row is stored per array element):
--   Data.customerInformation.cif
--   Data.financeInformation[].contractReferenceNumber
--   Data.financeInformation[].userReferenceNumber
--   Data.financeInformation[].financeCurrency
--   Data.financeInformation[].financeAmount
--   Data.financeInformation[].accountNumber
--   Data.financeInformation[].currentBalance
--   Data.financeInformation[].outstandingBalanceAmount
--   Data.financeInformation[].contractAmountPaid
--   Data.financeInformation[].balloonAmount
--   Data.financeInformation[].bookingDate       (yyyyMMdd)
--   Data.financeInformation[].valueDate         (yyyyMMdd)
--   Data.financeInformation[].latestActionDate  (yyyyMMdd)
--   Data.financeInformation[].maturityDate      (yyyyMMdd)
--   Data.financeInformation[].product.moduleCode
--   Data.financeInformation[].product.productCode
--   Data.financeInformation[].statuses.contractStatus
--   Data.financeInformation[].statuses.initiationStatus
--   Data.financeInformation[].profit.profitRate
--   Data.financeInformation[].profit.internalRateOfReturn
--   APIStatus.statusType / identifier / statusCode /
--             statusMessage / statusDescription
--   APIStatus.appStatusDetails[0].appStatusCode / Message / Description
--
-- Objects:
--   1. TABLE  dbo.T24_Contract_Detail
--   2. PROC   Proc_T24_ContractDetail_Insert
--   3. PROC   Proc_T24_ContractDetail_Select
-- =============================================

-- =============================================
-- 1. CREATE TABLE
-- =============================================
IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[T24_Contract_Detail]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[T24_Contract_Detail]
    (
        SRNo                     INT IDENTITY(1,1)  NOT NULL,

        -- Request context (as supplied by the caller / screen)
        ContractID               NVARCHAR(300)      NULL,   -- e.g. 997HF52220260201?cif=2598452_branch=997
        ApplicationRefNo         NVARCHAR(50)       NULL,   -- e.g. MF123
        BranchCode               NVARCHAR(20)       NULL,

        -- Data.customerInformation
        CIF                      NVARCHAR(50)       NULL,

        -- Data.financeInformation[]  (one row per finance information entry)
        ContractReferenceNumber  NVARCHAR(100)      NULL,
        UserReferenceNumber      NVARCHAR(100)      NULL,
        FinanceCurrency          NVARCHAR(10)       NULL,
        FinanceAmount            NUMERIC(18, 4)     NULL,
        AccountNumber            NVARCHAR(50)       NULL,
        CurrentBalance           NUMERIC(18, 4)     NULL,
        OutstandingBalanceAmount NUMERIC(18, 4)     NULL,
        ContractAmountPaid       NUMERIC(18, 4)     NULL,
        BalloonAmount            NUMERIC(18, 4)     NULL,
        BookingDate              DATETIME           NULL,
        ValueDate                DATETIME           NULL,
        LatestActionDate         DATETIME           NULL,
        MaturityDate             DATETIME           NULL,

        -- Data.financeInformation[].product
        ModuleCode               NVARCHAR(20)       NULL,
        ProductCode              NVARCHAR(20)       NULL,

        -- Data.financeInformation[].statuses
        ContractStatus           NVARCHAR(20)       NULL,
        InitiationStatus         NVARCHAR(20)       NULL,

        -- Data.financeInformation[].profit
        ProfitRate               NUMERIC(18, 6)     NULL,
        InternalRateOfReturn     NUMERIC(18, 6)     NULL,

        -- APIStatus
        APIStatusType            NVARCHAR(50)       NULL,
        APIStatusIdentifier      NVARCHAR(100)      NULL,
        APIStatusCode            NVARCHAR(50)       NULL,
        APIStatusMessage         NVARCHAR(500)      NULL,
        APIStatusDescription     NVARCHAR(500)      NULL,

        -- APIStatus.appStatusDetails[0] (first element)
        AppStatusCode            NVARCHAR(50)       NULL,
        AppStatusMessage         NVARCHAR(500)      NULL,
        AppStatusDescription     NVARCHAR(500)      NULL,

        -- Raw payload retained for audit / troubleshooting
        RawResponseJSON          NVARCHAR(MAX)      NULL,

        -- Standard audit
        CreatedBy                NVARCHAR(100)      NULL DEFAULT 'SYSTEM',
        CreatedOn                DATETIME           NULL DEFAULT GETDATE(),

        CONSTRAINT PK_T24_Contract_Detail PRIMARY KEY CLUSTERED (SRNo ASC)
    )
    PRINT 'Table T24_Contract_Detail created.'
END
ELSE
    PRINT 'Table T24_Contract_Detail already exists - skipped.'
GO

-- =============================================
-- 2. Proc_T24_ContractDetail_Insert
--    One call = one financeInformation[] row.
--    The calling page loops over the parsed array
--    and calls this once per element.
-- =============================================
IF OBJECT_ID('[dbo].[Proc_T24_ContractDetail_Insert]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_T24_ContractDetail_Insert]
GO

CREATE PROCEDURE [dbo].[Proc_T24_ContractDetail_Insert]
    @ContractID               NVARCHAR(300)  = NULL,
    @ApplicationRefNo         NVARCHAR(50)   = NULL,
    @BranchCode               NVARCHAR(20)   = NULL,
    @CIF                      NVARCHAR(50)   = NULL,
    @ContractReferenceNumber  NVARCHAR(100)  = NULL,
    @UserReferenceNumber      NVARCHAR(100)  = NULL,
    @FinanceCurrency          NVARCHAR(10)   = NULL,
    @FinanceAmount            NUMERIC(18,4)  = NULL,
    @AccountNumber            NVARCHAR(50)   = NULL,
    @CurrentBalance           NUMERIC(18,4)  = NULL,
    @OutstandingBalanceAmount NUMERIC(18,4)  = NULL,
    @ContractAmountPaid       NUMERIC(18,4)  = NULL,
    @BalloonAmount            NUMERIC(18,4)  = NULL,
    @BookingDate              DATETIME       = NULL,
    @ValueDate                DATETIME       = NULL,
    @LatestActionDate         DATETIME       = NULL,
    @MaturityDate             DATETIME       = NULL,
    @ModuleCode               NVARCHAR(20)   = NULL,
    @ProductCode              NVARCHAR(20)   = NULL,
    @ContractStatus           NVARCHAR(20)   = NULL,
    @InitiationStatus         NVARCHAR(20)   = NULL,
    @ProfitRate               NUMERIC(18,6)  = NULL,
    @InternalRateOfReturn     NUMERIC(18,6)  = NULL,
    @APIStatusType            NVARCHAR(50)   = NULL,
    @APIStatusIdentifier      NVARCHAR(100)  = NULL,
    @APIStatusCode            NVARCHAR(50)   = NULL,
    @APIStatusMessage         NVARCHAR(500)  = NULL,
    @APIStatusDescription     NVARCHAR(500)  = NULL,
    @AppStatusCode            NVARCHAR(50)   = NULL,
    @AppStatusMessage         NVARCHAR(500)  = NULL,
    @AppStatusDescription     NVARCHAR(500)  = NULL,
    @RawResponseJSON          NVARCHAR(MAX)  = NULL,
    @CreatedBy                NVARCHAR(100)  = 'SYSTEM',
    @NewSRNo                  INT            OUTPUT,
    @Status                   NVARCHAR(50)   OUTPUT,
    @Message                  NVARCHAR(500)  OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    BEGIN TRY
        INSERT INTO [dbo].[T24_Contract_Detail]
            (ContractID, ApplicationRefNo, BranchCode, CIF,
             ContractReferenceNumber, UserReferenceNumber, FinanceCurrency, FinanceAmount,
             AccountNumber, CurrentBalance, OutstandingBalanceAmount, ContractAmountPaid, BalloonAmount,
             BookingDate, ValueDate, LatestActionDate, MaturityDate,
             ModuleCode, ProductCode, ContractStatus, InitiationStatus,
             ProfitRate, InternalRateOfReturn,
             APIStatusType, APIStatusIdentifier, APIStatusCode, APIStatusMessage, APIStatusDescription,
             AppStatusCode, AppStatusMessage, AppStatusDescription,
             RawResponseJSON, CreatedBy, CreatedOn)
        VALUES
            (@ContractID, @ApplicationRefNo, @BranchCode, @CIF,
             @ContractReferenceNumber, @UserReferenceNumber, @FinanceCurrency, @FinanceAmount,
             @AccountNumber, @CurrentBalance, @OutstandingBalanceAmount, @ContractAmountPaid, @BalloonAmount,
             @BookingDate, @ValueDate, @LatestActionDate, @MaturityDate,
             @ModuleCode, @ProductCode, @ContractStatus, @InitiationStatus,
             @ProfitRate, @InternalRateOfReturn,
             @APIStatusType, @APIStatusIdentifier, @APIStatusCode, @APIStatusMessage, @APIStatusDescription,
             @AppStatusCode, @AppStatusMessage, @AppStatusDescription,
             @RawResponseJSON, ISNULL(@CreatedBy, 'SYSTEM'), GETDATE())

        SET @NewSRNo = SCOPE_IDENTITY()
        SET @Status  = 'SUCCESS'
        SET @Message = 'Contract detail saved. SRNo=' + CAST(@NewSRNo AS NVARCHAR(10)) +
                       ISNULL(' (Contract Ref: ' + @ContractReferenceNumber + ')', '')
    END TRY
    BEGIN CATCH
        SET @NewSRNo = 0
        SET @Status  = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- =============================================
-- 3. Proc_T24_ContractDetail_Select
--    Flexible query with common filters.
-- =============================================
IF OBJECT_ID('[dbo].[Proc_T24_ContractDetail_Select]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_T24_ContractDetail_Select]
GO

CREATE PROCEDURE [dbo].[Proc_T24_ContractDetail_Select]
    @SRNo                    INT           = NULL,
    @CIF                     NVARCHAR(50)  = NULL,
    @ApplicationRefNo        NVARCHAR(50)  = NULL,
    @ContractReferenceNumber NVARCHAR(100) = NULL,
    @ContractStatus          NVARCHAR(20)  = NULL,
    @ProductCode             NVARCHAR(20)  = NULL,
    @TopN                    INT           = 500
AS
BEGIN
    SET NOCOUNT ON

    SELECT TOP (@TopN)
        SRNo, ContractID, ApplicationRefNo, BranchCode, CIF,
        ContractReferenceNumber, UserReferenceNumber, FinanceCurrency, FinanceAmount,
        AccountNumber, CurrentBalance, OutstandingBalanceAmount, ContractAmountPaid, BalloonAmount,
        BookingDate, ValueDate, LatestActionDate, MaturityDate,
        ModuleCode, ProductCode, ContractStatus, InitiationStatus,
        ProfitRate, InternalRateOfReturn,
        APIStatusCode, APIStatusMessage,
        AppStatusCode, AppStatusMessage,
        CreatedBy, CreatedOn
    FROM [dbo].[T24_Contract_Detail]
    WHERE (@SRNo IS NULL OR SRNo = @SRNo)
      AND (ISNULL(@CIF,'')                     = '' OR CIF                     = @CIF)
      AND (ISNULL(@ApplicationRefNo,'')        = '' OR ApplicationRefNo        LIKE '%' + @ApplicationRefNo + '%')
      AND (ISNULL(@ContractReferenceNumber,'') = '' OR ContractReferenceNumber LIKE '%' + @ContractReferenceNumber + '%')
      AND (ISNULL(@ContractStatus,'')          = '' OR ContractStatus          = @ContractStatus)
      AND (ISNULL(@ProductCode,'')             = '' OR ProductCode             = @ProductCode)
    ORDER BY SRNo DESC
END
GO

PRINT '== Script 15: T24_Contract_Detail table, Insert and Select procs created successfully. =='
GO
