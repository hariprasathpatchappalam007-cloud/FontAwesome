USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================================================
-- Proc_HF48_CreateCLMTicket
--
-- Shared CLM (Customer Lifecycle Management) service-ticket creation logic.
-- Extracted from Proc_HF48_Manual_Trigger's 'CreateCLMTicket' action so that
-- BOTH of the following apply the exact same business rules:
--   - Proc_HF48_Manual_Trigger           (manual "Create CLM Ticket" button)
--   - Proc_HF48_Disbursement_Monitoring  (automated 10-day Tier 1 trigger)
--
-- Business rules (unchanged from the manual trigger):
--   - Looks up the disbursement/application details for the given
--     App Ref No / Lead No / Disb Date.
--   - Open-ticket guard: skips creation if an open (non-Closed) CLM ticket
--     already exists for the application in FRM_SERVICE_REQUEST.
--   - Only Tier 1 / Tier 2 developers are eligible for a CLM ticket.
--   - Creates the FRM_SERVICE_REQUEST / FRM_SERVICE_REQUEST_HISTORY records
--     (with the same workflow/stage/allocation routing as the manual flow).
--   - Records the ticket in HF48_DISB_TASKS, including the full disbursement
--     details and the CLM ticket reference no. (Case_RefNo = SRNO), so they
--     can be displayed against the service request.
--   - Sends the team notification email and writes an audit log entry.
--
-- NOTE: This procedure does not open its own transaction. It is expected to
-- run inside the caller's transaction/try-catch (exactly as the original
-- inline logic in Proc_HF48_Manual_Trigger did), so an error here rolls
-- back whatever the caller has already done in the same batch.
-- =============================================================================
IF OBJECT_ID('[dbo].[Proc_HF48_CreateCLMTicket]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_CreateCLMTicket]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_CreateCLMTicket]
    @APP_REF_NO NVARCHAR(50),
    @Lead_No    NVARCHAR(50),
    @Disb_Date  DATETIME,
    @UserID     NVARCHAR(100),
    @Remarks    NVARCHAR(MAX) = NULL,
    @TaskID     INT OUTPUT,
    @Case_RefNo NVARCHAR(50) OUTPUT,
    @Status     NVARCHAR(50) OUTPUT,
    @Message    NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    SET @TaskID = NULL
    SET @Case_RefNo = NULL

    DECLARE @MAIL_TO NVARCHAR(1000)
    DECLARE @MAIL_CC NVARCHAR(1000)
    DECLARE @MAIL_SUBJECT NVARCHAR(500)
    DECLARE @MAIL_BODY NVARCHAR(MAX)
    DECLARE @EvalTeamEmail NVARCHAR(500)
    DECLARE @OpsTeamEmail NVARCHAR(500)
    DECLARE @CLMTeamEmail NVARCHAR(500)

    DECLARE @Customer_Name NVARCHAR(200)
    DECLARE @DeveloperName NVARCHAR(200)
    DECLARE @ProjectName NVARCHAR(200)
    DECLARE @Disb_Amount DECIMAL(18,2)
    DECLARE @DevTier NVARCHAR(50)
    DECLARE @Disb_Status NVARCHAR(50)
    DECLARE @ProjectStatus NVARCHAR(50)
    DECLARE @MilestonePaymentPct DECIMAL(18,2)
    DECLARE @PropertyPaymentPct DECIMAL(18,2)
    DECLARE @FinancePaymentPct DECIMAL(18,2)
    DECLARE @Disb_SrNo INT
    DECLARE @DaysLeft INT
    DECLARE @ExistingSRNo INT

    -- Distribution list emails
    SELECT @EvalTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam'
    SELECT @OpsTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam'
    SELECT @CLMTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam'

    -- Application / disbursement details (needed for HF48_DISB_TASKS + email)
    SELECT
        @Customer_Name = ld.Customer_name,
        @DeveloperName = ldp.Property_DeveloperName,
        @ProjectName = ldp.Property_ProjectName,
        @Disb_Amount = ldd.Disb_amount,
        @Disb_Status = ldd.Disb_Status,
        @MilestonePaymentPct = ldd.MilestonePaymentPct,
        @PropertyPaymentPct = ldd.PropertyPaymentPct,
        @FinancePaymentPct = ldd.FinancePaymentPct,
        @DevTier = ISNULL(ldm.dev_tier, 'Tier 2'),
        @ProjectStatus = ISNULL(lpm.value_tranche, 'No-Hold'),
        @Disb_SrNo = ldd.disb_srno
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS ld ON ld.lead_no = ldd.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldd.lead_no
    LEFT JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName
    LEFT JOIN lead_project lpm ON lpm.PROJECTNAME = ldp.Property_ProjectName
    WHERE ld.APP_REF_NO = @APP_REF_NO
      AND ldd.Lead_No = @Lead_No
      AND ldd.Disb_Date = @Disb_Date

    IF @Customer_Name IS NULL
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Disbursement record not found for App: ' + @APP_REF_NO + ', Lead: ' + @Lead_No
        RETURN
    END

    SET @DaysLeft = DATEDIFF(DAY, GETDATE(), @Disb_Date)

    -- =============================================
    -- Open-ticket guard: only create a new CLM ticket if there is no existing
    -- open ticket (not Closed) for this application in FRM_SERVICE_REQUEST
    -- =============================================
    SET @ExistingSRNo = NULL
    SELECT TOP 1 @ExistingSRNo = SRNO
    FROM FRM_SERVICE_REQUEST
    WHERE APPLICATIONID = @APP_REF_NO
      AND ISNULL(STATUS,'') <> 'C'
    ORDER BY SRNO DESC

    IF @ExistingSRNo IS NOT NULL
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'An open CLM ticket already exists for application ' + @APP_REF_NO + ' (SRNO=' + CONVERT(NVARCHAR(20), @ExistingSRNo) + '). A new ticket will not be created until it is closed.'

        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysLeft,
                'CLM-ServiceTicket-Skipped',
                'Open CLM ticket already exists (SRNO=' + CONVERT(NVARCHAR(20), @ExistingSRNo) + '). New ticket not created.',
                @UserID,
                ISNULL(@Remarks,''))
        RETURN
    END

    IF NOT (ISNULL(@DevTier,'') = 'Tier 1' OR ISNULL(@DevTier,'') = 'Tier 2')
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'This application dev_tier value is not Tier 1, please check the dev_tier value!'
        RETURN
    END

    -- =============================================
    -- Create the CLM ticket (ported unchanged from Proc_HF48_Manual_Trigger)
    -- =============================================
    DECLARE @USERNAME NVARCHAR(100),@cas_stage nvarchar(50) =NULL,
       @Current_Stage nvarchar(50) =NULL,
       @Next_Stage nvarchar(50) =NULL,
       @Current_Assigned_User nvarchar(100) =NULL,
       @Next_assigned_User nvarchar(100) =NULL,
       @Changed_Datetime datetime =NULL,
       @TAT_Datetime datetime =NULL,
       @TAT_StartTime datetime =NULL,
       @cas_workflow nvarchar(50) =NULL,
       @agentAllocationUser NVARCHAR(100)=NULL,
       @SRECCOUNT int,
       @CUSTID NVARCHAR(100)=NULL,
       @CUSTNAME NVARCHAR(100)=NULL,            
       @MOBILENO NVARCHAR(100)=NULL,
       @EMAILID NVARCHAR(100)=NULL,            
       @REMARKS_ NVARCHAR(100)=NULL,
       @Service_Source nvarchar(100)='0',
       @Service_Charge nvarchar(100)='0.00',
       @PaymentMode nvarchar(100)='0',
       @CO_ENDDATE nvarchar(50) =NULL,
       @Decline_Reason nvarchar(max) =NULL,
       @FILENAME NVARCHAR(200)=NULL
        
    SET @SRECCOUNT = 0              
    SELECT @SRECCOUNT=max(srno) FROM FRM_SERVICE_REQUEST            
    SET @SRECCOUNT = ISNULL(@SRECCOUNT,0) + 1

    INSERT INTO HF48_DISB_TASKS
        (APP_REF_NO, Lead_No, Disb_Date, Case_RefNo, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks, disb_srno,
         Customer_Name, Disb_Amount, DeveloperName, DevTier, ProjectName, ProjectStatus,
         MilestonePaymentPct, PropertyPaymentPct, FinancePaymentPct, Disb_Status, DaysLeft)
    VALUES
        (@APP_REF_NO, @Lead_No, @Disb_Date, @SRECCOUNT, 'CLM Service Ticket', 'CLM Team', 'Operations Team', 'Open', @UserID,
         ISNULL(@Remarks,''), @Disb_SrNo,
         @Customer_Name, @Disb_Amount, @DeveloperName, @DevTier, @ProjectName, @ProjectStatus,
         @MilestonePaymentPct, @PropertyPaymentPct, @FinancePaymentPct, @Disb_Status, @DaysLeft)

    SET @TaskID = SCOPE_IDENTITY()
    SET @Case_RefNo = CONVERT(NVARCHAR(50), @SRECCOUNT)

    -- Raquib work >> HF48 >> Phase 2 -- Total 3 places to created the CLM ticket
      If IsNull(@APP_REF_NO,'') <> ''
      Begin
           declare @CATEGORY_ NVARCHAR(100)='MBRE /  SZHP / self construction'
        declare @SUBCATEGORY_ NVARCHAR(100)='Milestone Payment'
        declare @IsretainCoolingOff nvarchar(5)='N'
        declare @Service_Department nvarchar(100)=null
        declare @allocationType nvarchar(100)
        declare @allocationuser nvarchar(100)
        DECLARE @Is_Email_Trigger nvarchar(10)
        DECLARE @Is_Sms_Trigger nvarchar(10)
        declare @WF_Code  nvarchar(50) =NULL
        declare @USERID1 nvarchar(50) = isnull(@UserID, 'SYSTEM')

        select @Service_Department = Service_Department,@allocationType=AllocationType,@allocationuser=OPS_MAKER_USER
       ,@Is_Email_Trigger = ISNULL(Is_Email_Trigger,'Y'),@Is_Sms_Trigger = ISNULL(Is_Sms_Trigger,'Y')
       ,@WF_Code = WF_Code
       from FRM_SERVICE_SUBCATEGORY_MASTER where SubCategory_Cat_Code = @CATEGORY_ and subcategory_code = @SUBCATEGORY_
       ---------------------------------

       SELECT @CUSTID=isnull(A.CUSTOMERID,''), @CUSTNAME=isnull(C.CUSTOMERNAME1,''),
       @MOBILENO=c.MOBILENUMBER,  @EMAILID=ISNULL(C.PERSONAL_EMAIL,A.PERSONAL_EMAIL)     
       FROM CORE_FLEX_ALL_APPS_MASTER A    
       left join Core_Customer_Details C on C.CUSTOMERID=A.CUSTOMERID        
       LEFT JOIN CORE_APPLICATION_DETAILS B  ON  B.APPLICATION_ID like '%' + A.APPLICATIONID + '%'         
       WHERE 1=1 AND A.APPLICATIONID like '%'+ @APP_REF_NO +'%' 

       if (isnull(@CUSTID,'')='' and isnull(@CUSTNAME,'')='')
       begin
        SELECT @CUSTID=isnull(A.CUSTOMERID, b.customerID), @CUSTNAME=isnull(A.CUSTOMER_NAME,B.Customer_Name),
        @MOBILENO=CAse When isnull(A.Mobile_Code,'')<>'' and isnull(A.Mobile_No,'')<>'' then A.mobile_code + A.Mobile_no
          else isnull(B.Customer_Mob_Code,'') + isnull(B.Customer_mob_no,'') end,
         @EMAILID=B.CUSTOMER_EMAIL_P 
        FROM Lead_details A    
        LEFT JOIN Lead_details_customer B  ON  A.Lead_no = B.Lead_no 
        WHERE 1=1 AND A.App_ref_no = @APP_REF_NO
       end

       if @allocationType = 'To User'
       begin
            set @USERNAME = @allocationuser 
         set @cas_stage = 'CLM_UPDATE';
         set @Next_Stage = 'END_OF_PROCESS'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();
       end
       else if @allocationType = 'To Workflow'
       begin
        set @USERNAME = CASE @allocationuser WHEN '' THEN @USERID1 ELSE ISNULL(@allocationuser,@USERID1) END
        set @cas_workflow = @WF_Code;
        if @WF_Code = 'CLM_RC_END' OR @WF_Code = 'CLM_RC_OPS_END' OR @WF_Code = 'CLM_RC_OPS_PMU_END'
        begin
         set @cas_stage = 'CAS_HELP_DESK';
         set @Next_Stage = 'CAS_LEVEL_6'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();
        end    
        else if @WF_Code = 'CLM_OPS_END'
        begin
         set @cas_stage = 'CAS_OPS_MAKER'
         set @Next_Stage = 'CAS_OPS_MAKER'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();
         declare @USRECCOUNT int=0
         select @USRECCOUNT=COUNT(1) from FRM_USERROLE where USER_ROLE = 'CAS_OPS_MAKER' and user_userid = @USERNAME
         IF ISNULL(@USRECCOUNT,0)=0
         BEGIN
          SET @USERNAME=NULL
          SET @cas_stage='CAS_OPS_HELP_DESK'
         END
        end
        else 
        begin
         set @cas_stage = 'CLM_UPDATE';
         set @Next_Stage = 'END_OF_PROCESS'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();

         IF( EXISTS( SELECT 1 from FRM_SERVICE_SUBCATEGORY_MASTER where SubCategory_Cat_Code = @CATEGORY_ and subcategory_code = @SUBCATEGORY_ AND IsRetention=1))    
         BEGIN
          IF( EXISTS( select 1 from FRM_GNARR where Value = @USERID1 and CODE = 'CAS_RETENTION'))                                     
            begin
             set @agentAllocationUser = @USERID1
            end 
          ELSE
          BEGIN
           select TOP 1 @agentAllocationUser=A.Value from FRM_GNARR A
           LEFT OUTER JOIN
           FRM_REQUEST_ALLOCATION_USERLIST B
           ON A.Value=B.USERID AND B.SYSTEM_NAME='Retention'
           where  A.Code='CAS_RETENTION' AND ISNULL(A.STATUS,'A')='A' ORDER BY ISNULL(B.LastAssignDate,DATEADD(YEAR,-2,GETDATE())) ASC

           IF( EXISTS( SELECT 1 from FRM_REQUEST_ALLOCATION_USERLIST WHERE SYSTEM_NAME='Retention' AND USERID=@agentAllocationUser))    
           BEGIN
            UPDATE FRM_REQUEST_ALLOCATION_USERLIST SET LastAssignDate=GETDATE() WHERE SYSTEM_NAME='Retention' AND USERID=@agentAllocationUser
           END
           ELSE
           BEGIN
            INSERT INTO FRM_REQUEST_ALLOCATION_USERLIST(
            SYSTEM_NAME
           ,USERID
           ,Status
           ,LastAssignDate
             )
              VALUES ('Retention',@agentAllocationUser,'A',GETDATE())
           END
           END
         END
         ELSE
         SET @agentAllocationUser= NULL
        End    
       end
       else
        begin
         set @cas_stage = 'CLM';
         set @Next_Stage = 'CLM_UPDATE'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();

        if isnull(@Service_Department,'0') <> '0'
        begin
    
         select @SRECCOUNT = count(1) from FRM_REQUEST_ALLOCATION_USERLIST  
         where userid = @USERID1 and isnull(status,'A') = 'A' and SYSTEM_NAME = 'Customer Service' AND DepartmentName = @Service_Department
     
         if @SRECCOUNT > 0 and @Service_Department = 'Customer Service'
          set @USERNAME = @USERID1
         else
          select top 1 @USERNAME = userid from FRM_REQUEST_ALLOCATION_USERLIST 
          where SYSTEM_NAME = 'Customer Service' AND DepartmentName = @Service_Department and isnull(status,'A') = 'A' order by isnull(LastAssignDate,'01/01/1900')
     
         update FRM_REQUEST_ALLOCATION_USERLIST set LastAssignDate= getdate() 
         where system_name = 'Customer Service' and DepartmentName = @Service_Department and USERID = @USERNAME
      
        end
        else
        begin
         select top 1 @USERNAME = userid from FRM_REQUEST_ALLOCATION_USERLIST 
         where SYSTEM_NAME = 'Customer Service' and isnull(status,'A') = 'A' order by isnull(LastAssignDate,getdate())

         update FRM_REQUEST_ALLOCATION_USERLIST set LastAssignDate= getdate() 
         where system_name = 'Customer Service' and USERID = @USERNAME
        end
       end
       
       SET @agentAllocationUser=ISNULL(@agentAllocationUser,@USERID1)
            
       INSERT INTO FRM_SERVICE_REQUEST            
       (            
        SRNO,APPLICATIONID,CUSTID,CUSTOMERNAME,            
        MOBILENO,EMAILID,CATEGORY,SUBCATEGORY,            
        REMARKS,STATUS,CREATEDBY_USER,CREATEDON_DATE,ASSIGNED_TO,
        service_source,Service_Charge,Service_Department,PaymentMode,
        Assigned_Department,IsCoolingOff,CO_StartDate,CO_EndDate
        ,cas_workflow,cas_stage
        ,Agent_AssignedTo,cas_assignedTo
  
       )            
       VALUES            
       (            
        @SRECCOUNT,@APP_REF_NO,@CUSTID,@CUSTNAME,            
        @MOBILENO,@EMAILID,@CATEGORY_,@SUBCATEGORY_,            
        @REMARKS_,'N',@USERID1,GETDATE(),CASE @cas_Stage WHEN 'CAS_HELP_DESK' THEN '0' ELSE @USERNAME END ,-- Changed by rajesh kumar(17/05/2023)
        @Service_Source,convert(numeric(20,2),@Service_Charge),@Service_Department,@PaymentMode,
        @Service_Department,@IsretainCoolingOff,GETDATE(),@CO_ENDDATE,
        @cas_workflow,@cas_Stage
        ,@agentAllocationUser,CASE @cas_Stage WHEN 'CAS_HELP_DESK' THEN '0' ELSE ISNULL(@allocationuser,@USERID1) END --added by rajesh kumar (08/06/2023)
       )   
   
       if @WF_Code = 'CLM_RC_END' OR @WF_Code = 'CLM_RC_OPS_END' OR @WF_Code = 'CLM_OPS_END' OR @WF_Code = 'CLM_RC_OPS_PMU_END'
       begin
        INSERT INTO FRM_SERVICE_REQUEST_HISTORY            
        (SRNO,APPLICATIONID,CREATEDBY_USER,CREATEDON_DATE,REMARKS,STATUS,FILE_NAMES,
        Current_Stage,Next_Stage,Current_Assigned_User,Next_assigned_User,Changed_Datetime,TAT_Datetime,Time_Taken,TAT_StartTime,DECLINE_REASON) --Added by Sandip for Credit after sales
        VALUES(@SRECCOUNT,@APP_REF_NO,@USERID1,GETDATE(),@REMARKS_,'IP',@FILENAME,'CLM',@cas_stage,@USERID1,NULL,getdate(),@TAT_Datetime, DATEDIFF(MI,@TAT_StartTime,@TAT_Datetime),@TAT_StartTime,@DECLINE_REASON)
       END
       ELSE
       BEGIN
        INSERT INTO FRM_SERVICE_REQUEST_HISTORY            
        (SRNO,APPLICATIONID,CREATEDBY_USER,CREATEDON_DATE,REMARKS,STATUS,FILE_NAMES,
        Current_Stage,Next_Stage,Current_Assigned_User,Next_assigned_User,Changed_Datetime,TAT_Datetime,Time_Taken,TAT_StartTime,DECLINE_REASON) --Added by Sandip for Credit after sales
           
        VALUES       
        (@SRECCOUNT,@APP_REF_NO,@USERID1,GETDATE(),@REMARKS_,'N',@FILENAME,
        'CLM',@cas_stage
        ,@USERID1,NULL,getdate(),@TAT_Datetime, DATEDIFF(MI,@TAT_StartTime,@TAT_Datetime),@TAT_StartTime,@DECLINE_REASON
        )
       END 

       ---------------------------------------------------------------------------------------------------------------------------
      END

    -- Notify all teams
    SET @MAIL_TO = @OpsTeamEmail
    SET @MAIL_CC = @EvalTeamEmail + ';' + @CLMTeamEmail
    SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Service Ticket Created (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

    SET @MAIL_BODY = 'Dear Team,

'
    SET @MAIL_BODY = @MAIL_BODY + 'A CLM Service Ticket has been created by ' + ISNULL(@UserID,'') + '.

'
    SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#FF6600><td colspan=2><font color=white><b>CLM Service Ticket</b></font></td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Service Ticket Ref No</font></td><td>' + ISNULL(@Case_RefNo,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + ' (' + ISNULL(@DevTier,'') + ')</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Assigned To</font></td><td>Operations Team (CLM)</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#FF6600 valign=top><font color=white><b>Created By</b></font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'Service ticket') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '</table>
'
    SET @MAIL_BODY = @MAIL_BODY + 'Regards,
HF48 Automated Monitoring System'

    INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
    VALUES (@APP_REF_NO, 'N', 'HF48 Service Ticket', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

    -- Audit Log
    INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysLeft,
      'CLM-ServiceTicket-Created',
      'CLM Service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' (Ref ' + @Case_RefNo + ') created.',
      @MAIL_TO + ';CC:' + @MAIL_CC,
      @UserID,
      ISNULL(@Remarks, 'CLM service ticket creation'))

    SET @Status = 'SUCCESS'
    SET @Message = 'Service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' (Ref ' + @Case_RefNo + ') created successfully. Notifications sent.'
END
GO

PRINT 'Proc_HF48_CreateCLMTicket created successfully.'
GO

-- =============================================================================
-- Proc_HF48_CreateENGTicket
--
-- Shared Engineering service-ticket creation logic. Extracted from
-- Proc_HF48_Manual_Trigger's 'CreateENGTicket' action so that BOTH of the
-- following apply the exact same business rules:
--   - Proc_HF48_Manual_Trigger           (manual "Create Engineering Ticket" button)
--   - Proc_HF48_Disbursement_Monitoring  (automated 10-day non-Tier-1 trigger)
--
-- Business rules (unchanged from the manual trigger):
--   - Looks up the disbursement/application details for the given
--     App Ref No / Lead No / Disb Date.
--   - Open-ticket guard: skips creation if an open (non-Closed) Engineering
--     ticket already exists for the application in ENG_HLP_CASES.
--   - Only Tier 2 developers are eligible for an Engineering ticket.
--   - Creates the ENG_HLP_CASES record.
--   - Records the ticket in HF48_DISB_TASKS, including the full disbursement
--     details and the Engineering ticket reference no. (Case_RefNo), so they
--     can be displayed against the service request.
--   - Sends the team notification email and writes an audit log entry.
--
-- NOTE: This procedure does not open its own transaction - see the note on
-- Proc_HF48_CreateCLMTicket above.
-- =============================================================================
IF OBJECT_ID('[dbo].[Proc_HF48_CreateENGTicket]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_CreateENGTicket]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_CreateENGTicket]
    @APP_REF_NO NVARCHAR(50),
    @Lead_No    NVARCHAR(50),
    @Disb_Date  DATETIME,
    @UserID     NVARCHAR(100),
    @Remarks    NVARCHAR(MAX) = NULL,
    @TaskID     INT OUTPUT,
    @Case_RefNo NVARCHAR(50) OUTPUT,
    @Status     NVARCHAR(50) OUTPUT,
    @Message    NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    SET @TaskID = NULL
    SET @Case_RefNo = NULL

    DECLARE @MAIL_TO NVARCHAR(1000)
    DECLARE @MAIL_CC NVARCHAR(1000)
    DECLARE @MAIL_SUBJECT NVARCHAR(500)
    DECLARE @MAIL_BODY NVARCHAR(MAX)
    DECLARE @EnggTeamEmail NVARCHAR(500)
    DECLARE @OpsTeamEmail NVARCHAR(500)

    DECLARE @Customer_Name NVARCHAR(200)
    DECLARE @DeveloperName NVARCHAR(200)
    DECLARE @ProjectName NVARCHAR(200)
    DECLARE @Disb_Amount DECIMAL(18,2)
    DECLARE @DevTier NVARCHAR(50)
    DECLARE @Disb_Status NVARCHAR(50)
    DECLARE @ProjectStatus NVARCHAR(50)
    DECLARE @MilestonePaymentPct DECIMAL(18,2)
    DECLARE @PropertyPaymentPct DECIMAL(18,2)
    DECLARE @FinancePaymentPct DECIMAL(18,2)
    DECLARE @Disb_SrNo INT
    DECLARE @DaysLeft INT
    DECLARE @ExistingCaseRefNo NVARCHAR(50)
    DECLARE @reccount INT

    -- Distribution list emails
    SELECT @EnggTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EngineeringTeam'
    SELECT @OpsTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam'

    -- Application / disbursement details (needed for HF48_DISB_TASKS + email)
    SELECT
        @Customer_Name = ld.Customer_name,
        @DeveloperName = ldp.Property_DeveloperName,
        @ProjectName = ldp.Property_ProjectName,
        @Disb_Amount = ldd.Disb_amount,
        @Disb_Status = ldd.Disb_Status,
        @MilestonePaymentPct = ldd.MilestonePaymentPct,
        @PropertyPaymentPct = ldd.PropertyPaymentPct,
        @FinancePaymentPct = ldd.FinancePaymentPct,
        @DevTier = ISNULL(ldm.dev_tier, 'Tier 2'),
        @ProjectStatus = ISNULL(lpm.value_tranche, 'No-Hold'),
        @Disb_SrNo = ldd.disb_srno
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS ld ON ld.lead_no = ldd.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldd.lead_no
    LEFT JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName
    LEFT JOIN lead_project lpm ON lpm.PROJECTNAME = ldp.Property_ProjectName
    WHERE ld.APP_REF_NO = @APP_REF_NO
      AND ldd.Lead_No = @Lead_No
      AND ldd.Disb_Date = @Disb_Date

    IF @Customer_Name IS NULL
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Disbursement record not found for App: ' + @APP_REF_NO + ', Lead: ' + @Lead_No
        RETURN
    END

    SET @DaysLeft = DATEDIFF(DAY, GETDATE(), @Disb_Date)

    -- =============================================
    -- Open-ticket guard: only create a new Engineering ticket if there is no
    -- existing open ticket (not Closed) for this application in ENG_HLP_CASES
    -- =============================================
    SET @ExistingCaseRefNo = NULL
    SELECT TOP 1 @ExistingCaseRefNo = Case_RefNo
    FROM ENG_HLP_CASES
    WHERE Case_AppID = @APP_REF_NO
      AND ISNULL(Case_Status,'') <> 'C'
    ORDER BY Case_RefNo DESC

    IF @ExistingCaseRefNo IS NOT NULL
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'An open Engineering ticket already exists for application ' + @APP_REF_NO + ' (Case Ref No=' + @ExistingCaseRefNo + '). A new ticket will not be created until it is closed.'

        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysLeft,
                'ENG-ServiceTicket-Skipped',
                'Open Engineering ticket already exists (Case Ref No=' + @ExistingCaseRefNo + '). New ticket not created.',
                @UserID,
                ISNULL(@Remarks,''))
        RETURN
    END

    IF ISNULL(@DevTier,'') <> 'Tier 2'
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'This application dev_tier value is not Tier 2, please check the dev_tier value!'
        RETURN
    END

    -- =============================================
    -- Create the Engineering ticket (ported unchanged from Proc_HF48_Manual_Trigger)
    -- =============================================
    select @reccount = count(1) from ENG_HLP_CASES where convert(nvarchar(10),CreatedOn_Date,103) =  convert(nvarchar(10),getdate(),103)
    set @reccount = @reccount + 1
    set @Case_RefNo = replace(convert(varchar(30),getdate(),102),'.','') + convert(varchar(10),@reccount)

    INSERT INTO HF48_DISB_TASKS
        (APP_REF_NO, Lead_No, Disb_Date, Case_RefNo, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks, disb_srno,
         Customer_Name, Disb_Amount, DeveloperName, DevTier, ProjectName, ProjectStatus,
         MilestonePaymentPct, PropertyPaymentPct, FinancePaymentPct, Disb_Status, DaysLeft)
    VALUES
        (@APP_REF_NO, @Lead_No, @Disb_Date, @Case_RefNo, 'Engineering Task', 'Engineering Team', 'Engineering Team', 'Open', @UserID,
         ISNULL(@Remarks,''), @Disb_SrNo,
         @Customer_Name, @Disb_Amount, @DeveloperName, @DevTier, @ProjectName, @ProjectStatus,
         @MilestonePaymentPct, @PropertyPaymentPct, @FinancePaymentPct, @Disb_Status, @DaysLeft)

    SET @TaskID = SCOPE_IDENTITY()

    insert into ENG_HLP_CASES (Case_RefNo,
             Case_CustID,
             Case_CustName,
             Case_AppID,
             Case_TelNo,
             Case_MobNo,
             Case_Email,
             Case_SDesc,
             Case_Status,
             Case_AssignedUser,
             Createdby_User,
             Createdon_Date,
             Case_user_Status,
             Case_filename,
             Case_category,
             Case_subcategory,
             USERNAME,
             InitialedBY_USER,
             case_User_Location)
      values(@Case_RefNo,null,@Customer_Name,@APP_REF_NO,null,null,null,
      '30-day pre-disbursement task for engineering review.',
      'O','COMMON-NEW','SYSTEM',GETDATE(),'O',null,'4','Milestone / Progress Verification','SYSTEM','SYSTEM','TAMWEEL_AUD')

    -- Notify Engineering Team, CC Operations
    SET @MAIL_TO = @EnggTeamEmail
    SET @MAIL_CC = @OpsTeamEmail
    SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Engineering Service Ticket Created (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

    SET @MAIL_BODY = 'Dear Team,

'
    SET @MAIL_BODY = @MAIL_BODY + 'An Engineering Ticket has been created by ' + ISNULL(@UserID,'') + '.

'
    SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#FF6600><td colspan=2><font color=white><b>Engineering Service Ticket</b></font></td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Service Ticket Ref No</font></td><td>' + ISNULL(@Case_RefNo,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + ' (' + ISNULL(@DevTier,'') + ')</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Assigned To</font></td><td>Engineering Team</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#FF6600 valign=top><font color=white><b>Created By</b></font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'Service ticket') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '</table>
'
    SET @MAIL_BODY = @MAIL_BODY + 'Regards,
HF48 Automated Monitoring System'

    INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
    VALUES (@APP_REF_NO, 'N', 'HF48 Service Ticket', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

    -- Audit Log
    INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysLeft,
      'ENG-ServiceTicket-Created',
      'Engineering service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' (Ref ' + @Case_RefNo + ') created.',
      @MAIL_TO + ';CC:' + @MAIL_CC,
      @UserID,
      ISNULL(@Remarks, 'Engineering service ticket creation'))

    SET @Status = 'SUCCESS'
    SET @Message = 'Service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' (Ref ' + @Case_RefNo + ') created successfully. Notifications sent.'
END
GO

PRINT 'Proc_HF48_CreateENGTicket created successfully.'
GO
