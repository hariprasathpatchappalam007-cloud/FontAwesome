USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Script 10: Proc_HF48_PostponeNoHold_Approve
-- Approves a "Postpone" request:
--   - Shifts LEAD_DETAILS_DISB.Disb_Date
--   - Does NOT touch lead_project.value_tranche
--   - Marks the request as Approved
--
-- Called from HF48BulkPostponement.aspx when
-- the RequestType = 'Postpone'.
--
-- NOTE: Table names (HF48_BulkPostpone_Requests,
-- HF48_BulkPostpone_RequestDetail) must match
-- the actual schema in your database.
-- =============================================
IF OBJECT_ID('[dbo].[Proc_HF48_PostponeNoHold_Approve]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_HF48_PostponeNoHold_Approve]
GO

CREATE PROCEDURE [dbo].[Proc_HF48_PostponeNoHold_Approve]
    @RequestID      INT,
    @CheckerUser    NVARCHAR(100),
    @CheckerRemarks NVARCHAR(500) = NULL,
    @Status         NVARCHAR(50)  OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    -- ---- Validate the request exists and is the right type -------------------
    DECLARE @RequestType   NVARCHAR(50)
    DECLARE @ReqStatus     NVARCHAR(50)
    DECLARE @MakerUser     NVARCHAR(100)
    DECLARE @ShiftDays     INT
    DECLARE @ProjectName   NVARCHAR(200)
    DECLARE @AffectedRows  INT

    SELECT
        @RequestType  = RequestType,
        @ReqStatus    = [Status],
        @MakerUser    = MakerUser,
        @ShiftDays    = ShiftDays,
        @ProjectName  = Property_ProjectName,
        @AffectedRows = AffectedRowCount
    FROM [dbo].[HF48_BulkPostpone_Requests]
    WHERE RequestID = @RequestID

    IF @RequestType IS NULL
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) + ' not found.'
        RETURN
    END

    IF @RequestType <> 'Postpone'
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) +
                       ' is of type "' + @RequestType + '", not "Postpone". Use the standard Approve action.'
        RETURN
    END

    IF @ReqStatus <> 'Pending Approval'
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request is not in Pending Approval status (current: ' + @ReqStatus + ').'
        RETURN
    END

    -- Maker / Checker four-eyes check
    IF UPPER(@MakerUser) = UPPER(@CheckerUser)
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Maker and Checker cannot be the same user.'
        RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_POSTPONE_APPROVE

        -- ---- Apply date shifts from the pre-computed detail rows -------------
        UPDATE ldd
        SET ldd.Disb_Date = d.NewDisbDate
        FROM [dbo].[LEAD_DETAILS_DISB] ldd
        INNER JOIN [dbo].[HF48_BulkPostpone_RequestDetail] d
            ON d.Lead_No = ldd.lead_no
           AND CAST(ldd.Disb_Date AS DATE) = CAST(d.OldDisbDate AS DATE)
        WHERE d.RequestID = @RequestID
          AND d.Applied   = 0

        -- Mark detail rows as applied
        UPDATE [dbo].[HF48_BulkPostpone_RequestDetail]
        SET Applied = 1
        WHERE RequestID = @RequestID

        -- ---- Intentionally NOT updating lead_project.value_tranche ----------
        -- (This is the key difference from Proc_HF48_BulkPostpone_Approve)

        -- ---- Mark the request as Approved ------------------------------------
        UPDATE [dbo].[HF48_BulkPostpone_Requests]
        SET [Status]       = 'Approved',
            CheckerUser    = @CheckerUser,
            CheckerOn      = GETDATE(),
            CheckerRemarks = @CheckerRemarks
        WHERE RequestID = @RequestID

        -- ---- Audit log entry -------------------------------------------------
        INSERT INTO [dbo].[HF48_DISB_AUDIT_LOG]
            (APP_REF_NO, Lead_No, Disb_Date, DaysBefore,
             ActionType, ActionResult, NotificationSentTo,
             CreatedBy, CreatedOn, Remarks)
        SELECT
            d.APP_REF_NO,
            d.Lead_No,
            d.OldDisbDate,
            @ShiftDays,
            CASE WHEN @ShiftDays >= 0 THEN 'BulkPostponement' ELSE 'BulkPreponment' END,
            'Date shifted from ' + CONVERT(NVARCHAR(20), d.OldDisbDate, 103) +
                ' to ' + CONVERT(NVARCHAR(20), d.NewDisbDate, 103),
            NULL,
            @CheckerUser,
            GETDATE(),
            'Postpone (No Hold) approved. Req #' + CAST(@RequestID AS NVARCHAR(10)) +
                CASE WHEN ISNULL(@CheckerRemarks,'') <> '' THEN '. ' + @CheckerRemarks ELSE '' END
        FROM [dbo].[HF48_BulkPostpone_RequestDetail] d
        WHERE d.RequestID = @RequestID

    COMMIT TRANSACTION T_POSTPONE_APPROVE

    SET @Status  = 'SUCCESS'
    SET @Message = 'Request #' + CAST(@RequestID AS NVARCHAR(10)) + ' approved. ' +
                   CAST(@AffectedRows AS NVARCHAR(10)) + ' schedule(s) ' +
                   CASE WHEN @ShiftDays >= 0 THEN 'postponed' ELSE 'preponed' END +
                   ' by ' + CAST(ABS(@ShiftDays) AS NVARCHAR(10)) + ' day(s). No hold applied to project: ' +
                   ISNULL(@ProjectName, 'N/A') + '.'

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_POSTPONE_APPROVE
        SET @Status  = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- =============================================
-- Also update Proc_HF48_BulkPostpone_Submit to
-- accept RequestType = 'Postpone'.
-- If the existing proc validates the type, run
-- the ALTER below; otherwise skip it.
-- =============================================
-- OPTIONAL: Add 'Postpone' as a valid RequestType
-- Example (adjust to match your actual proc body):
--
-- ALTER PROCEDURE [dbo].[Proc_HF48_BulkPostpone_Submit]
-- ... keep all existing parameters ...
-- AS
-- BEGIN
--     IF @RequestType NOT IN ('Hold','Unhold','Postpone')
--     BEGIN
--         SET @Status = 'FAILURE'; SET @Message = 'Invalid RequestType.'; RETURN;
--     END
--     ... rest of existing logic unchanged ...
-- END
-- GO

PRINT '== Script 10: Proc_HF48_PostponeNoHold_Approve created successfully. =='
GO
