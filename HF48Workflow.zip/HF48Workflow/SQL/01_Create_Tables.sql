USE [LMS_DEV]
GO

-- =============================================
-- HF48 Disbursement Monitoring - Table Scripts
-- =============================================

-- 1. Audit Log Table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_AUDIT_LOG]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[HF48_DISB_AUDIT_LOG]
    (
        AuditID         INT IDENTITY(1,1) PRIMARY KEY,
        APP_REF_NO      NVARCHAR(50),
        Lead_No         NVARCHAR(50),
        Disb_Date       DATETIME,
        DaysBefore      INT,
        ActionType       NVARCHAR(100),    -- '60-Day Notification','30-Day Notification','10-Day Task','Evaluation-Negative','Evaluation-Positive','ServiceTicket-Created','ServiceTicket-Closed','Manual-Notification','Manual-ServiceTicket'
        ActionResult    NVARCHAR(500),
        NotificationSentTo NVARCHAR(500),
        CreatedBy       NVARCHAR(100) DEFAULT 'SYSTEM',
        CreatedOn       DATETIME DEFAULT GETDATE(),
        Remarks         NVARCHAR(MAX)
    )
END
GO

-- 2. Task Table for Engineering Team
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[HF48_DISB_TASKS]
    (
        TaskID          INT IDENTITY(1,1) PRIMARY KEY,
        APP_REF_NO      NVARCHAR(50),
        Lead_No         NVARCHAR(50),
        Disb_Date       DATETIME,
        Case_RefNo      NVARCHAR(50),      -- FRM_SERVICE_REQUEST.SRNO (CLM) or ENG_HLP_CASES.Case_RefNo (Engineering)
        TaskType        NVARCHAR(100),     -- 'Engineering Task','CLM Service Ticket'
        AssignedTeam    NVARCHAR(100),
        AssignedTo      NVARCHAR(100),
        Status          NVARCHAR(50) DEFAULT 'Open',  -- 'Open','In-Progress','Closed'
        CreatedBy       NVARCHAR(100) DEFAULT 'SYSTEM',
        CreatedOn       DATETIME DEFAULT GETDATE(),
        ClosedBy        NVARCHAR(100),
        ClosedOn        DATETIME,
        Remarks         NVARCHAR(MAX),
        disb_srno       INT,               -- FK back to LEAD_DETAILS_DISB.disb_srno

        -- Disbursement detail snapshot (captured at ticket-creation time so the
        -- CLM/Engineering service request screens can display these without a join)
        Customer_Name        NVARCHAR(200),
        Disb_Amount          DECIMAL(18,2),
        DeveloperName        NVARCHAR(200),
        DevTier              NVARCHAR(50),
        ProjectName          NVARCHAR(200),
        ProjectStatus        NVARCHAR(50),      -- lead_project.value_tranche
        MilestonePaymentPct  DECIMAL(18,2),
        PropertyPaymentPct   DECIMAL(18,2),
        FinancePaymentPct    DECIMAL(18,2),
        Disb_Status          NVARCHAR(50),      -- LEAD_DETAILS_DISB.Disb_Status
        DaysLeft             INT                -- days remaining at ticket-creation time
    )
END
GO

-- 2b. Migration: add Case_RefNo / disb_srno to HF48_DISB_TASKS
--     if the table already existed before these columns were introduced
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'Case_RefNo'
)
BEGIN
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD Case_RefNo NVARCHAR(50) NULL
    PRINT 'Column Case_RefNo added to HF48_DISB_TASKS.'
END
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'disb_srno'
)
BEGIN
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD disb_srno INT NULL
    PRINT 'Column disb_srno added to HF48_DISB_TASKS.'
END
GO

-- 2c. Migration: add disbursement-detail snapshot columns to HF48_DISB_TASKS
--     (App Ref No/Lead No/Case_RefNo already existed; these add the rest of
--     the fields required to display full disbursement details against the
--     CLM/Engineering service request)
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'Customer_Name')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD Customer_Name NVARCHAR(200) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'Disb_Amount')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD Disb_Amount DECIMAL(18,2) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'DeveloperName')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD DeveloperName NVARCHAR(200) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'DevTier')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD DevTier NVARCHAR(50) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'ProjectName')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD ProjectName NVARCHAR(200) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'ProjectStatus')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD ProjectStatus NVARCHAR(50) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'MilestonePaymentPct')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD MilestonePaymentPct DECIMAL(18,2) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'PropertyPaymentPct')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD PropertyPaymentPct DECIMAL(18,2) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'FinancePaymentPct')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD FinancePaymentPct DECIMAL(18,2) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'Disb_Status')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD Disb_Status NVARCHAR(50) NULL
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'DaysLeft')
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD DaysLeft INT NULL
PRINT 'HF48_DISB_TASKS disbursement-detail snapshot columns verified/added.'
GO

-- 3. Configuration Table for Distribution Lists
-- Uses existing frm_gnarr pattern: Code / Value / PassValue
-- Insert config entries if not exists

IF NOT EXISTS (SELECT 1 FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam')
    INSERT INTO frm_gnarr (Code, Value, PassValue) VALUES ('HF48_DISTRIBUTION', 'EvaluationTeam', 'evaluation.team@dib.ae')

IF NOT EXISTS (SELECT 1 FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EngineeringTeam')
    INSERT INTO frm_gnarr (Code, Value, PassValue) VALUES ('HF48_DISTRIBUTION', 'EngineeringTeam', 'engineering.team@dib.ae')

IF NOT EXISTS (SELECT 1 FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam')
    INSERT INTO frm_gnarr (Code, Value, PassValue) VALUES ('HF48_DISTRIBUTION', 'OperationsTeam', 'operations.team@dib.ae')

IF NOT EXISTS (SELECT 1 FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam')
    INSERT INTO frm_gnarr (Code, Value, PassValue) VALUES ('HF48_DISTRIBUTION', 'CLMTeam', 'clm.team@dib.ae')
GO

PRINT 'HF48 Disbursement Monitoring tables and configuration created successfully.'
GO
