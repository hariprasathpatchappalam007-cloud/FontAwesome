USE [LMS_DEV]
GO

-- =============================================
-- HF48 Disbursement Monitoring - Table Scripts
-- =============================================

-- 1. Audit Log Table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_AUDIT_LOG]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[HF48_DISB_AUDIT_LOG]
    (
        AuditID         INT IDENTITY(1,1) PRIMARY KEY,
        APP_REF_NO      NVARCHAR(50),
        Lead_No         NVARCHAR(50),
        Disb_Date       DATETIME,
        DaysBefore      INT,
        ActionType       NVARCHAR(100),    -- '60-Day Notification','30-Day Notification','10-Day Task','Evaluation-Negative','Evaluation-Positive','ServiceTicket-Created','ServiceTicket-Closed','Manual-Notification','Manual-ServiceTicket'
        ActionResult    NVARCHAR(500),
        NotificationSentTo NVARCHAR(500),
        CreatedBy       NVARCHAR(100) DEFAULT 'SYSTEM',
        CreatedOn       DATETIME DEFAULT GETDATE(),
        Remarks         NVARCHAR(MAX)
    )
END
GO

-- 2. Task Table for Engineering Team
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[HF48_DISB_TASKS]
    (
        TaskID          INT IDENTITY(1,1) PRIMARY KEY,
        APP_REF_NO      NVARCHAR(50),
        Lead_No         NVARCHAR(50),
        Disb_Date       DATETIME,
        Case_RefNo      NVARCHAR(50),      -- FRM_SERVICE_REQUEST.SRNO (CLM) or ENG_HLP_CASES.Case_RefNo (Engineering)
        TaskType        NVARCHAR(100),     -- 'Engineering Task','CLM Service Ticket'
        AssignedTeam    NVARCHAR(100),
        AssignedTo      NVARCHAR(100),
        Status          NVARCHAR(50) DEFAULT 'Open',  -- 'Open','In-Progress','Closed'
        CreatedBy       NVARCHAR(100) DEFAULT 'SYSTEM',
        CreatedOn       DATETIME DEFAULT GETDATE(),
        ClosedBy        NVARCHAR(100),
        ClosedOn        DATETIME,
        Remarks         NVARCHAR(MAX),
        disb_srno       INT                -- FK back to LEAD_DETAILS_DISB.disb_srno
    )
END
GO

-- 2b. Migration: add Case_RefNo / disb_srno to HF48_DISB_TASKS
--     if the table already existed before these columns were introduced
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'Case_RefNo'
)
BEGIN
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD Case_RefNo NVARCHAR(50) NULL
    PRINT 'Column Case_RefNo added to HF48_DISB_TASKS.'
END
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[HF48_DISB_TASKS]') AND name = 'disb_srno'
)
BEGIN
    ALTER TABLE [dbo].[HF48_DISB_TASKS] ADD disb_srno INT NULL
    PRINT 'Column disb_srno added to HF48_DISB_TASKS.'
END
GO

-- 3. Configuration Table for Distribution Lists
-- Uses existing frm_gnarr pattern: Code / Value / PassValue
-- Insert config entries if not exists

IF NOT EXISTS (SELECT 1 FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam')
    INSERT INTO frm_gnarr (Code, Value, PassValue) VALUES ('HF48_DISTRIBUTION', 'EvaluationTeam', 'evaluation.team@dib.ae')

IF NOT EXISTS (SELECT 1 FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EngineeringTeam')
    INSERT INTO frm_gnarr (Code, Value, PassValue) VALUES ('HF48_DISTRIBUTION', 'EngineeringTeam', 'engineering.team@dib.ae')

IF NOT EXISTS (SELECT 1 FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam')
    INSERT INTO frm_gnarr (Code, Value, PassValue) VALUES ('HF48_DISTRIBUTION', 'OperationsTeam', 'operations.team@dib.ae')

IF NOT EXISTS (SELECT 1 FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam')
    INSERT INTO frm_gnarr (Code, Value, PassValue) VALUES ('HF48_DISTRIBUTION', 'CLMTeam', 'clm.team@dib.ae')
GO

PRINT 'HF48 Disbursement Monitoring tables and configuration created successfully.'
GO
