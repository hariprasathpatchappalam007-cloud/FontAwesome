USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Script 08: Maker-Checker Stored Procedures
-- for Takaful_Product_Master (Table 2)
-- =============================================

-- =============================================
-- 1. Proc_Takaful_GetProducts
--    Get all products with optional filters
-- =============================================
IF OBJECT_ID('[dbo].[Proc_Takaful_GetProducts]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_Takaful_GetProducts]
GO

CREATE PROCEDURE [dbo].[Proc_Takaful_GetProducts]
    @ProductCode  NVARCHAR(50)  = NULL,
    @VendorName   NVARCHAR(200) = NULL,
    @ProductType  NVARCHAR(50)  = NULL,
    @Status       NVARCHAR(10)  = NULL
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        SRNO, ProductCode, VendorName, ProductType, Rate,
        MakerID, MakerDate, CheckerID, CheckerDate, CheckerRemarks,
        [Status],
        CASE [Status]
            WHEN 'P' THEN 'Pending Approval'
            WHEN 'A' THEN 'Approved'
            WHEN 'R' THEN 'Rejected'
            ELSE [Status]
        END AS StatusDesc,
        CreatedBy_User, CreatedOn_Date, UpdatedBy_User, UpdatedOn_Date
    FROM [dbo].[Takaful_Product_Master]
    WHERE IsActive = 1
      AND (ISNULL(@ProductCode,'') = '' OR ProductCode LIKE '%' + @ProductCode + '%')
      AND (ISNULL(@VendorName,'') = '' OR VendorName LIKE '%' + @VendorName + '%')
      AND (ISNULL(@ProductType,'') = '' OR ProductType = @ProductType)
      AND (ISNULL(@Status,'') = '' OR [Status] = @Status)
    ORDER BY VendorName, ProductType
END
GO

-- =============================================
-- 2. Proc_Takaful_GetPendingForChecker
--    Pending items with comparison to current
--    approved rate in Takaful_Vendor_Master
-- =============================================
IF OBJECT_ID('[dbo].[Proc_Takaful_GetPendingForChecker]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_Takaful_GetPendingForChecker]
GO

CREATE PROCEDURE [dbo].[Proc_Takaful_GetPendingForChecker]
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        p.SRNO,
        p.ProductCode,
        p.VendorName,
        p.ProductType,
        p.Rate                     AS ProposedRate,
        p.MakerID,
        p.MakerDate,
        p.CreatedOn_Date,
        -- Current live rate in Takaful_Vendor_Master for comparison
        CASE p.ProductType
            WHEN 'GHP'   THEN vm.GHP_Rate
            WHEN 'Staff' THEN vm.Staff_Rate
            WHEN 'DIB'   THEN vm.DIB_Rate
            ELSE NULL
        END                        AS CurrentApprovedRate,
        CASE
            WHEN vm.VendorName IS NULL THEN 'NEW VENDOR'
            ELSE 'RATE CHANGE'
        END                        AS ChangeType
    FROM [dbo].[Takaful_Product_Master] p
    LEFT JOIN [dbo].[Takaful_Vendor_Master] vm
        ON vm.VendorName = p.VendorName
    WHERE p.[Status] = 'P'
      AND p.IsActive = 1
    ORDER BY p.MakerDate ASC
END
GO

-- =============================================
-- 3. Proc_Takaful_GetMySubmissions
--    Maker's own submissions (any status)
-- =============================================
IF OBJECT_ID('[dbo].[Proc_Takaful_GetMySubmissions]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_Takaful_GetMySubmissions]
GO

CREATE PROCEDURE [dbo].[Proc_Takaful_GetMySubmissions]
    @MakerID NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        SRNO, ProductCode, VendorName, ProductType, Rate,
        MakerID, MakerDate, CheckerID, CheckerDate, CheckerRemarks,
        [Status],
        CASE [Status]
            WHEN 'P' THEN 'Pending Approval'
            WHEN 'A' THEN 'Approved'
            WHEN 'R' THEN 'Rejected - can re-edit'
            ELSE [Status]
        END AS StatusDesc,
        CreatedOn_Date
    FROM [dbo].[Takaful_Product_Master]
    WHERE MakerID = @MakerID
      AND IsActive = 1
    ORDER BY CreatedOn_Date DESC
END
GO

-- =============================================
-- 4. Proc_Takaful_SaveProduct
--    Maker: create new or re-submit rejected
-- =============================================
IF OBJECT_ID('[dbo].[Proc_Takaful_SaveProduct]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_Takaful_SaveProduct]
GO

CREATE PROCEDURE [dbo].[Proc_Takaful_SaveProduct]
    @SRNO         INT           = 0,   -- 0 = new, >0 = update
    @ProductCode  NVARCHAR(50),
    @VendorName   NVARCHAR(200),
    @ProductType  NVARCHAR(50),
    @Rate         NUMERIC(18,10),
    @MakerID      NVARCHAR(100),
    @Status       NVARCHAR(50)  OUTPUT,
    @Message      NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    BEGIN TRY
    BEGIN TRANSACTION T_SAVE

        IF @SRNO = 0
        BEGIN
            -- Check duplicate ProductCode
            IF EXISTS (
                SELECT 1 FROM [dbo].[Takaful_Product_Master]
                WHERE ProductCode = @ProductCode AND IsActive = 1
            )
            BEGIN
                SET @Status  = 'FAILURE'
                SET @Message = 'Product Code ' + @ProductCode + ' already exists.'
                ROLLBACK TRANSACTION T_SAVE
                RETURN
            END

            INSERT INTO [dbo].[Takaful_Product_Master]
                (ProductCode, VendorName, ProductType, Rate,
                 MakerID, MakerDate, [Status],
                 CreatedBy_User, CreatedOn_Date, IsActive)
            VALUES
                (@ProductCode, @VendorName, @ProductType, @Rate,
                 @MakerID, GETDATE(), 'P',
                 @MakerID, GETDATE(), 1)

            DECLARE @NewSRNO INT = SCOPE_IDENTITY()

            INSERT INTO [dbo].[Takaful_Product_Master_History]
                (SRNO, ProductCode, VendorName, ProductType,
                 OldRate, NewRate, OldStatus, NewStatus,
                 ActionType, ActionBy, ActionDate, Remarks,
                 MakerID, MakerDate)
            VALUES
                (@NewSRNO, @ProductCode, @VendorName, @ProductType,
                 NULL, @Rate, NULL, 'P',
                 'CREATED', @MakerID, GETDATE(),
                 'New product submitted for checker approval',
                 @MakerID, GETDATE())

            SET @Status  = 'SUCCESS'
            SET @Message = 'Product ' + @ProductCode + ' submitted for checker approval.'
        END
        ELSE
        BEGIN
            DECLARE @OldRate   NUMERIC(18,10)
            DECLARE @OldStatus NVARCHAR(10)
            DECLARE @OldMaker  NVARCHAR(100)

            SELECT @OldRate = Rate, @OldStatus = [Status], @OldMaker = MakerID
            FROM [dbo].[Takaful_Product_Master]
            WHERE SRNO = @SRNO AND IsActive = 1

            IF @OldRate IS NULL
            BEGIN
                SET @Status  = 'FAILURE'
                SET @Message = 'Record not found (SRNO=' + CAST(@SRNO AS NVARCHAR(10)) + ').'
                ROLLBACK TRANSACTION T_SAVE
                RETURN
            END

            -- Only allow edit if status is Rejected or Pending (not Approved)
            IF @OldStatus = 'A'
            BEGIN
                SET @Status  = 'FAILURE'
                SET @Message = 'Approved records cannot be directly edited. Create a new product code.'
                ROLLBACK TRANSACTION T_SAVE
                RETURN
            END

            UPDATE [dbo].[Takaful_Product_Master]
            SET VendorName     = @VendorName,
                ProductType    = @ProductType,
                Rate           = @Rate,
                MakerID        = @MakerID,
                MakerDate      = GETDATE(),
                CheckerID      = NULL,
                CheckerDate    = NULL,
                CheckerRemarks = NULL,
                [Status]       = 'P',
                UpdatedBy_User = @MakerID,
                UpdatedOn_Date = GETDATE()
            WHERE SRNO = @SRNO

            INSERT INTO [dbo].[Takaful_Product_Master_History]
                (SRNO, ProductCode, VendorName, ProductType,
                 OldRate, NewRate, OldStatus, NewStatus,
                 ActionType, ActionBy, ActionDate, Remarks,
                 MakerID, MakerDate)
            VALUES
                (@SRNO, @ProductCode, @VendorName, @ProductType,
                 @OldRate, @Rate, @OldStatus, 'P',
                 'MODIFIED', @MakerID, GETDATE(),
                 'Product modified and re-submitted for checker approval',
                 @MakerID, GETDATE())

            SET @Status  = 'SUCCESS'
            SET @Message = 'Product ' + @ProductCode + ' updated and re-submitted for checker approval.'
        END

    COMMIT TRANSACTION T_SAVE
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_SAVE
        SET @Status  = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- =============================================
-- 5. Proc_Takaful_CheckerAction
--    Checker: Approve or Reject a pending record
--    On Approve: sync rate to Takaful_Vendor_Master
-- =============================================
IF OBJECT_ID('[dbo].[Proc_Takaful_CheckerAction]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_Takaful_CheckerAction]
GO

CREATE PROCEDURE [dbo].[Proc_Takaful_CheckerAction]
    @SRNO           INT,
    @Action         NVARCHAR(10),    -- 'APPROVE' or 'REJECT'
    @CheckerID      NVARCHAR(100),
    @CheckerRemarks NVARCHAR(500) = NULL,
    @Status         NVARCHAR(50)  OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @ProductCode  NVARCHAR(50)
    DECLARE @VendorName   NVARCHAR(200)
    DECLARE @ProductType  NVARCHAR(50)
    DECLARE @Rate         NUMERIC(18, 10)
    DECLARE @MakerID      NVARCHAR(100)
    DECLARE @MakerDate    DATETIME
    DECLARE @CurStatus    NVARCHAR(10)

    SELECT
        @ProductCode = ProductCode,
        @VendorName  = VendorName,
        @ProductType = ProductType,
        @Rate        = Rate,
        @MakerID     = MakerID,
        @MakerDate   = MakerDate,
        @CurStatus   = [Status]
    FROM [dbo].[Takaful_Product_Master]
    WHERE SRNO = @SRNO AND IsActive = 1

    IF @ProductCode IS NULL
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Record SRNO ' + CAST(@SRNO AS NVARCHAR(10)) + ' not found.'
        RETURN
    END

    IF @CurStatus <> 'P'
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Record is not in Pending status. Current status: ' + @CurStatus
        RETURN
    END

    -- Four-eyes principle: maker and checker must be different users
    IF UPPER(@MakerID) = UPPER(@CheckerID)
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Maker and Checker cannot be the same user (' + @MakerID + ').'
        RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_CHECKER

        IF @Action = 'APPROVE'
        BEGIN
            -- Update Product Master status
            UPDATE [dbo].[Takaful_Product_Master]
            SET [Status]       = 'A',
                CheckerID      = @CheckerID,
                CheckerDate    = GETDATE(),
                CheckerRemarks = @CheckerRemarks,
                UpdatedBy_User = @CheckerID,
                UpdatedOn_Date = GETDATE()
            WHERE SRNO = @SRNO

            -- Sync to Takaful_Vendor_Master (Table 1)
            IF EXISTS (SELECT 1 FROM [dbo].[Takaful_Vendor_Master] WHERE VendorName = @VendorName)
            BEGIN
                UPDATE [dbo].[Takaful_Vendor_Master]
                SET
                    GHP_Rate       = CASE WHEN @ProductType = 'GHP'   THEN @Rate ELSE GHP_Rate   END,
                    Staff_Rate     = CASE WHEN @ProductType = 'Staff' THEN @Rate ELSE Staff_Rate  END,
                    DIB_Rate       = CASE WHEN @ProductType = 'DIB'   THEN @Rate ELSE DIB_Rate    END,
                    UpdatedBy_User = @CheckerID,
                    UpdatedOn_date = GETDATE(),
                    [Status]       = 'A'
                WHERE VendorName = @VendorName
            END
            ELSE
            BEGIN
                -- New vendor: insert with the rate column that applies
                INSERT INTO [dbo].[Takaful_Vendor_Master]
                    (VendorName, GHP_Rate, Staff_Rate, DIB_Rate,
                     Createdby_User, Createdon_Date, UpdatedBy_User, UpdatedOn_date, [Status])
                VALUES (
                    @VendorName,
                    CASE WHEN @ProductType = 'GHP'   THEN @Rate ELSE NULL END,
                    CASE WHEN @ProductType = 'Staff' THEN @Rate ELSE NULL END,
                    CASE WHEN @ProductType = 'DIB'   THEN @Rate ELSE NULL END,
                    @CheckerID, GETDATE(), @CheckerID, GETDATE(), 'A'
                )
            END

            -- Audit history
            INSERT INTO [dbo].[Takaful_Product_Master_History]
                (SRNO, ProductCode, VendorName, ProductType,
                 OldRate, NewRate, OldStatus, NewStatus,
                 ActionType, ActionBy, ActionDate, Remarks,
                 MakerID, MakerDate, CheckerID, CheckerDate)
            VALUES
                (@SRNO, @ProductCode, @VendorName, @ProductType,
                 @Rate, @Rate, 'P', 'A',
                 'APPROVED', @CheckerID, GETDATE(), ISNULL(@CheckerRemarks, 'Approved'),
                 @MakerID, @MakerDate, @CheckerID, GETDATE())

            SET @Status  = 'SUCCESS'
            SET @Message = 'Product ' + @ProductCode + ' APPROVED. Takaful_Vendor_Master updated for: ' + @VendorName + ' (' + @ProductType + ').'
        END
        ELSE IF @Action = 'REJECT'
        BEGIN
            IF ISNULL(@CheckerRemarks, '') = ''
            BEGIN
                SET @Status  = 'FAILURE'
                SET @Message = 'Rejection remarks are mandatory.'
                ROLLBACK TRANSACTION T_CHECKER
                RETURN
            END

            UPDATE [dbo].[Takaful_Product_Master]
            SET [Status]       = 'R',
                CheckerID      = @CheckerID,
                CheckerDate    = GETDATE(),
                CheckerRemarks = @CheckerRemarks,
                UpdatedBy_User = @CheckerID,
                UpdatedOn_Date = GETDATE()
            WHERE SRNO = @SRNO

            INSERT INTO [dbo].[Takaful_Product_Master_History]
                (SRNO, ProductCode, VendorName, ProductType,
                 OldRate, NewRate, OldStatus, NewStatus,
                 ActionType, ActionBy, ActionDate, Remarks,
                 MakerID, MakerDate, CheckerID, CheckerDate)
            VALUES
                (@SRNO, @ProductCode, @VendorName, @ProductType,
                 @Rate, @Rate, 'P', 'R',
                 'REJECTED', @CheckerID, GETDATE(), @CheckerRemarks,
                 @MakerID, @MakerDate, @CheckerID, GETDATE())

            SET @Status  = 'SUCCESS'
            SET @Message = 'Product ' + @ProductCode + ' REJECTED. Reason: ' + @CheckerRemarks
        END
        ELSE
        BEGIN
            SET @Status  = 'FAILURE'
            SET @Message = 'Invalid action. Use APPROVE or REJECT.'
            ROLLBACK TRANSACTION T_CHECKER
            RETURN
        END

    COMMIT TRANSACTION T_CHECKER
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_CHECKER
        SET @Status  = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- =============================================
-- 6. Proc_Takaful_GetHistory
--    Full tracking history with optional filters
-- =============================================
IF OBJECT_ID('[dbo].[Proc_Takaful_GetHistory]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[Proc_Takaful_GetHistory]
GO

CREATE PROCEDURE [dbo].[Proc_Takaful_GetHistory]
    @ProductCode NVARCHAR(50)  = NULL,
    @VendorName  NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON

    SELECT TOP 500
        h.HistoryID,
        h.SRNO,
        h.ProductCode,
        h.VendorName,
        h.ProductType,
        h.OldRate,
        h.NewRate,
        CASE h.OldStatus WHEN 'P' THEN 'Pending' WHEN 'A' THEN 'Approved' WHEN 'R' THEN 'Rejected' ELSE ISNULL(h.OldStatus,'--') END AS OldStatusDesc,
        CASE h.NewStatus WHEN 'P' THEN 'Pending' WHEN 'A' THEN 'Approved' WHEN 'R' THEN 'Rejected' ELSE ISNULL(h.NewStatus,'--') END AS NewStatusDesc,
        h.ActionType,
        h.ActionBy,
        h.ActionDate,
        h.Remarks,
        h.MakerID,
        h.MakerDate,
        h.CheckerID,
        h.CheckerDate
    FROM [dbo].[Takaful_Product_Master_History] h
    WHERE (ISNULL(@ProductCode,'') = '' OR h.ProductCode LIKE '%' + @ProductCode + '%')
      AND (ISNULL(@VendorName,'') = '' OR h.VendorName LIKE '%' + @VendorName + '%')
    ORDER BY h.ActionDate DESC
END
GO

PRINT '== Script 08: Takaful Maker-Checker procedures created successfully. =='
GO
