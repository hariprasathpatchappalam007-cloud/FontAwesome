USE [LMS_DEV]
GO

-- =============================================
-- Bulk Postponement v2 schema upgrade
-- - Hold / Unhold request types (single-click Hold,
--   Unhold reverts dates AND status from snapshot)
-- - Multi-document upload table
-- =============================================

-- 1. Request header: RequestType + link back to source Hold
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BULK_POSTPONE_REQUEST]') AND name = 'RequestType')
BEGIN
    ALTER TABLE [dbo].[HF48_BULK_POSTPONE_REQUEST]
        ADD RequestType NVARCHAR(10) NULL  -- 'Hold' or 'Unhold'
END
GO

-- Back-fill v1 rows (they were all postponements = Hold)
UPDATE [dbo].[HF48_BULK_POSTPONE_REQUEST] SET RequestType = 'Hold' WHERE RequestType IS NULL
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BULK_POSTPONE_REQUEST]') AND name = 'SourceRequestID')
BEGIN
    ALTER TABLE [dbo].[HF48_BULK_POSTPONE_REQUEST]
        ADD SourceRequestID INT NULL  -- when RequestType='Unhold', points to the original Hold request
END
GO

-- 2. Request detail: snapshot status as well as date
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BULK_POSTPONE_DETAIL]') AND name = 'OldDisbStatus')
BEGIN
    ALTER TABLE [dbo].[HF48_BULK_POSTPONE_DETAIL]
        ADD OldDisbStatus NVARCHAR(30) NULL,
            NewDisbStatus NVARCHAR(30) NULL
END
GO

-- Back-fill v1 detail rows: original Hold flow shifted Not Disbursed -> Hold
UPDATE [dbo].[HF48_BULK_POSTPONE_DETAIL]
   SET OldDisbStatus = ISNULL(OldDisbStatus, 'Not Disbursed'),
       NewDisbStatus = ISNULL(NewDisbStatus, 'Hold')
 WHERE OldDisbStatus IS NULL OR NewDisbStatus IS NULL
GO

-- 3. Multi-document uploads (drag-drop)
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HF48_BULK_POSTPONE_DOCS]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[HF48_BULK_POSTPONE_DOCS]
    (
        DocID         INT IDENTITY(1,1) PRIMARY KEY,
        DraftID       NVARCHAR(50) NOT NULL,                   -- per-page GUID before submit
        RequestID     INT NULL,                                -- linked on Submit
        OriginalName  NVARCHAR(260) NOT NULL,
        StoredPath    NVARCHAR(500) NOT NULL,
        ContentType   NVARCHAR(100),
        SizeBytes     BIGINT,
        UploadedBy    NVARCHAR(100),
        UploadedOn    DATETIME NOT NULL DEFAULT GETDATE()
    )
    CREATE INDEX IX_HF48_BULK_POSTPONE_DOCS_Draft   ON [dbo].[HF48_BULK_POSTPONE_DOCS](DraftID)
    CREATE INDEX IX_HF48_BULK_POSTPONE_DOCS_Request ON [dbo].[HF48_BULK_POSTPONE_DOCS](RequestID)
END
GO

PRINT 'BulkPostpone v2 schema upgrade applied.'
GO
