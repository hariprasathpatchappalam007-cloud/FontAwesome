USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- v2 procs: replace v1 procs
-- Adds:
--  - lead_stage eligibility (END_OF_PROCESS, OPS_PMU, OPS_LODGMENT, OPS_LODGEMENT)
--  - AppRefNo + DisbStatus filters in Preview
--  - finance_amount, dev_tier, value_tranche, disbursed-to-date columns
--  - GroupIndex per APP_REF_NO for the UI colour bands
--  - RequestType branching (Hold / Unhold) with status snapshot
--  - GetActiveHolds for the Unhold picker
-- =============================================

-- ---------------------------------------------
-- Helper inline TVF: eligible lead stages
-- ---------------------------------------------
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fn_HF48_EligibleLeadStages]') AND type IN (N'IF',N'TF',N'FN'))
    DROP FUNCTION [dbo].[fn_HF48_EligibleLeadStages]
GO

CREATE FUNCTION [dbo].[fn_HF48_EligibleLeadStages]()
RETURNS TABLE
AS RETURN
(
    SELECT s.lead_stage FROM (VALUES
        ('END_OF_PROCESS'),
        ('OPS_PMU'),
        ('OPS_LODGMENT'),
        ('OPS_LODGEMENT')
    ) AS s(lead_stage)
)
GO

-- =============================================
-- Proc_HF48_BulkPostpone_GetProjects (v2)
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_GetProjects]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_GetProjects]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_GetProjects]
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        ldp.Property_ProjectID,
        MAX(ldp.Property_ProjectName)    AS Property_ProjectName,
        MAX(ldp.Property_DeveloperName)  AS Property_DeveloperName,
        MAX(ISNULL(ldm.dev_tier, 'Tier 2'))   AS dev_tier,
        MAX(ISNULL(lpm.value_tranche, 'No-Hold')) AS value_tranche,
        COUNT(DISTINCT ld.APP_REF_NO)    AS AppCount,
        SUM(CASE WHEN ISNULL(ldd.disb_status,'') = 'Hold' THEN 1 ELSE 0 END) AS HoldRows,
        SUM(CASE WHEN ISNULL(ldd.disb_status,'') = 'Not Disbursed' THEN 1 ELSE 0 END) AS PendingRows
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS_FINANCE ldf  ON ldd.lead_no = ldf.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldf.lead_no
    INNER JOIN LEAD_DETAILS ld           ON ld.lead_no  = ldf.lead_no
    INNER JOIN dbo.fn_HF48_EligibleLeadStages() els ON els.lead_stage = ld.lead_stage
    LEFT  JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName
    LEFT  JOIN lead_project lpm          ON lpm.PROJECTNAME   = ldp.Property_ProjectName
    WHERE ldf.LEAD_Product_ISTINSNA = 'HF48'
      AND ISNULL(ldd.Status,'') = 'A'
      AND ISNULL(ldd.disb_status,'') IN ('Hold','Not Disbursed')
    GROUP BY ldp.Property_ProjectID
    ORDER BY MAX(ldp.Property_ProjectName)
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_Preview (v2)
-- Returns one row per schedule line; the UI uses
-- GroupIndex (DENSE_RANK on APP_REF_NO) to colour-band
-- rows belonging to the same application.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_Preview]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_Preview]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_Preview]
    @Property_ProjectID NVARCHAR(50),
    @ShiftDays          INT          = 0,    -- 0 for plain Hold (no date change)
    @AppRefNo           NVARCHAR(50) = NULL, -- filter by Application ID
    @DisbStatus         NVARCHAR(30) = NULL  -- 'Disbursed' / 'Not Disbursed' / 'Hold' / NULL = all
AS
BEGIN
    SET NOCOUNT ON

    ;WITH src AS (
        SELECT
            ld.APP_REF_NO,
            ldd.Lead_No,
            ld.Customer_name,
            ld.lead_stage,
            ldd.Disb_Date                                 AS OldDisbDate,
            DATEADD(DAY, ISNULL(@ShiftDays,0), ldd.Disb_Date) AS NewDisbDate,
            ldd.Disb_amount,
            ldf.finance_amount,
            ISNULL(ldd.disb_status,'') AS disb_status,
            ldd.MilestonePaymentPct,
            ldd.PropertyPaymentPct,
            ldd.FinancePaymentPct,
            ldp.Property_ProjectID,
            ldp.Property_ProjectName,
            ldp.Property_DeveloperName,
            ISNULL(ldm.dev_tier,'Tier 2') AS dev_tier,
            ISNULL(lpm.value_tranche,'No-Hold') AS value_tranche
        FROM LEAD_DETAILS_DISB ldd
        INNER JOIN LEAD_DETAILS_FINANCE ldf  ON ldd.lead_no = ldf.lead_no
        INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldf.lead_no
        INNER JOIN LEAD_DETAILS ld           ON ld.lead_no  = ldf.lead_no
        INNER JOIN dbo.fn_HF48_EligibleLeadStages() els ON els.lead_stage = ld.lead_stage
        LEFT  JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName
        LEFT  JOIN lead_project lpm          ON lpm.PROJECTNAME   = ldp.Property_ProjectName
        WHERE ldf.LEAD_Product_ISTINSNA = 'HF48'
          AND ISNULL(ldd.Status,'') = 'A'
          AND ldp.Property_ProjectID = @Property_ProjectID
          AND (ISNULL(@AppRefNo,'')   = '' OR ld.APP_REF_NO LIKE '%' + @AppRefNo + '%')
          AND (ISNULL(@DisbStatus,'') = '' OR ISNULL(ldd.disb_status,'') = @DisbStatus)
    )
    SELECT
        s.*,
        DENSE_RANK() OVER (ORDER BY s.APP_REF_NO) AS GroupIndex,
        SUM(CASE WHEN s.disb_status = 'Disbursed' THEN s.Disb_amount ELSE 0 END)
            OVER (PARTITION BY s.APP_REF_NO) AS DisbursedToDate
    FROM src s
    ORDER BY s.APP_REF_NO, s.OldDisbDate
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_Submit (v2)
--  @RequestType    = 'Hold' | 'Unhold'
--  @ShiftDays      = forward shift in days (Hold only; ignored for Unhold)
--  @SourceRequestID= required for Unhold; references the approved Hold to be reverted
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_Submit]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_Submit]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_Submit]
    @RequestType        NVARCHAR(10),         -- 'Hold' | 'Unhold'
    @Property_ProjectID NVARCHAR(50)  = NULL,
    @ShiftDays          INT           = 0,
    @SourceRequestID    INT           = NULL,
    @Reason             NVARCHAR(1000),
    @MakerUser          NVARCHAR(100),
    @DraftID            NVARCHAR(50)  = NULL,
    @RequestID          INT           OUTPUT,
    @Status             NVARCHAR(50)  OUTPUT,
    @Message            NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON
    SET @RequestID = 0

    IF ISNULL(@Reason,'') = ''
    BEGIN
        SET @Status='FAILURE'; SET @Message='Reason is required.'; RETURN
    END

    IF @RequestType NOT IN ('Hold','Unhold')
    BEGIN
        SET @Status='FAILURE'; SET @Message='RequestType must be Hold or Unhold.'; RETURN
    END

    DECLARE @ProjectName  NVARCHAR(200), @DeveloperName NVARCHAR(200)
    DECLARE @Affected INT = 0, @Apps INT = 0

    BEGIN TRY
    BEGIN TRANSACTION T_BPSUB

    -- ---------------- HOLD ----------------
    IF @RequestType = 'Hold'
    BEGIN
        IF ISNULL(@Property_ProjectID,'') = ''
        BEGIN
            ROLLBACK TRANSACTION T_BPSUB
            SET @Status='FAILURE'; SET @Message='Project is required for Hold.'; RETURN
        END

        SELECT TOP 1
            @ProjectName   = ldp.Property_ProjectName,
            @DeveloperName = ldp.Property_DeveloperName
        FROM LEAD_DETAILS_Property ldp
        WHERE ldp.Property_ProjectID = @Property_ProjectID

        IF @ProjectName IS NULL
        BEGIN
            ROLLBACK TRANSACTION T_BPSUB
            SET @Status='FAILURE'; SET @Message='Project not found: ' + @Property_ProjectID; RETURN
        END

        INSERT INTO HF48_BULK_POSTPONE_REQUEST
            (RequestType, Property_ProjectID, Property_ProjectName, Property_DeveloperName,
             ShiftDays, Reason, Status, MakerUser)
        VALUES
            ('Hold', @Property_ProjectID, @ProjectName, @DeveloperName,
             ISNULL(@ShiftDays,0), @Reason, 'Pending Approval', @MakerUser)

        SET @RequestID = SCOPE_IDENTITY()

        ;WITH Pending AS (
            SELECT ld.APP_REF_NO, ldd.Lead_No, ld.Customer_name,
                   ldd.Disb_Date, ldd.Disb_amount, ldd.disb_status
            FROM LEAD_DETAILS_DISB ldd
            INNER JOIN LEAD_DETAILS_FINANCE ldf  ON ldd.lead_no = ldf.lead_no
            INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldf.lead_no
            INNER JOIN LEAD_DETAILS ld           ON ld.lead_no  = ldf.lead_no
            INNER JOIN dbo.fn_HF48_EligibleLeadStages() els ON els.lead_stage = ld.lead_stage
            WHERE ldf.LEAD_Product_ISTINSNA = 'HF48'
              AND ISNULL(ldd.Status,'') = 'A'
              AND ISNULL(ldd.disb_status,'') = 'Not Disbursed'   -- only flip non-disbursed; never touch Disbursed/already-Hold
              AND ldp.Property_ProjectID = @Property_ProjectID
        )
        INSERT INTO HF48_BULK_POSTPONE_DETAIL
            (RequestID, APP_REF_NO, Lead_No, Customer_Name,
             OldDisbDate, NewDisbDate, OldDisbStatus, NewDisbStatus,
             Disb_Amount, Disb_Status)
        SELECT
            @RequestID, APP_REF_NO, Lead_No, Customer_name,
            Disb_Date, DATEADD(DAY, ISNULL(@ShiftDays,0), Disb_Date),
            disb_status, 'Hold',
            Disb_amount, disb_status
        FROM Pending
    END

    -- ---------------- UNHOLD ----------------
    ELSE IF @RequestType = 'Unhold'
    BEGIN
        IF ISNULL(@SourceRequestID,0) = 0
        BEGIN
            ROLLBACK TRANSACTION T_BPSUB
            SET @Status='FAILURE'; SET @Message='SourceRequestID (the Hold to be released) is required for Unhold.'; RETURN
        END

        DECLARE @SrcStatus NVARCHAR(30), @SrcType NVARCHAR(10)
        SELECT @SrcStatus = Status, @SrcType = RequestType,
               @ProjectName = Property_ProjectName,
               @DeveloperName = Property_DeveloperName,
               @Property_ProjectID = Property_ProjectID
        FROM HF48_BULK_POSTPONE_REQUEST
        WHERE RequestID = @SourceRequestID

        IF @SrcStatus IS NULL
        BEGIN
            ROLLBACK TRANSACTION T_BPSUB
            SET @Status='FAILURE'; SET @Message='Source request not found.'; RETURN
        END
        IF @SrcType <> 'Hold' OR @SrcStatus <> 'Approved'
        BEGIN
            ROLLBACK TRANSACTION T_BPSUB
            SET @Status='FAILURE'; SET @Message='Source must be an Approved Hold request.'; RETURN
        END
        IF EXISTS (SELECT 1 FROM HF48_BULK_POSTPONE_REQUEST
                    WHERE SourceRequestID = @SourceRequestID
                      AND Status IN ('Pending Approval','Approved'))
        BEGIN
            ROLLBACK TRANSACTION T_BPSUB
            SET @Status='FAILURE'; SET @Message='An Unhold for this Hold is already pending or applied.'; RETURN
        END

        INSERT INTO HF48_BULK_POSTPONE_REQUEST
            (RequestType, Property_ProjectID, Property_ProjectName, Property_DeveloperName,
             ShiftDays, Reason, Status, MakerUser, SourceRequestID)
        VALUES
            ('Unhold', @Property_ProjectID, @ProjectName, @DeveloperName,
             0, @Reason, 'Pending Approval', @MakerUser, @SourceRequestID)

        SET @RequestID = SCOPE_IDENTITY()

        -- Snapshot the reverse: take the SOURCE hold's NewDisbDate as the
        -- current "Old", and the SOURCE hold's OldDisbDate as the new target.
        INSERT INTO HF48_BULK_POSTPONE_DETAIL
            (RequestID, APP_REF_NO, Lead_No, Customer_Name,
             OldDisbDate, NewDisbDate, OldDisbStatus, NewDisbStatus,
             Disb_Amount, Disb_Status)
        SELECT
            @RequestID, src.APP_REF_NO, src.Lead_No, src.Customer_Name,
            src.NewDisbDate, src.OldDisbDate,         -- revert dates
            src.NewDisbStatus, src.OldDisbStatus,     -- revert status (back to 'Not Disbursed')
            src.Disb_Amount, src.NewDisbStatus
        FROM HF48_BULK_POSTPONE_DETAIL src
        WHERE src.RequestID = @SourceRequestID
          AND src.Applied = 1
    END

    -- ---------------- common: link uploaded docs and finalise counters ----
    IF ISNULL(@DraftID,'') <> ''
    BEGIN
        UPDATE HF48_BULK_POSTPONE_DOCS
           SET RequestID = @RequestID
         WHERE DraftID = @DraftID AND RequestID IS NULL
    END

    SELECT @Affected = COUNT(*),
           @Apps     = COUNT(DISTINCT APP_REF_NO)
    FROM HF48_BULK_POSTPONE_DETAIL WHERE RequestID = @RequestID

    IF @Affected = 0
    BEGIN
        ROLLBACK TRANSACTION T_BPSUB
        SET @RequestID = 0
        SET @Status='FAILURE'
        SET @Message = CASE @RequestType
                         WHEN 'Hold' THEN 'No eligible "Not Disbursed" schedules found for this project.'
                         ELSE 'Source Hold has no applied detail rows to revert.'
                       END
        RETURN
    END

    UPDATE HF48_BULK_POSTPONE_REQUEST
       SET AffectedRowCount = @Affected,
           AffectedAppCount = @Apps
     WHERE RequestID = @RequestID

    INSERT INTO HF48_DISB_AUDIT_LOG
        (APP_REF_NO, Lead_No, Disb_Date, ActionType, ActionResult, CreatedBy, Remarks)
    VALUES
        ('BULK#' + CONVERT(VARCHAR(10), @RequestID), @ProjectName, GETDATE(),
         'BulkPostpone-' + @RequestType + '-Submitted',
         'Request #' + CONVERT(VARCHAR(10), @RequestID) + ' submitted: ' +
            CONVERT(VARCHAR(10), @Apps) + ' app(s), ' +
            CONVERT(VARCHAR(10), @Affected) + ' schedule(s)' +
            CASE WHEN @RequestType='Hold' AND ISNULL(@ShiftDays,0) > 0
                 THEN ', shift +' + CONVERT(VARCHAR(10), @ShiftDays) + 'd'
                 ELSE '' END,
         @MakerUser, @Reason)

    COMMIT TRANSACTION T_BPSUB

    SET @Status  = 'SUCCESS'
    SET @Message = @RequestType + ' request #' + CONVERT(VARCHAR(10), @RequestID) +
                   ' submitted for Checker approval (' +
                   CONVERT(VARCHAR(10), @Apps) + ' application(s), ' +
                   CONVERT(VARCHAR(10), @Affected) + ' schedule row(s)).'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_BPSUB
        SET @RequestID = 0
        SET @Status='FAILURE'
        SET @Message = 'Submit failed: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_Approve (v2)
-- Same code path applies to Hold and Unhold:
-- snapshot rows already encode NewDisbDate + NewDisbStatus.
-- For Unhold approvals we additionally mark the source Hold as 'Released'.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_Approve]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_Approve]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_Approve]
    @RequestID      INT,
    @CheckerUser    NVARCHAR(100),
    @CheckerRemarks NVARCHAR(1000) = NULL,
    @Status         NVARCHAR(50)  OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @MakerUser NVARCHAR(100), @ReqStatus NVARCHAR(30), @ReqType NVARCHAR(10)
    DECLARE @ShiftDays INT, @ProjectName NVARCHAR(200), @SourceID INT
    DECLARE @AppliedRows INT

    SELECT @MakerUser = MakerUser, @ReqStatus = Status, @ReqType = RequestType,
           @ShiftDays = ShiftDays, @ProjectName = Property_ProjectName,
           @SourceID = SourceRequestID
    FROM HF48_BULK_POSTPONE_REQUEST
    WHERE RequestID = @RequestID

    IF @MakerUser IS NULL
    BEGIN
        SET @Status='FAILURE'; SET @Message='Request not found: ' + CONVERT(VARCHAR(10), @RequestID); RETURN
    END
    IF @ReqStatus <> 'Pending Approval'
    BEGIN
        SET @Status='FAILURE'; SET @Message='Request is in status "' + @ReqStatus + '" and cannot be approved.'; RETURN
    END
    IF UPPER(LTRIM(RTRIM(@MakerUser))) = UPPER(LTRIM(RTRIM(ISNULL(@CheckerUser,''))))
    BEGIN
        SET @Status='FAILURE'; SET @Message='Maker-Checker violation: the Maker (' + @MakerUser + ') cannot approve their own request.'; RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_BPAPP

        -- Apply both date AND status from the snapshot.
        -- Hold: target rows have current status 'Not Disbursed' (verbatim guard).
        -- Unhold: target rows have current status 'Hold'.
        UPDATE ldd
           SET ldd.Disb_Date   = d.NewDisbDate,
               ldd.disb_status = d.NewDisbStatus
        FROM LEAD_DETAILS_DISB ldd
        INNER JOIN HF48_BULK_POSTPONE_DETAIL d
                ON d.Lead_No     = ldd.Lead_No
               AND d.OldDisbDate = ldd.Disb_Date
        WHERE d.RequestID = @RequestID
          AND ISNULL(ldd.Status,'') = 'A'
          AND ISNULL(ldd.disb_status,'') = d.OldDisbStatus  -- "no changes during hold/postponement": only flip rows that still match the snapshot

        SET @AppliedRows = @@ROWCOUNT

        UPDATE HF48_BULK_POSTPONE_DETAIL
           SET Applied = 1, AppliedOn = GETDATE()
         WHERE RequestID = @RequestID

        UPDATE HF48_BULK_POSTPONE_REQUEST
           SET Status = 'Approved',
               CheckerUser = @CheckerUser,
               CheckerOn = GETDATE(),
               CheckerRemarks = @CheckerRemarks
         WHERE RequestID = @RequestID

        -- For Unhold: mark the source Hold as 'Released' so it disappears from
        -- the Active-Holds picker and can't be unheld twice.
        IF @ReqType = 'Unhold' AND @SourceID IS NOT NULL
        BEGIN
            UPDATE HF48_BULK_POSTPONE_REQUEST
               SET Status = 'Released'
             WHERE RequestID = @SourceID
        END

        INSERT INTO HF48_DISB_AUDIT_LOG
            (APP_REF_NO, Lead_No, Disb_Date, DaysBefore,
             ActionType, ActionResult, CreatedBy, Remarks)
        SELECT
            d.APP_REF_NO, d.Lead_No, d.NewDisbDate, ISNULL(@ShiftDays,0),
            'BulkPostpone-' + @ReqType + '-Approved',
            'Disb_Date ' + CONVERT(VARCHAR(10), d.OldDisbDate, 103) + ' -> ' +
            CONVERT(VARCHAR(10), d.NewDisbDate, 103) +
            ' / status ' + ISNULL(d.OldDisbStatus,'') + ' -> ' + ISNULL(d.NewDisbStatus,'') +
            ' (Request #' + CONVERT(VARCHAR(10), @RequestID) + ')',
            @CheckerUser,
            'Project: ' + @ProjectName +
                ' / Maker: ' + @MakerUser +
                ISNULL(' / Checker remarks: ' + @CheckerRemarks, '')
        FROM HF48_BULK_POSTPONE_DETAIL d
        WHERE d.RequestID = @RequestID

    COMMIT TRANSACTION T_BPAPP

    SET @Status  = 'SUCCESS'
    SET @Message = @ReqType + ' request #' + CONVERT(VARCHAR(10), @RequestID) +
                   ' approved. ' + CONVERT(VARCHAR(10), @AppliedRows) +
                   ' schedule row(s) updated.'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_BPAPP
        SET @Status='FAILURE'
        SET @Message = 'Approve failed: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- Reject proc unchanged from v1 in shape, but recreate so deployment is one file.
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_Reject]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_Reject]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_Reject]
    @RequestID      INT,
    @CheckerUser    NVARCHAR(100),
    @CheckerRemarks NVARCHAR(1000),
    @Status         NVARCHAR(50)  OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    IF ISNULL(@CheckerRemarks,'') = ''
    BEGIN
        SET @Status='FAILURE'; SET @Message='Rejection requires Checker remarks.'; RETURN
    END

    DECLARE @MakerUser NVARCHAR(100), @ReqStatus NVARCHAR(30), @ReqType NVARCHAR(10)
    DECLARE @ProjectName NVARCHAR(200)

    SELECT @MakerUser = MakerUser, @ReqStatus = Status, @ReqType = RequestType,
           @ProjectName = Property_ProjectName
    FROM HF48_BULK_POSTPONE_REQUEST
    WHERE RequestID = @RequestID

    IF @MakerUser IS NULL
    BEGIN
        SET @Status='FAILURE'; SET @Message='Request not found.'; RETURN
    END
    IF @ReqStatus <> 'Pending Approval'
    BEGIN
        SET @Status='FAILURE'; SET @Message='Request is in status "' + @ReqStatus + '" and cannot be rejected.'; RETURN
    END
    IF UPPER(LTRIM(RTRIM(@MakerUser))) = UPPER(LTRIM(RTRIM(ISNULL(@CheckerUser,''))))
    BEGIN
        SET @Status='FAILURE'; SET @Message='Maker-Checker violation: the Maker cannot reject their own request.'; RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_BPREJ

        UPDATE HF48_BULK_POSTPONE_REQUEST
           SET Status = 'Rejected',
               CheckerUser = @CheckerUser,
               CheckerOn = GETDATE(),
               CheckerRemarks = @CheckerRemarks
         WHERE RequestID = @RequestID

        INSERT INTO HF48_DISB_AUDIT_LOG
            (APP_REF_NO, Lead_No, Disb_Date, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES
            ('BULK#' + CONVERT(VARCHAR(10), @RequestID), @ProjectName, GETDATE(),
             'BulkPostpone-' + ISNULL(@ReqType,'Hold') + '-Rejected',
             'Request #' + CONVERT(VARCHAR(10), @RequestID) + ' rejected by Checker.',
             @CheckerUser,
             'Maker: ' + @MakerUser + ' / Checker remarks: ' + @CheckerRemarks)

    COMMIT TRANSACTION T_BPREJ

    SET @Status='SUCCESS'
    SET @Message = ISNULL(@ReqType,'Request') + ' #' + CONVERT(VARCHAR(10), @RequestID) + ' rejected.'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_BPREJ
        SET @Status='FAILURE'
        SET @Message = 'Reject failed: ' + ERROR_MESSAGE()
    END CATCH
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_GetRequests (v2)
--   exposes RequestType + SourceRequestID
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_GetRequests]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_GetRequests]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_GetRequests]
    @Status NVARCHAR(30) = NULL
AS
BEGIN
    SET NOCOUNT ON

    SELECT TOP 200
        RequestID, RequestType, SourceRequestID,
        Property_ProjectID, Property_ProjectName, Property_DeveloperName,
        ShiftDays, Reason, Status, AffectedAppCount, AffectedRowCount,
        MakerUser, MakerOn, CheckerUser, CheckerOn, CheckerRemarks
    FROM HF48_BULK_POSTPONE_REQUEST
    WHERE (ISNULL(@Status,'') = '' OR Status = @Status)
    ORDER BY MakerOn DESC
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_GetRequestDetail (v2)
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_GetRequestDetail]
    @RequestID INT
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        d.DetailID, d.RequestID, d.APP_REF_NO, d.Lead_No, d.Customer_Name,
        d.OldDisbDate, d.NewDisbDate, d.OldDisbStatus, d.NewDisbStatus,
        d.Disb_Amount, d.Disb_Status, d.Applied, d.AppliedOn,
        DENSE_RANK() OVER (ORDER BY d.APP_REF_NO) AS GroupIndex
    FROM HF48_BULK_POSTPONE_DETAIL d
    WHERE d.RequestID = @RequestID
    ORDER BY d.APP_REF_NO, d.OldDisbDate
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_GetActiveHolds
--   Approved Hold requests not yet released — feeds Unhold picker.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_GetActiveHolds]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_GetActiveHolds]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_GetActiveHolds]
AS
BEGIN
    SET NOCOUNT ON

    SELECT
        r.RequestID, r.Property_ProjectID, r.Property_ProjectName,
        r.Property_DeveloperName, r.ShiftDays, r.AffectedAppCount, r.AffectedRowCount,
        r.MakerUser, r.MakerOn, r.CheckerUser, r.CheckerOn
    FROM HF48_BULK_POSTPONE_REQUEST r
    WHERE r.RequestType = 'Hold'
      AND r.Status = 'Approved'
      AND NOT EXISTS (
            SELECT 1 FROM HF48_BULK_POSTPONE_REQUEST u
            WHERE u.RequestType = 'Unhold'
              AND u.SourceRequestID = r.RequestID
              AND u.Status IN ('Pending Approval','Approved')
      )
    ORDER BY r.CheckerOn DESC
END
GO

-- =============================================
-- Proc_HF48_BulkPostpone_GetDocs
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_GetDocs]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_GetDocs]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_GetDocs]
    @DraftID    NVARCHAR(50) = NULL,
    @RequestID  INT          = NULL
AS
BEGIN
    SET NOCOUNT ON
    SELECT DocID, DraftID, RequestID, OriginalName, StoredPath, ContentType,
           SizeBytes, UploadedBy, UploadedOn
    FROM HF48_BULK_POSTPONE_DOCS
    WHERE (@RequestID IS NOT NULL AND RequestID = @RequestID)
       OR (@RequestID IS NULL AND ISNULL(@DraftID,'') <> '' AND DraftID = @DraftID)
    ORDER BY UploadedOn ASC
END
GO

PRINT 'BulkPostpone v2 procs created.'
GO
