USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_Manual_Trigger
-- Allows manual re-triggering of notifications 
-- and service ticket creation on any day
-- Called from the ASP.NET Web Forms interface
-- =============================================
CREATE PROC [dbo].[Proc_HF48_Manual_Trigger]
    @APP_REF_NO NVARCHAR(50),
    @Lead_No NVARCHAR(50),
    @Disb_Date DATETIME,
    @ActionType NVARCHAR(50),  -- 'SendNotification' or 'CreateServiceTicket'
    @NotificationType NVARCHAR(50) = NULL, -- '60-Day','30-Day','10-Day' (for SendNotification)
    @UserID NVARCHAR(100),
    @Remarks NVARCHAR(MAX) = NULL,
    @Status NVARCHAR(50) OUTPUT,
    @Message NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @MAIL_TO NVARCHAR(1000)
    DECLARE @MAIL_CC NVARCHAR(1000)
    DECLARE @MAIL_SUBJECT NVARCHAR(500)
    DECLARE @MAIL_BODY NVARCHAR(MAX)
    DECLARE @EvalTeamEmail NVARCHAR(500)
    DECLARE @EnggTeamEmail NVARCHAR(500)
    DECLARE @OpsTeamEmail NVARCHAR(500)
    DECLARE @CLMTeamEmail NVARCHAR(500)
    DECLARE @TaskID INT

    DECLARE @Customer_Name NVARCHAR(200)
    DECLARE @DeveloperName NVARCHAR(200)
    DECLARE @ProjectName NVARCHAR(200)
    DECLARE @Disb_Amount DECIMAL(18,2)
    DECLARE @DevTier NVARCHAR(50)
    DECLARE @DisbStatus NVARCHAR(10)
    DECLARE @MilestonePaymentPct DECIMAL(18,2)
    DECLARE @PropertyPaymentPct DECIMAL(18,2)
    DECLARE @FinancePaymentPct DECIMAL(18,2)
    DECLARE @DaysRemaining INT

    -- Fetch distribution emails
    SELECT @EvalTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam'
    SELECT @EnggTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EngineeringTeam'
    SELECT @OpsTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam'
    SELECT @CLMTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam'

    -- Get application details
    SELECT 
        @Customer_Name = ld.Customer_name,
        @DeveloperName = ldp.Property_DeveloperName,
        @ProjectName = ldp.Property_ProjectName,
        @Disb_Amount = ldd.Disb_amount,
        @DisbStatus = ldd.Status,
        @MilestonePaymentPct = ldd.MilestonePaymentPct,
        @PropertyPaymentPct = ldd.PropertyPaymentPct,
        @FinancePaymentPct = ldd.FinancePaymentPct,
        @DevTier = ISNULL(ldm.dev_tier, 'Tier 2')
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS ld ON ld.lead_no = ldd.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldd.lead_no
    LEFT JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName
    WHERE ld.APP_REF_NO = @APP_REF_NO 
      AND ldd.Lead_No = @Lead_No
      AND ldd.Disb_Date = @Disb_Date

    IF @Customer_Name IS NULL
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Disbursement record not found for App: ' + @APP_REF_NO + ', Lead: ' + @Lead_No
        RETURN
    END

    SET @DaysRemaining = DATEDIFF(DAY, GETDATE(), @Disb_Date)

    BEGIN TRY
    BEGIN TRANSACTION T_MANUAL

        -- =============================================
        -- Manual Notification
        -- =============================================
        IF @ActionType = 'SendNotification'
        BEGIN
            -- Determine recipients based on notification type
            IF @NotificationType IN ('60-Day', '30-Day')
            BEGIN
                SET @MAIL_TO = @EvalTeamEmail
                SET @MAIL_CC = ''
            END
            ELSE IF @NotificationType = '10-Day'
            BEGIN
                SET @MAIL_TO = @EnggTeamEmail
                SET @MAIL_CC = @OpsTeamEmail
            END
            ELSE
            BEGIN
                SET @MAIL_TO = @EvalTeamEmail
                SET @MAIL_CC = @OpsTeamEmail
            END

            SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Manual ' + ISNULL(@NotificationType,'') + ' Notification (Triggered by ' + @UserID + ')'

            SET @MAIL_BODY = 'Dear Team,<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'This is a <b>manually triggered</b> ' + ISNULL(@NotificationType,'') + ' pre-disbursement notification.<br>'
            SET @MAIL_BODY = @MAIL_BODY + '<i>Actual days remaining: ' + CONVERT(VARCHAR(10), @DaysRemaining) + '</i><br><br>'
            SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#FF6600><td colspan=2><font color=white><b>Manual Notification - Disbursement Details</b></font></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + ' (' + ISNULL(@DevTier,'') + ')</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Milestone %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@MilestonePaymentPct,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Property Payment %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@PropertyPaymentPct,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Finance Payment %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@FinancePaymentPct,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Days Remaining</font></td><td>' + CONVERT(VARCHAR(10), @DaysRemaining) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#FF6600 valign=top><font color=white><b>Triggered By</b></font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'Manual trigger') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

            INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
            VALUES (@APP_REF_NO, 'N', 'HF48 Manual Notification', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

            -- Audit Log
            INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysRemaining,
                    'Manual-Notification (' + ISNULL(@NotificationType,'') + ')',
                    'Manual notification sent. Actual days remaining: ' + CONVERT(VARCHAR(10), @DaysRemaining),
                    @MAIL_TO + CASE WHEN ISNULL(@MAIL_CC,'') <> '' THEN ';CC:' + @MAIL_CC ELSE '' END,
                    @UserID,
                    ISNULL(@Remarks, 'Manual notification trigger'))

            SET @Status = 'SUCCESS'
            SET @Message = 'Manual ' + ISNULL(@NotificationType,'') + ' notification sent successfully.'
        END

        -- =============================================
        -- Manual Service Ticket Creation
        -- =============================================
        ELSE IF @ActionType = 'CreateServiceTicket'
        BEGIN
            INSERT INTO HF48_DISB_TASKS (APP_REF_NO, Lead_No, Disb_Date, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, 'CLM Service Ticket', 'CLM Team', 'Operations Team', 'Open', @UserID,
                    'Manually created service ticket. ' + ISNULL(@Remarks,''))

            SET @TaskID = SCOPE_IDENTITY()

            -- Notify all teams
            SET @MAIL_TO = @OpsTeamEmail
            SET @MAIL_CC = @EvalTeamEmail + ';' + @CLMTeamEmail
            SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Manual Service Ticket Created (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

            SET @MAIL_BODY = 'Dear Team,<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'A CLM Service Ticket has been <b>manually created</b> by ' + ISNULL(@UserID,'') + '.<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#FF6600><td colspan=2><font color=white><b>Manual Service Ticket</b></font></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Assigned To</font></td><td>Operations Team (CLM)</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#FF6600 valign=top><font color=white><b>Created By</b></font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'Manual service ticket') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

            INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
            VALUES (@APP_REF_NO, 'N', 'HF48 Manual Service Ticket', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

            -- Audit Log
            INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysRemaining,
                    'Manual-ServiceTicket',
                    'Manual service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' created.',
                    @MAIL_TO + ';CC:' + @MAIL_CC,
                    @UserID,
                    ISNULL(@Remarks, 'Manual service ticket creation'))

            SET @Status = 'SUCCESS'
            SET @Message = 'Service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' created successfully. Notifications sent.'
        END
        ELSE
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Invalid ActionType. Use SendNotification or CreateServiceTicket.'
            IF @@TRANCOUNT > 0
                ROLLBACK TRANSACTION T_MANUAL
            RETURN
        END

    COMMIT TRANSACTION T_MANUAL
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION T_MANUAL

        SET @Status = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()

        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                'Manual Trigger ERROR',
                'Error during manual trigger',
                @UserID,
                'Error: ' + ERROR_MESSAGE())
    END CATCH
END
GO

PRINT 'Proc_HF48_Manual_Trigger created successfully.'
GO
