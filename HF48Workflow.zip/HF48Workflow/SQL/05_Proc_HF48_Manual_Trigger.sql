USE [LMS_DEV]
GO
/****** Object:  StoredProcedure [dbo].[Proc_HF48_Manual_Trigger]    Script Date: 16/07/2026 8:58:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_Manual_Trigger
-- Allows manual re-triggering of notifications 
-- and service ticket creation on any day
-- Called from the ASP.NET Web Forms interface
-- =============================================
ALTER PROC [dbo].[Proc_HF48_Manual_Trigger]
    @APP_REF_NO NVARCHAR(50),
    @Lead_No NVARCHAR(50),
    @Disb_Date DATETIME,
    @ActionType NVARCHAR(50),  -- 'SendNotification' or 'CreateServiceTicket'
    @NotificationType NVARCHAR(50) = NULL, -- '60-Day','30-Day','10-Day' (for SendNotification)
    @UserID NVARCHAR(100),
    @Remarks NVARCHAR(MAX) = NULL,
    @Status NVARCHAR(50) OUTPUT,
    @Message NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @MAIL_TO NVARCHAR(1000)
    DECLARE @MAIL_CC NVARCHAR(1000)
    DECLARE @MAIL_SUBJECT NVARCHAR(500)
    DECLARE @MAIL_BODY NVARCHAR(MAX)
    DECLARE @EvalTeamEmail NVARCHAR(500)
    DECLARE @EnggTeamEmail NVARCHAR(500)
    DECLARE @OpsTeamEmail NVARCHAR(500)
    DECLARE @CLMTeamEmail NVARCHAR(500)
    DECLARE @TaskID INT

    DECLARE @Customer_Name NVARCHAR(200)
    DECLARE @DeveloperName NVARCHAR(200)
    DECLARE @ProjectName NVARCHAR(200)
    DECLARE @Disb_Amount DECIMAL(18,2)
    DECLARE @DevTier NVARCHAR(50)
    DECLARE @DisbStatus NVARCHAR(10)
    DECLARE @MilestonePaymentPct DECIMAL(18,2)
    DECLARE @PropertyPaymentPct DECIMAL(18,2)
    DECLARE @FinancePaymentPct DECIMAL(18,2)
    DECLARE @DaysRemaining INT

 DECLARE @reccount numeric(20)
 DECLARE @Case_RefNo varchar(50)
 Declare @Disb_SrNo int
 DECLARE @ExistingSRNo INT = NULL
 DECLARE @ExistingCaseRefNo NVARCHAR(50) = NULL

    -- Fetch distribution emails
    SELECT @EvalTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam'
    SELECT @EnggTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EngineeringTeam'
    SELECT @OpsTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam'
    SELECT @CLMTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam'

    -- Get application details
    SELECT 
        @Customer_Name = ld.Customer_name,
        @DeveloperName = ldp.Property_DeveloperName,
        @ProjectName = ldp.Property_ProjectName,
        @Disb_Amount = ldd.Disb_amount,
        @DisbStatus = ldd.Status,
        @MilestonePaymentPct = ldd.MilestonePaymentPct,
        @PropertyPaymentPct = ldd.PropertyPaymentPct,
        @FinancePaymentPct = ldd.FinancePaymentPct,
        @DevTier = ISNULL(ldm.dev_tier, ''),
  @Disb_SrNo = ldd.disb_srno
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS ld ON ld.lead_no = ldd.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldd.lead_no
    LEFT JOIN LEAD_DEVELOPER_MASTER ldm ON ldm.DeveloperName = ldp.Property_DeveloperName
    WHERE ld.APP_REF_NO = @APP_REF_NO 
      AND ldd.Lead_No = @Lead_No
      AND ldd.Disb_Date = @Disb_Date

    IF @Customer_Name IS NULL
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Disbursement record not found for App: ' + @APP_REF_NO + ', Lead: ' + @Lead_No
        RETURN
    END

    SET @DaysRemaining = DATEDIFF(DAY, GETDATE(), @Disb_Date)

    BEGIN TRY
    BEGIN TRANSACTION T_MANUAL

        -- =============================================
        -- Manual Notification
        -- =============================================
        IF @ActionType = 'SendNotification'
        BEGIN
            -- Determine recipients based on notification type
            IF @NotificationType IN ('60-Day', '30-Day')
            BEGIN
                SET @MAIL_TO = @EvalTeamEmail
                SET @MAIL_CC = ''
            END
            ELSE IF @NotificationType = '5-Day'
            BEGIN
                SET @MAIL_TO = @EnggTeamEmail
                SET @MAIL_CC = @OpsTeamEmail
            END
            ELSE
            BEGIN
                SET @MAIL_TO = @EvalTeamEmail
                SET @MAIL_CC = @OpsTeamEmail
            END

            SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Manual ' + ISNULL(@NotificationType,'') + ' Notification (Triggered by ' + @UserID + ')'

            SET @MAIL_BODY = 'Dear Team,

'
            SET @MAIL_BODY = @MAIL_BODY + 'This is a <b>manually triggered</b> ' + ISNULL(@NotificationType,'') + ' pre-disbursement notification.
'
            SET @MAIL_BODY = @MAIL_BODY + '<i>Actual days remaining: ' + CONVERT(VARCHAR(10), @DaysRemaining) + '</i>

'
            SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#FF6600><td colspan=2><font color=white><b>Manual Notification - Disbursement Details</b></font></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + ' (' + ISNULL(@DevTier,'') + ')</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Milestone %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@MilestonePaymentPct,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Property Payment %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@PropertyPaymentPct,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Finance Payment %</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@FinancePaymentPct,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Days Remaining</font></td><td>' + CONVERT(VARCHAR(10), @DaysRemaining) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#FF6600 valign=top><font color=white><b>Triggered By</b></font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'Manual trigger') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '</table>
'
            SET @MAIL_BODY = @MAIL_BODY + 'Regards,
HF48 Automated Monitoring System'

            INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
            VALUES (@APP_REF_NO, 'N', 'HF48 Manual Notification', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

            -- Audit Log
            INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysRemaining,
                    'Manual-Notification (' + ISNULL(@NotificationType,'') + ')',
                    'Manual notification sent. Actual days remaining: ' + CONVERT(VARCHAR(10), @DaysRemaining),
                    @MAIL_TO + CASE WHEN ISNULL(@MAIL_CC,'') <> '' THEN ';CC:' + @MAIL_CC ELSE '' END,
                    @UserID,
                    ISNULL(@Remarks, 'Manual notification trigger'))

            SET @Status = 'SUCCESS'
            SET @Message = 'Manual ' + ISNULL(@NotificationType,'') + ' notification sent successfully.'
        END

        -- =============================================
        -- Manual Service Ticket Creation
        -- =============================================
        ELSE IF @ActionType = 'CreateCLMTicket'
        BEGIN
   -- Open-ticket guard: only create a new CLM ticket if there is no existing
   -- open ticket (not Closed) for this application in FRM_SERVICE_REQUEST
   SET @ExistingSRNo = NULL
   SELECT TOP 1 @ExistingSRNo = SRNO
   FROM FRM_SERVICE_REQUEST
   WHERE APPLICATIONID = @APP_REF_NO
     AND ISNULL(STATUS,'') <> 'C'
   ORDER BY SRNO DESC

   IF @ExistingSRNo IS NOT NULL
   BEGIN
    SET @Status = 'FAILURE'
    SET @Message = 'An open CLM ticket already exists for application ' + @APP_REF_NO + ' (SRNO=' + CONVERT(NVARCHAR(20), @ExistingSRNo) + '). A new ticket will not be created until it is closed.'
   END
   ELSE
   if (isnull(@DevTier,'') = 'Tier 1' or isnull(@DevTier,'') = 'Tier 2') 
   begin
    DECLARE @USERNAME NVARCHAR(100),@cas_stage nvarchar(50) =NULL,
       @Current_Stage nvarchar(50) =NULL,
       @Next_Stage nvarchar(50) =NULL,
       @Current_Assigned_User nvarchar(100) =NULL,
       @Next_assigned_User nvarchar(100) =NULL,
       @Changed_Datetime datetime =NULL,
       @TAT_Datetime datetime =NULL,
       @TAT_StartTime datetime =NULL,
       @cas_workflow nvarchar(50) =NULL,
       @agentAllocationUser NVARCHAR(100)=NULL,
       @SRECCOUNT int,
       @CUSTID NVARCHAR(100)=NULL,
       @CUSTNAME NVARCHAR(100)=NULL,            
       @MOBILENO NVARCHAR(100)=NULL,
       @EMAILID NVARCHAR(100)=NULL,            
       @REMARKS_ NVARCHAR(100)=NULL,
       @Service_Source nvarchar(100)='0',
       @Service_Charge nvarchar(100)='0.00',
       @PaymentMode nvarchar(100)='0',
       @CO_ENDDATE nvarchar(50) =NULL,
       @Decline_Reason nvarchar(max) =NULL,
       @FILENAME NVARCHAR(200)=NULL
        
    SET @SRECCOUNT = 0              
    SELECT @SRECCOUNT=max(srno) FROM FRM_SERVICE_REQUEST            
    SET @SRECCOUNT = ISNULL(@SRECCOUNT,0) + 1


    INSERT INTO HF48_DISB_TASKS (APP_REF_NO, Lead_No, Disb_Date,Case_RefNo, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks,disb_srno)
                        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date,@SRECCOUNT, 'CLM Service Ticket', 'CLM Team', 'Operations Team', 'Open', @UserID,
                                'Manually created service ticket. ' + ISNULL(@Remarks,''),@Disb_SrNo)
      
    --INSERT INTO HF48_DISB_TASKS (APP_REF_NO, Lead_No, Disb_Date, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks)
    --VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, 'CLM Service Ticket', 'CLM Team', 'Operations Team', 'Open', @UserID,
    --  'Manually created service ticket. ' + ISNULL(@Remarks,''))

    SET @TaskID = SCOPE_IDENTITY()

    -- Raquib work >> HF48 >> Phase 2 -- Total 3 places to created the CLM ticket
      If IsNull(@APP_REF_NO,'') <> ''
      Begin
           declare @CATEGORY_ NVARCHAR(100)='MBRE /  SZHP / self construction'
        declare @SUBCATEGORY_ NVARCHAR(100)='Milestone Payment'
        declare @IsretainCoolingOff nvarchar(5)='N'
        declare @Service_Department nvarchar(100)=null
        declare @allocationType nvarchar(100)
        declare @allocationuser nvarchar(100)
        DECLARE @Is_Email_Trigger nvarchar(10)
        DECLARE @Is_Sms_Trigger nvarchar(10)
        declare @WF_Code  nvarchar(50) =NULL
        declare @USERID1 nvarchar(50) = isnull(@UserID, 'SYSTEM')

        select @Service_Department = Service_Department,@allocationType=AllocationType,@allocationuser=OPS_MAKER_USER
       ,@Is_Email_Trigger = ISNULL(Is_Email_Trigger,'Y'),@Is_Sms_Trigger = ISNULL(Is_Sms_Trigger,'Y')
       ,@WF_Code = WF_Code
       from FRM_SERVICE_SUBCATEGORY_MASTER where SubCategory_Cat_Code = @CATEGORY_ and subcategory_code = @SUBCATEGORY_
       ---------------------------------

       SELECT @CUSTID=isnull(A.CUSTOMERID,''), @CUSTNAME=isnull(C.CUSTOMERNAME1,''),
       @MOBILENO=c.MOBILENUMBER,  @EMAILID=ISNULL(C.PERSONAL_EMAIL,A.PERSONAL_EMAIL)     
       FROM CORE_FLEX_ALL_APPS_MASTER A    
       left join Core_Customer_Details C on C.CUSTOMERID=A.CUSTOMERID        
       LEFT JOIN CORE_APPLICATION_DETAILS B  ON  B.APPLICATION_ID like '%' + A.APPLICATIONID + '%'         
       WHERE 1=1 AND A.APPLICATIONID like '%'+ @APP_REF_NO +'%' 

       if (isnull(@CUSTID,'')='' and isnull(@CUSTNAME,'')='')
       begin
        SELECT @CUSTID=isnull(A.CUSTOMERID, b.customerID), @CUSTNAME=isnull(A.CUSTOMER_NAME,B.Customer_Name),
        @MOBILENO=CAse When isnull(A.Mobile_Code,'')<>'' and isnull(A.Mobile_No,'')<>'' then A.mobile_code + A.Mobile_no
          else isnull(B.Customer_Mob_Code,'') + isnull(B.Customer_mob_no,'') end,
         @EMAILID=B.CUSTOMER_EMAIL_P 
        FROM Lead_details A    
        LEFT JOIN Lead_details_customer B  ON  A.Lead_no = B.Lead_no 
        WHERE 1=1 AND A.App_ref_no = @APP_REF_NO
       end

       if @allocationType = 'To User'
       begin
            set @USERNAME = @allocationuser 
         set @cas_stage = 'CLM_UPDATE';
         set @Next_Stage = 'END_OF_PROCESS'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();
       end
       else if @allocationType = 'To Workflow'
       begin
        set @USERNAME = CASE @allocationuser WHEN '' THEN @USERID1 ELSE ISNULL(@allocationuser,@USERID1) END
        set @cas_workflow = @WF_Code;
        if @WF_Code = 'CLM_RC_END' OR @WF_Code = 'CLM_RC_OPS_END' OR @WF_Code = 'CLM_RC_OPS_PMU_END'
        begin
         set @cas_stage = 'CAS_HELP_DESK';
         set @Next_Stage = 'CAS_LEVEL_6'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();
        end    
        else if @WF_Code = 'CLM_OPS_END'
        begin
         set @cas_stage = 'CAS_OPS_MAKER'
         set @Next_Stage = 'CAS_OPS_MAKER'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();
         declare @USRECCOUNT int=0
         select @USRECCOUNT=COUNT(1) from FRM_USERROLE where USER_ROLE = 'CAS_OPS_MAKER' and user_userid = @USERNAME
         IF ISNULL(@USRECCOUNT,0)=0
         BEGIN
          SET @USERNAME=NULL
          SET @cas_stage='CAS_OPS_HELP_DESK'
         END
        end
        else 
        begin
         set @cas_stage = 'CLM_UPDATE';
         set @Next_Stage = 'END_OF_PROCESS'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();

         IF( EXISTS( SELECT 1 from FRM_SERVICE_SUBCATEGORY_MASTER where SubCategory_Cat_Code = @CATEGORY_ and subcategory_code = @SUBCATEGORY_ AND IsRetention=1))    
         BEGIN
          IF( EXISTS( select 1 from FRM_GNARR where Value = @USERID1 and CODE = 'CAS_RETENTION'))                                     
            begin
             set @agentAllocationUser = @USERID1
            end 
          ELSE
          BEGIN
           select TOP 1 @agentAllocationUser=A.Value from FRM_GNARR A
           LEFT OUTER JOIN
           FRM_REQUEST_ALLOCATION_USERLIST B
           ON A.Value=B.USERID AND B.SYSTEM_NAME='Retention'
           where  A.Code='CAS_RETENTION' AND ISNULL(A.STATUS,'A')='A' ORDER BY ISNULL(B.LastAssignDate,DATEADD(YEAR,-2,GETDATE())) ASC

           IF( EXISTS( SELECT 1 from FRM_REQUEST_ALLOCATION_USERLIST WHERE SYSTEM_NAME='Retention' AND USERID=@agentAllocationUser))    
           BEGIN
            UPDATE FRM_REQUEST_ALLOCATION_USERLIST SET LastAssignDate=GETDATE() WHERE SYSTEM_NAME='Retention' AND USERID=@agentAllocationUser
           END
           ELSE
           BEGIN
            INSERT INTO FRM_REQUEST_ALLOCATION_USERLIST(
            SYSTEM_NAME
           ,USERID
           ,Status
           ,LastAssignDate
             )
              VALUES ('Retention',@agentAllocationUser,'A',GETDATE())
           END
           END
         END
         ELSE
         SET @agentAllocationUser= NULL
        End    
       end
       else
        begin
         set @cas_stage = 'CLM';
         set @Next_Stage = 'CLM_UPDATE'
         set @TAT_StartTime = GETDATE();
         set @TAT_Datetime = GETDATE();

        if isnull(@Service_Department,'0') <> '0'
        begin
    
         select @SRECCOUNT = count(1) from FRM_REQUEST_ALLOCATION_USERLIST  
         where userid = @USERID1 and isnull(status,'A') = 'A' and SYSTEM_NAME = 'Customer Service' AND DepartmentName = @Service_Department
     
         if @SRECCOUNT > 0 and @Service_Department = 'Customer Service'
          set @USERNAME = @USERID1
         else
          select top 1 @USERNAME = userid from FRM_REQUEST_ALLOCATION_USERLIST 
          where SYSTEM_NAME = 'Customer Service' AND DepartmentName = @Service_Department and isnull(status,'A') = 'A' order by isnull(LastAssignDate,'01/01/1900')
     
         update FRM_REQUEST_ALLOCATION_USERLIST set LastAssignDate= getdate() 
         where system_name = 'Customer Service' and DepartmentName = @Service_Department and USERID = @USERNAME
      
        end
        else
        begin
         select top 1 @USERNAME = userid from FRM_REQUEST_ALLOCATION_USERLIST 
         where SYSTEM_NAME = 'Customer Service' and isnull(status,'A') = 'A' order by isnull(LastAssignDate,getdate())

         update FRM_REQUEST_ALLOCATION_USERLIST set LastAssignDate= getdate() 
         where system_name = 'Customer Service' and USERID = @USERNAME
        end
       end
       
       SET @agentAllocationUser=ISNULL(@agentAllocationUser,@USERID1)
            
       INSERT INTO FRM_SERVICE_REQUEST            
       (            
        SRNO,APPLICATIONID,CUSTID,CUSTOMERNAME,            
        MOBILENO,EMAILID,CATEGORY,SUBCATEGORY,            
        REMARKS,STATUS,CREATEDBY_USER,CREATEDON_DATE,ASSIGNED_TO,
        service_source,Service_Charge,Service_Department,PaymentMode,
        Assigned_Department,IsCoolingOff,CO_StartDate,CO_EndDate
        ,cas_workflow,cas_stage
        ,Agent_AssignedTo,cas_assignedTo
  
       )            
       VALUES            
       (            
        @SRECCOUNT,@APP_REF_NO,@CUSTID,@CUSTNAME,            
        @MOBILENO,@EMAILID,@CATEGORY_,@SUBCATEGORY_,            
        @REMARKS_,'N',@USERID1,GETDATE(),CASE @cas_Stage WHEN 'CAS_HELP_DESK' THEN '0' ELSE @USERNAME END ,-- Changed by rajesh kumar(17/05/2023)
        @Service_Source,convert(numeric(20,2),@Service_Charge),@Service_Department,@PaymentMode,
        @Service_Department,@IsretainCoolingOff,GETDATE(),@CO_ENDDATE,
        @cas_workflow,@cas_Stage
        ,@agentAllocationUser,CASE @cas_Stage WHEN 'CAS_HELP_DESK' THEN '0' ELSE ISNULL(@allocationuser,@USERID1) END --added by rajesh kumar (08/06/2023)
       )   
   
       if @WF_Code = 'CLM_RC_END' OR @WF_Code = 'CLM_RC_OPS_END' OR @WF_Code = 'CLM_OPS_END' OR @WF_Code = 'CLM_RC_OPS_PMU_END'
       begin
        INSERT INTO FRM_SERVICE_REQUEST_HISTORY            
        (SRNO,APPLICATIONID,CREATEDBY_USER,CREATEDON_DATE,REMARKS,STATUS,FILE_NAMES,
        Current_Stage,Next_Stage,Current_Assigned_User,Next_assigned_User,Changed_Datetime,TAT_Datetime,Time_Taken,TAT_StartTime,DECLINE_REASON) --Added by Sandip for Credit after sales
        VALUES(@SRECCOUNT,@APP_REF_NO,@USERID1,GETDATE(),@REMARKS_,'IP',@FILENAME,'CLM',@cas_stage,@USERID1,NULL,getdate(),@TAT_Datetime, DATEDIFF(MI,@TAT_StartTime,@TAT_Datetime),@TAT_StartTime,@DECLINE_REASON)
       END
       ELSE
       BEGIN
        INSERT INTO FRM_SERVICE_REQUEST_HISTORY            
        (SRNO,APPLICATIONID,CREATEDBY_USER,CREATEDON_DATE,REMARKS,STATUS,FILE_NAMES,
        Current_Stage,Next_Stage,Current_Assigned_User,Next_assigned_User,Changed_Datetime,TAT_Datetime,Time_Taken,TAT_StartTime,DECLINE_REASON) --Added by Sandip for Credit after sales
           
        VALUES       
        (@SRECCOUNT,@APP_REF_NO,@USERID1,GETDATE(),@REMARKS_,'N',@FILENAME,
        'CLM',@cas_stage
        ,@USERID1,NULL,getdate(),@TAT_Datetime, DATEDIFF(MI,@TAT_StartTime,@TAT_Datetime),@TAT_StartTime,@DECLINE_REASON
        )
       END 

       ---------------------------------------------------------------------------------------------------------------------------
      END

    -- Notify all teams
    SET @MAIL_TO = @OpsTeamEmail
    SET @MAIL_CC = @EvalTeamEmail + ';' + @CLMTeamEmail
    SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Manual Service Ticket Created (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

    SET @MAIL_BODY = 'Dear Team,

'
    SET @MAIL_BODY = @MAIL_BODY + 'A CLM Service Ticket has been <b>manually created</b> by ' + ISNULL(@UserID,'') + '.

'
    SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#FF6600><td colspan=2><font color=white><b>Manual Service Ticket</b></font></td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Assigned To</font></td><td>Operations Team (CLM)</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#FF6600 valign=top><font color=white><b>Created By</b></font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'Manual service ticket') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '</table>
'
    SET @MAIL_BODY = @MAIL_BODY + 'Regards,
HF48 Automated Monitoring System'

    INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
    VALUES (@APP_REF_NO, 'N', 'HF48 Manual Service Ticket', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

    -- Audit Log
    INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysRemaining,
      'Manual-ServiceTicket',
      'Manual service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' created.',
      @MAIL_TO + ';CC:' + @MAIL_CC,
      @UserID,
      ISNULL(@Remarks, 'Manual service ticket creation'))

    SET @Status = 'SUCCESS'
    SET @Message = 'Service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' created successfully. Notifications sent.'
   end
   else
    SET @Message = 'This application dev_tier value is not Tier 1, please check the dev_tier value!'
        END
  ELSE IF @ActionType = 'CreateENGTicket'
        BEGIN
   -- Open-ticket guard: only create a new Engineering ticket if there is no
   -- existing open ticket (not Closed) for this application in ENG_HLP_CASES
   SET @ExistingCaseRefNo = NULL
   SELECT TOP 1 @ExistingCaseRefNo = Case_RefNo
   FROM ENG_HLP_CASES
   WHERE Case_AppID = @APP_REF_NO
     AND ISNULL(Case_Status,'') <> 'C'
   ORDER BY Case_RefNo DESC

   IF @ExistingCaseRefNo IS NOT NULL
   BEGIN
    SET @Status = 'FAILURE'
    SET @Message = 'An open Engineering ticket already exists for application ' + @APP_REF_NO + ' (Case Ref No=' + @ExistingCaseRefNo + '). A new ticket will not be created until it is closed.'
   END
   ELSE
   if (isnull(@DevTier,'') = 'Tier 2')
   begin
    select @reccount = count(1) from ENG_HLP_CASES where convert(nvarchar(10),CreatedOn_Date,103) =  convert(nvarchar(10),getdate(),103)
    set @reccount = @reccount + 1
    --select @reccount
    set @Case_RefNo= replace(convert(varchar(30),getdate(),102),'.','') + convert(varchar(10),@reccount)

    INSERT INTO HF48_DISB_TASKS (APP_REF_NO, Lead_No, Disb_Date,Case_RefNo, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks,disb_srno)
    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date,@Case_RefNo ,'Engineering Task', 'Engineering Team', 'Engineering Team', 'Open', @UserID,
      'Manual created engineering ticket.'+ ISNULL(@Remarks,''), @Disb_SrNo)

    --INSERT INTO HF48_DISB_TASKS (APP_REF_NO, Lead_No, Disb_Date, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks)
    --VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, 'CLM Service Ticket', 'CLM Team', 'Operations Team', 'Open', @UserID,
    --        'Manually created service ticket. ' + ISNULL(@Remarks,''))

    SET @TaskID = SCOPE_IDENTITY()

    insert into ENG_HLP_CASES (Case_RefNo,
             Case_CustID,
             Case_CustName,
             Case_AppID,
             Case_TelNo,
             Case_MobNo,
             Case_Email,
             Case_SDesc,
             Case_Status,
             Case_AssignedUser,
             Createdby_User,
             Createdon_Date,
             Case_user_Status,
             Case_filename,
             Case_category,
             Case_subcategory,
             USERNAME,
             InitialedBY_USER,
             case_User_Location)
      values(@Case_RefNo,null,@Customer_Name,@APP_REF_NO,null,null,null,
      '30-day pre-disbursement task for engineering review.',
      'O','COMMON-NEW','SYSTEM',GETDATE(),'O',null,'4','Milestone / Progress Verification','SYSTEM','SYSTEM','TAMWEEL_AUD')

    -- Notify all teams
    SET @MAIL_TO = @EnggTeamEmail
    SET @MAIL_CC = @OpsTeamEmail 
    SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Manual Service Ticket Created (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

    SET @MAIL_BODY = 'Dear Team,

'
    SET @MAIL_BODY = @MAIL_BODY + 'A Engineering Ticket has been <b>manually created</b> by ' + ISNULL(@UserID,'') + '.

'
    SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#FF6600><td colspan=2><font color=white><b>Manual Engineering Ticket</b></font></td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Assigned To</font></td><td>Engineering Team (CLM)</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#FF6600 valign=top><font color=white><b>Created By</b></font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'Manual service ticket') + '</td></tr>'
    SET @MAIL_BODY = @MAIL_BODY + '</table>
'
    SET @MAIL_BODY = @MAIL_BODY + 'Regards,
HF48 Automated Monitoring System'

    INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
    VALUES (@APP_REF_NO, 'N', 'HF48 Manual Service Ticket', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

    -- Audit Log
    INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
    VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, @DaysRemaining,
      'Manual-ServiceTicket',
      'Manual service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' created.',
      @MAIL_TO + ';CC:' + @MAIL_CC,
      @UserID,
      ISNULL(@Remarks, 'Manual service ticket creation'))

    SET @Status = 'SUCCESS'
    SET @Message = 'Service ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' created successfully. Notifications sent.'
   end
   else
    SET @Message = 'This application dev_tier value is not Tier 2, please check the dev_tier value!'
        END
        ELSE
        BEGIN
            SET @Status = 'FAILURE'
            SET @Message = 'Invalid ActionType. Use SendNotification or CreateServiceTicket.'
            IF @@TRANCOUNT > 0
                ROLLBACK TRANSACTION T_MANUAL
            RETURN
        END

    COMMIT TRANSACTION T_MANUAL
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION T_MANUAL

        SET @Status = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()

        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                'Manual Trigger ERROR',
                'Error during manual trigger',
                @UserID,
                'Error: ' + ERROR_MESSAGE())
    END CATCH
END
 