USE [LMS_DEV]
GO

-- =============================================
-- Script 07: Takaful Product Master (Table 2)
-- Product-level table with Maker-Checker support
-- Syncs approved rates back to Takaful_Vendor_Master (Table 1)
-- =============================================

-- =============================================
-- 1. Takaful_Product_Master (Table 2)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Takaful_Product_Master]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[Takaful_Product_Master]
    (
        SRNO            INT IDENTITY(1,1)   NOT NULL,
        ProductCode     NVARCHAR(50)        NOT NULL,
        VendorName      NVARCHAR(200)       NULL,
        ProductType     NVARCHAR(50)        NULL,   -- DIB, Staff, GHP, SZHP
        Rate            NUMERIC(18, 10)     NULL,

        -- Maker fields
        MakerID         NVARCHAR(100)       NULL,
        MakerDate       DATETIME            NULL,

        -- Checker fields
        CheckerID       NVARCHAR(100)       NULL,
        CheckerDate     DATETIME            NULL,
        CheckerRemarks  NVARCHAR(500)       NULL,

        -- Status: P=Pending, A=Approved, R=Rejected
        [Status]        NVARCHAR(10)        NULL    DEFAULT 'P',

        -- Standard audit
        CreatedBy_User  NVARCHAR(100)       NULL,
        CreatedOn_Date  DATETIME            NULL    DEFAULT GETDATE(),
        UpdatedBy_User  NVARCHAR(100)       NULL,
        UpdatedOn_Date  DATETIME            NULL,

        IsActive        BIT                 NOT NULL DEFAULT 1,

        CONSTRAINT PK_Takaful_Product_Master PRIMARY KEY CLUSTERED (SRNO ASC)
    )
    PRINT 'Table Takaful_Product_Master created.'
END
ELSE
    PRINT 'Table Takaful_Product_Master already exists - skipped.'
GO

-- =============================================
-- 2. Takaful_Product_Master_History (full audit trail)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Takaful_Product_Master_History]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[Takaful_Product_Master_History]
    (
        HistoryID       INT IDENTITY(1,1)   NOT NULL,
        SRNO            INT                 NULL,   -- FK to parent record
        ProductCode     NVARCHAR(50)        NULL,
        VendorName      NVARCHAR(200)       NULL,
        ProductType     NVARCHAR(50)        NULL,
        OldRate         NUMERIC(18, 10)     NULL,
        NewRate         NUMERIC(18, 10)     NULL,
        OldStatus       NVARCHAR(10)        NULL,
        NewStatus       NVARCHAR(10)        NULL,
        -- ActionType: CREATED, MODIFIED, APPROVED, REJECTED, DEACTIVATED
        ActionType      NVARCHAR(50)        NULL,
        ActionBy        NVARCHAR(100)       NULL,
        ActionDate      DATETIME            NULL    DEFAULT GETDATE(),
        Remarks         NVARCHAR(500)       NULL,
        MakerID         NVARCHAR(100)       NULL,
        MakerDate       DATETIME            NULL,
        CheckerID       NVARCHAR(100)       NULL,
        CheckerDate     DATETIME            NULL,

        CONSTRAINT PK_Takaful_Product_Master_History PRIMARY KEY CLUSTERED (HistoryID ASC)
    )
    PRINT 'Table Takaful_Product_Master_History created.'
END
ELSE
    PRINT 'Table Takaful_Product_Master_History already exists - skipped.'
GO

---- =============================================
---- 3. Insert Script: Seed Table 2 from Table 2 CSV
---- Initial load marked as Approved (Status='A')
---- =============================================
--IF NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[Takaful_Product_Master])
--BEGIN
--    INSERT INTO [dbo].[Takaful_Product_Master]
--        (ProductCode, VendorName, ProductType, Rate,
--         MakerID, MakerDate, CheckerID, CheckerDate,
--         [Status], CreatedBy_User, CreatedOn_Date, IsActive)
--    VALUES
--        ('Tkfl001', 'DIB - Salama Takaful Group cover', 'DIB',   0.0001849000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl002', 'DIB - Salama Takaful Group cover', 'Staff', 0.0001849000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl003', 'DIB - Salama Takaful Group cover', 'GHP',   0.0001849000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl004', 'Sukoon Takaful Group Cover',        'DIB',   0.0001899000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl005', 'Sukoon Takaful Group Cover',        'Staff', 0.0001899000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl006', 'Sukoon Takaful Group Cover',        'GHP',   0.0001899000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl007', 'Watania Takaful Group Cover',       'DIB',   0.0001850000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl008', 'Watania Takaful Group Cover',       'Staff', 0.0001850000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl009', 'Watania Takaful Group Cover',       'GHP',   0.0001850000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
--        ('Tkfl010', 'Sukoon Takaful Group Cover',        'SZHP',  0.0002920000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1)

--    PRINT 'Takaful_Product_Master seeded with 10 records.'
--END
--ELSE
--    PRINT 'Takaful_Product_Master already has data - seed skipped.'
--GO

--PRINT '== Script 07 completed successfully. =='
--GO

-- =============================================
-- 4. ALTER: Add ApplicantType column
--    Run this migration on an existing database
-- =============================================
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[Takaful_Product_Master]') AND name = 'ApplicantType'
)
BEGIN
    ALTER TABLE [dbo].[Takaful_Product_Master]
        ADD ApplicantType NVARCHAR(50) NULL
    PRINT 'Column ApplicantType added to Takaful_Product_Master.'
END
ELSE
    PRINT 'Column ApplicantType already exists in Takaful_Product_Master - skipped.'
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID(N'[dbo].[Takaful_Product_Master_History]') AND name = 'ApplicantType'
)
BEGIN
    ALTER TABLE [dbo].[Takaful_Product_Master_History]
        ADD ApplicantType NVARCHAR(50) NULL
    PRINT 'Column ApplicantType added to Takaful_Product_Master_History.'
END
ELSE
    PRINT 'Column ApplicantType already exists in Takaful_Product_Master_History - skipped.'
GO

-- =============================================
-- 5. MIGRATION: Set existing rows as Primary
--    and fix rate format (* 100 : 0.0001849 -> 0.01849)
-- =============================================
UPDATE [dbo].[Takaful_Product_Master]
SET ApplicantType = 'Primary',
    Rate          = Rate * 100   -- convert stored 0.0001849 to display format 0.01849
WHERE ApplicantType IS NULL
  AND IsActive = 1
PRINT 'Existing rows updated to ApplicantType=Primary and rate corrected.'
GO

-- =============================================
-- 6. REVISED INSERT SCRIPT  (reflects Table2.csv)
--    30 rows — each row has its own unique ProductCode
--    Tkfl001-Tkfl030 (one per Vendor+Type+ApplicantType)
--
--    SAFE TO RUN: skips rows where ProductCode already exists
-- =============================================
DECLARE @sys NVARCHAR(50) = 'SYSTEM'
DECLARE @now DATETIME     = GETDATE()

;WITH NewRows (ProductCode, VendorName, ProductType, ApplicantType, Rate) AS
(
    -- DIB - Salama Takaful Group cover (Tkfl001-Tkfl009)
    SELECT 'Tkfl001', 'DIB - Salama Takaful Group cover', 'DIB',   'Primary',      0.01849 UNION ALL
    SELECT 'Tkfl002', 'DIB - Salama Takaful Group cover', 'DIB',   'Co-applicant', 0.01849 UNION ALL
    SELECT 'Tkfl003', 'DIB - Salama Takaful Group cover', 'DIB',   'Co-borrower',  0.01849 UNION ALL
    SELECT 'Tkfl004', 'DIB - Salama Takaful Group cover', 'Staff', 'Primary',      0.01849 UNION ALL
    SELECT 'Tkfl005', 'DIB - Salama Takaful Group cover', 'Staff', 'Co-applicant', 0.01849 UNION ALL
    SELECT 'Tkfl006', 'DIB - Salama Takaful Group cover', 'Staff', 'Co-borrower',  0.01849 UNION ALL
    SELECT 'Tkfl007', 'DIB - Salama Takaful Group cover', 'GHP',   'Primary',      0.01849 UNION ALL
    SELECT 'Tkfl008', 'DIB - Salama Takaful Group cover', 'GHP',   'Co-applicant', 0.01849 UNION ALL
    SELECT 'Tkfl009', 'DIB - Salama Takaful Group cover', 'GHP',   'Co-borrower',  0.01849 UNION ALL
    -- Sukoon Takaful Group Cover — DIB/Staff/GHP (Tkfl010-Tkfl018)
    SELECT 'Tkfl010', 'Sukoon Takaful Group Cover', 'DIB',   'Primary',      0.01899 UNION ALL
    SELECT 'Tkfl011', 'Sukoon Takaful Group Cover', 'DIB',   'Co-applicant', 0.01899 UNION ALL
    SELECT 'Tkfl012', 'Sukoon Takaful Group Cover', 'DIB',   'Co-borrower',  0.01899 UNION ALL
    SELECT 'Tkfl013', 'Sukoon Takaful Group Cover', 'Staff', 'Primary',      0.01899 UNION ALL
    SELECT 'Tkfl014', 'Sukoon Takaful Group Cover', 'Staff', 'Co-applicant', 0.01899 UNION ALL
    SELECT 'Tkfl015', 'Sukoon Takaful Group Cover', 'Staff', 'Co-borrower',  0.01899 UNION ALL
    SELECT 'Tkfl016', 'Sukoon Takaful Group Cover', 'GHP',   'Primary',      0.01899 UNION ALL
    SELECT 'Tkfl017', 'Sukoon Takaful Group Cover', 'GHP',   'Co-applicant', 0.01899 UNION ALL
    SELECT 'Tkfl018', 'Sukoon Takaful Group Cover', 'GHP',   'Co-borrower',  0.01899 UNION ALL
    -- Watania Takaful Group Cover (Tkfl019-Tkfl027) — Co-applicant/Co-borrower at lower rate
    SELECT 'Tkfl019', 'Watania Takaful Group Cover', 'DIB',   'Primary',      0.0185 UNION ALL
    SELECT 'Tkfl020', 'Watania Takaful Group Cover', 'DIB',   'Co-applicant', 0.0148 UNION ALL
    SELECT 'Tkfl021', 'Watania Takaful Group Cover', 'DIB',   'Co-borrower',  0.0148 UNION ALL
    SELECT 'Tkfl022', 'Watania Takaful Group Cover', 'Staff', 'Primary',      0.0185 UNION ALL
    SELECT 'Tkfl023', 'Watania Takaful Group Cover', 'Staff', 'Co-applicant', 0.0148 UNION ALL
    SELECT 'Tkfl024', 'Watania Takaful Group Cover', 'Staff', 'Co-borrower',  0.0148 UNION ALL
    SELECT 'Tkfl025', 'Watania Takaful Group Cover', 'GHP',   'Primary',      0.0185 UNION ALL
    SELECT 'Tkfl026', 'Watania Takaful Group Cover', 'GHP',   'Co-applicant', 0.0148 UNION ALL
    SELECT 'Tkfl027', 'Watania Takaful Group Cover', 'GHP',   'Co-borrower',  0.0148 UNION ALL
    -- Sukoon Takaful Group Cover — SZHP (Tkfl028-Tkfl030)
    SELECT 'Tkfl028', 'Sukoon Takaful Group Cover', 'SZHP', 'Primary',      0.0292 UNION ALL
    SELECT 'Tkfl029', 'Sukoon Takaful Group Cover', 'SZHP', 'Co-applicant', 0.0292 UNION ALL
    SELECT 'Tkfl030', 'Sukoon Takaful Group Cover', 'SZHP', 'Co-borrower',  0.0292
)
INSERT INTO [dbo].[Takaful_Product_Master]
    (ProductCode, VendorName, ProductType, ApplicantType, Rate,
     MakerID, MakerDate, CheckerID, CheckerDate,
     [Status], CreatedBy_User, CreatedOn_Date, IsActive)
SELECT
    n.ProductCode, n.VendorName, n.ProductType, n.ApplicantType, n.Rate,
    @sys, @now, @sys, @now, 'A', @sys, @now, 1
FROM NewRows n
WHERE NOT EXISTS (
    SELECT 1 FROM [dbo].[Takaful_Product_Master]
    WHERE ProductCode = n.ProductCode AND IsActive = 1
)
PRINT 'Takaful_Product_Master revised seed completed (Tkfl001-Tkfl030).'
GO

PRINT '== Script 07 migration and seed completed successfully. =='
GO
