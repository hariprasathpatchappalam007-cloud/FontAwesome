USE [LMS_DEV]
GO

-- =============================================
-- Script 07: Takaful Product Master (Table 2)
-- Product-level table with Maker-Checker support
-- Syncs approved rates back to Takaful_Vendor_Master (Table 1)
-- =============================================

-- =============================================
-- 1. Takaful_Product_Master (Table 2)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Takaful_Product_Master]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[Takaful_Product_Master]
    (
        SRNO            INT IDENTITY(1,1)   NOT NULL,
        ProductCode     NVARCHAR(50)        NOT NULL,
        VendorName      NVARCHAR(200)       NULL,
        ProductType     NVARCHAR(50)        NULL,   -- DIB, Staff, GHP, SZHP
        Rate            NUMERIC(18, 10)     NULL,

        -- Maker fields
        MakerID         NVARCHAR(100)       NULL,
        MakerDate       DATETIME            NULL,

        -- Checker fields
        CheckerID       NVARCHAR(100)       NULL,
        CheckerDate     DATETIME            NULL,
        CheckerRemarks  NVARCHAR(500)       NULL,

        -- Status: P=Pending, A=Approved, R=Rejected
        [Status]        NVARCHAR(10)        NULL    DEFAULT 'P',

        -- Standard audit
        CreatedBy_User  NVARCHAR(100)       NULL,
        CreatedOn_Date  DATETIME            NULL    DEFAULT GETDATE(),
        UpdatedBy_User  NVARCHAR(100)       NULL,
        UpdatedOn_Date  DATETIME            NULL,

        IsActive        BIT                 NOT NULL DEFAULT 1,

        CONSTRAINT PK_Takaful_Product_Master PRIMARY KEY CLUSTERED (SRNO ASC)
    )
    PRINT 'Table Takaful_Product_Master created.'
END
ELSE
    PRINT 'Table Takaful_Product_Master already exists - skipped.'
GO

-- =============================================
-- 2. Takaful_Product_Master_History (full audit trail)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Takaful_Product_Master_History]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[Takaful_Product_Master_History]
    (
        HistoryID       INT IDENTITY(1,1)   NOT NULL,
        SRNO            INT                 NULL,   -- FK to parent record
        ProductCode     NVARCHAR(50)        NULL,
        VendorName      NVARCHAR(200)       NULL,
        ProductType     NVARCHAR(50)        NULL,
        OldRate         NUMERIC(18, 10)     NULL,
        NewRate         NUMERIC(18, 10)     NULL,
        OldStatus       NVARCHAR(10)        NULL,
        NewStatus       NVARCHAR(10)        NULL,
        -- ActionType: CREATED, MODIFIED, APPROVED, REJECTED, DEACTIVATED
        ActionType      NVARCHAR(50)        NULL,
        ActionBy        NVARCHAR(100)       NULL,
        ActionDate      DATETIME            NULL    DEFAULT GETDATE(),
        Remarks         NVARCHAR(500)       NULL,
        MakerID         NVARCHAR(100)       NULL,
        MakerDate       DATETIME            NULL,
        CheckerID       NVARCHAR(100)       NULL,
        CheckerDate     DATETIME            NULL,

        CONSTRAINT PK_Takaful_Product_Master_History PRIMARY KEY CLUSTERED (HistoryID ASC)
    )
    PRINT 'Table Takaful_Product_Master_History created.'
END
ELSE
    PRINT 'Table Takaful_Product_Master_History already exists - skipped.'
GO

-- =============================================
-- 3. Insert Script: Seed Table 2 from Table 2 CSV
-- Initial load marked as Approved (Status='A')
-- =============================================
IF NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[Takaful_Product_Master])
BEGIN
    INSERT INTO [dbo].[Takaful_Product_Master]
        (ProductCode, VendorName, ProductType, Rate,
         MakerID, MakerDate, CheckerID, CheckerDate,
         [Status], CreatedBy_User, CreatedOn_Date, IsActive)
    VALUES
        ('Tkfl001', 'DIB - Salama Takaful Group cover', 'DIB',   0.0001849000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl002', 'DIB - Salama Takaful Group cover', 'Staff', 0.0001849000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl003', 'DIB - Salama Takaful Group cover', 'GHP',   0.0001849000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl004', 'Sukoon Takaful Group Cover',        'DIB',   0.0001899000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl005', 'Sukoon Takaful Group Cover',        'Staff', 0.0001899000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl006', 'Sukoon Takaful Group Cover',        'GHP',   0.0001899000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl007', 'Watania Takaful Group Cover',       'DIB',   0.0001850000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl008', 'Watania Takaful Group Cover',       'Staff', 0.0001850000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl009', 'Watania Takaful Group Cover',       'GHP',   0.0001850000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1),
        ('Tkfl010', 'Sukoon Takaful Group Cover',        'SZHP',  0.0002920000, 'SYSTEM', GETDATE(), 'SYSTEM', GETDATE(), 'A', 'SYSTEM', GETDATE(), 1)

    PRINT 'Takaful_Product_Master seeded with 10 records.'
END
ELSE
    PRINT 'Takaful_Product_Master already has data - seed skipped.'
GO

PRINT '== Script 07 completed successfully. =='
GO
