USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_BulkPostpone_Reject
-- Checker action: marks the request 'Rejected', no
-- changes are made to LEAD_DETAILS_DISB. Maker != Checker.
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Proc_HF48_BulkPostpone_Reject]') AND type = N'P')
    DROP PROC [dbo].[Proc_HF48_BulkPostpone_Reject]
GO

CREATE PROC [dbo].[Proc_HF48_BulkPostpone_Reject]
    @RequestID      INT,
    @CheckerUser    NVARCHAR(100),
    @CheckerRemarks NVARCHAR(1000),
    @Status         NVARCHAR(50)  OUTPUT,
    @Message        NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    IF ISNULL(@CheckerRemarks,'') = ''
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Rejection requires Checker remarks.'
        RETURN
    END

    DECLARE @MakerUser NVARCHAR(100), @ReqStatus NVARCHAR(30)
    DECLARE @ProjectName NVARCHAR(200)

    SELECT @MakerUser = MakerUser,
           @ReqStatus = Status,
           @ProjectName = Property_ProjectName
    FROM HF48_BULK_POSTPONE_REQUEST
    WHERE RequestID = @RequestID

    IF @MakerUser IS NULL
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request not found: ' + CONVERT(VARCHAR(10), @RequestID)
        RETURN
    END

    IF @ReqStatus <> 'Pending Approval'
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Request is in status "' + @ReqStatus + '" and cannot be rejected.'
        RETURN
    END

    IF UPPER(LTRIM(RTRIM(@MakerUser))) = UPPER(LTRIM(RTRIM(ISNULL(@CheckerUser,''))))
    BEGIN
        SET @Status  = 'FAILURE'
        SET @Message = 'Maker-Checker violation: the Maker (' + @MakerUser + ') cannot reject their own request.'
        RETURN
    END

    BEGIN TRY
    BEGIN TRANSACTION T_BPREJ

        UPDATE HF48_BULK_POSTPONE_REQUEST
           SET Status = 'Rejected',
               CheckerUser = @CheckerUser,
               CheckerOn = GETDATE(),
               CheckerRemarks = @CheckerRemarks
         WHERE RequestID = @RequestID

        INSERT INTO HF48_DISB_AUDIT_LOG
            (APP_REF_NO, Lead_No, Disb_Date, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES
            ('BULK#' + CONVERT(VARCHAR(10), @RequestID), @ProjectName, GETDATE(),
             'BulkPostpone-Rejected',
             'Request #' + CONVERT(VARCHAR(10), @RequestID) + ' rejected by Checker.',
             @CheckerUser,
             'Maker: ' + @MakerUser + ' / Checker remarks: ' + @CheckerRemarks)

    COMMIT TRANSACTION T_BPREJ

    SET @Status  = 'SUCCESS'
    SET @Message = 'Request #' + CONVERT(VARCHAR(10), @RequestID) + ' rejected.'
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION T_BPREJ
        SET @Status  = 'FAILURE'
        SET @Message = 'Reject failed: ' + ERROR_MESSAGE()
    END CATCH
END
GO

PRINT 'Proc_HF48_BulkPostpone_Reject created.'
GO
