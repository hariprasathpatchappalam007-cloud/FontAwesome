USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_ServiceTicket_Close
-- Called when a CLM service ticket is closed
-- Logs closure and notifies Operations, Evaluation, CLM Teams
-- =============================================
CREATE PROC [dbo].[Proc_HF48_ServiceTicket_Close]
    @TaskID INT,
    @UserID NVARCHAR(100),
    @Remarks NVARCHAR(MAX) = NULL,
    @Status NVARCHAR(50) OUTPUT,
    @Message NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @MAIL_TO NVARCHAR(1000)
    DECLARE @MAIL_CC NVARCHAR(1000)
    DECLARE @MAIL_SUBJECT NVARCHAR(500)
    DECLARE @MAIL_BODY NVARCHAR(MAX)
    DECLARE @EvalTeamEmail NVARCHAR(500)
    DECLARE @OpsTeamEmail NVARCHAR(500)
    DECLARE @CLMTeamEmail NVARCHAR(500)

    DECLARE @APP_REF_NO NVARCHAR(50)
    DECLARE @Lead_No NVARCHAR(50)
    DECLARE @Disb_Date DATETIME
    DECLARE @TaskType NVARCHAR(100)
    DECLARE @TaskStatus NVARCHAR(50)

    -- Validate task exists
    SELECT 
        @APP_REF_NO = APP_REF_NO,
        @Lead_No = Lead_No,
        @Disb_Date = Disb_Date,
        @TaskType = TaskType,
        @TaskStatus = Status
    FROM HF48_DISB_TASKS
    WHERE TaskID = @TaskID

    IF @APP_REF_NO IS NULL
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Task ID ' + CONVERT(VARCHAR(10), @TaskID) + ' not found.'
        RETURN
    END

    IF @TaskStatus = 'Closed'
    BEGIN
        SET @Status = 'FAILURE'
        SET @Message = 'Task ID ' + CONVERT(VARCHAR(10), @TaskID) + ' is already closed.'
        RETURN
    END

    SELECT @EvalTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam'
    SELECT @OpsTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam'
    SELECT @CLMTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam'

    BEGIN TRY
    BEGIN TRANSACTION T_TICKET_CLOSE

        -- Close the task
        UPDATE HF48_DISB_TASKS
        SET Status = 'Closed',
            ClosedBy = @UserID,
            ClosedOn = GETDATE(),
            Remarks = ISNULL(Remarks,'') + ' | Closed: ' + ISNULL(@Remarks,'')
        WHERE TaskID = @TaskID

        -- Audit Log
        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                'Service Ticket Closed',
                'Task #' + CONVERT(VARCHAR(10), @TaskID) + ' (' + ISNULL(@TaskType,'') + ') closed.',
                @OpsTeamEmail + ';' + @EvalTeamEmail + ';' + @CLMTeamEmail,
                @UserID,
                ISNULL(@Remarks, 'Service ticket closed.'))

        -- Notify Operations, Evaluation, and CLM Teams
        SET @MAIL_TO = @OpsTeamEmail
        SET @MAIL_CC = @EvalTeamEmail + ';' + @CLMTeamEmail
        SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Service Ticket Closed (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

        SET @MAIL_BODY = 'Dear Team,<br><br>'
        SET @MAIL_BODY = @MAIL_BODY + 'The following service ticket has been <b>CLOSED</b>.<br><br>'
        SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#000066><td colspan=2><font color=white><b>Ticket Closure Details</b></font></td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Task Type</font></td><td>' + ISNULL(@TaskType,'') + '</td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Closed By</font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Closed On</font></td><td>' + CONVERT(VARCHAR(20), GETDATE(), 120) + '</td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'') + '</td></tr>'
        SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
        SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

        INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
        VALUES (@APP_REF_NO, 'N', 'HF48 Service Ticket', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

        SET @Status = 'SUCCESS'
        SET @Message = 'Task #' + CONVERT(VARCHAR(10), @TaskID) + ' closed successfully. Notifications sent.'

    COMMIT TRANSACTION T_TICKET_CLOSE
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION T_TICKET_CLOSE

        SET @Status = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()

        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                'Service Ticket Close ERROR',
                'Error closing task #' + CONVERT(VARCHAR(10), @TaskID),
                @UserID,
                'Error: ' + ERROR_MESSAGE())
    END CATCH
END
GO

PRINT 'Proc_HF48_ServiceTicket_Close created successfully.'
GO
