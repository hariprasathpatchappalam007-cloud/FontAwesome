USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_Evaluation_Action
-- Called when the Evaluation Team marks a disbursement 
-- as Positive or Negative based on milestone review
-- =============================================
CREATE PROC [dbo].[Proc_HF48_Evaluation_Action]
    @APP_REF_NO NVARCHAR(50),
    @Lead_No NVARCHAR(50),
    @Disb_Date DATETIME,
    @EvaluationResult NVARCHAR(20),   -- 'Positive' or 'Negative'
    @MilestoneDeviation DECIMAL(18,2), -- percentage deviation
    @UserID NVARCHAR(100),
    @Remarks NVARCHAR(MAX) = NULL,
    @Status NVARCHAR(50) OUTPUT,
    @Message NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @MAIL_TO NVARCHAR(1000)
    DECLARE @MAIL_CC NVARCHAR(1000)
    DECLARE @MAIL_SUBJECT NVARCHAR(500)
    DECLARE @MAIL_BODY NVARCHAR(MAX)
    DECLARE @EvalTeamEmail NVARCHAR(500)
    DECLARE @OpsTeamEmail NVARCHAR(500)
    DECLARE @CLMTeamEmail NVARCHAR(500)
    DECLARE @TaskID INT
    DECLARE @Customer_Name NVARCHAR(200)
    DECLARE @DeveloperName NVARCHAR(200)
    DECLARE @ProjectName NVARCHAR(200)
    DECLARE @Disb_Amount DECIMAL(18,2)
    DECLARE @CLM_Case_RefNo NVARCHAR(50)
    DECLARE @TicketStatus NVARCHAR(50)
    DECLARE @TicketMessage NVARCHAR(500)

    SELECT @EvalTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam'
    SELECT @OpsTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam'
    SELECT @CLMTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam'

    -- Get application details
    SELECT 
        @Customer_Name = ld.Customer_name,
        @DeveloperName = ldp.Property_DeveloperName,
        @ProjectName = ldp.Property_ProjectName,
        @Disb_Amount = ldd.Disb_amount
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS ld ON ld.lead_no = ldd.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldd.lead_no
    WHERE ld.APP_REF_NO = @APP_REF_NO 
      AND ldd.Lead_No = @Lead_No
      AND ldd.Disb_Date = @Disb_Date

    BEGIN TRY
    BEGIN TRANSACTION T_EVAL_ACTION

        -- =============================================
        -- NEGATIVE SCENARIO
        -- Milestone is 10% less than expected
        -- =============================================
        IF UPPER(@EvaluationResult) = 'NEGATIVE'
        BEGIN
            -- Audit Log
            INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                    'Evaluation - Negative',
                    'Marked as Negative. Milestone deviation: ' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '%',
                    @EvalTeamEmail + ';' + @OpsTeamEmail,
                    @UserID,
                    ISNULL(@Remarks, 'Property milestone is 10% less than expected.'))

            -- Notify Evaluation and Operations Teams
            SET @MAIL_TO = @EvalTeamEmail
            SET @MAIL_CC = @OpsTeamEmail
            SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Evaluation Result: NEGATIVE - Milestone Below Expected'

            SET @MAIL_BODY = 'Dear Team,<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'The evaluation for the following application has been marked as <b style="color:red;">NEGATIVE</b>.<br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Property milestone is <b>' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '%</b> less than expected.<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#CC0000><td colspan=2><font color=white><b>Negative Evaluation Details</b></font></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#CC0000 valign=top><font color=white><b>Milestone Deviation</b></font></td><td><b>' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '% below expected</b></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Evaluated By</font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

            INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
            VALUES (@APP_REF_NO, 'N', 'HF48 Evaluation', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

            SET @Status = 'SUCCESS'
            SET @Message = 'Evaluation marked as Negative. Notification sent to Evaluation and Operations Teams.'
        END

        -- =============================================
        -- POSITIVE SCENARIO
        -- Milestone is 10% above expected
        -- =============================================
        IF UPPER(@EvaluationResult) = 'POSITIVE'
        BEGIN
            -- 1. Audit Log for positive evaluation
            INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                    'Evaluation - Positive',
                    'Marked as Positive. Milestone deviation: +' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '%',
                    @EvalTeamEmail + ';' + @OpsTeamEmail,
                    @UserID,
                    ISNULL(@Remarks, 'Property milestone is 10% above expected.'))

            -- 2. Notify Evaluation and Operations Teams
            SET @MAIL_TO = @EvalTeamEmail
            SET @MAIL_CC = @OpsTeamEmail
            SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Evaluation Result: POSITIVE - Milestone Above Expected'

            SET @MAIL_BODY = 'Dear Team,<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'The evaluation for the following application has been marked as <b style="color:green;">POSITIVE</b>.<br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Property milestone is <b>+' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '%</b> above expected.<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#006600><td colspan=2><font color=white><b>Positive Evaluation Details</b></font></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#006600 valign=top><font color=white><b>Milestone Deviation</b></font></td><td><b>+' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '% above expected</b></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Evaluated By</font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

            INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
            VALUES (@APP_REF_NO, 'N', 'HF48 Evaluation', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

            -- 3. Create the CLM Service Ticket via the shared ticket-creation
            --    procedure (see 16_Proc_HF48_CreateTicket_Shared.sql) so this
            --    positive Engineering-review outcome applies the exact same
            --    HF48_DISB_TASKS-based open-ticket guard, full disbursement
            --    detail capture, CreatedOn population, notification, and
            --    audit logging as the automated 10-day trigger and the
            --    manual trigger.
            SET @TaskID = NULL
            SET @CLM_Case_RefNo = NULL
            SET @TicketStatus = NULL
            SET @TicketMessage = NULL

            EXEC dbo.Proc_HF48_CreateCLMTicket
                @APP_REF_NO = @APP_REF_NO,
                @Lead_No    = @Lead_No,
                @Disb_Date  = @Disb_Date,
                @UserID     = @UserID,
                @Remarks    = 'Positive Engineering evaluation. Milestone +' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '% above expected. ' + ISNULL(@Remarks,''),
                @TaskID     = @TaskID OUTPUT,
                @Case_RefNo = @CLM_Case_RefNo OUTPUT,
                @Status     = @TicketStatus OUTPUT,
                @Message    = @TicketMessage OUTPUT

            SET @Status = 'SUCCESS'
            SET @Message = 'Evaluation marked as Positive. ' + ISNULL(@TicketMessage,'')
        END

    COMMIT TRANSACTION T_EVAL_ACTION
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION T_EVAL_ACTION

        SET @Status = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()

        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                'Evaluation Action ERROR',
                'Error during evaluation processing',
                @UserID,
                'Error: ' + ERROR_MESSAGE())
    END CATCH
END
GO

PRINT 'Proc_HF48_Evaluation_Action created successfully.'
GO
