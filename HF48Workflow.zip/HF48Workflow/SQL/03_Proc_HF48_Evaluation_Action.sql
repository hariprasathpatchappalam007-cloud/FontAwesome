USE [LMS_DEV]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Proc_HF48_Evaluation_Action
-- Called when the Evaluation Team marks a disbursement 
-- as Positive or Negative based on milestone review
-- =============================================
CREATE PROC [dbo].[Proc_HF48_Evaluation_Action]
    @APP_REF_NO NVARCHAR(50),
    @Lead_No NVARCHAR(50),
    @Disb_Date DATETIME,
    @EvaluationResult NVARCHAR(20),   -- 'Positive' or 'Negative'
    @MilestoneDeviation DECIMAL(18,2), -- percentage deviation
    @UserID NVARCHAR(100),
    @Remarks NVARCHAR(MAX) = NULL,
    @Status NVARCHAR(50) OUTPUT,
    @Message NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @MAIL_TO NVARCHAR(1000)
    DECLARE @MAIL_CC NVARCHAR(1000)
    DECLARE @MAIL_SUBJECT NVARCHAR(500)
    DECLARE @MAIL_BODY NVARCHAR(MAX)
    DECLARE @EvalTeamEmail NVARCHAR(500)
    DECLARE @OpsTeamEmail NVARCHAR(500)
    DECLARE @CLMTeamEmail NVARCHAR(500)
    DECLARE @TaskID INT
    DECLARE @Customer_Name NVARCHAR(200)
    DECLARE @DeveloperName NVARCHAR(200)
    DECLARE @ProjectName NVARCHAR(200)
    DECLARE @Disb_Amount DECIMAL(18,2)

    SELECT @EvalTeamEmail = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'EvaluationTeam'
    SELECT @OpsTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'OperationsTeam'
    SELECT @CLMTeamEmail  = ISNULL(PassValue,'') FROM frm_gnarr WHERE Code = 'HF48_DISTRIBUTION' AND Value = 'CLMTeam'

    -- Get application details
    SELECT 
        @Customer_Name = ld.Customer_name,
        @DeveloperName = ldp.Property_DeveloperName,
        @ProjectName = ldp.Property_ProjectName,
        @Disb_Amount = ldd.Disb_amount
    FROM LEAD_DETAILS_DISB ldd
    INNER JOIN LEAD_DETAILS ld ON ld.lead_no = ldd.lead_no
    INNER JOIN LEAD_DETAILS_Property ldp ON ldp.lead_no = ldd.lead_no
    WHERE ld.APP_REF_NO = @APP_REF_NO 
      AND ldd.Lead_No = @Lead_No
      AND ldd.Disb_Date = @Disb_Date

    BEGIN TRY
    BEGIN TRANSACTION T_EVAL_ACTION

        -- =============================================
        -- NEGATIVE SCENARIO
        -- Milestone is 10% less than expected
        -- =============================================
        IF UPPER(@EvaluationResult) = 'NEGATIVE'
        BEGIN
            -- Audit Log
            INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                    'Evaluation - Negative',
                    'Marked as Negative. Milestone deviation: ' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '%',
                    @EvalTeamEmail + ';' + @OpsTeamEmail,
                    @UserID,
                    ISNULL(@Remarks, 'Property milestone is 10% less than expected.'))

            -- Notify Evaluation and Operations Teams
            SET @MAIL_TO = @EvalTeamEmail
            SET @MAIL_CC = @OpsTeamEmail
            SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Evaluation Result: NEGATIVE - Milestone Below Expected'

            SET @MAIL_BODY = 'Dear Team,<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'The evaluation for the following application has been marked as <b style="color:red;">NEGATIVE</b>.<br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Property milestone is <b>' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '%</b> less than expected.<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#CC0000><td colspan=2><font color=white><b>Negative Evaluation Details</b></font></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#CC0000 valign=top><font color=white><b>Milestone Deviation</b></font></td><td><b>' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '% below expected</b></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Evaluated By</font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

            INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
            VALUES (@APP_REF_NO, 'N', 'HF48 Evaluation', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

            SET @Status = 'SUCCESS'
            SET @Message = 'Evaluation marked as Negative. Notification sent to Evaluation and Operations Teams.'
        END

        -- =============================================
        -- POSITIVE SCENARIO
        -- Milestone is 10% above expected
        -- =============================================
        IF UPPER(@EvaluationResult) = 'POSITIVE'
        BEGIN
            -- 1. Audit Log for positive evaluation
            INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                    'Evaluation - Positive',
                    'Marked as Positive. Milestone deviation: +' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '%',
                    @EvalTeamEmail + ';' + @OpsTeamEmail,
                    @UserID,
                    ISNULL(@Remarks, 'Property milestone is 10% above expected.'))

            -- 2. Notify Evaluation and Operations Teams
            SET @MAIL_TO = @EvalTeamEmail
            SET @MAIL_CC = @OpsTeamEmail
            SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 Evaluation Result: POSITIVE - Milestone Above Expected'

            SET @MAIL_BODY = 'Dear Team,<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'The evaluation for the following application has been marked as <b style="color:green;">POSITIVE</b>.<br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Property milestone is <b>+' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '%</b> above expected.<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#006600><td colspan=2><font color=white><b>Positive Evaluation Details</b></font></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Customer Name</font></td><td>' + ISNULL(@Customer_Name,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Disbursement Date</font></td><td>' + CONVERT(VARCHAR(20), @Disb_Date, 103) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Amount</font></td><td>' + CONVERT(VARCHAR(20), ISNULL(@Disb_Amount,0)) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Developer</font></td><td>' + ISNULL(@DeveloperName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Project</font></td><td>' + ISNULL(@ProjectName,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#006600 valign=top><font color=white><b>Milestone Deviation</b></font></td><td><b>+' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '% above expected</b></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Evaluated By</font></td><td>' + ISNULL(@UserID,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Remarks</font></td><td>' + ISNULL(@Remarks,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

            INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
            VALUES (@APP_REF_NO, 'N', 'HF48 Evaluation', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

            -- 3. Create CLM Service Ticket, assign to Operations
            INSERT INTO HF48_DISB_TASKS (APP_REF_NO, Lead_No, Disb_Date, TaskType, AssignedTeam, AssignedTo, Status, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, 'CLM Service Ticket', 'CLM Team', 'Operations Team', 'Open', @UserID,
                    'Positive evaluation. CLM service ticket created. Milestone +' + CONVERT(VARCHAR(20), @MilestoneDeviation) + '% above expected.')

            SET @TaskID = SCOPE_IDENTITY()

            -- 4. Audit log for CLM ticket creation
            INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, NotificationSentTo, CreatedBy, Remarks)
            VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                    'CLM Service Ticket Created',
                    'CLM Service Ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' created under CLM Team, assigned to Operations.',
                    @EvalTeamEmail + ';' + @OpsTeamEmail + ';' + @CLMTeamEmail,
                    @UserID,
                    'Positive evaluation resulted in CLM service ticket.')

            -- 5. Notify Evaluation, Operations, and CLM Teams about CLM ticket
            SET @MAIL_TO = @EvalTeamEmail
            SET @MAIL_CC = @OpsTeamEmail + ';' + @CLMTeamEmail
            SET @MAIL_SUBJECT = @APP_REF_NO + ' - HF48 CLM Service Ticket Created (Task #' + CONVERT(VARCHAR(10), @TaskID) + ')'

            SET @MAIL_BODY = 'Dear Team,<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Following a <b style="color:green;">POSITIVE</b> evaluation, a CLM Service Ticket has been created.<br><br>'
            SET @MAIL_BODY = @MAIL_BODY + '<table cellspacing=1 cellpadding=5 width=80% border=1>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr bgcolor=#000066><td colspan=2><font color=white><b>CLM Service Ticket</b></font></td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc width=200 valign=top><font color=white>Task ID</font></td><td>' + CONVERT(VARCHAR(10), @TaskID) + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Application No</font></td><td>' + ISNULL(@APP_REF_NO,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Lead No</font></td><td>' + ISNULL(@Lead_No,'') + '</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '<tr><td bgcolor=#9999cc valign=top><font color=white>Assigned To</font></td><td>Operations Team (CLM)</td></tr>'
            SET @MAIL_BODY = @MAIL_BODY + '</table><br>'
            SET @MAIL_BODY = @MAIL_BODY + 'Regards,<br>HF48 Automated Monitoring System'

            INSERT INTO FRM_MESSAGES (APPNNO, MESSAGEUPLOADEDYN, MESSAGECATEGORY, MESSAGE_TYPE, MAIL_TO, MAIL_CC, MAIL_SUBJECT, MAIL_BODY)
            VALUES (@APP_REF_NO, 'N', 'HF48 Evaluation', 'E', REPLACE(@MAIL_TO,' ',''), REPLACE(@MAIL_CC,' ',''), @MAIL_SUBJECT, @MAIL_BODY)

            SET @Status = 'SUCCESS'
            SET @Message = 'Evaluation marked as Positive. CLM ticket #' + CONVERT(VARCHAR(10), @TaskID) + ' created. Notifications sent.'
        END

    COMMIT TRANSACTION T_EVAL_ACTION
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION T_EVAL_ACTION

        SET @Status = 'FAILURE'
        SET @Message = 'Error: ' + ERROR_MESSAGE()

        INSERT INTO HF48_DISB_AUDIT_LOG (APP_REF_NO, Lead_No, Disb_Date, DaysBefore, ActionType, ActionResult, CreatedBy, Remarks)
        VALUES (@APP_REF_NO, @Lead_No, @Disb_Date, NULL,
                'Evaluation Action ERROR',
                'Error during evaluation processing',
                @UserID,
                'Error: ' + ERROR_MESSAGE())
    END CATCH
END
GO

PRINT 'Proc_HF48_Evaluation_Action created successfully.'
GO
