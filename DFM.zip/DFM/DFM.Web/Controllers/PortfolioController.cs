using System;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using DFM.Web.Infrastructure;
using DFM.Web.Models;

namespace DFM.Web.Controllers
{
    [ApiAuthorize, RoutePrefix("api/portfolio")]
    public class PortfolioController : ApiController
    {
        [HttpGet, Route("dashboard")]
        public IHttpActionResult Dashboard()
        {
            return Ok(new {
                metrics = Db.Query("SELECT * FROM vw_ManagementDashboard"),
                projects = Db.Query("SELECT * FROM vw_ProjectPortfolio ORDER BY CreatedUtc DESC"),
                budgets = Db.Query("SELECT * FROM BudgetSources ORDER BY BudgetType,ExternalId"),
                jira = Db.Query("SELECT TOP 500 * FROM vw_JiraProjectPicker ORDER BY JiraUpdated DESC"),
                budgetUsage = Db.Query("SELECT * FROM vw_CapexProjectUtilization ORDER BY BudgetSource,ApprovedUtc DESC")
            });
        }

        [HttpGet, Route("projects/{projectId:int}")]
        public IHttpActionResult Project(int projectId)
        {
            return Ok(new {
                project = Db.Query("SELECT * FROM vw_ProjectPortfolio WHERE ProjectId=@id", new SqlParameter("@id", projectId)).FirstOrDefault(),
                pets = Db.Query("SELECT * FROM PETRequests WHERE ProjectId=@id ORDER BY CreatedUtc", new SqlParameter("@id", projectId)),
                spendItems = Db.Query("SELECT s.* FROM SpendItems s JOIN PETRequests p ON p.PetId=s.PetId WHERE p.ProjectId=@id", new SqlParameter("@id", projectId)),
                budgetLines = Db.Query("SELECT b.* FROM BudgetLines b JOIN PETRequests p ON p.PetId=b.PetId WHERE p.ProjectId=@id", new SqlParameter("@id", projectId)),
                invoices = Db.Query("SELECT i.* FROM Invoices i JOIN BudgetLines b ON b.BudgetLineId=i.BudgetLineId JOIN PETRequests p ON p.PetId=b.PetId WHERE p.ProjectId=@id", new SqlParameter("@id", projectId)),
                attachments = Db.Query("SELECT AttachmentId,EntityType,EntityId,OriginalName,ContentType,FileSize,UploadedUtc FROM Attachments WHERE (EntityType='Project' AND EntityId=@id) OR (EntityType='PET' AND EntityId IN (SELECT PetId FROM PETRequests WHERE ProjectId=@id))", new SqlParameter("@id", projectId))
            });
        }

        [ApiAuthorize("Requestor", "Master"), HttpPost, Route("projects")]
        public IHttpActionResult SaveProject(ProjectRequest value)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.ProjectName)) return BadRequest("Project name is required.");
            var rows = Db.Query("EXEC dbo.sp_SaveProject @ProjectId,@IsJira,@JiraKey,@Name,@Type,@Lead,@Executive,@Sme,@Size,@Manager,@BudgetType,@BudgetSource,@RequiresPet,@SkipReview,@User", P("@ProjectId", value.ProjectId), P("@IsJira", value.IsJira), P("@JiraKey", value.JiraKey), P("@Name", value.ProjectName), P("@Type", value.ProjectType), P("@Lead", value.AccountableExecLead), P("@Executive", value.AccountableExec), P("@Sme", value.SmeLead), P("@Size", value.ProjectSize), P("@Manager", value.ProjectManager), P("@BudgetType", value.BudgetType), P("@BudgetSource", value.BudgetSourceId), P("@RequiresPet", value.RequiresPet), P("@SkipReview", value.SkipReview), P("@User", User.Identity.Name));
            return Ok(rows.FirstOrDefault());
        }

        [ApiAuthorize("Requestor", "Master"), HttpPost, Route("pets")]
        public IHttpActionResult SavePet(PetRequest value)
        {
            if (value == null || value.RequestedAmount <= 0) return BadRequest("A positive PET amount is required.");
            return Ok(Db.Query("EXEC dbo.sp_SavePet @PetId,@ProjectId,@Code,@Amount,@Currency,@User", P("@PetId", value.PetId), P("@ProjectId", value.ProjectId), P("@Code", value.Code), P("@Amount", value.RequestedAmount), P("@Currency", value.Currency), P("@User", User.Identity.Name)).FirstOrDefault());
        }

        [ApiAuthorize("Requestor", "Master"), HttpPost, Route("spend-items")]
        public IHttpActionResult SaveSpendItem(SpendItemRequest value)
        {
            if (value == null || string.IsNullOrWhiteSpace(value.Vendor)) return BadRequest("Vendor is required.");
            var foreignAmount = value.ForeignAmount == 0 ? value.Units * value.UnitPrice : value.ForeignAmount;
            var aedAmount = value.AedAmount == 0 ? foreignAmount : value.AedAmount;
            return Ok(Db.Query("EXEC dbo.sp_SaveSpendItem @Id,@Pet,@Head,@Topic,@Vendor,@CostType,@UnitType,@Units,@UnitPrice,@Currency,@Foreign,@Aed,@Contingency,@Gl", P("@Id", value.SpendItemId), P("@Pet", value.PetId), P("@Head", value.Head), P("@Topic", value.Topic), P("@Vendor", value.Vendor), P("@CostType", value.CostType), P("@UnitType", value.UnitType), P("@Units", value.Units), P("@UnitPrice", value.UnitPrice), P("@Currency", value.Currency), P("@Foreign", foreignAmount), P("@Aed", aedAmount), P("@Contingency", value.ContingencyPercent), P("@Gl", value.GlNumber)).FirstOrDefault());
        }

        [ApiAuthorize("Reviewer"), HttpPost, Route("pets/{petId:int}/review")]
        public IHttpActionResult Review(int petId, DecisionRequest value) { Db.Execute("EXEC dbo.sp_PetDecision @PetId,@Stage,@Approve,@Comments,@User", P("@PetId", petId), P("@Stage", "Review"), P("@Approve", value.Approve), P("@Comments", value.Comments), P("@User", User.Identity.Name)); return Ok(); }

        [ApiAuthorize("Approver"), HttpPost, Route("pets/{petId:int}/approve")]
        public IHttpActionResult Approve(int petId, DecisionRequest value) { Db.Execute("EXEC dbo.sp_PetDecision @PetId,@Stage,@Approve,@Comments,@User", P("@PetId", petId), P("@Stage", "Approval"), P("@Approve", value.Approve), P("@Comments", value.Comments), P("@User", User.Identity.Name)); return Ok(); }

        [ApiAuthorize("Requestor", "Master"), HttpPost, Route("budget-lines")]
        public IHttpActionResult SaveBudgetLine(BudgetLineRequest value) { return Ok(Db.Query("EXEC dbo.sp_SaveBudgetLine @Id,@Pet,@Vendor,@Justification,@Cost,@Currency,@Gl,@PetRef,@CamId,@CamStatus,@CamComments,@LpoRequest,@LpoStatus,@LpoComments,@User", P("@Id", value.BudgetLineId), P("@Pet", value.PetId), P("@Vendor", value.Vendor), P("@Justification", value.Justification), P("@Cost", value.Cost), P("@Currency", value.Currency), P("@Gl", value.GlNumber), P("@PetRef", value.PetReference), P("@CamId", value.CamId), P("@CamStatus", value.CamStatus), P("@CamComments", value.CamComments), P("@LpoRequest", value.LpoRequest), P("@LpoStatus", value.LpoStatus), P("@LpoComments", value.LpoComments), P("@User", User.Identity.Name)).FirstOrDefault()); }

        [ApiAuthorize("Requestor", "Master"), HttpPost, Route("invoices")]
        public IHttpActionResult SaveInvoice(InvoiceRequest value) { return Ok(Db.Query("EXEC dbo.sp_SaveInvoice @Id,@Line,@Vendor,@Justification,@Gl,@Number,@Amount,@Status,@PaymentDate,@User", P("@Id", value.InvoiceId), P("@Line", value.BudgetLineId), P("@Vendor", value.VendorName), P("@Justification", value.Justification), P("@Gl", value.GlNumber), P("@Number", value.InvoiceNumber), P("@Amount", value.InvoiceAmount), P("@Status", value.InvoiceStatus), P("@PaymentDate", value.PaymentDate), P("@User", User.Identity.Name)).FirstOrDefault()); }

        [ApiAuthorize("Master"), HttpPut, Route("budgets/{budgetSourceId:int}")]
        public IHttpActionResult UpdateBudget(int budgetSourceId, dynamic value) { Db.Execute("EXEC dbo.sp_UpdateBudget @Id,@Description,@Budget,@Utilization,@Available,@User", P("@Id", budgetSourceId), P("@Description", (string)value.description), P("@Budget", (decimal)value.budget), P("@Utilization", (decimal)value.utilization), P("@Available", (decimal)value.availableBudget), P("@User", User.Identity.Name)); return Ok(); }

        [ApiAuthorize("Requestor", "Master"), HttpPost, Route("attachments/{entityType}/{entityId:int}")]
        public async Task<IHttpActionResult> UploadAttachment(string entityType, int entityId)
        {
            if (!Request.Content.IsMimeMultipartContent()) return Content(HttpStatusCode.UnsupportedMediaType, "Use multipart/form-data.");
            var root = HttpContext.Current.Server.MapPath("~/App_Data/Attachments"); Directory.CreateDirectory(root);
            var provider = await Request.Content.ReadAsMultipartAsync(new MultipartFormDataStreamProvider(root));
            foreach (var file in provider.FileData)
            {
                var original = file.Headers.ContentDisposition.FileName.Trim('"');
                Db.Execute("INSERT Attachments(EntityType,EntityId,OriginalName,StoredName,ContentType,FileSize,UploadedBy) VALUES(@type,@id,@original,@stored,@content,@size,@user)", P("@type", entityType), P("@id", entityId), P("@original", Path.GetFileName(original)), P("@stored", Path.GetFileName(file.LocalFileName)), P("@content", file.Headers.ContentType == null ? "application/octet-stream" : file.Headers.ContentType.MediaType), P("@size", new FileInfo(file.LocalFileName).Length), P("@user", User.Identity.Name));
            }
            return Ok();
        }

        [ApiAuthorize("Requestor", "Master"), HttpPost, Route("bulk/{kind}/{parentId:int}")]
        public async Task<IHttpActionResult> Bulk(string kind, int parentId)
        {
            if (!new[] { "pet", "budget", "invoice" }.Contains(kind, StringComparer.OrdinalIgnoreCase)) return BadRequest("Unknown template type.");
            var csv = await Request.Content.ReadAsStringAsync();
            var imported = CsvBulkImporter.Import(kind, parentId, csv, User.Identity.Name);
            return Ok(new { imported = imported });
        }

        private static SqlParameter P(string name, object value) { return new SqlParameter(name, Db.Value(value)); }
    }
}
