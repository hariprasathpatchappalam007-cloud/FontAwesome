(function () {
  "use strict";
  angular
    .module("dfmApp", [])
    .directive("falconSelect2", function ($timeout) {
      return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attributes, ngModel) {
          $timeout(function () {
            element.select2({ width: "100%", placeholder: attributes.placeholder || "Select an option", allowClear: true });
            element.on("change.falcon", function () {
              scope.$evalAsync(function () { ngModel.$setViewValue(element.val()); });
            });
          }, 0, false);
          scope.$on("$destroy", function () { element.off("change.falcon"); if (element.data("select2")) element.select2("destroy"); });
        },
      };
    })
    .controller("PortfolioController", function ($http, $timeout) {
      var vm = this;
      vm.session = null;
      vm.auth = { mode: "login" };
      vm.questions = [
        { securityQuestionId: 1, question: "What was the name of your first school?" },
        { securityQuestionId: 2, question: "In which city were you born?" },
        { securityQuestionId: 3, question: "What is the name of your childhood best friend?" },
      ];
      vm.today = new Date();
      vm.tab = "portfolio";
      vm.role = "Master";
      vm.demo = true;
      vm.search = "";
      vm.statusFilter = "";
      vm.viewFilter = "all";
      vm.page = 1;
      vm.pageSize = 10;
      vm.pageCount = 1;
      vm.filteredCount = 0;
      vm.visibleProjects = [];
      vm.approvalItems = [];
      vm.tabs = [
        { id: "portfolio", label: "Portfolio", icon: "layout-dashboard" },
        { id: "approvals", label: "Approvals", icon: "stamp" },
        { id: "budgets", label: "CAPEX / OPEX", icon: "landmark" },
        {
          id: "reports",
          label: "Management report",
          icon: "chart-no-axes-combined",
        },
      ];
      vm.roles = ["Requestor", "Reviewer", "Approver", "Master"];
      vm.stages = ["ITA", "Design", "Develop", "UAT", "Staging", "Live"];
      vm.metrics = {
        projectsRegistered: 4,
        activeProjects: 3,
        petsApproved: 3,
        petsOnTrack: 2,
        petsRejected: 1,
        invoicesRaised: 5,
        invoicesOutstanding: 3,
        invoicesSettled: 2,
        capexBudget: 5200000,
        capexUtilized: 2117500,
        opexBudget: 1750000,
        opexUtilized: 638000,
      };
      vm.budgets = [
        {
          budgetSourceId: 1,
          budgetType: "CAPEX",
          externalId: "IT_NP14_Sub_57_2025",
          description:
            "Core banking platform enhancements and security remediation",
          budget: 1750000,
          utilization: 1242630.78,
          availableBudget: 507369.22,
          requiresPet: true,
        },
        {
          budgetSourceId: 2,
          budgetType: "CAPEX",
          externalId: "IT_NP12_Sub_11_2025",
          description: "FinnOne delivery squad for risk and cards",
          budget: 2140876,
          utilization: 716217.25,
          availableBudget: 1424658.75,
        },
        {
          budgetSourceId: 3,
          budgetType: "OPEX",
          externalId: "OPEX-CET-0001",
          description: "MDS procurement of VDI licenses 2026",
          budget: 1200000,
          utilization: 84000,
          availableBudget: 1116000,
          requiresPet: true,
        },
        {
          budgetSourceId: 4,
          budgetType: "OPEX",
          externalId: "OPEX-CET-0002",
          description: "ATM CDM platform operational support",
          budget: 950000,
          utilization: 0,
          availableBudget: 950000,
        },
      ];
      vm.jira = [
        {
          jiraKey: "DIBITP-27312",
          summary:
            "Card upgrade, product change and limit change for credit cards",
          status: "Execution / Delivery",
          projectType: "Project",
          accountableExecLead: "Amit Saxena",
          accountableExec: "Zahoor Ul Islam",
          smeLead: "Amit Saxena",
          assignedProjectManager: "Syeda Areeba Tariq",
          projectRag: "Green",
          platform: "FinOne",
          demandType: "Fast Track",
          requirements:
            "Automate contract communication and create a card upgrade workflow with product and limit-change controls.",
          portfolioExecutiveSummary:
            "Architecture design is complete. Integration discovery and delivery planning are in progress.",
        },
        {
          jiraKey: "DMGT-1011",
          summary: "Card upgrade",
          status: "Execution / Delivery",
          projectType: "Demand",
          accountableExecLead: "Amit Saxena",
          accountableExec: "Zahoor Ul Islam",
          smeLead: "Amit Saxena",
          assignedProjectManager: "Syeda Areeba Tariq",
          projectRag: "Green",
          platform: "Cards",
          demandType: "Fast Track",
          requirements:
            "Increase cards revenue and simplify the customer upgrade process.",
          portfolioExecutiveSummary:
            "Demand accepted and linked to the delivery project.",
        },
        {
          jiraKey: "DMGT-433",
          summary: "Eleveo Call Recording System Upgrade",
          status: "Live",
          projectType: "Enhancement",
          accountableExecLead: "Wasim Akram",
          accountableExec: "Zahoor Ul Islam",
          smeLead: "Karthi Vasudevan",
          assignedProjectManager: "Muhammad Yahya Abdul Hayu",
          projectRag: "Green",
          platform: "Call Center / IVR Services",
          demandType: "Strategic",
          requirements:
            "Upgrade obsolete RHEL and call recording components as part of OS remediation.",
          portfolioExecutiveSummary:
            "Development complete and service moved to live support.",
        },
      ];
      var invoices = [
        {
          invoiceId: 1001,
          vendorName: "Oracle LLC",
          justification: "Annual license",
          glNumber: "55001",
          invoiceNumber: "INV-2026-001",
          invoiceAmount: 15000,
          invoiceStatus: "Paid",
          paymentDate: new Date(2026, 7, 6),
        },
      ];
      var lines = [
        {
          budgetLineId: 1,
          vendor: "Oracle LLC",
          justification: "Annual platform license",
          cost: 150000,
          currency: "AED",
          glNumber: "55001",
          petReference: "PET-100",
          camId: "CAM-001",
          camStatus: "Approved",
          camComments: "Approved",
          lpoRequest: "LPO-100",
          lpoStatus: "Issued",
          lpoComments: "Completed",
          invoices: invoices,
        },
      ];
      vm.projects = [
        {
          projectId: 1,
          projectCode: "PRJ-000001",
          jiraKey: "DIBITP-27312",
          projectName: "Card upgrade and product change",
          projectType: "Project",
          accountableExecLead: "Amit Saxena",
          accountableExec: "Zahoor Ul Islam",
          smeLead: "Amit Saxena",
          projectSize: "Large",
          projectManager: "Syeda Areeba Tariq",
          requestorEmail: "cards.requestor@dfm.ae",
          requestorName: "Preview User",
          status: "Approved",
          createdUtc: new Date(2026, 7, 6),
          budgetType: "CAPEX",
          budgetSource: "IT_NP14_Sub_57_2025",
          budgetSourceId: 1,
          availableBudget: 507369.22,
          pets: [
            {
              petId: 1,
              code: "PET-2026-001",
              status: "Approved",
              requestedAmount: 150000,
              reviewerEmail: "Amit Saxena",
              approverEmail: "Zahoor Ul Islam",
              createdUtc: new Date(2026, 7, 5),
              spendItems: [],
              budgetLines: lines,
            },
          ],
        },
        {
          projectId: 2,
          projectCode: "PRJ-000002",
          jiraKey: "DMGT-433",
          projectName: "Eleveo Call Recording System Upgrade",
          projectType: "Enhancement",
          accountableExecLead: "Wasim Akram",
          accountableExec: "Ahmed Ali",
          smeLead: "Karthi Vasudevan",
          projectSize: "Medium",
          projectManager: "Muhammad Yahya Abdul Hayu",
          requestorEmail: "operations@dfm.ae",
          requestorName: "Operations Change",
          status: "Pending Approval",
          createdUtc: new Date(2026, 7, 18),
          budgetType: "OPEX",
          budgetSource: "OPEX-CET-0001",
          budgetSourceId: 3,
          availableBudget: 1116000,
          pets: [
            {
              petId: 2,
              code: "PET-2026-014",
              status: "Pending Approval",
              requestedAmount: 280000,
              reviewerEmail: "Wasim Akram",
              createdUtc: new Date(2026, 7, 19),
              spendItems: [],
              budgetLines: [],
            },
          ],
        },
        {
          projectId: 3,
          projectCode: "PRJ-000003",
          projectName: "Finance data retention controls",
          projectType: "Regulatory",
          accountableExecLead: "Nandi Kumar",
          accountableExec: "Sara Khan",
          smeLead: "Ravi Menon",
          projectSize: "Small",
          projectManager: "Hariprasath R",
          requestorEmail: "finance.change@dfm.ae",
          requestorName: "Finance Change",
          status: "Pending Review",
          createdUtc: new Date(2026, 7, 22),
          budgetType: "CAPEX",
          budgetSource: "IT_NP12_Sub_11_2025",
          budgetSourceId: 2,
          availableBudget: 1424658.75,
          requiresPet: true,
          pets: [
            {
              petId: 3,
              code: "PET-2026-018",
              status: "Pending Review",
              requestedAmount: 92500,
              createdUtc: new Date(2026, 7, 23),
              spendItems: [
                { spendItemId: 1, head: "Software", topic: "Retention controls", vendor: "Data Systems LLC", costType: "CAPEX", units: 5, unitPrice: 17500, currency: "AED", foreignAmount: 87500, aedAmount: 87500, contingencyPercent: 5, glNumber: "55001" },
              ],
              budgetLines: [],
            },
          ],
        },
        {
          projectId: 4,
          projectCode: "PRJ-000004",
          projectName: "ATM settlement reconciliation",
          projectType: "Operational",
          accountableExecLead: "Farah Noor",
          accountableExec: "Omar Salim",
          smeLead: "Khalid Rahman",
          projectSize: "Medium",
          projectManager: "Leena George",
          requestorEmail: "atm.ops@dfm.ae",
          requestorName: "ATM Operations",
          status: "Active",
          createdUtc: new Date(2026, 7, 25),
          budgetType: "OPEX",
          budgetSource: "OPEX-CET-0002",
          budgetSourceId: 4,
          availableBudget: 950000,
          requiresPet: false,
          pets: [],
        },
      ];

      vm.pageTitle = function () {
        return {
          portfolio: "Projects & financial workflow",
          approvals: "PET review & approval queue",
          budgets: "Budget source control",
          reports: "Management reporting",
        }[vm.tab];
      };
      vm.authTitle = function () { return { login: "Sign in", setup: "Create your password", reset: "Verify your identity", complete: "Choose a new password" }[vm.auth.mode]; };
      vm.authHelp = function () { return vm.auth.mode === "login" ? "Use your synchronized Active Directory email ID." : "This anonymous step is protected by your stored security challenge."; };
      vm.authAction = function () { return { login: "Sign in", setup: "Activate account", reset: "Verify answer", complete: "Reset password" }[vm.auth.mode]; };
      vm.enterPreview = function () { vm.session = { displayName: "Preview User", email: "cards.requestor@dfm.ae", initials: "PU", roles: vm.roles }; vm.demo = true; prepareProjects(); vm.updateView(); redraw(); };
      vm.signOut = function () { vm.session = null; vm.auth = { mode: "login" }; sessionStorage.removeItem("dfmToken"); };
      vm.authenticate = function () {
        vm.auth.error = "";
        var route = vm.auth.mode === "login" ? "login" : vm.auth.mode === "setup" ? "first-time-setup" : vm.auth.mode === "reset" ? "reset/challenge" : "reset/complete";
        $http.post("api/auth/" + route, vm.auth).then(function (response) {
          if (vm.auth.mode === "login") {
            if (response.data.requiresPasswordSetup) { vm.auth.mode = "setup"; return; }
            sessionStorage.setItem("dfmToken", response.data.token); vm.session = response.data; vm.session.initials = (vm.session.displayName || vm.session.email).split(/\s+/).slice(0,2).map(function (part) { return part.charAt(0); }).join("").toUpperCase();
            $http.defaults.headers.common.Authorization = "Bearer " + response.data.token;
            loadDashboard();
          } else if (vm.auth.mode === "reset") { vm.auth.resetToken = response.data.resetToken; vm.auth.mode = "complete"; }
          else { vm.auth = { mode: "login", email: vm.auth.email }; notice("Password saved. Sign in to continue."); }
          redraw();
        }, function (response) { vm.auth.error = response.data && response.data.message ? response.data.message : "Unable to complete this request."; });
      };
      vm.can = function (action) {
        return action === "request"
          ? vm.role === "Requestor" || vm.role === "Master"
          : false;
      };
      vm.setRole = function (role) {
        vm.role = role;
        vm.updateView();
        redraw();
      };
      vm.money = function (value) {
        return new Intl.NumberFormat("en-AE", {
          style: "currency",
          currency: "AED",
          maximumFractionDigits: 0,
        }).format(Number(value) || 0);
      };
      vm.percent = function (value, total) {
        return total ? Math.round(((Number(value) || 0) * 100) / total) : 0;
      };
      vm.statusClass = function (status) {
        var text = (status || "").toLowerCase();
        if (/approved|paid|settled|issued|active|live/.test(text))
          return "approved";
        if (/reject|blocked/.test(text)) return "rejected";
        if (/pending|outstanding|received|review|approval/.test(text))
          return "pending";
        return "neutral";
      };
      vm.pendingPet = function (project, status) {
        for (var index = 0; index < project.pets.length; index++) if (project.pets[index].status === status) return project.pets[index];
        return null;
      };
      vm.petFinalAed = function (pet) {
        if (!pet.spendItems || !pet.spendItems.length) return Number(pet.requestedAmount) || 0;
        return pet.spendItems.reduce(function (total, item) { return total + (Number(item.aedAmount) || 0) * (1 + (Number(item.contingencyPercent) || 0) / 100); }, 0);
      };
      vm.updateView = function (keepPage) {
        var query = vm.search.toLowerCase();
        var currentEmail = (vm.session && vm.session.email || "").toLowerCase();
        var currentName = (vm.session && vm.session.displayName || "").toLowerCase();
        var filtered = vm.projects.filter(function (p) {
          var pets = p.pets || [];
          var isMine = (p.requestorEmail || "").toLowerCase() === currentEmail || (p.requestorName || "").toLowerCase() === currentName;
          var viewMatch = vm.viewFilter === "all" ||
            (vm.viewFilter === "my" && isMine) ||
            (vm.viewFilter === "jira" && !!p.jiraKey) ||
            (vm.viewFilter === "nonJira" && !p.jiraKey) ||
            (vm.viewFilter === "pendingReview" && pets.some(function (pet) { return pet.status === "Pending Review"; })) ||
            (vm.viewFilter === "pendingApproval" && pets.some(function (pet) { return pet.status === "Pending Approval"; })) ||
            (vm.viewFilter === "approved" && pets.some(function (pet) { return pet.status === "Approved" && (isMine || (pet.approverEmail || "").toLowerCase() === currentEmail); })) ||
            (vm.viewFilter === "reviewed" && pets.some(function (pet) { return !!pet.reviewedUtc || !!pet.reviewerEmail; }));
          return (
            viewMatch &&
            (!vm.statusFilter || p.status === vm.statusFilter) &&
            (!query ||
              [
                p.projectCode,
                p.jiraKey,
                p.projectName,
                p.accountableExecLead,
                p.requestorEmail,
              ]
                .join(" ")
                .toLowerCase()
                .indexOf(query) >= 0)
          );
        });
        vm.filteredCount = filtered.length;
        vm.pageCount = Math.max(1, Math.ceil(filtered.length / vm.pageSize));
        if (!keepPage || vm.page > vm.pageCount) vm.page = 1;
        var start = (vm.page - 1) * vm.pageSize;
        vm.visibleProjects = filtered.slice(start, start + vm.pageSize);
        vm.approvalItems = buildApprovalItems();
      };
      vm.changePage = function (page) { vm.page = Math.max(1, Math.min(vm.pageCount, page)); vm.updateView(true); };
      function buildApprovalItems() {
        var status =
          vm.role === "Reviewer"
            ? "Pending Review"
            : vm.role === "Approver"
              ? "Pending Approval"
              : "";
        var result = [];
        if (!status) return result;
        vm.projects.forEach(function (p) {
          p.pets.forEach(function (pet) {
            if (pet.status === status) result.push({ project: p, pet: pet });
          });
        });
        return result;
      }
      function prepareProjects() {
        if (vm.demo) vm.budgetUsage = [];
        vm.projects.forEach(function (project) {
          if (typeof project.petsLoaded === "undefined") project.petsLoaded = angular.isArray(project.pets);
          project.pets = project.pets || [];
          if (!project.petsLoaded) return;
          project.petCount = project.pets.length;
          project.spendRequestCount = 0;
          project.budgetLineCount = 0;
          project.invoiceCount = 0;
          project.pets.forEach(function (pet) {
            pet.spendItems = pet.spendItems || [];
            pet.budgetLines = pet.budgetLines || [];
            if (pet.spendItems.length) pet.requestedAmount = vm.petFinalAed(pet);
            project.spendRequestCount += pet.spendItems.length;
            project.budgetLineCount += pet.budgetLines.length;
            pet.budgetLines.forEach(function (line) { line.invoices = line.invoices || []; project.invoiceCount += line.invoices.length; });
            if (vm.demo && project.budgetType === "CAPEX" && pet.status === "Approved") vm.budgetUsage.push({ budgetSource: project.budgetSource, projectName: project.projectName, petCode: pet.code, amount: pet.requestedAmount });
          });
        });
      }
      vm.toggleProject = function (project) {
        if (project.expanded) { project.expanded = false; return; }
        if (project.petsLoaded || vm.demo) { project.expanded = project.pets.length > 0; redraw(); return; }
        project.loading = true;
        $http.get("api/portfolio/projects/" + project.projectId).then(function (response) {
          var data = response.data;
          project.pets = data.pets || [];
          project.pets.forEach(function (pet) {
            pet.spendItems = (data.spendItems || []).filter(function (item) { return item.petId === pet.petId; });
            pet.budgetLines = (data.budgetLines || []).filter(function (line) { return line.petId === pet.petId; });
            pet.budgetLines.forEach(function (line) { line.invoices = (data.invoices || []).filter(function (invoice) { return invoice.budgetLineId === line.budgetLineId; }); });
          });
          project.petsLoaded = true;
          project.loading = false;
          project.expanded = project.pets.length > 0;
          prepareProjects();
          vm.updateView(true);
          redraw();
        }, function () { project.loading = false; notice("Unable to load project details."); });
      };
      vm.openProject = function (project) {
        vm.modal = {
          type: "project",
          kicker: "PROJECT REGISTRATION",
          title: project ? "Edit project" : "Register a new project",
          submit: project ? "Save changes" : "Register project",
        };
        vm.form = angular.copy(
          project || {
            isJira: true,
            projectType: "Project",
            projectSize: "Medium",
            budgetType: "CAPEX",
            requiresPet: true,
            skipReview: false,
          },
        );
        vm.form.isJira = project ? !!project.jiraKey : true;
        redraw();
      };
      vm.pickJira = function () {
        var jira = vm.jira.filter(function (j) {
          return j.jiraKey === vm.form.jiraKey;
        })[0];
        if (!jira) return;
        vm.form.projectName = jira.summary;
        vm.form.projectType = jira.projectType;
        vm.form.accountableExecLead = jira.accountableExecLead;
        vm.form.accountableExec = jira.accountableExec;
        vm.form.smeLead = jira.smeLead;
        vm.form.projectManager = jira.assignedProjectManager;
      };
      vm.openJira = function (project) {
        var jira =
          vm.jira.filter(function (j) {
            return j.jiraKey === project.jiraKey;
          })[0] || project;
        vm.form = angular.extend({}, project, jira, {
          projectName: jira.summary || project.projectName,
        });
        vm.modal = {
          type: "jira",
          kicker: "SYNCHRONIZED JIRA DETAIL",
          title: project.jiraKey || project.projectCode,
        };
        redraw();
      };
      vm.openPet = function (project, pet) {
        vm.selectedProject = project;
        vm.selectedPet = pet;
        vm.form = angular.copy(pet || {
            projectId: project.projectId,
            code: "PET-2026-" + String(Date.now()).slice(-4),
            currency: "AED",
            requestedAmount: 0,
          });
        vm.modal = {
          type: "pet",
          kicker: "PET REQUEST",
          title: pet ? "Edit " + pet.code : "Create PET for " + project.projectCode,
          submit: pet ? "Save PET" : "Submit for review",
        };
        redraw();
      };
      vm.openSpend = function (pet) {
        vm.selectedPet = pet;
        vm.selectedProject = vm.projects.filter(function (project) { return project.pets.indexOf(pet) >= 0; })[0];
        vm.selectedPet.spendItems = vm.selectedPet.spendItems || [];
        vm.spendEditable = vm.can("request") && (pet.status === "Pending Review" || (pet.status === "Pending Approval" && vm.selectedProject && vm.selectedProject.skipReview));
        vm.form = { petId: pet.petId, units: 1, currency: "AED", contingencyPercent: 0 };
        vm.modal = { type: "spend", kicker: "PET COST DETAIL", title: "Spend line items · " + pet.code, submit: "Save spend item" };
        redraw();
      };
      vm.editSpend = function (item) {
        vm.form = angular.copy(item);
        redraw();
      };
      vm.openDecision = function (pet, stage) {
        vm.form = angular.copy(pet);
        vm.form.approve = true;
        vm.modal = {
          type: "decision",
          stage: stage,
          kicker:
            stage === "review" ? "REVIEWER DECISION" : "APPROVER DECISION",
          title: stage === "review" ? "Review PET" : "Approve PET",
          submit: "Record decision",
        };
        vm.selectedProject = vm.projects.filter(function (p) {
          return p.pets.indexOf(pet) >= 0;
        })[0];
        redraw();
      };
      vm.openBudgetLine = function (pet, line) {
        vm.selectedPet = pet;
        vm.form = angular.copy(
          line || {
            petId: pet.petId,
            currency: "AED",
            camStatus: "Pending",
            lpoStatus: "Not Raised",
          },
        );
        vm.modal = {
          type: "budgetLine",
          kicker: "APPROVED PET SPEND",
          title: line ? "Edit budget line" : "Add budget line",
          submit: "Save budget line",
        };
        redraw();
      };
      vm.openInvoice = function (line, invoice) {
        vm.selectedLine = line;
        vm.form = angular.copy(
          invoice || {
            budgetLineId: line.budgetLineId,
            vendorName: line.vendor,
            glNumber: line.glNumber,
            invoiceStatus: "Raised",
          },
        );
        if (vm.form.paymentDate)
          vm.form.paymentDate = new Date(vm.form.paymentDate);
        vm.modal = {
          type: "invoice",
          kicker: "INVOICE REGISTER",
          title: invoice ? "Update invoice" : "Add invoice",
          submit: "Save invoice",
        };
        redraw();
      };
      vm.openBudget = function (budget) {
        vm.selectedBudget = budget;
        vm.form = angular.copy(budget);
        vm.modal = {
          type: "budget",
          kicker: "MASTER CONTROL",
          title: "Edit " + budget.externalId,
          submit: "Update budget",
        };
        redraw();
      };
      vm.openUpload = function (kind, item) {
        var templates = {
          pet: "templates/pet-upload-template.csv",
          budget: "templates/budget-upload-template.csv",
          invoice: "templates/invoice-upload-template.csv",
        };
        vm.modal = {
          type: "upload",
          kind: kind,
          kicker: "BULK IMPORT",
          title:
            kind === "attachment"
              ? "Attach supporting files"
              : "Upload " + kind + " records",
          submit: "Upload files",
          template: templates[kind],
          help:
            kind === "attachment"
              ? "PDF, spreadsheet and image files up to 50 MB."
              : "Use the supplied CSV columns. Invalid rows are rejected with a row-level reason.",
        };
        vm.form = { item: item };
        redraw();
      };
      vm.download = function (kind) {
        window.location.href = "templates/" + kind + "-upload-template.csv";
      };
      vm.close = function () {
        vm.modal = null;
        vm.form = {};
        redraw();
      };
      vm.closeOnBackdrop = function (event) {
        if (event.target === event.currentTarget) vm.close();
      };
      vm.saveModal = function () {
        var type = vm.modal.type;
        if (type === "project") {
          var existing =
            vm.form.projectId &&
            vm.projects.filter(function (p) {
              return p.projectId === vm.form.projectId;
            })[0];
          var budget = vm.budgets.filter(function (b) {
            return String(b.budgetSourceId) === String(vm.form.budgetSourceId);
          })[0];
          if (existing) angular.extend(existing, vm.form);
          else {
            vm.form.projectId = vm.projects.length + 1;
            vm.form.projectCode =
              "PRJ-" + ("000000" + vm.form.projectId).slice(-6);
            vm.form.jiraKey = vm.form.isJira ? vm.form.jiraKey : null;
            vm.form.requestorEmail = vm.session.email;
            vm.form.requestorName = vm.session.displayName;
            vm.form.status = vm.form.requiresPet ? "Active" : "Registered";
            vm.form.createdUtc = new Date();
            vm.form.pets = [];
            vm.form.petsLoaded = true;
            vm.form.budgetSource = budget ? budget.externalId : "Not required";
            vm.form.availableBudget = budget ? budget.availableBudget : 0;
            vm.projects.unshift(vm.form);
            vm.metrics.projectsRegistered++;
          }
          prepareProjects();
          vm.updateView();
          notice("Project saved");
        }
        if (type === "pet") {
          if (vm.selectedPet) angular.extend(vm.selectedPet, vm.form);
          else {
            vm.form.petId = Date.now();
            vm.form.status = vm.selectedProject.skipReview ? "Pending Approval" : "Pending Review";
            vm.form.createdUtc = new Date();
            vm.form.spendItems = [];
            vm.form.budgetLines = [];
            vm.selectedProject.pets.push(vm.form);
            vm.metrics.petsOnTrack++;
          }
          vm.selectedProject.status = vm.selectedProject.skipReview ? "Pending Approval" : "Pending Review";
          prepareProjects();
          vm.updateView();
          notice(vm.selectedPet ? "PET updated" : vm.selectedProject.skipReview ? "PET sent directly to the Accountable Executive" : "PET submitted to the Accountable Executive Lead");
        }
        if (type === "spend") {
          var oldSpend = vm.form.spendItemId && vm.selectedPet.spendItems.filter(function (item) { return item.spendItemId === vm.form.spendItemId; })[0];
          vm.form.foreignAmount = vm.form.units * vm.form.unitPrice;
          vm.form.aedAmount = vm.form.aedAmount || vm.form.foreignAmount;
          if (oldSpend) angular.extend(oldSpend, vm.form);
          else { vm.form.spendItemId = Date.now(); vm.selectedPet.spendItems.push(vm.form); }
          vm.selectedPet.requestedAmount = vm.petFinalAed(vm.selectedPet);
          prepareProjects();
          vm.updateView();
          notice("Spend item saved");
        }
        if (type === "decision") {
          var target = vm.selectedProject.pets.filter(function (p) {
            return p.petId === vm.form.petId;
          })[0];
          target.status = vm.form.approve
            ? vm.modal.stage === "review"
              ? "Pending Approval"
              : "Approved"
            : "Rejected";
          vm.selectedProject.status = target.status;
          if (target.status === "Approved") {
            vm.metrics.petsApproved++;
            vm.metrics.petsOnTrack--;
            vm.selectedProject.availableBudget -= target.requestedAmount;
          } else if (target.status === "Rejected") {
            vm.metrics.petsRejected++;
            vm.metrics.petsOnTrack--;
          }
          if (vm.modal.stage === "review") { target.reviewerEmail = vm.session.email; target.reviewedUtc = new Date(); }
          if (vm.modal.stage === "approve") target.approverEmail = vm.session.email;
          prepareProjects();
          vm.updateView();
          notice("Decision recorded");
        }
        if (type === "budgetLine") {
          var old =
            vm.form.budgetLineId &&
            vm.selectedPet.budgetLines.filter(function (x) {
              return x.budgetLineId === vm.form.budgetLineId;
            })[0];
          if (old) angular.extend(old, vm.form);
          else {
            vm.form.budgetLineId = Date.now();
            vm.form.invoices = [];
            vm.selectedPet.budgetLines.push(vm.form);
          }
          prepareProjects();
          vm.updateView();
          notice("Budget line saved");
        }
        if (type === "invoice") {
          var oldInvoice =
            vm.form.invoiceId &&
            vm.selectedLine.invoices.filter(function (x) {
              return x.invoiceId === vm.form.invoiceId;
            })[0];
          if (oldInvoice) angular.extend(oldInvoice, vm.form);
          else {
            vm.form.invoiceId = Date.now();
            vm.selectedLine.invoices.push(vm.form);
            vm.metrics.invoicesRaised++;
            vm.metrics.invoicesOutstanding++;
          }
          prepareProjects();
          vm.updateView();
          notice("Invoice saved");
        }
        if (type === "budget") {
          angular.extend(vm.selectedBudget, vm.form);
          notice("Budget source updated");
        }
        if (type === "upload") notice("File accepted for validation");
        vm.close();
        redraw();
      };
      function notice(message) {
        vm.toast = message;
        $timeout(function () {
          vm.toast = "";
        }, 3000);
      }
      var iconTimer;
      function redraw() {
        if (iconTimer) $timeout.cancel(iconTimer);
        iconTimer = $timeout(function () {
          if (window.lucide)
            window.lucide.createIcons({ attrs: { "stroke-width": 1.8 } });
        }, 0, false);
      }
      function loadDashboard() {
        $http.get("api/portfolio/dashboard").then(function (response) {
          var data = response.data;
          if (data.projects && data.projects.length) {
            vm.demo = false;
            vm.metrics = data.metrics[0];
            vm.projects = data.projects;
            vm.budgets = data.budgets;
            vm.jira = data.jira;
            vm.budgetUsage = data.budgetUsage || [];
            prepareProjects();
            vm.updateView();
          }
          redraw();
        }, redraw);
      }
      prepareProjects();
      vm.updateView();
      redraw();
    });
})();
