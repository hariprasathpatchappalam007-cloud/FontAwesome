using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("DFM.Web")]
[assembly: AssemblyCompany("DFM")]
[assembly: AssemblyProduct("Digital Finance Management")]
[assembly: ComVisible(false)]
[assembly: Guid("6a26c456-ee74-4fa5-a56b-3d0d8a989e17")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
