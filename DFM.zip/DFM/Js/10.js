<script> (function(){ var CONFIG={ confluenceBaseUrl:window.location.origin+"/collaboration", jiraBaseUrl:"https://agile.dib.ae/planner", referencePageId:"178734163", jiraPageSize:100, maxJiraPages:50, demandKeyRegex:/^(DMGT|IDC)-\d+$/i, demandKeyExtractRegex:/(DMGT|IDC)-\d+/gi, configKeys:{filterId:"FilterID",supportingDemand:"Supporting Demand"} };/* ===== Dashboard parameters - change here for future maintenance ===== */var GOVERNANCE_CONFIG={  baseline0AgeRiskDays:60,  defaultStatusGroups:{    "Backlog":true,    "Under Discussion":true,    "Baseline 0":true,    "Baseline 1":true,    "Other":true,    "Completed":false,    /*"Dropped / Cancelled"*/"On Hold":false  },  reviewStatuses:{    ae:"ACCOUNTABLE EXECUTIVE REVIEW",    tech:"TECHNOLOGY REVIEW"  },  reviewSlaDays:{    accountableExecutiveReview:4,    technologyReview:{XS:4,SR:4,S:5,M:6,L:8,XL:8,defaultDays:4}  },  liveCompletedStatuses:[    "Live",    "Completed",    "Live - Pending Business Feedback",    "Live – Pending Business Feedback"  ],  baseline1Statuses:[    "Execution-Delivery (Baseline 1)",    "Approved for Baseline 1"  ],  goLiveMonthsToShow:6,  jiraBrowsePath:"/browse/",  defaultTheme:"light",  governanceLiveBoard:{    cardsPerPage:1,    autoRotateMs:5500,    upcomingPickupDays:7,    topItemsToShow:3,    completedLookbackDays:7  },  capacityHeatmap:{    displayGroups:["Backlog","Under Discussion","Baseline 0","Baseline 1"],    pressureGroups:["Under Discussion","Baseline 0","Baseline 1"],    sizeAllocation:{XS:10,SR:10,S:20,M:50,L:100,XL:100,defaultAllocation:50},    supportingAllocation:{mode:"bySize",fixedDefault:50,bySize:{XS:10,SR:10,S:20,M:50,L:100,XL:100,defaultAllocation:50}},    pressureBands:{greenMax:50,amberMax:90,redMax:100}  },  activityCalendar:{    baseline0:["Scope","ITA","Cost Approval","Plan"],    baseline1:["Develop","ITQA","UAT","Staging","Go Live"],    aliases:{      "Develop":["Develop","Development"],      "Stagin":["Stagin","Staging"]    }  }}; var DESIGN_FIELDS={ key:"Key", summary:"Summary", status:"Status", sme:"SME Lead", platform:"Platform", aeLead:"Accountable Executive Lead", pm:"Assigned Project Manager", size:"Size", segment:"Demand Segment", projectGoLive:"Project Execution Go Live", portfolioSummary:"Portfolio Executive Summary", requirement:"Requirement", issueType:"Issue Type", transitionDays:"Days since Last Transition", actualGoLive:"Actual Go-Live Date", proposedPickupDate:"Proposed Demand Pick-up Date", plannedStart:"Planned Start", plannedEnd:"Planned End", actualStartDate:"Actual Start Date", actualEndDate:"Actual End Date" }; var FIELD_MAP={}; var governanceExpanded=true;var activeTab="dashboard";var dashboardTheme=GOVERNANCE_CONFIG.defaultTheme||"light";var JIRA_BROWSE_URL = CONFIG.jiraBaseUrl + GOVERNANCE_CONFIG.jiraBrowsePath;
 
var CONFLUENCE_Page_URL = "http://agile.dib.ae/collaboration/display/DUUTH/Demand-Page?key=";
 
var ALL_DEMANDS=[]; var LINKED_EXECUTION_ISSUES={}; var LINKED_PHASE_ISSUES={}; var LINKED_ACTIVITY_ISSUES={}; var PROJECT_PHASE_ACTIVITIES={}; var SUPPORTING_DEMAND_SME_MAP={}; var DISPLAY_RECORDS=[]; var selectedType="ALL"; var selectedSme="ALL"; var selectedPlatforms={}; var selectedAeLead="ALL"; var selectedReviewStatus=""; var selectedSearch=""; var selectedGoLiveMonth=""; var sortColumn="key"; var sortDirection="ASC"; var selectedStatusGroups=JSON.parse(JSON.stringify(GOVERNANCE_CONFIG.defaultStatusGroups)); var governanceBoardPage=0; var governanceBoardTimer=null; var governanceBoardPaused=false; var progressDiv=document.getElementById("dashboardProgress"); var root=document.getElementById("portfolioView"); function esc(v){
try{
  var amp=String.fromCharCode(38);
  return String(v==null?"":v)
   .replace(/&/g,amp+"amp;")
   .replace(/</g,amp+"lt;")
   .replace(/>/g,amp+"gt;")
   .replace(/"/g,amp+"quot;")
   .replace(/'/g,amp+"#39;");
}catch(e){return "";}
} window.onerror=function(message,source,lineno,colno,error){ if(progressDiv){progressDiv.innerHTML+="<div style='color:#ef4444'>JS ERROR: "+esc(message)+" | Line: "+lineno+" | Column: "+colno+"</div>";} return false; }; function logProgress(message,type){ var color="#dbeafe"; if(type==="INFO")color="#38bdf8"; if(type==="SUCCESS")color="#22c55e"; if(type==="ERROR")color="#ef4444"; if(type==="WARN")color="#facc15"; progressDiv.innerHTML+="<div style='color:"+color+"'>["+new Date().toLocaleTimeString()+"] "+esc(message)+"</div>"; progressDiv.scrollTop=progressDiv.scrollHeight; } function fail(fn,err){ var msg=err&&err.message?err.message:String(err); logProgress("FAILED in "+fn+" : "+msg,"ERROR"); throw new Error(fn+" failed: "+msg); } function clean(v){return String(v||"").replace(/\u00a0/g," ").trim();} function normalize(v){return clean(v).toLowerCase().replace(/\s+/g," ");} function unique(arr){var seen={},out=[],i;for(i=0;i<arr.length;i++){if(arr[i]&&!seen[arr[i]]){seen[arr[i]]=true;out.push(arr[i]);}}return out;} function getTableMatrix(table){ var rows=table.querySelectorAll("tr"),matrix=[],i,j,cells,rowData; for(i=0;i<rows.length;i++){ cells=rows[i].querySelectorAll("td,th");rowData=[]; for(j=0;j<cells.length;j++){rowData.push(clean(cells[j].innerText||cells[j].textContent));} matrix.push(rowData); } return matrix; } function findHeaderRow(matrix,h1,h2){
var r,c,row,f1,f2;
for(r=0;r<matrix.length;r++){
   row=matrix[r]||[];
   f1=false;f2=false;
   for(c=0;c<row.length;c++){
     if(normalize(row[c])===normalize(h1))f1=true;
     if(normalize(row[c])===normalize(h2))f2=true;
   }
   if(f1&&f2)return r;
}
return -1;
}
function tableHasHeaders(table,h1,h2){
var m=getTableMatrix(table);
return findHeaderRow(m,h1,h2)>=0;
} function extractIssueKeys(text){ var matches=String(text||"").match(CONFIG.demandKeyExtractRegex||/(DMGT|IDC)-\d+/gi); var out=[],i; if(!matches)return[]; for(i=0;i<matches.length;i++){out.push(String(matches[i]).toUpperCase());} return unique(out); } /* ===== Core Jira / Confluence helpers ===== */function readReferencePage(){ var url=CONFIG.confluenceBaseUrl+"/rest/api/content/"+CONFIG.referencePageId+"?expand=body.view"; logProgress("Reading Confluence reference page","INFO"); return fetch(url,{method:"GET",credentials:"same-origin",headers:{"Accept":"application/json"}}) .then(function(res){logProgress("Confluence HTTP Status: "+res.status,"INFO");if(!res.ok)throw new Error("Confluence API HTTP "+res.status);return res.json();}) .then(function(data){if(!data.body||!data.body.view||!data.body.view.value)throw new Error("Missing body.view.value");logProgress("Reference page read successfully","SUCCESS");return data.body.view.value;}) .catch(function(err){fail("readReferencePage",err);}); } function parseReferenceConfig(html){
var doc=new DOMParser().parseFromString(html,"text/html");
var tables=doc.querySelectorAll("table");
var configTable=null,matrix,result,i,r,prop,val,m;
result={filterId:"",supportingDemandIds:[],supportingDemandSmeMap:{}};
for(i=0;i<tables.length;i++){
   if(tableHasHeaders(tables[i],"Property","Value")){configTable=tables[i];break;}
}
if(!configTable)throw new Error("Configuration table not found. Expected Property | Value");
matrix=getTableMatrix(configTable);
for(r=1;r<matrix.length;r++){
   if(matrix[r].length<2)continue;
   prop=clean(matrix[r][0]);
   val=clean(matrix[r].slice(1).join(" "));
   if(normalize(prop)===normalize(CONFIG.configKeys.filterId)){
     m=val.match(/\d+/);
     result.filterId=m?m[0]:val;
   }
   if(normalize(prop)===normalize(CONFIG.configKeys.supportingDemand)){
     result.supportingDemandIds=extractIssueKeys(val);
     logProgress("Supporting Demand IDs from property row: "+result.supportingDemandIds.join(", "),"SUCCESS");
   }
}
for(i=0;i<tables.length;i++){
   if(tableHasHeaders(tables[i],"Demand Key","Supporting SME")){
     matrix=getTableMatrix(tables[i]);
     var headerRow=findHeaderRow(matrix,"Demand Key","Supporting SME");
     var header=matrix[headerRow]||[], demandCol=-1, smeCol=-1, c, demandKey, smeName;
     for(c=0;c<header.length;c++){
       if(normalize(header[c])===normalize("Demand Key"))demandCol=c;
       if(normalize(header[c])===normalize("Supporting SME"))smeCol=c;
     }
     if(demandCol>=0 && smeCol>=0){
       for(r=headerRow+1;r<matrix.length;r++){
         demandKey=clean(matrix[r][demandCol]||"").toUpperCase();
         smeName=cleanSmeName(matrix[r][smeCol]||"");
         if((CONFIG.demandKeyRegex||/^(DMGT|IDC)-\d+$/i).test(demandKey) || /(DMGT|IDC)-\d+/i.test(demandKey)){
           demandKey=(demandKey.match(CONFIG.demandKeyExtractRegex||/(DMGT|IDC)-\d+/gi)||[demandKey])[0].toUpperCase();
           result.supportingDemandIds.push(demandKey);
           if(smeName){addSupportingSme(result.supportingDemandSmeMap,demandKey,smeName);}
         }
       }
       logProgress("Supporting Demand IDs read from SME mapping table: "+result.supportingDemandIds.length,"SUCCESS");
     }
   }
}
result.supportingDemandIds=unique(result.supportingDemandIds);
if(!result.filterId)throw new Error("FilterID not found in reference table");
logProgress("FilterID: "+result.filterId,"SUCCESS");
logProgress("Supporting Demand IDs total: "+result.supportingDemandIds.length,"SUCCESS");
logProgress("Supporting Demand SME mappings: "+Object.keys(result.supportingDemandSmeMap).length,"SUCCESS");
return result;
} function readJiraFieldCatalog(){ var url=CONFIG.jiraBaseUrl+"/rest/api/2/field"; logProgress("Reading Jira field catalog","INFO"); return fetch(url,{method:"GET",credentials:"include",headers:{"Accept":"application/json"}}) .then(function(res){logProgress("Jira Field API HTTP Status: "+res.status,"INFO");if(!res.ok)throw new Error("Jira Field API HTTP "+res.status);return res.json();}) .then(function(fields){logProgress("Jira fields retrieved: "+fields.length,"SUCCESS");return fields;}) .catch(function(err){fail("readJiraFieldCatalog",err);}); } function buildFieldMap(jiraFields){ var required=[ DESIGN_FIELDS.summary,DESIGN_FIELDS.status,DESIGN_FIELDS.sme,DESIGN_FIELDS.platform, DESIGN_FIELDS.aeLead,DESIGN_FIELDS.pm,DESIGN_FIELDS.size,DESIGN_FIELDS.segment, DESIGN_FIELDS.projectGoLive,DESIGN_FIELDS.portfolioSummary,DESIGN_FIELDS.requirement,DESIGN_FIELDS.issueType,DESIGN_FIELDS.transitionDays,DESIGN_FIELDS.actualGoLive,DESIGN_FIELDS.proposedPickupDate,DESIGN_FIELDS.plannedStart,DESIGN_FIELDS.plannedEnd,DESIGN_FIELDS.actualStartDate,DESIGN_FIELDS.actualEndDate ]; var systemFields={"Key":"key","Summary":"summary","Status":"status","Issue Type":"issuetype"}; var map={},i,j,name,found; for(i=0;i<required.length;i++){ name=required[i]; if(systemFields[name]){map[name]=systemFields[name];continue;} found=null; for(j=0;j<jiraFields.length;j++){ if(jiraFields[j].name&&normalize(jiraFields[j].name)===normalize(name)){found=jiraFields[j];break;} } if(found){map[name]=found.id;logProgress("Mapped field: "+name+" -> "+found.id,"SUCCESS");} else{logProgress("Field not found in Jira: "+name,"WARN");} } return map; } function getJiraFields(){ var fields=["summary","status","issuetype","issuelinks","created"],k,id; for(k in FIELD_MAP){ if(FIELD_MAP.hasOwnProperty(k)){ id=FIELD_MAP[k]; if(id&&id!=="key"&&fields.indexOf(id)<0){fields.push(id);} } } return fields.join(","); } function jiraSearchAll(jql,fields){ var all=[],startAt=0,pageNo=0; function fetchPage(){   pageNo++;   if(pageNo>CONFIG.maxJiraPages){     logProgress("Stopped after max Jira pages: "+CONFIG.maxJiraPages,"WARN");     return Promise.resolve(all);   }   var url=CONFIG.jiraBaseUrl+"/rest/api/2/search";   var body={     jql:jql,     startAt:startAt,     maxResults:CONFIG.jiraPageSize,     fields:String(fields||"").split(",").filter(function(x){return x;})   };   logProgress("Reading Jira page "+pageNo+" | startAt="+startAt+" | "+jql,"INFO");   return fetch(url,{     method:"POST",     credentials:"include",     headers:{"Accept":"application/json","Content-Type":"application/json"},     body:JSON.stringify(body)   })   .then(function(res){     if(!res.ok)throw new Error("Jira Search HTTP "+res.status+" | "+jql);     return res.json();   })   .then(function(data){     var issues=data.issues||[];     var total=data.total||0;     all=all.concat(issues);     logProgress("Loaded "+all.length+" of "+total+" for "+jql,"SUCCESS");     if(issues.length===0)return all;     startAt=startAt+issues.length;     if(startAt<total)return fetchPage();     return all;   }); } return fetchPage().catch(function(err){fail("jiraSearchAll",err);});}function jiraSearchKeysInBatches(keys,fields,label){
keys=unique(keys||[]);
var batchSize=35;
var batches=[];
var i;
for(i=0;i<keys.length;i+=batchSize){batches.push(keys.slice(i,i+batchSize));}
logProgress((label||"Issue")+" key fetch batches: "+batches.length+" | total keys: "+keys.length,"INFO");
function quoteJqlKey(k){return '"'+String(k||"").replace(/"/g,'')+'"';}
function fetchIssueDirect(key){
   var fieldList=String(fields||"").split(",").filter(function(x){return x;});
   var url=CONFIG.jiraBaseUrl+"/rest/api/2/issue/"+encodeURIComponent(key)+"?fields="+encodeURIComponent(fieldList.join(","));
   logProgress((label||"Issue")+" direct fetch fallback: "+key,"WARN");
   return fetch(url,{method:"GET",credentials:"include",headers:{"Accept":"application/json"}})
     .then(function(res){
       if(!res.ok){
         logProgress((label||"Issue")+" direct fetch failed: "+key+" | HTTP "+res.status,"ERROR");
         return null;
       }
       return res.json();
     })
     .then(function(issue){return issue&&issue.key?issue:null;})
     .catch(function(err){
       logProgress((label||"Issue")+" direct fetch error: "+key+" | "+err.message,"ERROR");
       return null;
     });
}
var chain=Promise.resolve([]);
batches.forEach(function(batch,idx){
   chain=chain.then(function(all){
     var jql="key in ("+batch.map(quoteJqlKey).join(",")+")";
     logProgress((label||"Issue")+" batch "+(idx+1)+"/"+batches.length+" | keys: "+batch.join(", "),"INFO");
     return jiraSearchAll(jql,fields).then(function(issues){return all.concat(issues);});
   });
});
return chain.then(function(issues){
   var found={},missing=[],i,key;
   for(i=0;i<issues.length;i++){
     if(issues[i]&&issues[i].key){found[String(issues[i].key).toUpperCase()]=true;}
   }
   for(i=0;i<keys.length;i++){
     key=String(keys[i]||"").toUpperCase();
     if(key&&!found[key])missing.push(key);
   }
   if(!missing.length)return issues;
   logProgress((label||"Issue")+" missing after JQL key search: "+missing.join(", ")+". Trying direct issue fetch.","WARN");
   var direct=Promise.resolve([]);
   missing.forEach(function(k){
     direct=direct.then(function(list){
       return fetchIssueDirect(k).then(function(issue){
         if(issue)list.push(issue);
         return list;
       });
     });
   });
   return direct.then(function(extra){
     logProgress((label||"Issue")+" direct fallback loaded: "+extra.length+" of "+missing.length,"SUCCESS");
     return issues.concat(extra);
   });
    });
} function mergeDemandSourceRows(rows) {
    var map = {}, out = [], i, row, key, existing, source;
    for (i = 0; i < rows.length; i++) {
        row = rows[i];
        if (!row || !row.issue || !row.issue.key) continue;
        key = String(row.issue.key || "").toUpperCase();
        source = row.sourceType || "Vertical";
        if (!map[key]) {
            map[key] = { sourceType: source, issue: row.issue, isSupportingDemand: false, isVertical: false };
            out.push(map[key]);
        }
        existing = map[key];
        if (source === "Vertical") {
            existing.isVertical = true;
            existing.issue = row.issue;
            existing.sourceType = existing.isSupportingDemand ? "Vertical" : "Vertical";
        }
        if (source === "Supporting Demand") {
            existing.isSupportingDemand = true;
            if (!existing.isVertical) {
                existing.sourceType = "Supporting Demand";
                existing.issue = row.issue;
            }
        }
        if (SUPPORTING_DEMAND_SME_MAP[key]) { existing.isSupportingDemand = true; }
    }
    logProgress("Merged demand rows after de-duplication: " + out.length, "SUCCESS");
    return out;
}
function fetchDemandData(config) { var fields = getJiraFields(); var verticalJql = "filter=" + config.filterId; var vp, sp; vp = jiraSearchAll(verticalJql, fields).then(function (issues) { var out = [], i; for (i = 0; i < issues.length; i++) { out.push({ sourceType: "Vertical", issue: issues[i] }); } return out; }); if (config.supportingDemandIds.length) { sp = jiraSearchKeysInBatches(config.supportingDemandIds, fields, "Supporting Demand").then(function (issues) { var out = [], i; for (i = 0; i < issues.length; i++) { out.push({ sourceType: "Supporting Demand", issue: issues[i] }); } return out; }); } else { sp = Promise.resolve([]); } return Promise.all([vp, sp]).then(function (results) { logProgress("Verticals: " + results[0].length, "SUCCESS"); logProgress("Supporting Demands fetched: " + results[1].length, "SUCCESS"); return mergeDemandSourceRows(results[0].concat(results[1])); }); }
function formatValue(v) { var list = [], i; if (v == null) return ""; if (typeof v === "string" || typeof v === "number") return v; if (v.displayName) return v.displayName; if (v.name) return v.name; if (v.value) return v.value; if (Object.prototype.toString.call(v) === "[object Array]") { for (i = 0; i < v.length; i++) { list.push(formatValue(v[i])); } return list.join(", "); } try { return JSON.stringify(v); } catch (e) { return ""; } } function getIssueValue(issue, displayName) { var fieldId = FIELD_MAP[displayName]; var f = issue.fields || {}; if (displayName === "Key") return issue.key; if (fieldId === "summary") return f.summary || ""; if (fieldId === "status") return f.status ? f.status.name : ""; if (fieldId === "issuetype") return f.issuetype ? f.issuetype.name : ""; if (!fieldId) return ""; return formatValue(f[fieldId]); } function getLinkedIssueKeysFromDemand(demandIssue) { var links = demandIssue.fields && demandIssue.fields.issuelinks ? demandIssue.fields.issuelinks : []; var demandType = getIssueValue(demandIssue, DESIGN_FIELDS.issueType); var keys = [], i, li, candidate, typeName; for (i = 0; i < links.length; i++) { li = links[i]; candidate = null; if (li.outwardIssue) candidate = li.outwardIssue; if (!candidate && li.inwardIssue) candidate = li.inwardIssue; if (candidate && candidate.key) { typeName = candidate.fields && candidate.fields.issuetype ? candidate.fields.issuetype.name : ""; if (typeName === "Project") { keys.push(candidate.key); } if (demandType === "Service Request" && typeName === "Service Request") { keys.push(candidate.key); } } } return unique(keys); } function fetchLinkedExecutionIssues(demandRows) { var allKeys = [], i, keys, j, fields; for (i = 0; i < demandRows.length; i++) { keys = getLinkedIssueKeysFromDemand(demandRows[i].issue); for (j = 0; j < keys.length; j++) { allKeys.push(keys[j]); } } allKeys = unique(allKeys); logProgress("Linked Project/SR issue keys found: " + allKeys.length, "INFO"); if (!allKeys.length) { return Promise.resolve({}); } fields = getJiraFields(); return jiraSearchKeysInBatches(allKeys, fields, "Linked Project/SR").then(function (issues) { var map = {}, i; for (i = 0; i < issues.length; i++) { map[issues[i].key] = issues[i]; } logProgress("Linked Project/SR issues loaded: " + issues.length, "SUCCESS"); return map; }); } function getLinkedIssueKeysByType(issue, typeName) { var links = issue && issue.fields && issue.fields.issuelinks ? issue.fields.issuelinks : []; var keys = [], i, li, candidate, cType; for (i = 0; i < links.length; i++) { li = links[i]; candidate = null; if (li.outwardIssue) candidate = li.outwardIssue; if (!candidate && li.inwardIssue) candidate = li.inwardIssue; if (candidate && candidate.key) { cType = candidate.fields && candidate.fields.issuetype ? candidate.fields.issuetype.name : ""; if (normalize(cType) === normalize(typeName)) keys.push(candidate.key); } } return unique(keys); } function fetchPhaseAndActivityData(linkedExecutionMap) { PROJECT_PHASE_ACTIVITIES = {}; LINKED_PHASE_ISSUES = {}; LINKED_ACTIVITY_ISSUES = {}; logProgress('Initial Phase / Activity loading skipped. Activities are fetched only when P popup or expansion is clicked.', 'INFO'); return Promise.resolve(); } function classifyPhase(issue) { var text = (getIssueValue(issue, DESIGN_FIELDS.summary) + " " + getIssueValue(issue, DESIGN_FIELDS.status)).toLowerCase(); if (text.indexOf("baseline 0") >= 0 || text.indexOf("initiation") >= 0 || text.indexOf("pipeline") >= 0) return "baseline0"; if (text.indexOf("baseline 1") >= 0 || text.indexOf("execution") >= 0 || text.indexOf("delivery") >= 0 || text.indexOf("commitment") >= 0) return "baseline1"; return "other"; } function buildProjectPhaseActivities() { PROJECT_PHASE_ACTIVITIES = {}; } function getActivitiesForProject(projectKey) { return PROJECT_PHASE_ACTIVITIES[projectKey] || []; } function firstNonBlank(a, b) { if (a !== null && a !== undefined && String(a) !== "") return a; return b || ""; } function isLiveOrCompletedStatus(status) { var s = String(status || "").trim(); return GOVERNANCE_CONFIG.liveCompletedStatuses.indexOf(s) >= 0; } function resolveGoLiveDate(demand, linked, status) { var demandActual = getIssueValue(demand, DESIGN_FIELDS.actualGoLive); var linkedActual = getIssueValue(linked, DESIGN_FIELDS.actualGoLive); var projectExecution = getIssueValue(linked, DESIGN_FIELDS.projectGoLive); if (isLiveOrCompletedStatus(status)) { return firstNonBlank(demandActual, firstNonBlank(linkedActual, projectExecution)); } return firstNonBlank(projectExecution, firstNonBlank(demandActual, linkedActual)); } function resolveJiraSmeLead(jiraSme) { return cleanSmeName(jiraSme); } function resolveSupportingSmeLead(demandKey) { var key = String(demandKey || "").toUpperCase(); return toSmeArray(SUPPORTING_DEMAND_SME_MAP[key]); } function isSupportingDemandKey(demandKey) { return !!SUPPORTING_DEMAND_SME_MAP[String(demandKey || "").toUpperCase()]; } function buildDisplayRecords() { var out = [], i, demandRow, demand, keys, linkedIssue, row, j; for (i = 0; i < ALL_DEMANDS.length; i++) { demandRow = ALL_DEMANDS[i]; demand = demandRow.issue; keys = getLinkedIssueKeysFromDemand(demand); if (!keys.length) { row = mergeDemandAndLinked(demandRow, null); out.push(row); } else { for (j = 0; j < keys.length; j++) { linkedIssue = LINKED_EXECUTION_ISSUES[keys[j]]; row = mergeDemandAndLinked(demandRow, linkedIssue); out.push(row); } } } DISPLAY_RECORDS = out; logUnmappedStatusSummary(); } function logUnmappedStatusSummary() { var seen = {}, i, p, s; for (i = 0; i < DISPLAY_RECORDS.length; i++) { p = DISPLAY_RECORDS[i]; if (getGroupedStatus(p.status) === "Other") { s = String(p.status || "Blank Status").trim() || "Blank Status"; if (!seen[s]) { seen[s] = true; logProgress("Other status mapped: " + s, "WARN"); } } } } function mergeDemandAndLinked(demandRow, linkedIssue) {
    var demand = demandRow.issue; var linked = linkedIssue || { fields: {} }; var finalStatus = firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.status), getIssueValue(linked, DESIGN_FIELDS.status)); var jiraSme = resolveJiraSmeLead(firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.sme), getIssueValue(linked, DESIGN_FIELDS.sme))); var supportingSme = resolveSupportingSmeLead(demand.key); return {
        key: demand.key, linkedKey: linkedIssue ? linkedIssue.key : "", demandIssueType: getIssueValue(demand, DESIGN_FIELDS.issueType), linkedIssueType: linkedIssue ? getIssueValue(linked, DESIGN_FIELDS.issueType) : "", summary: getIssueValue(demand, DESIGN_FIELDS.summary), status: finalStatus, type: demandRow.sourceType, isSupportingDemand: !!(demandRow.isSupportingDemand || isSupportingDemandKey(demand.key)), platform: firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.platform), getIssueValue(linked, DESIGN_FIELDS.platform)), lead: firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.aeLead), getIssueValue(linked, DESIGN_FIELDS.aeLead)), pm: cleanSmeName(firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.pm), getIssueValue(linked, DESIGN_FIELDS.pm))), sme: jiraSme, supportingSme: supportingSme.join(", "), supportingSmes: supportingSme, size: firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.size), getIssueValue(linked, DESIGN_FIELDS.size)), segment: firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.segment), getIssueValue(linked, DESIGN_FIELDS.segment)), goLive: resolveGoLiveDate(demand, linked, finalStatus), pickupDate: firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.proposedPickupDate), getIssueValue(linked, DESIGN_FIELDS.proposedPickupDate)), created: demand.fields.created || "", queueDays: firstNonBlank(getIssueValue(demand, DESIGN_FIELDS.transitionDays), getIssueValue(linked, DESIGN_FIELDS.transitionDays)), portfolioSummary: getIssueValue(linked, DESIGN_FIELDS.portfolioSummary),
        requirement: getIssueValue(demand, DESIGN_FIELDS.requirement), activities: linkedIssue ? getActivitiesForProject(linkedIssue.key) : []
    };
} var STATUS_GROUPS = { "Backlog": ["Tech No Capacity"], "Under Discussion": ["Lean AE Review", "ACCOUNTABLE EXECUTIVE REVIEW", "DO INCOMPLETE / ADDL. INFO REQUIRED", "TECHNOLOGY REVIEW", "ADDL INFO Required - SR", "IT BP REVIEW", "BRD Preparation by Business", "DO - BRD PREPARATION - STRATEGIC", "DO PRESENTATION", "ADDL INFO REQUIRED - STRATEGIC", "Doability - Addl.Info", "Doability – Addl.Info", "BRMO Phase", "IDH Portfolio Review", "IDH Head Review", "IT DAg Review", "IT DAG Review", "ADDL INFO Required_Fast Track", "Fast TRack.ADDL INFO Required"], "Baseline 0": ["Initiation-Pipeline (Baseline 0)"], "Baseline 1": ["Execution-Delivery (Baseline 1)", "Approved for Baseline 1"], "Completed": ["Live", "Completed", "Live - Pending Business Feedback", "Live – Pending Business Feedback"], /*"Dropped / Cancelled"*/"On Hold": ["Demand On Hold"]/*["Cancelled","Deferred","Demand On Hold","Dropped"]*/ }; function baseRecords() { var out = [], i, p; for (i = 0; i < DISPLAY_RECORDS.length; i++) { p = DISPLAY_RECORDS[i]; if (selectedType !== "ALL" && p.type !== selectedType) { continue; } if (selectedAeLead !== "ALL" && p.lead !== selectedAeLead) { continue; } out.push(p); } return out; } function fullyFilteredRecords() { var records = baseRecords(); var out = [], i, p, g; for (i = 0; i < records.length; i++) { p = records[i]; g = getGroupedStatus(p.status); if (selectedReviewStatus && p.status !== selectedReviewStatus) continue; if (!selectedReviewStatus && !selectedStatusGroups[g]) continue; if (selectedGoLiveMonth && (g !== "Completed" || getMonthKey(p.goLive) !== selectedGoLiveMonth)) continue; if (selectedSme !== "ALL" && !recordHasSme(p, selectedSme)) continue; if (hasSelectedPlatforms() && !recordMatchesSelectedPlatforms(p)) continue; if (!matchesSearch(p)) continue; out.push(p); } return out; } function matchesSearch(record) { if (!selectedSearch) return true; var q = String(selectedSearch || "").toLowerCase(); var combined = [record.key, record.summary, record.status, getGroupedStatus(record.status), record.platform, record.lead, record.sme, supportingSmeText(record), record.pm, record.size, record.segment, record.goLive, record.pickupDate, formatDateOnly(record.created), formatDateOnly(record.pickupDate), record.portfolioSummary].join(" ").toLowerCase(); return combined.indexOf(q) >= 0; } function projectRecords() { return sortRecords(fullyFilteredRecords()); } function countType(type) { var c = 0, i, p; for (i = 0; i < DISPLAY_RECORDS.length; i++) { p = DISPLAY_RECORDS[i]; if (selectedAeLead !== "ALL" && p.lead !== selectedAeLead) { continue; } if (type === "ALL" || p.type === type) { c++; } } return c; } function countGroup(name) { var records = baseRecords(); var c = 0, i; for (i = 0; i < records.length; i++) {
    if (getGroupedStatus(records[i].status) === name) { c++; }
} return c;
} function statusClass(name) { if (name === "Backlog") return "red"; if (name === "Under Discussion") return "orange"; if (name === "Baseline 0") return "blue"; if (name === "Baseline 1") return "green"; if (name === "Completed") return "sky"; return "gray"; } function getGroupedStatus(status) { var group, statuses, i, raw, norm; raw = String(status || "").trim(); norm = raw.toLowerCase(); for (group in STATUS_GROUPS) { if (STATUS_GROUPS.hasOwnProperty(group)) { statuses = STATUS_GROUPS[group]; for (i = 0; i < statuses.length; i++) { if (norm === String(statuses[i] || "").trim().toLowerCase()) return group; } } } return "Other"; } function getGroupedStatusClass(status) { var group = getGroupedStatus(status); if (group === "Backlog") return "pill-red"; if (group === "Under Discussion") return "pill-orange"; if (group === "Baseline 0") return "pill-blue"; if (group === "Baseline 1") return "pill-green"; if (group === "Completed") return "pill-blue"; if (group === "On Hold" /*"Dropped / Cancelled"*/) return "pill-gray"; return "pill-gray"; } function countStatusExact(statusName) { var records = baseRecords(); var c = 0, i; for (i = 0; i < records.length; i++) { if (records[i].status === statusName) { c++; } } return c; } function parseDateValue(dateValue) { if (!dateValue) return null; var d = new Date(dateValue); if (isNaN(d.getTime())) return null; return d; } function todayMidnight() { var n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime(); } function isBaseline1Status(status) { var s = String(status || "").trim(); return GOVERNANCE_CONFIG.baseline1Statuses.indexOf(s) >= 0 || getGroupedStatus(s) === "Baseline 1"; } function isGoLiveDelayed(record) { if (!isBaseline1Status(record.status)) return false; if (isLiveOrCompletedStatus(record.status)) return false; var d = parseDateValue(record.goLive); if (!d) return false; var goLiveMidnight = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); return goLiveMidnight < todayMidnight(); } function goLiveHtml(record) { var displayDate = formatDateOnly(record.goLive); if (!displayDate) return ""; if (isGoLiveDelayed(record)) { return "<span class='golive-delayed'><span class='golive-delayed-label'>Go Live Delayed"</span > +esc(displayDate) + ""</span >; } return "<span class='golive-normal'>" + esc(displayDate) + ""</span >; } function formatDateOnly(dateValue) { if (!dateValue) return ""; var d = new Date(dateValue); if (isNaN(d.getTime())) return ""; var day = d.getDate(); var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]; var month = monthNames[d.getMonth()]; var year = d.getFullYear(); return (day < 10 ? "0" + day : day) + "-" + month + "-" + year; } function ageDays(dateValue) { if (!dateValue) return 0; var d = new Date(dateValue); if (isNaN(d.getTime())) return 0; var now = new Date(); var diff = now.getTime() - d.getTime(); return Math.floor(diff / (1000 * 60 * 60 * 24)); } function ageText(dateValue) { var days = ageDays(dateValue); if (days <= 0) return ""; if (days < 30) return days + " days"; var months = Math.floor(days / 30); var rem = days % 30; if (months < 12) { return months + " mo" + (rem > 0 ? " " + rem + " d" : ""); } var years = Math.floor(months / 12); var remMonths = months % 12; return years + " yr" + (remMonths > 0 ? " " + remMonths + " mo" : ""); } function isBaseline0Aged(record) { var group = getGroupedStatus(record.status); var days = ageDays(record.created); return group === "Baseline 0" && days > GOVERNANCE_CONFIG.baseline0AgeRiskDays; } function numericDays(v) { var m = String(v || "").match(/\d+/); return m ? parseInt(m[0], 10) : 0; } function isReviewQueueStatus(status) { var s = String(status || "").toUpperCase(); return s === GOVERNANCE_CONFIG.reviewStatuses.tech || s === GOVERNANCE_CONFIG.reviewStatuses.ae; } function normalizeSize(sizeValue) { var s = String(sizeValue || "").toLowerCase(); s = s.replace(/-/g, " "); s = s.replace(/\s+/g, " ").trim(); if (s === "xs" || s.indexOf("xtra small") >= 0 || s.indexOf("extra small") >= 0 || s.indexOf("x small") >= 0) { return "XS"; } if (s === "sr" || s.indexOf("service request") >= 0) { return "SR"; } if (s === "xl" || s.indexOf("xtra large") >= 0 || s.indexOf("extra large") >= 0 || s.indexOf("x large") >= 0 || s === "x large") { return "XL"; } if (s === "s" || s === "small" || s.indexOf(" small") >= 0) { return "S"; } if (s === "m" || s === "medium" || s.indexOf("medium") >= 0) { return "M"; } if (s === "l" || s === "large" || s.indexOf("large") >= 0) { return "L"; } return ""; } function reviewSlaDays(record) { var status = String(record.status || "").toUpperCase(); var size = normalizeSize(record.size); var sla = GOVERNANCE_CONFIG.reviewSlaDays; if (status === GOVERNANCE_CONFIG.reviewStatuses.ae) { return sla.accountableExecutiveReview; } if (status === GOVERNANCE_CONFIG.reviewStatuses.tech) { return sla.technologyReview[size] || sla.technologyReview.defaultDays; } return 0; } function queueClass(days, sla) { if (!sla) return "queue-ok"; if (days > sla) return "queue-risk"; if (days === sla) return "queue-warn"; return "queue-ok"; } function pickupDateHtml(record) {
    var d = parseDateValue(record.pickupDate); if (!d) {
        return "<div><span class='age-normal'>" + esc(formatDateOnly(record.created)) + "
        "+esc(ageText(record.created))+" < div class='pickup-muted' > No pickup date</div ></div > "</span>; } var pickupMidnight=new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime(); if(pickupMidnight<todayMidnight()){   return " < div > <span class='pickup-overdue'><span class='pickup-label'>Pickup Overdue"</span>+esc(formatDateOnly(record.pickupDate))+"</div>"</span>; } return " < div > <span class='pickup-target'><span class='pickup-label'>Pickup Target"</span>+esc(formatDateOnly(record.pickupDate))+"</div>"</span>;}function ageQueueHtml(record){ var hasQueueValue=String(record.queueDays||"").match(/\d+/); var days=numericDays(record.queueDays); var sla=reviewSlaDays(record); if(getGroupedStatus(record.status)==="Backlog"){   return pickupDateHtml(record); } if(isReviewQueueStatus(record.status)){   if(!hasQueueValue){     return " < div > <span class='queue-warn'>In Queue
No data<div class='queue-muted'>SLA: "</span>+esc(sla+" days")+"</div></div > ";   }   var cls=queueClass(days,sla);   var label=days>sla?"SLA Breached":"In Queue";   return " < div > <span class='"+cls+"'>"+esc(label)+"
"+esc(days+" days")+"<div class='queue-muted'>SLA: "</span>+esc(sla+" days")+"</div></div > "; } if(isBaseline0Aged(record)){   return " < div > <span class='age-risk'>"+esc(formatDateOnly(record.created))+"
"+esc(ageText(record.created))+"</div>"</span>; } return " < div > <span class='age-normal'>"+esc(formatDateOnly(record.created))+"
"+esc(ageText(record.created))+"</div>"</span>;}function getMonthKey(dateValue){ var v=String(dateValue||""); if(v.length>=7)return v.substring(0,7); return ""; } function countGoLiveByMonth(){ var records=baseRecords(); var out={},i,p,m; for(i=0;i<records.length;i++){ p=records[i]; if(getGroupedStatus(p.status)==="Completed"){ m=getMonthKey(p.goLive); if(m){ if(!out[m]){out[m]=0;} out[m]++; } } } return out; } function getRecentSixMonths(){ var today=new Date(); var out=[],i,d,y,m; for(i=GOVERNANCE_CONFIG.goLiveMonthsToShow-1;i>=0;i--){ d=new Date(today.getFullYear(),today.getMonth()-i,1); y=d.getFullYear(); m=d.getMonth()+1; out.push(y+" - "+(m<10?"0"+m:m)); } return out; } function monthLabel(key){ var names=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]; var m=parseInt(key.substring(5,7),10); return names[m-1]||key; } function uniqueSmes(){ var records=baseRecords(); var seen={},out=[],i,p,g,names,j,sme; for(i=0;i<records.length;i++){   p=records[i];   g=getGroupedStatus(p.status);   if(selectedReviewStatus && p.status!==selectedReviewStatus)continue;   if(!selectedReviewStatus && !selectedStatusGroups[g])continue;   names=[p.sme].concat(supportingSmeList(p));   for(j=0;j<names.length;j++){     sme=cleanSmeName(names[j]||"");     if(sme&&!seen[sme]){       seen[sme]=true;       out.push(sme);     }   } } return out;} function countBySme(sme){ var records=baseRecords(); var c=0,i,p,g; for(i=0;i<records.length;i++){   p=records[i];   g=getGroupedStatus(p.status);   if(selectedReviewStatus && p.status!==selectedReviewStatus)continue;   if(!selectedReviewStatus && !selectedStatusGroups[g])continue;   if(sme==="ALL"||recordHasSme(p,sme)){c++;} } return c;} function uniqueAeLeadsForVerticals(){ var seen={},out=[],i,p; for(i=0;i<DISPLAY_RECORDS.length;i++){ p=DISPLAY_RECORDS[i]; if(p.type==="Vertical"&&p.lead){ if(!seen[p.lead]){seen[p.lead]=true;out.push(p.lead);} } } return out; } function countByAeLead(ae){ var c=0,i,p; for(i=0;i<DISPLAY_RECORDS.length;i++){ p=DISPLAY_RECORDS[i]; if(p.type==="Vertical"&&p.lead===ae)c++; } return c; } function sortRecords(records){ records.sort(function(a,b){   var av,bv;   if(sortColumn==="created"){     av=isReviewQueueStatus(a.status)?numericDays(a.queueDays):(a.created?new Date(a.created).getTime():0);     bv=isReviewQueueStatus(b.status)?numericDays(b.queueDays):(b.created?new Date(b.created).getTime():0);   }else if(sortColumn==="goLive"){     av=a[sortColumn]?new Date(a[sortColumn]).getTime():0;     bv=b[sortColumn]?new Date(b[sortColumn]).getTime():0;   }else{     av=String(a[sortColumn]||"").toLowerCase();     bv=String(b[sortColumn]||"").toLowerCase();   }   if(av<bv)return sortDirection==="ASC"?-1:1;   if(av>bv)return sortDirection==="ASC"?1:-1;   return 0; }); return records;}/* ===== Portfolio rendering ===== */function render(){ root.className=dashboardTheme==="dark"?"dark - mode":""; var html=""; html+=renderTabs(); if(activeTab==="capacity"){   html+=renderCapacityHeatmapTab(); }else{   html+=renderDashboardTab(); } root.innerHTML=html;initGovernanceBoard();}function renderTabs(){ var h=""; var toggleLabel=dashboardTheme==="dark"?"☀Light Mode":"🌙 Dark Mode"; var toggleClass=dashboardTheme==="dark"?"theme - toggle - btn":"theme - toggle - btn light"; h+=" < div class='tab-shell' > <div class='tab-row'>"; h+="<button class='"+tabClass("dashboard")+"' onclick='setActiveTab(\"dashboard\")'>▦ Dashboard</button>"; h+="<button class='"+tabClass("capacity")+"' onclick='setActiveTab(\"capacity\")'>▣ Capacity Heatmap</button>"; h+="<div class='theme-toggle-wrap'><button class='"+toggleClass+"' onclick='toggleDashboardTheme()'>"+toggleLabel+"</button></div>"; h+="</div></div > "; return h;}function tabClass(tabName){ return activeTab===tabName?"tab - btn active":"tab - btn";}function renderDashboardTab(){ var html=""; html+=" < div class='pv-hero' > <div class='pv-title'>CET Portfolio Project Listing</div> <div class='pv-sub'>Demand-centric governance view enriched with linked Project / Service Request execution details</div></div > "; html+=" < div class='pv-top' > "; html+=topCard("ALL","Total Demands",countType("ALL"),"All records"); html+=topCard("Vertical","Verticals",countType("Vertical"),"From Jira filter"); html+=topCard("Supporting Demand","Supporting Demands",countType("Supporting Demand"),"Fetched by key"); html+="</div > "; html+=" < div class='pv-status-box' > <div class='pv-status-title'>Portfolio Status Overview - "+esc(selectedType==="ALL"?"Total Demands":selectedType)+"</div>"; html+=" < div class='pv-status-grid' > "; html+=statusCircle("Backlog"); html+=statusCircle("Under Discussion"); html+=statusCircle("Baseline 0"); html+=statusCircle("Baseline 1"); html+=statusCircle("Other"); html+=statusCircle("Completed"); html+=statusCircle("On Hold");/*statusCircle("Dropped / Cancelled");*/ html+="</div ></div > "; html+=governanceRow(); html+=smeFilterPanel(); html+=platformFilterPanel(); html+=" < div class='pv-panel' > ";html+=" < div class='project-head-row' > ";html+=" < div class='project-title-block' > ";html+=" < div class='project-title' > Project Listing < span style = 'font-size:12px;color:#64748b;font-weight:900' > ("+projectRecords().length+" items)</div > "</span>;html+=" < div class='filter-note' > Type: "+esc(selectedType)+" | AE Lead: "+esc(selectedAeLead)+" | SME: "+esc(selectedSme)+" | Platform: "+esc(selectedPlatformFilterText())+" | Go Live Month: "+esc(selectedGoLiveMonth?monthLabel(selectedGoLiveMonth):"ALL")+" | Search: "+esc(selectedSearch||"ALL")+" | Review: "+esc(selectedReviewStatus||"ALL")+"</div > ";html+="</div > ";html+=" < div class='project-search-center' > ";html+=projectSearchBox();html+="</div > ";html+=" < div class='project-filter-right' > <div class='export-control-row'>";html+=statusFilterDropdown();html+=exportProjectButton();html+="</div></div > ";html+="</div > ";html+=projectList();html+="</div > ";return html; }function topCard(type,label,value,note){ var active=selectedType===type?" active":""; var colorClass="total"; var html=""; if(type==="Vertical")colorClass="vertical"; if(type==="Supporting Demand")colorClass="support"; html+=" < div class='pv-card "+colorClass+active+"' onclick = 'setDemandType(\""+type+"\")' > "; html+=" < div class='pv-label' > "+esc(label)+"</div > "; html+=" < div class='pv-value' > "+value+"</div > "; html+=" < div class='pv-note' > "+esc(note)+"</div > "; if(type==="Vertical"){ html+=aeLeadMiniStrip(); } html+="</div > "; return html; } function aeLeadMiniStrip(){ var leads=uniqueAeLeadsForVerticals(); var h=" < div class='ae-mini-row' > "; var i,ae,cls; for(i=0;i<leads.length;i++){ ae=leads[i]; cls=selectedAeLead===ae?"ae - mini - chip active":"ae - mini - chip"; h+=" < span class='"+cls+"' onclick =\"event.stopPropagation();setAeLeadFilter('" + jsString(ae) + "')\">" + esc(ae) + " " + countByAeLead(ae) + ""</span >;
    } h += "</div>"; return h;
} function statusCircle(name) { var cls = selectedStatusGroups[name] ? "pv-circle active" : "pv-circle"; return "<div class='" + cls + "' onclick='toggleStatusGroup(\"" + name + "\")'><div class='pv-num " + statusClass(name) + "'>" + countGroup(name) + "</div><div class='pv-name'>" + esc(name) + "</div></div>"; } function projectSearchBox() { var active = selectedSearch ? " active" : ""; var h = ""; h += "<div class='search-box-wrap'>"; h += "<span class='search-icon'>⌕"</span >; h += "<input id='projectSearchBox' class='project-search' type='text' value='" + esc(selectedSearch) + "' placeholder='Search key, summary, platform, SME, PM...' oninput='setProjectSearch(this.value)' onclick='event.stopPropagation()'>"; h += "<button class='search-clear" + active + "' onclick='clearProjectSearch()'>×</button>"; h += "</div>"; return h; } function statusFilterDropdown() { var groups = ["Backlog", "Under Discussion", "Baseline 0", "Baseline 1", "Other", "Completed", "On Hold" /*"Dropped / Cancelled"*/]; var h = "", i, g, checked; h += "<div class='status-filter-wrap'>"; h += "<button class='status-filter-btn' onclick='toggleStatusMenu()'>Status Filter ▾</button>"; h += "<div id='statusFilterMenu' class='status-filter-menu'>"; for (i = 0; i < groups.length; i++) { g = groups[i]; checked = selectedStatusGroups[g] ? "checked" : ""; h += "<label><input type='checkbox' " + checked + " onchange='setStatusGroupChecked(\"" + g + "\",this.checked)'>" + esc(g) + "</label>"; } h += "</div></div>"; return h; } function exportProjectButton() { return "<button class='excel-export-btn' onclick='exportProjectListingToExcel()' title='Export current filtered Project Listing to Excel' aria-label='Export current filtered Project Listing to Excel'><span class='excel-export-icon'>X<span class='excel-export-label'>Export Excel</span></button>"</span >; } function governanceRow() { var h = ""; var displayStyle = governanceExpanded ? "block" : "none"; var arrowText = governanceExpanded ? "v" : ">"; h += "<div class='pv-gov-wrap'>"; h += "<div class='pv-gov-head' onclick='toggleGovernanceRow()'>"; h += "<div><div class='pv-gov-title'>Monthly Governance Focus</div><div class='pv-gov-sub'>Highlights, Go Live timeline and review queue</div></div>"; h += "<div id='governanceArrow' class='pv-gov-arrow'>" + arrowText + "</div>"; h += "</div>"; h += "<div id='governanceContent' class='pv-gov-content' style='display:" + displayStyle + "'>"; h += "<div class='pv-governance'>"; h += headDiscussion(); h += goLiveTimeline(); h += reviewQueue(); h += "</div></div></div>"; return h; } function governanceBoardRecords() { return baseRecords(); }
function projectChip(record, extra) { var text = (record.key || "") + (extra ? " · " + extra : ""); return "<span class='gov-focus-chip' title='" + esc(record.summary || record.key) + "'>" + esc(text) + ""</span >; }
function topRecordChips(records, formatter) { var max = GOVERNANCE_CONFIG.governanceLiveBoard.topItemsToShow || 3; var h = "", i, p, extra; if (!records.length) { return "<span class='gov-focus-chip'>No active item"</span >; } for (i = 0; i < records.length && i < max; i++) { p = records[i]; extra = formatter ? formatter(p) : ""; h += projectChip(p, extra); } if (records.length > max) { h += "<span class='gov-focus-chip'>+" + esc(records.length - max) + " more"</span >; } return h; }
function isDroppedOrCancelledStatus(status) { return getGroupedStatus(status) === "On Hold" /*"Dropped / Cancelled"*/; }
function isPlanPickupEligible(record) { return !(isLiveOrCompletedStatus(record.status) || isDroppedOrCancelledStatus(record.status)); }
function pickupWindowStatus(record) { if (!isPlanPickupEligible(record)) return ""; var d = parseDateValue(record.pickupDate); var today = todayMidnight(); var weekMs = (GOVERNANCE_CONFIG.governanceLiveBoard.upcomingPickupDays || 7) * 24 * 60 * 60 * 1000; var midnight; if (!d) return ""; midnight = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); if (midnight < today) return "Overdue"; if (midnight <= today + weekMs) return "Next 7d"; return ""; }
function governanceCalendarDataForRecord(record) { var k1 = record.key + "|" + (record.linkedKey || ""); var k2 = record.key + "|" + (typeof v18ProjectKeyFromRecord === "function" ? v18ProjectKeyFromRecord(record) : ""); if (typeof V18_TABLE_CACHE !== "undefined" && V18_TABLE_CACHE[k1]) return V18_TABLE_CACHE[k1]; if (typeof V18_TABLE_CACHE !== "undefined" && V18_TABLE_CACHE[k2]) return V18_TABLE_CACHE[k2]; if (typeof V18_POPUP_ACTIVITY_CACHE !== "undefined" && V18_POPUP_ACTIVITY_CACHE[k1]) return V18_POPUP_ACTIVITY_CACHE[k1]; if (typeof V18_POPUP_ACTIVITY_CACHE !== "undefined" && V18_POPUP_ACTIVITY_CACHE[k2]) return V18_POPUP_ACTIVITY_CACHE[k2]; return null; }
function governanceBaseline1Activities(record) { var data = governanceCalendarDataForRecord(record); if (data && data.baseline1) return data.baseline1 || []; return filterMainActivities((record.activities || []), "baseline1") || []; }
function governanceActivityName(a) { return String(a.summary || a.name || ""); }
function governanceIsBaseline1ActivityName(name) { var n = String(name || "").toLowerCase(); return n.indexOf("develop") >= 0 || n.indexOf("development") >= 0 || n.indexOf("itqa") >= 0 || n.indexOf("sit") >= 0 || n.indexOf("uat") >= 0 || n.indexOf("staging") >= 0 || n.indexOf("stagin") >= 0 || n.indexOf("go live") >= 0 || n === "live" || n.indexOf(" live") >= 0; }
function governanceActivityActualEnd(a) { return parseDateValue(a.actualEnd) || parseDateValue(a.end); }
function governanceActivityPlannedEnd(a) { return parseDateValue(a.plannedEnd) || parseDateValue(a.end); }
function governanceActivityDone(a) { if (typeof v18ActivityStatus === "function") { return v18ActivityStatus(a).cls === "done"; } return isActivityDone(a); }
function governanceWithinLookback(d, days) { if (!d) return false; var today = todayMidnight(); var start = today - ((days || 7) * 24 * 60 * 60 * 1000); var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); return x >= start && x <= today; }
function governanceCompletedB1Events(records) { var events = [], days = GOVERNANCE_CONFIG.governanceLiveBoard.completedLookbackDays || 7, i, p, acts, j, a, n, d; for (i = 0; i < records.length; i++) { p = records[i]; acts = governanceBaseline1Activities(p); for (j = 0; j < acts.length; j++) { a = acts[j]; n = governanceActivityName(a); if (!governanceIsBaseline1ActivityName(n)) continue; if (!governanceActivityDone(a)) continue; d = governanceActivityActualEnd(a); if (governanceWithinLookback(d, days)) { events.push({ record: p, activity: a, date: d, label: n }); } } } events.sort(function (a, b) { return b.date - a.date; }); return events; }
function governanceB1SlipEvents(records) { var events = [], today = todayMidnight(), i, p, acts, j, a, n, e, mid; for (i = 0; i < records.length; i++) { p = records[i]; if (isLiveOrCompletedStatus(p.status) || isDroppedOrCancelledStatus(p.status)) continue; acts = governanceBaseline1Activities(p); for (j = 0; j < acts.length; j++) { a = acts[j]; n = governanceActivityName(a); if (!governanceIsBaseline1ActivityName(n)) continue; if (governanceActivityDone(a)) continue; e = governanceActivityPlannedEnd(a); if (!e) continue; mid = new Date(e.getFullYear(), e.getMonth(), e.getDate()).getTime(); if (mid < today) { events.push({ record: p, activity: a, date: e, label: n }); } } } events.sort(function (a, b) { return a.date - b.date; }); return events; }
function uniqueProjectCountFromEvents(events) { var seen = {}, c = 0, i, k; for (i = 0; i < events.length; i++) { k = (events[i].record && events[i].record.key) || ("row" + i); if (!seen[k]) { seen[k] = true; c++; } } return c; }
function governanceActivityChips(events, formatter) { var max = GOVERNANCE_CONFIG.governanceLiveBoard.topItemsToShow || 3; var h = "", i, e, extra; if (!events.length) { return "<span class='gov-focus-chip'>No active item"</span >; } for (i = 0; i < events.length && i < max; i++) { e = events[i]; extra = formatter ? formatter(e) : ""; h += projectChip(e.record, (e.label ? e.label + " · " : "") + extra); } if (events.length > max) { h += "<span class='gov-focus-chip'>+" + esc(events.length - max) + " more"</span >; } return h; }
function buildGovernanceFocusCards() {
    var records = governanceBoardRecords(); var delayed = [], pickup = [], pickupOverdue = 0, pickupUpcoming = 0, aeReview = [], slaBreached = [], baseline0Risk = [], missingPickup = []; var i, p, sla, days, win, rows, topOwner, ownerName, completedB1, b1Slip, loadedActivityProjects = 0; for (i = 0; i < records.length; i++) { p = records[i]; if (isGoLiveDelayed(p)) { delayed.push(p); } win = pickupWindowStatus(p); if (win) { pickup.push(p); if (win === "Overdue") pickupOverdue++; if (win === "Next 7d") pickupUpcoming++; } if (p.status === GOVERNANCE_CONFIG.reviewStatuses.ae) { aeReview.push(p); } sla = reviewSlaDays(p); days = numericDays(p.queueDays); if (sla && days > sla) { slaBreached.push(p); } if (isBaseline0Aged(p)) { baseline0Risk.push(p); } if (getGroupedStatus(p.status) === "Backlog" && !parseDateValue(p.pickupDate) && isPlanPickupEligible(p)) { missingPickup.push(p); } if (governanceCalendarDataForRecord(p)) { loadedActivityProjects++; } }
    completedB1 = governanceCompletedB1Events(records);
    b1Slip = governanceB1SlipEvents(records);
    rows = buildCapacityHeatmapRows(); topOwner = rows && rows.length ? rows[0] : null; ownerName = topOwner ? topOwner.ownerName : "No active owner";
    return [
        { title: "Delayed Go-Lives", count: delayed.length, cls: "red", text: delayed.length + " Baseline 1 item(s) have Go-Live dates already crossed and need recovery decision.", items: topRecordChips(delayed, function (x) { return formatDateOnly(x.goLive); }) },
        { title: "Plan Pickups", count: pickup.length, cls: pickupOverdue > 0 ? "red" : "amber", text: pickupOverdue + " overdue · " + pickupUpcoming + " due in next " + (GOVERNANCE_CONFIG.governanceLiveBoard.upcomingPickupDays || 7) + " days.", items: topRecordChips(pickup, function (x) { return pickupWindowStatus(x) + " " + formatDateOnly(x.pickupDate); }) },
        { title: "AE Review Approval", count: aeReview.length, cls: "blue", text: aeReview.length + " project(s) are under Accountable Executive Review and require approval / direction.", items: topRecordChips(aeReview, function (x) { return ageText(x.created) || x.status; }) },
        { title: "SLA Breached", count: slaBreached.length, cls: "red", text: slaBreached.length + " review item(s) have exceeded the configured governance SLA.", items: topRecordChips(slaBreached, function (x) { return numericDays(x.queueDays) + "d / SLA " + reviewSlaDays(x) + "d"; }) },
        { title: "B1 Completed This Week", count: completedB1.length, cls: completedB1.length ? "green" : "blue", text: completedB1.length + " delivery milestone(s) completed in the reporting window.", items: governanceActivityChips(completedB1, function (e) { return formatDateOnly(e.date); }) },
        { title: "Baseline 1 Execution Risk", count: uniqueProjectCountFromEvents(b1Slip), cls: b1Slip.length ? "red" : "green", text: uniqueProjectCountFromEvents(b1Slip) + " project(s) have slipping Develop / SIT / UAT / Staging / Go-Live activity milestones. Based on loaded activity data.", items: governanceActivityChips(b1Slip, function (e) { return "Due " + formatDateOnly(e.date); }) },
        { title: "SME / PM Pressure", count: topOwner ? topOwner.pressureScore : 0, cls: (topOwner && topOwner.pressureScore > GOVERNANCE_CONFIG.capacityHeatmap.pressureBands.medium) ? "purple" : "green", text: "Highest current pressure: " + ownerName + ". Useful for capacity and pickup decision.", items: topOwner ? "<span class='gov-focus-chip'>Active: " + esc(topOwner.activeCount) + "<span class='gov-focus-chip'>SME: "</span> +esc(topOwner.smeItemCount) + "<span class='gov-focus-chip'>PM: "</span> +esc(topOwner.pmItemCount) + ""</span>: "<span class='gov-focus-chip'>No active workload"</span>},
        { title: "Baseline 0 Ageing", count: baseline0Risk.length, cls: baseline0Risk.length ? "amber" : "green", text: baseline0Risk.length + " Baseline 0 item(s) are older than " + GOVERNANCE_CONFIG.baseline0AgeRiskDays + " days and need movement decision.", items: topRecordChips(baseline0Risk, function (x) { return ageText(x.created); }) },
        { title: "Missing Pickup Date", count: missingPickup.length, cls: missingPickup.length ? "amber" : "green", text: missingPickup.length + " eligible backlog item(s) do not have a proposed pickup date captured.", items: topRecordChips(missingPickup, function (x) { return x.status; }) }
    ];
}
function governanceFocusCardHtml(card) { var h = ""; h += "<div class='gov-focus-card " + card.cls + "'>"; h += "<div class='gov-focus-top'><div class='gov-focus-name'>" + esc(card.title) + "</div><div class='gov-focus-count'>" + esc(card.count) + "</div></div>"; h += "<div class='gov-focus-text'>" + esc(card.text) + "</div>"; h += "<div class='gov-focus-list'>" + card.items + "</div>"; h += "</div>"; return h; }
function headDiscussion() { var cards = buildGovernanceFocusCards(); var pages = cards.length || 1; var h = "", i, active, pauseLabel, pauseClass; if (governanceBoardPage >= pages) { governanceBoardPage = 0; } pauseLabel = governanceBoardPaused ? "START" : "PAUSE"; pauseClass = governanceBoardPaused ? "gov-live-pause paused" : "gov-live-pause"; h += "<div class='gov-card'>"; h += "<div class='gov-discussion-top'><div class='gov-title'>Highlights / Head Discussion</div><div class='gov-discussion-actions'><button class='gov-live-nav' onclick='moveGovernanceBoard(-1);event.stopPropagation();' title='Previous'>‹</button><button id='govLivePauseBtn' class='" + pauseClass + "' onclick='toggleGovernanceBoardPause();event.stopPropagation();'>" + pauseLabel + "</button><button class='gov-live-nav' onclick='moveGovernanceBoard(1);event.stopPropagation();' title='Next'>›</button></div></div>"; h += "<div id='govLiveBoard' class='gov-live-board'>"; h += "<div class='gov-live-body'>"; for (i = 0; i < pages; i++) { active = i === governanceBoardPage ? " active" : ""; h += "<div class='gov-live-slide" + active + "' data-gov-slide='" + i + "'>"; h += governanceFocusCardHtml(cards[i]); h += "</div>"; } h += "</div><div class='gov-live-dots'>"; for (i = 0; i < pages; i++) { active = i === governanceBoardPage ? " active" : ""; h += "<button class='gov-live-dot" + active + "' onclick='setGovernanceBoardPage(" + i + ");event.stopPropagation();' title='Signal " + (i + 1) + "'></button>"; } h += "</div></div></div>"; return h; }
function refreshGovernanceBoardOnly() { var board = document.getElementById("govLiveBoard"); if (!board) return; var holder = board.parentNode; if (!holder) return; var html = headDiscussion(); var temp = document.createElement("div"); temp.innerHTML = html; var newCard = temp.firstChild; if (newCard) { holder.parentNode.replaceChild(newCard, holder); applyGovernanceBoardPage(); } }
function initGovernanceBoard() { if (governanceBoardTimer) { clearInterval(governanceBoardTimer); governanceBoardTimer = null; } if (!document.getElementById("govLiveBoard")) return; if (governanceBoardPaused) return; governanceBoardTimer = setInterval(function () { moveGovernanceBoard(1, true); }, GOVERNANCE_CONFIG.governanceLiveBoard.autoRotateMs || 5500); }
function pauseGovernanceBoard() { governanceBoardPaused = true; if (governanceBoardTimer) { clearInterval(governanceBoardTimer); governanceBoardTimer = null; } updateGovernancePauseButton(); }
function resumeGovernanceBoard() { governanceBoardPaused = false; updateGovernancePauseButton(); initGovernanceBoard(); }
function toggleGovernanceBoardPause() { if (governanceBoardPaused) { resumeGovernanceBoard(); } else { pauseGovernanceBoard(); } }
function updateGovernancePauseButton() { var btn = document.getElementById("govLivePauseBtn"); if (!btn) return; btn.innerHTML = governanceBoardPaused ? "START" : "PAUSE"; if (governanceBoardPaused) { btn.classList.add("paused"); } else { btn.classList.remove("paused"); } }
function governanceBoardDomPageCount() { var slides = document.querySelectorAll("#govLiveBoard .gov-live-slide"); return slides && slides.length ? slides.length : 1; }
function applyGovernanceBoardPage() { var slides = document.querySelectorAll("#govLiveBoard .gov-live-slide"); var dots = document.querySelectorAll("#govLiveBoard .gov-live-dot"); var sub = document.querySelector("#govLiveBoard .gov-live-sub"); var pages = slides && slides.length ? slides.length : 1; var i; if (governanceBoardPage >= pages) governanceBoardPage = 0; if (governanceBoardPage < 0) governanceBoardPage = pages - 1; for (i = 0; i < slides.length; i++) { slides[i].classList.remove("active"); slides[i].classList.remove("before"); slides[i].classList.remove("after"); if (i === governanceBoardPage) { slides[i].classList.add("active"); } else if (i < governanceBoardPage) { slides[i].classList.add("before"); } else { slides[i].classList.add("after"); } } for (i = 0; i < dots.length; i++) { if (i === governanceBoardPage) { dots[i].classList.add("active"); } else { dots[i].classList.remove("active"); } } if (sub) { sub.innerHTML = "One priority at a time · " + (governanceBoardPage + 1) + " / " + pages; } updateGovernancePauseButton(); }
function setGovernanceBoardPage(page) { governanceBoardPage = page; applyGovernanceBoardPage(); }
function moveGovernanceBoard(delta, silent) { var pages = governanceBoardDomPageCount(); governanceBoardPage = (governanceBoardPage + delta + pages) % pages; applyGovernanceBoardPage(); } function goLiveTimeline() { var data = countGoLiveByMonth(); var months = getRecentSixMonths(); var h = "", i, m, c, activeClass; h += "<div class='gov-card'>"; h += "<div class='gov-title'>Go Live Items - Monthwise</div>"; h += "<div class='ppt-timeline'><div class='ppt-line'></div><div class='ppt-grid'>"; for (i = 0; i < months.length; i++) { m = months[i]; c = data[m] || 0; activeClass = selectedGoLiveMonth === m ? " selected" : ""; h += "<div class='golive-month-item" + activeClass + "' onclick='toggleGoLiveMonthFilter(\"" + m + "\");event.stopPropagation();' title='" + (selectedGoLiveMonth === m ? "Unselect month and show all completed items" : "Select completed Go-Live items for " + esc(monthLabel(m))) + "'><div class='ppt-month'>" + esc(monthLabel(m)) + "</div><div class='ppt-dot'>" + c + "</div><div class='ppt-note'>Live / Done</div></div>"; } h += "</div></div></div>"; return h; } function reviewQueue() { var ae = countStatusExact(GOVERNANCE_CONFIG.reviewStatuses.ae); var tech = countStatusExact(GOVERNANCE_CONFIG.reviewStatuses.tech); var aeActive = selectedReviewStatus === GOVERNANCE_CONFIG.reviewStatuses.ae ? " review-active" : ""; var techActive = selectedReviewStatus === GOVERNANCE_CONFIG.reviewStatuses.tech ? " review-active" : ""; var h = ""; h += "<div class='gov-card'>"; h += "<div class='gov-title'>Review Queue</div>"; h += "<table class='gov-review-table'>"; h += "<thead><tr><th>Review Stage</th><th>Count</th></tr></thead>"; h += "<tbody>"; h += "<tr class='review-click" + aeActive + "' onclick='setReviewStatusFilter(" + JSON.stringify(GOVERNANCE_CONFIG.reviewStatuses.ae) + ")'>"; h += "<td>Accountable Executive Review</td>"; h += "<td><span class='gov-count'>" + ae + "</td>"</span >; h += "</tr>"; h += "<tr class='review-click" + techActive + "' onclick='setReviewStatusFilter(" + JSON.stringify(GOVERNANCE_CONFIG.reviewStatuses.tech) + ")'>"; h += "<td>Technology Review</td>"; h += "<td><span class='gov-count'>" + tech + "</td>"</span >; h += "</tr>"; h += "</tbody></table>"; if (selectedReviewStatus) { h += "<div style='margin-top:10px;'>"; h += "<button class='review-clear-btn' onclick='clearReviewStatusFilter()'>Clear Review Filter</button>"; h += "</div>"; } h += "</div>"; return h; } function jsString(v) { return String(v || "").replace(/\\/g, "\\\\").replace(/'/g, "\\'"); } function smeFilterPanel() { var h = ""; h += "<div class='sme-filter-panel'>"; h += "<div class='sme-filter-head'>"; h += "<div>"; h += "<div class='sme-filter-title'>SME Lead Focus</div>"; h += "<div class='sme-filter-sub'>Filter the project listing by platform owner / subject matter expert</div>"; h += "</div>"; h += "</div>"; h += smeStrip(); h += "</div>"; return h; } function smeStrip() { var smes = uniqueSmes(); var h = "", i, sme, cls; h += "<div class='sme-strip'>"; cls = selectedSme === "ALL" ? "sme-chip active" : "sme-chip"; h += "<div class='" + cls + "' onclick='setSmeFilter(\"ALL\")'><span>ALL</span>class='sme-count'>" + countBySme("ALL") + "</span></div>"; for (i = 0; i < smes.length; i++) { sme = smes[i]; cls = selectedSme === sme ? "sme-chip active" : "sme-chip"; h += "<div class='" + cls + "' onclick=\"setSmeFilter('" + jsString(sme) + "')\"><span>" + esc(sme) + "<span class='sme-count'>"</span > +countBySme(sme) + "</div>"</span >; } h += "</div>"; return h; }
/* ===== Platform Multi-Select Filter ===== */
function platformValues(record) {
    var raw = String(record && record.platform || "").replace(/\r/g, "\n");
    var parts = raw.split(/[,;\n|]+/), out = [], seen = {}, i, v;
    for (i = 0; i < parts.length; i++) {
        v = clean(parts[i]);
        if (!v) continue;
        if (!seen[v.toLowerCase()]) { seen[v.toLowerCase()] = true; out.push(v); }
    }
    if (!out.length) out.push("Unassigned");
    return out;
}
function hasSelectedPlatforms() {
    var k;
    for (k in selectedPlatforms) { if (selectedPlatforms.hasOwnProperty(k) && selectedPlatforms[k]) return true; }
    return false;
}
function selectedPlatformFilterText() {
    var out = [], k;
    for (k in selectedPlatforms) { if (selectedPlatforms.hasOwnProperty(k) && selectedPlatforms[k]) out.push(k); }
    return out.length ? out.join(", ") : "ALL";
}
function recordMatchesSelectedPlatforms(record) {
    if (!hasSelectedPlatforms()) return true;
    var vals = platformValues(record), i;
    for (i = 0; i < vals.length; i++) { if (selectedPlatforms[vals[i]]) return true; }
    return false;
}
function platformBaseRecords() {
    var records = baseRecords(), out = [], i, p, g;
    for (i = 0; i < records.length; i++) {
        p = records[i];
        g = getGroupedStatus(p.status);
        if (selectedReviewStatus && p.status !== selectedReviewStatus) continue;
        if (!selectedReviewStatus && !selectedStatusGroups[g]) continue;
        if (selectedSme !== "ALL" && !recordHasSme(p, selectedSme)) continue;
        if (!matchesSearch(p)) continue;
        out.push(p);
    }
    return out;
}
function uniquePlatforms() {
    var records = platformBaseRecords(), seen = {}, out = [], i, j, vals, v;
    for (i = 0; i < records.length; i++) {
        vals = platformValues(records[i]);
        for (j = 0; j < vals.length; j++) {
            v = vals[j];
            if (!seen[v.toLowerCase()]) { seen[v.toLowerCase()] = true; out.push(v); }
        }
    }
    out.sort(function (a, b) { return a.localeCompare(b); });
    return out;
}
function countByPlatform(platform) {
    var records = platformBaseRecords(), i, c = 0;
    if (platform === "ALL") return records.length;
    for (i = 0; i < records.length; i++) {
        if (platformValues(records[i]).indexOf(platform) >= 0) c++;
    }
    return c;
}
function platformFilterPanel() {
    var h = "";
    h += "<div class='platform-filter-panel'>";
    h += "<div class='platform-filter-head'><div>";
    h += "<div class='platform-filter-title'>Platform Focus</div>";
    h += "<div class='platform-filter-sub'>Multi-select one or more Platforms to filter the Project Listing.</div>";
    h += "</div><button class='platform-clear-btn' onclick='setAllPlatforms();event.stopPropagation();'>ALL</button></div>";
    h += platformStrip();
    h += "</div>";
    return h;
}
function platformStrip() {
    var platforms = uniquePlatforms(), h = "", i, p, cls, allActive = !hasSelectedPlatforms();
    h += "<div class='platform-strip'>";
    cls = allActive ? "platform-chip active" : "platform-chip";
    h += "<div class='" + cls + "' onclick='setAllPlatforms()'><span>ALL<span class='platform-count'>"</span > +countByPlatform("ALL") + "</div>"</span >;
    for (i = 0; i < platforms.length; i++) {
        p = platforms[i];
        cls = selectedPlatforms[p] ? "platform-chip active" : "platform-chip";
        h += "<div class='" + cls + "' onclick=\"togglePlatformFilter('" + jsString(p) + "')\"><span>" + esc(p) + "<span class='platform-count'>"</span > +countByPlatform(p) + "</div>"</span >;
    }
    h += "</div>";
    return h;
}
function sortLabel(col, label) { var arrow = ""; if (sortColumn === col) { arrow = sortDirection === "ASC" ? " ^" : " v"; } return "<div class='sort-cell' onclick='sortBy(\"" + col + "\")'>" + esc(label) + arrow + "</div>"; }
function smeCellHtml(record) { var h = "", supports = supportingSmeList(record); h += "<div class='sme-cell-main'>" + esc(record.sme || "-") + "</div>"; if (supports.length) { h += "<div class='supporting-sme'><span class='supporting-sme-label'>Support"</span > +esc(supports.join(", ")) + "</div>"; } return h; }
function projectList() {
    var records = projectRecords();
    var h = "", i, p, statusClassName, reqText, summaryText;
    h += "<div class='project-list-wrap'>";
    h += "<div class='port-card port-head'>";
    h += "<div class='port-row'>";
    h += "<div></div>";
    h += sortLabel("key", "Key");
    h += sortLabel("summary", "Summary");
    h += sortLabel("status", "Status");
    h += sortLabel("platform", "Platform");
    h += sortLabel("lead", "AE Lead");
    h += sortLabel("sme", "SME");
    h += sortLabel("pm", "PM");
    h += sortLabel("size", "Size");
    h += sortLabel("segment", "Segment");
    h += sortLabel("created", "Age / Queue");
    h += sortLabel("goLive", "Go Live");
    h += "</div></div>";

    for (i = 0; i < records.length; i++) {
        p = records[i];
        statusClassName = getGroupedStatusClass(p.status);
        reqText = p.requirement || "No requirement available.";
        summaryText = p.portfolioSummary || "No portfolio executive summary available.";

        h += "<div class='port-card'>";
        h += "<div class='port-row port-body'>";
        h += "<div class='row-action-cell'><button class='port-toggle' title='Expand summary' onclick='toggleSummary(" + i + ")'>v</button><button class='project-plan-btn' title='Project activity calendar' onclick='openActivityTimelineModal(" + i + ")'>P</button></div>";
        h += "<div class='port-key'><a href='" +
            // JIRA_BROWSE_URL +
            CONFLUENCE_Page_URL +
            esc(p.key) +
            "' target='_blank' class='jira-link'>" + esc(p.key) + " ↗</a></div>";

        h += "<div class='port-summary'>" + esc(p.summary) + "</div>";
        h += "<div><span class='port-pill " + statusClassName + "'>" + esc(getGroupedStatus(p.status)) + "
            < span style = 'font-size:11px;color:#64748b' > "</span>+esc(p.status)+"</div > "</span>;
        h += "<div><span class='port-pill pill-blue' title='" + esc(p.platform) + "'>" + esc(p.platform) + "</div>"</span >;
        h += "<div>" + esc(p.lead) + "</div>";
        h += "<div>" + smeCellHtml(p) + "</div>";
        h += "<div>" + esc(p.pm) + "</div>";
        h += "<div>" + esc(p.size) + "</div>";
        h += "<div>" + esc(p.segment) + "</div>";
        h += ageQueueHtml(p);
        h += "<div>" + goLiveHtml(p) + "</div>";
        h += "</div>";

        h += "<div id='summary_" + i + "' class='port-detail'>";
        h += "<div class='v19-expansion-row'>";
        h += "<div class='v19-exp-card'><div class='v19-card-title'><span class='v19-card-icon'>EPortfolio Executive Summary</div><div class='v19-card-line'></div><div class='v19-card-body v19-rich-text'>"</span > +v19RichText(summaryText) + "</div></div>";
        h += "<div class='v19-exp-card'><div class='v19-card-title'><span class='v19-card-icon'>RRequirement</div><div class='v19-card-line'></div><div class='v19-card-body v19-rich-text'>"</span > +v19RichText(reqText) + "</div></div>";
        h += "<div id='v19_activity_flow_" + i + "' class='v19-exp-card v19-flow-card'><div class='v19-card-title'><span class='v19-card-icon'>ABaseline Activity Flow</div><div class='v19-card-line'></div><div class='v19-card-body'><div class='v19-flow-loading'>Expand row to load activities...</div></div></div>"</span >;
        h += "</div>";
        h += "</div>";
        h += "</div>";
    }
    h += "</div>";
    return h;
}

function getMainActivityNames(phaseGroup) { var cfg = GOVERNANCE_CONFIG.activityCalendar || {}; return phaseGroup === "baseline1" ? (cfg.baseline1 || []) : (cfg.baseline0 || []); } function activityNameMatchesConfigured(summary, configuredName) { var n = normalize(summary), c = normalize(configuredName), aliases = (GOVERNANCE_CONFIG.activityCalendar && GOVERNANCE_CONFIG.activityCalendar.aliases && GOVERNANCE_CONFIG.activityCalendar.aliases[configuredName]) || [configuredName], i, a; if (!n) return false; for (i = 0; i < aliases.length; i++) { a = normalize(aliases[i]); if (n === a || n.indexOf(a) >= 0) return true; } if (n === c || n.indexOf(c) >= 0) return true; return false; } function filterMainActivities(activities, phaseGroup) { var names = getMainActivityNames(phaseGroup), out = [], i, j, a, matched; for (j = 0; j < names.length; j++) { matched = false; for (i = 0; i < activities.length; i++) { a = activities[i]; if (a.phaseGroup !== phaseGroup) continue; if (activityNameMatchesConfigured(a.summary, names[j])) { out.push(a); matched = true; break; } } } return out; } function activityStartDate(a) { return parseDateValue(a.actualStart) || parseDateValue(a.plannedStart); } function activityEndDate(a) { return parseDateValue(a.actualEnd) || parseDateValue(a.plannedEnd); } function isActivityDone(a) { var s = String(a.status || "").toLowerCase(); return s === "done" || s === "completed" || s === "closed" || s === "live" || s.indexOf("done") >= 0 || s.indexOf("complete") >= 0; } function activityState(a) { var e = activityEndDate(a); if (!activityStartDate(a) && !e) return "tbd"; if (isActivityDone(a)) return "done"; if (e && new Date(e.getFullYear(), e.getMonth(), e.getDate()).getTime() < todayMidnight()) return "breach"; return "progress"; } function shortDateRange(a) { var s = activityStartDate(a), e = activityEndDate(a); if (!s && !e) return "TBD"; return (s ? formatDateOnly(s).replace(/-/g, " ") : "TBD") + " → " + (e ? formatDateOnly(e).replace(/-/g, " ") : "TBD"); } function monthStart(d) { return new Date(d.getFullYear(), d.getMonth(), 1); } function addMonths(d, n) { return new Date(d.getFullYear(), d.getMonth() + n, 1); } function addDays(d, n) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; } function weekStart(d) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); var day = x.getDay(); var diff = (day === 0 ? -6 : 1 - day); x.setDate(x.getDate() + diff); x.setHours(0, 0, 0, 0); return x; } function weekLabel(d) { var end = addDays(d, 6); return formatDateOnly(d).substring(0, 6) + " - " + formatDateOnly(end).substring(0, 6); } function monthKeyFromDate(d) { return d.getFullYear() + "-" + ((d.getMonth() + 1) < 10 ? "0" : "") + (d.getMonth() + 1); } function sameMonth(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth(); } function buildTimelineMonths(activities) { var dates = [], i, s, e, min, max, weeks = [], cursor, weekCount; for (i = 0; i < activities.length; i++) { s = activityStartDate(activities[i]); e = activityEndDate(activities[i]); if (s) dates.push(s); if (e) dates.push(e); } if (!dates.length) { min = weekStart(addMonths(new Date(), -1)); max = weekStart(addMonths(new Date(), 5)); } else { dates.sort(function (a, b) { return a - b; }); min = weekStart(addDays(dates[0], -14)); max = weekStart(addDays(dates[dates.length - 1], 21)); } cursor = new Date(min.getTime()); while (cursor <= max && weeks.length < 42) { weeks.push(new Date(cursor.getTime())); cursor = addDays(cursor, 7); } if (weeks.length < 12) { while (weeks.length < 12) { weeks.push(addDays(weeks[weeks.length - 1], 7)); } } weekCount = weeks.length; return { start: min, end: addDays(weeks[weeks.length - 1], 7), weeks: weeks, months: weeks, weekCount: weekCount }; } function buildMonthHeaderSpans(range) { var spans = [], weeks = range.weeks || range.months, i, mKey, current = null; for (i = 0; i < weeks.length; i++) { mKey = monthKeyFromDate(weeks[i]); if (!current || current.key !== mKey) { current = { key: mKey, label: monthLabel(mKey) + " " + weeks[i].getFullYear(), span: 1 }; spans.push(current); } else { current.span++; } } return spans; } function pctForDate(d, range) { var total = range.end.getTime() - range.start.getTime(); return Math.max(0, Math.min(100, ((d.getTime() - range.start.getTime()) / total) * 100)); } function placeActivities(activities, range) { var items = [], lanes = [], i, a, s, e, startPct, endPct, width, lane, placed, tbdIndex = 0; for (i = 0; i < activities.length; i++) { a = activities[i]; s = activityStartDate(a); e = activityEndDate(a); if (!s && !e) { startPct = Math.min(92, 72 + (tbdIndex * 5)); endPct = Math.min(98, startPct + 10); tbdIndex++; } else { if (!s) s = e; if (!e) e = s; startPct = pctForDate(s, range); endPct = pctForDate(e, range); if (endPct < startPct) { var tmp = startPct; startPct = endPct; endPct = tmp; } } width = Math.max(8, endPct - startPct); items.push({ activity: a, startPct: startPct, endPct: Math.min(99, startPct + width), width: width, lane: 0 }); } items.sort(function (x, y) { return x.startPct - y.startPct; }); for (i = 0; i < items.length; i++) { placed = false; for (lane = 0; lane < lanes.length; lane++) { if (items[i].startPct > lanes[lane] + 1.8) { items[i].lane = lane; lanes[lane] = items[i].endPct; placed = true; break; } } if (!placed) { items[i].lane = lanes.length; lanes.push(items[i].endPct); } } return { items: items, lanes: Math.max(1, lanes.length) }; } function renderDependencySvg() { return ''; } function todayLabel() { return "Today " + formatDateOnly(new Date()); } function renderPhaseTimeline(label, sub, activities, range, markerId) { var placed = placeActivities(activities, range), rowHeight = Math.max(72, placed.lanes * 46 + 24), weekWidth = (100 / (range.weeks || range.months).length).toFixed(4) + "%", h = "", i, it, a, state, left, width, top; h += "<div class='phase-band-v18'><div class='phase-label-v18'><b>" + esc(label) + "</b><span>" + esc(sub) + "</div>"</span >; h += "<div class='phase-track-v18' style='height:" + rowHeight + "px;--week-width:" + weekWidth + "'>"; var todayPct = pctForDate(new Date(), range); if (todayPct >= 0 && todayPct <= 100) h += "<div class='today-line-v18' style='left:" + todayPct.toFixed(2) + "%'><span class='today-label-v18'>" + esc(todayLabel()) + "</div>"</span >; h += renderDependencySvg(placed, rowHeight, markerId); for (i = 0; i < placed.items.length; i++) { it = placed.items[i]; a = it.activity; state = activityState(a); left = it.startPct; width = Math.max(8, Math.min(24, it.endPct - it.startPct)); top = 16 + it.lane * 46; h += "<div class='task-v18 " + state + "' title='" + esc(a.summary + " | " + a.status + " | " + shortDateRange(a)) + "' style='left:" + left.toFixed(2) + "%;width:" + width.toFixed(2) + "%;top:" + top + "px'>"; h += "<span class='task-dot-v18'><span class='task-name-v18'>"</span > +esc(a.summary || a.key) + "<span class='task-date-v18'>"</span > +esc(shortDateRange(a)) + "</div>"</span >; } if (!placed.items.length) { h += "<div class='timeline-empty-v18' style='margin:14px'>No activities available</div>"; } h += "</div></div>"; return h; } function renderActivityTimeline(record) { var activities = record.activities || [], b0 = [], b1 = [], i, range, h = "", spans, weekCount, boardMin; b0 = filterMainActivities(activities, "baseline0"); b1 = filterMainActivities(activities, "baseline1"); if (!b0.length && !b1.length) { return "<div class='timeline-empty-v18'>No configured main Phase / Activity timeline available for this Project.</div>"; } range = buildTimelineMonths(b0.concat(b1)); spans = buildMonthHeaderSpans(range); weekCount = range.weeks.length; boardMin = Math.max(1320, 145 + (weekCount * 74)); h += "<div class='timeline-box-v18'><div class='timeline-head-v18'><div><div class='timeline-title-v18'>Project Phase Activity Calendar</div><div class='timeline-sub-v18'>Monthly Gantt view with month headers, larger popup activity strips, today date and MS Project-style dependency connectors.</div></div>"; h += "<div class='timeline-legend-v18'><span class='tl-legend-chip tl-done'>Done<span class='tl-legend-chip tl-progress'>Planned</span><span class='tl-legend-chip tl-breach'>Breached</span><span class='tl-legend-chip tl-tbd'>TBD</span></div></div>"</span >; h += "<div class='timeline-scroll-v18'><div class='gantt-board-v18' style='min-width:" + boardMin + "px'>"; h += "<div class='gantt-months-v18' style='grid-template-columns:145px repeat(" + weekCount + ",1fr)'><div>Month</div>"; for (i = 0; i"<div style='grid-column:span " + spans[i].span + "'>" + esc(spans[i].label) + "</div>"; } h += "</div><div class='gantt-weeks-v18' style='grid-template-columns:145px repeat(" + weekCount + ",1fr)'><div>Month</div>"; for (i = 0; i < range.weeks.length; i++) { h += "<div>" + esc(weekLabel(range.weeks[i])) + "</div>"; } h += "</div>"; h += renderPhaseTimeline("Baseline 0", "Initiation Pipeline", b0, range, "arr_b0_" + esc(record.key).replace(/[^A-Za-z0-9]/g, "")); h += renderPhaseTimeline("Baseline 1", "Execution / Delivery", b1, range, "arr_b1_" + esc(record.key).replace(/[^A-Za-z0-9]/g, "")); h += "</div></div><div class='timeline-footer-v18'><span>Start = Actual Start Date, else Planned Start.<span>End = Actual End Date, else Planned End.</span><span>TBD when dates are unavailable.</span></div></div>"</span >; return h;}function closeActivityTimelineModal() { var overlay = document.getElementById("projectPlanOverlay"); if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay); } function activityExportText(record, phaseGroup) { var arr = filterMainActivities((record.activities || []), phaseGroup), out = [], i, a; for (i = 0; i < arr.length; i++) { a = arr[i]; out.push((a.key || "") + " | " + (a.summary || "") + " | " + (a.status || "") + " | " + shortDateRange(a)); } return out.join(" ; "); } function heatmapSizeAllocation(sizeValue) {
    var size = normalizeSize(sizeValue);
    var cfg = GOVERNANCE_CONFIG.capacityHeatmap.sizeAllocation || {};
    return Number(cfg[size] || cfg.defaultAllocation || 0);
}
function heatmapSupportingAllocation(sizeValue) {
    var size = normalizeSize(sizeValue);
    var cfg = GOVERNANCE_CONFIG.capacityHeatmap.supportingAllocation || {};
    var bySize = cfg.bySize || {};
    if (cfg.mode === "fixed") { return Number(cfg.fixedDefault !== undefined ? cfg.fixedDefault : 5); }
    if (cfg.mode === "bySize") {
        if (bySize.hasOwnProperty(size)) { return Number(bySize[size]); }
        return Number(bySize.defaultAllocation !== undefined ? bySize.defaultAllocation : (cfg.fixedDefault !== undefined ? cfg.fixedDefault : 5));
    }
    if (bySize.hasOwnProperty(size)) { return Number(bySize[size]); }
    if (cfg.fixedDefault !== undefined) { return Number(cfg.fixedDefault); }
    return heatmapSizeAllocation(sizeValue);
}
function heatmapCellClass(value) {
    var bands = GOVERNANCE_CONFIG.capacityHeatmap.pressureBands || {};
    value = Number(value || 0);
    if (value <= 0) return "hm-zero";
    if (value <= bands.greenMax) return "hm-low";
    if (value <= bands.amberMax) return "hm-med";
    if (value <= bands.redMax) return "hm-high";
    return "hm-critical";
}
function heatmapPressureClass(score) {
    var bands = GOVERNANCE_CONFIG.capacityHeatmap.pressureBands || {};
    score = Number(score || 0);
    if (score <= bands.greenMax) return "rec-green";
    if (score <= bands.amberMax) return "rec-amber";
    if (score <= bands.redMax) return "rec-orange";
    return "rec-red";
}
function heatmapPressureLabel(score) {
    var bands = GOVERNANCE_CONFIG.capacityHeatmap.pressureBands || {};
    score = Number(score || 0);
    if (score <= bands.greenMax) return "Healthy";
    if (score <= bands.amberMax) return "Constrained";
    if (score <= bands.redMax) return "Delivery Risk";
    return "Overallocated";
}
function heatmapRecommendation(row) {
    var score = Number(row.pressureScore || 0);
    if (score <= GOVERNANCE_CONFIG.capacityHeatmap.pressureBands.greenMax) return { label: "Healthy", cls: "rec-green" };
    if (score <= GOVERNANCE_CONFIG.capacityHeatmap.pressureBands.amberMax) return { label: "Manage", cls: "rec-amber" };
    if (score <= GOVERNANCE_CONFIG.capacityHeatmap.pressureBands.redMax) return { label: "Delivery Risk", cls: "rec-orange" };
    return { label: "Reduce Load", cls: "rec-red" };
}
function cleanSmeName(name) { return String(name || "").replace(/\s+/g, " ").replace(/\s*\(IT Dept\)\s*$/i, "").trim(); }
function toSmeArray(value) {
    var arr = [], i, n, seen = {};
    if (value == null) return [];
    if (Object.prototype.toString.call(value) === "[object Array]") {
        for (i = 0; i < value.length; i++)arr = arr.concat(toSmeArray(value[i]));
    } else {
        n = cleanSmeName(value);
        if (n) arr.push(n);
    }
    var out = [];
    for (i = 0; i < arr.length; i++) {
        n = cleanSmeName(arr[i]);
        if (!n) continue;
        if (!seen[n.toLowerCase()]) { seen[n.toLowerCase()] = true; out.push(n); }
    }
    return out;
}
function addSupportingSme(map, demandKey, name) {
    var key = String(demandKey || "").toUpperCase();
    var arr = toSmeArray(map[key]);
    var incoming = toSmeArray(name);
    var i;
    for (i = 0; i < incoming.length; i++) { arr.push(incoming[i]); }
    map[key] = toSmeArray(arr);
}
function supportingSmeList(record) {
    var key = String(record && record.key || "").toUpperCase();
    return toSmeArray((record && record.supportingSmeList) || SUPPORTING_DEMAND_SME_MAP[key]);
}
function supportingSmeText(record) { return supportingSmeList(record).join(", "); }
function recordHasSme(record, name) {
    var target = cleanSmeName(name).toLowerCase();
    if (!target) return false;
    if (cleanSmeName(record.sme).toLowerCase() === target) return true;
    if (cleanSmeName(record.pm).toLowerCase() === target) return true;
    return supportingSmeList(record).map(function (x) { return cleanSmeName(x).toLowerCase(); }).indexOf(target) >= 0;
}
function normalizePersonName(name) { return cleanSmeName(name); }
function heatmapContributorAllocations(record) {
    var allocations = [];
    var seen = {};
    var baseAlloc = heatmapSizeAllocation(record.size);
    var supportAlloc = heatmapSupportingAllocation(record.size);
    function add(name, role, allocation) {
        var n = normalizePersonName(name), key;
        if (!n) return;
        key = n.toLowerCase();
        if (seen[key]) {
            seen[key].roles[role] = true;
            if (Number(allocation || 0) > seen[key].allocation) { seen[key].allocation = Number(allocation || 0); }
            return;
        }
        seen[key] = { name: n, allocation: Number(allocation || 0), roles: {} };
        seen[key].roles[role] = true;
        allocations.push(seen[key]);
    }
    add(record.sme, "SME", baseAlloc);
    var supports = supportingSmeList(record), i;
    for (i = 0; i < supports.length; i++) { add(supports[i], "Support", supportAlloc); }
    add(record.pm, "PM", baseAlloc);
    if (!allocations.length) { add("Unassigned", "Unassigned", baseAlloc); }
    return allocations;
}
function buildCapacityHeatmapRows() {
    var displayGroups = GOVERNANCE_CONFIG.capacityHeatmap.displayGroups || ["Backlog", "Under Discussion", "Baseline 0", "Baseline 1"];
    var pressureGroups = GOVERNANCE_CONFIG.capacityHeatmap.pressureGroups || ["Under Discussion", "Baseline 0", "Baseline 1"];
    var map = {}, rows = [], records = DISPLAY_RECORDS;
    var i, p, g, row, contributors, c, owner, ownerKey, allocation, roles, gi, isPressure;
    function hasGroup(arr, name) { return arr.indexOf(name) >= 0; }
    for (i = 0; i < records.length; i++) {
        p = records[i];
        if (selectedType !== "ALL" && p.type !== selectedType) continue;
        if (selectedAeLead !== "ALL" && p.lead !== selectedAeLead) continue;
        g = getGroupedStatus(p.status);
        if (!hasGroup(displayGroups, g)) continue;
        isPressure = hasGroup(pressureGroups, g);
        contributors = heatmapContributorAllocations(p);
        for (c = 0; c < contributors.length; c++) {
            owner = contributors[c].name;
            ownerKey = owner.toLowerCase();
            allocation = Number(contributors[c].allocation || 0);
            roles = contributors[c].roles || {};
            if (!map[ownerKey]) {
                map[ownerKey] = {
                    sme: owner,
                    ownerName: owner,
                    activeCount: 0,
                    displayCount: 0,
                    pressureScore: 0,
                    smeItemCount: 0,
                    pmItemCount: 0,
                    supportItemCount: 0,
                    groups: {}
                };
                for (gi = 0; gi < displayGroups.length; gi++) {
                    map[ownerKey].groups[displayGroups[gi]] = { count: 0, allocation: 0 };
                }
            }
            row = map[ownerKey];
            if (!row.groups[g]) { row.groups[g] = { count: 0, allocation: 0 }; }
            row.groups[g].count++;
            row.groups[g].allocation += allocation;
            row.displayCount++;
            if (isPressure) {
                row.activeCount++;
                row.pressureScore += allocation;
            }
            if (roles.SME) { row.smeItemCount++; }
            if (roles.Support) { row.supportItemCount++; }
            if (roles.PM) { row.pmItemCount++; }
        }
    }
    for (ownerKey in map) { if (map.hasOwnProperty(ownerKey)) { rows.push(map[ownerKey]); } }
    rows.sort(function (a, b) {
        if (b.pressureScore !== a.pressureScore) return b.pressureScore - a.pressureScore;
        var ab = (a.groups.Backlog && a.groups.Backlog.allocation) || 0;
        var bb = (b.groups.Backlog && b.groups.Backlog.allocation) || 0;
        if (bb !== ab) return bb - ab;
        return a.ownerName > b.ownerName ? 1 : -1;
    });
    return rows;
}
function heatmapKpis(rows) {
    var active = 0, over = 0, max = 0, i;
    for (i = 0; i < rows.length; i++) {
        active += rows[i].activeCount;
        if (rows[i].pressureScore > 100) over++;
        if (rows[i].pressureScore > max) max = rows[i].pressureScore;
    }
    return { active: active, over: over, max: max };
}
function heatCellHtml(row, group) {
    var cell = row.groups[group];
    var value = Math.round(Number(cell.allocation || 0));
    var sub = cell.count + " item" + (cell.count === 1 ? "" : "s");
    return "<div class='heat-cell " + heatmapCellClass(value) + "'><span class='heat-num'>" + esc(value + "%") + "<span class='heat-subtext'>"</span > +esc(sub) + "</div>"</span >;
}
function renderCapacityHeatmapTab() {
    var rows = buildCapacityHeatmapRows();
    var kpi = heatmapKpis(rows);
    var h = "", i, row, rec, pressureCls, pressure;
    h += "<div class='heat-hero'>";
    h += "<div class='heat-title'>Capacity Heatmap</div>";
    h += "<div class='heat-sub'>SME / Supporting SME / PM allocation view based on project size, with Backlog shown separately.</div>";
    h += "</div>";
    h += "<div class='heat-kpis'>";
    h += "<div class='heat-kpi'><div class='heat-kpi-label'>Active Assignments</div><div class='heat-kpi-value'>" + kpi.active + "</div><div class='heat-kpi-note'>Under Discussion + Baseline 0 + Baseline 1</div></div>";
    h += "<div class='heat-kpi'><div class='heat-kpi-label'>Overallocated Owners</div><div class='heat-kpi-value'>" + kpi.over + "</div><div class='heat-kpi-note'>Above 100% capacity</div></div>";
    h += "<div class='heat-kpi'><div class='heat-kpi-label'>Highest Pressure</div><div class='heat-kpi-value'>" + Math.round(kpi.max) + "%</div><div class='heat-kpi-note'>Maximum owner allocation</div></div>";
    h += "</div>";
    h += "<div class='heat-advice'><b>Capacity logic:</b> XS 10%, S 20%, M 50%, L 100%, XL 100%. Supporting SME allocation follows the same actual demand-size allocation. SME Lead, Supporting SME and Assigned PM are included once per demand per person.</div>";
    h += "<div class='heat-panel'>";
    h += "<div class='heat-panel-title'>Portfolio Capacity Heatmap</div>";
    h += "<div class='heat-panel-sub'>Cells show percentage allocation by stage. Backlog is displayed for visibility but excluded from Pressure calculation.</div>";
    h += "<div class='heat-grid'>";
    h += "<div class='heat-head'>SME / PM Owner</div>";
    h += "<div class='heat-head'>Backlog
        < span style = 'font-weight:700' > Visible only</div > "</span>;
    h += "<div class='heat-head'>Under Discussion
        < span style = 'font-weight:700' > Allocation %</div > "</span>;
    h += "<div class='heat-head'>Baseline 0
        < span style = 'font-weight:700' > Allocation %</div > "</span>;
    h += "<div class='heat-head'>Baseline 1
        < span style = 'font-weight:700' > Allocation %</div > "</span>;
    h += "<div class='heat-head'>Pressure</div>";
    h += "<div class='heat-head'>Recommendation</div>";
    if (rows.length === 0) {
        h += "<div class='heat-sme' style='grid-column:1/-1'>No active capacity records found for the selected context.</div>";
    } else {
        for (i = 0; i < rows.length; i++) {
            row = rows[i];
            rec = heatmapRecommendation(row);
            pressure = Math.round(Number(row.pressureScore || 0));
            pressureCls = heatmapPressureClass(pressure);
            h += "<div class='heat-sme'><div>" + esc(row.ownerName) + "<span class='heat-owner-meta'>SME: " + esc(row.smeItemCount) + " | Support: " + esc(row.supportItemCount || 0) + " | PM: " + esc(row.pmItemCount) + "</div></div>"</span >;
            h += heatCellHtml(row, "Backlog");
            h += heatCellHtml(row, "Under Discussion");
            h += heatCellHtml(row, "Baseline 0");
            h += heatCellHtml(row, "Baseline 1");
            h += "<div class='pressure-pill " + pressureCls + "'>" + esc(pressure + "%") + "
                < span style = 'font-size:10px' > "+esc(heatmapPressureLabel(pressure))+"</div > "</span>;
            h += "<div class='rec-pill " + rec.cls + "'>" + esc(rec.label) + "</div>";
        }
    }
    h += "</div>";
    h += "<div class='heat-legend'>";
    h += "<span class='legend-chip'><span class='legend-box hm-zero'>0%</span>"</span >;
    h += "<span class='legend-chip'><span class='legend-box hm-low'>≤50%</span>"</span >;
    h += "<span class='legend-chip'><span class='legend-box hm-med'>>50–90%</span>"</span >;
    h += "<span class='legend-chip'><span class='legend-box hm-high'>>90–100%</span>"</span >;
    h += "<span class='legend-chip'><span class='legend-box hm-critical'>>100%</span>"</span >;
    h += "</div>";
    h += "</div>";
    h += "<div class='heat-panel'>";
    h += "<div class='heat-panel-title'>Capacity Parameters</div>";
    h += "<div class='heat-panel-sub'>Configured in GOVERNANCE_CONFIG.capacityHeatmap: displayGroups, pressureGroups, sizeAllocation, supportingAllocation and pressureBands. Change those values only to adjust the model later.</div>";
    h += "</div>";
    return h;
} function resetStatusSelectionToCompleted() {
    var g;
    for (g in selectedStatusGroups) {
        if (selectedStatusGroups.hasOwnProperty(g)) { selectedStatusGroups[g] = false; }
    }
    selectedStatusGroups.Completed = true;
    selectedReviewStatus = "";
}
function toggleGoLiveMonthFilter(monthKey) {
    selectedGoLiveMonth = selectedGoLiveMonth === monthKey ? "" : monthKey;
    resetStatusSelectionToCompleted();
    render();
}
/* ===== Excel Export - Project Listing ===== */function excelClean(v) { if (v === null || v === undefined) return ""; return String(v).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim(); } function excelYesNo(v) { return v ? "Yes" : "No"; } function activeStatusGroupText() { var out = [], g; for (g in selectedStatusGroups) { if (selectedStatusGroups.hasOwnProperty(g) && selectedStatusGroups[g]) out.push(g); } return out.join(", "); } function exportProjectRows() { return projectRecords(); } function exportProjectRowsToJson(records) { var out = [], i, p, group, queueDays, sla, queueBreach, goLiveDelayed, baseline0AgeBreach; for (i = 0; i < records.length; i++) { p = records[i]; group = getGroupedStatus(p.status); queueDays = numericDays(p.queueDays); sla = reviewSlaDays(p); queueBreach = !!(sla && queueDays > sla); goLiveDelayed = isGoLiveDelayed(p); baseline0AgeBreach = isBaseline0Aged(p); out.push({ "Demand Key": p.key || "", "Jira URL": JIRA_BROWSE_URL + (p.key || ""), "Linked Execution Key": p.linkedKey || "", "Demand Issue Type": p.demandIssueType || "", "Linked Issue Type": p.linkedIssueType || "", "Source Type": p.type || "", "Summary": p.summary || "", "Status": p.status || "", "Status Group": group || "", "Platform": p.platform || "", "Accountable Executive Lead": p.lead || "", "SME Lead": p.sme || "", "Supporting SME": supportingSmeText(p) || "", "Assigned Project Manager": p.pm || "", "Size": p.size || "", "Normalized Size": normalizeSize(p.size) || "", "Demand Segment": p.segment || "", "Created Date": formatDateOnly(p.created), "Created Age Days": ageDays(p.created), "Created Age Text": ageText(p.created), "Baseline 0 Age Risk": excelYesNo(baseline0AgeBreach), "Queue Age Days": queueDays || "", "Review SLA Days": sla || "", "Review SLA Breached": excelYesNo(queueBreach), "Go Live Date": formatDateOnly(p.goLive), "Go Live Delayed": excelYesNo(goLiveDelayed), "Proposed Demand Pick-up Date": formatDateOnly(p.pickupDate), "Pickup Overdue": excelYesNo((function () { var d = parseDateValue(p.pickupDate); if (!d) return false; return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() < todayMidnight(); })()), "Portfolio Executive Summary": p.portfolioSummary || "", "Baseline 0 Activities": activityExportText(p, "baseline0"), "Baseline 1 Activities": activityExportText(p, "baseline1"), "Activity Count": (p.activities || []).length, "Current Dashboard Type Filter": selectedType || "ALL", "Current AE Lead Filter": selectedAeLead || "ALL", "Current SME Filter": selectedSme || "ALL", "Current Review Filter": selectedReviewStatus || "ALL", "Current Search Text": selectedSearch || "", "Current Status Groups": activeStatusGroupText() }); } return out; } function downloadExcelHtmlFallback(rows, fileName) {
    var headers = [], i, k, html, blob, url, a;
    if (!rows.length) return;
    for (k in rows[0]) {
        if (rows[0].hasOwnProperty(k)) headers.push(k);
    }
    html = "<meta charset='UTF-8'><table border='1'><thead><tr>";
    for (i = 0; i < headers.length; i++) {
        html += "<th>" + esc(headers[i]) + "</th>";
    }
    html += "</tr></thead><tbody>";
    rows.forEach(function (r) {
        html += "<tr>";
        headers.forEach(function (h) {
            html += "<td>" + esc(r[h]) + "</td>";
        });
        html += "</tr>";
    });
    html += "</tbody></table>";
    blob = new Blob([html], { type: "application/vnd.ms-excel;charset=utf-8;" });
    url = URL.createObjectURL(blob);
    a = document.createElement("a");
    a.href = url;
    a.download = fileName.replace(/\.xlsx$/, ".xls");
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 500);
} function exportProjectListingToExcel() { var records = exportProjectRows(); var rows = exportProjectRowsToJson(records); var fileName = "CET_Project_Listing_" + (new Date().toISOString().slice(0, 10)) + ".xlsx"; var worksheet, workbook, headers; if (!rows.length) { alert("No Project Listing records available to export for the current filters."); return; } try { if (typeof XLSX === "undefined") { downloadExcelHtmlFallback(rows, fileName); return; } worksheet = XLSX.utils.json_to_sheet(rows); headers = Object.keys(rows[0]); worksheet["!cols"] = headers.map(function (h) { return { wch: Math.max(16, Math.min(48, h.length + 8)) }; }); workbook = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(workbook, worksheet, "Project Listing"); XLSX.writeFile(workbook, fileName); } catch (e) { logProgress("Excel XLSX export failed. Fallback XLS export used: " + e.message, "WARN"); downloadExcelHtmlFallback(rows, fileName); } }/* ===== User actions ===== */window.moveGovernanceBoard = moveGovernanceBoard; window.setGovernanceBoardPage = setGovernanceBoardPage; window.pauseGovernanceBoard = pauseGovernanceBoard; window.resumeGovernanceBoard = resumeGovernanceBoard; window.toggleGovernanceBoardPause = toggleGovernanceBoardPause; window.toggleGoLiveMonthFilter = toggleGoLiveMonthFilter; window.exportProjectListingToExcel = exportProjectListingToExcel; window.setActiveTab = function (tabName) { activeTab = tabName; render(); }; window.toggleDashboardTheme = function () { dashboardTheme = dashboardTheme === "dark" ? "light" : "dark"; render(); }; window.setProjectSearch = function (value) { selectedSearch = value || ""; render(); var b = document.getElementById("projectSearchBox"); if (b) { b.focus(); var len = b.value.length; try { b.setSelectionRange(len, len); } catch (e) { } } }; window.clearProjectSearch = function () { selectedSearch = ""; render(); }; window.sortBy = function (col) { if (sortColumn === col) { sortDirection = sortDirection === "ASC" ? "DESC" : "ASC"; } else { sortColumn = col; sortDirection = "ASC"; } render(); }; window.toggleStatusGroup = function (group) { selectedStatusGroups[group] = !selectedStatusGroups[group]; selectedReviewStatus = ""; selectedSme = "ALL"; render(); }; window.setStatusGroupChecked = function (group, isChecked) { selectedStatusGroups[group] = isChecked; selectedReviewStatus = ""; selectedSme = "ALL"; render(); }; window.toggleStatusMenu = function () { var m = document.getElementById("statusFilterMenu"); if (!m) return; m.style.display = m.style.display === "block" ? "none" : "block"; }; window.setAeLeadFilter = function (ae) { selectedType = "Vertical"; selectedAeLead = selectedAeLead === ae ? "ALL" : ae; selectedSme = "ALL"; render(); }; window.setDemandType = function (type) { selectedType = type; selectedSme = "ALL"; selectedAeLead = "ALL"; render(); }; window.setSmeFilter = function (sme) { selectedSme = selectedSme === sme ? "ALL" : sme; render(); }; window.togglePlatformFilter = function (platform) {
    if (selectedPlatforms[platform]) { delete selectedPlatforms[platform]; }
    else { selectedPlatforms[platform] = true; }
    render();
};
window.setAllPlatforms = function () {
    selectedPlatforms = {};
    render();
}; window.setReviewStatusFilter = function (statusName) { selectedReviewStatus = selectedReviewStatus === statusName ? "" : statusName; selectedSme = "ALL"; render(); }; window.clearReviewStatusFilter = function () { selectedReviewStatus = ""; selectedSme = "ALL"; render(); }; window.toggleGovernanceRow = function () { governanceExpanded = !governanceExpanded; render(); }; window.toggleDashboardProgress = function () { var d = document.getElementById("dashboardProgress"); var a = document.getElementById("dashboardProgressArrow"); if (!d) return; if (d.style.display === "none") { d.style.display = "block"; if (a) a.innerHTML = "▼"; } else { d.style.display = "none"; if (a) a.innerHTML = "►"; } };
/* ===== V18 Final local popup-only activity loader, calendar and expansion table ===== */
var V18_POPUP_ACTIVITY_CACHE = {};
var V18_TABLE_CACHE = {};
var V18_ACTIVITY_CONFIG = { phaseIssueType: "Phase", activityIssueType: "Activity", baseline0PhaseKeywords: ["INITIATION PIPELINE", "BASELINE 0"], baseline1PhaseKeywords: ["EXECUTION", "DELIVERY", "COMMITMENT", "BASELINE 1"], baseline0: ["Scope", "ITA", "Cost Approval", "Plan"], baseline1: ["Develop", "ITQA", "UAT", "Staging", "Go Live"], dateFields: { plannedStart: "Planned Start", plannedEnd: "Planned End", actualStart: "Actual Start Date", actualEnd: "Actual End Date" } };
function v18LinkedKeys(issue) { var links = issue && issue.fields && issue.fields.issuelinks ? issue.fields.issuelinks : [], keys = [], i, li; for (i = 0; i < links.length; i++) { li = links[i]; if (li.outwardIssue && li.outwardIssue.key) keys.push(li.outwardIssue.key); if (li.inwardIssue && li.inwardIssue.key) keys.push(li.inwardIssue.key); } return unique(keys); }
function v18LinkedKeysByType(issue, typeName) { var links = issue && issue.fields && issue.fields.issuelinks ? issue.fields.issuelinks : [], keys = [], i, li, c, t; for (i = 0; i < links.length; i++) { li = links[i]; c = li.outwardIssue || li.inwardIssue; if (!c || !c.key) continue; t = c.fields && c.fields.issuetype && c.fields.issuetype.name ? c.fields.issuetype.name : ""; if (!t || normalize(t) === normalize(typeName)) keys.push(c.key); } return unique(keys); }
function v18PopupFields() { var fields = ["summary", "status", "issuetype", "issuelinks", "created"], names = [DESIGN_FIELDS.summary, DESIGN_FIELDS.status, DESIGN_FIELDS.issueType, V18_ACTIVITY_CONFIG.dateFields.plannedStart, V18_ACTIVITY_CONFIG.dateFields.plannedEnd, V18_ACTIVITY_CONFIG.dateFields.actualStart, V18_ACTIVITY_CONFIG.dateFields.actualEnd], i, id; for (i = 0; i < names.length; i++) { id = FIELD_MAP[names[i]]; if (id && id !== "key" && fields.indexOf(id) < 0) fields.push(id); } return fields.join(","); }
function v18SearchJql(jql) { return jiraSearchAll(jql, v18PopupFields()); }
function v18FetchIssue(key) { if (!key) return Promise.resolve(null); return v18SearchJql("key = " + key).then(function (issues) { return issues && issues.length ? issues[0] : null; }); }
function v18FetchSmallKeys(keys) { keys = unique(keys || []); if (!keys.length) return Promise.resolve([]); if (keys.length === 1) return v18FetchIssue(keys[0]).then(function (x) { return x ? [x] : []; }); return v18SearchJql("key in (" + keys.join(",") + ")"); }
function v18IssueValue(issue, displayName) { var id = FIELD_MAP[displayName]; if (!issue || !id) return ""; if (id === "summary") return issue.fields && issue.fields.summary ? issue.fields.summary : ""; if (id === "status") return issue.fields && issue.fields.status ? issue.fields.status.name : ""; if (id === "issuetype") return issue.fields && issue.fields.issuetype ? issue.fields.issuetype.name : ""; return formatValue(issue.fields ? issue.fields[id] : ""); }
function v18HasKeyword(text, keys) { var s = String(text || "").toUpperCase(), i; for (i = 0; i < keys.length; i++) { if (s.indexOf(keys[i]) >= 0) return true; } return false; }
function v18PhaseType(issue) { var s = v18IssueValue(issue, DESIGN_FIELDS.summary); if (v18HasKeyword(s, V18_ACTIVITY_CONFIG.baseline0PhaseKeywords)) return "B0"; if (v18HasKeyword(s, V18_ACTIVITY_CONFIG.baseline1PhaseKeywords)) return "B1"; return ""; }
function v18Norm(v) { return String(v || "").toLowerCase().replace(/\s+/g, " ").trim(); }
function v18ActivityMatches(name, target) { var n = v18Norm(name), t = v18Norm(target); if (t === "scope" && n.indexOf("scope") >= 0) return true; if (t === "itqa" && (n.indexOf("itqa") >= 0 || n.indexOf("sit") >= 0)) return true; if (t === "go live" && (n.indexOf("go live") >= 0 || n === "live" || n.indexOf("live") >= 0)) return true; if (t === "staging" && (n.indexOf("staging") >= 0 || n.indexOf("stagin") >= 0)) return true; return n === t || n.indexOf(t) >= 0 || t.indexOf(n) >= 0; }
function v18MapActivity(issue, baseline) { var df = V18_ACTIVITY_CONFIG.dateFields, summary = v18IssueValue(issue, DESIGN_FIELDS.summary), status = v18IssueValue(issue, DESIGN_FIELDS.status), actualStart = v18IssueValue(issue, df.actualStart), actualEnd = v18IssueValue(issue, df.actualEnd), plannedStart = v18IssueValue(issue, df.plannedStart), plannedEnd = v18IssueValue(issue, df.plannedEnd); return { key: issue.key, summary: summary, name: summary, status: status, baseline: baseline, plannedStart: plannedStart, plannedEnd: plannedEnd, actualStart: actualStart, actualEnd: actualEnd, start: actualStart || plannedStart || "", end: actualEnd || plannedEnd || "" }; }
function v18ProjectKeyFromRecord(record) { if (record.linkedKey) return record.linkedKey; if (record.projectKey) return record.projectKey; if (record.executionKey) return record.executionKey; if (record.projectIssueKey) return record.projectIssueKey; var i, row, keys; for (i = 0; i < ALL_DEMANDS.length; i++) { row = ALL_DEMANDS[i]; if (row && row.issue && row.issue.key === record.key) { keys = getLinkedIssueKeysFromDemand(row.issue); return keys && keys.length ? keys[0] : ""; } } return ""; }
function v18OrderActivities(list, baseline) { var order = baseline === "B1" ? V18_ACTIVITY_CONFIG.baseline1 : V18_ACTIVITY_CONFIG.baseline0, out = [], used = {}, i, j; for (i = 0; i < order.length; i++) { for (j = 0; j < (list || []).length; j++) { if (used[j]) continue; if (v18ActivityMatches(list[j].summary || list[j].name, order[i])) { out.push(list[j]); used[j] = true; break; } } } return out; }
function v18EnsureTbdActivities(list, baseline) { var order = baseline === "B1" ? V18_ACTIVITY_CONFIG.baseline1 : V18_ACTIVITY_CONFIG.baseline0, out = v18OrderActivities(list || [], baseline), existing = {}, i, j; for (i = 0; i < out.length; i++) { for (j = 0; j < order.length; j++) { if (v18ActivityMatches(out[i].summary || out[i].name, order[j])) existing[order[j]] = true; } } for (i = 0; i < order.length; i++) { if (!existing[order[i]]) out.push({ summary: order[i], name: order[i], status: "TBD", baseline: baseline, plannedStart: "", plannedEnd: "", actualStart: "", actualEnd: "", start: "", end: "" }); } return v18OrderActivities(out, baseline); }
function v18FetchCalendarForRecord(record) { var cacheKey = record.key + "|" + (v18ProjectKeyFromRecord(record) || ""); if (V18_POPUP_ACTIVITY_CACHE[cacheKey]) return Promise.resolve(V18_POPUP_ACTIVITY_CACHE[cacheKey]); var demandKey = record.key, knownProjectKey = v18ProjectKeyFromRecord(record); logProgress("P/Expansion Activity load started for selected demand only: " + demandKey, "INFO"); return Promise.resolve().then(function () { if (knownProjectKey) return v18FetchIssue(knownProjectKey); return v18FetchIssue(demandKey).then(function (demandIssue) { if (!demandIssue) throw new Error("Demand not found: " + demandKey); var projectKeys = v18LinkedKeysByType(demandIssue, "Project"); if (!projectKeys.length) projectKeys = v18LinkedKeys(demandIssue); if (!projectKeys.length) throw new Error("No linked Project found for demand " + demandKey); return v18FetchIssue(projectKeys[0]); }); }).then(function (projectIssue) { if (!projectIssue) throw new Error("Linked Project not found for demand " + demandKey); var phaseKeys = v18LinkedKeysByType(projectIssue, V18_ACTIVITY_CONFIG.phaseIssueType); if (!phaseKeys.length) phaseKeys = v18LinkedKeys(projectIssue); if (!phaseKeys.length) return { baseline0: [], baseline1: [], projectIssue: projectIssue }; return v18FetchSmallKeys(phaseKeys).then(function (phaseIssues) { var b0PhaseKeys = [], b1PhaseKeys = [], i, phase, type; for (i = 0; i < phaseIssues.length; i++) { phase = phaseIssues[i]; type = v18PhaseType(phase); if (type === "B0") b0PhaseKeys.push(phase.key); if (type === "B1") b1PhaseKeys.push(phase.key); } return v18FetchActivitiesForPhases(phaseIssues, b0PhaseKeys, b1PhaseKeys, projectIssue); }); }).then(function (result) { result.baseline0 = v18EnsureTbdActivities(result.baseline0, "B0"); result.baseline1 = v18EnsureTbdActivities(result.baseline1, "B1"); V18_POPUP_ACTIVITY_CACHE[cacheKey] = result; logProgress("Activity loaded for " + demandKey + " | B0 " + result.baseline0.length + " | B1 " + result.baseline1.length, "SUCCESS"); return result; }); }
function v18FetchActivitiesForPhases(phaseIssues, b0PhaseKeys, b1PhaseKeys, projectIssue) { var baseline0 = [], baseline1 = []; function next(index) { if (index >= phaseIssues.length) return Promise.resolve({ baseline0: baseline0, baseline1: baseline1, projectIssue: projectIssue, phaseIssues: phaseIssues }); var phase = phaseIssues[index], baseline = b0PhaseKeys.indexOf(phase.key) >= 0 ? "B0" : (b1PhaseKeys.indexOf(phase.key) >= 0 ? "B1" : ""); if (!baseline) return next(index + 1); var activityKeys = v18LinkedKeysByType(phase, V18_ACTIVITY_CONFIG.activityIssueType); if (!activityKeys.length) activityKeys = v18LinkedKeys(phase); return v18FetchSmallKeys(activityKeys).then(function (activityIssues) { var i, a, name, order = baseline === "B1" ? V18_ACTIVITY_CONFIG.baseline1 : V18_ACTIVITY_CONFIG.baseline0, j, matched; for (i = 0; i < activityIssues.length; i++) { a = activityIssues[i]; name = v18IssueValue(a, DESIGN_FIELDS.summary); matched = false; for (j = 0; j < order.length; j++) { if (v18ActivityMatches(name, order[j])) matched = true; } if (matched) { if (baseline === "B0") baseline0.push(v18MapActivity(a, "B0")); if (baseline === "B1") baseline1.push(v18MapActivity(a, "B1")); } } return next(index + 1); }); } return next(0); }
function v18DateNoYear(v) { var d = parseDateValue(v); if (!d) return "TBD"; var m = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], day = d.getDate(); return (day < 10 ? "0" + day : day) + "-" + m[d.getMonth()]; }
function v18DateRange(a) { var s = a.start || a.actualStart || a.plannedStart || "", e = a.end || a.actualEnd || a.plannedEnd || ""; if (!s && !e) return "TBD"; var ss = v18DateNoYear(s), ee = v18DateNoYear(e); if (ss === "TBD" && ee === "TBD") return "TBD"; if (ss === "TBD") return "Ends " + ee; if (ee === "TBD") return "Starts " + ss; if (ss === ee) return ss; return ss + " → " + ee; }
function v18ActivityStatus(a) { var status = String(a.status || "").toLowerCase(), end = parseDateValue(a.end || a.actualEnd || a.plannedEnd), now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate()); if (status.indexOf("done") >= 0 || status.indexOf("complete") >= 0 || status.indexOf("closed") >= 0 || status === "live") return { label: "Done", cls: "done", pill: "v18-status-done" }; if (!a.start && !a.end && !a.actualStart && !a.actualEnd && !a.plannedStart && !a.plannedEnd) return { label: "TBD", cls: "tbd", pill: "v18-status-tbd" }; if (end && new Date(end.getFullYear(), end.getMonth(), end.getDate()) < today) return { label: "Breached", cls: "breach", pill: "v18-status-breach" }; return { label: "Open", cls: "progress", pill: "v18-status-open" }; }
function v18Months(all) { var i, d, min = null, max = null; for (i = 0; i < all.length; i++) { d = parseDateValue(all[i].start || all[i].end || all[i].actualStart || all[i].plannedStart); if (d && (!min || d < min)) min = d; d = parseDateValue(all[i].end || all[i].start || all[i].actualEnd || all[i].plannedEnd); if (d && (!max || d > max)) max = d; } if (!min || !max) { min = new Date(); max = new Date(); max.setMonth(max.getMonth() + 5); } min = new Date(min.getFullYear(), min.getMonth(), 1); max = new Date(max.getFullYear(), max.getMonth() + 1, 0); var out = [], cur = new Date(min.getFullYear(), min.getMonth(), 1); while (cur <= max) { out.push(new Date(cur.getFullYear(), cur.getMonth(), 1)); cur.setMonth(cur.getMonth() + 1); } while (out.length < 4) { cur = new Date(out[out.length - 1].getFullYear(), out[out.length - 1].getMonth() + 1, 1); out.push(cur); } return out; }
function v18MonthLabel(d) { var m = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]; return m[d.getMonth()] + " " + d.getFullYear(); }
function v18TaskPos(a, months, idx) { if (!months.length) return { left: 2, width: 18 }; var s = parseDateValue(a.start || a.actualStart || a.plannedStart), e = parseDateValue(a.end || a.actualEnd || a.plannedEnd); if (!s && !e) { var sw = 100 / months.length, slot = idx % months.length; return { left: (slot * sw) + 2, width: Math.max(16, sw - 4) }; } if (!s) s = e; if (!e) e = s; var bs = new Date(months[0].getFullYear(), months[0].getMonth(), 1).getTime(), last = months[months.length - 1], be = new Date(last.getFullYear(), last.getMonth() + 1, 0).getTime(), total = be - bs, st = Math.max(bs, Math.min(be, s.getTime())), en = Math.max(bs, Math.min(be, e.getTime())), left = ((st - bs) / total) * 100, right = ((en - bs) / total) * 100, width = Math.max(16, right - left); if (left + width > 98.5) width = 98.5 - left; return { left: left, width: width }; }
function v18RenderPhaseRow(title, sub, acts, months, baseline) { acts = v18EnsureTbdActivities(acts || [], baseline); var h = "<div class='phase-band'><div class='phase-label'><b>" + esc(title) + "</b><span>" + esc(sub) + "</div><div class='phase-track'>"</span>, i, a, pos, st, top; for (i = 0; i < acts.length; i++) { a = acts[i]; pos = v18TaskPos(a, months, i); st = v18ActivityStatus(a); top = 14 + (i % 3) * 56; h += "<div class='task " + st.cls + "' title='" + esc((a.summary || a.name || "") + " | " + v18DateRange(a)) + "' style='left:" + pos.left.toFixed(2) + "%;width:" + pos.width.toFixed(2) + "%;top:" + top + "px'><span class='task-name'>" + esc(a.summary || a.name || "") + "<span class='task-date'>"</span > +esc(v18DateRange(a)) + "</div>"</span >; } return h + "</div></div>"; }
function v18RenderCalendar(record, data) {
    var b0 = v18EnsureTbdActivities(data.baseline0 || [], "B0"), b1 = v18EnsureTbdActivities(data.baseline1 || [], "B1"), months = v18Months(b0.concat(b1)), h = "", i; h += "<div class='activity-calendar-toolbar'><div><b>Project Phase Activity Calendar</b>
        < span > Clean monthly view.Activities are ordered and placed in lanes to avoid overlap.</div > <div class='legend-row'><span class='legend-chip lg-done'>Done</span><span class='legend-chip lg-progress'>Planned / Open</span><span class='legend-chip lg-breach'>Breached</span><span class='legend-chip lg-tbd'>TBD</span></div></div > "</span>;h+=" < div class='timeline-scroll' > <div class='gantt-board' style='--gantt-month-count:"+months.length+"'><div class='gantt-months'><div>Phase</div>";for(i=0;i<months.length; i++)h+="<div>"+esc(v18MonthLabel(months[i]))+"</div>";h+="</div>"+v18RenderPhaseRow("Baseline 0","Initiation Pipeline",b0,months,"B0")+v18RenderPhaseRow("Baseline 1","Execution / Delivery",b1,months,"B1")+"</div></div > <div class='phase-footer'><span>Top: Activity Summary.<span>Bottom: DD-MMM date range.</span><span>TBD activities are shown in configured sequence.</span></div>"</span>; return h;
}
function v18RenderActivityTable(data) {
    var b0 = v18EnsureTbdActivities(data.baseline0 || [], "B0"), b1 = v18EnsureTbdActivities(data.baseline1 || [], "B1"), rows = [], i, a, st, h = "<table class='v18-activity-table'><thead><tr><th>Activity</th><th>Dates</th><th>Status</th></tr></thead><tbody>"; for (i = 0; i < b0.length; i++)rows.push({ b: "Baseline 0", c: "v18-b0-label", a: b0[i] }); for (i = 0; i < b1.length; i++)rows.push({ b: "Baseline 1", c: "v18-b1-label", a: b1[i] }); for (i = 0; i < rows.length; i++) {
        a = rows[i].a; st = v18ActivityStatus(a); h += "<tr><td><span class='v18-baseline-label " + rows[i].c + "'>" + esc(rows[i].b) + "
        "</span>+esc(a.summary||a.name||"")+"</td > <td><span class='v18-date-cell'>"+esc(v18DateRange(a))+"</td><td><span class='v18-status-pill "</span>+st.pill+"'>"+esc(st.label)+"</td></tr>"</span>;
    } return h + "</tbody></table>";
}
function openActivityCalendarPopup(recordIndex) {
    var records = projectRecords(), record = records[recordIndex]; if (!record) { alert("Unable to locate selected demand record."); return; } closeActivityCalendarPopup(); var h = "<div id='activityCalendarPopup' class='activity-calendar-modal'><div class='activity-calendar-window'><div class='activity-calendar-header'><div><div class='activity-calendar-title'>Activity Calendar - " + esc(record.key) + "</div><div class='activity-calendar-sub'>" + esc(record.summary || "") + "</div></div><button type='button' class='activity-calendar-close' onclick='closeActivityCalendarPopup()'>×</button></div><div id='activityCalendarPopupBody' class='activity-calendar-body'><div class='activity-calendar-loading'>Loading live Phase / Activity details for this selected demand only...</div></div></div></div>"; document.body.insertAdjacentHTML("beforeend", h); v18FetchCalendarForRecord(record).then(function (data) { var key = record.key + "|" + (v18ProjectKeyFromRecord(record) || record.linkedKey || ""); V18_TABLE_CACHE[key] = data; record.activities = (data.baseline0 || []).concat(data.baseline1 || []); var body = document.getElementById("activityCalendarPopupBody"); if (body) body.innerHTML = v18RenderCalendar(record, data); if (typeof refreshGovernanceBoardOnly === "function") { refreshGovernanceBoardOnly(); } }).catch(function (err) {
        var body = document.getElementById("activityCalendarPopupBody"); if (body) body.innerHTML = "<div class='dd-error'><b>Unable to load Activity Calendar</b>
        "+esc(err.message||err)+"</div > ";});}
        function closeActivityCalendarPopup() { var el = document.getElementById("activityCalendarPopup"); if (el) el.remove(); }

        window.closeActivityTimelineModal = closeActivityCalendarPopup;
        /* ===== V19 CLEAN HELPERS: rich text, shared activity flow, no duplicate projectList ===== */
        function v19RichText(value) {
            var raw = String(value || "").trim();
            if (!raw) { return "<span style='color:#64748b;font-weight:800'>No information available."</span >; }

            function inlineFormat(s) {
                s = esc(s);
                s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
                s = s.replace(/\*([^*]+)\*/g, "<strong>$1</strong>");
                s = s.replace(/__([^_]+)__/g, "<strong>$1</strong>");
                return s;
            }

            if (/<\/?[a-z][\s\S]*>/i.test(raw)) {
                var tmp = document.createElement("div");
                tmp.innerHTML = raw;
                var allowed = { "B": 1, "STRONG": 1, "I": 1, "EM": 1, "U": 1, "BR": 1, "P": 1, "UL": 1, "OL": 1, "LI": 1, "DIV": 1, "SPAN": 1 };
                (function cleanNode(node) {
                    var children = [].slice.call(node.children || []);
                    for (var i = 0; i < children.length; i++) {
                        var c = children[i];
                        if (!allowed[c.tagName]) {
                            var text = document.createTextNode(c.innerText || c.textContent || "");
                            c.parentNode.replaceChild(text, c);
                        } else {
                            while (c.attributes && c.attributes.length) { c.removeAttribute(c.attributes[0].name); }
                            cleanNode(c);
                        }
                    }
                })(tmp);
                return tmp.innerHTML;
            }
            var lines = raw.replace(/\r/g, "").split("\n");
            var html = "", inUl = false, inOl = false;

            function closeLists() {
                if (inUl) { html += "</ul>"; inUl = false; }
                if (inOl) { html += "</ol>"; inOl = false; }
            }

            for (var i = 0; i < lines.length; i++) {
                var line = lines[i].trim();
                if (!line) { closeLists(); continue; }

                var m = line.match(/^(\d+)[\.\)]\s+(.*)$/);
                if (m) {
                    if (inUl) { html += "</ul>"; inUl = false; }
                    if (!inOl) { html += "<ol>"; inOl = true; }
                    html += "<li>" + inlineFormat(m[2]) + "</li>";
                    continue;
                }

                m = line.match(/^[-•]\s+(.*)$/);
                if (m) {
                    if (inOl) { html += "</ol>"; inOl = false; }
                    if (!inUl) { html += "<ul>"; inUl = true; }
                    html += "<li>" + inlineFormat(m[1]) + "</li>";
                    continue;
                }

                closeLists();
                html += "<p>" + inlineFormat(line) + "</p>";
            }
            closeLists();
            return html;
        }

        function v19FlowStep(activity) {
            var st = v18ActivityStatus(activity);
            var name = activity.summary || activity.name || "Activity";
            var date = v18DateRange(activity);

            return "<div class='v19-flow-step " + st.cls + "' title='" + esc(name + " | " + date + " | " + st.label) + "'>" +
                "<div class='v19-flow-step-name'>" + esc(name) + "</div>" +
                "<div class='v19-flow-step-date'>" + esc(date) + "</div>" +
                "</div>";
        }

        function v19FlowRow(label, activities) {
            var h = "";
            var i;

            h += "<div class='v19-flow-row'>";
            h += "<div class='v19-flow-label'><span>" + esc(label) + "<span class='v19-flow-count'>"</span > +activities.length + " activities</div>"</span >;
            h += "<div class='v19-flow-steps'>";

            for (i = 0; i < activities.length; i++) {
                h += v19FlowStep(activities[i]);
            }

            h += "</div></div>";
            return h;
        }

        function v19RenderActivityFlow(data) {
            var b0 = v18EnsureTbdActivities((data && data.baseline0) || [], "B0");
            var b1 = v18EnsureTbdActivities((data && data.baseline1) || [], "B1");

            return "<div class='v19-flow-body'>" +
                v19FlowRow("Baseline 0", b0) +
                v19FlowRow("Baseline 1", b1) +
                "</div>";
        }

        function v19LoadExpansionActivityFlow(i) {
            var target = document.getElementById("v19_activity_flow_" + i);
            var records = projectRecords();
            var record = records[i];
            if (!target || !record) {
                logProgress("V19 flow: target or record missing for row " + i, "WARN");
                return;
            }

            var body = target.querySelector(".v19-card-body");
            if (!body) {
                logProgress("V19 flow: body container missing for " + record.key, "WARN");
                return;
            }

            var key = record.key + "|" + (record.linkedKey || "");
            if (V18_TABLE_CACHE[key]) {
                record.activities = (V18_TABLE_CACHE[key].baseline0 || []).concat(V18_TABLE_CACHE[key].baseline1 || []);
                body.innerHTML = v19RenderActivityFlow(V18_TABLE_CACHE[key]);
                if (typeof refreshGovernanceBoardOnly === "function") { refreshGovernanceBoardOnly(); }
                logProgress("V19 flow reused cache for " + record.key, "SUCCESS");
                return;
            }

            body.innerHTML = "<div class='v19-flow-loading'>Loading Baseline Activity Flow from Jira...</div>";
            logProgress("V19 expansion flow loading for selected demand only: " + record.key, "INFO");

            v18FetchCalendarForRecord(record).then(function (data) {
                V18_TABLE_CACHE[key] = data;
                record.activities = (data.baseline0 || []).concat(data.baseline1 || []);
                body.innerHTML = v19RenderActivityFlow(data);
                if (typeof refreshGovernanceBoardOnly === "function") { refreshGovernanceBoardOnly(); }
                logProgress("V19 expansion flow rendered for " + record.key, "SUCCESS");
            }).catch(function (err) {
                body.innerHTML = "<div class='dd-error'><b>Unable to load activity flow</b>
                "+esc(err.message||err)+"</div > ";
                logProgress("V19 expansion flow failed for " + record.key + " : " + (err.message || err), "ERROR");
            });
        }





        window.closeActivityTimelineModal = closeActivityCalendarPopup;


        window.toggleSummary = function (i) {
            var d = document.getElementById("summary_" + i);
            if (!d) return;
            var opening = d.style.display !== "block";
            d.style.display = opening ? "block" : "none";
            if (opening && typeof v19LoadExpansionActivityFlow === "function") {
                v19LoadExpansionActivityFlow(i);
            }
        }; filterId function openActivityTimelineModal(i) { return openActivityCalendarPopup(i); }
        window.openActivityTimelineModal = openActivityTimelineModal;
        window.closeActivityTimelineModal = closeActivityCalendarPopup;


        /* ===== V19.1 PATCH: DD-MMM-YY dates, iconic rich text, and no-overlap popup lanes ===== */
        function v19DateNoYear(value) {
            var d = parseDateValue(value);
            if (!d) return "TBD";
            var m = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            var day = d.getDate();
            var yy = String(d.getFullYear()).slice(-2);
            return (day < 10 ? "0" + day : day) + "-" + m[d.getMonth()] + "-" + yy;
        }

        /* Override shared date range used by both P popup and expansion activity flow */
        function v18DateRange(a) {
            var s = a.start || a.actualStart || a.plannedStart || "";
            var e = a.end || a.actualEnd || a.plannedEnd || "";
            if (!s && !e) return "TBD";
            var ss = v19DateNoYear(s), ee = v19DateNoYear(e);
            if (ss === "TBD" && ee === "TBD") return "TBD";
            if (ss === "TBD") return "Ends " + ee;
            if (ee === "TBD") return "Starts " + ss;
            if (ss === ee) return ss;
            return ss + " → " + ee;
        }

        /* Replace rich text renderer to handle Jira-style * bullets and *bold labels* */
        function v19RichText(value) {
            var raw = String(value || "").trim();
            if (!raw) { return "<span style='color:#64748b;font-weight:800'>No information available."</span >; }

            function inlineFormat(s) {
                s = esc(s);
                s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
                s = s.replace(/\*([^*]+)\*/g, "<strong>$1</strong>");
                s = s.replace(/__([^_]+)__/g, "<strong>$1</strong>");
                return s;
            }

            if (/<\/?[a-z][\s\S]*>/i.test(raw)) {
                var tmp = document.createElement("div");
                tmp.innerHTML = raw;
                var allowed = { "B": 1, "STRONG": 1, "I": 1, "EM": 1, "U": 1, "BR": 1, "P": 1, "UL": 1, "OL": 1, "LI": 1, "DIV": 1, "SPAN": 1 };
                (function cleanNode(node) {
                    var children = [].slice.call(node.children || []);
                    for (var i = 0; i < children.length; i++) {
                        var c = children[i];
                        if (!allowed[c.tagName]) {
                            var text = document.createTextNode(c.innerText || c.textContent || "");
                            c.parentNode.replaceChild(text, c);
                        } else {
                            while (c.attributes && c.attributes.length) { c.removeAttribute(c.attributes[0].name); }
                            cleanNode(c);
                        }
                    }
                })(tmp);
                return tmp.innerHTML;
            }

            var lines = raw.replace(/\r/g, "").split("\n");
            var html = "", inUl = false, inOl = false, inSection = false;

            function closeLists() {
                if (inUl) { html += "</ul>"; inUl = false; }
                if (inOl) { html += "</ol>"; inOl = false; }
            }
            function closeSection() {
                closeLists();
                if (inSection) { html += "</div>"; inSection = false; }
            }
            function openSection(title) {
                closeSection();
                html += "<div class='v19-rt-section'><div class='v19-rt-heading'>" + inlineFormat(title) + "</div>";
                inSection = true;
            }

            for (var i = 0; i < lines.length; i++) {
                var line = lines[i].trim();
                if (!line) { closeLists(); continue; }

                var heading = line.match(/^\*([^*]+):\*$/) || line.match(/^\*\*([^*]+):\*\*$/);
                if (heading) {
                    openSection(heading[1] + ":");
                    continue;
                }

                var m = line.match(/^(\d+)[\.\)]\s+(.*)$/);
                if (m) {
                    if (inUl) { html += "</ul>"; inUl = false; }
                    if (!inOl) { html += "<ol>"; inOl = true; }
                    html += "<li>" + inlineFormat(m[2]) + "</li>";
                    continue;
                }

                m = line.match(/^[-•]\s+(.*)$/) || line.match(/^\*\s+(.*)$/);
                if (m) {
                    if (inOl) { html += "</ol>"; inOl = false; }
                    if (!inUl) { html += "<ul>"; inUl = true; }
                    html += "<li>" + inlineFormat(m[1]) + "</li>";
                    continue;
                }

                if (!inSection) { html += "<div class='v19-rt-section'>"; inSection = true; }
                closeLists();
                html += "<p>" + inlineFormat(line) + "</p>";
            }
            closeSection();
            return html;
        }

        /* Override popup phase row: one dedicated lane per activity to prevent overlap */
        function v18RenderPhaseRow(title, sub, acts, months, baseline) {
            acts = v18EnsureTbdActivities(acts || [], baseline);
            var rowHeight = Math.max(128, 24 + (acts.length * 58));
            var h = "<div class='phase-band'><div class='phase-label'><b>" + esc(title) + "</b><span>" + esc(sub) + "</div><div class='phase-track' style='height:"</span> +rowHeight + "px;min-height:" + rowHeight + "px'>";
            var i, a, pos, st, top;
            for (i = 0; i < acts.length; i++) {
                a = acts[i];
                pos = v18TaskPos(a, months, i);
                st = v18ActivityStatus(a);
                top = 14 + (i * 56);
                h += "<div class='task " + st.cls + "' title='" + esc((a.summary || a.name || "") + " | " + v18DateRange(a)) + "' style='left:" + pos.left.toFixed(2) + "%;width:" + pos.width.toFixed(2) + "%;top:" + top + "px'>";
                h += "<span class='task-name'>" + esc(a.summary || a.name || "") + ""</span >;
                h += "<span class='task-date'>" + esc(v18DateRange(a)) + ""</span >;
                h += "</div>";
            }
            h += "</div></div>";
            return h;
        }

        /* Override popup calendar render to allow horizontal/vertical scroll and full month bar visibility */
        function v18RenderCalendar(record, data) {
            var b0 = v18EnsureTbdActivities((data && data.baseline0) || [], "B0");
            var b1 = v18EnsureTbdActivities((data && data.baseline1) || [], "B1");
            var months = v18Months(b0.concat(b1));
            var minWidth = Math.max(1500, 150 + (months.length * 255));
            var h = "", i;
            h += "<div class='activity-calendar-toolbar'><div><b>Project Phase Activity Calendar</b>
                < span > Clean monthly view.Activities are ordered and placed in dedicated lanes to avoid overlap.</div > "</span>;
            h += "<div class='legend-row'><span class='legend-chip lg-done'>Done<span class='legend-chip lg-progress'>Planned / Open</span><span class='legend-chip lg-breach'>Breached</span><span class='legend-chip lg-tbd'>TBD</span></div></div>"</span >;
            h += "<div class='timeline-scroll'><div class='gantt-board' style='--gantt-month-count:" + months.length + ";min-width:" + minWidth + "px'><div class='gantt-months'><div>Phase</div>";
            for (i = 0; i < months.length; i++) { h += "<div>" + esc(v18MonthLabel(months[i])) + "</div>"; }
            h += "</div>";
            h += v18RenderPhaseRow("Baseline 0", "Initiation Pipeline", b0, months, "B0");
            h += v18RenderPhaseRow("Baseline 1", "Execution / Delivery", b1, months, "B1");
            h += "</div></div>";
            h += "<div class='phase-footer'><span>Top: Activity Summary.<span>Bottom: DD-MMM-YY date range.</span><span>Each activity uses its own lane to avoid overlap.</span></div>"</span >;
            return h;
        }


        /* ===== V19.2 PATCH: Compact popup width, aligned calendar bars, natural Jira bullets ===== */
        function v19DateShortYear(value) {
            var d = parseDateValue(value);
            if (!d) return "TBD";
            var m = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            var day = d.getDate();
            var yy = String(d.getFullYear()).slice(-2);
            return (day < 10 ? "0" + day : day) + "-" + m[d.getMonth()] + "-" + yy;
        }
        /* Used by Activity Flow and Popup */
        function v18DateRange(a) {
            var s = a.start || a.actualStart || a.plannedStart || "";
            var e = a.end || a.actualEnd || a.plannedEnd || "";
            if (!s && !e) return "TBD";
            var ss = v19DateShortYear(s), ee = v19DateShortYear(e);
            if (ss === "TBD" && ee === "TBD") return "TBD";
            if (ss === "TBD") return "Ends " + ee;
            if (ee === "TBD") return "Starts " + ss;
            if (ss === ee) return ss;
            return ss + " → " + ee;
        }

        /* Less aggressive Jira rich-text formatter:
           - Keeps normal bullets as bullets
           - Converts only clear heading lines like *This Week Target:* into an iconic heading
           - Does not turn every bullet/special char into a tick icon
        */
        function v19RichText(value) {
            var raw = String(value || "").trim();
            if (!raw) { return "<span style='color:#64748b;font-weight:800'>No information available."</span >; }

            function inlineFormat(s) {
                s = esc(s);
                s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
                s = s.replace(/\*([^*]+)\*/g, "<strong>$1</strong>");
                s = s.replace(/__([^_]+)__/g, "<strong>$1</strong>");
                return s;
            }

            if (/<\/?[a-z][\s\S]*>/i.test(raw)) {
                var tmp = document.createElement("div");
                tmp.innerHTML = raw;
                var allowed = { "B": 1, "STRONG": 1, "I": 1, "EM": 1, "U": 1, "BR": 1, "P": 1, "UL": 1, "OL": 1, "LI": 1, "DIV": 1, "SPAN": 1 };
                (function cleanNode(node) {
                    var children = [].slice.call(node.children || []);
                    for (var i = 0; i < children.length; i++) {
                        var c = children[i];
                        if (!allowed[c.tagName]) {
                            var text = document.createTextNode(c.innerText || c.textContent || "");
                            c.parentNode.replaceChild(text, c);
                        } else {
                            while (c.attributes && c.attributes.length) { c.removeAttribute(c.attributes[0].name); }
                            cleanNode(c);
                        }
                    }
                })(tmp);
                return tmp.innerHTML;
            }

            var lines = raw.replace(/\r/g, "").split("\n");
            var html = "", inUl = false, inOl = false, inSection = false;

            function closeLists() {
                if (inUl) { html += "</ul>"; inUl = false; }
                if (inOl) { html += "</ol>"; inOl = false; }
            }
            function closeSection() {
                closeLists();
                if (inSection) { html += "</div>"; inSection = false; }
            }
            function openSection(title) {
                closeSection();
                html += "<div class='v19-rt-section'><div class='v19-rt-heading'>" + inlineFormat(title) + "</div>";
                inSection = true;
            }

            for (var i = 0; i < lines.length; i++) {
                var line = lines[i].trim();
                if (!line) { closeLists(); continue; }

                var heading = line.match(/^\*([^*]{2,80}:)\*$/) || line.match(/^\*\*([^*]{2,80}:)\*\*$/);
                if (heading) {
                    openSection(heading[1]);
                    continue;
                }

                var numbered = line.match(/^(\d+)[\.\)]\s+(.*)$/);
                if (numbered) {
                    if (inUl) { html += "</ul>"; inUl = false; }
                    if (!inOl) { html += "<ol>"; inOl = true; }
                    html += "<li>" + inlineFormat(numbered[2]) + "</li>";
                    continue;
                }

                /* Treat only actual bullet marker followed by space as a list item.
                   This prevents random *, ), (, etc. from becoming icons/list items. */
                var bullet = line.match(/^[-•]\s+(.*)$/) || line.match(/^\*\s+(.*)$/);
                if (bullet) {
                    if (inOl) { html += "</ol>"; inOl = false; }
                    if (!inUl) { html += "<ul>"; inUl = true; }
                    html += "<li>" + inlineFormat(bullet[1]) + "</li>";
                    continue;
                }

                if (!inSection) { html += "<div class='v19-rt-section'>"; inSection = true; }
                closeLists();
                html += "<p>" + inlineFormat(line) + "</p>";
            }
            closeSection();
            return html;
        }

        /* ===== V19.4 STRUCTURED PROJECT PLAN GRID CONFIGURATION =====
           Keep P-popup / expansion visual parameters here for easy maintenance.
        */
        var V19_PROJECT_PLAN_GRID_CONFIG = {
            labelColumnWidthPx: 128,
            monthColumnWidthPx: 220,
            minBoardWidthPx: 1280,
            maxRightPct: 99.20,
            minBarWidthPct: 5.60,
            baselineHeaderHeightPx: 34,
            laneHeightPx: 44,
            laneTopPaddingPx: 6,
            barHeightPx: 32,
            barVerticalOffsetPx: 6
        };

        function v19MonthStart(d) {
            return new Date(d.getFullYear(), d.getMonth(), 1);
        }

        function v19MonthEnd(d) {
            return new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59, 999);
        }

        function v19MonthMidPoint(monthDate) {
            var s = v19MonthStart(monthDate).getTime();
            var e = v19MonthEnd(monthDate).getTime();
            return s + ((e - s) / 2);
        }

        function v18TaskPos(a, months, idx) {
            var cfg = V19_PROJECT_PLAN_GRID_CONFIG;
            var monthCount = (months && months.length) ? months.length : 1;
            var monthPct = 100 / monthCount;

            if (!months || !months.length) {
                return { left: 1, width: cfg.minBarWidthPct };
            }

            var s = parseDateValue(a.start || a.actualStart || a.plannedStart);
            var e = parseDateValue(a.end || a.actualEnd || a.plannedEnd);

            if (!s && !e) {
                return {
                    left: Math.min(cfg.maxRightPct - cfg.minBarWidthPct, (idx % monthCount) * monthPct + 1),
                    width: Math.max(cfg.minBarWidthPct, Math.min(monthPct - 2, cfg.minBarWidthPct + 2))
                };
            }

            if (!s) { s = e; }
            if (!e) { e = s; }
            if (e.getTime() < s.getTime()) {
                var swap = s;
                s = e;
                e = swap;
            }

            var boardStart = v19MonthStart(months[0]).getTime();
            var boardEnd = v19MonthEnd(months[monthCount - 1]).getTime();
            var total = Math.max(1, boardEnd - boardStart);

            var startTime = Math.max(boardStart, Math.min(boardEnd, s.getTime()));
            var endTime = Math.max(boardStart, Math.min(boardEnd, e.getTime()));

            /* Single-day items are centered in their month so last-month bars remain aligned. */
            if (Math.abs(endTime - startTime) < 86400000) {
                var mIndex = Math.max(0, Math.min(monthCount - 1, (s.getFullYear() - months[0].getFullYear()) * 12 + (s.getMonth() - months[0].getMonth())));
                var center = ((v19MonthMidPoint(months[mIndex]) - boardStart) / total) * 100;
                var w = Math.min(Math.max(cfg.minBarWidthPct, monthPct * .42), monthPct - 2);
                var l = Math.max(0.75, center - (w / 2));
                if (l + w > cfg.maxRightPct) { l = cfg.maxRightPct - w; }
                return { left: l, width: w };
            }

            var left = ((startTime - boardStart) / total) * 100;
            var right = ((endTime - boardStart) / total) * 100;
            var width = Math.max(cfg.minBarWidthPct, right - left);

            if (left + width > cfg.maxRightPct) {
                width = Math.max(cfg.minBarWidthPct, cfg.maxRightPct - left);
            }

            return { left: left, width: width };
        }

        function v19PlanTrackHeight(activityCount) {
            var cfg = V19_PROJECT_PLAN_GRID_CONFIG;
            return Math.max(cfg.laneHeightPx, Math.max(1, activityCount || 0) * cfg.laneHeightPx);
        }

        function v19RenderActivityLabels(acts) {
            var h = "";
            var i, a;

            h += "<div class='v19-plan-activity-labels'>";
            for (i = 0; i < acts.length; i++) {
                a = acts[i];
                h += "<div class='v19-plan-activity-label'>" +
                    "<b>" + esc(a.summary || a.name || "Activity") + "</b>" +
                    "<span>" + esc(v18DateRange(a)) + ""</span > +
                        "</div>";
            }
            h += "</div>";

            return h;
        }

        function v18RenderPhaseRow(title, sub, acts, months, baseline) {
            var cfg = V19_PROJECT_PLAN_GRID_CONFIG;
            acts = v18EnsureTbdActivities(acts || [], baseline);

            var rowHeight = v19PlanTrackHeight(acts.length);
            var h = "";
            var i, a, pos, st, top;

            h += "<div class='v19-plan-baseline' style='grid-template-columns:" + cfg.labelColumnWidthPx + "px 1fr'>";
            h += "<div class='v19-plan-baseline-title'>" + esc(title) + " <span>" + esc(sub) + " | " + acts.length + " activities</div>"</span >;
            h += v19RenderActivityLabels(acts);
            h += "<div class='v19-plan-track' style='height:" + rowHeight + "px;min-height:" + rowHeight + "px'>";

            for (i = 0; i < acts.length; i++) {
                a = acts[i];
                pos = v18TaskPos(a, months, i);
                st = v18ActivityStatus(a);
                top = (i * cfg.laneHeightPx) + cfg.barVerticalOffsetPx;

                h += "<div class='v19-plan-task " + st.cls + "' title='" + esc((a.summary || a.name || "") + " | " + v18DateRange(a)) + "' " +
                    "style='left:" + pos.left.toFixed(3) + "%;width:" + pos.width.toFixed(3) + "%;top:" + top + "px;height:" + cfg.barHeightPx + "px;min-height:" + cfg.barHeightPx + "px'>" +
                    "<span class='task-name'>" + esc(a.summary || a.name || "") + ""</span > +
                        "<span class='task-date'>" + esc(v18DateRange(a)) + ""</span > +
                            "</div>";
            }

            h += "</div></div>";
            return h;
        }

        function v18RenderCalendar(record, data) {
            var cfg = V19_PROJECT_PLAN_GRID_CONFIG;
            var b0 = v18EnsureTbdActivities((data && data.baseline0) || [], "B0");
            var b1 = v18EnsureTbdActivities((data && data.baseline1) || [], "B1");
            var months = v18Months(b0.concat(b1));
            var minWidth = Math.max(cfg.minBoardWidthPx, cfg.labelColumnWidthPx + (months.length * cfg.monthColumnWidthPx));
            var h = "";
            var i;

            h += "<div class='activity-calendar-toolbar'>";
            h += "<div><b>Project Phase Activity Calendar</b>
                < span > Baseline labels are header rows.Activities use compact dedicated lanes aligned to the frozen month grid.</div > "</span>;
            h += "<div class='legend-row'><span class='legend-chip lg-done'>Done<span class='legend-chip lg-progress'>Planned / Open</span><span class='legend-chip lg-breach'>Breached</span><span class='legend-chip lg-tbd'>TBD</span></div>"</span >;
            h += "</div>";

            h += "<div class='timeline-scroll'>";
            h += "<div class='gantt-board' style='--gantt-month-count:" + months.length + ";min-width:" + minWidth + "px'>";
            h += "<div class='gantt-months' style='grid-template-columns:" + cfg.labelColumnWidthPx + "px repeat(" + months.length + ", minmax(" + cfg.monthColumnWidthPx + "px, 1fr))'><div>Month</div>";

            for (i = 0; i < months.length; i++) {
                h += "<div>" + esc(v18MonthLabel(months[i])) + "</div>";
            }

            h += "</div>";
            h += v18RenderPhaseRow("Baseline 0", "Scope | ITA | Cost Approval | Plan", b0, months, "B0");
            h += v18RenderPhaseRow("Baseline 1", "Develop | ITQA/SIT | UAT | Staging | Go Live", b1, months, "B1");
            h += "</div></div>";
            h += "<div class='phase-footer'><span>Compact bars reduce vertical scroll.<span>Baseline 0 and Baseline 1 are independent grids.</span><span>Sticky month header remains visible during vertical scrolling.</span></div>"</span >;

            return h;
        }

        function showFatalError(err) {
        root.innerHTML = "<div class='dd-error'><b>Dashboard Error</b>

            "+esc(err.message)+"</div > "; logProgress("Fatal Error: "+err.message,"ERROR"); } function startDashboard(){ var configObj; logProgress("Dashboard start - V20.5 Robust IDC / DMGT Fetch + Multi Supporting SME","INFO"); readReferencePage() .then(function(html){ configObj=parseReferenceConfig(html); SUPPORTING_DEMAND_SME_MAP=configObj.supportingDemandSmeMap||{}; return readJiraFieldCatalog(); }) .then(function(jiraFields){ FIELD_MAP=buildFieldMap(jiraFields); return fetchDemandData(configObj); }) .then(function(demands){ ALL_DEMANDS=demands; return fetchLinkedExecutionIssues(ALL_DEMANDS); }) .then(function(linkedMap){ LINKED_EXECUTION_ISSUES=linkedMap; buildDisplayRecords(); render(); logProgress("Dashboard loaded successfully.Startup loaded Demand + Project only.Phase / Activity remains lazy for P button and expansion.Display rows: "+DISPLAY_RECORDS.length,"SUCCESS"); }) .catch(function(err){ showFatalError(err); }); } startDashboard(); })(); </script>

                <script>
                /* ===== V18 HOTFIX: Reliable Popup Close for Confluence HTML Macro ===== */
                (function () {
                    function removePopupById(id) {
                        var el = document.getElementById(id);
                        if (el && el.parentNode) { el.parentNode.removeChild(el); }
                    }

                    window.closeActivityCalendarPopup = function () {
                        removePopupById("activityCalendarPopup");
                        removePopupById("projectPlanOverlay");
                        document.body.classList.remove("v18-popup-open");
                    };

                    window.closeActivityTimelineModal = function () {
                        removePopupById("projectPlanOverlay");
                        removePopupById("activityCalendarPopup");
                        document.body.classList.remove("v18-popup-open");
                    };

                    document.addEventListener("click", function (e) {
                        var closeBtn = e.target.closest(".activity-calendar-close,.project-plan-close,.v18-popup-close");
                        if (closeBtn) {
                            e.preventDefault();
                            e.stopPropagation();
                            window.closeActivityCalendarPopup();
                            return false;
                        }

                        if (e.target && (e.target.id === "activityCalendarPopup" || e.target.id === "projectPlanOverlay")) {
                            e.preventDefault();
                            e.stopPropagation();
                            window.closeActivityCalendarPopup();
                            return false;
                        }
                    }, true);

                    document.addEventListener("keydown", function (e) {
                        if (e.key === "Escape" || e.key === "Esc") {
                            window.closeActivityCalendarPopup();
                        }
                    }, true);
                })();
</script >    
