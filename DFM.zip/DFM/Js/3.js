<script>


//------- Demand Details API Client/Manager -------------------

class ApiClient {
  constructor(config) {
    try {
      this.config = config;
    } catch (error) {
      handleGlobalError("ApiClient.constructor", error);
    }
  }

  async fetchJson(url) {
    try {
  
      const response = await fetch(url, { credentials: "same-origin" });
      if (!response.ok) {
        throw new Error(
          `API Connection Failed (Status: ${response.status}) for URL: ${url}`,
        );
      }

      return await response.json();
    } catch (error) {
       alert("Incorrect URL passed");
  //handleGlobalError("ApiClient.fetchJson", error);
      //throw error;
    }
  }

  async fetchIssue(issueKey, fields) {
    try {
      const url = fields
        ? this.config.api.issueWithFields(issueKey, fields)
        : this.config.api.issue(issueKey);

      return await this.fetchJson(url);
    } catch (error) {
      handleGlobalError("ApiClient.fetchIssue", error);
      throw error;
    }
  }

  async fetchProject(projectId) {
    try {
      return await this.fetchIssue(projectId);
    } catch (error) {
      handleGlobalError("ApiClient.fetchProject", error);
      throw error;
    }
  }

  async discoverFieldId(possibleNames) {
    try {
      const fields = await this.fetchJson(this.config.api.fields);

      if (!fields || !Array.isArray(fields)) {
        throw new Error(
          "Invalid response format received from fields API endpoint.",
        );
      }

      const found = fields.find((f) => {
        const n = String(f.name || "")
          .trim()
          .toLowerCase();
        return possibleNames.some((x) => n.includes(x.toLowerCase()));
      });

      return found ? found.id : "";
    } catch (error) {
      handleGlobalError("ApiClient.discoverFieldId", error);
      return "";
    }
  }
}



</script>