<script>  

//------- Demand Details Main Orchestrator / Manager -------------------
// The main flow is intentionally small: resolve the issue key, build the two
// UI widgets, and render the results once the data layer has completed.

document.addEventListener("DOMContentLoaded", async function () {
  try {
    const demandContainerId = AppConfig?.containers?.demandDetails;
    const stageContainerId = AppConfig?.containers?.stageDetails;

    if (!demandContainerId || !document.getElementById(demandContainerId)) {
      throw new Error("Demand details container is missing from the page.");
    }

    //stageContainerId not used, so commented
    // if (!stageContainerId || !document.getElementById(stageContainerId)) {
    //   throw new Error("Stage details container is missing from the page.");
    // }

    const apiClient = new ApiClient(AppConfig);
    const issueKey = UrlUtils.getIssueKey(AppConfig);

    const demandInstance = new DemandDetails({
      issueKey,
      config: AppConfig,
      apiClient,
      containerId: AppConfig.containers.demandDetails,
    });

    const stageInstance = new StageDetails({
      issueKey,
      config: AppConfig,
      apiClient,
      containerId: AppConfig.containers.stageDetails,
    });

    await demandInstance.processCreation();
    await stageInstance.processCreation(demandInstance.project);

    const calendarActivities = await stageInstance.getProjectCalendarActivities(
      demandInstance.project.planProjID,
    );

    demandInstance.project.calendarActivities = calendarActivities;

    demandInstance.render(stageInstance.getHtml());
    stageInstance.render();
  } catch (error) {
    handleGlobalError("Main Orchestrator Flow", error);
  }
});

  </script>