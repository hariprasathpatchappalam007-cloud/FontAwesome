<script>    


Object.assign(DemandRenderer, {
  render(project, stageHtml, config) {
    try {
      if (!project) {
        throw new Error("Project data object is null or undefined inside DemandRenderer.");
      }

      const ragClass = StatusUtils.getRagCssClass(project.projectRag);
      const ragText = project.projectRag || "None.";

      const projectContainer = project.projectId
        ? `<a class="demand-link" href="${config.api.browse(project.projectId)}" target="_blank">🔗 ${project.projectId}</a>`
        : "No Project Created.";

      const demandContainer = project.demandId
        ? `<a class="demand-link" href="${config.api.browse(project.demandId)}" target="_blank">🔗 ${project.demandId}</a>`
        : "";

      const requirementsContainer = project.requirements
        ? `${project.requirements}`
        : config.ui.noRequirementsMessage;

      const keyUpdatesContainer = project.PortfolioExecutiveSummary
        ? `<div class="jira-rendered-html">${project.PortfolioExecutiveSummary}</div>`
        : config.ui.noPortfolioExecutiveSummaryMessage;

      DemandRenderer.latestPortfolioSummaryHtml = project.PortfolioExecutiveSummary || "";

      return `
        <div class="dib-dashboard">
          <div class="dib-main-grid">
            <section class="dib-info-card dib-details-section">
              <div class="dib-section-header">
                <div>
                  <div class="dib-section-kicker">Demand Details</div>
                  <h2>${project.projectName || ""}</h2>
                </div>
                <div class="dib-header-actions">${projectContainer}</div>
              </div>
              <div class="dib-details-grid">
                ${DemandRenderer.renderInfoItem("Start Date", `📅 ${project.startDate || ""}`)}
                ${DemandRenderer.renderInfoItem("Overall Status", `<span class="badge badge-status">${project.overallStatus || ""}</span>`)}
                ${DemandRenderer.renderInfoItem("Project RAG", `<span class="badge badge-rag-${ragClass}">${ragText}</span>`)}
                ${DemandRenderer.renderInfoItem("SME Lead", project.smeLead || "")}
                ${DemandRenderer.renderInfoItem("Demand ID", demandContainer)}
                ${DemandRenderer.renderInfoItem("Size", project.size || "")}
                ${DemandRenderer.renderInfoItem("Demand Owner", project.demandOwner || "")}
                ${DemandRenderer.renderInfoItem("Department", project.projectDepartment || "")}
                ${DemandRenderer.renderInfoItem("Segment", project.demandSegment || "")}
                ${DemandRenderer.renderInfoItem("Project Manager", `👤 ${project.projectManager || ""}`)}
                ${DemandRenderer.renderInfoItem("Demand Type", project.demandType || "")}
                ${DemandRenderer.renderInfoItem("Classification", project.classification || "")}
                ${DemandRenderer.renderInfoItem("Stakeholders", project.stakeholders || "")}
                ${DemandRenderer.renderInfoItem("End Date", `📅 ${project.endDate || ""}`)}
                ${DemandRenderer.renderInfoItem("Platform", `${project.platform || ""}`)}
              </div>
            </section>

            <aside class="dib-info-card dib-stage-section">
              <div class="dib-section-header compact">
                <div>
                  <div class="dib-section-kicker">Delivery Flow</div>
                  <h2>Current Stage</h2>
                </div>
              </div>
              ${stageHtml}
            </aside>
          </div>

          <div class="dib-content-grid">
            ${DemandRenderer.renderDesignerCard("R", "Project's Requirements", requirementsContainer)}
            ${DemandRenderer.renderDesignerCard("E", "Portfolio Executive Summary", keyUpdatesContainer)}
          </div>
          ${DemandRenderer.renderProjectCalendar(project.calendarActivities || [], project)}
          ${DemandRenderer.renderAttachmentsBox(project.attachments || [])}
        </div>`;
    } catch (error) {
      handleGlobalError("DemandRenderer.render", error);
      return `<div style="padding:10px; color:red; border:1px dashed red;">❌ Failed to render Demand HTML Layout.</div>`;
    }
  },

  renderDesignerCard(iconLetter, title, content) {
    const popupKey = String(title || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    DemandRenderer.cardPopupContents[popupKey] = { title, content: content || "" };

    return `
    <div class="designer-card">
      <div class="designer-card-header">
        <div class="designer-card-title-wrap">
          <span class="designer-card-icon">${iconLetter}</span>
          <span class="designer-card-title">${title}</span>
        </div>
        <button class="designer-card-expand-btn" type="button" onclick="DemandRenderer.openCardPopup('${popupKey}')" title="Open Full View">
          <svg class="designer-card-expand-icon" viewBox="0 0 24 24" aria-hidden="true">
            <polyline points="15 3 21 3 21 9"></polyline>
            <polyline points="9 21 3 21 3 15"></polyline>
            <line x1="21" y1="3" x2="14" y2="10"></line>
            <line x1="3" y1="21" x2="10" y2="14"></line>
          </svg>
          <span>Expand</span>
        </button>
      </div>
      <div class="designer-card-divider"></div>
      <div class="designer-card-body jira-rendered-html">${content || ""}</div>
    </div>`;
  },

  renderInfoItem(label, value) {
    return `
      <div class="dib-info-item">
        <div class="dib-info-label">${label}</div>
        <div class="dib-info-value">${value || ""}</div>
      </div>`;
  },

  renderProjectCalendar(activities, project) {
    try {
      if (!activities || activities.length === 0) {
        return `
        <section class="dib-gantt-card">
          <div class="dib-gantt-header">
            <div>
              <div class="dib-section-kicker">Project Calendar View</div>
              <h2>No activities found</h2>
            </div>
          </div>
        </section>`;
      }

      const datedActivities = activities.filter((x) => x.startDate && x.endDate);
      const allDates = datedActivities.flatMap((x) => [new Date(x.startDate), new Date(x.endDate)]);
      const minDate = new Date(Math.min(...allDates));
      
      const maxDate = new Date(Math.max(...allDates));      
      //Thu Apr 09 2026 04:00:00 GMT+0400 (Gulf Standard Time)
      const todayDate = new Date();
      maxDate.setFullYear(todayDate.getFullYear());
      maxDate.setMonth(todayDate.getMonth()+1);
      maxDate.setDate(todayDate.getDate());

      minDate.setHours(0, 0, 0, 0);
      maxDate.setHours(0, 0, 0, 0);

      const totalDays = Math.max(1, Math.ceil((maxDate - minDate) / 86400000) + 1);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayOffset = Math.ceil((today - minDate) / 86400000);
      const todayLeft = Math.min(100, Math.max(0, (todayOffset / totalDays) * 100));

      const monthHeaders = DemandRenderer.buildGanttMonthHeaders(minDate, maxDate, totalDays);
      const grouped = DemandRenderer.groupActivitiesByBaseline(activities);
      const totalWorkDays = DemandRenderer.sumBaselineWorkDays(datedActivities);

      const baselineRows = Object.keys(grouped)
        .map((baselineName) => {
          const baselineTotalWorkDays = DemandRenderer.sumBaselineWorkDays(grouped[baselineName]);
          const baselineProgress = DemandRenderer.getBaselineProgress(grouped[baselineName]);
          const rows = grouped[baselineName]
            .map((item, index) => {
              const hasDates = item.startDate && item.endDate;
              const workDays = DemandRenderer.calculateWorkDays(item.startDate, item.endDate);
              const colorClass = DemandRenderer.getActivityColorClass(item.activity, item.status, baselineName);
              const health = DemandRenderer.getActivityHealth(item);
              const isMilestone = DemandRenderer.isMilestoneActivity(item);
              const rowExtraClass = [health.className, isMilestone ? "milestone-row" : ""].join(" ");
              const childIssues = item.childIssues || [];

              const activityPopupKey = String(`${baselineName}-${item.key || item.activity}`).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
              DemandRenderer.activityPopupContents[activityPopupKey] = {
                baselineName,
                activity: item.activity,
                activityKey: item.key,
                childIssues,
              };

              const unitTestCasesBadge = childIssues.length > 0
                ? `<button class="dib-testcase-btn" type="button" onclick="DemandRenderer.openActivityChildrenPopup('${activityPopupKey}')">🧪 ${childIssues.length} Unit Test Cases</button>`
                : "";

              let barHtml = `<span class="dib-gantt-no-date">No dates</span>`;
              if (hasDates) {
                const start = new Date(item.startDate);
                const end = new Date(item.endDate);
                start.setHours(0, 0, 0, 0);
                end.setHours(0, 0, 0, 0);
                const offset = Math.max(0, Math.ceil((start - minDate) / 86400000));
                const duration = Math.max(1, Math.ceil((end - start) / 86400000) + 1);
                const left = (offset / totalDays) * 100;
                const width = (duration / totalDays) * 100;
                barHtml = isMilestone
                  ? `<div class="dib-gantt-milestone ${colorClass}" style="left:${left}%;"><span>♦</span></div>`
                  : `<div class="dib-gantt-bar ${colorClass}" style="left:${left}%; width:${width}%;">${DateUtils.formatDate(item.startDate)} - ${DateUtils.formatDate(item.endDate)}</div>`;
              }

              const itemStartDate = item.startDate ? DateUtils.formatDate(item.startDate) : "";
              const itemEndDate = item.endDate ? DateUtils.formatDate(item.endDate) : "";
              const itemDate = itemStartDate === "" && itemEndDate === "" ? "" : `${itemStartDate}→${itemEndDate}`;

              return `
              <div class="dib-gantt-row ${rowExtraClass}">
                <div class="dib-gantt-index">${index + 1}</div>
                <div class="dib-gantt-activity">
                  <div class="dib-gantt-activity-name">${item.activity || ""}</div>
                  <div class="dib-gantt-meta">
                    ${itemDate}
                    <span class="dib-workday-badge">${workDays || 0} WD</span>
                    <span class="dib-health-badge ${health.className}">${health.label}</span>
                    ${unitTestCasesBadge}
                  </div>
                </div>
                <div class="dib-gantt-timeline">
                  <div class="dib-gantt-today-line" style="left:${todayLeft}%;"><span class="dib-gantt-today-label">TODAY</span></div>
                  ${barHtml}
                </div>
                <div class="dib-gantt-owner">${item.responsible || "-"}</div>
              </div>`;
            })
            .join("");

          return `
          <div class="dib-baseline-row">
            <div class="dib-baseline-title">
              <div class="dib-baseline-left"><span>${baselineName}</span></div>
              <div class="dib-baseline-right">
                <span style="color:white" class="dib-summary-chip">${grouped[baselineName].length} Activities</span>
                <span style="color:white" class="dib-summary-chip dib-summary-chip-gold">${baselineTotalWorkDays} Workdays</span>
                <span style="color:white" class="dib-summary-chip dib-summary-chip-progress">${baselineProgress}% Done</span>
              </div>
            </div>
            <div class="dib-baseline-progress"><div class="dib-baseline-progress-fill" style="width:${baselineProgress}%;"></div></div>
            <div class="dib-gantt-row dib-gantt-head">
              <div>#</div>
              <div>Activity</div>
              <div class="dib-gantt-month-axis">${monthHeaders}</div>
              <div class="dib-gantt-month">Responsible</div>
            </div>
            ${rows}
          </div>`;
        })
        .join("");

      return `
      <section class="dib-gantt-card">
        <div class="dib-gantt-header">
          <div>
            <div class="dib-section-kicker">Project Calendar View</div>
            <h2>${project.projectName || "Project Timeline"}</h2>
          </div>
          <div class="dib-gantt-summary">
            <span>📅 ${DateUtils.formatDate(minDate)} - ${DateUtils.formatDate(maxDate)}</span>
            <span>${totalDays} Calendar Days</span>
            <span>${totalWorkDays} Workdays</span>
            <span>${Object.keys(grouped).length} Baselines</span>
          </div>
        </div>
        <div class="dib-gantt-legend">
          <span><i class="legend-done"></i> Done</span>
          <span><i class="legend-progress"></i> In Progress</span>
          <span><i class="legend-not-started"></i> Not Started</span>
          <span><i class="legend-risk"></i> Blocked / Delayed</span>
        </div>
        <div class="dib-gantt-table">${baselineRows}</div>
      </section>`;
    } catch (error) {
      handleGlobalError("DemandRenderer.renderProjectCalendar", error);
      return "";
    }
  },

  renderAttachmentsBox(attachments) {
    try {
      if (!attachments || attachments.length === 0) {
        return `
        <section class="dib-attachments-card">
          <div class="dib-attachments-header">
            <div>
              <div class="dib-section-kicker">Attachments</div>
              <h2>Project Document(s)</h2>
            </div>
            <span class="dib-attachments-count">0 Documents</span>
          </div>
          <div class="dib-empty-documents">No documents attached to this demand.</div>
        </section>`;
      }

      const rows = attachments.map((att, index) => {
        const fileName = att.filename || "Unnamed document";
        const fileUrl = att.content || att.self || "#";
        const author = att.author && att.author.displayName ? att.author.displayName : "Unknown";
        const created = att.created ? DateUtils.formatDate(att.created) : "";
        const size = DemandRenderer.formatFileSize(att.size);
        const icon = DemandRenderer.getAttachmentIcon(fileName);

        return `
        <a class="dib-document-row" href="${fileUrl}" target="_blank">
          <div class="dib-document-index">${index + 1}</div>
          <div class="dib-document-icon">${icon}</div>
          <div class="dib-document-main">
            <div class="dib-document-name">${fileName}</div>
            <div class="dib-document-meta">Uploaded by <strong>${author}</strong>${created ? ` on <strong>${created}</strong>` : ""}${size ? ` · ${size}` : ""}</div>
          </div>
          <div class="dib-document-action">Open ↗</div>
        </a>`;
      }).join("");

      return `
      <section class="dib-attachments-card">
        <div class="dib-attachments-header">
          <div>
            <div class="dib-section-kicker">Attachments</div>
            <h2>Project Document(s)</h2>
          </div>
          <span class="dib-attachments-count">${attachments.length} Document${attachments.length > 1 ? "s" : ""}</span>
        </div>
        <div class="dib-documents-list">${rows}</div>
      </section>`;
    } catch (error) {
      handleGlobalError("DemandRenderer.renderAttachmentsBox", error);
      return "";
    }
  },

  formatFileSize(bytes) {
    if (!bytes || isNaN(bytes)) return "";
    const size = Number(bytes);
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  },

  getAttachmentIcon(fileName) {
    const name = String(fileName || "").toLowerCase();
    if (name.endsWith(".pdf")) return "PDF";
    if (name.endsWith(".doc") || name.endsWith(".docx")) return "DOC";
    if (name.endsWith(".xls") || name.endsWith(".xlsx")) return "XLS";
    if (name.endsWith(".ppt") || name.endsWith(".pptx")) return "PPT";
    if (name.endsWith(".msg")) return "MSG";
    if (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg")) return "IMG";
    return "FILE";
  },
});



</script>