<script>       


class DemandRenderer {
  static activityPopupContents = {};
  static cardPopupContents = {};
  static latestPortfolioSummaryHtml = "";
  static tcPopupPageSize = 2000;
  static activeTcPopupKey = "";
  static activeTcPopupPage = 1;

  static closeActivityChildrenPopup() {
    const overlay = document.getElementById("dib-activity-popup-overlay");
    if (overlay) overlay.remove();
  }

  static openActivityChildrenPopup(popupKey) {
    try {
      const existing = document.getElementById("dib-activity-popup-overlay");
      if (existing) existing.remove();

      DemandRenderer.activeTcPopupKey = popupKey;
      DemandRenderer.activeTcPopupPage = 1;

      const data = DemandRenderer.activityPopupContents[popupKey];
      if (!data) return;

      const testCases = data.childIssues || [];
      const metrics = DemandRenderer.getTcSummaryMetrics(testCases);
      const {
        doneCount,
        inProgressCount,
        pendingCount,
        donePercent,
        progressPercent,
        pendingPercent,
      } = metrics;
      const bugSummary = DemandRenderer.getTcBugSummary(testCases);

      const html = `
      <div id="dib-activity-popup-overlay" class="dib-popup-overlay dib-tc-overlay">
        <div class="dib-popup-card dib-testcase-popup-card">
          <div class="dib-tc-popup-header">
            <div class="dib-tc-header-icon">${DemandRenderer.getTcSvgIcon("lab")}</div>
            <div class="dib-tc-header-text">
              <div class="dib-section-kicker">${data.baselineName || "Baseline 1"}</div>
              <h2>${data.activity || "ITQA"} - Unit Test Cases</h2>
              <p>All Unit Test Cases linked under ITQA activity</p>
            </div>
            <button class="dib-tc-close" type="button" onclick="DemandRenderer.closeActivityChildrenPopup()">×</button>
          </div>

          <div class="dib-tc-kpi-grid">
            <div class="dib-tc-kpi-card">
              <div class="dib-tc-kpi-icon total">${DemandRenderer.getTcSvgIcon("stack")}</div>
              <div>
                <span>Total Test Cases</span>
                <strong>${testCases.length}</strong>
                <small>All Test Cases</small>
              </div>
            </div>
            <div class="dib-tc-kpi-card">
              <div class="dib-tc-kpi-icon done">${DemandRenderer.getTcSvgIcon("check")}</div>
              <div>
                <span>Done</span>
                <strong>${doneCount}</strong>
                <small>${donePercent}%</small>
              </div>
            </div>
            <div class="dib-tc-kpi-card">
              <div class="dib-tc-kpi-icon progress">${DemandRenderer.getTcSvgIcon("clock")}</div>
              <div>
                <span>In Progress</span>
                <strong>${inProgressCount}</strong>
                <small>${progressPercent}%</small>
              </div>
            </div>
            <div class="dib-tc-kpi-card">
              <div class="dib-tc-kpi-icon pending">${DemandRenderer.getTcSvgIcon("hourglass")}</div>
              <div>
                <span>Pending</span>
                <strong>${pendingCount}</strong>
                <small>${pendingPercent}%</small>
              </div>
            </div>
          </div>

          <div class="dib-tc-bug-strip dib-tc-bug-kpi-grid">
           <div class="dib-tc-bug-pill total">
              <div class="dib-tc-bug-pill-icon">${DemandRenderer.getTcBugSvgIcon("total")}</div>
              <div><span>Total Bugs</span><strong>${bugSummary.total}</strong><small>All linked bugs.</small></div>
            </div>

            <div class="dib-tc-bug-pill showstopper">
              <div class="dib-tc-bug-pill-icon">${DemandRenderer.getTcBugSvgIcon("octagon")}</div>
              <div><span>Showstopper</span><strong>${bugSummary.showstopper}</strong><small>Production stopper.</small></div>
            </div>
          
            <div class="dib-tc-bug-pill critical">
              <div class="dib-tc-bug-pill-icon">${DemandRenderer.getTcBugSvgIcon("alert")}</div>
              <div><span>Critical</span><strong>${bugSummary.critical}</strong><small>High impact defects.</small></div>
            </div>
          
            <div class="dib-tc-bug-pill major">
              <div class="dib-tc-bug-pill-icon">${DemandRenderer.getTcBugSvgIcon("flag")}</div>
              <div><span>Major</span><strong>${bugSummary.major}</strong><small>Functional impact.</small></div>
            </div>
          
            <div class="dib-tc-bug-pill minor">
              <div class="dib-tc-bug-pill-icon">${DemandRenderer.getTcBugSvgIcon("dot")}</div>
              <div><span>Minor</span><strong>${bugSummary.minor}</strong><small>Low impact defects.</small></div>
            </div>
          </div>

          <div class="dib-tc-table-wrap">
            <div class="dib-tc-table-head">
              <div>#</div>
              <div>Test Case</div>
              <div>Key</div>
              <div>Status</div>
              <div>Bugs</div>
              <div>Actions</div>
            </div>
          </div>

          <div id="dib-testcase-rows" class="dib-tc-table-body"></div>
        </div>
      </div>`;

      document.body.insertAdjacentHTML("beforeend", html);
      DemandRenderer.renderActivityChildrenPage(1);
    } catch (error) {
      handleGlobalError("DemandRenderer.openActivityChildrenPopup", error);
    }
  }

  static renderActivityChildrenPage(pageNumber) {
    try {
      const data = DemandRenderer.activityPopupContents[DemandRenderer.activeTcPopupKey];
      if (!data) return;

      const testCases = data.childIssues || [];
      const pageSize = DemandRenderer.tcPopupPageSize;
      const totalPages = Math.max(1, Math.ceil(testCases.length / pageSize));
      const safePage = Math.min(Math.max(Number(pageNumber) || 1, 1), totalPages);
      DemandRenderer.activeTcPopupPage = safePage;

      const startIndex = (safePage - 1) * pageSize;
      const endIndex = Math.min(startIndex + pageSize, testCases.length);
      const currentRows = testCases.slice(startIndex, endIndex);

      const rowsHtml = currentRows
        .map((item, index) => {
          const statusClass = DemandRenderer.getTcStatusClass(item.status);
          const bugColumnHtml = DemandRenderer.renderTcBugColumn(item);
          return `
          <div class="dib-tc-row">
            <div class="dib-tc-index">${startIndex + index + 1}</div>
            <div class="dib-tc-title-cell">
              <a class="dib-tc-title dib-tc-title-link" href="${AppConfig.api.browse(item.key)}" target="_blank">${item.summary || "Unnamed Test Case"}</a>
            </div>
            <div class="dib-tc-key">${item.key || ""}</div>
            <div>
              <span class="dib-tc-status ${statusClass}">
                ${DemandRenderer.getTcStatusIcon(item.status)} ${item.status || "No Status"}
              </span>
            </div>
            <div class="dib-tc-bugs-cell">${bugColumnHtml}</div>
            <div class="dib-tc-action">
              <a href="${AppConfig.api.browse(item.key)}" target="_blank" title="Open Test Case in Jira">${DemandRenderer.getTcSvgIcon("open")}</a>
            </div>
          </div>`;
        })
        .join("");

      const rowsContainer = document.getElementById("dib-testcase-rows");
      if (rowsContainer) {
        rowsContainer.innerHTML = rowsHtml || `<div class="dib-empty-documents">No unit test cases found under ITQA.</div>`;
      }
    } catch (error) {
      handleGlobalError("DemandRenderer.renderActivityChildrenPage", error);
    }
  }

  static getTcSummaryMetrics(testCases = []) {
    const total = Array.isArray(testCases) ? testCases.length : 0;
    const doneCount = testCases.filter((x) => DemandRenderer.isDoneActivity(x.status)).length;
    const inProgressCount = testCases.filter((x) => String(x.status || "").toLowerCase().includes("progress")).length;
    const pendingCount = total - doneCount - inProgressCount;

    return {
      total,
      doneCount,
      inProgressCount,
      pendingCount,
      donePercent: total ? ((doneCount / total) * 100).toFixed(2) : 0,
      progressPercent: total ? ((inProgressCount / total) * 100).toFixed(2) : 0,
      pendingPercent: total ? ((pendingCount / total) * 100).toFixed(2) : 0,
    };
  }

  static getTcStatusClass(status) {
    const s = String(status || "").toLowerCase();
    if (DemandRenderer.isDoneActivity(status)) return "tc-done";
    if (s.includes("progress")) return "tc-progress";
    if (s.includes("block") || s.includes("fail") || s.includes("defect")) return "tc-risk";
    return "tc-pending";
  }

  static getTcStatusIcon(status) {
    const s = String(status || "").toLowerCase();
    if (DemandRenderer.isDoneActivity(status)) return "✓";
    if (s.includes("progress")) return "◔";
    if (s.includes("block") || s.includes("fail") || s.includes("defect")) return "!";
    return "⌛";
  }

  static getTcAssigneeName(item) {
    try {
      const rawFields = item.raw && item.raw.fields ? item.raw.fields : {};
      return ValueUtils.getValue(rawFields.assignee) || ValueUtils.getValue(item.assignee) || "-";
    } catch (error) {
      return "-";
    }
  }

  static getTcInitials(name) {
    const clean = String(name || "").trim();
    if (!clean || clean === "-") return "NA";
    return clean.split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x.charAt(0).toUpperCase()).join("");
  }

  static getTcSvgIcon(type) {
    const icons = {
      lab: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 3h6"></path><path d="M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3"></path><path d="M8 15h8"></path></svg>`,
      stack: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 3 8l9 5 9-5-9-5Z"></path><path d="M3 12l9 5 9-5"></path><path d="M3 16l9 5 9-5"></path></svg>`,
      check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="9"></circle><path d="m8 12 3 3 5-6"></path></svg>`,
      clock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l4 2"></path></svg>`,
      hourglass: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 3h12"></path><path d="M6 21h12"></path><path d="M8 3c0 5 8 5 8 10s-8 5-8 8"></path><path d="M16 3c0 5-8 5-8 10s8 5 8 8"></path></svg>`,
      open: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 3h7v7"></path><path d="M10 14 21 3"></path><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"></path></svg>`,
    };
    return icons[type] || "";
  }

  static getSeverityIcons(type) {

    const severity = {
      showstopper: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2"/><path d="M12 7V13" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><circle cx="12" cy="16.5" r="1.3" fill="currentColor"/></svg>`,

      critical: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 4L21 20H3L12 4Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M12 9V14" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="12" cy="17" r="1.2" fill="currentColor"/></svg>`,

      major: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7 5V19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M7 6H16L14 10L16 14H7" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>`,

      minor: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="4" fill="currentColor"/></svg>`
    };
    return severity[type] || "";
  }



  static openCardPopup(popupKey) {
    try {
      const existing = document.getElementById("dib-card-popup-overlay");
      if (existing) existing.remove();

      const item = DemandRenderer.cardPopupContents[popupKey] || {
        title: "Details",
        content: "No content available.",
      };

      const html = `
      <div id="dib-card-popup-overlay" class="dib-popup-overlay">
        <div class="dib-popup-card">
          <div class="dib-popup-header">
            <div>
              <div class="dib-section-kicker">${item.title}</div>
              <h2>Full View</h2>
            </div>
            <button class="dib-popup-close" type="button" onclick="DemandRenderer.closeCardPopup()">×</button>
          </div>
          <div class="dib-popup-body jira-rendered-html">${item.content || "No content available."}</div>
        </div>
      </div>`;
      document.body.insertAdjacentHTML("beforeend", html);
    } catch (error) {
      handleGlobalError("DemandRenderer.openCardPopup", error);
    }
  }

  static closeCardPopup() {
    const overlay = document.getElementById("dib-card-popup-overlay");
    if (overlay) overlay.remove();
  }

  static openPortfolioSummaryPopup() {
    try {
      const existing = document.getElementById("dib-portfolio-popup-overlay");
      if (existing) existing.remove();

      const html = `
      <div id="dib-portfolio-popup-overlay" class="dib-popup-overlay">
        <div class="dib-popup-card">
          <div class="dib-popup-header">
            <div>
              <div class="dib-section-kicker">Portfolio Executive Summary</div>
              <h2>Project's Key Updates</h2>
            </div>
            <button class="dib-popup-close" type="button" onclick="DemandRenderer.closePortfolioSummaryPopup()">×</button>
          </div>
          <div class="dib-popup-body jira-rendered-html">${DemandRenderer.latestPortfolioSummaryHtml || "No summary available."}</div>
        </div>
      </div>`;
      document.body.insertAdjacentHTML("beforeend", html);
    } catch (error) {
      handleGlobalError("DemandRenderer.openPortfolioSummaryPopup", error);
    }
  }

  static closePortfolioSummaryPopup() {
    const overlay = document.getElementById("dib-portfolio-popup-overlay");
    if (overlay) overlay.remove();
  }
}




</script>