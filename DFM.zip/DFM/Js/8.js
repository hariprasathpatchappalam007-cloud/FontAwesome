<script>   

// StageDetails workflow class kept in its own module.
class StageDetails {
  //----------------------------------------------------------
  constructor({ issueKey, config, apiClient, containerId }) {
    try {
      this.issueKey = issueKey;
      this.config = config;
      this.apiClient = apiClient;
      this.container = document.getElementById(containerId);
      this.stageResult = null;
      this.requirementsKeyUpdatesInstance = null;
      this.html = "";
    } catch (error) {
      handleGlobalError("StageDetails.constructor", error);
    }
  }
//----------------------------------------------------------
  async processCreation(project) {
    try {
      if (!project || !project.planProjID) {
        this.html = `<div class="stage-box">${this.config.ui.noProjectMessage}</div>`;
        return null;
      }

      this.stageResult = await this.#findFirstNotDoneStageWithStates(project.planProjID);
      this.html = StageDetailsRenderer.render(this.stageResult, this.config);
      return this.stageResult;
    } catch (error) {
      handleGlobalError("StageDetails.processCreation", error);
      throw error;
    }
  }
//----------------------------------------------------------
  render() {
    try {
      if (this.container) {
        // Rendering is delegated from the orchestrator and kept as a placeholder.
      }
    } catch (error) {
      handleGlobalError("StageDetails.render", error);
    }
  }

  getHtml() {
    try {
      return this.html;
    } catch (error) {
      handleGlobalError("StageDetails.getHtml", error);
      return "";
    }
  }
//----------------------------------------------------------
  async getProjectCalendarActivities(projectKey) {
    try {

      if (!projectKey) return [];

      const f = this.config.fields;
      const activityFetchFields = [
        "summary",
        "status",
        f.activityActualStartDate || f.activityStartDate,
        f.activityActualEndDate || f.activityEndDate,
        f.activityPlannedStartDate,
        f.activityPlannedEndDate,
        f.activityResponsible
      ].filter(Boolean).join(",");


      const baselines = await this.#getChildren(projectKey);
      const activities = [];

      for (const baseline of baselines) {
        if (!baseline || !baseline.key) continue;

        const states = await this.#getChildren(baseline.key);

        for (const state of states) {
          if (!state || !state.key) continue;

          try {
            const fullStateIssue = await this.apiClient.fetchIssue(state.key,activityFetchFields);
            const stateFields = fullStateIssue.fields || {};
            const actualStartDate = ValueUtils.getValue(stateFields[f.activityActualStartDate || f.activityStartDate] );
            const actualEndDate = ValueUtils.getValue(stateFields[f.activityActualEndDate || f.activityEndDate]);
            const plannedStartDate = ValueUtils.getValue(stateFields[f.activityPlannedStartDate]);
            const plannedEndDate = ValueUtils.getValue(stateFields[f.activityPlannedEndDate]);
            const startDate = actualStartDate || plannedStartDate;
            const endDate = actualEndDate || plannedEndDate;
            const dateSource = actualStartDate || actualEndDate ? "Actual": plannedStartDate || plannedEndDate? "Planned" : "";
            const responsible = ValueUtils.getValue(stateFields[f.activityResponsible]);
            const activityName = ValueUtils.getValue(stateFields.summary) || state.summary || "";
            const baselineName = String(baseline.summary || "").toLowerCase();
            const isBaseline1 = baselineName.includes("baseline 1") || baselineName.includes("base line 1");
            const isITQA = String(activityName || "").toLowerCase().trim() === "itqa";
            let childIssues = [];

            if (isBaseline1 && isITQA) {
              childIssues = await this.#getChildren(state.key);

              childIssues = await Promise.all(
                childIssues.map(async testCase => {
                  return await this.#enrichTestCaseWithLinkedBugs(testCase);
                })
              );
            }

            activities.push({
              baselineKey: baseline.key,
              baselineName: baseline.summary || "",
              key: state.key,
              activity: ValueUtils.getValue(stateFields.summary) || state.summary || "",
              status: ValueUtils.getValue(stateFields.status) || state.status || "",
              startDate,
              endDate,
              actualStartDate,
              actualEndDate,
              plannedStartDate,
              plannedEndDate,
              dateSource,
              responsible,
              childIssues
            });

          } catch (stateError) {
            console.warn(
              "Failed to fetch full state issue:",
              state.key,
              stateError.message
            );

            activities.push({
              baselineKey: baseline.key,
              baselineName: baseline.summary || "",
              key: state.key,
              activity: state.summary || "",
              status: state.status || "",
              actualStartDate: "",
              actualEndDate: "",
              plannedStartDate: "",
              plannedEndDate: "",
              responsible: ""
            });
          }
        }
      }

      return activities;

    } catch (error) {
      handleGlobalError("StageDetails.getProjectCalendarActivities", error);
      return [];
    }
  }
  //#region -----------------------Internal Class Helpers/Methods ----------------------------
  
  async #findFirstNotDoneStageWithStates(planProjectKey) {
    try {
      const stages = await this.#getChildren(planProjectKey);

      for (const stage of stages) {
        if (StatusUtils.isDoneStatus(stage.status, this.config)) continue;

        const states = await this.#getChildren(stage.key);

        if (states.length > 0) {
          return {
            stageKey: stage.key,
            stageName: stage.summary,
            stageStatus: stage.status,
            states,
          };
        }
      }
      return null;
    } catch (error) {
      handleGlobalError("StageDetails.#findFirstNotDoneStageWithStates", error);
      return null;
    }
  }//----------end

  async #getChildren(issueKey) {
    try {
      try {
        const jiraChildren = await this.#getChildrenFromJira(issueKey);
        if (jiraChildren.length > 0) return jiraChildren;
      } catch (e) {
        console.warn("Jira issuelinks failed:", e.message);
      }

      return await this.#getChildrenFromBigPicture(issueKey);
    } catch (error) {
      handleGlobalError("StageDetails.#getChildren", error);
      return [];
    }
  }//----------end

  async #getChildrenFromJira(issueKey) {
    try {
      const issueData = await this.apiClient.fetchIssue(issueKey, "summary,status,issuelinks");
      return this.#getChildrenFromJiraIssueLinks(issueData);
    } catch (error) {
      handleGlobalError("StageDetails.#getChildrenFromJira", error);
      throw error;
    }
  }

  #getChildrenFromJiraIssueLinks(issueData) {
    try {
      const links = issueData.fields && issueData.fields.issuelinks ? issueData.fields.issuelinks : [];

      return links
        .filter(
          (link) =>
            link.type &&
            (link.type.outward.toLowerCase() === "is parent of".toLowerCase() ||
              link.type.name.toLowerCase() === "Parent-Child Link".toLocaleLowerCase() ||
              String(link.type.outward || "").toLowerCase().includes("parent") ||      
     link.type.outward.toLowerCase().includes("finished together")||
              link.type.outward.toLowerCase().includes("started together")) &&
             link.outwardIssue,
        )
        .map((link) => this.#normalizeIssue(link.outwardIssue));
    } catch (error) {
      handleGlobalError("StageDetails.#getChildrenFromJiraIssueLinks", error);
      return [];
    }
  }//----------end

  async #getChildrenFromBigPicture(issueKey) {
    try {
      const possibleUrls = this.config.api.bigPictureChildren(issueKey);

      for (const url of possibleUrls) {
        try {
          const response = await fetch(url, { credentials: "same-origin" });

          if (!response.ok) {
            console.warn("BigPicture endpoint skipped:", url, "Status:", response.status);
            continue;
          }

          const data = await response.json();
          const children = this.#normalizeBigPictureChildren(data);

          if (children.length > 0) return children;
        } catch (e) {
          console.warn("BigPicture endpoint failed:", url, e.message);
        }
      }

      return [];
    } catch (error) {
      handleGlobalError("StageDetails.#getChildrenFromBigPicture", error);
      return [];
    }
  }//----------end

  #normalizeBigPictureChildren(data) {
    try {
      if (!data) return [];
      const possibleArrays = [
        data.children,
        data.issues,
        data.tasks,
        data.rows,
        data.items,
        data.data && data.data.children,
        data.data && data.data.issues,
        data.data && data.data.tasks,
        data.data && data.data.rows,
        data.data && data.data.items,
      ].filter(Array.isArray);

      if (possibleArrays.length === 0) return [];

      return possibleArrays[0]
        .map((item) => {
          const issue = item.issue || item.jiraIssue || item;

          return {
            key: issue.key || issue.issueKey || issue.issue_key || item.key || item.issueKey || "",
            summary: issue.summary || issue.name || issue.title || item.summary || item.name || item.title || "",
            status: ValueUtils.getValue(issue.status) || ValueUtils.getValue(item.status) || issue.statusName || item.statusName || "",
            raw: item,
          };
        })
        .filter((x) => x.key || x.summary);
    } catch (error) {
      handleGlobalError("StageDetails.#normalizeBigPictureChildren", error);
      return [];
    }
  }//----------end

  #normalizeIssue(issue) {
    try {
      if (!issue) return { key: "", summary: "", status: "", raw: null };
      return {
        key: issue.key || issue.issueKey || issue.issue_key || issue.id || "",
        summary: ValueUtils.getValue(issue.fields && issue.fields.summary) || issue.summary || issue.name || issue.title || "",
        status: ValueUtils.getValue(issue.fields && issue.fields.status) || issue.status || issue.statusName || issue.status_name || "",
        raw: issue,
      };
    } catch (error) {
      handleGlobalError("StageDetails.#normalizeIssue", error);
      return { key: "", summary: "", status: "", raw: issue };
    }
  }//----------end

  async #enrichTestCaseWithLinkedBugs(testCase) {
    try {
      if (!testCase || !testCase.key) return testCase;

      const testCaseIssue = await this.apiClient.fetchIssue(
        testCase.key,
        "summary,status,issuetype,issuelinks"
      );

      const links = testCaseIssue.fields && testCaseIssue.fields.issuelinks
        ? testCaseIssue.fields.issuelinks
        : [];

      const bugRefs = links
        .map(link => link.outwardIssue || link.inwardIssue)
        .filter(Boolean)
        .filter(issue => {
          const issueType = ValueUtils.getValue(issue.fields && issue.fields.issuetype);
          return String(issueType || "").toLowerCase() === "bug";
        });

      const bugs = await Promise.all(
        bugRefs.map(async bugRef => {
          return await this.#fetchBugSeverityDetails(bugRef.key);
        })
      );

      const cleanBugs = bugs.filter(Boolean);

      return {
        ...testCase,
        bugs: cleanBugs,
        bugSummary: this.#buildBugSeveritySummary(cleanBugs)
      };

    } catch (error) {
      console.warn("Failed to enrich test case bugs:", testCase.key, error.message);

      return {
        ...testCase,
        bugs: [],
        bugSummary: this.#buildBugSeveritySummary([])
      };
    }
  }//----------end

  async #fetchBugSeverityDetails(bugKey) {
    try {
      if (!bugKey) return null;

      const bugIssue = await this.apiClient.fetchIssue(
        bugKey,
        "summary,status,issuetype,customfield_10700"
      );

      const fields = bugIssue.fields || {};
      const rawSeverity = ValueUtils.getValue(fields.customfield_10700);

      return {
        key: bugIssue.key || bugKey,
        summary: ValueUtils.getValue(fields.summary),
        status: ValueUtils.getValue(fields.status),
        issueType: ValueUtils.getValue(fields.issuetype),
        rawSeverity,
        severity: this.#normalizeBugSeverity(rawSeverity),
        raw: bugIssue
      };

    } catch (error) {
      console.warn("Failed to fetch bug severity:", bugKey, error.message);
      return null;
    }
  }//----------end

  #normalizeBugSeverity(value) {
    const v = String(value || "").trim().toLowerCase();

    if (v.includes("showstopper") || v.includes("show stopper")) {
      return "showstopper";
    }

    if (v.includes("critical")) {
      return "critical";
    }

    if (v.includes("major")) {
      return "major";
    }

    if (v.includes("minor")) {
      return "minor";
    }

    return "unknown";
  }//----------end

  #buildBugSeveritySummary(bugs) {
    const summary = {
      showstopper: 0,
      critical: 0,
      major: 0,
      minor: 0,
      unknown: 0,
      total: 0
    };

    (bugs || []).forEach(bug => {
      const severity = bug.severity || "unknown";

      if (summary[severity] === undefined) {
        summary.unknown += 1;
      } else {
        summary[severity] += 1;
      }

      summary.total += 1;
    });

    return summary;
  }//----------end

  //#endregion----------------------- END
}


</script>