<script>      


//--------------------------------------------------------------------------------
// Value Util
//---------------
const ValueUtils = {
  getValue(value, fallback = "") {
    try {
      if (value === null || value === undefined || value === "")
        return fallback;

      if (Array.isArray(value)) {
        return value
          .map((x) => ValueUtils.getValue(x))
          .filter(Boolean)
          .join(", ");
      }

      if (typeof value === "object") {
        return (
          value.displayName ||
          value.value ||
          value.name ||
          value.key ||
          fallback
        );
      }

      return String(value);
    } catch (error) {
      handleGlobalError("ValueUtils.getValue", error);
      return fallback;
    }
  },
};
//--------------------------------------------------------------------------------
// Date Util
//---------------
const DateUtils = {
  formatDate(dateValue) {
    try {
      if (!dateValue) return "";

      const d = new Date(dateValue);
      if (isNaN(d.getTime())) return "";

      return d.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
      
    } catch (error) {
      handleGlobalError("DateUtils.formatDate", error);
      return "";
    }
  },
};
//--------------------------------------------------------------------------------
// UrlUtils Util
//---------------
const UrlUtils = {
  getIssueKey(config) {
    try {
      const params = new URLSearchParams(window.location.search);
      const safeParams = new URLSearchParams(
        Array.from(params.entries()).map(([k, v]) => [k.toLowerCase(), v]),
      );

      for (const paramName of config.defaults.issueKeyParams) {
        const value = safeParams.get(paramName.toLowerCase());
        if (value) return value;
      }
      return config.defaults.issueKey;
    } catch (error) {
      handleGlobalError("UrlUtils.getIssueKey", error);
      return config && config.defaults ? config.defaults.issueKey : "";
    }
  },
};
//--------------------------------------------------------------------------------
// StatusUtils Util
//-------------------
const StatusUtils = {
  isDoneStatus(statusName, config = AppConfig) {
    try {
      const s = String(statusName || "")
        .trim()
        .toLowerCase();
      return config.statuses.done.includes(s);
    } catch (error) {
      handleGlobalError("StatusUtils.isDoneStatus", error);
      return false;
    }
  },

  getRagCssClass(rag) {
    try {
      const v = String(rag || "empty")
        .trim()
        .toLowerCase();
      if (v.includes("green")) return "green";
      if (v.includes("red")) return "red";
      if (v.includes("amber")) return "amber";
      if (v.includes("yellow")) return "yellow";
      return "unknown";
    } catch (error) {
      handleGlobalError("StatusUtils.getRagCssClass", error);
      return "unknown";
    }
  },
};

//--------------------------------------------------------------------------------
// PeopleUtils Util
//-------------------

const PeopleUtils = {
  refineADName(adName) {
    try {
      if (adName && adName.split("(").length > 0) {
        return adName.split("(")[0].trim();
      }
      return adName;
    } catch (error) {
      handleGlobalError("PeopleUtils.refineADName", error);
      return adName;
    }
  },

  extractStakeholders(fields, config) {
    try {
      const raw = config.fields.stakeholderFields
        .map((fieldName) => ValueUtils.getValue(fields[fieldName]))
        .join("_");

      const matches = [...raw.matchAll(/\(([^)]+)\)/g)].map((m) => m[1]);
      return [...new Set(matches)].join(", ");
    } catch (error) {
      handleGlobalError("PeopleUtils.extractStakeholders", error);
      return "";
    }
  },
};

//--------------------------------------------------------------------------------
// JiraHtmlUtils Util
//-------------------

const JiraHtmlUtils = {
  getRenderedField(responseData, fieldId) {
    try {
      if (!responseData) {
        console.warn("JiraHtmlUtils.getRenderedField: response data is missing.");
        return "";
      }

      if (
        responseData.renderedFields &&
        fieldId &&
        responseData.renderedFields[fieldId] !== undefined &&
        responseData.renderedFields[fieldId] !== null &&
        String(responseData.renderedFields[fieldId]).trim() !== ""
      ) {
        return responseData.renderedFields[fieldId];
      }

      const targetFieldId = fieldId || "customfield_13900";
      const fieldsContainer = responseData.fields || {};

      if (
        fieldsContainer[targetFieldId] !== undefined &&
        fieldsContainer[targetFieldId] !== null
      ) {
        const rawValue = ValueUtils.getValue(fieldsContainer[targetFieldId]);
        if (typeof rawValue === "string" && rawValue.includes("#")) {
          return JiraHtmlUtils.convertHashToHtmlList(rawValue);
        }
        if (typeof rawValue === "string") {
          return rawValue.replace(/\n/g, "
");
        }
        return rawValue;
      }

      return "";
    } catch (error) {
      if (typeof handleGlobalError === "function") {
        handleGlobalError("JiraHtmlUtils.getRenderedField", error);
      }
      return "";
    }
  },

  convertHashToHtmlList(rawText) {
    const items = rawText
      .split("#")
      .map((item) => item.trim())
      .filter(Boolean);
    if (items.length === 0) return rawText;

    let html = `<ol style="margin: 0; padding-left: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; color: #172b4d; line-height: 1.6;">`;
    items.forEach((item) => {
      const cleanItem = item.replace(/^\d+[\s\.\)]+/, "").trim();
      html += `<li style="margin-bottom: 6px; padding-left: 4px;">${cleanItem}</li>`;
    });
    html += `</ol>`;
    return html;
  },
};



</script>