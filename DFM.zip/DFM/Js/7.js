<script>  

// DemandDetails workflow class kept in its own module.
class DemandDetails {
  constructor({ issueKey, config, apiClient, containerId }) {
    try {
      this.issueKey = issueKey;
      this.config = config;
      this.apiClient = apiClient;
      this.container = document.getElementById(containerId);
      this.project = null;
    } catch (error) {
      handleGlobalError("DemandDetails.constructor", error);
    }
  }

  async processCreation() {
    try {
        const demandIssue = await this.apiClient.fetchIssue(
        this.issueKey,
        this.config.fields.demandFetchFields.join(","),
      );

      const fields = demandIssue.fields || {};
      const projectId = ValueUtils.getValue(fields[this.config.fields.projectId]);
      let ragValue = "";
      let portfolioExecutiveSummaryVal = "";

      const requirements = JiraHtmlUtils.getRenderedField(
        demandIssue,
        this.config.fields.requirements,
      );

      if (projectId) {
        const projectIssue = await this.apiClient.fetchProject(projectId);
        const projectFields = projectIssue.fields || {};

        portfolioExecutiveSummaryVal = JiraHtmlUtils.getRenderedField(
          projectIssue,
          this.config.fields.PortfolioExecutiveSummary,
        );

        const ragField = projectFields[this.config.fields.projectRag];
        ragValue = ragField ? ValueUtils.getValue(ragField) : "";
      }

      this.project = this.#mapProject(
        fields,
        ragValue,
        portfolioExecutiveSummaryVal,
        requirements,
      );

      return this.project;
    } catch (error) {
      handleGlobalError("DemandDetails.processCreation", error);
      throw error;
    }
  }

  render(stageHtml = "") {
    try {
      if (!this.container) {
        console.warn("DemandDetails.render: container element not found in DOM.");
        return;
      }

      this.container.innerHTML = DemandRenderer.render(
        this.project,
        stageHtml,
        this.config,
      );
    } catch (error) {
      handleGlobalError("DemandDetails.render", error);
    }
  }

  #mapProject(fields, ragValue, portfolioExecutiveSummaryVal, requirements) {
    try {
      const f = this.config.fields;
      return {
        projectName: ValueUtils.getValue(fields[f.summary]),
        projectId: ValueUtils.getValue(fields[f.projectId]),
        startDate: DateUtils.formatDate(fields[f.created]),
        endDate: DateUtils.formatDate(fields[f.endDate]),
        platform: ValueUtils.getValue(fields[f.platform]),
        planProjID: ValueUtils.getValue(fields[f.projectId]),
        overallStatus: ValueUtils.getValue(fields[f.status]).toUpperCase(),
        projectRag: ragValue,
        smeLead: PeopleUtils.refineADName(ValueUtils.getValue(fields[f.smeLead])),
        demandId: ValueUtils.getValue(fields[f.demandId])
          ? ValueUtils.getValue(fields[f.demandId]).replace("-Demand", "")
          : "",
        size: ValueUtils.getValue(fields[f.size]),
        demandOwner: PeopleUtils.refineADName(ValueUtils.getValue(fields[f.demandOwner])),
        projectDepartment: ValueUtils.getValue(fields[f.projectDepartment]),
        demandSegment: ValueUtils.getValue(fields[f.demandSegment]),
        projectManager: PeopleUtils.refineADName(ValueUtils.getValue(fields[f.assignee])),
        demandType: ValueUtils.getValue(fields[f.demandType]),
        classification: ValueUtils.getValue(fields[f.classification]),
        stakeholders: PeopleUtils.extractStakeholders(fields, this.config),
        requirements,
        PortfolioExecutiveSummary: portfolioExecutiveSummaryVal,
        attachments: fields[f.attachments] || [],
      };
    } catch (error) {
      handleGlobalError("DemandDetails.#mapProject", error);
      return {};
    }
  }
}
   </script>