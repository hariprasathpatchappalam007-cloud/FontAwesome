<script>         


// Central configuration and lightweight global error handling for the demand details UI.
// Keep this file focused on configuration so the feature modules stay readable.
function handleGlobalError(functionName, error) {
  const errorDetails = {
    function: functionName,
    name: error && error.name ? error.name : "UnknownError",
    message: error && error.message ? error.message : String(error),
    stackTrace: error && error.stack ? error.stack : "",
  };

  console.error("[DemandApp]", errorDetails);

  if (typeof window !== "undefined" && typeof window.alert === "function") {
    window.alert(`❌ Error In : [${errorDetails.function}]!
            ---------------------------------------
            Type : ${errorDetails.name}
            Message : ${errorDetails.message}
            lineNumber: ${error.lineNumber || "N/A"},
            columnNumber: ${error.columnNumber || "N/A"}
            StackTrace : ${errorDetails.stackTrace}`);
  }
}
//--------------------------------------------------------------------------------------
const DEFAULT_ISSUE_KEY = "DMGT-433";
let AppConfig = {};
//----------------------------
try {
  AppConfig = {
    defaults: {
      issueKey: DEFAULT_ISSUE_KEY, // default demand ID
      issueKeyParams: ["issuekey", "issueKey", "key"],
    },

    containers: {
      demandDetails: "demand-details-container",
      stageDetails: "stage-details-container",
    },

    api: {
      jiraBasePath: "/planner",
      issue: (issueKey) => 
        `/planner/rest/api/2/issue/${issueKey}?expand=renderedFields`,
      issueWithFields: (issueKey, fields) =>
        `/planner/rest/api/2/issue/${issueKey}?expand=renderedFields&fields=${encodeURIComponent(fields)}`,
      fields: "/planner/rest/api/2/field",
      browse: (issueKey) => `/planner/browse/${issueKey}`,
      bigPictureChildren: (issueKey) => [
        `/planner/rest/softwareplant-bigpicture/1.0/structure/issue/${issueKey}`,
        `/planner/rest/bigpicture/1.0/structure/issue/${issueKey}`,
        `/planner/rest/bigpicture/1.0/wbs/issue/${issueKey}`,
        `/planner/rest/ppm/1.0/structure/issue/${issueKey}`,
      ],
    },

    fields: {
      summary: "summary",
      status: "status",
      assignee: "assignee",
      reporter: "reporter",
      created: "created",
      projectId: "customfield_13416",
      projectRag: "customfield_13509",
      smeLead: "customfield_13358",
      demandId: "customfield_11300",
      size: "customfield_12618",
      demandOwner: "customfield_13317",
      projectDepartment: "customfield_13310",
      demandSegment: "customfield_13600",
      demandType: "customfield_13339",
      classification: "customfield_13307",
      endDate: "customfield_13306",
      platform: "customfield_12609",
      requirements: "customfield_13309",
      PortfolioExecutiveSummary: "customfield_13900",
      //For baseline 0/1 Gantt chart (Actual)
      activityActualStartDate: "customfield_12628",
      activityActualEndDate: "customfield_12629",
      activityPlannedStartDate: "customfield_12636",
      activityPlannedEndDate: "customfield_12637",
      //For baseline 0/1 Gantt chart
      activityStartDate: "customfield_12628",
      activityEndDate: "customfield_12629",
      activityResponsible: "assignee",
      attachments: "attachment",
      stakeholderFields: [
        "assignee",
        "customfield_12603",
        "customfield_13317",
        "reporter",
        "customfield_14001",
        "customfield_13376",
        "customfield_13379",
        "customfield_13357",
        "customfield_13358",
      ],
      demandFetchFields: [
        "summary",
        "status",
        "assignee",
        "reporter",
        "created",
        "customfield_12610",
        "customfield_13306",
        "customfield_13416",
        "customfield_13358",
        "customfield_11300",
        "customfield_12618",
        "customfield_13317",
        "customfield_13310",
        "customfield_13600",
        "customfield_13339",
        "customfield_13307",
        "customfield_12603",
        "customfield_14001",
        "customfield_13376",
        "customfield_13379",
        "customfield_13357",
        "customfield_12609",
        "customfield_13309",
        "customfield_13900",
        "customfield_12628",
        "customfield_12629",
        "customfield_12636",
        "customfield_12637",
        "attachment",
      ],
    },
    statuses: {
      done: ["done", "closed", "resolved", "completed", "complete"],
    },
    ui: {
      noProjectMessage:
        "There is no project created for this Demand/Service/LP.",
      noStageMessage: "No not-done stage with states found.",

      noRequirementsMessage:
        "There is no requirements mentioned for this project.",
      noPortfolioExecutiveSummaryMessage:
        "This project require the PM to provide the status.",
    },
  };
} catch (error) {
  if (typeof handleGlobalError === "function") {
    handleGlobalError("AppConfig Initialization", error);
  } else {
    alert(
      `❌ Code Error Occurred in AppConfig!\n Message: ${error.message}\n Stack:\n${error.stack}`,
    );
  }
}

</script>