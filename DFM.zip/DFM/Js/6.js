<script>    


Object.assign(DemandRenderer, {
  groupActivitiesByBaseline(activities) {
    const grouped = {};
    activities.forEach((item) => {
      const baselineName = DemandRenderer.getBaselineDisplayName(item.baselineName || "Other Activities");
      if (!grouped[baselineName]) grouped[baselineName] = [];
      grouped[baselineName].push(item);
    });

    const ordered = {};
    ["Baseline 0", "Baseline 1"].forEach((name) => {
      if (grouped[name]) ordered[name] = grouped[name];
    });

    Object.keys(grouped).forEach((name) => {
      if (!ordered[name]) ordered[name] = grouped[name];
    });

    Object.keys(ordered).forEach((key) => {
      ordered[key].sort((a, b) => {
        const da = a.startDate ? new Date(a.startDate) : new Date("9999-12-31");
        const db = b.startDate ? new Date(b.startDate) : new Date("9999-12-31");
        return da - db;
      });
    });

    return ordered;
  },

  getBaselineDisplayName(baselineName) {
    const name = String(baselineName || "").toLowerCase();
    if (name.includes("baseline 0") || name.includes("base line 0")) return "Baseline 0";
    if (name.includes("baseline 1") || name.includes("base line 1")) return "Baseline 1";
    return baselineName || "Other Activities";
  },

  buildGanttMonthHeaders(minDate, maxDate, totalDays) {
    const months = [];
    const cursor = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
    const finalMonth = new Date(maxDate.getFullYear(), maxDate.getMonth(), 1);

    while (cursor <= finalMonth) {
      const monthStart = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
      const monthEnd = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);

      const visibleStart = monthStart < minDate ? minDate : monthStart;
      const visibleEnd = monthEnd > maxDate ? maxDate : monthEnd;

      const visibleDays = Math.max(1, Math.ceil((visibleEnd - visibleStart) / 86400000) + 1);
      const widthPercent = (visibleDays / totalDays) * 100;
      months.push(`<div class="dib-gantt-month" style="width:${widthPercent}%;">${cursor.toLocaleDateString("en-GB", { month: "short", year: "numeric" })}</div>`);
      cursor.setMonth(cursor.getMonth() + 1);
    }
    return months.join("");
  },

  getActivityColorClass(activity, status, baselineName = "") {
    const s = String(status || "").trim().toLowerCase();
    const a = String(activity || "").trim().toLowerCase();

    if (s.includes("done") || s.includes("completed") || s.includes("complete") || s.includes("closed") || s.includes("resolved")) return "gantt-status-done";
    if (s.includes("in progress") || s.includes("progress") || s.includes("doing") || s.includes("active") || s.includes("ongoing")) return "gantt-status-progress";
    if (s.includes("not started") || s.includes("to do") || s.includes("todo") || s.includes("open") || s.includes("new")) return "gantt-status-not-started";
    if (s.includes("blocked") || s.includes("block") || s.includes("delayed") || s.includes("delay") || s.includes("on hold") || s.includes("hold")) return "gantt-status-risk";
    if (s.includes("cancelled") || s.includes("canceled") || s.includes("dropped")) return "gantt-status-cancelled";
    if (a.includes("uat") || a.includes("test") || a.includes("testing")) return "gantt-status-uat";
    if (a.includes("dev") || a.includes("development") || a.includes("build")) return "gantt-status-dev";
    return "gantt-status-default";
  },

  calculateWorkDays(startDate, endDate) {
    try {
      if (!startDate || !endDate) return "";
      const start = new Date(startDate);
      const end = new Date(endDate);
      if (isNaN(start.getTime()) || isNaN(end.getTime())) return "";
      let workDays = 0;
      const current = new Date(start);
      while (current <= end) {
        const day = current.getDay();
        if (day !== 0 && day !== 6) workDays++;
        current.setDate(current.getDate() + 1);
      }
      return workDays;
    } catch (error) {
      handleGlobalError("DemandRenderer.calculateWorkDays", error);
      return "";
    }
  },

  sumBaselineWorkDays(activities) {
    try {
      return activities.reduce((total, activity) => total + (Number(DemandRenderer.calculateWorkDays(activity.startDate, activity.endDate)) || 0), 0);
    } catch (error) {
      handleGlobalError("DemandRenderer.sumBaselineWorkDays", error);
      return 0;
    }
  },

  getBaselineProgress(activities) {
    try {
      if (!activities || activities.length === 0) return 0;
      const doneCount = activities.filter((item) => DemandRenderer.isDoneActivity(item.status)).length;
      return Math.round((doneCount / activities.length) * 100);
    } catch (error) {
      handleGlobalError("DemandRenderer.getBaselineProgress", error);
      return 0;
    }
  },

  isDoneActivity(status) {
    const s = String(status || "").toLowerCase();
    return s.includes("done") || s.includes("completed") || s.includes("complete") || s.includes("closed") || s.includes("resolved");
  },

  isDelayedActivity(item) {
    try {
      if (!item || !item.endDate) return false;
      if (DemandRenderer.isDoneActivity(item.status)) return false;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const end = new Date(item.endDate);
      end.setHours(0, 0, 0, 0);
      return end < today;
    } catch (error) {
      handleGlobalError("DemandRenderer.isDelayedActivity", error);
      return false;
    }
  },

  isCurrentActivity(item) {
    try {
      if (!item || !item.startDate || !item.endDate) return false;
      if (DemandRenderer.isDoneActivity(item.status)) return false;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const start = new Date(item.startDate);
      const end = new Date(item.endDate);
      start.setHours(0, 0, 0, 0);
      end.setHours(0, 0, 0, 0);
      return today >= start && today <= end;
    } catch (error) {
      handleGlobalError("DemandRenderer.isCurrentActivity", error);
      return false;
    }
  },

  isUpcomingActivity(item) {
    try {
      if (!item || !item.startDate) return false;
      if (DemandRenderer.isDoneActivity(item.status)) return false;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const start = new Date(item.startDate);
      start.setHours(0, 0, 0, 0);
      return start > today;
    } catch (error) {
      handleGlobalError("DemandRenderer.isUpcomingActivity", error);
      return false;
    }
  },

  getActivityHealth(item) {
    if (DemandRenderer.isDoneActivity(item.status)) return { label: "Completed", className: "health-completed" };
    if (DemandRenderer.isDelayedActivity(item)) return { label: "Delayed", className: "health-delayed" };
    if (DemandRenderer.isCurrentActivity(item)) return { label: "In Progress", className: "health-progress" };
    if (DemandRenderer.isUpcomingActivity(item)) return { label: "Upcoming", className: "health-upcoming" };
    return { label: "Not Scheduled", className: "health-unscheduled" };
  },

  isMilestoneActivity(item) {
    try {
      const name = String(item.activity || "").toLowerCase();
      const workDays = DemandRenderer.calculateWorkDays(item.startDate, item.endDate);
      return Number(workDays) === 1 || name.includes("go live") || name.includes("golive") || name.includes("live") || name.includes("signoff") || name.includes("sign off") || name.includes("approval") || name.includes("handover") || name.includes("deployment");
    } catch (error) {
      handleGlobalError("DemandRenderer.isMilestoneActivity", error);
      return false;
    }
  },

  getTcBugSummary(testCases) {
    const summary = { showstopper: 0, critical: 0, major: 0, minor: 0, total: 0 };
    (testCases || []).forEach((tc) => {
      const bugSummary = tc.bugSummary || {};
      summary.showstopper += Number(bugSummary.showstopper || 0);
      summary.critical += Number(bugSummary.critical || 0);
      summary.major += Number(bugSummary.major || 0);
      summary.minor += Number(bugSummary.minor || 0);
      summary.total += Number(bugSummary.total || 0);
    });
    return summary;
  },

  renderTcBugColumn(testCase) {
    try {
      const bugs = testCase.bugs || [];
      if (bugs.length === 0) {
        return `<div class="dib-tc-bugs-empty">${DemandRenderer.getTcBugSvgIcon("shield")}<span>No Bugs</span></div>`;
      }

      const grouped = { showstopper: [], critical: [], major: [], minor: [], unknown: [] };
      bugs.forEach((bug) => {
        const severity = bug.severity || "unknown";
        if (!grouped[severity]) grouped.unknown.push(bug);
        else grouped[severity].push(bug);
      });

      const items = [
        { key: "showstopper", label: "Showstopper", icon: "octagon" },
        { key: "critical", label: "Critical", icon: "alert" },
        { key: "major", label: "Major", icon: "flag" },
        { key: "minor", label: "Minor", icon: "dot" },
        { key: "unknown", label: "Unknown", icon: "help" },
      ].filter((x) => grouped[x.key] && grouped[x.key].length > 0);

      return `
      <div class="dib-tc-bugs-stack">
        ${items.map((item) => {
        const bugKeys = grouped[item.key].map((b) => b.key).filter(Boolean).join(", ");
        const firstBugKey = grouped[item.key][0] && grouped[item.key][0].key;
        return `
          <a class="dib-tc-bug-chip bug-${item.key}" href="${AppConfig.api.browse(firstBugKey)}" target="_blank" title="${grouped[item.key].length} ${item.label}: ${bugKeys}" onclick="event.stopPropagation();">
            class="dib-tc-bug-chip-icon">${DemandRenderer.getTcBugSvgIcon(item.icon)}</span>
            <strong>${grouped[item.key].length}</strong>
            <em>${item.label}</em>
          </a>`;
      }).join("")}
      </div>`;
    } catch (error) {
      handleGlobalError("DemandRenderer.renderTcBugColumn", error);
      return "";
    }
  },

  getTcBugTooltip(items) {
    return (items || []).map((x) => `${x.count} ${x.label}`).join(", ");
  },

  getTcBugSvgIcon(type) {
    const icons = {
      octagon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><path d="M7.5 2h9L22 7.5v9L16.5 22h-9L2 16.5v-9L7.5 2Z"></path><path d="M12 7v6"></path><path d="M12 17h.01"></path></svg>`,
      alert: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 3 2 21h20L12 3Z"></path><path d="M12 9v5"></path><path d="M12 18h.01"></path></svg>`,
      flag: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 21V4"></path><path d="M5 4h12l-2 5 2 5H5"></path></svg>`,
      dot: `<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="5"></circle></svg>`,
      shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"></path><path d="m9 12 2 2 4-5"></path></svg>`,
      total :`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 9H16V15C16 17.2091 14.2091 19 12 19C9.79086 19 8 17.2091 8 15V9Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M10 9V7C10 5.89543 10.8954 5 12 5C13.1046 5 14 5.89543 14 7V9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M5 10H8M16 10H19" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M5 14H8M16 14H19" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M6 18L8.5 16.5M18 18L15.5 16.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M12 10V17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`
    };
    return icons[type] || "";
  },
});

class StageDetailsRenderer {
  static render(result, config) {
    try {
      if (!result) {
        return `<div class="stage-box">${config.ui.noStageMessage}</div>`;
      }
      if (!result.states || !Array.isArray(result.states)) {
        throw new Error("Invalid states array format inside StageDetailsRenderer.");
      }

      let html = `<div class="stage-box">`;
      result.states.forEach((state, index) => {
        if (!state) return;
        const done = StatusUtils.isDoneStatus(state.status, config);
        html += `
          <div class="state-item ${done ? "done" : "not-done"}">
            <input type="checkbox" ${done ? "checked" : ""} disabled>
            <span>${index + 1}. ${state.summary || ""}</span>
            <span>- ${state.status || ""}</span>
          </div>`;
      });

      html += `</div>`;
      return html;
    } catch (error) {
      handleGlobalError("StageDetailsRenderer.render", error);
      return `<div style="padding:10px; color:red; border:1px dashed red;">❌ Failed to render Stage HTML Box.</div>`;
    }
  }
}
 

</script>