using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Text;
using DFM.App_Code.DAL;

namespace DFM.App_Code.Helpers
{
    /// <summary>
    /// Imports CAPEX/OPEX CSV files from the Requirement folder into the master tables.
    /// </summary>
    public static class CsvImporter
    {
        public static string RequirementFolder
        {
            get { return ConfigurationManager.AppSettings["RequirementFolder"] ?? ""; }
        }

        public static int ImportCapexFromRequirement(string user)
        {
            return ImportFromCsv(Path.Combine(RequirementFolder, "CAPEX.csv"), "CAPEX", user);
        }

        public static int ImportOpexFromRequirement(string user)
        {
            return ImportFromCsv(Path.Combine(RequirementFolder, "OPEX.csv"), "OPEX", user);
        }

        // CSV columns: Type, ID, Description, Budget, Utilization, Available Budget,
        //              Locked Amt, Budget after Locked Amt, Claim Amt, Net Balance
        public static int ImportFromCsv(string path, string kind, string user)
        {
            if (!File.Exists(path)) return 0;
            int count = 0;
            using (var sr = new StreamReader(path, Encoding.UTF8, true))
            {
                string header = sr.ReadLine(); // skip
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var fields = ParseCsvLine(line);
                    if (fields.Count < 10) continue;
                    string id  = (fields[1] ?? "").Trim();
                    if (string.IsNullOrEmpty(id)) continue;
                    string desc = (fields[2] ?? "").Trim();

                    decimal budget   = ParseDecimal(fields[3]);
                    decimal util     = ParseDecimal(fields[4]);
                    decimal avail    = ParseDecimal(fields[5]);
                    decimal locked   = ParseDecimal(fields[6]);
                    decimal afterL   = ParseDecimal(fields[7]);
                    decimal claim    = ParseDecimal(fields[8]);
                    decimal net      = ParseDecimal(fields[9]);

                    if (string.Equals(kind, "OPEX", StringComparison.OrdinalIgnoreCase))
                    {
                        MastersDAL.UpsertOpex(id, desc, budget, util, avail, locked, afterL, claim, net, user);
                    }
                    else if (string.Equals(kind, "AMC", StringComparison.OrdinalIgnoreCase))
                    {
                        MastersDAL.UpsertAmc(id, desc, budget, util, avail, locked, afterL, claim, net, user);
                    }
                    else
                    {
                        MastersDAL.UpsertCapex(id, desc, budget, util, avail, locked, afterL, claim, net, user);
                    }
                    count++;
                }
            }
            return count;
        }

        public static decimal ParseDecimal(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return 0m;
            string clean = s.Replace(",", "").Replace("\"", "").Trim();
            if (clean == "" || clean == "-") return 0m;
            decimal v;
            if (decimal.TryParse(clean, NumberStyles.Any, CultureInfo.InvariantCulture, out v)) return v;
            return 0m;
        }

        // Splits a CSV line, honoring double-quoted fields that may contain commas.
        public static List<string> ParseCsvLine(string line)
        {
            var result = new List<string>();
            if (line == null) return result;
            var sb = new StringBuilder();
            bool inQuotes = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                    {
                        sb.Append('"'); i++;
                    }
                    else inQuotes = !inQuotes;
                }
                else if (c == ',' && !inQuotes)
                {
                    result.Add(sb.ToString());
                    sb.Clear();
                }
                else sb.Append(c);
            }
            result.Add(sb.ToString());
            return result;
        }
    }
}
