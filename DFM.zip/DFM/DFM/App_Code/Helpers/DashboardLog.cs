using System;
using System.Data.SqlClient;
using System.Web;
using DFM.App_Code.DAL;

namespace DFM.App_Code.Helpers
{
    /// <summary>
    /// Req6: lightweight scenario logger for the redesigned dashboard.
    /// Writes one row per UI event to dbo.DashboardExecLog so we can deliver
    /// the "~10-15 scenario execution log" required for the dashboard side.
    /// </summary>
    public static class DashboardLog
    {
        public static void Log(string scenario, string detail, int? durationMs = null)
        {
            if (string.IsNullOrEmpty(scenario)) return;
            try
            {
                string user = null;
                try
                {
                    if (HttpContext.Current != null && HttpContext.Current.User != null
                        && HttpContext.Current.User.Identity != null)
                        user = HttpContext.Current.User.Identity.Name;
                    if (string.IsNullOrEmpty(user) && HttpContext.Current != null
                        && HttpContext.Current.Session != null)
                        user = HttpContext.Current.Session["UserName"] as string;
                }
                catch { }

                Db.Exec(
                    "INSERT INTO dbo.DashboardExecLog(Scenario, Detail, DurationMs, UserName, LoggedAt) " +
                    "VALUES(@s, @d, @dur, @u, GETDATE())",
                    new SqlParameter("@s",   (object)Trim(scenario, 100) ?? DBNull.Value),
                    new SqlParameter("@d",   (object)Trim(detail, 1000) ?? DBNull.Value),
                    new SqlParameter("@dur", durationMs.HasValue ? (object)durationMs.Value : DBNull.Value),
                    new SqlParameter("@u",   (object)Trim(user, 100) ?? DBNull.Value));
            }
            catch { /* logging must never break the UI */ }
        }

        private static string Trim(string s, int max)
        {
            if (s == null) return null;
            return s.Length <= max ? s : s.Substring(0, max);
        }
    }
}
