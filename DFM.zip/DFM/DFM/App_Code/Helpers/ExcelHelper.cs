using System;
using System.Data;
using System.IO;
using System.Text;
using System.Web;

namespace DFM.App_Code.Helpers
{
    public static class ExcelHelper
    {
        // Writes the DataTable as an HTML "Excel" file (.xls). Excel/LibreOffice reads it
        // as a workbook. This avoids any third-party dependency.
        public static void ExportToExcel(HttpResponse response, DataTable dt, string fileName)
        {
            if (response == null) return;
            if (dt == null) dt = new DataTable();

            response.Clear();
            response.Buffer = true;
            response.Charset = "utf-8";
            response.ContentEncoding = Encoding.UTF8;
            response.ContentType = "application/vnd.ms-excel";
            string safeName = string.IsNullOrWhiteSpace(fileName) ? "Export" : fileName;
            if (!safeName.EndsWith(".xls", StringComparison.OrdinalIgnoreCase)) safeName += ".xls";
            response.AddHeader("Content-Disposition", "attachment;filename=" + safeName);

            var sb = new StringBuilder();
            sb.Append("<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns=\"http://www.w3.org/TR/REC-html40\">");
            sb.Append("<head><meta charset='utf-8'/></head><body>");
            sb.Append("<table border='1' style='border-collapse:collapse;font-family:Segoe UI;font-size:12pt;'>");
            sb.Append("<thead><tr style='background:#0b6efd;color:#fff;font-weight:bold;'>");
            foreach (DataColumn col in dt.Columns)
                sb.Append("<th>").Append(HttpUtility.HtmlEncode(col.ColumnName)).Append("</th>");
            sb.Append("</tr></thead><tbody>");

            foreach (DataRow row in dt.Rows)
            {
                sb.Append("<tr>");
                foreach (DataColumn col in dt.Columns)
                {
                    object v = row[col];
                    string s = (v == null || v == DBNull.Value) ? "" : v.ToString();
                    sb.Append("<td>").Append(HttpUtility.HtmlEncode(s)).Append("</td>");
                }
                sb.Append("</tr>");
            }
            sb.Append("</tbody></table></body></html>");

            response.Write(sb.ToString());
            try { response.Flush(); } catch { }
            try { HttpContext.Current.ApplicationInstance.CompleteRequest(); } catch { }
        }
    }
}
