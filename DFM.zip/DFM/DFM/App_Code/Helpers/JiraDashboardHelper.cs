using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;
using DFM.App_Code.DAL;

namespace DFM.App_Code.Helpers
{
    public class JiraDashboardCard
    {
        public string Label;
        public string Jql;        // original JQL from JIRADashBoard.csv (for tooltip / live fallback)
        public string SqlWhere;   // derived WHERE clause against dbo.JiraIssues, or "" if no native mapping
        public int    Count;
        public string Tone;       // "primary", "success", "warning", "danger", "info", "secondary"
    }

    /// <summary>
    /// Loads JIRADashBoard.csv from the Requirement folder and translates the
    /// status-based JQL filters into SQL that can be evaluated against the
    /// cached <c>dbo.JiraIssues</c> table. Platform-based filters that can't be
    /// natively mapped fall through to an empty count (a live JIRA fetch could
    /// be plugged in later).
    /// </summary>
    public static class JiraDashboardHelper
    {
        public static string CsvPath
        {
            get
            {
                string folder = ConfigurationManager.AppSettings["RequirementFolder"] ?? "";
                return Path.Combine(folder, "JIRADashBoard.csv");
            }
        }

        public static List<JiraDashboardCard> LoadCards()
        {
            var list = new List<JiraDashboardCard>();
            if (!File.Exists(CsvPath)) return list;

            try
            {
                using (var sr = new StreamReader(CsvPath, Encoding.UTF8, true))
                {
                    sr.ReadLine(); // header
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        var f = CsvImporter.ParseCsvLine(line);
                        if (f.Count < 2) continue;
                        string label = (f[0] ?? "").Trim().TrimEnd(':').Trim();
                        string jql   = (f[1] ?? "").Trim();
                        if (string.IsNullOrEmpty(label)) continue;
                        var card = new JiraDashboardCard { Label = label, Jql = jql };
                        TranslateJql(card);
                        list.Add(card);
                    }
                }
            }
            catch { /* leave whatever we got */ }
            return list;
        }

        // Runs the WHERE expression against dbo.JiraIssues. Returns 0 if no mapping.
        public static int CountFor(JiraDashboardCard card)
        {
            if (string.IsNullOrEmpty(card.SqlWhere)) return 0;
            try
            {
                object o = Db.Scalar("SELECT COUNT(*) FROM JiraIssues WHERE " + card.SqlWhere);
                return o == null || o == DBNull.Value ? 0 : Convert.ToInt32(o);
            }
            catch { return 0; }
        }

        public static List<JiraDashboardCard> LoadWithCounts()
        {
            var cards = LoadCards();
            foreach (var c in cards) c.Count = CountFor(c);
            return cards;
        }

        // ====================================================================
        //  Bar-chart datasets (SQL-driven, sourced from dbo.JiraIssues)
        // ====================================================================

        public class BarRow
        {
            public string Label;
            public int    Count;
            public string Color;
        }

        /// <summary>
        /// Demand status summary - returns one row per status bucket plus a
        /// synthetic "Total Demand" first row, in the order the dashboard expects.
        /// Any status found in JiraIssues that does NOT fall in the canonical
        /// five buckets is appended at the end so nothing is hidden.
        /// </summary>
        public static List<BarRow> GetDemandStatusBars()
        {
            var bars = new List<BarRow>();
            string baseWhere = "IssueType IN ('Demand','Idea') OR ISNULL(IssueType,'') = ''";

            int total     = ScalarInt("SELECT COUNT(*) FROM JiraIssues WHERE " + baseWhere);
            int active    = ScalarInt(@"SELECT COUNT(*) FROM JiraIssues WHERE (" + baseWhere + @")
                AND ISNULL(Status,'') NOT IN ('Cancelled','Demand On Hold','Dropped','Closed','Completed',
                                              'Completed - Can Improve','Completed - On Track','Done','On Hold','Deferred')");
            int cancelled = ScalarInt(@"SELECT COUNT(*) FROM JiraIssues WHERE (" + baseWhere + @")
                AND Status IN ('Cancelled','Dropped','Deferred')");
            int onHold    = ScalarInt(@"SELECT COUNT(*) FROM JiraIssues WHERE (" + baseWhere + @")
                AND Status IN ('Demand On Hold','On Hold')");
            int completed = ScalarInt(@"SELECT COUNT(*) FROM JiraIssues WHERE (" + baseWhere + @")
                AND Status IN ('Completed','Completed - Can Improve','Completed - On Track','Done')");

            bars.Add(new BarRow { Label = "Total Demand", Count = total,     Color = "#1d4ed8" });
            bars.Add(new BarRow { Label = "Active",       Count = active,    Color = "#15803d" });
            bars.Add(new BarRow { Label = "On Hold",      Count = onHold,    Color = "#b45309" });
            bars.Add(new BarRow { Label = "Cancelled",    Count = cancelled, Color = "#b91c1c" });
            bars.Add(new BarRow { Label = "Completed",    Count = completed, Color = "#0e7490" });

            // Pull any statuses in the data that didn't land in the canonical
            // buckets above so the user can see them on the chart.
            DataTable other = null;
            try
            {
                other = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(Status)),''),'(blank)') AS S, COUNT(*) AS C
                                   FROM JiraIssues
                                   WHERE (" + baseWhere + @")
                                     AND ISNULL(Status,'') NOT IN
                                         ('Cancelled','Dropped','Deferred',
                                          'Demand On Hold','On Hold',
                                          'Completed','Completed - Can Improve','Completed - On Track','Done',
                                          'Closed')
                                   GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(Status)),''),'(blank)')
                                   HAVING COUNT(*) > 0
                                   ORDER BY COUNT(*) DESC");
            }
            catch { }
            if (other != null)
            {
                string[] palette = new[] {
                    "#7c3aed","#0891b2","#db2777","#6b7280","#0284c7","#a16207","#65a30d","#be185d"
                };
                int idx = 0;
                foreach (DataRow r in other.Rows)
                {
                    string s = r["S"].ToString();
                    bars.Add(new BarRow {
                        Label = s,
                        Count = Convert.ToInt32(r["C"]),
                        Color = palette[idx++ % palette.Length]
                    });
                }
            }
            return bars;
        }

        /// <summary>
        /// Platform-wise summary - groups the free-text Platform column from
        /// JiraIssues into the canonical buckets requested for the dashboard.
        /// Bars are always returned in the same order so the chart layout
        /// remains stable even when some buckets are empty.
        /// </summary>
        public static List<BarRow> GetPlatformBars()
        {
            string sql = @"
SELECT Bucket, COUNT(*) AS Cnt FROM (
    SELECT
        CASE
            WHEN Platform IN ('Internet Banking','SME Internet Banking')                                                          THEN 'IB'
            WHEN Platform IN ('Mobile Banking - Retail','Mobile Wallet System','SME Mobile 3x3')                                  THEN 'MB'
            WHEN Platform IN ('Tablet App - Customer Onboarding','Visitor Management System - Tablet')                            THEN 'TABLET'
            WHEN Platform LIKE '%SMS%'                                                                                            THEN 'SMS'
            WHEN Platform LIKE 'CCM%' OR Platform LIKE '%Statement%'                                                              THEN 'CCM'
            WHEN Platform LIKE '%Website%' OR Platform LIKE '%Portal%'                                                            THEN 'Website'
            WHEN Platform LIKE 'Genesys%' OR Platform LIKE '%IVR%' OR Platform LIKE '%Call Center%' OR Platform = 'Dialer System' THEN 'Call Center'
            WHEN Platform LIKE '%WhatsApp%' OR Platform LIKE '%Bank Buddy%'                                                       THEN 'WhatsApp'
            WHEN Platform LIKE 'HF LMS%' OR Platform = 'Bank Notification System'                                                 THEN 'HF LMS'
            WHEN Platform IN ('ATMs','KAL','KAL-KTC System','CDM - Smart Deposit')                                                THEN 'ATM'
            WHEN Platform LIKE 'Card%' OR Platform IN ('CMS','DDS','Loyalty System','UAT - Loyalty','VISA Edit Package System','CTI - HPS (Middleware System)') THEN 'Cards'
            WHEN Platform LIKE '%FinOne%' OR Platform LIKE '%FinnOne%' OR Platform LIKE 'Collections%'                            THEN 'Finnone'
            WHEN Platform LIKE 'BoardVantage%'                                                                                    THEN 'BOARD VANTAGE'
            WHEN Platform LIKE 'CRM%' OR Platform = 'New System to be implemented'                                                THEN 'CRM'
            WHEN Platform LIKE '%e-Channel%'                                                                                      THEN 'EMX'
            WHEN Platform LIKE 'QMS%'                                                                                             THEN 'QMS'
            WHEN Platform = 'Unison'                                                                                              THEN 'Unison'
            WHEN Platform LIKE '%VOC%' OR Platform LIKE '%Voice of Customer%'                                                     THEN 'VOC'
            ELSE 'Others'
        END AS Bucket
    FROM JiraIssues
) X
GROUP BY Bucket";
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            try
            {
                DataTable dt = Db.Query(sql);
                foreach (DataRow r in dt.Rows)
                    counts[r["Bucket"].ToString()] = Convert.ToInt32(r["Cnt"]);
            }
            catch { }

            string[] order = new[] {
                "IB","MB","TABLET","SMS","CCM","Website","Call Center","WhatsApp",
                "HF LMS","ATM","Cards","Finnone","BOARD VANTAGE","CRM","EMX","QMS",
                "Unison","VOC","Others"
            };
            string[] palette = new[] {
                "#1e40af","#0e7490","#15803d","#b45309","#6b21a8","#be185d","#0891b2","#dc2626",
                "#475569","#7c3aed","#22c55e","#3b82f6","#f59e0b","#ec4899","#06b6d4","#8b5cf6",
                "#10b981","#ef4444","#64748b"
            };

            var bars = new List<BarRow>();
            for (int i = 0; i < order.Length; i++)
            {
                int c = counts.ContainsKey(order[i]) ? counts[order[i]] : 0;
                bars.Add(new BarRow { Label = order[i], Count = c, Color = palette[i % palette.Length] });
            }
            return bars;
        }

        private static int ScalarInt(string sql)
        {
            try { object o = Db.Scalar(sql); return o == null || o == DBNull.Value ? 0 : Convert.ToInt32(o); }
            catch { return 0; }
        }

        // ===== Serialise BarRow lists for inline emission =====
        public static string LabelsJs(List<BarRow> rows)
        {
            var sb = new StringBuilder("[");
            for (int i = 0; i < rows.Count; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append('"').Append(rows[i].Label.Replace("\\", "\\\\").Replace("\"", "\\\"")).Append('"');
            }
            sb.Append(']'); return sb.ToString();
        }
        public static string DataJs(List<BarRow> rows)
        {
            var sb = new StringBuilder("[");
            for (int i = 0; i < rows.Count; i++) { if (i > 0) sb.Append(','); sb.Append(rows[i].Count); }
            sb.Append(']'); return sb.ToString();
        }
        public static string ColorsJs(List<BarRow> rows)
        {
            var sb = new StringBuilder("[");
            for (int i = 0; i < rows.Count; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append('"').Append(rows[i].Color).Append('"');
            }
            sb.Append(']'); return sb.ToString();
        }

        // Best-effort mapping for the status-based filters listed in JIRADashBoard.csv.
        // Platform-based filters use a custom field we don't currently cache - they
        // are stored with the original JQL so the UI can still show them (count 0)
        // and a live fetch can be plugged in later without changing the dashboard.
        private static void TranslateJql(JiraDashboardCard card)
        {
            string l = (card.Label ?? "").ToLowerInvariant();
            string jql = (card.Jql ?? "").ToLowerInvariant();

            // Demand / Idea base scope - everything our cache currently models.
            string baseDemand = "IssueType IN ('Demand','Idea')";

            if (l == "total demand")
            {
                card.SqlWhere = baseDemand;
                card.Tone = "primary";
                return;
            }
            if (l == "active")
            {
                card.SqlWhere = baseDemand + @" AND ISNULL(Status,'') NOT IN
                    ('Cancelled','Demand On Hold','Dropped','Closed','Completed',
                     'Completed - Can Improve','Completed - On Track','Done','On Hold','Deferred')";
                card.Tone = "success";
                return;
            }
            if (l == "cancelled")
            {
                card.SqlWhere = baseDemand + " AND Status IN ('Cancelled','Dropped','Deferred')";
                card.Tone = "danger";
                return;
            }
            if (l == "on hold")
            {
                card.SqlWhere = baseDemand + " AND Status IN ('Demand On Hold','On Hold')";
                card.Tone = "warning";
                return;
            }
            if (l == "completed")
            {
                card.SqlWhere = baseDemand + @" AND Status IN
                    ('Completed','Completed - Can Improve','Completed - On Track','Done')";
                card.Tone = "info";
                return;
            }
            if (l == "parent query")
            {
                card.SqlWhere = baseDemand;
                card.Tone = "secondary";
                return;
            }
            // Platform-based filters: keep the JQL for live fallback, no native SQL mapping.
            card.SqlWhere = "";
            card.Tone = "secondary";
        }

        // ====================================================================
        //  New Dashboard Charts (Req 4)
        // ====================================================================

        /// <summary>Demands grouped by Chief Name Mapping</summary>
        public static List<BarRow> GetDemandsByChief()
        {
            var bars = new List<BarRow>();
            string[] palette = new[] { "#1e40af","#0e7490","#15803d","#b45309","#6b21a8","#be185d","#0891b2","#dc2626","#475569","#7c3aed" };
            try
            {
                // Req6: Demand analytics must be sourced from DMGT (not DIBITP).
                DataTable dt = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(ChiefNameMapping)),''),'Unassigned') AS Chief, COUNT(*) AS Cnt
                    FROM JiraIssues WHERE ProjectKey = 'DMGT'
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(ChiefNameMapping)),''),'Unassigned') ORDER BY COUNT(*) DESC");
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["Chief"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = palette[idx++ % palette.Length] });
            }
            catch { }
            return bars;
        }

        /// <summary>Demands grouped by Project Manager</summary>
        public static List<BarRow> GetDemandsByManager()
        {
            var bars = new List<BarRow>();
            string[] palette = new[] { "#1e40af","#0e7490","#15803d","#b45309","#6b21a8","#be185d","#0891b2","#dc2626","#475569","#7c3aed" };
            try
            {
                // Req6: Demand analytics must be sourced from DMGT (not DIBITP).
                DataTable dt = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(Manager)),''),'Unassigned') AS Mgr, COUNT(*) AS Cnt
                    FROM JiraIssues WHERE ProjectKey = 'DMGT'
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(Manager)),''),'Unassigned') ORDER BY COUNT(*) DESC");
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["Mgr"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = palette[idx++ % palette.Length] });
            }
            catch { }
            return bars;
        }

        /// <summary>Demands grouped by Technical Team (SME Lead/Tech Lead)</summary>
        public static List<BarRow> GetDemandsByTechTeam()
        {
            var bars = new List<BarRow>();
            string[] palette = new[] { "#1e40af","#0e7490","#15803d","#b45309","#6b21a8","#be185d","#0891b2","#dc2626","#475569","#7c3aed" };
            try
            {
                // Req6: Demand analytics must be sourced from DMGT (not DIBITP).
                DataTable dt = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(TechLead)),''),'Unassigned') AS TL, COUNT(*) AS Cnt
                    FROM JiraIssues WHERE ProjectKey = 'DMGT'
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(TechLead)),''),'Unassigned') ORDER BY COUNT(*) DESC");
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["TL"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = palette[idx++ % palette.Length] });
            }
            catch { }
            return bars;
        }

        /// <summary>Aging demands - older than 3 months, still open</summary>
        public static DataTable GetAgingDemands()
        {
            try
            {
                return Db.Query(@"SELECT JiraID, Summary, ProjectName, Status, Manager, TechLead,
                    JiraCreated, DATEDIFF(MONTH, JiraCreated, GETDATE()) AS AgingMonths
                    FROM JiraIssues
                    WHERE JiraCreated IS NOT NULL
                      AND DATEDIFF(MONTH, JiraCreated, GETDATE()) >= 3
                      AND ISNULL(Status,'') NOT IN ('Done','Closed','Completed','Completed - Can Improve','Completed - On Track','Cancelled','Dropped')
                    ORDER BY JiraCreated ASC");
            }
            catch { return new DataTable(); }
        }

        /// <summary>Demands/projects that have missed their target dates</summary>
        public static DataTable GetMissedDeliverables()
        {
            try
            {
                return Db.Query(@"SELECT JiraID, Summary, ProjectName, Status, Manager, TechLead,
                    TargetCompletionDate, DATEDIFF(DAY, TargetCompletionDate, GETDATE()) AS OverdueDays
                    FROM JiraIssues
                    WHERE TargetCompletionDate IS NOT NULL
                      AND TargetCompletionDate < GETDATE()
                      AND ISNULL(Status,'') NOT IN ('Done','Closed','Completed','Completed - Can Improve','Completed - On Track','Cancelled','Dropped')
                    ORDER BY TargetCompletionDate ASC");
            }
            catch { return new DataTable(); }
        }

        /// <summary>On Hold demands</summary>
        public static DataTable GetOnHoldDemands()
        {
            try
            {
                return Db.Query(@"SELECT JiraID, Summary, ProjectName, Manager, TechLead, JiraCreated
                    FROM JiraIssues WHERE Status IN ('Demand On Hold','On Hold') ORDER BY JiraCreated ASC");
            }
            catch { return new DataTable(); }
        }

        /// <summary>Deferred demands</summary>
        public static DataTable GetDeferredDemands()
        {
            try
            {
                return Db.Query(@"SELECT JiraID, Summary, ProjectName, Manager, TechLead, JiraCreated
                    FROM JiraIssues WHERE Status IN ('Deferred') ORDER BY JiraCreated ASC");
            }
            catch { return new DataTable(); }
        }

        /// <summary>Demands converted to Projects (DIBITP)</summary>
        public static DataTable GetConvertedDemands()
        {
            try
            {
                return Db.Query(@"SELECT JiraID, Summary, ProjectName, Manager, TechLead, Status, JiraCreated
                    FROM JiraIssues WHERE ProjectKey = 'DIBITP' OR IssueType = 'Project' ORDER BY JiraCreated DESC");
            }
            catch { return new DataTable(); }
        }

        /// <summary>Gantt data for SME / Project Manager occupancy. Req6: fall back on JiraCreated/TargetCompletionDate when Proposed_Baseline dates are NULL.</summary>
        public static DataTable GetGanttData(string groupBy)
        {
            string col = groupBy == "TechLead" ? "TechLead" : "Manager";
            try
            {
                return Db.Query(string.Format(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM({0})),''),'Unassigned') AS PersonName,
                    JiraID, Summary, Status,
                    ISNULL(Proposed_Baseline_0_Start_Date, JiraCreated)            AS StartDate,
                    ISNULL(Proposed_Baseline_0_End_Date,   TargetCompletionDate)   AS EndDate,
                    TargetCompletionDate
                    FROM JiraIssues
                    WHERE (Proposed_Baseline_0_Start_Date IS NOT NULL
                        OR Proposed_Baseline_0_End_Date   IS NOT NULL
                        OR (JiraCreated IS NOT NULL AND TargetCompletionDate IS NOT NULL))
                      AND ISNULL(Status,'') NOT IN ('Cancelled','Dropped')
                    ORDER BY {0}, StartDate", col));
            }
            catch { return new DataTable(); }
        }

        /// <summary>Aging histogram: how many demands per aging-month bucket</summary>
        public static List<BarRow> GetAgingHistogram()
        {
            var bars = new List<BarRow>();
            try
            {
                DataTable dt = Db.Query(@"
                    SELECT
                        CASE
                            WHEN DATEDIFF(MONTH, JiraCreated, GETDATE()) BETWEEN 3 AND 6 THEN '3-6 Months'
                            WHEN DATEDIFF(MONTH, JiraCreated, GETDATE()) BETWEEN 7 AND 12 THEN '7-12 Months'
                            WHEN DATEDIFF(MONTH, JiraCreated, GETDATE()) > 12 THEN '12+ Months'
                            ELSE '<3 Months'
                        END AS AgeBucket,
                        COUNT(*) AS Cnt
                    FROM JiraIssues
                    WHERE JiraCreated IS NOT NULL
                      AND ProjectKey = 'DMGT'  -- Req6: Demand aging is DMGT-only
                      AND ISNULL(Status,'') NOT IN ('Done','Closed','Completed','Completed - Can Improve','Completed - On Track','Cancelled','Dropped')
                    GROUP BY
                        CASE
                            WHEN DATEDIFF(MONTH, JiraCreated, GETDATE()) BETWEEN 3 AND 6 THEN '3-6 Months'
                            WHEN DATEDIFF(MONTH, JiraCreated, GETDATE()) BETWEEN 7 AND 12 THEN '7-12 Months'
                            WHEN DATEDIFF(MONTH, JiraCreated, GETDATE()) > 12 THEN '12+ Months'
                            ELSE '<3 Months'
                        END
                    ORDER BY MIN(DATEDIFF(MONTH, JiraCreated, GETDATE()))");
                string[] colors = new[] { "#15803d", "#b45309", "#dc2626", "#7f1d1d" };
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["AgeBucket"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = colors[idx++ % colors.Length] });
            }
            catch { }
            return bars;
        }

        // ====================================================================
        //  Additional chart dimensions (Dashboard Redesign)
        // ====================================================================

        /// <summary>Project RAG distribution (GROUP BY ProjectRAG)</summary>
        public static List<BarRow> GetProjectRagBars()
        {
            var bars = new List<BarRow>();
            string[] ragOrder = new[] { "Red", "Amber", "Green", "Blue" };
            try
            {
                DataTable dt = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(ProjectRAG)),''),'Unspecified') AS R, COUNT(*) AS Cnt
                    FROM JiraIssues
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(ProjectRAG)),''),'Unspecified')
                    HAVING COUNT(*) > 0
                    ORDER BY COUNT(*) DESC");
                var map = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                foreach (DataRow r in dt.Rows)
                    map[r["R"].ToString()] = Convert.ToInt32(r["Cnt"]);
                foreach (string rg in ragOrder)
                    if (map.ContainsKey(rg)) { bars.Add(new BarRow { Label = rg, Count = map[rg], Color = RagColor(rg) }); map.Remove(rg); }
                foreach (var kv in map)
                    bars.Add(new BarRow { Label = kv.Key, Count = kv.Value, Color = "#94a3b8" });
            }
            catch { }
            return bars;
        }

        /// <summary>Platform Vertical distribution</summary>
        public static List<BarRow> GetPlatformVerticalBars()
        {
            var bars = new List<BarRow>();
            string[] palette = new[] { "#1e40af","#0e7490","#15803d","#b45309","#6b21a8","#be185d","#0891b2","#dc2626","#475569","#7c3aed" };
            try
            {
                DataTable dt = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(PlatformVertical)),''),'Unknown') AS PV, COUNT(*) AS Cnt
                    FROM JiraIssues
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(PlatformVertical)),''),'Unknown')
                    HAVING COUNT(*) > 1
                    ORDER BY COUNT(*) DESC");
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["PV"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = palette[idx++ % palette.Length] });
            }
            catch { }
            return bars;
        }

        /// <summary>Overall Status distribution (all issue types)</summary>
        public static List<BarRow> GetOverallStatusBars()
        {
            var bars = new List<BarRow>();
            string[] palette = new[] { "#1e40af","#0e7490","#15803d","#b45309","#6b21a8","#be185d","#0891b2","#dc2626","#475569","#7c3aed","#22c55e","#3b82f6","#f59e0b","#ec4899" };
            try
            {
                DataTable dt = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(OverallStatus)),''),'Unknown') AS OS, COUNT(*) AS Cnt
                    FROM JiraIssues
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(OverallStatus)),''),'Unknown')
                    HAVING COUNT(*) > 1
                    ORDER BY COUNT(*) DESC");
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["OS"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = palette[idx++ % palette.Length] });
            }
            catch { }
            return bars;
        }

        /// <summary>Schedule RAG distribution</summary>
        public static List<BarRow> GetScheduleRagBars()
        {
            var bars = new List<BarRow>();
            try
            {
                DataTable dt = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(ScheduleRag)),''),'Unknown') AS SR, COUNT(*) AS Cnt
                    FROM JiraIssues
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(ScheduleRag)),''),'Unknown')
                    HAVING COUNT(*) > 1
                    ORDER BY COUNT(*) DESC");
                foreach (DataRow r in dt.Rows)
                {
                    string rag = r["SR"].ToString();
                    bars.Add(new BarRow { Label = rag, Count = Convert.ToInt32(r["Cnt"]), Color = RagColor(rag) });
                }
            }
            catch { }
            return bars;
        }

        /// <summary>Demand Owner distribution (top 25)</summary>
        public static List<BarRow> GetDemandOwnerBars()
        {
            var bars = new List<BarRow>();
            string[] palette = new[] { "#1e40af","#0e7490","#15803d","#b45309","#6b21a8","#be185d","#0891b2","#dc2626","#475569","#7c3aed" };
            try
            {
                DataTable dt = Db.Query(@"SELECT TOP 25 ISNULL(NULLIF(LTRIM(RTRIM(DemandOwner)),''),'Unknown') AS DOwner, COUNT(*) AS Cnt
                    FROM JiraIssues
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(DemandOwner)),''),'Unknown')
                    HAVING COUNT(*) > 1
                    ORDER BY COUNT(*) DESC");
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["DOwner"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = palette[idx++ % palette.Length] });
            }
            catch { }
            return bars;
        }

        /// <summary>Issue Type distribution</summary>
        public static List<BarRow> GetIssueTypeBars()
        {
            var bars = new List<BarRow>();
            string[] palette = new[] { "#3b82f6","#06b6d4","#22c55e","#f97316","#a855f7","#ec4899","#0ea5e9","#ef4444","#64748b","#8b5cf6","#fbbf24","#10b981" };
            try
            {
                DataTable dt = Db.Query(@"SELECT ISNULL(NULLIF(LTRIM(RTRIM(IssueType)),''),'Unknown') AS IT, COUNT(*) AS Cnt
                    FROM JiraIssues
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(IssueType)),''),'Unknown')
                    HAVING COUNT(*) > 1
                    ORDER BY COUNT(*) DESC");
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["IT"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = palette[idx++ % palette.Length] });
            }
            catch { }
            return bars;
        }

        /// <summary>Assigned Project Manager distribution (top 25)</summary>
        public static List<BarRow> GetAssignedPMBars()
        {
            var bars = new List<BarRow>();
            string[] palette = new[] { "#1e40af","#0e7490","#15803d","#b45309","#6b21a8","#be185d","#0891b2","#dc2626","#475569","#7c3aed" };
            try
            {
                DataTable dt = Db.Query(@"SELECT TOP 25 ISNULL(NULLIF(LTRIM(RTRIM(AssignedProjectManager)),''),'Unknown') AS APM, COUNT(*) AS Cnt
                    FROM JiraIssues
                    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(AssignedProjectManager)),''),'Unknown')
                    HAVING COUNT(*) > 1
                    ORDER BY COUNT(*) DESC");
                int idx = 0;
                foreach (DataRow r in dt.Rows)
                    bars.Add(new BarRow { Label = r["APM"].ToString(), Count = Convert.ToInt32(r["Cnt"]), Color = palette[idx++ % palette.Length] });
            }
            catch { }
            return bars;
        }

        private static string RagColor(string rag)
        {
            if (string.Equals(rag, "Red",   StringComparison.OrdinalIgnoreCase)) return "#dc2626";
            if (string.Equals(rag, "Amber", StringComparison.OrdinalIgnoreCase)) return "#f59e0b";
            if (string.Equals(rag, "Green", StringComparison.OrdinalIgnoreCase)) return "#16a34a";
            if (string.Equals(rag, "Blue",  StringComparison.OrdinalIgnoreCase)) return "#0b6efd";
            return "#94a3b8";
        }
    }
}
