using System;
using System.Security.Cryptography;
using System.Text;

namespace DFM.App_Code.Helpers
{
    public static class PasswordHelper
    {
        public static string GenerateSalt()
        {
            byte[] saltBytes = new byte[32];
            using (var rng = new RNGCryptoServiceProvider()) rng.GetBytes(saltBytes);
            return Convert.ToBase64String(saltBytes);
        }

        public static string Hash(string password, string salt)
        {
            using (var sha = SHA256.Create())
            {
                byte[] data = Encoding.UTF8.GetBytes(salt + password);
                return Convert.ToBase64String(sha.ComputeHash(data));
            }
        }

        public static bool Verify(string password, string storedHash, string storedSalt)
        {
            if (string.IsNullOrEmpty(storedHash) || string.IsNullOrEmpty(storedSalt)) return false;
            return string.Equals(Hash(password, storedSalt), storedHash, StringComparison.Ordinal);
        }
    }
}
