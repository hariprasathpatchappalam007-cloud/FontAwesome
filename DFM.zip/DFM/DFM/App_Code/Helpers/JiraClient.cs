using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;
using DFM.App_Code.DAL;

namespace DFM.App_Code.Helpers
{
    public class JiraConfigInfo
    {
        public string BaseUrl;
        public string Email;
        public string Token;
        public string ProjectKey;
    }

    public class JiraFieldInfo
    {
        public string Key;
        public string Name;
    }

    /// <summary>
    /// Minimal JIRA REST client. Falls back to the cached dbo.JiraIssues seed table.
    /// </summary>
    public static class JiraClient
    {
        public static JiraConfigInfo GetConfig()
        {
            var info = new JiraConfigInfo();
            DataRow row = Db.QueryRow("SELECT TOP 1 BaseUrl, UserEmail, ApiToken, ProjectKey FROM JiraConfig ORDER BY ConfigID DESC");
            if (row == null)
            {
                info.BaseUrl = ""; info.Email = ""; info.Token = ""; info.ProjectKey = "";
                return info;
            }
            info.BaseUrl    = row["BaseUrl"]    == DBNull.Value ? "" : row["BaseUrl"].ToString();
            info.Email      = row["UserEmail"]  == DBNull.Value ? "" : row["UserEmail"].ToString();
            info.Token      = row["ApiToken"]   == DBNull.Value ? "" : row["ApiToken"].ToString();
            info.ProjectKey = row["ProjectKey"] == DBNull.Value ? "" : row["ProjectKey"].ToString();
            return info;
        }

        public static string FetchRaw(string url, string email, string token)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "GET";
            req.Accept = "application/json";
            req.Timeout = 15000;
            if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(token))
            {
                string basic = Convert.ToBase64String(Encoding.ASCII.GetBytes(email + ":" + token));
                req.Headers["Authorization"] = "Basic " + basic;
            }
            using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            using (Stream rs = resp.GetResponseStream())
            using (StreamReader sr = new StreamReader(rs))
            {
                return sr.ReadToEnd();
            }
        }

        public static List<Dictionary<string, object>> SearchIssues(string jql, int maxResults)
        {
            JiraConfigInfo cfg = GetConfig();
            List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
            if (string.IsNullOrEmpty(cfg.BaseUrl)) return list;
            try
            {
                string url = cfg.BaseUrl.TrimEnd('/') + "/rest/api/2/search?maxResults=" + maxResults +
                             "&jql=" + Uri.EscapeDataString(jql);
                string json = FetchRaw(url, cfg.Email, cfg.Token);
                JavaScriptSerializer jss = new JavaScriptSerializer();
                jss.MaxJsonLength = int.MaxValue;
                Dictionary<string, object> root = jss.Deserialize<Dictionary<string, object>>(json);
                if (root != null && root.ContainsKey("issues"))
                {
                    System.Collections.ArrayList issues = (System.Collections.ArrayList)root["issues"];
                    foreach (object it in issues)
                    {
                        Dictionary<string, object> d = it as Dictionary<string, object>;
                        if (d != null) list.Add(d);
                    }
                }
            }
            catch { /* swallow - caller falls back to cache */ }
            return list;
        }

        public static List<JiraFieldInfo> FetchAllFields()
        {
            List<JiraFieldInfo> result = new List<JiraFieldInfo>();
            JiraConfigInfo cfg = GetConfig();
            if (string.IsNullOrEmpty(cfg.BaseUrl)) return result;
            try
            {
                string url = cfg.BaseUrl.TrimEnd('/') + "/rest/api/2/field";
                string json = FetchRaw(url, cfg.Email, cfg.Token);
                JavaScriptSerializer jss = new JavaScriptSerializer();
                jss.MaxJsonLength = int.MaxValue;
                System.Collections.ArrayList arr = jss.Deserialize<System.Collections.ArrayList>(json);
                foreach (object item in arr)
                {
                    Dictionary<string, object> d = item as Dictionary<string, object>;
                    if (d == null) continue;
                    string id = d.ContainsKey("id") && d["id"] != null ? d["id"].ToString() : null;
                    string name = d.ContainsKey("name") && d["name"] != null ? d["name"].ToString() : null;
                    bool isCustom = d.ContainsKey("custom") && Convert.ToBoolean(d["custom"]);
                    if (isCustom && !string.IsNullOrEmpty(id) && !string.IsNullOrEmpty(name))
                    {
                        JiraFieldInfo f = new JiraFieldInfo();
                        f.Key = id;
                        f.Name = name;
                        result.Add(f);
                    }
                }
            }
            catch { }
            return result;
        }

        public static DataTable GetCachedIssues()
        {
            return Db.Query(@"SELECT JiraID, Summary, ProjectName, ProjectStage, ProjectType, ProjectRAG,
                                     OverallStatus, DemandType, Department, Manager, TechLead, Sponsor,
                                     Stakeholder, Classification, Objectives, StartDate, EndDate,
                                     CustomFieldsJson
                              FROM JiraIssues ORDER BY JiraID");
        }

        public static DataRow GetCachedIssue(string jiraId)
        {
            return Db.QueryRow("SELECT * FROM JiraIssues WHERE JiraID=@id", Db.P("@id", jiraId));
        }
    }
}
