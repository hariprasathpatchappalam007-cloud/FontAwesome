using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using DFM.App_Code.DAL;

namespace DFM.App_Code.Helpers
{
    public static class AuthHelper
    {
        public const string DefaultPassword = "Welcome@123";

        public static string AuthMode
        {
            get
            {
                string s = ConfigurationManager.AppSettings["AuthMode"];
                return string.IsNullOrEmpty(s) ? "Forms" : s;
            }
        }

        public static bool IsWindowsAuth
        {
            get { return string.Equals(AuthMode, "Windows", StringComparison.OrdinalIgnoreCase); }
        }

        public static void EnsureSeededPasswords()
        {
            string[] users = new string[] { "admin", "approver", "user1" };
            for (int i = 0; i < users.Length; i++)
            {
                string u = users[i];
                DataRow row = Db.QueryRow("SELECT UserID, PasswordHash FROM AppUsers WHERE Username=@u", Db.P("@u", u));
                if (row != null && (row["PasswordHash"] == DBNull.Value || string.IsNullOrEmpty(row["PasswordHash"].ToString())))
                {
                    string salt = PasswordHelper.GenerateSalt();
                    string hash = PasswordHelper.Hash(DefaultPassword, salt);
                    Db.Exec("UPDATE AppUsers SET PasswordHash=@h, PasswordSalt=@s WHERE Username=@u",
                        Db.P("@h", hash), Db.P("@s", salt), Db.P("@u", u));
                }
            }
        }

        public static bool TryLogin(string username, string password, out string error)
        {
            error = null;
            try
            {
                EnsureSeededPasswords();

                DataTable dt = Db.Query(
                    @"SELECT u.UserID, u.Username, u.PasswordHash, u.PasswordSalt, u.FullName, u.Email,
                             u.IsEnabled, r.RoleName
                      FROM AppUsers u INNER JOIN UserRoles r ON u.RoleID = r.RoleID
                      WHERE u.Username = @u",
                    Db.P("@u", username));

                if (dt.Rows.Count == 0) { error = "Invalid username or password."; return false; }
                DataRow row = dt.Rows[0];

                if (!Convert.ToBoolean(row["IsEnabled"])) { error = "Your account is disabled."; return false; }

                if (!PasswordHelper.Verify(password, row["PasswordHash"].ToString(), row["PasswordSalt"].ToString()))
                {
                    error = "Invalid username or password.";
                    return false;
                }

                Db.Exec("UPDATE AppUsers SET LastLoginDate=GETDATE() WHERE UserID=@id", Db.P("@id", row["UserID"]));

                HttpContext http = HttpContext.Current;
                http.Session["UserID"]   = row["UserID"];
                http.Session["Username"] = row["Username"].ToString();
                http.Session["FullName"] = row["FullName"].ToString();
                http.Session["Role"]     = row["RoleName"].ToString();
                http.Session["Email"]    = row["Email"] == DBNull.Value ? "" : row["Email"].ToString();

                FormsAuthentication.SetAuthCookie(row["Username"].ToString(), false);
                return true;
            }
            catch (SqlException ex)
            {
                error = "Database error: " + ex.Message;
                return false;
            }
        }

        public static string CurrentUser
        {
            get
            {
                HttpContext http = HttpContext.Current;
                string sessUser = http.Session["Username"] as string;
                if (!string.IsNullOrEmpty(sessUser)) return sessUser;
                if (http.User != null && http.User.Identity != null && !string.IsNullOrEmpty(http.User.Identity.Name))
                    return http.User.Identity.Name;
                return "system";
            }
        }

        public static string CurrentRole
        {
            get
            {
                string r = HttpContext.Current.Session["Role"] as string;
                return string.IsNullOrEmpty(r) ? "User" : r;
            }
        }
    }
}
