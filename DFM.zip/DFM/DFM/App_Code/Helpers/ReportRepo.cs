using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using DFM.App_Code.DAL;

namespace DFM.App_Code.Helpers
{
    /// <summary>
    /// Req6: thin read-only accessor over dbo.DashboardReport (the pre-aggregated
    /// dashboard payload populated by sp_RefreshDashboardReport at sync time).
    ///
    /// The web pages NEVER recompute aggregates over JiraIssues at runtime;
    /// they only project rows out of this table so the dashboard renders in
    /// the "blink of an eye" (Req6).
    /// </summary>
    public static class ReportRepo
    {
        /// <summary>Time the report was last refreshed by the console.</summary>
        public static DateTime? GetLastRefreshed()
        {
            object o = Db.Scalar("SELECT MAX(LastRefreshed) FROM dbo.DashboardReport");
            return (o == null || o == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(o);
        }

        /// <summary>Raw rows for one section (e.g. 'KPI', 'PlatformDemand').</summary>
        public static DataTable GetSection(string section)
        {
            return Db.Query(
                "SELECT Bucket, SubBucket, TotalCount, OpenCount, ClosedCount, " +
                "RedCount, AmberCount, GreenCount, SortOrder, Extra " +
                "FROM dbo.DashboardReport WHERE Section=@s " +
                "ORDER BY SortOrder, Bucket",
                new SqlParameter("@s", section));
        }

        public static DataTable GetKPIs()              { return GetSection("KPI"); }
        public static DataTable GetDemandStatus()      { return GetSection("DemandStatus"); }
        public static DataTable GetPlatformDemand()    { return GetSection("PlatformDemand"); }
        public static DataTable GetPortfolioByPlatform(){ return GetSection("PortfolioByPlatform"); }
        public static DataTable GetDeliveryByVertical() { return GetSection("DeliveryByVertical"); }
        public static DataTable GetRagDistribution()   { return GetSection("RagDistribution"); }
        public static DataTable GetAgingBuckets()      { return GetSection("AgingBuckets"); }
        public static DataTable GetPMWorkload()        { return GetSection("PMWorkload"); }
        public static DataTable GetTLWorkload()        { return GetSection("TLWorkload"); }
        public static DataTable GetChiefOwnership()    { return GetSection("ChiefOwnership"); }
        public static DataTable GetMarketTrending()    { return GetSection("MarketTrending"); }

        /// <summary>
        /// Returns distinct values for filter dropdowns from the dedicated
        /// DashboardFilterValues table. Falls back to JiraIssues if the
        /// table is empty or missing (defensive - prevents blank dropdowns).
        /// </summary>
        public static List<string> GetFilterValues(string filterType)
        {
            var list = new List<string>();
            try
            {
                var dt = Db.Query(
                    "SELECT DISTINCT FilterValue FROM dbo.DashboardFilterValues " +
                    "WHERE FilterType=@t AND FilterValue IS NOT NULL AND LTRIM(RTRIM(FilterValue))<>'' " +
                    "ORDER BY FilterValue",
                    new SqlParameter("@t", filterType));
                foreach (DataRow r in dt.Rows) list.Add(r[0].ToString());
            }
            catch { /* table may not exist on first deploy */ }

            if (list.Count == 0)
            {
                string col = MapFilterToColumn(filterType);
                if (col != null)
                {
                    try
                    {
                        var dt = Db.Query(
                            "SELECT DISTINCT " + col + " FROM dbo.JiraIssues " +
                            "WHERE " + col + " IS NOT NULL AND LTRIM(RTRIM(" + col + "))<>'' " +
                            "ORDER BY " + col);
                        foreach (DataRow r in dt.Rows) list.Add(r[0].ToString());
                    }
                    catch { }
                }
            }
            return list;
        }

        private static string MapFilterToColumn(string t)
        {
            switch ((t ?? "").ToLowerInvariant())
            {
                case "platform":      return "Platform";
                case "vertical":      return "PlatformVertical";
                case "manager":       return "Manager";
                case "techlead":      return "TechLead";
                case "chief":         return "ChiefNameMapping";
                case "portfoliohead": return "IdhPortfolioHead";
                case "rag":           return "OverallProjectRag";
                case "priority":      return "Priority";
                default: return null;
            }
        }
    }
}
