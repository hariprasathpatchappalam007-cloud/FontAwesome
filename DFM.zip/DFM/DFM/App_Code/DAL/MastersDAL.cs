using System;
using System.Data;
using System.Data.SqlClient;

namespace DFM.App_Code.DAL
{
    public static class MastersDAL
    {
        // Manual master edits go here as 'ManualUpdate' rows so the
        // CAPEX/OPEX Workflow History link surfaces them just like
        // PET approval locks and BPM debits.
        private static decimal D(DataRow r, string c)
        {
            if (r == null || !r.Table.Columns.Contains(c) || r[c] == DBNull.Value) return 0m;
            return System.Convert.ToDecimal(r[c]);
        }
        private static void LogMasterEdit(string sourceType, string sourceId, DataRow before,
            decimal newBudget, decimal newUtil, decimal newLocked, string user, string notes)
        {
            try
            {
                decimal pb = D(before, "Budget");
                decimal pu = D(before, "Utilization");
                decimal pl = D(before, "LockedAmount");
                bool create = (before == null);

                // Skip a no-op log when nothing actually changed.
                if (!create && pb == newBudget && pu == newUtil && pl == newLocked) return;

                Db.Exec(@"INSERT INTO CapexHistory(SourceType, SourceID, ProjectID, Action, Amount,
                            PrevBudget, NewBudget, PrevUtil, NewUtil, PrevLocked, NewLocked, Notes, ActionBy)
                          VALUES(@st, @src, NULL, @act, @amt,
                            @pb, @nb, @pu, @nu, @pl, @nl, @n, @u)",
                    Db.P("@st", sourceType), Db.P("@src", sourceId),
                    Db.P("@act", create ? "Created" : "ManualUpdate"),
                    Db.P("@amt", newBudget - pb),
                    Db.P("@pb", pb), Db.P("@nb", newBudget),
                    Db.P("@pu", pu), Db.P("@nu", newUtil),
                    Db.P("@pl", pl), Db.P("@nl", newLocked),
                    Db.P("@n", notes ?? (create ? "Master record created" : "Direct master edit")),
                    Db.P("@u", user ?? "system"));
            }
            catch { /* don't block the save if audit table is missing */ }
        }

        // ---- CAPEX ----
        public static DataTable GetCapex(string search = null)
        {
            try
            {
                return Db.QuerySP("sp_GetCapex", Db.P("@Search", search ?? ""));
            }
            catch
            {
                string sql = "SELECT * FROM CapexMaster WHERE 1=1";
                if (!string.IsNullOrEmpty(search))
                    sql += " AND (CapexID LIKE @s OR Description LIKE @s)";
                sql += " ORDER BY CapexID";
                if (!string.IsNullOrEmpty(search))
                    return Db.Query(sql, Db.P("@s", "%" + search + "%"));
                return Db.Query(sql);
            }
        }

        public static DataRow GetCapexById(string id)
        {
            return Db.QueryRow("SELECT * FROM CapexMaster WHERE CapexID=@id", Db.P("@id", id));
        }

        public static void UpsertCapex(string id, string desc, decimal budget, decimal util, decimal avail,
            decimal locked, decimal afterLocked, decimal claim, decimal net, string user)
        {
            DataRow before = GetCapexById(id);
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM CapexMaster WHERE CapexID=@id)
    UPDATE CapexMaster SET Description=@d, Budget=@b, Utilization=@u, AvailableBudget=@a,
        LockedAmount=@l, BudgetAfterLockedAmount=@al, ClaimAmount=@c, NetBalance=@n,
        ModifiedDate=GETDATE(), ModifiedBy=@user
    WHERE CapexID=@id
ELSE
    INSERT INTO CapexMaster(CapexID, Description, Budget, Utilization, AvailableBudget,
        LockedAmount, BudgetAfterLockedAmount, ClaimAmount, NetBalance, ModifiedBy)
    VALUES (@id, @d, @b, @u, @a, @l, @al, @c, @n, @user);",
                Db.P("@id", id), Db.P("@d", desc), Db.P("@b", budget), Db.P("@u", util),
                Db.P("@a", avail), Db.P("@l", locked), Db.P("@al", afterLocked),
                Db.P("@c", claim), Db.P("@n", net), Db.P("@user", user));
            LogMasterEdit("CAPEX", id, before, budget, util, locked, user, null);
        }

        public static void DeleteCapex(string id)
        {
            DataRow before = GetCapexById(id);
            Db.Exec("DELETE FROM CapexMaster WHERE CapexID=@id", Db.P("@id", id));
            if (before != null)
            {
                try
                {
                    Db.Exec(@"INSERT INTO CapexHistory(SourceType, SourceID, ProjectID, Action, Amount,
                                PrevBudget, NewBudget, PrevUtil, NewUtil, PrevLocked, NewLocked, Notes, ActionBy)
                              VALUES('CAPEX', @src, NULL, 'Deleted', 0,
                                @pb, 0, @pu, 0, @pl, 0, 'Master record deleted', @u)",
                        Db.P("@src", id), Db.P("@pb", D(before, "Budget")),
                        Db.P("@pu", D(before, "Utilization")), Db.P("@pl", D(before, "LockedAmount")),
                        Db.P("@u", "system"));
                }
                catch { }
            }
        }

        // ---- OPEX ----
        public static DataTable GetOpex(string search = null)
        {
            string sql = "SELECT * FROM OpexMaster WHERE 1=1";
            if (!string.IsNullOrEmpty(search)) sql += " AND (OpexID LIKE @s OR Description LIKE @s)";
            sql += " ORDER BY OpexID";
            if (!string.IsNullOrEmpty(search))
                return Db.Query(sql, Db.P("@s", "%" + search + "%"));
            return Db.Query(sql);
        }

        public static DataRow GetOpexById(string id)
        {
            return Db.QueryRow("SELECT * FROM OpexMaster WHERE OpexID=@id", Db.P("@id", id));
        }

        public static void UpsertOpex(string id, string desc, decimal budget, decimal util, decimal avail,
            decimal locked, decimal afterLocked, decimal claim, decimal net, string user)
        {
            DataRow before = GetOpexById(id);
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM OpexMaster WHERE OpexID=@id)
    UPDATE OpexMaster SET Description=@d, Budget=@b, Utilization=@u, AvailableBudget=@a,
        LockedAmount=@l, BudgetAfterLockedAmount=@al, ClaimAmount=@c, NetBalance=@n,
        ModifiedDate=GETDATE(), ModifiedBy=@user
    WHERE OpexID=@id
ELSE
    INSERT INTO OpexMaster(OpexID, Description, Budget, Utilization, AvailableBudget,
        LockedAmount, BudgetAfterLockedAmount, ClaimAmount, NetBalance, ModifiedBy)
    VALUES (@id, @d, @b, @u, @a, @l, @al, @c, @n, @user);",
                Db.P("@id", id), Db.P("@d", desc), Db.P("@b", budget), Db.P("@u", util),
                Db.P("@a", avail), Db.P("@l", locked), Db.P("@al", afterLocked),
                Db.P("@c", claim), Db.P("@n", net), Db.P("@user", user));
            LogMasterEdit("OPEX", id, before, budget, util, locked, user, null);
        }

        public static void DeleteOpex(string id)
        {
            DataRow before = GetOpexById(id);
            Db.Exec("DELETE FROM OpexMaster WHERE OpexID=@id", Db.P("@id", id));
            if (before != null)
            {
                try
                {
                    Db.Exec(@"INSERT INTO CapexHistory(SourceType, SourceID, ProjectID, Action, Amount,
                                PrevBudget, NewBudget, PrevUtil, NewUtil, PrevLocked, NewLocked, Notes, ActionBy)
                              VALUES('OPEX', @src, NULL, 'Deleted', 0,
                                @pb, 0, @pu, 0, @pl, 0, 'Master record deleted', @u)",
                        Db.P("@src", id), Db.P("@pb", D(before, "Budget")),
                        Db.P("@pu", D(before, "Utilization")), Db.P("@pl", D(before, "LockedAmount")),
                        Db.P("@u", "system"));
                }
                catch { }
            }
        }

        // ---- AMC ----
        public static DataTable GetAmc(string search = null)
        {
            string sql = "SELECT * FROM AmcMaster WHERE 1=1";
            if (!string.IsNullOrEmpty(search)) sql += " AND (AmcID LIKE @s OR Description LIKE @s)";
            sql += " ORDER BY AmcID";
            if (!string.IsNullOrEmpty(search))
                return Db.Query(sql, Db.P("@s", "%" + search + "%"));
            return Db.Query(sql);
        }

        public static DataRow GetAmcById(string id)
        {
            return Db.QueryRow("SELECT * FROM AmcMaster WHERE AmcID=@id", Db.P("@id", id));
        }

        public static void UpsertAmc(string id, string desc, decimal budget, decimal util, decimal avail,
            decimal locked, decimal afterLocked, decimal claim, decimal net, string user)
        {
            DataRow before = GetAmcById(id);
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM AmcMaster WHERE AmcID=@id)
    UPDATE AmcMaster SET Description=@d, Budget=@b, Utilization=@u, AvailableBudget=@a,
        LockedAmount=@l, BudgetAfterLockedAmount=@al, ClaimAmount=@c, NetBalance=@n,
        ModifiedDate=GETDATE(), ModifiedBy=@user
    WHERE AmcID=@id
ELSE
    INSERT INTO AmcMaster(AmcID, Description, Budget, Utilization, AvailableBudget,
        LockedAmount, BudgetAfterLockedAmount, ClaimAmount, NetBalance, ModifiedBy)
    VALUES (@id, @d, @b, @u, @a, @l, @al, @c, @n, @user);",
                Db.P("@id", id), Db.P("@d", desc), Db.P("@b", budget), Db.P("@u", util),
                Db.P("@a", avail), Db.P("@l", locked), Db.P("@al", afterLocked),
                Db.P("@c", claim), Db.P("@n", net), Db.P("@user", user));
            LogMasterEdit("AMC", id, before, budget, util, locked, user, null);
        }

        public static void DeleteAmc(string id)
        {
            Db.Exec("DELETE FROM AmcMaster WHERE AmcID=@id", Db.P("@id", id));
        }

        // ---- Approvers ----
        public static DataTable GetApprovers(bool activeOnly = false)
        {
            string sql = "SELECT * FROM ApproverMaster";
            if (activeOnly) sql += " WHERE IsActive = 1";
            sql += " ORDER BY ApproverName";
            return Db.Query(sql);
        }

        public static DataTable GetAllApprovers()
        {
            return GetApprovers(false);
        }

        public static void UpsertApprover(int approverId, string name, string email,
            string dept, int level, bool active)
        {
            if (approverId > 0)
            {
                Db.Exec(@"UPDATE ApproverMaster SET ApproverName=@n, Email=@e, Department=@d,
                          ApprovalLevel=@l, IsActive=@a WHERE ApproverID=@id",
                    Db.P("@id", approverId), Db.P("@n", name), Db.P("@e", email),
                    Db.P("@d", dept), Db.P("@l", level), Db.P("@a", active));
            }
            else
            {
                Db.Exec(@"INSERT INTO ApproverMaster(ApproverName, Email, Department, ApprovalLevel, IsActive)
                          VALUES(@n, @e, @d, @l, @a)",
                    Db.P("@n", name), Db.P("@e", email), Db.P("@d", dept),
                    Db.P("@l", level), Db.P("@a", active));
            }
        }

        public static void DeleteApprover(int id)
        {
            Db.Exec("DELETE FROM ApproverMaster WHERE ApproverID=@id", Db.P("@id", id));
        }

        // ---- JIRA Field config ----
        public static DataTable GetJiraFields()
        {
            try { return Db.QuerySP("sp_GetJiraFields"); }
            catch { return Db.Query("SELECT * FROM JiraCustomFieldConfig ORDER BY DisplayOrder, FieldName"); }
        }

        public static void SetJiraFieldVisibility(int id, bool visible)
        {
            try { Db.ExecSP("sp_SetJiraFieldVisibility", Db.P("@ID", id), Db.P("@IsVisible", visible)); }
            catch
            {
                Db.Exec("UPDATE JiraCustomFieldConfig SET IsVisible=@v, UpdatedDate=GETDATE() WHERE ID=@id",
                    Db.P("@id", id), Db.P("@v", visible));
            }
        }

        public static void UpsertJiraField(string key, string name, int order, bool visible)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM JiraCustomFieldConfig WHERE FieldKey=@k)
    UPDATE JiraCustomFieldConfig SET FieldName=@n, DisplayOrder=@o, IsVisible=@v, UpdatedDate=GETDATE() WHERE FieldKey=@k
ELSE
    INSERT INTO JiraCustomFieldConfig(FieldKey, FieldName, DisplayOrder, IsVisible) VALUES (@k, @n, @o, @v);",
                Db.P("@k", key), Db.P("@n", name), Db.P("@o", order), Db.P("@v", visible));
        }

        // ---- User settings ----
        public static DataRow GetUserSettings(string username)
        {
            return Db.QueryRow("SELECT * FROM UserSettings WHERE Username=@u", Db.P("@u", username));
        }

        public static void SaveUserSettings(string username, string theme, string fontSize, string defaultPage, bool notif)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM UserSettings WHERE Username=@u)
    UPDATE UserSettings SET ThemeName=@t, FontSize=@f, DefaultPage=@d, Notifications=@n, UpdatedDate=GETDATE() WHERE Username=@u
ELSE
    INSERT INTO UserSettings(Username, ThemeName, FontSize, DefaultPage, Notifications)
    VALUES (@u, @t, @f, @d, @n);",
                Db.P("@u", username), Db.P("@t", theme), Db.P("@f", fontSize),
                Db.P("@d", defaultPage), Db.P("@n", notif));
        }

        // ---- JIRA config ----
        public static DataRow GetJiraConfig()
        {
            try { return Db.QueryRowSP("sp_GetJiraConfig"); }
            catch { return Db.QueryRow("SELECT TOP 1 * FROM JiraConfig ORDER BY ConfigID DESC"); }
        }

        public static void SaveJiraConfig(string baseUrl, string email, string token, string projectKey)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM JiraConfig)
    UPDATE JiraConfig SET BaseUrl=@b, UserEmail=@e, ApiToken=@t, ProjectKey=@p, UpdatedDate=GETDATE()
ELSE
    INSERT INTO JiraConfig(BaseUrl, UserEmail, ApiToken, ProjectKey) VALUES (@b, @e, @t, @p);",
                Db.P("@b", baseUrl), Db.P("@e", email), Db.P("@t", token), Db.P("@p", projectKey));
        }

        // Req 67-68: JIRA Username/Password (no API token)
        public static void SaveJiraConfigBasic(string baseUrl, string projectKey, string userName, string password)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM JiraConfig)
    UPDATE JiraConfig SET BaseUrl=@b, ProjectKey=@p, UserName=@u, UserPassword=@pw, UpdatedDate=GETDATE()
ELSE
    INSERT INTO JiraConfig(BaseUrl, ProjectKey, UserName, UserPassword) VALUES (@b, @p, @u, @pw);",
                Db.P("@b", baseUrl), Db.P("@p", projectKey),
                Db.P("@u", userName), Db.P("@pw", password));
        }
    }
}
