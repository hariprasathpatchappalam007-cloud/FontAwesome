using System.Data;
using System.Data.SqlClient;

namespace DFM.App_Code.DAL
{
    public static class MastersDAL
    {
        // ---- CAPEX ----
        public static DataTable GetCapex(string search = null)
        {
            string sql = "SELECT * FROM CapexMaster WHERE 1=1";
            if (!string.IsNullOrEmpty(search))
                sql += " AND (CapexID LIKE @s OR Description LIKE @s)";
            sql += " ORDER BY CapexID";
            if (!string.IsNullOrEmpty(search))
                return Db.Query(sql, Db.P("@s", "%" + search + "%"));
            return Db.Query(sql);
        }

        public static DataRow GetCapexById(string id)
        {
            return Db.QueryRow("SELECT * FROM CapexMaster WHERE CapexID=@id", Db.P("@id", id));
        }

        public static void UpsertCapex(string id, string desc, decimal budget, decimal util, decimal avail,
            decimal locked, decimal afterLocked, decimal claim, decimal net, string user)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM CapexMaster WHERE CapexID=@id)
    UPDATE CapexMaster SET Description=@d, Budget=@b, Utilization=@u, AvailableBudget=@a,
        LockedAmount=@l, BudgetAfterLockedAmount=@al, ClaimAmount=@c, NetBalance=@n,
        ModifiedDate=GETDATE(), ModifiedBy=@user
    WHERE CapexID=@id
ELSE
    INSERT INTO CapexMaster(CapexID, Description, Budget, Utilization, AvailableBudget,
        LockedAmount, BudgetAfterLockedAmount, ClaimAmount, NetBalance, ModifiedBy)
    VALUES (@id, @d, @b, @u, @a, @l, @al, @c, @n, @user);",
                Db.P("@id", id), Db.P("@d", desc), Db.P("@b", budget), Db.P("@u", util),
                Db.P("@a", avail), Db.P("@l", locked), Db.P("@al", afterLocked),
                Db.P("@c", claim), Db.P("@n", net), Db.P("@user", user));
        }

        public static void DeleteCapex(string id)
        {
            Db.Exec("DELETE FROM CapexMaster WHERE CapexID=@id", Db.P("@id", id));
        }

        // ---- OPEX ----
        public static DataTable GetOpex(string search = null)
        {
            string sql = "SELECT * FROM OpexMaster WHERE 1=1";
            if (!string.IsNullOrEmpty(search)) sql += " AND (OpexID LIKE @s OR Description LIKE @s)";
            sql += " ORDER BY OpexID";
            if (!string.IsNullOrEmpty(search))
                return Db.Query(sql, Db.P("@s", "%" + search + "%"));
            return Db.Query(sql);
        }

        public static DataRow GetOpexById(string id)
        {
            return Db.QueryRow("SELECT * FROM OpexMaster WHERE OpexID=@id", Db.P("@id", id));
        }

        public static void UpsertOpex(string id, string desc, decimal budget, decimal util, decimal avail,
            decimal locked, decimal afterLocked, decimal claim, decimal net, string user)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM OpexMaster WHERE OpexID=@id)
    UPDATE OpexMaster SET Description=@d, Budget=@b, Utilization=@u, AvailableBudget=@a,
        LockedAmount=@l, BudgetAfterLockedAmount=@al, ClaimAmount=@c, NetBalance=@n,
        ModifiedDate=GETDATE(), ModifiedBy=@user
    WHERE OpexID=@id
ELSE
    INSERT INTO OpexMaster(OpexID, Description, Budget, Utilization, AvailableBudget,
        LockedAmount, BudgetAfterLockedAmount, ClaimAmount, NetBalance, ModifiedBy)
    VALUES (@id, @d, @b, @u, @a, @l, @al, @c, @n, @user);",
                Db.P("@id", id), Db.P("@d", desc), Db.P("@b", budget), Db.P("@u", util),
                Db.P("@a", avail), Db.P("@l", locked), Db.P("@al", afterLocked),
                Db.P("@c", claim), Db.P("@n", net), Db.P("@user", user));
        }

        public static void DeleteOpex(string id)
        {
            Db.Exec("DELETE FROM OpexMaster WHERE OpexID=@id", Db.P("@id", id));
        }

        // ---- AMC ----
        public static DataTable GetAmc(string search = null)
        {
            string sql = "SELECT * FROM AmcMaster WHERE 1=1";
            if (!string.IsNullOrEmpty(search)) sql += " AND (AmcID LIKE @s OR Description LIKE @s)";
            sql += " ORDER BY AmcID";
            if (!string.IsNullOrEmpty(search))
                return Db.Query(sql, Db.P("@s", "%" + search + "%"));
            return Db.Query(sql);
        }

        public static DataRow GetAmcById(string id)
        {
            return Db.QueryRow("SELECT * FROM AmcMaster WHERE AmcID=@id", Db.P("@id", id));
        }

        public static void UpsertAmc(string id, string desc, decimal budget, decimal util, decimal avail,
            decimal locked, decimal afterLocked, decimal claim, decimal net, string user)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM AmcMaster WHERE AmcID=@id)
    UPDATE AmcMaster SET Description=@d, Budget=@b, Utilization=@u, AvailableBudget=@a,
        LockedAmount=@l, BudgetAfterLockedAmount=@al, ClaimAmount=@c, NetBalance=@n,
        ModifiedDate=GETDATE(), ModifiedBy=@user
    WHERE AmcID=@id
ELSE
    INSERT INTO AmcMaster(AmcID, Description, Budget, Utilization, AvailableBudget,
        LockedAmount, BudgetAfterLockedAmount, ClaimAmount, NetBalance, ModifiedBy)
    VALUES (@id, @d, @b, @u, @a, @l, @al, @c, @n, @user);",
                Db.P("@id", id), Db.P("@d", desc), Db.P("@b", budget), Db.P("@u", util),
                Db.P("@a", avail), Db.P("@l", locked), Db.P("@al", afterLocked),
                Db.P("@c", claim), Db.P("@n", net), Db.P("@user", user));
        }

        public static void DeleteAmc(string id)
        {
            Db.Exec("DELETE FROM AmcMaster WHERE AmcID=@id", Db.P("@id", id));
        }

        // ---- Approvers ----
        public static DataTable GetApprovers(bool activeOnly = false)
        {
            string sql = "SELECT * FROM ApproverMaster";
            if (activeOnly) sql += " WHERE IsActive = 1";
            sql += " ORDER BY ApproverName";
            return Db.Query(sql);
        }

        public static DataTable GetAllApprovers()
        {
            return GetApprovers(false);
        }

        public static void UpsertApprover(int approverId, string name, string email,
            string dept, int level, bool active)
        {
            if (approverId > 0)
            {
                Db.Exec(@"UPDATE ApproverMaster SET ApproverName=@n, Email=@e, Department=@d,
                          ApprovalLevel=@l, IsActive=@a WHERE ApproverID=@id",
                    Db.P("@id", approverId), Db.P("@n", name), Db.P("@e", email),
                    Db.P("@d", dept), Db.P("@l", level), Db.P("@a", active));
            }
            else
            {
                Db.Exec(@"INSERT INTO ApproverMaster(ApproverName, Email, Department, ApprovalLevel, IsActive)
                          VALUES(@n, @e, @d, @l, @a)",
                    Db.P("@n", name), Db.P("@e", email), Db.P("@d", dept),
                    Db.P("@l", level), Db.P("@a", active));
            }
        }

        public static void DeleteApprover(int id)
        {
            Db.Exec("DELETE FROM ApproverMaster WHERE ApproverID=@id", Db.P("@id", id));
        }

        // ---- JIRA Field config ----
        public static DataTable GetJiraFields()
        {
            return Db.Query("SELECT * FROM JiraCustomFieldConfig ORDER BY DisplayOrder, FieldName");
        }

        public static void SetJiraFieldVisibility(int id, bool visible)
        {
            Db.Exec("UPDATE JiraCustomFieldConfig SET IsVisible=@v, UpdatedDate=GETDATE() WHERE ID=@id",
                Db.P("@id", id), Db.P("@v", visible));
        }

        public static void UpsertJiraField(string key, string name, int order, bool visible)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM JiraCustomFieldConfig WHERE FieldKey=@k)
    UPDATE JiraCustomFieldConfig SET FieldName=@n, DisplayOrder=@o, IsVisible=@v, UpdatedDate=GETDATE() WHERE FieldKey=@k
ELSE
    INSERT INTO JiraCustomFieldConfig(FieldKey, FieldName, DisplayOrder, IsVisible) VALUES (@k, @n, @o, @v);",
                Db.P("@k", key), Db.P("@n", name), Db.P("@o", order), Db.P("@v", visible));
        }

        // ---- User settings ----
        public static DataRow GetUserSettings(string username)
        {
            return Db.QueryRow("SELECT * FROM UserSettings WHERE Username=@u", Db.P("@u", username));
        }

        public static void SaveUserSettings(string username, string theme, string fontSize, string defaultPage, bool notif)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM UserSettings WHERE Username=@u)
    UPDATE UserSettings SET ThemeName=@t, FontSize=@f, DefaultPage=@d, Notifications=@n, UpdatedDate=GETDATE() WHERE Username=@u
ELSE
    INSERT INTO UserSettings(Username, ThemeName, FontSize, DefaultPage, Notifications)
    VALUES (@u, @t, @f, @d, @n);",
                Db.P("@u", username), Db.P("@t", theme), Db.P("@f", fontSize),
                Db.P("@d", defaultPage), Db.P("@n", notif));
        }

        // ---- JIRA config ----
        public static DataRow GetJiraConfig()
        {
            return Db.QueryRow("SELECT TOP 1 * FROM JiraConfig ORDER BY ConfigID DESC");
        }

        public static void SaveJiraConfig(string baseUrl, string email, string token, string projectKey)
        {
            Db.Exec(@"
IF EXISTS (SELECT 1 FROM JiraConfig)
    UPDATE JiraConfig SET BaseUrl=@b, UserEmail=@e, ApiToken=@t, ProjectKey=@p, UpdatedDate=GETDATE()
ELSE
    INSERT INTO JiraConfig(BaseUrl, UserEmail, ApiToken, ProjectKey) VALUES (@b, @e, @t, @p);",
                Db.P("@b", baseUrl), Db.P("@e", email), Db.P("@t", token), Db.P("@p", projectKey));
        }
    }
}
