using System;
using System.Data;

namespace DFM.App_Code.DAL
{
    public static class MemoDAL
    {
        // ===== Memos (Internal Memo / CAM) =====
        public static DataTable GetByProject(int projectId)
        {
            return Db.Query(@"
SELECT m.*, v.VendorName, v.VendorCode
FROM CapexMemos m
LEFT JOIN VendorMaster v ON m.VendorID = v.VendorID
WHERE m.ProjectID=@id
ORDER BY m.MemoID DESC", Db.P("@id", projectId));
        }

        public static DataRow GetById(int memoId)
        {
            return Db.QueryRow(@"
SELECT m.*, v.VendorName, v.VendorCode
FROM CapexMemos m
LEFT JOIN VendorMaster v ON m.VendorID = v.VendorID
WHERE m.MemoID=@id", Db.P("@id", memoId));
        }

        public static int Create(int projectId, string memoNumber, decimal approvedAmount,
            int? vendorId, DateTime? dateRaised, string lpoSoNumber, DateTime? poDate,
            string amsNumber, string description, int capexVersion, string user, string glCode = null)
        {
            object id = Db.Scalar(@"
INSERT INTO CapexMemos(ProjectID, MemoNumber, ApprovedAmountAED, VendorID, DateRaised,
    LPO_SO_Number, PODate, AMS_Number, CAMStatus, Description, CapexVersion,
    PendingBalance, CreatedBy, GLCode)
VALUES(@pid, @mn, @amt, @vid, @dr, @lpo, @pod, @ams, 'Open', @desc, @cv, @amt, @u, @gl);
SELECT CAST(SCOPE_IDENTITY() AS INT);",
                Db.P("@pid", projectId),
                Db.P("@mn", memoNumber ?? ""),
                Db.P("@amt", approvedAmount),
                Db.P("@vid", vendorId.HasValue ? (object)vendorId.Value : DBNull.Value),
                Db.P("@dr", dateRaised.HasValue ? (object)dateRaised.Value : DBNull.Value),
                Db.P("@lpo", lpoSoNumber ?? ""),
                Db.P("@pod", poDate.HasValue ? (object)poDate.Value : DBNull.Value),
                Db.P("@ams", amsNumber ?? ""),
                Db.P("@desc", description ?? ""),
                Db.P("@cv", capexVersion),
                Db.P("@u", user ?? ""),
                Db.P("@gl", string.IsNullOrEmpty(glCode) ? (object)DBNull.Value : glCode));
            return id == null || id == DBNull.Value ? 0 : Convert.ToInt32(id);
        }

        public static void Update(int memoId, string memoNumber, decimal approvedAmount,
            int? vendorId, DateTime? dateRaised, string lpoSoNumber, DateTime? poDate,
            string amsNumber, string camStatus, string description, string glCode = null)
        {
            Db.Exec(@"
UPDATE CapexMemos SET MemoNumber=@mn, ApprovedAmountAED=@amt, VendorID=@vid,
    DateRaised=@dr, LPO_SO_Number=@lpo, PODate=@pod, AMS_Number=@ams,
    CAMStatus=@cs, Description=@desc, GLCode=@gl, ModifiedDate=GETDATE()
WHERE MemoID=@id",
                Db.P("@id", memoId),
                Db.P("@mn", memoNumber ?? ""),
                Db.P("@amt", approvedAmount),
                Db.P("@vid", vendorId.HasValue ? (object)vendorId.Value : DBNull.Value),
                Db.P("@dr", dateRaised.HasValue ? (object)dateRaised.Value : DBNull.Value),
                Db.P("@lpo", lpoSoNumber ?? ""),
                Db.P("@pod", poDate.HasValue ? (object)poDate.Value : DBNull.Value),
                Db.P("@ams", amsNumber ?? ""),
                Db.P("@cs", camStatus ?? "Open"),
                Db.P("@desc", description ?? ""),
                Db.P("@gl", string.IsNullOrEmpty(glCode) ? (object)DBNull.Value : glCode));
        }

        public static void Delete(int memoId)
        {
            Db.Exec("DELETE FROM MemoInvoices WHERE MemoID=@id", Db.P("@id", memoId));
            Db.Exec("DELETE FROM CapexMemos WHERE MemoID=@id", Db.P("@id", memoId));
        }

        public static void RecalcMemoTotals(int memoId)
        {
            Db.Exec(@"
UPDATE CapexMemos SET
    TotalInvoiceAmount = ISNULL((SELECT SUM(InvoiceAmountAED) FROM MemoInvoices WHERE MemoID=@id), 0),
    AmountDisbursed = ISNULL((SELECT SUM(InvoiceAmountAED) FROM MemoInvoices WHERE MemoID=@id AND InvoiceStatus='Paid'), 0),
    PendingBalance = ApprovedAmountAED - ISNULL((SELECT SUM(InvoiceAmountAED) FROM MemoInvoices WHERE MemoID=@id AND InvoiceStatus='Paid'), 0),
    ModifiedDate = GETDATE()
WHERE MemoID=@id", Db.P("@id", memoId));
        }

        // ===== Vendor Settlement Summary =====
        public static DataTable GetSettlementSummary(int projectId)
        {
            return Db.Query(@"
SELECT m.MemoID, m.MemoNumber, m.LPO_SO_Number, m.ApprovedAmountAED AS TotalLPOAmount,
    m.AmountDisbursed, m.PendingBalance,
    CASE WHEN m.ApprovedAmountAED > 0 THEN CAST(m.AmountDisbursed * 100.0 / m.ApprovedAmountAED AS DECIMAL(5,2)) ELSE 0 END AS PctUtilized,
    CASE WHEN m.ApprovedAmountAED > 0 THEN CAST(m.PendingBalance * 100.0 / m.ApprovedAmountAED AS DECIMAL(5,2)) ELSE 0 END AS PctRemaining,
    m.CAMStatus, v.VendorName
FROM CapexMemos m
LEFT JOIN VendorMaster v ON m.VendorID = v.VendorID
WHERE m.ProjectID=@id
ORDER BY m.MemoID", Db.P("@id", projectId));
        }

        /// <summary>Check if all memos/invoices are settled for a project (closure check).</summary>
        public static bool IsFullySettled(int projectId)
        {
            object o = Db.Scalar(@"
SELECT CASE WHEN EXISTS(
    SELECT 1 FROM CapexMemos m WHERE m.ProjectID=@id AND (m.PendingBalance > 0 OR m.CAMStatus <> 'Closed')
) OR EXISTS(
    SELECT 1 FROM MemoInvoices i INNER JOIN CapexMemos m ON i.MemoID=m.MemoID
    WHERE m.ProjectID=@id AND i.InvoiceStatus <> 'Paid'
) THEN 0 ELSE 1 END", Db.P("@id", projectId));
            return o != null && Convert.ToInt32(o) == 1;
        }

        // ===== Invoices =====
        public static DataTable GetInvoices(int memoId)
        {
            return Db.Query("SELECT * FROM MemoInvoices WHERE MemoID=@id ORDER BY InvoiceID",
                Db.P("@id", memoId));
        }

        public static DataRow GetInvoice(int invoiceId)
        {
            return Db.QueryRow("SELECT * FROM MemoInvoices WHERE InvoiceID=@id",
                Db.P("@id", invoiceId));
        }

        public static int AddInvoice(int memoId, string invoiceMemoNum, string invoiceNum,
            decimal amount, DateTime? invoiceDate, DateTime? entryDate, string status,
            string description, string user)
        {
            // Validate: disbursement must not exceed LPO limit
            DataRow memo = GetById(memoId);
            if (memo != null)
            {
                decimal lpoAmount = memo["ApprovedAmountAED"] == DBNull.Value ? 0m : Convert.ToDecimal(memo["ApprovedAmountAED"]);
                decimal totalExisting = memo["TotalInvoiceAmount"] == DBNull.Value ? 0m : Convert.ToDecimal(memo["TotalInvoiceAmount"]);
                if (totalExisting + amount > lpoAmount)
                    throw new InvalidOperationException(
                        string.Format("Invoice amount ({0:N2}) would exceed LPO limit ({1:N2}). Current total: {2:N2}.",
                            amount, lpoAmount, totalExisting));
            }

            object id = Db.Scalar(@"
INSERT INTO MemoInvoices(MemoID, InvoiceMemoNumber, InvoiceNumber, InvoiceAmountAED,
    InvoiceDate, InvoiceEntryDate, InvoiceStatus, InvoiceDescription, CreatedBy)
VALUES(@mid, @imn, @inum, @amt, @idate, @edate, @st, @desc, @u);
SELECT CAST(SCOPE_IDENTITY() AS INT);",
                Db.P("@mid", memoId),
                Db.P("@imn", invoiceMemoNum ?? ""),
                Db.P("@inum", invoiceNum ?? ""),
                Db.P("@amt", amount),
                Db.P("@idate", invoiceDate.HasValue ? (object)invoiceDate.Value : DBNull.Value),
                Db.P("@edate", entryDate.HasValue ? (object)entryDate.Value : DBNull.Value),
                Db.P("@st", status ?? "Pending"),
                Db.P("@desc", description ?? ""),
                Db.P("@u", user ?? ""));

            int invId = id == null || id == DBNull.Value ? 0 : Convert.ToInt32(id);
            RecalcMemoTotals(memoId);
            return invId;
        }

        public static void UpdateInvoice(int invoiceId, string invoiceMemoNum, string invoiceNum,
            decimal amount, DateTime? invoiceDate, DateTime? entryDate, string status, string description)
        {
            DataRow inv = GetInvoice(invoiceId);
            if (inv == null) return;
            int memoId = Convert.ToInt32(inv["MemoID"]);

            Db.Exec(@"
UPDATE MemoInvoices SET InvoiceMemoNumber=@imn, InvoiceNumber=@inum, InvoiceAmountAED=@amt,
    InvoiceDate=@idate, InvoiceEntryDate=@edate, InvoiceStatus=@st,
    InvoiceDescription=@desc, ModifiedDate=GETDATE()
WHERE InvoiceID=@id",
                Db.P("@id", invoiceId),
                Db.P("@imn", invoiceMemoNum ?? ""),
                Db.P("@inum", invoiceNum ?? ""),
                Db.P("@amt", amount),
                Db.P("@idate", invoiceDate.HasValue ? (object)invoiceDate.Value : DBNull.Value),
                Db.P("@edate", entryDate.HasValue ? (object)entryDate.Value : DBNull.Value),
                Db.P("@st", status ?? "Pending"),
                Db.P("@desc", description ?? ""));

            RecalcMemoTotals(memoId);
        }

        public static void DeleteInvoice(int invoiceId)
        {
            DataRow inv = GetInvoice(invoiceId);
            if (inv == null) return;
            int memoId = Convert.ToInt32(inv["MemoID"]);
            Db.Exec("DELETE FROM MemoInvoices WHERE InvoiceID=@id", Db.P("@id", invoiceId));
            RecalcMemoTotals(memoId);
        }
    }
}
