using System;
using System.Data;

namespace DFM.App_Code.DAL
{
    public static class VendorMasterDAL
    {
        public static DataTable GetAll(bool activeOnly = true)
        {
            string sql = activeOnly
                ? "SELECT * FROM VendorMaster WHERE IsActive=1 ORDER BY VendorName"
                : "SELECT * FROM VendorMaster ORDER BY VendorName";
            return Db.Query(sql);
        }

        public static DataRow GetById(int id)
        {
            return Db.QueryRow("SELECT * FROM VendorMaster WHERE VendorID=@id", Db.P("@id", id));
        }

        public static void Upsert(int id, string code, string name, string contact, string phone, string email, bool active)
        {
            if (id > 0)
                Db.Exec(@"UPDATE VendorMaster SET VendorCode=@c, VendorName=@n, ContactPerson=@cp,
                          Phone=@ph, Email=@em, IsActive=@a, ModifiedDate=GETDATE()
                          WHERE VendorID=@id",
                    Db.P("@id", id), Db.P("@c", code), Db.P("@n", name), Db.P("@cp", contact),
                    Db.P("@ph", phone), Db.P("@em", email), Db.P("@a", active));
            else
                Db.Exec(@"INSERT INTO VendorMaster(VendorCode, VendorName, ContactPerson, Phone, Email, IsActive)
                          VALUES(@c, @n, @cp, @ph, @em, @a)",
                    Db.P("@c", code), Db.P("@n", name), Db.P("@cp", contact),
                    Db.P("@ph", phone), Db.P("@em", email), Db.P("@a", active));
        }

        public static void Delete(int id)
        {
            Db.Exec("DELETE FROM VendorMaster WHERE VendorID=@id", Db.P("@id", id));
        }
    }
}
