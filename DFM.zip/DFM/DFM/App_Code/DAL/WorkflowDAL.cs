using System;
using System.Data;
using System.Data.SqlClient;

namespace DFM.App_Code.DAL
{
    /// <summary>
    /// Operations for the unified workflow screen introduced in Req3.
    /// </summary>
    public static class WorkflowDAL
    {
        // ===== Project workflow stages =====
        public static void SetStage(int projectId, string column, string status)
        {
            // Whitelist column names
            string col;
            switch (column)
            {
                case "CapexStageStatus":  col = "CapexStageStatus";  break;
                case "PetStageStatus":    col = "PetStageStatus";    break;
                case "PetApprovalStatus": col = "PetApprovalStatus"; break;
                case "BpmStageStatus":    col = "BpmStageStatus";    break;
                default: return;
            }
            Db.Exec("UPDATE Projects SET " + col + "=@s, ModifiedDate=GETDATE() WHERE ProjectID=@id",
                Db.P("@s", status ?? ""), Db.P("@id", projectId));
        }

        public static void SetCurrentStage(int projectId, string stage)
        {
            Db.Exec("UPDATE Projects SET CurrentStage=@s, ModifiedDate=GETDATE() WHERE ProjectID=@id",
                Db.P("@s", stage ?? ""), Db.P("@id", projectId));
        }

        // ===== PET approval (Req 14-19) =====
        public static void ApprovePet(int projectId, decimal approvedAmount, string approver, string comments)
        {
            DataRow prj = ProjectsDAL.GetProject(projectId);
            if (prj == null) return;

            string ptype = prj["ProjectType"].ToString();
            string srcId = prj["BudgetSourceID"] == DBNull.Value ? "" : prj["BudgetSourceID"].ToString();
            int version = prj["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prj["Version"]);

            Db.Exec(@"UPDATE Projects
                      SET PetApprovedAmount=@a, LockedAmount=@a,
                          PetApprovalStatus='Approved', PetStageStatus='Approved',
                          CurrentStage='BPM',
                          ApprovedDate=GETDATE(), ModifiedBy=@u, ModifiedDate=GETDATE()
                      WHERE ProjectID=@id",
                Db.P("@id", projectId), Db.P("@a", approvedAmount), Db.P("@u", approver));

            // Sync PetSubmissions: close out any pending submission for this project
            Db.Exec(@"UPDATE PetSubmissions
                      SET Status='Approved', ApprovedBy=@u, ApprovedDate=GETDATE(), ApprovedAmount=@a
                      WHERE ProjectID=@id AND Status='Pending'",
                Db.P("@id", projectId), Db.P("@a", approvedAmount), Db.P("@u", approver));

            ProjectsDAL.AddWorkflow(projectId, "PET Approved", null, approver, comments, version);

            Db.Exec(@"INSERT INTO LockedAmountHistory(ProjectID, SourceType, SourceID, Amount, Action, ActionBy)
                      VALUES(@id, @st, @src, @a, 'Locked', @u)",
                Db.P("@id", projectId), Db.P("@st", ptype), Db.P("@src", srcId),
                Db.P("@a", approvedAmount), Db.P("@u", approver));

            string masterTbl = ptype == "OPEX" ? "OpexMaster" : ptype == "AMC" ? "AmcMaster" : "CapexMaster";
            string keyCol    = ptype == "OPEX" ? "OpexID"     : ptype == "AMC" ? "AmcID"     : "CapexID";

            // Capture prev values for CapexHistory audit
            DataRow before = Db.QueryRow(string.Format(
                "SELECT Budget, Utilization, LockedAmount FROM {0} WHERE {1}=@src", masterTbl, keyCol),
                Db.P("@src", srcId));

            decimal prevLocked = before != null && before["LockedAmount"] != DBNull.Value
                ? Convert.ToDecimal(before["LockedAmount"]) : 0m;
            decimal prevBudget = before != null && before["Budget"] != DBNull.Value
                ? Convert.ToDecimal(before["Budget"]) : 0m;
            decimal prevUtil   = before != null && before["Utilization"] != DBNull.Value
                ? Convert.ToDecimal(before["Utilization"]) : 0m;

            Db.Exec(string.Format(@"
UPDATE {0}
SET LockedAmount = ISNULL(LockedAmount,0) + @a,
    BudgetAfterLockedAmount = ISNULL(Budget,0) - (ISNULL(LockedAmount,0) + @a),
    NetBalance = ISNULL(Budget,0) - ISNULL(Utilization,0) - (ISNULL(LockedAmount,0) + @a),
    ModifiedDate = GETDATE(), ModifiedBy = @u
WHERE {1}=@src", masterTbl, keyCol),
                Db.P("@a", approvedAmount), Db.P("@u", approver), Db.P("@src", srcId));

            Db.Exec(@"INSERT INTO CapexHistory(SourceType, SourceID, ProjectID, Action, Amount,
                        PrevBudget, NewBudget, PrevUtil, NewUtil, PrevLocked, NewLocked, Notes, ActionBy)
                      VALUES(@st, @src, @id, 'Locked', @a, @pb, @pb, @pu, @pu, @pl, @nl, @n, @u)",
                Db.P("@st", ptype), Db.P("@src", srcId), Db.P("@id", projectId),
                Db.P("@a", approvedAmount),
                Db.P("@pb", prevBudget), Db.P("@pu", prevUtil),
                Db.P("@pl", prevLocked), Db.P("@nl", prevLocked + approvedAmount),
                Db.P("@n", "PET approval lock"), Db.P("@u", approver));

            NotificationsDAL.Send(prj["CreatedBy"].ToString(),
                "PET Approved",
                "Your PET for " + prj["ProjectName"] + " has been approved (amount " + approvedAmount.ToString("N2") + ").",
                "~/Forms/Workflow.aspx?id=" + projectId, projectId, "PETApproved");
        }

        public static void RejectPet(int projectId, string approver, string comments)
        {
            DataRow prj = ProjectsDAL.GetProject(projectId);
            if (prj == null) return;
            int version = prj["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prj["Version"]);

            // Rejection rolls back to "Project Identity & Budget Source" stage
            Db.Exec(@"UPDATE Projects
                      SET PetApprovalStatus='Rejected', PetStageStatus='Rejected',
                          CurrentStage='Registration',
                          ModifiedBy=@u, ModifiedDate=GETDATE()
                      WHERE ProjectID=@id",
                Db.P("@id", projectId), Db.P("@u", approver));

            // Sync PetSubmissions: close out any pending submission for this project
            Db.Exec(@"UPDATE PetSubmissions
                      SET Status='Rejected', ApprovedBy=@u, ApprovedDate=GETDATE()
                      WHERE ProjectID=@id AND Status='Pending'",
                Db.P("@id", projectId), Db.P("@u", approver));

            ProjectsDAL.AddWorkflow(projectId, "PET Rejected", null, approver, comments, version);

            // Req 17: requestor notification
            NotificationsDAL.Send(prj["CreatedBy"].ToString(),
                "PET Rejected",
                "Your PET for " + prj["ProjectName"] + " was rejected. " + (comments ?? ""),
                "~/Forms/Workflow.aspx?id=" + projectId, projectId, "PETRejected");
        }

        // ===== BPM (Req 19-20) =====
        public static void SubmitBpm(int projectId, string user, string comments)
        {
            DataRow prj = ProjectsDAL.GetProject(projectId);
            if (prj == null) return;
            int version = prj["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prj["Version"]);
            Db.Exec(@"UPDATE Projects SET BpmStageStatus='Submitted', CurrentStage='BPM',
                      ModifiedBy=@u, ModifiedDate=GETDATE() WHERE ProjectID=@id",
                Db.P("@id", projectId), Db.P("@u", user));
            ProjectsDAL.AddWorkflow(projectId, "BPM Submitted", null, user, comments, version);
        }

        public static void CloseBpm(int projectId, string user, string comments)
        {
            DataRow prj = ProjectsDAL.GetProject(projectId);
            if (prj == null) return;
            int version = prj["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prj["Version"]);
            decimal approved = prj["PetApprovedAmount"] == DBNull.Value
                ? 0m : Convert.ToDecimal(prj["PetApprovedAmount"]);
            string ptype = prj["ProjectType"].ToString();
            string srcId = prj["BudgetSourceID"] == DBNull.Value ? "" : prj["BudgetSourceID"].ToString();

            Db.Exec(@"UPDATE Projects SET BpmStageStatus='Closed', Status='Approved',
                      CurrentStage='Closed', DebitedAmount=@a,
                      ModifiedBy=@u, ModifiedDate=GETDATE() WHERE ProjectID=@id",
                Db.P("@id", projectId), Db.P("@a", approved), Db.P("@u", user));

            ProjectsDAL.AddWorkflow(projectId, "BPM Closed", null, user, comments, version);

            // Convert lock to actual utilization (debit)
            Db.Exec(@"INSERT INTO DebitedAmountHistory(ProjectID, SourceType, SourceID, Amount, ActionBy)
                      VALUES(@id, @st, @src, @a, @u)",
                Db.P("@id", projectId), Db.P("@st", ptype), Db.P("@src", srcId),
                Db.P("@a", approved), Db.P("@u", user));

            string masterTbl = ptype == "OPEX" ? "OpexMaster" : ptype == "AMC" ? "AmcMaster" : "CapexMaster";
            string keyCol    = ptype == "OPEX" ? "OpexID"     : ptype == "AMC" ? "AmcID"     : "CapexID";

            Db.Exec(string.Format(@"
UPDATE {0}
SET Utilization = ISNULL(Utilization,0) + @a,
    LockedAmount = CASE WHEN ISNULL(LockedAmount,0) >= @a THEN ISNULL(LockedAmount,0) - @a ELSE 0 END,
    ClaimAmount = ISNULL(ClaimAmount,0) + @a,
    AvailableBudget = ISNULL(Budget,0) - (ISNULL(Utilization,0) + @a),
    BudgetAfterLockedAmount = ISNULL(Budget,0) - CASE WHEN ISNULL(LockedAmount,0) >= @a THEN ISNULL(LockedAmount,0) - @a ELSE 0 END,
    NetBalance = ISNULL(Budget,0) - (ISNULL(Utilization,0) + @a) - CASE WHEN ISNULL(LockedAmount,0) >= @a THEN ISNULL(LockedAmount,0) - @a ELSE 0 END,
    ModifiedDate = GETDATE(), ModifiedBy = @u
WHERE {1}=@src", masterTbl, keyCol),
                Db.P("@a", approved), Db.P("@u", user), Db.P("@src", srcId));

            Db.Exec(@"INSERT INTO CapexHistory(SourceType, SourceID, ProjectID, Action, Amount, Notes, ActionBy)
                      VALUES(@st, @src, @id, 'Utilized', @a, 'BPM closed - lock converted to debit', @u)",
                Db.P("@st", ptype), Db.P("@src", srcId), Db.P("@id", projectId),
                Db.P("@a", approved), Db.P("@u", user));
        }

        // ===== Workflow History (Req 23-26, 45-46) =====
        public static DataTable GetSourceHistory(string sourceType, string sourceId)
        {
            return Db.Query(@"
SELECT ch.HistoryID, ch.SourceType, ch.SourceID, ch.ProjectID, p.ProjectCode,
       p.ProjectName, p.JiraID,
       ch.Action, ch.Amount, ch.PrevLocked, ch.NewLocked, ch.PrevUtil, ch.NewUtil,
       ch.Notes, ch.ActionBy, ch.ActionDate
FROM CapexHistory ch
LEFT JOIN Projects p ON ch.ProjectID = p.ProjectID
WHERE ch.SourceType=@t AND ch.SourceID=@s
ORDER BY ch.ActionDate DESC",
                Db.P("@t", sourceType), Db.P("@s", sourceId));
        }

        // ===== AI audit log =====
        public static void LogAiCall(string user, string prompt, int responseLen, int? projectId)
        {
            try
            {
                Db.Exec(@"INSERT INTO AI_Audit_Log(UserName, Prompt, ResponseLen, ProjectID)
                          VALUES(@u, @p, @r, @pid)",
                    Db.P("@u", user), Db.P("@p", prompt ?? ""),
                    Db.P("@r", responseLen),
                    Db.P("@pid", projectId.HasValue ? (object)projectId.Value : DBNull.Value));
            }
            catch { }
        }

        // ===== PET Guidance (Req 43) =====
        public static DataTable GetPetGuidance()
        {
            try { return Db.Query("SELECT * FROM PetGuidance"); }
            catch { return new DataTable(); }
        }

        public static void UpsertGuidance(string fieldName, string guidance)
        {
            Db.Exec(@"
IF EXISTS(SELECT 1 FROM PetGuidance WHERE FieldName=@f)
    UPDATE PetGuidance SET Guidance=@g, UpdatedDate=GETDATE() WHERE FieldName=@f
ELSE
    INSERT INTO PetGuidance(FieldName, Guidance) VALUES(@f, @g);",
                Db.P("@f", fieldName), Db.P("@g", guidance));
        }
    }
}
