using System.Data;

namespace DFM.App_Code.DAL
{
    public static class RolesDAL
    {
        public static DataTable GetUserRoles(string username)
        {
            return Db.Query("SELECT * FROM UserRoleAssignments WHERE Username=@u ORDER BY RoleType",
                Db.P("@u", username));
        }

        public static bool HasRole(string username, string roleType)
        {
            object o = Db.Scalar(@"SELECT COUNT(*) FROM UserRoleAssignments
                                   WHERE Username=@u AND RoleType=@r",
                Db.P("@u", username), Db.P("@r", roleType));
            return System.Convert.ToInt32(o) > 0;
        }

        public static void AddRole(string username, string roleType, string by)
        {
            Db.Exec(@"
IF NOT EXISTS (SELECT 1 FROM UserRoleAssignments WHERE Username=@u AND RoleType=@r)
    INSERT INTO UserRoleAssignments(Username, RoleType, CreatedBy) VALUES(@u, @r, @by);",
                Db.P("@u", username), Db.P("@r", roleType), Db.P("@by", by));
        }

        public static void RemoveRole(string username, string roleType)
        {
            Db.Exec("DELETE FROM UserRoleAssignments WHERE Username=@u AND RoleType=@r",
                Db.P("@u", username), Db.P("@r", roleType));
        }

        public static DataTable GetAllAssignments()
        {
            return Db.Query(@"SELECT u.Username, u.FullName, u.Email,
                                 MAX(CASE WHEN a.RoleType='Requestor' THEN 1 ELSE 0 END) AS IsRequestor,
                                 MAX(CASE WHEN a.RoleType='Approver'  THEN 1 ELSE 0 END) AS IsApprover
                              FROM AppUsers u
                              LEFT JOIN UserRoleAssignments a ON u.Username = a.Username
                              GROUP BY u.Username, u.FullName, u.Email
                              ORDER BY u.Username");
        }
    }
}
