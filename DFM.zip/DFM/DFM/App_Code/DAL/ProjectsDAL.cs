using System;
using System.Data;
using System.Data.SqlClient;

namespace DFM.App_Code.DAL
{
    public static class ProjectsDAL
    {
        public static DataTable GetProjects(string projectType = null, string status = null)
        {
            string sql = @"SELECT p.*, a.ApproverName
                           FROM Projects p
                           LEFT JOIN ApproverMaster a ON p.ApproverID = a.ApproverID
                           WHERE 1=1";
            if (!string.IsNullOrEmpty(projectType) && projectType != "ALL") sql += " AND p.ProjectType=@pt";
            if (!string.IsNullOrEmpty(status) && status != "ALL") sql += " AND p.Status=@st";
            sql += " ORDER BY p.ProjectID DESC";

            System.Collections.Generic.List<SqlParameter> ps = new System.Collections.Generic.List<SqlParameter>();
            if (!string.IsNullOrEmpty(projectType) && projectType != "ALL") ps.Add(Db.P("@pt", projectType));
            if (!string.IsNullOrEmpty(status) && status != "ALL") ps.Add(Db.P("@st", status));
            return Db.Query(sql, ps.ToArray());
        }

        public static DataRow GetProject(int projectId)
        {
            return Db.QueryRow(@"SELECT p.*, a.ApproverName, a.Email AS ApproverEmail
                          FROM Projects p
                          LEFT JOIN ApproverMaster a ON p.ApproverID = a.ApproverID
                          WHERE p.ProjectID=@id", Db.P("@id", projectId));
        }

        public static int CreateProject(string jiraId, string projectName, string projectType,
            string budgetSourceId, decimal requestedAmount, int approverId, string baseline,
            string comments, string user, string status = "Draft")
        {
            object id = Db.Scalar(@"
INSERT INTO Projects(JiraID, ProjectName, ProjectType, BudgetSourceID, RequestedAmount, ApproverID,
    Status, BaselinePlan, Comments, Version, CreatedBy, SubmittedDate)
VALUES(@jira, @name, @ptype, @src, @amt, @app, @status, @plan, @cmt, 1, @user,
       CASE WHEN @status='Pending' THEN GETDATE() ELSE NULL END);
SELECT SCOPE_IDENTITY();",
                Db.P("@jira", jiraId), Db.P("@name", projectName), Db.P("@ptype", projectType),
                Db.P("@src", budgetSourceId), Db.P("@amt", requestedAmount), Db.P("@app", approverId),
                Db.P("@status", status), Db.P("@plan", baseline), Db.P("@cmt", comments),
                Db.P("@user", user));
            return Convert.ToInt32(id);
        }

        public static void UpdateProject(int projectId, string projectName, string budgetSourceId,
            decimal requestedAmount, int approverId, string baseline, string comments, string user)
        {
            Db.Exec(@"UPDATE Projects
                      SET ProjectName=@n, BudgetSourceID=@src, RequestedAmount=@a,
                          ApproverID=@app, BaselinePlan=@p, Comments=@c,
                          Version = Version + 1,
                          ModifiedBy=@user, ModifiedDate=GETDATE()
                      WHERE ProjectID=@id",
                Db.P("@id", projectId), Db.P("@n", projectName), Db.P("@src", budgetSourceId),
                Db.P("@a", requestedAmount), Db.P("@app", approverId),
                Db.P("@p", baseline), Db.P("@c", comments), Db.P("@user", user));
        }

        public static void SubmitProject(int projectId, string user)
        {
            Db.Exec(@"UPDATE Projects SET Status='Pending', SubmittedDate=GETDATE(),
                      ModifiedBy=@u, ModifiedDate=GETDATE() WHERE ProjectID=@id",
                Db.P("@id", projectId), Db.P("@u", user));
        }

        public static void AddWorkflow(int projectId, string stage, object approvalLevel,
            string actionBy, string comments, int version)
        {
            Db.Exec(@"INSERT INTO WorkflowHistory(ProjectID, Stage, ApprovalLevel, ActionBy, Comments, Version)
                      VALUES(@id, @s, @lvl, @u, @c, @v)",
                Db.P("@id", projectId), Db.P("@s", stage),
                Db.P("@lvl", approvalLevel == null ? (object)DBNull.Value : approvalLevel),
                Db.P("@u", actionBy), Db.P("@c", comments), Db.P("@v", version));
        }

        public static DataTable GetWorkflowHistory(int projectId)
        {
            return Db.Query("SELECT * FROM WorkflowHistory WHERE ProjectID=@id ORDER BY ActionDate ASC",
                Db.P("@id", projectId));
        }

        public static DataTable GetVersionHistory(int projectId)
        {
            return Db.Query("SELECT * FROM ProjectVersionHistory WHERE ProjectID=@id ORDER BY ChangedDate DESC",
                Db.P("@id", projectId));
        }

        public static void AddVersionSnapshot(int projectId, int version, string snapshotJson,
            string changedBy, string notes)
        {
            Db.Exec(@"INSERT INTO ProjectVersionHistory(ProjectID, Version, SnapshotJson, ChangedBy, ChangeNotes)
                      VALUES(@id, @v, @j, @u, @n)",
                Db.P("@id", projectId), Db.P("@v", version), Db.P("@j", snapshotJson),
                Db.P("@u", changedBy), Db.P("@n", notes));
        }

        public static DataTable GetComments(int projectId)
        {
            return Db.Query("SELECT * FROM ProjectComments WHERE ProjectID=@id ORDER BY CommentedDate DESC",
                Db.P("@id", projectId));
        }

        public static void AddComment(int projectId, string text, string user)
        {
            Db.Exec("INSERT INTO ProjectComments(ProjectID, CommentText, CommentedBy) VALUES(@id, @t, @u)",
                Db.P("@id", projectId), Db.P("@t", text), Db.P("@u", user));
        }

        public static void Approve(int projectId, string approver, string comments)
        {
            DataRow prj = GetProject(projectId);
            if (prj == null) return;
            decimal amt = prj["RequestedAmount"] == DBNull.Value ? 0m : Convert.ToDecimal(prj["RequestedAmount"]);
            string ptype = prj["ProjectType"].ToString();
            string srcId = prj["BudgetSourceID"] == DBNull.Value ? "" : prj["BudgetSourceID"].ToString();
            int version = prj["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prj["Version"]);

            Db.Exec(@"UPDATE Projects SET Status='Approved', LockedAmount=@a, DebitedAmount=@a,
                      ApprovedDate=GETDATE(), ModifiedBy=@u, ModifiedDate=GETDATE()
                      WHERE ProjectID=@id",
                Db.P("@id", projectId), Db.P("@a", amt), Db.P("@u", approver));

            AddWorkflow(projectId, "Approved", null, approver, comments, version);
            Db.Exec(@"INSERT INTO LockedAmountHistory(ProjectID, SourceType, SourceID, Amount, Action, ActionBy)
                      VALUES(@id, @st, @src, @a, 'Locked', @u)",
                Db.P("@id", projectId), Db.P("@st", ptype), Db.P("@src", srcId),
                Db.P("@a", amt), Db.P("@u", approver));
            Db.Exec(@"INSERT INTO DebitedAmountHistory(ProjectID, SourceType, SourceID, Amount, ActionBy)
                      VALUES(@id, @st, @src, @a, @u)",
                Db.P("@id", projectId), Db.P("@st", ptype), Db.P("@src", srcId),
                Db.P("@a", amt), Db.P("@u", approver));

            string masterTbl = ptype == "OPEX" ? "OpexMaster" : ptype == "AMC" ? "AmcMaster" : "CapexMaster";
            string keyCol  = ptype == "OPEX" ? "OpexID"     : ptype == "AMC" ? "AmcID"     : "CapexID";

            Db.Exec(string.Format(@"
UPDATE {0}
SET LockedAmount = ISNULL(LockedAmount,0) + @a,
    Utilization  = ISNULL(Utilization,0) + @a,
    AvailableBudget = ISNULL(Budget,0) - (ISNULL(Utilization,0) + @a),
    BudgetAfterLockedAmount = ISNULL(Budget,0) - (ISNULL(LockedAmount,0) + @a),
    NetBalance = ISNULL(Budget,0) - (ISNULL(Utilization,0) + @a) - (ISNULL(LockedAmount,0) + @a),
    ModifiedDate = GETDATE(), ModifiedBy = @u
WHERE {1}=@src", masterTbl, keyCol),
                Db.P("@a", amt), Db.P("@u", approver), Db.P("@src", srcId));
        }

        public static void Reject(int projectId, string approver, string comments)
        {
            DataRow prj = GetProject(projectId);
            if (prj == null) return;
            int version = prj["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prj["Version"]);
            Db.Exec(@"UPDATE Projects SET Status='Rejected', ModifiedBy=@u, ModifiedDate=GETDATE()
                      WHERE ProjectID=@id",
                Db.P("@id", projectId), Db.P("@u", approver));
            AddWorkflow(projectId, "Rejected", null, approver, comments, version);
        }

        public static DataRow GetDashboardSummary()
        {
            return Db.QueryRow(@"
SELECT
  (SELECT COUNT(*) FROM Projects)                                          AS TotalProjects,
  (SELECT COUNT(*) FROM Projects WHERE Status='Pending')                   AS PendingApproval,
  (SELECT COUNT(*) FROM Projects WHERE Status='Approved')                  AS Approved,
  (SELECT COUNT(*) FROM Projects WHERE Status='Rejected')                  AS Rejected,
  (SELECT COUNT(*) FROM Projects WHERE ProjectType='CAPEX')                AS CapexCount,
  (SELECT COUNT(*) FROM Projects WHERE ProjectType='OPEX')                 AS OpexCount,
  (SELECT COUNT(*) FROM Projects WHERE ProjectType='AMC')                  AS AmcCount,
  (SELECT ISNULL(SUM(Budget),0)          FROM CapexMaster)                  AS TotalCapexBudget,
  (SELECT ISNULL(SUM(Budget),0)          FROM OpexMaster)                   AS TotalOpexBudget,
  (SELECT ISNULL(SUM(Utilization),0)     FROM CapexMaster) +
  (SELECT ISNULL(SUM(Utilization),0)     FROM OpexMaster) +
  (SELECT ISNULL(SUM(Utilization),0)     FROM AmcMaster)                    AS TotalUtilized,
  (SELECT ISNULL(SUM(AvailableBudget),0) FROM CapexMaster) +
  (SELECT ISNULL(SUM(AvailableBudget),0) FROM OpexMaster) +
  (SELECT ISNULL(SUM(AvailableBudget),0) FROM AmcMaster)                    AS TotalAvailable,
  (SELECT ISNULL(SUM(LockedAmount),0)    FROM CapexMaster) +
  (SELECT ISNULL(SUM(LockedAmount),0)    FROM OpexMaster) +
  (SELECT ISNULL(SUM(LockedAmount),0)    FROM AmcMaster)                    AS TotalLocked");
        }

        public static DataTable GetRecentProjects(int top = 10)
        {
            return Db.Query(string.Format(@"
SELECT TOP {0} p.ProjectID, p.ProjectCode, p.ProjectName, p.ProjectType, p.Status,
       p.RequestedAmount, p.ModifiedDate, p.CreatedDate, p.JiraID, a.ApproverName
FROM Projects p LEFT JOIN ApproverMaster a ON p.ApproverID=a.ApproverID
ORDER BY ISNULL(p.ModifiedDate, p.CreatedDate) DESC", top));
        }

        // Returns flat dataset for building the project tree view.
        // Row types distinguished by RowType column: Project / PET / Memo / Invoice
        public static DataSet GetProjectTreeData(string projectType = null, string status = null,
            string requestedBy = null, DateTime? fromDate = null, DateTime? toDate = null)
        {
            var ps = new System.Collections.Generic.List<System.Data.SqlClient.SqlParameter>();
            string filter = " WHERE 1=1";
            if (!string.IsNullOrEmpty(projectType) && projectType != "ALL") { filter += " AND p.ProjectType=@pt"; ps.Add(Db.P("@pt", projectType)); }
            if (!string.IsNullOrEmpty(status) && status != "ALL") { filter += " AND p.Status=@st"; ps.Add(Db.P("@st", status)); }
            if (!string.IsNullOrEmpty(requestedBy) && requestedBy != "ALL") { filter += " AND p.CreatedBy=@rb"; ps.Add(Db.P("@rb", requestedBy)); }
            if (fromDate.HasValue) { filter += " AND p.CreatedDate >= @fd"; ps.Add(Db.P("@fd", fromDate.Value)); }
            if (toDate.HasValue) { filter += " AND p.CreatedDate <= @td"; ps.Add(Db.P("@td", toDate.Value.AddDays(1).AddSeconds(-1))); }

            DataSet ds = new DataSet();

            // Projects
            ds.Tables.Add(Db.Query(@"
SELECT p.ProjectID, ISNULL(p.JiraID, p.ProjectCode) AS ProjectCode,
       p.ProjectName, p.ProjectType, p.Status, p.CurrentStage,
       ISNULL(p.RequestedAmount,0) AS RequestedAmount, p.CreatedBy, p.CreatedDate,
       p.PetApprovalStatus, p.BpmStageStatus, ISNULL(a.ApproverName,'') AS ApproverName
FROM Projects p LEFT JOIN ApproverMaster a ON p.ApproverID=a.ApproverID" + filter + " ORDER BY p.ProjectID DESC", ps.ToArray()));
            ds.Tables[0].TableName = "Projects";

            if (ds.Tables[0].Rows.Count == 0) return ds;

            // PET totals per project
            ds.Tables.Add(Db.Query(@"
SELECT pf.ProjectID,
       COUNT(*) AS LineCount,
       ISNULL(SUM(pf.FinalAmtLCY),0) AS TotalAED,
       p.PetApprovalStatus
FROM PetForm pf
INNER JOIN Projects p ON p.ProjectID=pf.ProjectID
GROUP BY pf.ProjectID, p.PetApprovalStatus"));
            ds.Tables[1].TableName = "PETTotals";

            // Memos + vendor
            ds.Tables.Add(Db.Query(@"
SELECT m.MemoID, m.ProjectID, m.MemoNumber, ISNULL(m.ApprovedAmountAED,0) AS ApprovedAmountAED,
       ISNULL(v.VendorName, '') AS VendorName, ISNULL(m.LPO_SO_Number,'') AS LPO_SO_Number,
       m.DateRaised, ISNULL(m.CAMStatus,'Open') AS CAMStatus,
       ISNULL(m.AmountDisbursed,0) AS AmountDisbursed
FROM CapexMemos m
LEFT JOIN VendorMaster v ON m.VendorID=v.VendorID
ORDER BY m.ProjectID, m.MemoID"));
            ds.Tables[2].TableName = "Memos";

            // Invoices
            ds.Tables.Add(Db.Query(@"
SELECT i.InvoiceID, i.MemoID, ISNULL(i.InvoiceNumber,'') AS InvoiceNumber,
       ISNULL(i.InvoiceAmountAED,0) AS InvoiceAmountAED,
       i.InvoiceDate, ISNULL(i.InvoiceStatus,'Pending') AS InvoiceStatus
FROM MemoInvoices i
ORDER BY i.MemoID, i.InvoiceID"));
            ds.Tables[3].TableName = "Invoices";

            return ds;
        }

        public static DataTable GetBudgetSourceCards()
        {
            return Db.Query(@"
SELECT 'CAPEX' AS BudgetType, CapexID AS SourceID, CapexID AS SourceCode,
       ISNULL(Description,'') AS Description, ISNULL(Budget,0) AS Budget,
       ISNULL(Utilization,0) AS Utilization,
       ISNULL(AvailableBudget,0) AS AvailableBudget,
       ISNULL(LockedAmount,0) AS LockedAmount
FROM CapexMaster WHERE ISNULL(IsActive,1)=1
UNION ALL
SELECT 'OPEX', OpexID, OpexID, ISNULL(Description,''), ISNULL(Budget,0),
       ISNULL(Utilization,0), ISNULL(AvailableBudget,0), ISNULL(LockedAmount,0)
FROM OpexMaster WHERE ISNULL(IsActive,1)=1
ORDER BY BudgetType, SourceCode");
        }
    }
}
