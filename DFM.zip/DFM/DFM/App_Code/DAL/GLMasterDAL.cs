using System;
using System.Data;

namespace DFM.App_Code.DAL
{
    public static class GLMasterDAL
    {
        public static DataTable GetAll(bool activeOnly = true)
        {
            string sql = activeOnly
                ? "SELECT * FROM GLMaster WHERE IsActive=1 ORDER BY GLCode"
                : "SELECT * FROM GLMaster ORDER BY GLCode";
            return Db.Query(sql);
        }

        public static DataRow GetById(int id)
        {
            return Db.QueryRow("SELECT * FROM GLMaster WHERE GLID=@id", Db.P("@id", id));
        }

        public static void Upsert(int id, string code, string desc, bool active)
        {
            if (id > 0)
                Db.Exec(@"UPDATE GLMaster SET GLCode=@c, Description=@d, IsActive=@a, ModifiedDate=GETDATE()
                          WHERE GLID=@id",
                    Db.P("@id", id), Db.P("@c", code), Db.P("@d", desc), Db.P("@a", active));
            else
                Db.Exec("INSERT INTO GLMaster(GLCode, Description, IsActive) VALUES(@c, @d, @a)",
                    Db.P("@c", code), Db.P("@d", desc), Db.P("@a", active));
        }

        public static void Delete(int id)
        {
            Db.Exec("DELETE FROM GLMaster WHERE GLID=@id", Db.P("@id", id));
        }
    }
}
