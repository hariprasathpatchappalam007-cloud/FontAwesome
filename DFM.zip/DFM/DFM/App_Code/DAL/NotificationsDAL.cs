using System.Data;

namespace DFM.App_Code.DAL
{
    public static class NotificationsDAL
    {
        public static DataTable GetForUser(string user, int top)
        {
            return Db.Query(string.Format(@"
SELECT TOP {0} NotificationID, Recipient, Subject, Message, LinkUrl, IsRead, CreatedDate, ProjectID, NotifType
FROM Notifications WHERE Recipient=@u ORDER BY CreatedDate DESC", top),
                Db.P("@u", user));
        }

        public static void Send(string recipient, string subject, string message,
            string linkUrl, int? projectId, string notifType)
        {
            Db.Exec(@"INSERT INTO Notifications(Recipient, Subject, Message, LinkUrl, ProjectID, NotifType)
                      VALUES(@r, @s, @m, @l, @p, @t)",
                Db.P("@r", recipient),
                Db.P("@s", subject),
                Db.P("@m", message == null ? "" : message),
                Db.P("@l", linkUrl == null ? "" : linkUrl),
                Db.P("@p", projectId.HasValue ? (object)projectId.Value : System.DBNull.Value),
                Db.P("@t", notifType == null ? "" : notifType));
        }

        public static void MarkRead(int notificationId)
        {
            Db.Exec("UPDATE Notifications SET IsRead=1 WHERE NotificationID=@id",
                Db.P("@id", notificationId));
        }

        public static void MarkAllRead(string user)
        {
            Db.Exec("UPDATE Notifications SET IsRead=1 WHERE Recipient=@u AND IsRead=0",
                Db.P("@u", user));
        }
    }
}
