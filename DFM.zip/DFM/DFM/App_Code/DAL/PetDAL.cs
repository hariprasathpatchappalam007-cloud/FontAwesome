using System;
using System.Data;

namespace DFM.App_Code.DAL
{
    public static class PetDAL
    {
        // ===== PET Cost Type =====
        public static DataTable GetCostTypes()
        {
            return Db.Query("SELECT * FROM PetCostType WHERE IsActive=1 ORDER BY SortOrder, Category");
        }

        public static void UpsertCostType(int id, int order, string category, bool active)
        {
            if (id > 0)
                Db.Exec("UPDATE PetCostType SET SortOrder=@o, Category=@c, IsActive=@a WHERE CostTypeID=@id",
                    Db.P("@id", id), Db.P("@o", order), Db.P("@c", category), Db.P("@a", active));
            else
                Db.Exec("INSERT INTO PetCostType(SortOrder, Category, IsActive) VALUES(@o, @c, @a)",
                    Db.P("@o", order), Db.P("@c", category), Db.P("@a", active));
        }

        public static void DeleteCostType(int id)
        {
            Db.Exec("DELETE FROM PetCostType WHERE CostTypeID=@id", Db.P("@id", id));
        }

        // ===== PET Department =====
        public static DataTable GetDepartments()
        {
            return Db.Query("SELECT * FROM PetDepartment WHERE IsActive=1 ORDER BY Department");
        }

        public static DataRow GetDepartment(string department)
        {
            return Db.QueryRow("SELECT * FROM PetDepartment WHERE Department=@d",
                Db.P("@d", department));
        }

        public static void UpsertDepartment(int id, string dept, string prefix, bool active)
        {
            if (id > 0)
                Db.Exec("UPDATE PetDepartment SET Department=@d, Prefix=@p, IsActive=@a WHERE DepartmentID=@id",
                    Db.P("@id", id), Db.P("@d", dept), Db.P("@p", prefix), Db.P("@a", active));
            else
                Db.Exec("INSERT INTO PetDepartment(Department, Prefix, IsActive) VALUES(@d, @p, @a)",
                    Db.P("@d", dept), Db.P("@p", prefix), Db.P("@a", active));
        }

        public static void DeleteDepartment(int id)
        {
            Db.Exec("DELETE FROM PetDepartment WHERE DepartmentID=@id", Db.P("@id", id));
        }

        // ===== PET Currency =====
        public static DataTable GetCurrencies()
        {
            return Db.Query("SELECT * FROM PetCurrency WHERE IsActive=1 ORDER BY Code");
        }

        public static decimal GetRate(string code)
        {
            object o = Db.Scalar("SELECT TOP 1 RateToLocal FROM PetCurrency WHERE Code=@c AND IsActive=1",
                Db.P("@c", code));
            if (o == null || o == DBNull.Value) return 1m;
            return Convert.ToDecimal(o);
        }

        public static void UpsertCurrency(int id, string code, string name, decimal rate, bool active)
        {
            if (id > 0)
                Db.Exec("UPDATE PetCurrency SET Code=@c, Name=@n, RateToLocal=@r, IsActive=@a WHERE CurrencyID=@id",
                    Db.P("@id", id), Db.P("@c", code), Db.P("@n", name), Db.P("@r", rate), Db.P("@a", active));
            else
                Db.Exec("INSERT INTO PetCurrency(Code, Name, RateToLocal, IsActive) VALUES(@c, @n, @r, @a)",
                    Db.P("@c", code), Db.P("@n", name), Db.P("@r", rate), Db.P("@a", active));
        }

        public static void DeleteCurrency(int id)
        {
            Db.Exec("DELETE FROM PetCurrency WHERE CurrencyID=@id", Db.P("@id", id));
        }

        // ===== PET Form line items =====
        public static DataTable GetByProject(int projectId)
        {
            return Db.Query("SELECT * FROM PetForm WHERE ProjectID=@id ORDER BY SerialNo",
                Db.P("@id", projectId));
        }

        public static int Add(int projectId, string department, string lineCode, string expHead,
            string topic, string vendor, string description, string costType, string unitType,
            decimal units, decimal unitPrice, string baseCcy, decimal amtFcy, decimal amtLcy,
            decimal contingencyPct, decimal finalAmtLcy, int yearlyRecurrence, string comments, string user)
        {
            int next = Convert.ToInt32(Db.Scalar(
                "SELECT ISNULL(MAX(SerialNo),0)+1 FROM PetForm WHERE ProjectID=@id", Db.P("@id", projectId)));
            object id = Db.Scalar(@"
INSERT INTO PetForm(ProjectID, SerialNo, Department, LineCode, ExpHead, Topic, Vendor, Description,
    CostType, UnitType, Units, UnitPrice, BaseCurrency, AmtFCY, AmtLCY, ContingencyPct,
    FinalAmtLCY, YearlyRecurrence, Comments, CreatedBy)
VALUES(@p, @sn, @dep, @lc, @eh, @tp, @vn, @ds, @ct, @ut, @u, @up, @bc, @af, @al, @cp, @fa, @yr, @cm, @user);
SELECT SCOPE_IDENTITY();",
                Db.P("@p", projectId), Db.P("@sn", next), Db.P("@dep", department),
                Db.P("@lc", lineCode), Db.P("@eh", expHead), Db.P("@tp", topic),
                Db.P("@vn", vendor), Db.P("@ds", description), Db.P("@ct", costType),
                Db.P("@ut", unitType), Db.P("@u", units), Db.P("@up", unitPrice),
                Db.P("@bc", baseCcy), Db.P("@af", amtFcy), Db.P("@al", amtLcy),
                Db.P("@cp", contingencyPct), Db.P("@fa", finalAmtLcy),
                Db.P("@yr", yearlyRecurrence), Db.P("@cm", comments), Db.P("@user", user));
            return Convert.ToInt32(id);
        }

        public static void Delete(int petId)
        {
            Db.Exec("DELETE FROM PetForm WHERE PetID=@id", Db.P("@id", petId));
        }

        public static decimal GetTotalForProject(int projectId)
        {
            object o = Db.Scalar("SELECT ISNULL(SUM(FinalAmtLCY),0) FROM PetForm WHERE ProjectID=@id",
                Db.P("@id", projectId));
            return Convert.ToDecimal(o);
        }

        // ===== Auto-generate the next line code per department =====
        public static string NextLineCode(string department)
        {
            DataRow d = GetDepartment(department);
            if (d == null) return department + " - 1";
            string prefix = d["Prefix"].ToString();
            object o = Db.Scalar(@"
SELECT ISNULL(MAX(CAST(REPLACE(REPLACE(LineCode, @p, ''), ' - ', '') AS INT)),0) + 1
FROM PetForm WHERE LineCode LIKE @p + ' - %'",
                Db.P("@p", prefix));
            int next = Convert.ToInt32(o);
            return prefix + " - " + next;
        }

        // ===== Attachments =====
        public static DataTable GetAttachments(int projectId)
        {
            return Db.Query("SELECT * FROM Attachments WHERE ProjectID=@id ORDER BY UploadedDate DESC",
                Db.P("@id", projectId));
        }

        public static int AddAttachment(int projectId, string fileName, string storedPath,
            string docType, long sizeBytes, string user, string extracted)
        {
            object id = Db.Scalar(@"
INSERT INTO Attachments(ProjectID, FileName, StoredPath, DocType, SizeBytes, UploadedBy, ExtractedJson)
VALUES(@p, @fn, @sp, @dt, @sz, @u, @ex);
SELECT SCOPE_IDENTITY();",
                Db.P("@p", projectId), Db.P("@fn", fileName), Db.P("@sp", storedPath),
                Db.P("@dt", docType), Db.P("@sz", sizeBytes), Db.P("@u", user),
                Db.P("@ex", extracted));
            return Convert.ToInt32(id);
        }

        // ===== BPM =====
        public static DataTable GetBpmList(int projectId)
        {
            return Db.Query("SELECT * FROM BpmRequests WHERE ProjectID=@id ORDER BY CreatedDate DESC",
                Db.P("@id", projectId));
        }

        public static DataRow GetBpm(int bpmId)
        {
            return Db.QueryRow("SELECT * FROM BpmRequests WHERE BpmID=@id", Db.P("@id", bpmId));
        }

        public static int CreateBpm(int projectId, string bpmRef, string invoiceNo, DateTime? invoiceDate,
            decimal invoiceAmt, string ccy, string vendor, string memo, string notes, string user)
        {
            object id = Db.Scalar(@"
INSERT INTO BpmRequests(ProjectID, BpmReference, InvoiceNo, InvoiceDate, InvoiceAmount, Currency,
    Vendor, MemoSubject, Status, Notes, CreatedBy)
VALUES(@p, @r, @no, @dt, @a, @c, @v, @m, 'Submitted', @n, @u);
SELECT SCOPE_IDENTITY();",
                Db.P("@p", projectId), Db.P("@r", bpmRef), Db.P("@no", invoiceNo),
                Db.P("@dt", invoiceDate.HasValue ? (object)invoiceDate.Value : DBNull.Value),
                Db.P("@a", invoiceAmt), Db.P("@c", ccy), Db.P("@v", vendor),
                Db.P("@m", memo), Db.P("@n", notes), Db.P("@u", user));
            return Convert.ToInt32(id);
        }

        public static void CloseBpm(int bpmId, string user)
        {
            Db.Exec(@"UPDATE BpmRequests SET Status='Closed', ClosedDate=GETDATE() WHERE BpmID=@id",
                Db.P("@id", bpmId));
        }
    }
}
