using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DFM")]
[assembly: AssemblyDescription("Demand Fund Management")]
[assembly: AssemblyCompany("Dubai Islamic Bank")]
[assembly: AssemblyProduct("DFM")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
[assembly: Guid("D5F1A2B3-4C5D-6E7F-8A9B-0C1D2E3F4A5B")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
