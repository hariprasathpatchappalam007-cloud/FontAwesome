namespace DFM
{
    public partial class DefaultPage
    {
        protected global::System.Web.UI.WebControls.DropDownList ddlType;
        protected global::System.Web.UI.WebControls.DropDownList ddlStatus;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.Button btnRefresh;
        protected global::System.Web.UI.WebControls.Literal kTotalProjects;
        protected global::System.Web.UI.WebControls.Literal kCapexBudget;
        protected global::System.Web.UI.WebControls.Literal kOpexBudget;
        protected global::System.Web.UI.WebControls.Literal kUtilized;
        protected global::System.Web.UI.WebControls.Literal kLocked;
        protected global::System.Web.UI.WebControls.Literal kAvailable;
        protected global::System.Web.UI.WebControls.Literal kPending;
        protected global::System.Web.UI.WebControls.Literal kApproved;
        protected global::System.Web.UI.WebControls.Literal kRejected;
        protected global::System.Web.UI.WebControls.Literal kJiraTotal;
        protected global::System.Web.UI.WebControls.Literal kJiraActive;
        protected global::System.Web.UI.WebControls.Literal kJiraAmber;
        protected global::System.Web.UI.WebControls.Literal kJiraRed;
        protected global::System.Web.UI.WebControls.Literal litMeterPct;
    }
}
