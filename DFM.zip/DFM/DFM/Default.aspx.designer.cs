namespace DFM
{
    public partial class DefaultPage
    {
        protected global::System.Web.UI.WebControls.DropDownList ddlType;
        protected global::System.Web.UI.WebControls.DropDownList ddlStatus;
        protected global::System.Web.UI.WebControls.DropDownList ddlRequestedBy;
        protected global::System.Web.UI.WebControls.TextBox txtFromDate;
        protected global::System.Web.UI.WebControls.TextBox txtToDate;
        protected global::System.Web.UI.WebControls.Button btnApply;
        protected global::System.Web.UI.WebControls.Button btnRefresh;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.Literal kTotalProjects;
        protected global::System.Web.UI.WebControls.Literal kCapexBudget;
        protected global::System.Web.UI.WebControls.Literal kOpexBudget;
        protected global::System.Web.UI.WebControls.Literal kUtilized;
        protected global::System.Web.UI.WebControls.Literal kLocked;
        protected global::System.Web.UI.WebControls.Literal kAvailable;
        protected global::System.Web.UI.WebControls.Literal kPending;
        protected global::System.Web.UI.WebControls.Literal kApproved;
        protected global::System.Web.UI.WebControls.Literal kRejected;
        protected global::System.Web.UI.WebControls.Literal litMeterPct;
        protected global::System.Web.UI.WebControls.Literal litLastRefreshed;
        protected global::System.Web.UI.WebControls.Literal litBudgetCards;
        protected global::System.Web.UI.WebControls.Literal litTree;
    }
}
