namespace DFM
{
    public partial class DefaultPage
    {
        protected global::System.Web.UI.WebControls.DropDownList ddlType;
        protected global::System.Web.UI.WebControls.DropDownList ddlStatus;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.Button btnRefresh;
        protected global::System.Web.UI.WebControls.Literal kTotalProjects;
        protected global::System.Web.UI.WebControls.Literal kCapexBudget;
        protected global::System.Web.UI.WebControls.Literal kOpexBudget;
        protected global::System.Web.UI.WebControls.Literal kUtilized;
        protected global::System.Web.UI.WebControls.Literal kLocked;
        protected global::System.Web.UI.WebControls.Literal kAvailable;
        protected global::System.Web.UI.WebControls.Literal kPending;
        protected global::System.Web.UI.WebControls.Literal kApproved;
        protected global::System.Web.UI.WebControls.Literal kRejected;
        protected global::System.Web.UI.WebControls.Literal cCapex;
        protected global::System.Web.UI.WebControls.Literal cOpex;
        protected global::System.Web.UI.WebControls.Literal cAmc;
        protected global::System.Web.UI.WebControls.GridView gvProjects;
        protected global::System.Web.UI.WebControls.GridView gvJira;
    }
}
