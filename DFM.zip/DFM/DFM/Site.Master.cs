using System;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM
{
    public partial class SiteMaster : MasterPage
    {
        public string CurrentTheme { get; set; }
        public string CurrentFont { get; set; }
        public int UnreadCount { get; set; }

        public SiteMaster()
        {
            CurrentTheme = "ocean";
            CurrentFont = "Large";
            UnreadCount = 0;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string userName = Session["FullName"] as string;
            if (string.IsNullOrEmpty(userName)) userName = Session["Username"] as string;
            string role = Session["Role"] as string;
            if (string.IsNullOrEmpty(role)) role = "User";

            if (string.IsNullOrEmpty(userName))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }
            lblUserName.Text = userName;
            lblUserRole.Text = role;
            litTopUser.Text = userName;

            string user = AuthHelper.CurrentUser;

            // Theme + font preferences
            try
            {
                DataRow s = MastersDAL.GetUserSettings(user);
                if (s != null)
                {
                    if (s["ThemeName"] != DBNull.Value && !string.IsNullOrEmpty(s["ThemeName"].ToString()))
                        CurrentTheme = s["ThemeName"].ToString();
                    if (s["FontSize"] != DBNull.Value && !string.IsNullOrEmpty(s["FontSize"].ToString()))
                        CurrentFont = s["FontSize"].ToString();
                }
            }
            catch { }

            // Active functional role + Admin/PET Approver detection (Req 42)
            string active = Session["ActiveRole"] as string;
            bool hasApprover = false, hasRequestor = false, isAdmin = false, isPetApprover = false;
            try
            {
                DataTable assigned = RolesDAL.GetUserRoles(user);
                foreach (DataRow r in assigned.Rows)
                {
                    string rt = r["RoleType"].ToString();
                    if (string.Equals(rt, "Approver", StringComparison.OrdinalIgnoreCase)) hasApprover = true;
                    if (string.Equals(rt, "Requestor", StringComparison.OrdinalIgnoreCase)) hasRequestor = true;
                    if (string.Equals(rt, "Admin", StringComparison.OrdinalIgnoreCase)) isAdmin = true;
                    if (string.Equals(rt, "PETApprover", StringComparison.OrdinalIgnoreCase)) isPetApprover = true;
                }
            }
            catch { }

            // Fallback: legacy role on AppUsers (Admin / Approver)
            if (!isAdmin && string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase)) isAdmin = true;
            if (!isPetApprover && hasApprover) isPetApprover = true;

            if (string.IsNullOrEmpty(active))
            {
                active = hasApprover ? "Approver" : (hasRequestor ? "Requestor" : "User");
                Session["ActiveRole"] = active;
            }
            litActiveRole.Text = active;
            pnlRoleSwitcher.Visible = (hasApprover && hasRequestor);

            // Req 42: Master Data accessible only to Admin Users and PET Approvers.
            pnlMaster.Visible = (isAdmin || isPetApprover);
            pnlConfig.Visible = isAdmin;

            // Req 39: handle ?__nid=N — mark notif read then redirect.
            int nid;
            if (int.TryParse(Request.QueryString["__nid"], out nid) && nid > 0)
            {
                try { NotificationsDAL.MarkRead(nid); } catch { }
            }

            // Notifications panel (top 15)
            try
            {
                DataTable notifs = NotificationsDAL.GetForUser(user, 15);
                int unread = 0;
                foreach (DataRow nr in notifs.Rows)
                    if (!Convert.ToBoolean(nr["IsRead"])) unread++;
                UnreadCount = unread;
                litNotifBadge.Text = unread > 0 ? "<span class='notif-badge'>" + unread + "</span>" : "";
                if (notifs.Rows.Count == 0)
                {
                    pnlNoNotif.Visible = true;
                }
                else
                {
                    rptNotif.DataSource = notifs;
                    rptNotif.DataBind();
                }
            }
            catch
            {
                litNotifBadge.Text = "";
                pnlNoNotif.Visible = true;
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            Response.Redirect("~/Login.aspx");
        }

        protected void btnSwitchRole_Click(object sender, EventArgs e)
        {
            LinkButton lb = sender as LinkButton;
            if (lb == null) return;
            string r = lb.CommandArgument;
            if (string.Equals(r, "Approver", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(r, "Requestor", StringComparison.OrdinalIgnoreCase))
            {
                Session["ActiveRole"] = r;
            }
            Response.Redirect(Request.RawUrl);
        }

        protected void btnMarkAllRead_Click(object sender, EventArgs e)
        {
            string user = AuthHelper.CurrentUser;
            try { NotificationsDAL.MarkAllRead(user); } catch { }
            Response.Redirect(Request.RawUrl);
        }

        protected void btnClearAll_Click(object sender, EventArgs e)
        {
            string user = AuthHelper.CurrentUser;
            try { NotificationsDAL.ClearAll(user); } catch { }
            Response.Redirect(Request.RawUrl);
        }
    }
}
