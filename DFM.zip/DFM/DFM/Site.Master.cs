using System;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM
{
    public partial class SiteMaster : MasterPage
    {
        public string CurrentTheme { get; set; }
        public string CurrentFont { get; set; }

        public SiteMaster()
        {
            CurrentTheme = "ocean";
            CurrentFont = "Large";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string userName = Session["FullName"] as string;
            if (string.IsNullOrEmpty(userName)) userName = Session["Username"] as string;
            string role = Session["Role"] as string;
            if (string.IsNullOrEmpty(role)) role = "User";

            if (string.IsNullOrEmpty(userName))
            {
                Response.Redirect("~/Login.aspx");
                return;
            }
            lblUserName.Text = userName;
            lblUserRole.Text = role;
            litTopUser.Text = userName;

            // Theme + font preferences applied server-side so the very first
            // paint after login matches the user's saved choice.
            string user = AuthHelper.CurrentUser;
            try
            {
                DataRow s = MastersDAL.GetUserSettings(user);
                if (s != null)
                {
                    if (s["ThemeName"] != DBNull.Value && !string.IsNullOrEmpty(s["ThemeName"].ToString()))
                        CurrentTheme = s["ThemeName"].ToString();
                    if (s["FontSize"] != DBNull.Value && !string.IsNullOrEmpty(s["FontSize"].ToString()))
                        CurrentFont = s["FontSize"].ToString();
                }
            }
            catch { /* table missing on first run - keep defaults */ }

            // Active functional role (Approver / Requestor) for users with both
            string active = Session["ActiveRole"] as string;
            bool hasApprover = false, hasRequestor = false;
            try
            {
                DataTable assigned = RolesDAL.GetUserRoles(user);
                foreach (DataRow r in assigned.Rows)
                {
                    if (string.Equals(r["RoleType"].ToString(), "Approver",  StringComparison.OrdinalIgnoreCase)) hasApprover = true;
                    if (string.Equals(r["RoleType"].ToString(), "Requestor", StringComparison.OrdinalIgnoreCase)) hasRequestor = true;
                }
            }
            catch { /* UserRoleAssignments table missing - run 04_AdditionalTables.sql */ }

            if (string.IsNullOrEmpty(active))
            {
                active = hasApprover ? "Approver" : (hasRequestor ? "Requestor" : "User");
                Session["ActiveRole"] = active;
            }
            litActiveRole.Text = active;
            pnlRoleSwitcher.Visible = (hasApprover && hasRequestor);

            // Notifications (top 10)
            try
            {
                DataTable notifs = NotificationsDAL.GetForUser(user, 10);
                int unread = 0;
                foreach (DataRow nr in notifs.Rows)
                    if (!Convert.ToBoolean(nr["IsRead"])) unread++;
                litNotifBadge.Text = unread > 0 ? "<span class='notif-badge'>" + unread + "</span>" : "";
                if (notifs.Rows.Count == 0)
                {
                    pnlNoNotif.Visible = true;
                }
                else
                {
                    rptNotif.DataSource = notifs;
                    rptNotif.DataBind();
                }
            }
            catch
            {
                litNotifBadge.Text = "";
                pnlNoNotif.Visible = true;
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            Response.Redirect("~/Login.aspx");
        }

        protected void btnSwitchRole_Click(object sender, EventArgs e)
        {
            LinkButton lb = sender as LinkButton;
            if (lb == null) return;
            string role = lb.CommandArgument;
            if (string.Equals(role, "Approver", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, "Requestor", StringComparison.OrdinalIgnoreCase))
            {
                Session["ActiveRole"] = role;
            }
            Response.Redirect(Request.RawUrl);
        }
    }
}
