// DFM client-side helpers
window.DFM = window.DFM || {};

DFM.formatMoney = function (n) {
    if (n === null || n === undefined || isNaN(n)) return '-';
    return Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 });
};

DFM.applyTheme = function (name) {
    document.documentElement.setAttribute('data-theme', name);
    document.body.setAttribute('data-theme', name);
    try { localStorage.setItem('dfm-theme', name); } catch (e) { }
};

DFM.previewTheme = function (name) {
    document.documentElement.setAttribute('data-theme', name);
    document.body.setAttribute('data-theme', name);
};

DFM.applyFont = function (size) {
    document.documentElement.setAttribute('data-font', size);
    document.body.setAttribute('data-font', size);
    try { localStorage.setItem('dfm-font', size); } catch (e) { }
};

// Reload to drop any client-side preview and re-render with the saved server-side theme
DFM.restoreTheme = function () { location.reload(); };

DFM.toggleSidebar = function () {
    var collapsed = document.body.classList.toggle('sidebar-collapsed');
    try { localStorage.setItem('dfm-sidebar-collapsed', collapsed ? 'true' : 'false'); } catch (e) { }
    // Also toggle mobile open state
    var sb = document.getElementById('sidebar');
    if (sb && window.innerWidth <= 992) sb.classList.toggle('sidebar-open');
};

DFM.openGroup = function (id) {
    var grp = document.getElementById(id);
    if (!grp) return;
    grp.classList.add('expanded');
    var ch = document.getElementById(id + 'Chevron');
    if (ch) ch.classList.add('rotated');
};

DFM.closeGroup = function (id) {
    var grp = document.getElementById(id);
    if (!grp) return;
    grp.classList.remove('expanded');
    var ch = document.getElementById(id + 'Chevron');
    if (ch) ch.classList.remove('rotated');
};

DFM.toggleGroup = function (id) {
    var grp = document.getElementById(id);
    if (!grp) return;
    var nowOpen = !grp.classList.contains('expanded');
    if (nowOpen) DFM.openGroup(id); else DFM.closeGroup(id);
    try { localStorage.setItem('dfm-grp-' + id, nowOpen ? 'open' : 'closed'); } catch (e) { }
};

DFM.toggleNotif = function (e) {
    var p = document.getElementById('notifPanel');
    if (!p) return;
    p.style.display = (p.style.display === 'none' || !p.style.display) ? 'block' : 'none';
    if (e && e.stopPropagation) e.stopPropagation();
};

DFM.toggleUserMenu = function (e) {
    var p = document.getElementById('userMenu');
    if (!p) return;
    p.style.display = (p.style.display === 'none' || !p.style.display) ? 'block' : 'none';
    if (e && e.stopPropagation) e.stopPropagation();
};

// Close popovers on outside click
document.addEventListener('click', function (e) {
    var bell = document.querySelector('.topbar-bell');
    var notif = document.getElementById('notifPanel');
    if (notif && bell && !bell.contains(e.target)) notif.style.display = 'none';

    var ui = document.querySelector('.topbar-user');
    var menu = document.getElementById('userMenu');
    if (menu && ui && !ui.contains(e.target)) menu.style.display = 'none';
});
