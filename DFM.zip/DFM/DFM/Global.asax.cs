using System;
using System.Configuration;
using System.Web;
using System.Web.Security;

namespace DFM
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e) { }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {
            // Windows Authentication mode: trust the IIS-supplied identity, skip Forms login.
            string authMode = ConfigurationManager.AppSettings["AuthMode"];
            if (string.Equals(authMode, "Windows", StringComparison.OrdinalIgnoreCase))
            {
                if (HttpContext.Current.User != null && HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    string winUser = HttpContext.Current.User.Identity.Name;
                    if (!string.IsNullOrEmpty(winUser) && Session != null && Session["Username"] == null)
                    {
                        Session["Username"] = winUser;
                        Session["FullName"] = winUser;
                        Session["Role"] = "User";
                    }
                }
            }
        }

        protected void Application_Error(object sender, EventArgs e) { }

        protected void Session_End(object sender, EventArgs e) { }
    }
}
