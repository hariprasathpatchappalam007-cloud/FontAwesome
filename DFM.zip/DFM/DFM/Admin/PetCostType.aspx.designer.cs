namespace DFM.Admin
{
    public partial class PetCostType
    {
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.HiddenField hfId;
        protected global::System.Web.UI.WebControls.TextBox txtOrder;
        protected global::System.Web.UI.WebControls.TextBox txtCategory;
        protected global::System.Web.UI.WebControls.CheckBox chkActive;
        protected global::System.Web.UI.WebControls.Button btnSave;
        protected global::System.Web.UI.WebControls.Button btnReset;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
