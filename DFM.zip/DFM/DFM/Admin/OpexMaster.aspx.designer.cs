namespace DFM.Admin
{
    public partial class OpexMaster
    {
        protected global::System.Web.UI.WebControls.TextBox txtSearch;
        protected global::System.Web.UI.WebControls.Button btnSearch;
        protected global::System.Web.UI.WebControls.Button btnImport;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.TextBox txtId;
        protected global::System.Web.UI.WebControls.TextBox txtDesc;
        protected global::System.Web.UI.WebControls.TextBox txtBudget;
        protected global::System.Web.UI.WebControls.TextBox txtUtil;
        protected global::System.Web.UI.WebControls.TextBox txtAvail;
        protected global::System.Web.UI.WebControls.TextBox txtLocked;
        protected global::System.Web.UI.WebControls.TextBox txtAfterLock;
        protected global::System.Web.UI.WebControls.TextBox txtClaim;
        protected global::System.Web.UI.WebControls.TextBox txtNet;
        protected global::System.Web.UI.WebControls.Button btnSave;
        protected global::System.Web.UI.WebControls.Button btnReset;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
