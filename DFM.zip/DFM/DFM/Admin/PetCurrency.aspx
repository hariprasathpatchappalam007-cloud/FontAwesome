<%@ Page Title="PET Currency" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="PetCurrency.aspx.cs" Inherits="DFM.Admin.PetCurrency" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-usd"></span> PET Currency</h1>

    <div class="toolbar">
        <div class="spacer"></div>
        <asp:Button ID="btnExport" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
    </div>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-edit"></span> Add / Edit currency</h3>
        <asp:HiddenField ID="hfId" runat="server" Value="0" />
        <div class="form-row">
            <div class="form-group" style="flex:0 0 130px;">
                <label>Code</label>
                <asp:TextBox ID="txtCode" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Name</label>
                <asp:TextBox ID="txtName" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group" style="flex:0 0 200px;">
                <label>Rate to Local (AED)</label>
                <asp:TextBox ID="txtRate" runat="server" CssClass="form-control" Text="1.0000" />
            </div>
            <div class="form-group" style="flex:0 0 130px;">
                <label>Active</label>
                <asp:CheckBox ID="chkActive" runat="server" Checked="true" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnSave_Click" />
            <asp:Button ID="btnReset" runat="server" Text="Reset" CssClass="btn btn-secondary"
                OnClick="btnReset_Click" CausesValidation="false" />
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list"></span> Currencies</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table"
            GridLines="None" DataKeyNames="CurrencyID" OnRowCommand="gv_RowCommand">
            <Columns>
                <asp:BoundField DataField="Code" HeaderText="Code" />
                <asp:BoundField DataField="Name" HeaderText="Name" />
                <asp:BoundField DataField="RateToLocal" HeaderText="Rate to AED" DataFormatString="{0:N4}" ItemStyle-CssClass="text-right" />
                <asp:CheckBoxField DataField="IsActive" HeaderText="Active" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="EditRow"
                            CommandArgument='<%# Eval("CurrencyID") %>'>
                            <span class="glyphicon glyphicon-pencil"></span> Edit
                        </asp:LinkButton>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-danger" CommandName="DeleteRow"
                            CommandArgument='<%# Eval("CurrencyID") %>'
                            OnClientClick="return confirm('Delete this currency?');">
                            <span class="glyphicon glyphicon-trash"></span> Delete
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
