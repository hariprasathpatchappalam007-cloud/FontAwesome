using System;
using System.Data;
using DFM.App_Code.DAL;

namespace DFM.Admin
{
    public partial class GLMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) BindGrid();
        }

        private void BindGrid()
        {
            gv.DataSource = GLMasterDAL.GetAll(false);
            gv.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int id = 0; int.TryParse(hfEditId.Value, out id);
            GLMasterDAL.Upsert(id, txtGLCode.Text.Trim(), txtDesc.Text.Trim(), chkActive.Checked);
            ResetForm();
            BindGrid();
            lblMsg.Visible = true; lblMsg.CssClass = "alert-success";
            lblMsg.Text = "GL entry saved.";
        }

        protected void btnReset_Click(object sender, EventArgs e) { ResetForm(); }

        protected void gv_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "EditRow")
            {
                DataRow r = GLMasterDAL.GetById(id);
                if (r == null) return;
                hfEditId.Value = id.ToString();
                hfMode.Value = "EDIT";
                txtGLCode.Text = r["GLCode"].ToString();
                txtDesc.Text = r["Description"].ToString();
                chkActive.Checked = Convert.ToBoolean(r["IsActive"]);
            }
            else if (e.CommandName == "DeleteRow")
            {
                GLMasterDAL.Delete(id);
                BindGrid();
                lblMsg.Visible = true; lblMsg.CssClass = "alert-success";
                lblMsg.Text = "GL entry deleted.";
            }
        }

        private void ResetForm()
        {
            hfEditId.Value = "0"; hfMode.Value = "ADD";
            txtGLCode.Text = ""; txtDesc.Text = ""; chkActive.Checked = true;
        }
    }
}
