using System;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class UserSettings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var s = MastersDAL.GetUserSettings(AuthHelper.CurrentUser);
                if (s != null)
                {
                    SetSelected(ddlTheme, s["ThemeName"].ToString());
                    SetSelected(ddlFont, s["FontSize"].ToString());
                    if (s["DefaultPage"] != DBNull.Value) SetSelected(ddlPage, s["DefaultPage"].ToString());
                    chkNotif.Checked = Convert.ToBoolean(s["Notifications"]);
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            MastersDAL.SaveUserSettings(AuthHelper.CurrentUser, ddlTheme.SelectedValue,
                ddlFont.SelectedValue, ddlPage.SelectedValue, chkNotif.Checked);
            lblMsg.Visible = true;
            lblMsg.Text = "Settings saved.";
            ClientScript.RegisterStartupScript(GetType(), "t",
                "<script>DFM.applyTheme('" + ddlTheme.SelectedValue + "');</script>", false);
        }

        private static void SetSelected(System.Web.UI.WebControls.DropDownList ddl, string val)
        {
            var item = ddl.Items.FindByValue(val) ?? ddl.Items.FindByText(val);
            if (item != null) { ddl.ClearSelection(); item.Selected = true; }
        }
    }
}
