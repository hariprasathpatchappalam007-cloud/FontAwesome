using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class AmcMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }
        private void Bind() { gv.DataSource = MastersDAL.GetAmc(txtSearch.Text); gv.DataBind(); }
        protected void btnSearch_Click(object sender, EventArgs e) { Bind(); }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = MastersDAL.GetAmc(txtSearch.Text);
            ExcelHelper.ExportToExcel(Response, dt, "AMC_Master_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string id = txtId.Text.Trim();
            if (id.Length == 0) { lblMsg.Visible = true; lblMsg.Text = "AMC ID is required."; return; }
            MastersDAL.UpsertAmc(id, txtDesc.Text.Trim(),
                CsvImporter.ParseDecimal(txtBudget.Text), CsvImporter.ParseDecimal(txtUtil.Text),
                CsvImporter.ParseDecimal(txtAvail.Text), CsvImporter.ParseDecimal(txtLocked.Text),
                CsvImporter.ParseDecimal(txtAfterLock.Text), CsvImporter.ParseDecimal(txtClaim.Text),
                CsvImporter.ParseDecimal(txtNet.Text), AuthHelper.CurrentUser);
            lblMsg.Visible = true; lblMsg.Text = "AMC entry saved.";
            ClearForm(); Bind();
        }
        protected void btnReset_Click(object sender, EventArgs e) { ClearForm(); }
        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteRow")
            {
                MastersDAL.DeleteAmc(e.CommandArgument.ToString());
                Bind();
            }
        }
        private void ClearForm()
        {
            txtId.Text = txtDesc.Text = "";
            txtBudget.Text = txtUtil.Text = txtAvail.Text = txtLocked.Text = "";
            txtAfterLock.Text = txtClaim.Text = txtNet.Text = "";
        }
    }
}
