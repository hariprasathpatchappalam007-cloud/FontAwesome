using System;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class UserRoles : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        private void Bind()
        {
            gv.DataSource = RolesDAL.GetAllAssignments();
            gv.DataBind();
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Toggle") return;
            string arg = e.CommandArgument == null ? "" : e.CommandArgument.ToString();
            string[] parts = arg.Split('|');
            if (parts.Length != 2) return;
            string username = parts[0]; string roleType = parts[1];

            if (RolesDAL.HasRole(username, roleType))
            {
                RolesDAL.RemoveRole(username, roleType);
                lblMsg.Visible = true;
                lblMsg.Text = "Removed " + roleType + " role from " + username + ".";
            }
            else
            {
                RolesDAL.AddRole(username, roleType, AuthHelper.CurrentUser);
                lblMsg.Visible = true;
                lblMsg.Text = "Granted " + roleType + " role to " + username + ".";
            }
            Bind();
        }
    }
}
