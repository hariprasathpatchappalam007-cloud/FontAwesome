<%@ Page Title="JIRA Configuration" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="JiraConfig.aspx.cs" Inherits="DFM.Admin.JiraConfig" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">JIRA Configuration</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3>Connection</h3>
        <div class="form-row">
            <div class="form-group" style="flex:2 1 480px;">
                <label>JIRA Base URL</label>
                <asp:TextBox ID="txtBase" runat="server" CssClass="form-control" placeholder="https://yourcompany.atlassian.net" />
            </div>
            <div class="form-group">
                <label>Project Key</label>
                <asp:TextBox ID="txtKey" runat="server" CssClass="form-control" />
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>User Email</label>
                <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>API Token</label>
                <asp:TextBox ID="txtToken" runat="server" TextMode="Password" CssClass="form-control" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save Configuration" CssClass="btn btn-primary" OnClick="btnSave_Click" />
            <asp:Button ID="btnFetchFields" runat="server" Text="Discover JIRA Custom Fields"
                CssClass="btn btn-secondary" OnClick="btnFetchFields_Click" />
        </div>
    </div>

    <div class="card-panel">
        <h3>JIRA custom field visibility</h3>
        <p class="text-muted mb-3">Toggle which custom fields auto-populate on Project Registration.</p>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            DataKeyNames="ID" OnRowCommand="gv_RowCommand">
            <Columns>
                <asp:BoundField DataField="FieldKey" HeaderText="Key" />
                <asp:BoundField DataField="FieldName" HeaderText="Name" />
                <asp:BoundField DataField="DisplayOrder" HeaderText="Order" />
                <asp:CheckBoxField DataField="IsVisible" HeaderText="Visible" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="ToggleVisible"
                            CommandArgument='<%# Eval("ID") %>' Text="Toggle" />
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
