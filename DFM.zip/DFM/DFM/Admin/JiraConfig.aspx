<%@ Page Title="JIRA Configuration" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="JiraConfig.aspx.cs" Inherits="DFM.Admin.JiraConfig" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">JIRA Configuration</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <!-- Req 66-70: Standard 5-column layout, default URL, Username/Password only -->
    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-cog"></span> Connection (Username / Password)</h3>
        <div class="form-grid-5">
            <div class="form-group col-span-3">
                <label>JIRA Base URL</label>
                <asp:TextBox ID="txtBase" runat="server" CssClass="form-control"
                    placeholder="https://agile.dib.ae/planner" />
            </div>
            <div class="form-group">
                <label>Project Key</label>
                <asp:TextBox ID="txtKey" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Status</label>
                <asp:Literal ID="litStatus" runat="server" Text="Not configured" />
            </div>
        </div>
        <div class="form-grid-5">
            <div class="form-group col-span-2">
                <label>Username</label>
                <asp:TextBox ID="txtUser" runat="server" CssClass="form-control" autocomplete="off" />
            </div>
            <div class="form-group col-span-2">
                <label>Password</label>
                <asp:TextBox ID="txtPwd" runat="server" TextMode="Password" CssClass="form-control" autocomplete="new-password" />
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <asp:Button ID="btnSave" runat="server" Text="Save Configuration"
                    CssClass="btn btn-primary" OnClick="btnSave_Click" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnFetchFields" runat="server" Text="Discover JIRA Custom Fields"
                CssClass="btn btn-secondary" OnClick="btnFetchFields_Click" />
            <asp:Button ID="btnTest" runat="server" Text="Test Connection"
                CssClass="btn btn-info" OnClick="btnTest_Click" />
        </div>
    </div>

    <!-- Req 75: pagination + Name/Key filter -->
    <!-- Req 4: Separate DMGT and DIBITP field sections -->
    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list"></span> DMGT Custom Fields</h3>
        <p style="font-size:.85em;color:var(--text-muted);">Fields specific to the Demand Management (DMGT) project.</p>
        <div class="filter-row">
            <div class="form-group col-span-2">
                <label>Filter by Name</label>
                <asp:TextBox ID="txtFilterNameDMGT" runat="server" CssClass="form-control" AutoPostBack="true"
                    OnTextChanged="Filter_Changed" />
            </div>
            <div class="form-group col-span-2">
                <label>Filter by Key</label>
                <asp:TextBox ID="txtFilterKeyDMGT" runat="server" CssClass="form-control" AutoPostBack="true"
                    OnTextChanged="Filter_Changed" />
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <asp:Button ID="btnFilterDMGT" runat="server" Text="Apply" CssClass="btn btn-primary" OnClick="Filter_Changed" />
            </div>
        </div>
        <asp:GridView ID="gvDMGT" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            DataKeyNames="ID" AllowPaging="true" PageSize="15"
            OnRowCommand="gv_RowCommand" OnPageIndexChanging="gvDMGT_PageIndexChanging">
            <PagerStyle CssClass="pager" />
            <Columns>
                <asp:BoundField DataField="FieldKey" HeaderText="Key" />
                <asp:BoundField DataField="FieldName" HeaderText="Name" />
                <asp:BoundField DataField="DisplayOrder" HeaderText="Order" />
                <asp:CheckBoxField DataField="IsVisible" HeaderText="Visible" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="ToggleVisible"
                            CommandArgument='<%# Eval("ID") %>'>
                            <span class="glyphicon glyphicon-refresh"></span> Toggle
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list-alt"></span> DIBITP Custom Fields</h3>
        <p style="font-size:.85em;color:var(--text-muted);">Fields specific to the DIB IT Projects (DIBITP) project. These are different from DMGT fields.</p>
        <div class="filter-row">
            <div class="form-group col-span-2">
                <label>Filter by Name</label>
                <asp:TextBox ID="txtFilterNameDIBITP" runat="server" CssClass="form-control" AutoPostBack="true"
                    OnTextChanged="Filter_Changed" />
            </div>
            <div class="form-group col-span-2">
                <label>Filter by Key</label>
                <asp:TextBox ID="txtFilterKeyDIBITP" runat="server" CssClass="form-control" AutoPostBack="true"
                    OnTextChanged="Filter_Changed" />
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <asp:Button ID="btnFilterDIBITP" runat="server" Text="Apply" CssClass="btn btn-primary" OnClick="Filter_Changed" />
            </div>
        </div>
        <asp:GridView ID="gvDIBITP" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            DataKeyNames="ID" AllowPaging="true" PageSize="15"
            OnRowCommand="gv_RowCommand" OnPageIndexChanging="gvDIBITP_PageIndexChanging">
            <PagerStyle CssClass="pager" />
            <Columns>
                <asp:BoundField DataField="FieldKey" HeaderText="Key" />
                <asp:BoundField DataField="FieldName" HeaderText="Name" />
                <asp:BoundField DataField="DisplayOrder" HeaderText="Order" />
                <asp:CheckBoxField DataField="IsVisible" HeaderText="Visible" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="ToggleVisible"
                            CommandArgument='<%# Eval("ID") %>'>
                            <span class="glyphicon glyphicon-refresh"></span> Toggle
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
