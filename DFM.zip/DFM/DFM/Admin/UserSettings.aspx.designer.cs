namespace DFM.Admin
{
    public partial class UserSettings
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.DropDownList ddlTheme;
        protected global::System.Web.UI.WebControls.DropDownList ddlFont;
        protected global::System.Web.UI.WebControls.DropDownList ddlPage;
        protected global::System.Web.UI.WebControls.CheckBox chkNotif;
        protected global::System.Web.UI.WebControls.Button btnSave;
    }
}
