using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class ApproverMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadUserDropdown();
                Bind();
            }
        }

        private void LoadUserDropdown()
        {
            ddlUsername.Items.Clear();
            ddlUsername.Items.Add(new System.Web.UI.WebControls.ListItem("-- No user linked --", ""));
            try
            {
                foreach (DataRow r in MastersDAL.GetAppUsers().Rows)
                {
                    string uname = r["Username"].ToString();
                    string display = r["FullName"] != DBNull.Value && !string.IsNullOrEmpty(r["FullName"].ToString())
                        ? r["FullName"].ToString() + " (" + uname + ")"
                        : uname;
                    ddlUsername.Items.Add(new System.Web.UI.WebControls.ListItem(display, uname));
                }
            }
            catch { }
        }

        private void Bind() { gv.DataSource = MastersDAL.GetApprovers(); gv.DataBind(); }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = MastersDAL.GetApprovers();
            ExcelHelper.ExportToExcel(Response, dt, "Approver_Master_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int id;
            if (!int.TryParse(hfId.Value, out id)) id = 0;
            int level; int.TryParse(txtLevel.Text.Trim(), out level);
            if (level <= 0) level = 1;
            if (string.IsNullOrWhiteSpace(txtName.Text)) { lblMsg.Visible = true; lblMsg.Text = "Name is required."; return; }
            string selectedUser = ddlUsername.SelectedValue;
            MastersDAL.UpsertApprover(id, txtName.Text.Trim(), txtEmail.Text.Trim(),
                txtDept.Text.Trim(), level, chkActive.Checked,
                string.IsNullOrEmpty(selectedUser) ? null : selectedUser);
            lblMsg.Visible = true; lblMsg.Text = id > 0 ? "Approver updated." : "Approver added.";
            ClearForm(); Bind();
        }

        protected void btnReset_Click(object sender, EventArgs e) { ClearForm(); }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "DeleteRow") { MastersDAL.DeleteApprover(id); Bind(); }
            else if (e.CommandName == "EditRow")
            {
                var dt = MastersDAL.GetApprovers();
                foreach (DataRow row in dt.Rows)
                {
                    if (Convert.ToInt32(row["ApproverID"]) == id)
                    {
                        hfId.Value = id.ToString();
                        txtName.Text  = row["ApproverName"].ToString();
                        txtEmail.Text = row["Email"] == DBNull.Value ? "" : row["Email"].ToString();
                        txtDept.Text  = row["Department"] == DBNull.Value ? "" : row["Department"].ToString();
                        txtLevel.Text = row["ApprovalLevel"].ToString();
                        chkActive.Checked = Convert.ToBoolean(row["IsActive"]);
                        // Set the login-user dropdown
                        string savedUsername = row.Table.Columns.Contains("Username") && row["Username"] != DBNull.Value
                            ? row["Username"].ToString() : "";
                        var item = ddlUsername.Items.FindByValue(savedUsername);
                        if (item != null) ddlUsername.SelectedValue = savedUsername;
                        break;
                    }
                }
            }
        }

        private void ClearForm()
        {
            hfId.Value = "0"; txtName.Text = txtEmail.Text = txtDept.Text = "";
            txtLevel.Text = "1"; chkActive.Checked = true;
            ddlUsername.SelectedIndex = 0;
        }
    }
}
