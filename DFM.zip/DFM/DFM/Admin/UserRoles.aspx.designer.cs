namespace DFM.Admin
{
    public partial class UserRoles
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
