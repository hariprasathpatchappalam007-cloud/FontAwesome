namespace DFM.Admin
{
    public partial class JiraConfig
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.TextBox txtBase;
        protected global::System.Web.UI.WebControls.TextBox txtKey;
        protected global::System.Web.UI.WebControls.Literal litStatus;
        protected global::System.Web.UI.WebControls.TextBox txtUser;
        protected global::System.Web.UI.WebControls.TextBox txtPwd;
        protected global::System.Web.UI.WebControls.Button btnSave;
        protected global::System.Web.UI.WebControls.Button btnFetchFields;
        protected global::System.Web.UI.WebControls.Button btnTest;
        protected global::System.Web.UI.WebControls.TextBox txtFilterName;
        protected global::System.Web.UI.WebControls.TextBox txtFilterKey;
        protected global::System.Web.UI.WebControls.Button btnFilter;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
