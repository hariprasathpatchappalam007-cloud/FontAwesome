namespace DFM.Admin
{
    public partial class JiraConfig
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.TextBox txtBase;
        protected global::System.Web.UI.WebControls.TextBox txtKey;
        protected global::System.Web.UI.WebControls.TextBox txtEmail;
        protected global::System.Web.UI.WebControls.TextBox txtToken;
        protected global::System.Web.UI.WebControls.Button btnSave;
        protected global::System.Web.UI.WebControls.Button btnFetchFields;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
