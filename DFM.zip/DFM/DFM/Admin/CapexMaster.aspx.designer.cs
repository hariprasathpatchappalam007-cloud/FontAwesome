namespace DFM.Admin
{
    public partial class CapexMaster
    {
        protected global::System.Web.UI.WebControls.TextBox txtSearch;
        protected global::System.Web.UI.WebControls.LinkButton btnSearch;
        protected global::System.Web.UI.WebControls.LinkButton btnImport;
        protected global::System.Web.UI.WebControls.LinkButton btnExport;
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.HiddenField hfMode;
        protected global::System.Web.UI.WebControls.TextBox txtId;
        protected global::System.Web.UI.WebControls.TextBox txtDesc;
        protected global::System.Web.UI.WebControls.TextBox txtBudget;
        protected global::System.Web.UI.WebControls.TextBox txtUtil;
        protected global::System.Web.UI.WebControls.TextBox txtAvail;
        protected global::System.Web.UI.WebControls.TextBox txtLocked;
        protected global::System.Web.UI.WebControls.TextBox txtAfterLock;
        protected global::System.Web.UI.WebControls.TextBox txtClaim;
        protected global::System.Web.UI.WebControls.TextBox txtNet;
        protected global::System.Web.UI.WebControls.LinkButton btnSave;
        protected global::System.Web.UI.WebControls.LinkButton btnReset;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
