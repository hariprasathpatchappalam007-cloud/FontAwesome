<%@ Page Title="Vendor Master" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="VendorMaster.aspx.cs" Inherits="DFM.Admin.VendorMaster" %>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">Vendor Master</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-edit"></span> Add / Edit Vendor</h3>
        <asp:HiddenField ID="hfMode" runat="server" Value="ADD" />
        <asp:HiddenField ID="hfEditId" runat="server" Value="0" />
        <div class="form-grid-6">
            <div class="form-group">
                <label>Vendor Code</label>
                <asp:TextBox ID="txtCode" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Vendor Name</label>
                <asp:TextBox ID="txtName" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Contact Person</label>
                <asp:TextBox ID="txtContact" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Phone</label>
                <asp:TextBox ID="txtPhone" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Email</label>
                <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" TextMode="Email" />
            </div>
            <div class="form-group" style="align-self:end;">
                <label>Active</label>
                <asp:CheckBox ID="chkActive" runat="server" Checked="true" />
            </div>
        </div>
        <div class="toolbar">
            <asp:LinkButton ID="btnSave" runat="server" CssClass="btn btn-primary" OnClick="btnSave_Click">
                <span class="glyphicon glyphicon-floppy-disk"></span> Save
            </asp:LinkButton>
            <asp:LinkButton ID="btnReset" runat="server" CssClass="btn btn-secondary" OnClick="btnReset_Click" CausesValidation="false">
                <span class="glyphicon glyphicon-refresh"></span> Reset
            </asp:LinkButton>
        </div>
    </div>

    <div class="card-panel">
        <h3>Vendor Entries</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
                DataKeyNames="VendorID" OnRowCommand="gv_RowCommand">
                <Columns>
                    <asp:BoundField DataField="VendorID" HeaderText="ID" />
                    <asp:BoundField DataField="VendorCode" HeaderText="Code" />
                    <asp:BoundField DataField="VendorName" HeaderText="Name" />
                    <asp:BoundField DataField="ContactPerson" HeaderText="Contact" />
                    <asp:BoundField DataField="Phone" HeaderText="Phone" />
                    <asp:BoundField DataField="Email" HeaderText="Email" />
                    <asp:CheckBoxField DataField="IsActive" HeaderText="Active" />
                    <asp:TemplateField HeaderText="Actions" ItemStyle-CssClass="text-center">
                        <ItemTemplate>
                            <asp:LinkButton runat="server" CssClass="btn btn-xs btn-info"
                                CommandName="EditRow" CommandArgument='<%# Eval("VendorID") %>' ToolTip="Edit">
                                <span class="glyphicon glyphicon-pencil"></span>
                            </asp:LinkButton>
                            <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger"
                                CommandName="DeleteRow" CommandArgument='<%# Eval("VendorID") %>'
                                OnClientClick="return confirm('Delete this vendor?');" ToolTip="Delete">
                                <span class="glyphicon glyphicon-trash"></span>
                            </asp:LinkButton>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:12px;">No vendors found.</div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
