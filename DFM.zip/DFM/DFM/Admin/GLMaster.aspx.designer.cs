namespace DFM.Admin
{
    public partial class GLMaster
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.HiddenField hfMode;
        protected global::System.Web.UI.WebControls.HiddenField hfEditId;
        protected global::System.Web.UI.WebControls.TextBox txtGLCode;
        protected global::System.Web.UI.WebControls.TextBox txtDesc;
        protected global::System.Web.UI.WebControls.CheckBox chkActive;
        protected global::System.Web.UI.WebControls.LinkButton btnSave;
        protected global::System.Web.UI.WebControls.LinkButton btnReset;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
