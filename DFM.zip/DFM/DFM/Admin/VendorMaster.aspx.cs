using System;
using System.Data;
using DFM.App_Code.DAL;

namespace DFM.Admin
{
    public partial class VendorMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) BindGrid();
        }

        private void BindGrid()
        {
            gv.DataSource = VendorMasterDAL.GetAll(false);
            gv.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int id = 0; int.TryParse(hfEditId.Value, out id);
            VendorMasterDAL.Upsert(id, txtCode.Text.Trim(), txtName.Text.Trim(),
                txtContact.Text.Trim(), txtPhone.Text.Trim(), txtEmail.Text.Trim(), chkActive.Checked);
            ResetForm();
            BindGrid();
            lblMsg.Visible = true; lblMsg.CssClass = "alert-success";
            lblMsg.Text = "Vendor saved.";
        }

        protected void btnReset_Click(object sender, EventArgs e) { ResetForm(); }

        protected void gv_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "EditRow")
            {
                DataRow r = VendorMasterDAL.GetById(id);
                if (r == null) return;
                hfEditId.Value = id.ToString();
                hfMode.Value = "EDIT";
                txtCode.Text = r["VendorCode"].ToString();
                txtName.Text = r["VendorName"].ToString();
                txtContact.Text = r["ContactPerson"] == DBNull.Value ? "" : r["ContactPerson"].ToString();
                txtPhone.Text = r["Phone"] == DBNull.Value ? "" : r["Phone"].ToString();
                txtEmail.Text = r["Email"] == DBNull.Value ? "" : r["Email"].ToString();
                chkActive.Checked = Convert.ToBoolean(r["IsActive"]);
            }
            else if (e.CommandName == "DeleteRow")
            {
                VendorMasterDAL.Delete(id);
                BindGrid();
                lblMsg.Visible = true; lblMsg.CssClass = "alert-success";
                lblMsg.Text = "Vendor deleted.";
            }
        }

        private void ResetForm()
        {
            hfEditId.Value = "0"; hfMode.Value = "ADD";
            txtCode.Text = ""; txtName.Text = ""; txtContact.Text = "";
            txtPhone.Text = ""; txtEmail.Text = ""; chkActive.Checked = true;
        }
    }
}
