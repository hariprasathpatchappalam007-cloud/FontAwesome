<%@ Page Title="Approver Master" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ApproverMaster.aspx.cs" Inherits="DFM.Admin.ApproverMaster" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">Approver Master</h1>

    <div class="toolbar">
        <div class="spacer"></div>
        <asp:Button ID="btnExport" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
    </div>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3>Add / Edit approver</h3>
        <asp:HiddenField ID="hfId" runat="server" Value="0" />
        <div class="form-row">
            <div class="form-group"><label>Name</label><asp:TextBox ID="txtName" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Email</label><asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" /></div>
            <div class="form-group">
                <label>Login User <small class="text-muted">(links to User Management)</small></label>
                <asp:DropDownList ID="ddlUsername" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group"><label>Department</label><asp:TextBox ID="txtDept" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Approval Level</label><asp:TextBox ID="txtLevel" runat="server" CssClass="form-control" Text="1" /></div>
            <div class="form-group" style="flex:0 0 140px;">
                <label>Active</label>
                <asp:CheckBox ID="chkActive" runat="server" Checked="true" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnSave_Click" />
            <asp:Button ID="btnReset" runat="server" Text="Reset" CssClass="btn btn-secondary" OnClick="btnReset_Click" CausesValidation="false" />
        </div>
    </div>

    <div class="card-panel">
        <h3>Approvers</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
                DataKeyNames="ApproverID" OnRowCommand="gv_RowCommand">
                <Columns>
                    <asp:BoundField DataField="ApproverID" HeaderText="ID" />
                    <asp:BoundField DataField="ApproverName" HeaderText="Name" />
                    <asp:BoundField DataField="Email" HeaderText="Email" />
                    <asp:BoundField DataField="Username" HeaderText="Login User" />
                    <asp:BoundField DataField="Department" HeaderText="Department" />
                    <asp:BoundField DataField="ApprovalLevel" HeaderText="Level" />
                    <asp:CheckBoxField DataField="IsActive" HeaderText="Active" />
                    <asp:TemplateField HeaderText="Action">
                        <ItemTemplate>
                            <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="EditRow"
                                CommandArgument='<%# Eval("ApproverID") %>' Text="Edit" />
                            <asp:LinkButton runat="server" CssClass="btn btn-sm btn-danger" CommandName="DeleteRow"
                                CommandArgument='<%# Eval("ApproverID") %>' Text="Delete"
                                OnClientClick="return confirm('Delete this approver?');" />
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
