using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class PetCurrency : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        private void Bind() { gv.DataSource = PetDAL.GetCurrencies(); gv.DataBind(); }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int id; if (!int.TryParse(hfId.Value, out id)) id = 0;
            string code = txtCode.Text == null ? "" : txtCode.Text.Trim();
            if (code.Length == 0) { lblMsg.Visible = true; lblMsg.Text = "Code is required."; return; }
            decimal rate = CsvImporter.ParseDecimal(txtRate.Text);
            if (rate <= 0) rate = 1m;
            PetDAL.UpsertCurrency(id, code, txtName.Text == null ? "" : txtName.Text.Trim(),
                rate, chkActive.Checked);
            ClearForm();
            lblMsg.Visible = true; lblMsg.Text = "Saved.";
            Bind();
        }

        protected void btnReset_Click(object sender, EventArgs e) { ClearForm(); }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            ExcelHelper.ExportToExcel(Response, PetDAL.GetCurrencies(),
                "PET_Currencies_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "DeleteRow") { PetDAL.DeleteCurrency(id); Bind(); }
            else if (e.CommandName == "EditRow")
            {
                DataTable dt = PetDAL.GetCurrencies();
                foreach (DataRow r in dt.Rows)
                {
                    if (Convert.ToInt32(r["CurrencyID"]) == id)
                    {
                        hfId.Value = id.ToString();
                        txtCode.Text = r["Code"].ToString();
                        txtName.Text = r["Name"] == DBNull.Value ? "" : r["Name"].ToString();
                        txtRate.Text = Convert.ToDecimal(r["RateToLocal"]).ToString("N4");
                        chkActive.Checked = Convert.ToBoolean(r["IsActive"]);
                        break;
                    }
                }
            }
        }

        private void ClearForm()
        {
            hfId.Value = "0"; txtCode.Text = ""; txtName.Text = "";
            txtRate.Text = "1.0000"; chkActive.Checked = true;
        }
    }
}
