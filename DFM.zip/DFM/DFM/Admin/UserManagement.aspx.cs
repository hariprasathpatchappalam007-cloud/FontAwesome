using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class UserManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        private void Bind()
        {
            DataTable dt = Db.Query(@"SELECT u.UserID, u.Username, u.FullName, u.Email, r.RoleName,
                                            u.IsEnabled, u.LastLoginDate
                                      FROM AppUsers u INNER JOIN UserRoles r ON u.RoleID=r.RoleID
                                      ORDER BY u.Username");
            gv.DataSource = dt; gv.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string user = (txtUser.Text ?? "").Trim();
            if (string.IsNullOrEmpty(user)) { lblMsg.Visible = true; lblMsg.Text = "Username is required."; return; }
            if (Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM AppUsers WHERE Username=@u", Db.P("@u", user))) > 0)
            {
                lblMsg.Visible = true; lblMsg.Text = "Username already exists."; return;
            }
            int roleId = Convert.ToInt32(Db.Scalar("SELECT RoleID FROM UserRoles WHERE RoleName=@r",
                Db.P("@r", ddlRole.SelectedValue)));
            string salt = PasswordHelper.GenerateSalt();
            string hash = PasswordHelper.Hash(string.IsNullOrEmpty(txtPwd.Text) ? "Welcome@123" : txtPwd.Text, salt);
            Db.Exec(@"INSERT INTO AppUsers(Username, PasswordHash, PasswordSalt, FullName, Email, RoleID, IsEnabled, CreatedBy)
                      VALUES(@u, @h, @s, @n, @e, @r, 1, @cb)",
                Db.P("@u", user), Db.P("@h", hash), Db.P("@s", salt),
                Db.P("@n", txtName.Text.Trim()),
                Db.P("@e", string.IsNullOrEmpty(txtEmail.Text) ? "" : txtEmail.Text.Trim()),
                Db.P("@r", roleId), Db.P("@cb", AuthHelper.CurrentUser));
            lblMsg.Visible = true; lblMsg.Text = "User added.";
            txtUser.Text = txtName.Text = txtEmail.Text = "";
            Bind();
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = Db.Query(@"SELECT u.Username, u.FullName, u.Email, r.RoleName,
                                            u.IsEnabled, u.CreatedDate, u.LastLoginDate
                                      FROM AppUsers u INNER JOIN UserRoles r ON u.RoleID=r.RoleID
                                      ORDER BY u.Username");
            ExcelHelper.ExportToExcel(Response, dt, "DFM_Users_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "ToggleEnable")
            {
                Db.Exec("UPDATE AppUsers SET IsEnabled = 1 - IsEnabled WHERE UserID=@id", Db.P("@id", id));
                Bind();
            }
            else if (e.CommandName == "ResetPwd")
            {
                string salt = PasswordHelper.GenerateSalt();
                string hash = PasswordHelper.Hash("Welcome@123", salt);
                Db.Exec("UPDATE AppUsers SET PasswordHash=@h, PasswordSalt=@s WHERE UserID=@id",
                    Db.P("@h", hash), Db.P("@s", salt), Db.P("@id", id));
                lblMsg.Visible = true; lblMsg.Text = "Password reset to Welcome@123.";
                Bind();
            }
        }
    }
}
