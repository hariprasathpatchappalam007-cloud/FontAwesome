using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class JiraConfig : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadConfig();
                BindFields();
            }
        }

        private void LoadConfig()
        {
            // Req 66: default URL https://agile.dib.ae/planner
            JiraConfigInfo cfg = JiraClient.GetConfig();
            txtBase.Text = string.IsNullOrEmpty(cfg.BaseUrl) ? "https://agile.dib.ae/planner" : cfg.BaseUrl;
            txtKey.Text  = string.IsNullOrEmpty(cfg.ProjectKey) ? "DMGT" : cfg.ProjectKey;
            txtUser.Text = cfg.UserName ?? "";
            txtPwd.Attributes["value"] = cfg.Password ?? "";
            litStatus.Text = string.IsNullOrEmpty(cfg.UserName)
                ? "<span class='badge-status badge-pending'>Not configured</span>"
                : "<span class='badge-status badge-approved'>Configured for " + Server.HtmlEncode(cfg.UserName) + "</span>";
        }

        private void BindFields()
        {
            DataTable dt = null;
            try { dt = MastersDAL.GetJiraFields(); } catch { dt = new DataTable(); }
            string fn = (txtFilterName.Text ?? "").Trim();
            string fk = (txtFilterKey.Text ?? "").Trim();
            if (dt.Rows.Count > 0 && (fn.Length > 0 || fk.Length > 0))
            {
                DataView dv = new DataView(dt);
                System.Text.StringBuilder rf = new System.Text.StringBuilder();
                if (fn.Length > 0) rf.Append("FieldName LIKE '%" + fn.Replace("'", "''") + "%'");
                if (fk.Length > 0)
                {
                    if (rf.Length > 0) rf.Append(" AND ");
                    rf.Append("FieldKey LIKE '%" + fk.Replace("'", "''") + "%'");
                }
                dv.RowFilter = rf.ToString();
                gv.DataSource = dv;
            }
            else
            {
                gv.DataSource = dt;
            }
            gv.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            // Req 67-68: Username/Password basic auth, no API token
            MastersDAL.SaveJiraConfigBasic(txtBase.Text.Trim(), txtKey.Text.Trim(),
                txtUser.Text.Trim(), txtPwd.Text);
            lblMsg.Visible = true;
            lblMsg.Text = "JIRA configuration saved.";
            LoadConfig();
        }

        protected void btnFetchFields_Click(object sender, EventArgs e)
        {
            try
            {
                System.Collections.Generic.List<JiraFieldInfo> fields = JiraClient.FetchAllFields();
                int order = 100;
                foreach (JiraFieldInfo f in fields)
                {
                    MastersDAL.UpsertJiraField(f.Key, f.Name, order++, true);
                }
                lblMsg.Visible = true;
                lblMsg.Text = string.Format("Discovered {0} custom field(s) from JIRA.", fields.Count);
                BindFields();
            }
            catch (Exception ex)
            {
                lblMsg.Visible = true;
                lblMsg.Text = "Could not reach JIRA: " + ex.Message;
            }
        }

        protected void btnTest_Click(object sender, EventArgs e)
        {
            try
            {
                JiraConfigInfo cfg = JiraClient.GetConfig();
                string url = cfg.BaseUrl.TrimEnd('/') + "/rest/api/2/myself";
                string user = string.IsNullOrEmpty(cfg.UserName) ? cfg.Email : cfg.UserName;
                string pw   = string.IsNullOrEmpty(cfg.UserName) ? cfg.Token : cfg.Password;
                string body = JiraClient.FetchRaw(url, user, pw);
                lblMsg.Visible = true;
                lblMsg.Text = "Connected. Response: " + (body.Length > 200 ? body.Substring(0, 200) + "..." : body);
            }
            catch (Exception ex)
            {
                lblMsg.Visible = true; lblMsg.Text = "Connection failed: " + ex.Message;
            }
        }

        protected void Filter_Changed(object sender, EventArgs e) { BindFields(); }

        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv.PageIndex = e.NewPageIndex;
            BindFields();
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ToggleVisible")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                DataTable dt = MastersDAL.GetJiraFields();
                foreach (DataRow r in dt.Rows)
                {
                    if (Convert.ToInt32(r["ID"]) == id)
                    {
                        bool currently = Convert.ToBoolean(r["IsVisible"]);
                        MastersDAL.SetJiraFieldVisibility(id, !currently);
                        break;
                    }
                }
                BindFields();
            }
        }
    }
}
