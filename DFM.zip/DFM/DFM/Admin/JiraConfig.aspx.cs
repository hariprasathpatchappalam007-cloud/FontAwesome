using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class JiraConfig : System.Web.UI.Page
    {
        // DMGT field keys (common demand management fields)
        private static readonly System.Collections.Generic.HashSet<string> DmgtFieldKeys = new System.Collections.Generic.HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "customfield_13306","customfield_13307","customfield_13308","customfield_13309","customfield_13310",
            "customfield_13311","customfield_13312","customfield_13313","customfield_13314","customfield_13315",
            "customfield_13316","customfield_13317","customfield_13318","customfield_13319","customfield_13320",
            "customfield_13321","customfield_13322","customfield_13323","customfield_13324","customfield_13325",
            "customfield_13326","customfield_13327","customfield_13328","customfield_13329","customfield_13330",
            "customfield_13331","customfield_13332","customfield_13333","customfield_13334","customfield_13335",
            "customfield_13336","customfield_13337","customfield_13338","customfield_13339","customfield_13340",
            "customfield_13341","customfield_13342","customfield_13343","customfield_13344","customfield_13345",
            "customfield_13346","customfield_13347","customfield_13348","customfield_13349","customfield_13350",
            "customfield_13351","customfield_13352","customfield_13353","customfield_13354","customfield_13355",
            "customfield_13357","customfield_13358","customfield_13359","customfield_13361","customfield_13362",
            "customfield_13363","customfield_13364","customfield_13365","customfield_13366","customfield_13367",
            "customfield_13368","customfield_13369","customfield_13370","customfield_13371","customfield_13373",
            "customfield_13374","customfield_13375","customfield_13376","customfield_13377","customfield_13378",
            "customfield_13379","customfield_13380",
            "customfield_13400","customfield_13401","customfield_13402","customfield_13403","customfield_13404",
            "customfield_13405","customfield_13406","customfield_13407","customfield_13408","customfield_13409",
            "customfield_13410","customfield_13411","customfield_13412","customfield_13413","customfield_13414",
            "customfield_13415","customfield_13416",
            "customfield_14000","customfield_14001",
            "customfield_12603","customfield_12604","customfield_12607","customfield_12609","customfield_12618",
            "customfield_13600","customfield_13601","customfield_13700","customfield_13701","customfield_13702",
            "customfield_13703","customfield_13704","customfield_13705","customfield_13706","customfield_13707",
            "customfield_13708",
            "customfield_12942","customfield_13500","customfield_13305"
        };

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadConfig();
                BindFields();
            }
        }

        private void LoadConfig()
        {
            JiraConfigInfo cfg = JiraClient.GetConfig();
            txtBase.Text = string.IsNullOrEmpty(cfg.BaseUrl) ? "https://agile.dib.ae/planner" : cfg.BaseUrl;
            txtKey.Text  = string.IsNullOrEmpty(cfg.ProjectKey) ? "DMGT" : cfg.ProjectKey;
            txtUser.Text = cfg.UserName ?? "";
            txtPwd.Attributes["value"] = cfg.Password ?? "";
            litStatus.Text = string.IsNullOrEmpty(cfg.UserName)
                ? "<span class='badge-status badge-pending'>Not configured</span>"
                : "<span class='badge-status badge-approved'>Configured for " + Server.HtmlEncode(cfg.UserName) + "</span>";
        }

        private void BindFields()
        {
            DataTable dt = null;
            try { dt = MastersDAL.GetJiraFields(); } catch { dt = new DataTable(); }

            // Split into DMGT and DIBITP tables
            DataTable dmgtDt = dt.Clone();
            DataTable dibitpDt = dt.Clone();
            foreach (DataRow r in dt.Rows)
            {
                string key = r["FieldKey"] == DBNull.Value ? "" : r["FieldKey"].ToString();
                if (DmgtFieldKeys.Contains(key))
                    dmgtDt.ImportRow(r);
                else
                    dibitpDt.ImportRow(r);
            }

            // Apply DMGT filters
            string fnDmgt = (txtFilterNameDMGT.Text ?? "").Trim();
            string fkDmgt = (txtFilterKeyDMGT.Text ?? "").Trim();
            if (dmgtDt.Rows.Count > 0 && (fnDmgt.Length > 0 || fkDmgt.Length > 0))
            {
                DataView dv = new DataView(dmgtDt);
                var rf = new System.Text.StringBuilder();
                if (fnDmgt.Length > 0) rf.Append("FieldName LIKE '%" + fnDmgt.Replace("'", "''") + "%'");
                if (fkDmgt.Length > 0) { if (rf.Length > 0) rf.Append(" AND "); rf.Append("FieldKey LIKE '%" + fkDmgt.Replace("'", "''") + "%'"); }
                dv.RowFilter = rf.ToString();
                gvDMGT.DataSource = dv;
            }
            else
            {
                gvDMGT.DataSource = dmgtDt;
            }
            gvDMGT.DataBind();

            // Apply DIBITP filters
            string fnDibitp = (txtFilterNameDIBITP.Text ?? "").Trim();
            string fkDibitp = (txtFilterKeyDIBITP.Text ?? "").Trim();
            if (dibitpDt.Rows.Count > 0 && (fnDibitp.Length > 0 || fkDibitp.Length > 0))
            {
                DataView dv2 = new DataView(dibitpDt);
                var rf2 = new System.Text.StringBuilder();
                if (fnDibitp.Length > 0) rf2.Append("FieldName LIKE '%" + fnDibitp.Replace("'", "''") + "%'");
                if (fkDibitp.Length > 0) { if (rf2.Length > 0) rf2.Append(" AND "); rf2.Append("FieldKey LIKE '%" + fkDibitp.Replace("'", "''") + "%'"); }
                dv2.RowFilter = rf2.ToString();
                gvDIBITP.DataSource = dv2;
            }
            else
            {
                gvDIBITP.DataSource = dibitpDt;
            }
            gvDIBITP.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            MastersDAL.SaveJiraConfigBasic(txtBase.Text.Trim(), txtKey.Text.Trim(),
                txtUser.Text.Trim(), txtPwd.Text);
            lblMsg.Visible = true;
            lblMsg.Text = "JIRA configuration saved.";
            LoadConfig();
        }

        protected void btnFetchFields_Click(object sender, EventArgs e)
        {
            try
            {
                System.Collections.Generic.List<JiraFieldInfo> fields = JiraClient.FetchAllFields();
                int order = 100;
                foreach (JiraFieldInfo f in fields)
                {
                    MastersDAL.UpsertJiraField(f.Key, f.Name, order++, true);
                }
                lblMsg.Visible = true;
                lblMsg.Text = string.Format("Discovered {0} custom field(s) from JIRA.", fields.Count);
                BindFields();
            }
            catch (Exception ex)
            {
                lblMsg.Visible = true;
                lblMsg.Text = "Could not reach JIRA: " + ex.Message;
            }
        }

        protected void btnTest_Click(object sender, EventArgs e)
        {
            try
            {
                JiraConfigInfo cfg = JiraClient.GetConfig();
                string url = cfg.BaseUrl.TrimEnd('/') + "/rest/api/2/myself";
                string user = string.IsNullOrEmpty(cfg.UserName) ? cfg.Email : cfg.UserName;
                string pw   = string.IsNullOrEmpty(cfg.UserName) ? cfg.Token : cfg.Password;
                string body = JiraClient.FetchRaw(url, user, pw);
                lblMsg.Visible = true;
                lblMsg.Text = "Connected. Response: " + (body.Length > 200 ? body.Substring(0, 200) + "..." : body);
            }
            catch (Exception ex)
            {
                lblMsg.Visible = true; lblMsg.Text = "Connection failed: " + ex.Message;
            }
        }

        protected void Filter_Changed(object sender, EventArgs e) { BindFields(); }

        protected void gvDMGT_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvDMGT.PageIndex = e.NewPageIndex;
            BindFields();
        }

        protected void gvDIBITP_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvDIBITP.PageIndex = e.NewPageIndex;
            BindFields();
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ToggleVisible")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                DataTable dt = MastersDAL.GetJiraFields();
                foreach (DataRow r in dt.Rows)
                {
                    if (Convert.ToInt32(r["ID"]) == id)
                    {
                        bool currently = Convert.ToBoolean(r["IsVisible"]);
                        MastersDAL.SetJiraFieldVisibility(id, !currently);
                        break;
                    }
                }
                BindFields();
            }
        }
    }
}
