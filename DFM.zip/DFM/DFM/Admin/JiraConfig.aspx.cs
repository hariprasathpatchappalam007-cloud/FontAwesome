using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class JiraConfig : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadConfig();
                BindFields();
            }
        }

        private void LoadConfig()
        {
            var row = MastersDAL.GetJiraConfig();
            if (row != null)
            {
                txtBase.Text = row["BaseUrl"] == DBNull.Value ? "" : row["BaseUrl"].ToString();
                txtKey.Text = row["ProjectKey"] == DBNull.Value ? "" : row["ProjectKey"].ToString();
                txtEmail.Text = row["UserEmail"] == DBNull.Value ? "" : row["UserEmail"].ToString();
                txtToken.Attributes["value"] = row["ApiToken"] == DBNull.Value ? "" : row["ApiToken"].ToString();
            }
        }

        private void BindFields()
        {
            gv.DataSource = MastersDAL.GetJiraFields();
            gv.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            MastersDAL.SaveJiraConfig(txtBase.Text.Trim(), txtEmail.Text.Trim(),
                txtToken.Text, txtKey.Text.Trim());
            lblMsg.Visible = true; lblMsg.Text = "JIRA configuration saved.";
        }

        protected void btnFetchFields_Click(object sender, EventArgs e)
        {
            try
            {
                System.Collections.Generic.List<JiraFieldInfo> fields = JiraClient.FetchAllFields();
                int order = 100;
                foreach (JiraFieldInfo f in fields)
                {
                    MastersDAL.UpsertJiraField(f.Key, f.Name, order++, true);
                }
                lblMsg.Visible = true;
                lblMsg.Text = string.Format("Discovered {0} custom field(s) from JIRA.", fields.Count);
                BindFields();
            }
            catch (Exception ex)
            {
                lblMsg.Visible = true;
                lblMsg.Text = "Could not reach JIRA: " + ex.Message;
            }
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ToggleVisible")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                var dt = MastersDAL.GetJiraFields();
                foreach (DataRow r in dt.Rows)
                {
                    if (Convert.ToInt32(r["ID"]) == id)
                    {
                        bool currently = Convert.ToBoolean(r["IsVisible"]);
                        MastersDAL.SetJiraFieldVisibility(id, !currently);
                        break;
                    }
                }
                BindFields();
            }
        }
    }
}
