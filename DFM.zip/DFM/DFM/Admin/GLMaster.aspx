<%@ Page Title="GL Master" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="GLMaster.aspx.cs" Inherits="DFM.Admin.GLMaster" %>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">GL Master</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-edit"></span> Add / Edit GL</h3>
        <asp:HiddenField ID="hfMode" runat="server" Value="ADD" />
        <asp:HiddenField ID="hfEditId" runat="server" Value="0" />
        <div class="form-grid-5">
            <div class="form-group">
                <label>GL Code</label>
                <asp:TextBox ID="txtGLCode" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group col-span-2">
                <label>Description</label>
                <asp:TextBox ID="txtDesc" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Active</label>
                <asp:CheckBox ID="chkActive" runat="server" Checked="true" />
            </div>
            <div class="form-group" style="align-self:end;">
                <div class="toolbar" style="margin:0;">
                    <asp:LinkButton ID="btnSave" runat="server" CssClass="btn btn-primary" OnClick="btnSave_Click">
                        <span class="glyphicon glyphicon-floppy-disk"></span> Save
                    </asp:LinkButton>
                    <asp:LinkButton ID="btnReset" runat="server" CssClass="btn btn-secondary" OnClick="btnReset_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-refresh"></span> Reset
                    </asp:LinkButton>
                </div>
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3>GL Entries</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
                DataKeyNames="GLID" OnRowCommand="gv_RowCommand">
                <Columns>
                    <asp:BoundField DataField="GLID" HeaderText="ID" />
                    <asp:BoundField DataField="GLCode" HeaderText="GL Code" />
                    <asp:BoundField DataField="Description" HeaderText="Description" />
                    <asp:CheckBoxField DataField="IsActive" HeaderText="Active" />
                    <asp:TemplateField HeaderText="Actions" ItemStyle-CssClass="text-center">
                        <ItemTemplate>
                            <asp:LinkButton runat="server" CssClass="btn btn-xs btn-info"
                                CommandName="EditRow" CommandArgument='<%# Eval("GLID") %>' ToolTip="Edit">
                                <span class="glyphicon glyphicon-pencil"></span>
                            </asp:LinkButton>
                            <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger"
                                CommandName="DeleteRow" CommandArgument='<%# Eval("GLID") %>'
                                OnClientClick="return confirm('Delete this GL entry?');" ToolTip="Delete">
                                <span class="glyphicon glyphicon-trash"></span>
                            </asp:LinkButton>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:12px;">No GL entries found.</div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
