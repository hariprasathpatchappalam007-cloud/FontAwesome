<%@ Page Title="PET Cost Type" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="PetCostType.aspx.cs" Inherits="DFM.Admin.PetCostType" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-tags"></span> PET Cost Type</h1>

    <div class="toolbar">
        <div class="spacer"></div>
        <asp:Button ID="btnExport" runat="server" Text="Export to Excel"
            CssClass="btn btn-success" OnClick="btnExport_Click" />
    </div>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-edit"></span> Add / Edit category</h3>
        <asp:HiddenField ID="hfId" runat="server" Value="0" />
        <div class="form-row">
            <div class="form-group" style="flex:0 0 110px;">
                <label>Sort Order</label>
                <asp:TextBox ID="txtOrder" runat="server" CssClass="form-control" Text="100" />
            </div>
            <div class="form-group">
                <label>Category</label>
                <asp:TextBox ID="txtCategory" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group" style="flex:0 0 130px;">
                <label>Active</label>
                <asp:CheckBox ID="chkActive" runat="server" Checked="true" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnSave_Click" />
            <asp:Button ID="btnReset" runat="server" Text="Reset" CssClass="btn btn-secondary"
                OnClick="btnReset_Click" CausesValidation="false" />
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list"></span> Categories</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table"
            GridLines="None" DataKeyNames="CostTypeID" OnRowCommand="gv_RowCommand">
            <Columns>
                <asp:BoundField DataField="SortOrder" HeaderText="#" />
                <asp:BoundField DataField="Category" HeaderText="Category" />
                <asp:CheckBoxField DataField="IsActive" HeaderText="Active" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="EditRow"
                            CommandArgument='<%# Eval("CostTypeID") %>'>
                            <span class="glyphicon glyphicon-pencil"></span> Edit
                        </asp:LinkButton>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-danger" CommandName="DeleteRow"
                            CommandArgument='<%# Eval("CostTypeID") %>'
                            OnClientClick="return confirm('Delete this category?');">
                            <span class="glyphicon glyphicon-trash"></span> Delete
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
