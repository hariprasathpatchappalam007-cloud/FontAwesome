<%@ Page Title="User Roles" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="UserRoles.aspx.cs" Inherits="DFM.Admin.UserRoles" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-user"></span> User Role Definition</h1>

    <p class="text-muted">
        Each user can be a <strong>Requestor</strong>, an <strong>Approver</strong>, or both.
        Self-approval is blocked at the workflow level. Users with both roles can switch between them
        from the user icon at the top of the application.
    </p>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list-alt"></span> Assignments</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            OnRowCommand="gv_RowCommand">
            <Columns>
                <asp:BoundField DataField="Username" HeaderText="Username" />
                <asp:BoundField DataField="FullName" HeaderText="Full Name" />
                <asp:BoundField DataField="Email" HeaderText="Email" />
                <asp:TemplateField HeaderText="Requestor">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CommandName="Toggle"
                            CommandArgument='<%# Eval("Username") + "|Requestor" %>'
                            CssClass='<%# Convert.ToInt32(Eval("IsRequestor")) == 1 ? "btn btn-sm btn-success" : "btn btn-sm btn-secondary" %>'>
                            <span class='glyphicon <%# Convert.ToInt32(Eval("IsRequestor")) == 1 ? "glyphicon-ok" : "glyphicon-remove" %>'></span>
                            <%# Convert.ToInt32(Eval("IsRequestor")) == 1 ? " Requestor" : " Off" %>
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Approver">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CommandName="Toggle"
                            CommandArgument='<%# Eval("Username") + "|Approver" %>'
                            CssClass='<%# Convert.ToInt32(Eval("IsApprover")) == 1 ? "btn btn-sm btn-success" : "btn btn-sm btn-secondary" %>'>
                            <span class='glyphicon <%# Convert.ToInt32(Eval("IsApprover")) == 1 ? "glyphicon-ok" : "glyphicon-remove" %>'></span>
                            <%# Convert.ToInt32(Eval("IsApprover")) == 1 ? " Approver" : " Off" %>
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
