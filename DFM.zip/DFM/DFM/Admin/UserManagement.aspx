<%@ Page Title="User Management" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="UserManagement.aspx.cs" Inherits="DFM.Admin.UserManagement" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">User Management</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3>Add user (Forms login)</h3>
        <div class="form-row">
            <div class="form-group"><label>Username</label><asp:TextBox ID="txtUser" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Full name</label><asp:TextBox ID="txtName" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Email</label><asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" /></div>
            <div class="form-group">
                <label>Role</label>
                <asp:DropDownList ID="ddlRole" runat="server" CssClass="form-control">
                    <asp:ListItem>User</asp:ListItem>
                    <asp:ListItem>Approver</asp:ListItem>
                    <asp:ListItem>Admin</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group"><label>Initial password</label>
                <asp:TextBox ID="txtPwd" runat="server" CssClass="form-control" Text="Welcome@123" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Add User" CssClass="btn btn-primary" OnClick="btnSave_Click" />
            <asp:Button ID="btnExport" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
        </div>
    </div>

    <div class="card-panel">
        <h3>Users</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            DataKeyNames="UserID" OnRowCommand="gv_RowCommand">
            <Columns>
                <asp:BoundField DataField="Username" HeaderText="Username" />
                <asp:BoundField DataField="FullName" HeaderText="Full Name" />
                <asp:BoundField DataField="Email" HeaderText="Email" />
                <asp:BoundField DataField="RoleName" HeaderText="Role" />
                <asp:CheckBoxField DataField="IsEnabled" HeaderText="Enabled" />
                <asp:BoundField DataField="LastLoginDate" HeaderText="Last Login" DataFormatString="{0:dd-MMM-yy HH:mm}" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-secondary" CommandName="ToggleEnable"
                            CommandArgument='<%# Eval("UserID") %>' Text="Toggle" />
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-warning" CommandName="ResetPwd"
                            CommandArgument='<%# Eval("UserID") %>' Text="Reset Pwd"
                            OnClientClick="return confirm('Reset password to Welcome@123?');" />
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
