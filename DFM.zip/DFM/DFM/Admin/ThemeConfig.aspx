<%@ Page Title="Theme Configuration" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ThemeConfig.aspx.cs" Inherits="DFM.Admin.ThemeConfig" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">Theme &amp; Look</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3>Choose a theme</h3>
        <p class="text-muted">Click any tile to <strong>preview</strong>. Click "Apply" to save it as your default.</p>
        <div class="theme-grid">
            <div class="theme-tile t-ocean"    data-name="ocean"    onclick="DFM.previewTheme('ocean')">Ocean</div>
            <div class="theme-tile t-sunset"   data-name="sunset"   onclick="DFM.previewTheme('sunset')">Sunset</div>
            <div class="theme-tile t-forest"   data-name="forest"   onclick="DFM.previewTheme('forest')">Forest</div>
            <div class="theme-tile t-grape"    data-name="grape"    onclick="DFM.previewTheme('grape')">Grape</div>
            <div class="theme-tile t-midnight" data-name="midnight" onclick="DFM.previewTheme('midnight')">Midnight</div>
        </div>

        <div class="toolbar mt-3">
            <asp:HiddenField ID="hfTheme" runat="server" Value="ocean" />
            <asp:Button ID="btnApply" runat="server" Text="Apply preview" CssClass="btn btn-primary"
                OnClientClick="document.getElementById('hfTheme').value = document.documentElement.getAttribute('data-theme') || 'ocean';"
                OnClick="btnApply_Click" />
            <asp:Button ID="btnRevert" runat="server" Text="Revert" CssClass="btn btn-secondary"
                CausesValidation="false" OnClientClick="DFM.restoreTheme(); return false;" />
        </div>
    </div>

    <div class="card-panel">
        <h3>Live preview</h3>
        <div class="kpi-grid" style="margin-bottom:8px;">
            <div class="kpi-card kpi-blue">
                <div class="kpi-label">Sample KPI</div>
                <div class="kpi-value">12,345</div>
            </div>
            <div class="kpi-card kpi-orange">
                <div class="kpi-label">Sample utilized</div>
                <div class="kpi-value">87%</div>
            </div>
            <div class="kpi-card kpi-green">
                <div class="kpi-label">Sample available</div>
                <div class="kpi-value">654</div>
            </div>
        </div>
        <p>Page content will look like this with the selected theme.</p>
    </div>
    <script>
        $(function () {
            // Mark current selected
            var cur = document.documentElement.getAttribute('data-theme') || 'ocean';
            $('.theme-tile').removeClass('selected').filter('[data-name="' + cur + '"]').addClass('selected');
            $('.theme-tile').on('click', function () {
                $('.theme-tile').removeClass('selected'); $(this).addClass('selected');
            });
        });
    </script>
</asp:Content>
