using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class PetDepartment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        private void Bind() { gv.DataSource = PetDAL.GetDepartments(); gv.DataBind(); }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int id; if (!int.TryParse(hfId.Value, out id)) id = 0;
            string dept = txtDept.Text == null ? "" : txtDept.Text.Trim();
            string prefix = txtPrefix.Text == null ? "" : txtPrefix.Text.Trim();
            if (dept.Length == 0 || prefix.Length == 0)
            {
                lblMsg.Visible = true; lblMsg.Text = "Department and prefix are required.";
                return;
            }
            PetDAL.UpsertDepartment(id, dept, prefix, chkActive.Checked);
            ClearForm();
            lblMsg.Visible = true; lblMsg.Text = "Saved.";
            Bind();
        }

        protected void btnReset_Click(object sender, EventArgs e) { ClearForm(); }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            ExcelHelper.ExportToExcel(Response, PetDAL.GetDepartments(),
                "PET_Departments_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "DeleteRow") { PetDAL.DeleteDepartment(id); Bind(); }
            else if (e.CommandName == "EditRow")
            {
                DataTable dt = PetDAL.GetDepartments();
                foreach (DataRow r in dt.Rows)
                {
                    if (Convert.ToInt32(r["DepartmentID"]) == id)
                    {
                        hfId.Value = id.ToString();
                        txtDept.Text = r["Department"].ToString();
                        txtPrefix.Text = r["Prefix"].ToString();
                        chkActive.Checked = Convert.ToBoolean(r["IsActive"]);
                        break;
                    }
                }
            }
        }

        private void ClearForm()
        {
            hfId.Value = "0"; txtDept.Text = ""; txtPrefix.Text = "";
            chkActive.Checked = true;
        }
    }
}
