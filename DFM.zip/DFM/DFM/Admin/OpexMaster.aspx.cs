using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class OpexMaster : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }
        private void Bind() { gv.DataSource = MastersDAL.GetOpex(txtSearch.Text); gv.DataBind(); }
        protected void btnSearch_Click(object sender, EventArgs e) { Bind(); }
        protected void btnImport_Click(object sender, EventArgs e)
        {
            int n = CsvImporter.ImportOpexFromRequirement(AuthHelper.CurrentUser);
            ShowMsg(string.Format("Imported / updated {0} OPEX rows from Requirement folder.", n));
            Bind();
        }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = MastersDAL.GetOpex(txtSearch.Text);
            ExcelHelper.ExportToExcel(Response, dt, "OPEX_Master_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string id = txtId.Text.Trim();
            if (id.Length == 0) { ShowMsg("OPEX ID is required."); return; }
            MastersDAL.UpsertOpex(id, txtDesc.Text.Trim(),
                ParseD(txtBudget.Text), ParseD(txtUtil.Text), ParseD(txtAvail.Text),
                ParseD(txtLocked.Text), ParseD(txtAfterLock.Text),
                ParseD(txtClaim.Text), ParseD(txtNet.Text),
                AuthHelper.CurrentUser);
            ShowMsg("OPEX entry saved.");
            ClearForm(); Bind();
        }
        protected void btnReset_Click(object sender, EventArgs e) { ClearForm(); }
        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string id = e.CommandArgument.ToString();
            if (e.CommandName == "DeleteRow") { MastersDAL.DeleteOpex(id); ShowMsg("Deleted " + id); Bind(); }
            else if (e.CommandName == "EditRow")
            {
                var row = MastersDAL.GetOpexById(id);
                if (row == null) return;
                txtId.Text = row["OpexID"].ToString();
                txtDesc.Text = row["Description"].ToString();
                txtBudget.Text = Conv(row["Budget"]);
                txtUtil.Text = Conv(row["Utilization"]);
                txtAvail.Text = Conv(row["AvailableBudget"]);
                txtLocked.Text = Conv(row["LockedAmount"]);
                txtAfterLock.Text = Conv(row["BudgetAfterLockedAmount"]);
                txtClaim.Text = Conv(row["ClaimAmount"]);
                txtNet.Text = Conv(row["NetBalance"]);
            }
        }
        private void ClearForm()
        {
            txtId.Text = txtDesc.Text = "";
            txtBudget.Text = txtUtil.Text = txtAvail.Text = txtLocked.Text = "";
            txtAfterLock.Text = txtClaim.Text = txtNet.Text = "";
        }
        private void ShowMsg(string m) { lblMsg.Visible = true; lblMsg.Text = m; }
        private static decimal ParseD(string s)
        {
            return CsvImporter.ParseDecimal(s == null ? "" : s);
        }
        private static string Conv(object o)
        {
            if (o == DBNull.Value) return "";
            return Convert.ToDecimal(o).ToString("N2");
        }
    }
}
