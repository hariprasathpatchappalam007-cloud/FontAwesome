<%@ Page Title="CAPEX Master" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="CapexMaster.aspx.cs" Inherits="DFM.Admin.CapexMaster" %>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">CAPEX Master</h1>

    <div class="toolbar">
        <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" Style="max-width:340px;"
            placeholder="Search by ID or Description..." />
        <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-primary" OnClick="btnSearch_Click" />
        <asp:Button ID="btnImport" runat="server" Text="Import from Requirement Folder"
            CssClass="btn btn-secondary" OnClick="btnImport_Click" />
        <div class="spacer"></div>
        <asp:Button ID="btnExport" runat="server" Text="Export to Excel"
            CssClass="btn btn-success" OnClick="btnExport_Click" />
    </div>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3>Add / Edit CAPEX</h3>
        <asp:HiddenField ID="hfMode" runat="server" Value="ADD" />
        <div class="form-row">
            <div class="form-group">
                <label>CAPEX ID</label>
                <asp:TextBox ID="txtId" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group" style="flex:2 1 400px;">
                <label>Description</label>
                <asp:TextBox ID="txtDesc" runat="server" CssClass="form-control" />
            </div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Budget</label><asp:TextBox ID="txtBudget" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Utilization</label><asp:TextBox ID="txtUtil" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Available</label><asp:TextBox ID="txtAvail" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Locked Amt</label><asp:TextBox ID="txtLocked" runat="server" CssClass="form-control" /></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Budget after Locked</label><asp:TextBox ID="txtAfterLock" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Claim Amount</label><asp:TextBox ID="txtClaim" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Net Balance</label><asp:TextBox ID="txtNet" runat="server" CssClass="form-control" /></div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnSave_Click" />
            <asp:Button ID="btnReset" runat="server" Text="Reset" CssClass="btn btn-secondary" OnClick="btnReset_Click" CausesValidation="false" />
        </div>
    </div>

    <div class="card-panel">
        <h3>CAPEX entries</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
                DataKeyNames="CapexID" OnRowCommand="gv_RowCommand">
                <Columns>
                    <asp:BoundField DataField="CapexID" HeaderText="CAPEX ID" />
                    <asp:BoundField DataField="Description" HeaderText="Description" />
                    <asp:BoundField DataField="Budget" HeaderText="Budget" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="Utilization" HeaderText="Utilization" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="AvailableBudget" HeaderText="Available" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="LockedAmount" HeaderText="Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="BudgetAfterLockedAmount" HeaderText="After Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="ClaimAmount" HeaderText="Claim" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="NetBalance" HeaderText="Net Balance" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:TemplateField HeaderText="Action">
                        <ItemTemplate>
                            <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="EditRow"
                                CommandArgument='<%# Eval("CapexID") %>' Text="Edit" />
                            <asp:LinkButton runat="server" CssClass="btn btn-sm btn-danger" CommandName="DeleteRow"
                                CommandArgument='<%# Eval("CapexID") %>' Text="Delete"
                                OnClientClick="return confirm('Delete this CAPEX?');" />
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:18px;">
                        No CAPEX entries. Use "Import from Requirement Folder" to load CAPEX.csv.
                    </div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
