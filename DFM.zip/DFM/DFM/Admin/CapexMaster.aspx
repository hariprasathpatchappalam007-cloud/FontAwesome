<%@ Page Title="CAPEX Master" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="CapexMaster.aspx.cs" Inherits="DFM.Admin.CapexMaster" %>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">CAPEX Master</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="filter-row">
        <div class="form-group col-span-3">
            <label>Search</label>
            <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control"
                placeholder="Search by ID or Description..." />
        </div>
        <div class="form-group">
            <label>&nbsp;</label>
            <asp:LinkButton ID="btnSearch" runat="server" CssClass="btn btn-primary" OnClick="btnSearch_Click">
                <span class="glyphicon glyphicon-search"></span> Search
            </asp:LinkButton>
        </div>
        <div class="form-group">
            <label>&nbsp;</label>
            <div class="toolbar" style="margin:0;">
                <asp:LinkButton ID="btnImport" runat="server" CssClass="btn btn-secondary" OnClick="btnImport_Click" ToolTip="Import from Requirement Folder">
                    <span class="glyphicon glyphicon-import"></span> Import CSV
                </asp:LinkButton>
                <asp:LinkButton ID="btnExport" runat="server" CssClass="btn btn-success" OnClick="btnExport_Click">
                    <span class="glyphicon glyphicon-export"></span> Excel
                </asp:LinkButton>
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-edit"></span> Add / Edit CAPEX</h3>
        <asp:HiddenField ID="hfMode" runat="server" Value="ADD" />
        <%-- Row 1: 5 controls --%>
        <div class="form-grid-5">
            <div class="form-group">
                <label>CAPEX ID</label>
                <asp:TextBox ID="txtId" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group col-span-4">
                <label>Description</label>
                <asp:TextBox ID="txtDesc" runat="server" CssClass="form-control" />
            </div>
        </div>
        <%-- Row 2: 5 numeric fields --%>
        <div class="form-grid-5">
            <div class="form-group"><label>Budget</label><asp:TextBox ID="txtBudget" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Utilization</label><asp:TextBox ID="txtUtil" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Available</label><asp:TextBox ID="txtAvail" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Locked Amount</label><asp:TextBox ID="txtLocked" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>After Locked</label><asp:TextBox ID="txtAfterLock" runat="server" CssClass="form-control" /></div>
        </div>
        <%-- Row 3: 5 cols (Claim, Net, then actions on the right) --%>
        <div class="form-grid-5">
            <div class="form-group"><label>Claim Amount</label><asp:TextBox ID="txtClaim" runat="server" CssClass="form-control" /></div>
            <div class="form-group"><label>Net Balance</label><asp:TextBox ID="txtNet" runat="server" CssClass="form-control" /></div>
            <div class="form-group col-span-3" style="align-self:end;">
                <label>&nbsp;</label>
                <div class="toolbar" style="margin:0;">
                    <asp:LinkButton ID="btnSave" runat="server" CssClass="btn btn-primary" OnClick="btnSave_Click">
                        <span class="glyphicon glyphicon-floppy-disk"></span> Save
                    </asp:LinkButton>
                    <asp:LinkButton ID="btnReset" runat="server" CssClass="btn btn-secondary" OnClick="btnReset_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-refresh"></span> Reset
                    </asp:LinkButton>
                </div>
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3>CAPEX entries</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
                DataKeyNames="CapexID" OnRowCommand="gv_RowCommand">
                <Columns>
                    <asp:BoundField DataField="CapexID" HeaderText="CAPEX ID" />
                    <asp:BoundField DataField="Description" HeaderText="Description" />
                    <asp:BoundField DataField="Budget" HeaderText="Budget" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="Utilization" HeaderText="Utilization" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="AvailableBudget" HeaderText="Available" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="LockedAmount" HeaderText="Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="BudgetAfterLockedAmount" HeaderText="After Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="ClaimAmount" HeaderText="Claim" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="NetBalance" HeaderText="Net Balance" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:TemplateField HeaderText="Action">
                        <ItemStyle CssClass="action-cell" />
                        <ItemTemplate>
                            <div class="action-buttons">
                            <asp:LinkButton runat="server" CssClass="btn btn-xs" CommandName="EditRow"
                                CommandArgument='<%# Eval("CapexID") %>'>
                                <span class="glyphicon glyphicon-pencil"></span> Edit
                            </asp:LinkButton>
                            <!-- Req 45-46: Workflow History link -->
                            <a class="btn btn-xs btn-secondary"
                               href='<%# ResolveUrl("~/Forms/SourceHistory.aspx?type=CAPEX&id=" + Eval("CapexID")) %>'>
                                <span class="glyphicon glyphicon-time"></span> History
                            </a>
                            <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger" CommandName="DeleteRow"
                                CommandArgument='<%# Eval("CapexID") %>'
                                OnClientClick="return confirm('Delete this CAPEX?');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </asp:LinkButton>
                            </div>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:18px;">
                        No CAPEX entries. Use "Import from Requirement Folder" to load CAPEX.csv.
                    </div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
