<%@ Page Title="PET Department" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="PetDepartment.aspx.cs" Inherits="DFM.Admin.PetDepartment" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-th-list"></span> PET Department</h1>

    <div class="toolbar">
        <div class="spacer"></div>
        <asp:Button ID="btnExport" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
    </div>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-edit"></span> Add / Edit department</h3>
        <asp:HiddenField ID="hfId" runat="server" Value="0" />
        <div class="form-row">
            <div class="form-group">
                <label>Department</label>
                <asp:TextBox ID="txtDept" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group" style="flex:0 0 180px;">
                <label>ID Prefix</label>
                <asp:TextBox ID="txtPrefix" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group" style="flex:0 0 130px;">
                <label>Active</label>
                <asp:CheckBox ID="chkActive" runat="server" Checked="true" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnSave_Click" />
            <asp:Button ID="btnReset" runat="server" Text="Reset" CssClass="btn btn-secondary"
                OnClick="btnReset_Click" CausesValidation="false" />
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list"></span> Departments</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table"
            GridLines="None" DataKeyNames="DepartmentID" OnRowCommand="gv_RowCommand">
            <Columns>
                <asp:BoundField DataField="Department" HeaderText="Department" />
                <asp:BoundField DataField="Prefix" HeaderText="Prefix" />
                <asp:CheckBoxField DataField="IsActive" HeaderText="Active" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="EditRow"
                            CommandArgument='<%# Eval("DepartmentID") %>'>
                            <span class="glyphicon glyphicon-pencil"></span> Edit
                        </asp:LinkButton>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-danger" CommandName="DeleteRow"
                            CommandArgument='<%# Eval("DepartmentID") %>'
                            OnClientClick="return confirm('Delete this department?');">
                            <span class="glyphicon glyphicon-trash"></span> Delete
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
