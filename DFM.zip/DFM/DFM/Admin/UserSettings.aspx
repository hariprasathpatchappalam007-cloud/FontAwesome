<%@ Page Title="User Settings" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="UserSettings.aspx.cs" Inherits="DFM.Admin.UserSettings" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">User Settings</h1>
    <p class="text-muted">One-time setup for your account preferences. Update any time below.</p>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3>Preferences</h3>
        <div class="form-row">
            <div class="form-group">
                <label>Theme</label>
                <asp:DropDownList ID="ddlTheme" runat="server" CssClass="form-control">
                    <asp:ListItem Value="ocean">Ocean</asp:ListItem>
                    <asp:ListItem Value="sunset">Sunset</asp:ListItem>
                    <asp:ListItem Value="forest">Forest</asp:ListItem>
                    <asp:ListItem Value="grape">Grape</asp:ListItem>
                    <asp:ListItem Value="midnight">Midnight</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>Font Size</label>
                <asp:DropDownList ID="ddlFont" runat="server" CssClass="form-control">
                    <asp:ListItem>Normal</asp:ListItem>
                    <asp:ListItem>Large</asp:ListItem>
                    <asp:ListItem>Extra Large</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>Default landing page</label>
                <asp:DropDownList ID="ddlPage" runat="server" CssClass="form-control">
                    <asp:ListItem Value="~/Default.aspx">Dashboard</asp:ListItem>
                    <asp:ListItem Value="~/Forms/ProjectList.aspx">Project List</asp:ListItem>
                    <asp:ListItem Value="~/Forms/MyApprovals.aspx">My Approvals</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group" style="flex:0 0 200px;">
                <label>Notifications</label>
                <asp:CheckBox ID="chkNotif" runat="server" Text=" Enable email notifications" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSave" runat="server" Text="Save" CssClass="btn btn-primary" OnClick="btnSave_Click" />
        </div>
    </div>
</asp:Content>
