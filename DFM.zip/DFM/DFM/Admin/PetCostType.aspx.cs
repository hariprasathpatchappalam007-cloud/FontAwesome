using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class PetCostType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        private void Bind()
        {
            gv.DataSource = PetDAL.GetCostTypes();
            gv.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            int id; if (!int.TryParse(hfId.Value, out id)) id = 0;
            int order; if (!int.TryParse(txtOrder.Text, out order)) order = 100;
            string cat = txtCategory.Text == null ? "" : txtCategory.Text.Trim();
            if (cat.Length == 0) { lblMsg.Visible = true; lblMsg.Text = "Category is required."; return; }
            PetDAL.UpsertCostType(id, order, cat, chkActive.Checked);
            ClearForm();
            lblMsg.Visible = true; lblMsg.Text = "Saved.";
            Bind();
        }

        protected void btnReset_Click(object sender, EventArgs e) { ClearForm(); }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = PetDAL.GetCostTypes();
            ExcelHelper.ExportToExcel(Response, dt, "PET_CostTypes_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            if (e.CommandName == "DeleteRow") { PetDAL.DeleteCostType(id); Bind(); }
            else if (e.CommandName == "EditRow")
            {
                DataTable dt = PetDAL.GetCostTypes();
                foreach (DataRow r in dt.Rows)
                {
                    if (Convert.ToInt32(r["CostTypeID"]) == id)
                    {
                        hfId.Value = id.ToString();
                        txtOrder.Text = r["SortOrder"] == DBNull.Value ? "100" : r["SortOrder"].ToString();
                        txtCategory.Text = r["Category"].ToString();
                        chkActive.Checked = Convert.ToBoolean(r["IsActive"]);
                        break;
                    }
                }
            }
        }

        private void ClearForm()
        {
            hfId.Value = "0"; txtOrder.Text = "100"; txtCategory.Text = "";
            chkActive.Checked = true;
        }
    }
}
