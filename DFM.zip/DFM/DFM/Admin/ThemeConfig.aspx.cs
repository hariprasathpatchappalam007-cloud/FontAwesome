using System;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Admin
{
    public partial class ThemeConfig : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var s = MastersDAL.GetUserSettings(AuthHelper.CurrentUser);
                if (s != null) hfTheme.Value = s["ThemeName"].ToString();
            }
        }

        protected void btnApply_Click(object sender, EventArgs e)
        {
            string theme = string.IsNullOrEmpty(hfTheme.Value) ? "ocean" : hfTheme.Value;
            var existing = MastersDAL.GetUserSettings(AuthHelper.CurrentUser);
            string font = existing == null ? "Large" : existing["FontSize"].ToString();
            string defaultPage = existing == null || existing["DefaultPage"] == DBNull.Value ? "" : existing["DefaultPage"].ToString();
            bool notif = existing == null ? true : Convert.ToBoolean(existing["Notifications"]);
            MastersDAL.SaveUserSettings(AuthHelper.CurrentUser, theme, font, defaultPage, notif);
            lblMsg.Visible = true;
            lblMsg.Text = "Theme '" + theme + "' applied as your default.";
            ScriptManager_Register("DFM.applyTheme('" + theme + "');");
        }

        private void ScriptManager_Register(string js)
        {
            ClientScript.RegisterStartupScript(GetType(), "applyTheme",
                "<script>" + js + "</script>", false);
        }
    }
}
