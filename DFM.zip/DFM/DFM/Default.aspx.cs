using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Text;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM
{
    public partial class DefaultPage : System.Web.UI.Page
    {
        public string JsCapexBudget { get; private set; }
        public string JsOpexBudget  { get; private set; }
        public string JsUtilized    { get; private set; }
        public string JsAvailable   { get; private set; }
        public string JsLocked      { get; private set; }
        public string JsPending     { get; private set; }
        public string JsApproved    { get; private set; }
        public string JsRejected    { get; private set; }
        public string JsDraft       { get; private set; }

        // JIRA chart datasets (serialised inline into the page)
        public string JsRagLabels       { get; private set; }
        public string JsRagData         { get; private set; }
        public string JsRagColors       { get; private set; }
        public string JsDemandLabels    { get; private set; }
        public string JsDemandData      { get; private set; }
        public string JsTechLeadLabels  { get; private set; }
        public string JsTechLeadData    { get; private set; }
        public string JsManagerLabels   { get; private set; }
        public string JsManagerData     { get; private set; }
        public string JsDemandStatusLabels { get; private set; }
        public string JsDemandStatusData   { get; private set; }
        public string JsDemandStatusColors { get; private set; }
        public string JsPlatformLabels  { get; private set; }
        public string JsPlatformData    { get; private set; }
        public string JsPlatformColors  { get; private set; }

        public DefaultPage()
        {
            JsCapexBudget = "0"; JsOpexBudget = "0"; JsUtilized = "0";
            JsAvailable = "0"; JsLocked = "0";
            JsPending = "0"; JsApproved = "0"; JsRejected = "0"; JsDraft = "0";
            JsRagLabels = "[]"; JsRagData = "[]"; JsRagColors = "[]";
            JsDemandLabels = "[]"; JsDemandData = "[]";
            JsTechLeadLabels = "[]"; JsTechLeadData = "[]";
            JsManagerLabels = "[]"; JsManagerData = "[]";
            JsDemandStatusLabels = "[]"; JsDemandStatusData = "[]"; JsDemandStatusColors = "[]";
            JsPlatformLabels = "[]"; JsPlatformData = "[]"; JsPlatformColors = "[]";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) LoadDashboard();
        }

        protected void Filter_Changed(object sender, EventArgs e) { LoadDashboard(); }

        private void LoadDashboard()
        {
            DataRow s = ProjectsDAL.GetDashboardSummary();
            decimal capexBudget = ToDec(s, "TotalCapexBudget");
            decimal opexBudget  = ToDec(s, "TotalOpexBudget");
            decimal utilized    = ToDec(s, "TotalUtilized");
            decimal available   = ToDec(s, "TotalAvailable");
            decimal locked      = ToDec(s, "TotalLocked");

            int total    = ToInt(s, "TotalProjects");
            int pending  = ToInt(s, "PendingApproval");
            int approved = ToInt(s, "Approved");
            int rejected = ToInt(s, "Rejected");

            kTotalProjects.Text = total.ToString("N0");
            kCapexBudget.Text   = capexBudget.ToString("N0");
            kOpexBudget.Text    = opexBudget.ToString("N0");
            kUtilized.Text      = utilized.ToString("N0");
            kAvailable.Text     = available.ToString("N0");
            kLocked.Text        = locked.ToString("N0");
            kPending.Text       = pending.ToString("N0");
            kApproved.Text      = approved.ToString("N0");
            kRejected.Text      = rejected.ToString("N0");

            decimal totalBudget = capexBudget + opexBudget;
            int pct = totalBudget > 0 ? Math.Min(100, (int)Math.Round((utilized / totalBudget) * 100m)) : 0;
            litMeterPct.Text = pct.ToString() + "%";

            JsCapexBudget = capexBudget.ToString(CultureInfo.InvariantCulture);
            JsOpexBudget  = opexBudget.ToString(CultureInfo.InvariantCulture);
            JsUtilized    = utilized.ToString(CultureInfo.InvariantCulture);
            JsAvailable   = available.ToString(CultureInfo.InvariantCulture);
            JsLocked      = locked.ToString(CultureInfo.InvariantCulture);
            JsPending     = pending.ToString();
            JsApproved    = approved.ToString();
            JsRejected    = rejected.ToString();
            JsDraft       = (total - pending - approved - rejected).ToString();

            // ===== JIRA dashboard + charts =====
            DataTable jira = JiraClient.GetCachedIssues();
            int jt = jira.Rows.Count, jActive = 0;

            // Aggregations
            var ragCounts      = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var demandCounts   = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var techLeadCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var managerCounts  = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            foreach (DataRow r in jira.Rows)
            {
                string st = ColStr(r, "OverallStatus");
                if (!string.IsNullOrEmpty(st) && !st.Equals("Closed", StringComparison.OrdinalIgnoreCase)) jActive++;
                Bump(ragCounts,      Normalize(ColStr(r, "ProjectRAG"), "Unspecified"));
                Bump(demandCounts,   Normalize(ColStr(r, "DemandType"), "Unspecified"));
                Bump(techLeadCounts, Normalize(ColStr(r, "TechLead"),   "Unassigned"));
                Bump(managerCounts,  Normalize(ColStr(r, "Manager"),    "Unassigned"));
            }

            int jAmber = ragCounts.ContainsKey("Amber") ? ragCounts["Amber"] : 0;
            int jRed   = ragCounts.ContainsKey("Red")   ? ragCounts["Red"]   : 0;

            kJiraTotal.Text  = jt.ToString();
            kJiraActive.Text = jActive.ToString();
            kJiraAmber.Text  = jAmber.ToString();
            kJiraRed.Text    = jRed.ToString();

            // RAG ordered + color-mapped
            string[] ragOrder = new[] { "Red", "Amber", "Green", "Blue", "Unspecified" };
            var ragLbl = new List<string>(); var ragVal = new List<int>(); var ragClr = new List<string>();
            foreach (string rg in ragOrder)
                if (ragCounts.ContainsKey(rg)) { ragLbl.Add(rg); ragVal.Add(ragCounts[rg]); ragClr.Add(RagColor(rg)); }
            // Any unexpected RAG values land at the end
            foreach (var kv in ragCounts)
                if (Array.IndexOf(ragOrder, kv.Key) < 0) { ragLbl.Add(kv.Key); ragVal.Add(kv.Value); ragClr.Add("#94a3b8"); }
            JsRagLabels = ToJsArray(ragLbl);
            JsRagData   = ToJsIntArray(ragVal);
            JsRagColors = ToJsArray(ragClr);

            string dLbl, dVal, tLbl, tVal, mLbl, mVal;
            BuildTopN(demandCounts,   10, out dLbl, out dVal); JsDemandLabels   = dLbl; JsDemandData   = dVal;
            BuildTopN(techLeadCounts, 8,  out tLbl, out tVal); JsTechLeadLabels = tLbl; JsTechLeadData = tVal;
            BuildTopN(managerCounts,  8,  out mLbl, out mVal); JsManagerLabels  = mLbl; JsManagerData  = mVal;

            // SQL-driven bar charts (Demand Status + Platform-wise)
            var dsBars = JiraDashboardHelper.GetDemandStatusBars();
            JsDemandStatusLabels = JiraDashboardHelper.LabelsJs(dsBars);
            JsDemandStatusData   = JiraDashboardHelper.DataJs(dsBars);
            JsDemandStatusColors = JiraDashboardHelper.ColorsJs(dsBars);

            var plBars = JiraDashboardHelper.GetPlatformBars();
            JsPlatformLabels = JiraDashboardHelper.LabelsJs(plBars);
            JsPlatformData   = JiraDashboardHelper.DataJs(plBars);
            JsPlatformColors = JiraDashboardHelper.ColorsJs(plBars);
        }

        // ===== Helpers =====
        private static string ColStr(DataRow r, string c)
        {
            return (!r.Table.Columns.Contains(c) || r[c] == DBNull.Value) ? "" : r[c].ToString().Trim();
        }
        private static string Normalize(string v, string fallback)
        {
            return string.IsNullOrWhiteSpace(v) ? fallback : v;
        }
        private static void Bump(Dictionary<string, int> d, string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            if (d.ContainsKey(key)) d[key]++; else d[key] = 1;
        }
        private static string RagColor(string rag)
        {
            if (string.Equals(rag, "Red",   StringComparison.OrdinalIgnoreCase)) return "#dc2626";
            if (string.Equals(rag, "Amber", StringComparison.OrdinalIgnoreCase)) return "#f59e0b";
            if (string.Equals(rag, "Green", StringComparison.OrdinalIgnoreCase)) return "#16a34a";
            if (string.Equals(rag, "Blue",  StringComparison.OrdinalIgnoreCase)) return "#0b6efd";
            return "#94a3b8";
        }
        private static void BuildTopN(Dictionary<string, int> source, int top, out string labels, out string values)
        {
            var list = new List<KeyValuePair<string, int>>(source);
            list.Sort((a, b) => b.Value.CompareTo(a.Value));
            var lbl = new List<string>(); var val = new List<int>();
            int n = Math.Min(top, list.Count);
            for (int i = 0; i < n; i++) { lbl.Add(list[i].Key); val.Add(list[i].Value); }
            if (list.Count > n)
            {
                int other = 0;
                for (int i = n; i < list.Count; i++) other += list[i].Value;
                if (other > 0) { lbl.Add("Other"); val.Add(other); }
            }
            labels = ToJsArray(lbl);
            values = ToJsIntArray(val);
        }
        private static string ToJsArray(List<string> items)
        {
            var sb = new StringBuilder("[");
            for (int i = 0; i < items.Count; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append('"').Append(JsEscape(items[i])).Append('"');
            }
            sb.Append(']');
            return sb.ToString();
        }
        private static string ToJsIntArray(List<int> items)
        {
            var sb = new StringBuilder("[");
            for (int i = 0; i < items.Count; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append(items[i]);
            }
            sb.Append(']');
            return sb.ToString();
        }
        private static string JsEscape(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", " ").Replace("\n", " ");
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            string ptype = ddlType.SelectedValue;
            string status = ddlStatus.SelectedValue;
            DataTable dt = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype,
                                                   status == "ALL" ? null : status);
            ExcelHelper.ExportToExcel(Response, dt, "DFM_Dashboard_Projects_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        private static int ToInt(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return 0;
            return Convert.ToInt32(r[col]);
        }
        private static decimal ToDec(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return 0m;
            return Convert.ToDecimal(r[col]);
        }
    }
}
