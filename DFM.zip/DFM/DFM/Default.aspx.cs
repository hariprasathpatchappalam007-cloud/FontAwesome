using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM
{
    public partial class DefaultPage : System.Web.UI.Page
    {
        // For the inline charts
        public string JsCapexBudget { get; private set; }
        public string JsOpexBudget  { get; private set; }
        public string JsUtilized    { get; private set; }
        public string JsAvailable   { get; private set; }
        public string JsLocked      { get; private set; }
        public string JsPending     { get; private set; }
        public string JsApproved    { get; private set; }
        public string JsRejected    { get; private set; }
        public string JsDraft       { get; private set; }

        public DefaultPage()
        {
            JsCapexBudget = "0";
            JsOpexBudget  = "0";
            JsUtilized    = "0";
            JsAvailable   = "0";
            JsLocked      = "0";
            JsPending     = "0";
            JsApproved    = "0";
            JsRejected    = "0";
            JsDraft       = "0";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDashboard();
            }
        }

        protected void Filter_Changed(object sender, EventArgs e) { LoadDashboard(); }

        private void LoadDashboard()
        {
            DataRow s = ProjectsDAL.GetDashboardSummary();
            decimal capexBudget = ToDec(s, "TotalCapexBudget");
            decimal opexBudget  = ToDec(s, "TotalOpexBudget");
            decimal utilized    = ToDec(s, "TotalUtilized");
            decimal available   = ToDec(s, "TotalAvailable");
            decimal locked      = ToDec(s, "TotalLocked");

            int total    = ToInt(s, "TotalProjects");
            int pending  = ToInt(s, "PendingApproval");
            int approved = ToInt(s, "Approved");
            int rejected = ToInt(s, "Rejected");
            int capexCnt = ToInt(s, "CapexCount");
            int opexCnt  = ToInt(s, "OpexCount");
            int amcCnt   = ToInt(s, "AmcCount");

            kTotalProjects.Text = total.ToString("N0");
            kCapexBudget.Text   = capexBudget.ToString("N0");
            kOpexBudget.Text    = opexBudget.ToString("N0");
            kUtilized.Text      = utilized.ToString("N0");
            kAvailable.Text     = available.ToString("N0");
            kLocked.Text        = locked.ToString("N0");
            kPending.Text       = pending.ToString("N0");
            kApproved.Text      = approved.ToString("N0");
            kRejected.Text      = rejected.ToString("N0");

            cCapex.Text = capexCnt.ToString("N0");
            cOpex.Text  = opexCnt.ToString("N0");
            cAmc.Text   = amcCnt.ToString("N0");

            JsCapexBudget = capexBudget.ToString(System.Globalization.CultureInfo.InvariantCulture);
            JsOpexBudget  = opexBudget.ToString(System.Globalization.CultureInfo.InvariantCulture);
            JsUtilized    = utilized.ToString(System.Globalization.CultureInfo.InvariantCulture);
            JsAvailable   = available.ToString(System.Globalization.CultureInfo.InvariantCulture);
            JsLocked      = locked.ToString(System.Globalization.CultureInfo.InvariantCulture);
            JsPending     = pending.ToString();
            JsApproved    = approved.ToString();
            JsRejected    = rejected.ToString();
            JsDraft       = (total - pending - approved - rejected).ToString();

            string ptype = ddlType.SelectedValue;
            string status = ddlStatus.SelectedValue;
            gvProjects.DataSource = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype,
                                                            status == "ALL" ? null : status);
            gvProjects.DataBind();

            gvJira.DataSource = JiraClient.GetCachedIssues();
            gvJira.DataBind();
        }

        protected void gvProjects_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "OpenProject")
            {
                Response.Redirect("~/Forms/ProjectRegistration.aspx?id=" + e.CommandArgument);
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            string ptype = ddlType.SelectedValue;
            string status = ddlStatus.SelectedValue;
            DataTable dt = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype,
                                                   status == "ALL" ? null : status);
            ExcelHelper.ExportToExcel(Response, dt, "DFM_Dashboard_Projects_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        private static int ToInt(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return 0;
            return Convert.ToInt32(r[col]);
        }
        private static decimal ToDec(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return 0m;
            return Convert.ToDecimal(r[col]);
        }
    }
}
