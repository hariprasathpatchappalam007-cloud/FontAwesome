-- Add GLCode column to CapexMemos table for per-memo GL tracking
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('CapexMemos') AND name = 'GLCode')
BEGIN
    ALTER TABLE CapexMemos ADD GLCode NVARCHAR(50) NULL;
END
GO
