-- ============================================================
-- Req5: Dashboard schema extension
-- - Adds custom-field columns to JiraIssues
-- - Creates pre-aggregated DashboardSummary tables
-- - Creates SP for fast dashboard rendering
-- ============================================================

-- ----- 1. Add missing custom fields to JiraIssues -----
IF COL_LENGTH('dbo.JiraIssues','Platform') IS NULL
    ALTER TABLE dbo.JiraIssues ADD Platform NVARCHAR(200) NULL;        -- customfield_12609
IF COL_LENGTH('dbo.JiraIssues','PlatformVertical') IS NULL
    ALTER TABLE dbo.JiraIssues ADD PlatformVertical NVARCHAR(200) NULL; -- customfield_11632
IF COL_LENGTH('dbo.JiraIssues','PlatformName') IS NULL
    ALTER TABLE dbo.JiraIssues ADD PlatformName NVARCHAR(200) NULL;    -- customfield_11610
IF COL_LENGTH('dbo.JiraIssues','SecondaryPlatform') IS NULL
    ALTER TABLE dbo.JiraIssues ADD SecondaryPlatform NVARCHAR(200) NULL; -- customfield_13380
IF COL_LENGTH('dbo.JiraIssues','ActivityRagStatus') IS NULL
    ALTER TABLE dbo.JiraIssues ADD ActivityRagStatus NVARCHAR(50) NULL;  -- customfield_13419
IF COL_LENGTH('dbo.JiraIssues','ScheduleRag') IS NULL
    ALTER TABLE dbo.JiraIssues ADD ScheduleRag NVARCHAR(50) NULL;        -- customfield_13511
IF COL_LENGTH('dbo.JiraIssues','BudgetRag') IS NULL
    ALTER TABLE dbo.JiraIssues ADD BudgetRag NVARCHAR(50) NULL;          -- customfield_13510
IF COL_LENGTH('dbo.JiraIssues','RaidRag') IS NULL
    ALTER TABLE dbo.JiraIssues ADD RaidRag NVARCHAR(50) NULL;            -- customfield_13505
IF COL_LENGTH('dbo.JiraIssues','OverallProjectRag') IS NULL
    ALTER TABLE dbo.JiraIssues ADD OverallProjectRag NVARCHAR(50) NULL;  -- customfield_13509 (drives Project RAG)
IF COL_LENGTH('dbo.JiraIssues','Priority') IS NULL
    ALTER TABLE dbo.JiraIssues ADD Priority NVARCHAR(50) NULL;

-- Indexes for filtering performance on ~1 lakh records
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_Platform')
    CREATE INDEX IX_JiraIssues_Platform ON dbo.JiraIssues(Platform);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_Vertical')
    CREATE INDEX IX_JiraIssues_Vertical ON dbo.JiraIssues(PlatformVertical);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_Project')
    CREATE INDEX IX_JiraIssues_Project ON dbo.JiraIssues(ProjectKey);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_Parent')
    CREATE INDEX IX_JiraIssues_Parent ON dbo.JiraIssues(ParentJiraID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_Rag')
    CREATE INDEX IX_JiraIssues_Rag ON dbo.JiraIssues(OverallProjectRag);

-- ----- 2. Pre-aggregated dashboard summary tables -----
IF OBJECT_ID('dbo.DashboardSummary','U') IS NULL
BEGIN
    CREATE TABLE dbo.DashboardSummary(
        SummaryID    INT IDENTITY(1,1) PRIMARY KEY,
        Dimension    NVARCHAR(50) NOT NULL,  -- 'Vertical','Manager','Platform','RAG','Aging','Chief','TechLead','Status'
        Bucket       NVARCHAR(200) NOT NULL,
        TotalCount   INT NOT NULL DEFAULT 0,
        OpenCount    INT NOT NULL DEFAULT 0,
        ClosedCount  INT NOT NULL DEFAULT 0,
        LastSyncDate DATETIME NOT NULL DEFAULT GETDATE()
    );
    CREATE INDEX IX_DashSum_Dim ON dbo.DashboardSummary(Dimension);
END

IF OBJECT_ID('dbo.JiraSyncLog','U') IS NULL
BEGIN
    CREATE TABLE dbo.JiraSyncLog(
        SyncID       INT IDENTITY(1,1) PRIMARY KEY,
        StartTime    DATETIME NOT NULL,
        EndTime      DATETIME NULL,
        ProjectKey   NVARCHAR(20) NULL,
        TotalPulled  INT NULL,
        Inserted     INT NULL,
        Updated      INT NULL,
        Failed       INT NULL,
        Status       NVARCHAR(50) NULL,    -- 'Running','Success','Failed'
        ExceptionLog NVARCHAR(MAX) NULL
    );
END

IF OBJECT_ID('dbo.DashboardFilterValues','U') IS NULL
BEGIN
    CREATE TABLE dbo.DashboardFilterValues(
        FilterID    INT IDENTITY(1,1) PRIMARY KEY,
        Dimension   NVARCHAR(50) NOT NULL,  -- 'Platform','Vertical','Manager','TechLead','Priority','Status'
        Value       NVARCHAR(200) NOT NULL,
        DisplayName NVARCHAR(200) NULL,
        SortOrder   INT NULL,
        IsActive    BIT NOT NULL DEFAULT 1,
        UpdatedDate DATETIME NOT NULL DEFAULT GETDATE()
    );
    CREATE UNIQUE INDEX UX_DashFilter ON dbo.DashboardFilterValues(Dimension, Value);
END
GO

-- ----- 3. SP: Refresh dashboard summary tables -----
IF OBJECT_ID('dbo.sp_RefreshDashboardSummary','P') IS NOT NULL
    DROP PROCEDURE dbo.sp_RefreshDashboardSummary;
GO
CREATE PROCEDURE dbo.sp_RefreshDashboardSummary
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @now DATETIME = GETDATE();

    DELETE FROM dbo.DashboardSummary;

    -- By Platform
    INSERT INTO dbo.DashboardSummary(Dimension, Bucket, TotalCount, OpenCount, ClosedCount, LastSyncDate)
    SELECT 'Platform', ISNULL(Platform,'Unknown'), COUNT(*),
        SUM(CASE WHEN Status NOT IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        SUM(CASE WHEN Status IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        @now
    FROM dbo.JiraIssues
    WHERE ISNULL(Platform,'') <> ''
    GROUP BY Platform;

    -- By Vertical
    INSERT INTO dbo.DashboardSummary(Dimension, Bucket, TotalCount, OpenCount, ClosedCount, LastSyncDate)
    SELECT 'Vertical', ISNULL(PlatformVertical,'Unknown'), COUNT(*),
        SUM(CASE WHEN Status NOT IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        SUM(CASE WHEN Status IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        @now
    FROM dbo.JiraIssues
    WHERE ISNULL(PlatformVertical,'') <> ''
    GROUP BY PlatformVertical;

    -- By Manager
    INSERT INTO dbo.DashboardSummary(Dimension, Bucket, TotalCount, OpenCount, ClosedCount, LastSyncDate)
    SELECT 'Manager', ISNULL(Manager,'Unassigned'), COUNT(*),
        SUM(CASE WHEN Status NOT IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        SUM(CASE WHEN Status IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        @now
    FROM dbo.JiraIssues GROUP BY Manager;

    -- By TechLead
    INSERT INTO dbo.DashboardSummary(Dimension, Bucket, TotalCount, OpenCount, ClosedCount, LastSyncDate)
    SELECT 'TechLead', ISNULL(TechLead,'Unassigned'), COUNT(*),
        SUM(CASE WHEN Status NOT IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        SUM(CASE WHEN Status IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        @now
    FROM dbo.JiraIssues GROUP BY TechLead;

    -- By Chief
    INSERT INTO dbo.DashboardSummary(Dimension, Bucket, TotalCount, OpenCount, ClosedCount, LastSyncDate)
    SELECT 'Chief', ISNULL(ChiefNameMapping,'Unassigned'), COUNT(*),
        SUM(CASE WHEN Status NOT IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        SUM(CASE WHEN Status IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        @now
    FROM dbo.JiraIssues GROUP BY ChiefNameMapping;

    -- By RAG (Req5: from OverallProjectRag = customfield_13509)
    INSERT INTO dbo.DashboardSummary(Dimension, Bucket, TotalCount, OpenCount, ClosedCount, LastSyncDate)
    SELECT 'RAG', ISNULL(OverallProjectRag,'Not Set'), COUNT(*),
        SUM(CASE WHEN Status NOT IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        SUM(CASE WHEN Status IN ('Done','Closed','Cancelled','Completed') THEN 1 ELSE 0 END),
        @now
    FROM dbo.JiraIssues GROUP BY OverallProjectRag;

    -- Aging buckets (months since creation, for open issues)
    INSERT INTO dbo.DashboardSummary(Dimension, Bucket, TotalCount, OpenCount, ClosedCount, LastSyncDate)
    SELECT 'Aging', AgingBucket, COUNT(*), COUNT(*), 0, @now
    FROM (
        SELECT CASE
            WHEN DATEDIFF(MONTH, ISNULL(CreatedDate,@now), @now) <= 3 THEN '0-3 months'
            WHEN DATEDIFF(MONTH, CreatedDate, @now) <= 6 THEN '3-6 months'
            WHEN DATEDIFF(MONTH, CreatedDate, @now) <= 12 THEN '7-12 months'
            ELSE '12+ months' END AS AgingBucket
        FROM dbo.JiraIssues
        WHERE Status NOT IN ('Done','Closed','Cancelled','Completed')
    ) a
    GROUP BY AgingBucket;

    -- Refresh filter dropdown values
    DELETE FROM dbo.DashboardFilterValues;
    INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
        SELECT DISTINCT 'Platform', Platform FROM dbo.JiraIssues WHERE ISNULL(Platform,'')<>'';
    INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
        SELECT DISTINCT 'Vertical', PlatformVertical FROM dbo.JiraIssues WHERE ISNULL(PlatformVertical,'')<>'';
    INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
        SELECT DISTINCT 'Manager', Manager FROM dbo.JiraIssues WHERE ISNULL(Manager,'')<>'';
    INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
        SELECT DISTINCT 'TechLead', TechLead FROM dbo.JiraIssues WHERE ISNULL(TechLead,'')<>'';
END
GO

-- ----- 4. SP: Apply DMGT -> DIBITP inheritance (Chief/Manager/TechLead/PM) -----
IF OBJECT_ID('dbo.sp_ApplyHierarchyInheritance','P') IS NOT NULL
    DROP PROCEDURE dbo.sp_ApplyHierarchyInheritance;
GO
CREATE PROCEDURE dbo.sp_ApplyHierarchyInheritance
AS
BEGIN
    SET NOCOUNT ON;

    -- DIBITP children inherit empty fields from their DMGT parent
    UPDATE c
    SET
        c.ChiefNameMapping = CASE WHEN ISNULL(c.ChiefNameMapping,'')='' THEN p.ChiefNameMapping ELSE c.ChiefNameMapping END,
        c.Manager          = CASE WHEN ISNULL(c.Manager,'')='' THEN p.Manager ELSE c.Manager END,
        c.TechLead         = CASE WHEN ISNULL(c.TechLead,'')='' THEN p.TechLead ELSE c.TechLead END,
        c.ProjectManager   = CASE WHEN ISNULL(c.ProjectManager,'')='' THEN p.ProjectManager ELSE c.ProjectManager END,
        c.Platform         = CASE WHEN ISNULL(c.Platform,'')='' THEN p.Platform ELSE c.Platform END,
        c.PlatformVertical = CASE WHEN ISNULL(c.PlatformVertical,'')='' THEN p.PlatformVertical ELSE c.PlatformVertical END
    FROM dbo.JiraIssues c
    INNER JOIN dbo.JiraIssues p ON p.JiraKey = c.ParentJiraID
    WHERE c.ProjectKey = 'DIBITP'
      AND p.ProjectKey = 'DMGT';

    -- Repeat for grandchildren (DIBITP under DIBITP)
    UPDATE c
    SET
        c.ChiefNameMapping = CASE WHEN ISNULL(c.ChiefNameMapping,'')='' THEN p.ChiefNameMapping ELSE c.ChiefNameMapping END,
        c.Manager          = CASE WHEN ISNULL(c.Manager,'')='' THEN p.Manager ELSE c.Manager END,
        c.TechLead         = CASE WHEN ISNULL(c.TechLead,'')='' THEN p.TechLead ELSE c.TechLead END,
        c.ProjectManager   = CASE WHEN ISNULL(c.ProjectManager,'')='' THEN p.ProjectManager ELSE c.ProjectManager END,
        c.Platform         = CASE WHEN ISNULL(c.Platform,'')='' THEN p.Platform ELSE c.Platform END,
        c.PlatformVertical = CASE WHEN ISNULL(c.PlatformVertical,'')='' THEN p.PlatformVertical ELSE c.PlatformVertical END
    FROM dbo.JiraIssues c
    INNER JOIN dbo.JiraIssues p ON p.JiraKey = c.ParentJiraID
    WHERE c.ProjectKey = 'DIBITP'
      AND p.ProjectKey = 'DIBITP';
END
GO

-- ----- 5. SP: Fast KPI fetch -----
IF OBJECT_ID('dbo.sp_GetDashboardKPIs','P') IS NOT NULL
    DROP PROCEDURE dbo.sp_GetDashboardKPIs;
GO
CREATE PROCEDURE dbo.sp_GetDashboardKPIs
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        (SELECT COUNT(*) FROM dbo.JiraIssues WHERE ProjectKey='DMGT') AS TotalDemands,
        (SELECT COUNT(*) FROM dbo.JiraIssues WHERE ProjectKey='DIBITP') AS ActiveProjects,
        (SELECT COUNT(*) FROM dbo.JiraIssues WHERE ProjectKey='DIBITP'
            AND Status IN ('Done','Closed','Completed')) AS ClosedProjects,
        (SELECT COUNT(*) FROM dbo.JiraIssues WHERE OverallProjectRag='Red') AS RedRag,
        (SELECT COUNT(*) FROM dbo.JiraIssues WHERE OverallProjectRag='Amber') AS AmberRag,
        (SELECT COUNT(*) FROM dbo.JiraIssues WHERE OverallProjectRag='Green') AS GreenRag,
        (SELECT MAX(LastSyncDate) FROM dbo.DashboardSummary) AS LastRefreshed;
END
GO
