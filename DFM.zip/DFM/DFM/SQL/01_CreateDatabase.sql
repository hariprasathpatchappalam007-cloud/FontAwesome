-- =====================================================================
-- DFM (Demand Fund Management) - Database creation
-- =====================================================================
USE master;
GO
IF DB_ID('DFM') IS NULL
BEGIN
    CREATE DATABASE DFM;
END
GO
USE DFM;
GO
