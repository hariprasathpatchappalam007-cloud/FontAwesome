-- =====================================================================
-- DFM Seed Data
-- =====================================================================
USE DFM;
GO

-- Roles
IF NOT EXISTS (SELECT 1 FROM dbo.UserRoles WHERE RoleName = 'Admin')
INSERT INTO dbo.UserRoles(RoleName, Description) VALUES
('Admin','System administrator'),
('Approver','Funding approver'),
('User','Project requester');
GO

-- Default users (Forms auth testing)
-- Default password = "Welcome@123" - hash via PasswordHelper at runtime; for seed purposes
-- the application will (re)create these on first run if missing.
DECLARE @AdminRoleID INT = (SELECT RoleID FROM dbo.UserRoles WHERE RoleName='Admin');
DECLARE @ApproverRoleID INT = (SELECT RoleID FROM dbo.UserRoles WHERE RoleName='Approver');
DECLARE @UserRoleID INT = (SELECT RoleID FROM dbo.UserRoles WHERE RoleName='User');

IF NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Username='admin')
INSERT INTO dbo.AppUsers(Username, PasswordHash, PasswordSalt, FullName, Email, RoleID, CreatedBy)
VALUES ('admin', NULL, NULL, 'System Administrator', 'admin@dib.ae', @AdminRoleID, 'system');

IF NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Username='approver')
INSERT INTO dbo.AppUsers(Username, PasswordHash, PasswordSalt, FullName, Email, RoleID, CreatedBy)
VALUES ('approver', NULL, NULL, 'Default Approver', 'approver@dib.ae', @ApproverRoleID, 'system');

IF NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Username='user1')
INSERT INTO dbo.AppUsers(Username, PasswordHash, PasswordSalt, FullName, Email, RoleID, CreatedBy)
VALUES ('user1', NULL, NULL, 'Test Requester', 'user1@dib.ae', @UserRoleID, 'system');
GO

-- Approvers (initial)
IF NOT EXISTS (SELECT 1 FROM dbo.ApproverMaster)
INSERT INTO dbo.ApproverMaster(ApproverName, Email, Department, ApprovalLevel) VALUES
('Karthi Vasudevan',   'karthi.v@dib.ae',     'IT - CBE',      1),
('Shariq Qamar',       'shariq.q@dib.ae',     'IT - PMO',      2),
('Portfolio Head',     'portfolio@dib.ae',    'IT',            3);
GO

-- Default JIRA config row
IF NOT EXISTS (SELECT 1 FROM dbo.JiraConfig)
INSERT INTO dbo.JiraConfig(BaseUrl, UserEmail, ApiToken, ProjectKey)
VALUES ('https://agile.dib.ae', '', '', 'DMGT');
GO

-- Default JIRA custom field definitions (visible by default)
IF NOT EXISTS (SELECT 1 FROM dbo.JiraCustomFieldConfig)
INSERT INTO dbo.JiraCustomFieldConfig(FieldKey, FieldName, DisplayOrder, IsVisible) VALUES
('customfield_project_name',  'Project Name',     1, 1),
('customfield_project_id',    'Project ID',       2, 1),
('customfield_start_date',    'Start Date',       3, 1),
('customfield_overall_status','Overall Status',   4, 1),
('customfield_project_stage', 'Project Stage',    5, 1),
('customfield_governance',    'Governance Stage', 6, 1),
('customfield_project_rag',   'Project RAG',      7, 1),
('customfield_demand_type',   'Demand Type',      8, 1),
('customfield_project_type',  'Project Type',     9, 1),
('customfield_classification','Classification',  10, 1),
('customfield_tech_lead',     'Tech Lead',       11, 1),
('customfield_manager',       'Project Manager', 12, 1),
('customfield_sponsor',       'Project Sponsor', 13, 1),
('customfield_department',    'Project Department',14, 1),
('customfield_stakeholder',   'Stakeholder',     15, 1),
('customfield_objectives',    'Objectives & Requirements', 16, 1);
GO

-- Sample JIRA issues (for dropdown when JIRA isn't reachable)
IF NOT EXISTS (SELECT 1 FROM dbo.JiraIssues)
INSERT INTO dbo.JiraIssues(JiraID, Summary, ProjectName, StartDate, OverallStatus, ProjectStage, ProjectType, DemandType, ProjectRAG, Department, Manager, TechLead, Classification, Objectives)
VALUES
('DMGT-1305','Jaywan Visa Co Badged Debit Cards','Jaywan Visa Co Badged Debit Cards','01-Mar-26','BASELINE 0','Baseline 0 - Plan','Enhancement','Strategic','GREEN','IT - Consumer Banking Engineering Team','Shariq Qamar','Karthi Vasudevan','Change the Bank',
 'Goal: launch Visa Co-Badge debit card under Jaywan Scheme. Activities: Card Design and approvals, Stationery Design, White plastic, Chip Setup, Scheme Setup, Card Central Issuance.'),
('DMGT-993','Jaywan Mono Badge Debit Cards - Track 2 & 3','Jaywan Mono Badge Debit Cards','01-Mar-26','BASELINE 0','Baseline 0','Enhancement','Strategic','','IT - CBE','Shariq Qamar','Karthi Vasudevan','Change the Bank','Track 2 & 3 of Jaywan Mono Badge Debit Cards.');
GO
