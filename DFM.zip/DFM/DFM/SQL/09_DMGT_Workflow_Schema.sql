-- ============================================================
-- 09_DMGT_Workflow_Schema.sql
-- Req: DMGT Workflow & CAPEX Management enhancements
-- Tables: GLMaster, VendorMaster, CapexMemos, MemoInvoices
-- Columns: Projects.GLCode
-- ============================================================

-- 1. GL Master
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='GLMaster')
CREATE TABLE GLMaster (
    GLID           INT IDENTITY(1,1) PRIMARY KEY,
    GLCode         NVARCHAR(50)  NOT NULL,
    Description    NVARCHAR(300) NULL,
    IsActive       BIT           NOT NULL DEFAULT 1,
    CreatedDate    DATETIME      NOT NULL DEFAULT GETDATE(),
    ModifiedDate   DATETIME      NULL
);
GO

-- 2. Vendor Master
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='VendorMaster')
CREATE TABLE VendorMaster (
    VendorID       INT IDENTITY(1,1) PRIMARY KEY,
    VendorCode     NVARCHAR(50)  NOT NULL,
    VendorName     NVARCHAR(200) NOT NULL,
    ContactPerson  NVARCHAR(200) NULL,
    Phone          NVARCHAR(50)  NULL,
    Email          NVARCHAR(200) NULL,
    IsActive       BIT           NOT NULL DEFAULT 1,
    CreatedDate    DATETIME      NOT NULL DEFAULT GETDATE(),
    ModifiedDate   DATETIME      NULL
);
GO

-- 3. CAPEX Memos (Internal Memo / CAM)
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='CapexMemos')
CREATE TABLE CapexMemos (
    MemoID              INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID           INT           NOT NULL,
    MemoNumber          NVARCHAR(50)  NULL,       -- Memo# / CAM ID
    ApprovedAmountAED   DECIMAL(18,2) NOT NULL DEFAULT 0,
    VendorID            INT           NULL,
    DateRaised          DATETIME      NULL,
    LPO_SO_Number       NVARCHAR(100) NULL,       -- LPO/SO #
    PODate              DATETIME      NULL,
    AMS_Number          NVARCHAR(100) NULL,       -- AMS #
    CAMStatus           NVARCHAR(50)  NOT NULL DEFAULT 'Open',
    Description         NVARCHAR(500) NULL,
    TotalInvoiceAmount  DECIMAL(18,2) NOT NULL DEFAULT 0,
    AmountDisbursed     DECIMAL(18,2) NOT NULL DEFAULT 0,
    PendingBalance      DECIMAL(18,2) NOT NULL DEFAULT 0,
    CapexVersion        INT           NOT NULL DEFAULT 1,
    CreatedBy           NVARCHAR(100) NULL,
    CreatedDate         DATETIME      NOT NULL DEFAULT GETDATE(),
    ModifiedDate        DATETIME      NULL,
    CONSTRAINT FK_CapexMemos_Project FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID),
    CONSTRAINT FK_CapexMemos_Vendor  FOREIGN KEY (VendorID)  REFERENCES VendorMaster(VendorID)
);
GO

-- 4. Memo Invoices
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='MemoInvoices')
CREATE TABLE MemoInvoices (
    InvoiceID           INT IDENTITY(1,1) PRIMARY KEY,
    MemoID              INT           NOT NULL,
    InvoiceMemoNumber   NVARCHAR(50)  NULL,       -- Invoice Memo#
    InvoiceNumber       NVARCHAR(100) NULL,       -- Invoice #
    InvoiceAmountAED    DECIMAL(18,2) NOT NULL DEFAULT 0,
    InvoiceDate         DATETIME      NULL,
    InvoiceEntryDate    DATETIME      NULL,
    InvoiceStatus       NVARCHAR(50)  NOT NULL DEFAULT 'Pending',
    InvoiceDescription  NVARCHAR(500) NULL,
    CreatedBy           NVARCHAR(100) NULL,
    CreatedDate         DATETIME      NOT NULL DEFAULT GETDATE(),
    ModifiedDate        DATETIME      NULL,
    CONSTRAINT FK_MemoInvoices_Memo FOREIGN KEY (MemoID) REFERENCES CapexMemos(MemoID)
);
GO

-- 5. Add GLCode column to Projects if missing
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='Projects' AND COLUMN_NAME='GLCode')
    ALTER TABLE Projects ADD GLCode NVARCHAR(50) NULL;
GO

-- 6. Add CapexVersion column to Projects if missing
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='Projects' AND COLUMN_NAME='CapexVersion')
    ALTER TABLE Projects ADD CapexVersion INT NOT NULL DEFAULT 1;
GO

-- 7. Index for performance
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_CapexMemos_ProjectID')
    CREATE INDEX IX_CapexMemos_ProjectID ON CapexMemos(ProjectID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_MemoInvoices_MemoID')
    CREATE INDEX IX_MemoInvoices_MemoID ON MemoInvoices(MemoID);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_ProjectKey')
    CREATE INDEX IX_JiraIssues_ProjectKey ON JiraIssues(ProjectKey);
GO
