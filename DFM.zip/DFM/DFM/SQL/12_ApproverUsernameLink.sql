-- =====================================================================
-- Migration 12: Link ApproverMaster to AppUsers via Username
-- Fixes: Approve button mismatch; ApproverName (display) vs Username (login)
-- Run once against the DFM database
-- =====================================================================

-- 1. Add Username column to ApproverMaster (nullable; existing rows get NULL)
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME='ApproverMaster' AND COLUMN_NAME='Username'
)
    ALTER TABLE ApproverMaster ADD Username NVARCHAR(100) NULL;
GO

-- 2. Auto-populate Username for existing rows where Email matches AppUsers.Email
UPDATE am
SET    am.Username = au.Username
FROM   ApproverMaster am
INNER  JOIN AppUsers au ON am.Email = au.Email
WHERE  am.Username IS NULL
  AND  am.Email    IS NOT NULL
  AND  am.Email    <> '';
GO

-- 3. Index for fast lookup during login matching
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes WHERE name='IX_ApproverMaster_Username' AND object_id=OBJECT_ID('ApproverMaster')
)
    CREATE INDEX IX_ApproverMaster_Username ON ApproverMaster(Username);
GO

PRINT 'Migration 12 applied: ApproverMaster.Username column added and auto-populated.';
