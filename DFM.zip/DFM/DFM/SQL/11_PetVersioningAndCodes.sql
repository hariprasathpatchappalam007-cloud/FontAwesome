-- ============================================================
-- Migration 11: PET versioning, unique codes, parent-child IDs
-- ============================================================

-- 1. PetForm: add PetVersion (which submission round this item belongs to; NULL = draft/not yet submitted)
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='PetForm' AND COLUMN_NAME='PetVersion')
    ALTER TABLE PetForm ADD PetVersion INT NULL;

-- 2. PetForm: PetCode computed column  PET-{PetID}
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='PetForm' AND COLUMN_NAME='PetCode')
    ALTER TABLE PetForm ADD PetCode AS ('PET-' + CAST(PetID AS NVARCHAR(20))) PERSISTED;

-- 3. CapexMemos: MemoCode computed column  CAM-{MemoID}
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='CapexMemos' AND COLUMN_NAME='MemoCode')
    ALTER TABLE CapexMemos ADD MemoCode AS ('CAM-' + CAST(MemoID AS NVARCHAR(20))) PERSISTED;

-- 4. Projects: track the latest submitted PET version
IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='Projects' AND COLUMN_NAME='PetCurrentVersion')
    ALTER TABLE Projects ADD PetCurrentVersion INT NOT NULL DEFAULT 0;

-- 5. PetSubmissions: one row per PET submission round
IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PetSubmissions]') AND type = 'U')
CREATE TABLE [dbo].[PetSubmissions] (
    SubmissionID    INT            IDENTITY(1,1) PRIMARY KEY,
    ProjectID       INT            NOT NULL,
    PetVersion      INT            NOT NULL DEFAULT 1,
    SubmittedBy     NVARCHAR(150)  NULL,
    SubmittedDate   DATETIME       NOT NULL DEFAULT GETDATE(),
    Status          NVARCHAR(30)   NOT NULL DEFAULT 'Pending',   -- Pending | Approved | Rejected
    ApprovedBy      NVARCHAR(150)  NULL,
    ApprovedDate    DATETIME       NULL,
    ApprovedAmount  DECIMAL(18,2)  NULL,
    Comments        NVARCHAR(MAX)  NULL
);
