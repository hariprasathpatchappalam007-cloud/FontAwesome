-- =====================================================================
-- DFM - Seed PET masters from the Requirement folder CSVs.
-- Run AFTER 04_AdditionalTables.sql. The CsvImporter helper in the app
-- can also (re)load these from PET CostType.csv / PET Department.csv.
-- =====================================================================
USE DFM;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.PetCostType)
INSERT INTO dbo.PetCostType(SortOrder, Category) VALUES
(1,'Total Hardware'),(2,'Purchase Hardware'),(3,'Rental Hardware'),(4,'AMC Hardware'),
(5,'Software License Purchase'),(6,'Software License Subscription'),(7,'Software License AMC'),
(8,'Escrow Agreement'),(9,'Project Management Services'),(10,'Business Analysis'),
(11,'Architecture / Design'),(12,'SME Consulting Services'),(13,'Training'),
(14,'Application / Interface Development'),(15,'Software Customization'),
(16,'Software Installation & Configuration'),(17,'Hardware Installation & Configuration'),
(18,'Annual Support Operations'),(19,'QA Functional Testing'),(20,'QA Integration Testing'),
(21,'QA Performance Testing'),(22,'QA Load Testing'),(23,'QA Test Automation'),
(24,'SEC Penetration Testing'),(25,'UAT Functional Testing'),(26,'Professional Certification'),
(27,'Quality Assurance (External)'),(28,'Travel & Accommodation'),(29,'Premises Rent');
GO

IF NOT EXISTS (SELECT 1 FROM dbo.PetDepartment)
INSERT INTO dbo.PetDepartment(Department, Prefix) VALUES
('Data','DAT'),('Governance','GOV'),('Core','COR'),('EIS','EIS'),
('CRM','CRM'),('EA&I','EA'),('Risk','RSK'),('CET','CET'),
('Business','BUS'),('CIO Office','CIO'),('CTO','CTO'),('RTB','RTB'),('Test Gov.','TEST');
GO
