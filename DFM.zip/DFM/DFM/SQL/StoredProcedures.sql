
alter table projects add Budget decimal(18,2) null;
alter table projects add Utilization decimal(18,2) null;
alter table projects add AvailableBudget decimal(18,2) null;

-- ============================================================
-- DFM Stored Procedures
-- Replaces inline SQL with parameterized stored procedures
-- ============================================================

-- ===== Dashboard =====
IF OBJECT_ID('sp_GetDashboardSummary', 'P') IS NOT NULL DROP PROCEDURE sp_GetDashboardSummary;
GO
CREATE PROCEDURE sp_GetDashboardSummary
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        COUNT(*)                            AS TotalProjects,
        ISNULL(SUM(CASE WHEN ProjectType='CAPEX' THEN Budget ELSE 0 END),0) AS TotalCapexBudget,
        ISNULL(SUM(CASE WHEN ProjectType='OPEX'  THEN Budget ELSE 0 END),0) AS TotalOpexBudget,
        ISNULL(SUM(Utilization),0)         AS TotalUtilized,
        ISNULL(SUM(AvailableBudget),0)     AS TotalAvailable,
        ISNULL(SUM(LockedAmount),0)        AS TotalLocked,
        SUM(CASE WHEN Status='Pending'  THEN 1 ELSE 0 END) AS PendingApproval,
        SUM(CASE WHEN Status='Approved' THEN 1 ELSE 0 END) AS Approved,
        SUM(CASE WHEN Status='Rejected' THEN 1 ELSE 0 END) AS Rejected
    FROM Projects;
END
GO

-- ===== JIRA Issues: Get cached =====
IF OBJECT_ID('sp_GetJiraIssues', 'P') IS NOT NULL DROP PROCEDURE sp_GetJiraIssues;
GO
CREATE PROCEDURE sp_GetJiraIssues
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM JiraIssues ORDER BY JiraID;
END
GO

-- ===== JIRA Issues: Upsert =====
IF OBJECT_ID('sp_UpsertJiraIssue', 'P') IS NOT NULL DROP PROCEDURE sp_UpsertJiraIssue;
GO
CREATE PROCEDURE sp_UpsertJiraIssue
    @id NVARCHAR(50), @s NVARCHAR(MAX), @pn NVARCHAR(500), @st NVARCHAR(100),
    @it NVARCHAR(100), @dt NVARCHAR(200), @rag NVARCHAR(50),
    @pm NVARCHAR(200), @sme NVARCHAR(200), @ae NVARCHAR(200), @ael NVARCHAR(200),
    @asg NVARCHAR(200), @rep NVARCHAR(200), @iph NVARCHAR(200),
    @do NVARCHAR(200), @cnm NVARCHAR(200),
    @tcd DATETIME = NULL, @pdp DATETIME = NULL,
    @jc DATETIME = NULL, @ju DATETIME = NULL,
    @plt NVARCHAR(300) = NULL, @dep NVARCHAR(300) = NULL,
    @agld DATETIME = NULL, @pb0e DATETIME = NULL,
    @pb0s DATETIME = NULL, @pb0sb DATETIME = NULL,
    @pcl NVARCHAR(300) = NULL, @cl NVARCHAR(300) = NULL,
    @j NVARCHAR(MAX) = NULL,
    @ProjectKey NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM JiraIssues WHERE JiraID=@id)
        UPDATE JiraIssues SET
            Summary=@s, ProjectName=@pn, OverallStatus=@st, Status=@st,
            IssueType=@it, ProjectType=@it, DemandType=@dt, ProjectRAG=@rag,
            Manager=@pm, TechLead=@sme, Sponsor=@ae, Stakeholder=@ael,
            Assignee=@asg, Reporter=@rep,
            AccountableExecLead=@ael, SmeLead=@sme, AccountableExec=@ae,
            IdhPortfolioHead=@iph, AssignedProjectManager=@pm,
            DemandOwner=@do, ChiefNameMapping=@cnm,
            TargetCompletionDate=@tcd, ProposedDemandPickupDate=@pdp,
            JiraCreated=@jc, JiraUpdated=@ju, Platform=@plt,
            Department=@dep,
            Actual_Go_Live_Date=@agld,
            Target_Completion_Date=@tcd,
            Proposed_Demand_Pick_up_Date=@pdp,
            Proposed_Baseline_0_End_Date=@pb0e,
            Proposed_Baseline_0_Start_Date=@pb0s,
            Proposed_Baseline_0_submission_Date=@pb0sb,
            Primary_Classification=@pcl,
            Classification=@cl,
            CustomFieldsJson=@j, UpdatedDate=GETDATE(),
            ProjectKey=@ProjectKey
        WHERE JiraID=@id
    ELSE
        INSERT INTO JiraIssues(JiraID, Summary, ProjectName, OverallStatus, Status,
            IssueType, ProjectType, DemandType, ProjectRAG,
            Manager, TechLead, Sponsor, Stakeholder,
            Assignee, Reporter, AccountableExecLead, SmeLead, AccountableExec,
            IdhPortfolioHead, AssignedProjectManager, DemandOwner, ChiefNameMapping,
            TargetCompletionDate, ProposedDemandPickupDate, JiraCreated, JiraUpdated,
            Platform, Department,
            Actual_Go_Live_Date, Target_Completion_Date, Proposed_Demand_Pick_up_Date,
            Proposed_Baseline_0_End_Date, Proposed_Baseline_0_Start_Date,
            Proposed_Baseline_0_submission_Date,
            Primary_Classification, Classification,
            CustomFieldsJson, ProjectKey)
        VALUES(@id, @s, @pn, @st, @st, @it, @it, @dt, @rag,
            @pm, @sme, @ae, @ael,
            @asg, @rep, @ael, @sme, @ae,
            @iph, @pm, @do, @cnm,
            @tcd, @pdp, @jc, @ju, @plt, @dep,
            @agld, @tcd, @pdp,
            @pb0e, @pb0s, @pb0sb,
            @pcl, @cl,
            @j, @ProjectKey);
END
GO

-- ===== CAPEX Master CRUD =====
IF OBJECT_ID('sp_GetCapex', 'P') IS NOT NULL DROP PROCEDURE sp_GetCapex;
GO
CREATE PROCEDURE sp_GetCapex @search NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @search IS NULL OR @search = ''
        SELECT * FROM CapexMaster ORDER BY CapexID;
    ELSE
        SELECT * FROM CapexMaster
        WHERE CapexID LIKE '%' + @search + '%' OR Description LIKE '%' + @search + '%'
        ORDER BY CapexID;
END
GO

IF OBJECT_ID('sp_UpsertCapex', 'P') IS NOT NULL DROP PROCEDURE sp_UpsertCapex;
GO
CREATE PROCEDURE sp_UpsertCapex
    @id NVARCHAR(50), @d NVARCHAR(500),
    @b DECIMAL(18,2), @u DECIMAL(18,2), @a DECIMAL(18,2),
    @l DECIMAL(18,2), @al DECIMAL(18,2),
    @c DECIMAL(18,2), @n DECIMAL(18,2), @user NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM CapexMaster WHERE CapexID=@id)
        UPDATE CapexMaster SET Description=@d, Budget=@b, Utilization=@u, AvailableBudget=@a,
            LockedAmount=@l, BudgetAfterLockedAmount=@al, ClaimAmount=@c, NetBalance=@n,
            ModifiedDate=GETDATE(), ModifiedBy=@user
        WHERE CapexID=@id
    ELSE
        INSERT INTO CapexMaster(CapexID, Description, Budget, Utilization, AvailableBudget,
            LockedAmount, BudgetAfterLockedAmount, ClaimAmount, NetBalance, ModifiedBy)
        VALUES (@id, @d, @b, @u, @a, @l, @al, @c, @n, @user);
END
GO

IF OBJECT_ID('sp_DeleteCapex', 'P') IS NOT NULL DROP PROCEDURE sp_DeleteCapex;
GO
CREATE PROCEDURE sp_DeleteCapex @id NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM CapexMaster WHERE CapexID=@id;
END
GO

-- ===== OPEX Master CRUD =====
IF OBJECT_ID('sp_GetOpex', 'P') IS NOT NULL DROP PROCEDURE sp_GetOpex;
GO
CREATE PROCEDURE sp_GetOpex @search NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @search IS NULL OR @search = ''
        SELECT * FROM OpexMaster ORDER BY OpexID;
    ELSE
        SELECT * FROM OpexMaster
        WHERE OpexID LIKE '%' + @search + '%' OR Description LIKE '%' + @search + '%'
        ORDER BY OpexID;
END
GO

IF OBJECT_ID('sp_UpsertOpex', 'P') IS NOT NULL DROP PROCEDURE sp_UpsertOpex;
GO
CREATE PROCEDURE sp_UpsertOpex
    @id NVARCHAR(50), @d NVARCHAR(500),
    @b DECIMAL(18,2), @u DECIMAL(18,2), @a DECIMAL(18,2),
    @l DECIMAL(18,2), @al DECIMAL(18,2),
    @c DECIMAL(18,2), @n DECIMAL(18,2), @user NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM OpexMaster WHERE OpexID=@id)
        UPDATE OpexMaster SET Description=@d, Budget=@b, Utilization=@u, AvailableBudget=@a,
            LockedAmount=@l, BudgetAfterLockedAmount=@al, ClaimAmount=@c, NetBalance=@n,
            ModifiedDate=GETDATE(), ModifiedBy=@user
        WHERE OpexID=@id
    ELSE
        INSERT INTO OpexMaster(OpexID, Description, Budget, Utilization, AvailableBudget,
            LockedAmount, BudgetAfterLockedAmount, ClaimAmount, NetBalance, ModifiedBy)
        VALUES (@id, @d, @b, @u, @a, @l, @al, @c, @n, @user);
END
GO

-- ===== AMC Master CRUD =====
IF OBJECT_ID('sp_GetAmc', 'P') IS NOT NULL DROP PROCEDURE sp_GetAmc;
GO
CREATE PROCEDURE sp_GetAmc @search NVARCHAR(200) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @search IS NULL OR @search = ''
        SELECT * FROM AmcMaster ORDER BY AmcID;
    ELSE
        SELECT * FROM AmcMaster
        WHERE AmcID LIKE '%' + @search + '%' OR Description LIKE '%' + @search + '%'
        ORDER BY AmcID;
END
GO

-- ===== JIRA Config =====
IF OBJECT_ID('sp_GetJiraConfig', 'P') IS NOT NULL DROP PROCEDURE sp_GetJiraConfig;
GO
CREATE PROCEDURE sp_GetJiraConfig
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP 1 BaseUrl, UserEmail, ApiToken, ProjectKey, UserName, UserPassword
    FROM JiraConfig ORDER BY ConfigID DESC;
END
GO

IF OBJECT_ID('sp_SaveJiraConfigBasic', 'P') IS NOT NULL DROP PROCEDURE sp_SaveJiraConfigBasic;
GO
CREATE PROCEDURE sp_SaveJiraConfigBasic
    @b NVARCHAR(500), @p NVARCHAR(50), @u NVARCHAR(200), @pw NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM JiraConfig)
        UPDATE JiraConfig SET BaseUrl=@b, ProjectKey=@p, UserName=@u, UserPassword=@pw, UpdatedDate=GETDATE()
    ELSE
        INSERT INTO JiraConfig(BaseUrl, ProjectKey, UserName, UserPassword) VALUES (@b, @p, @u, @pw);
END
GO

-- ===== JIRA Fields Config =====
IF OBJECT_ID('sp_GetJiraFields', 'P') IS NOT NULL DROP PROCEDURE sp_GetJiraFields;
GO
CREATE PROCEDURE sp_GetJiraFields
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM JiraCustomFieldConfig ORDER BY DisplayOrder, FieldName;
END
GO

IF OBJECT_ID('sp_SetJiraFieldVisibility', 'P') IS NOT NULL DROP PROCEDURE sp_SetJiraFieldVisibility;
GO
CREATE PROCEDURE sp_SetJiraFieldVisibility @id INT, @v BIT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE JiraCustomFieldConfig SET IsVisible=@v, UpdatedDate=GETDATE() WHERE ID=@id;
END
GO

IF OBJECT_ID('sp_UpsertJiraField', 'P') IS NOT NULL DROP PROCEDURE sp_UpsertJiraField;
GO
CREATE PROCEDURE sp_UpsertJiraField
    @k NVARCHAR(100), @n NVARCHAR(300), @o INT, @v BIT
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM JiraCustomFieldConfig WHERE FieldKey=@k)
        UPDATE JiraCustomFieldConfig SET FieldName=@n, DisplayOrder=@o, IsVisible=@v, UpdatedDate=GETDATE() WHERE FieldKey=@k
    ELSE
        INSERT INTO JiraCustomFieldConfig(FieldKey, FieldName, DisplayOrder, IsVisible) VALUES (@k, @n, @o, @v);
END
GO

-- ===== Demand Status Summary (Dashboard bar chart) =====
IF OBJECT_ID('sp_GetDemandStatusSummary', 'P') IS NOT NULL DROP PROCEDURE sp_GetDemandStatusSummary;
GO
CREATE PROCEDURE sp_GetDemandStatusSummary
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @baseWhere NVARCHAR(200) = 'IssueType IN (''Demand'',''Idea'') OR ISNULL(IssueType,'''') = ''''';

    SELECT 'Total Demand' AS Label,
        (SELECT COUNT(*) FROM JiraIssues WHERE IssueType IN ('Demand','Idea') OR ISNULL(IssueType,'') = '') AS Cnt,
        '#1d4ed8' AS Color
    UNION ALL
    SELECT 'Active',
        (SELECT COUNT(*) FROM JiraIssues WHERE (IssueType IN ('Demand','Idea') OR ISNULL(IssueType,'') = '')
         AND ISNULL(Status,'') NOT IN ('Cancelled','Demand On Hold','Dropped','Closed','Completed',
            'Completed - Can Improve','Completed - On Track','Done','On Hold','Deferred')),
        '#15803d'
    UNION ALL
    SELECT 'On Hold',
        (SELECT COUNT(*) FROM JiraIssues WHERE (IssueType IN ('Demand','Idea') OR ISNULL(IssueType,'') = '')
         AND Status IN ('Demand On Hold','On Hold')),
        '#b45309'
    UNION ALL
    SELECT 'Cancelled',
        (SELECT COUNT(*) FROM JiraIssues WHERE (IssueType IN ('Demand','Idea') OR ISNULL(IssueType,'') = '')
         AND Status IN ('Cancelled','Dropped','Deferred')),
        '#b91c1c'
    UNION ALL
    SELECT 'Completed',
        (SELECT COUNT(*) FROM JiraIssues WHERE (IssueType IN ('Demand','Idea') OR ISNULL(IssueType,'') = '')
         AND Status IN ('Completed','Completed - Can Improve','Completed - On Track','Done')),
        '#0e7490';
END
GO

-- ===== Dashboard: Demands by Chief =====
IF OBJECT_ID('sp_GetDemandsByChief', 'P') IS NOT NULL DROP PROCEDURE sp_GetDemandsByChief;
GO
CREATE PROCEDURE sp_GetDemandsByChief
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ISNULL(NULLIF(LTRIM(RTRIM(ChiefNameMapping)),''),'Unassigned') AS Chief, COUNT(*) AS Cnt
    FROM JiraIssues
    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(ChiefNameMapping)),''),'Unassigned')
    ORDER BY COUNT(*) DESC;
END
GO

-- ===== Dashboard: Demands by Project Manager =====
IF OBJECT_ID('sp_GetDemandsByManager', 'P') IS NOT NULL DROP PROCEDURE sp_GetDemandsByManager;
GO
CREATE PROCEDURE sp_GetDemandsByManager
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ISNULL(NULLIF(LTRIM(RTRIM(Manager)),''),'Unassigned') AS Manager, COUNT(*) AS Cnt
    FROM JiraIssues
    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(Manager)),''),'Unassigned')
    ORDER BY COUNT(*) DESC;
END
GO

-- ===== Dashboard: Demands by Technical Team =====
IF OBJECT_ID('sp_GetDemandsByTechLead', 'P') IS NOT NULL DROP PROCEDURE sp_GetDemandsByTechLead;
GO
CREATE PROCEDURE sp_GetDemandsByTechLead
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ISNULL(NULLIF(LTRIM(RTRIM(TechLead)),''),'Unassigned') AS TechLead, COUNT(*) AS Cnt
    FROM JiraIssues
    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(TechLead)),''),'Unassigned')
    ORDER BY COUNT(*) DESC;
END
GO

-- ===== Dashboard: Aging Demands (demands older than 3 months) =====
IF OBJECT_ID('sp_GetAgingDemands', 'P') IS NOT NULL DROP PROCEDURE sp_GetAgingDemands;
GO
CREATE PROCEDURE sp_GetAgingDemands
AS
BEGIN
    SET NOCOUNT ON;
    SELECT JiraID, Summary, ProjectName, Status, Manager, TechLead,
           JiraCreated, DATEDIFF(MONTH, JiraCreated, GETDATE()) AS AgingMonths
    FROM JiraIssues
    WHERE JiraCreated IS NOT NULL
      AND DATEDIFF(MONTH, JiraCreated, GETDATE()) >= 3
      AND ISNULL(Status,'') NOT IN ('Done','Closed','Completed','Completed - Can Improve','Completed - On Track','Cancelled','Dropped')
    ORDER BY JiraCreated ASC;
END
GO

-- ===== Dashboard: Missed Deliverables =====
IF OBJECT_ID('sp_GetMissedDeliverables', 'P') IS NOT NULL DROP PROCEDURE sp_GetMissedDeliverables;
GO
CREATE PROCEDURE sp_GetMissedDeliverables
AS
BEGIN
    SET NOCOUNT ON;
    SELECT JiraID, Summary, ProjectName, Status, Manager, TechLead,
           TargetCompletionDate, DATEDIFF(DAY, TargetCompletionDate, GETDATE()) AS OverdueDays
    FROM JiraIssues
    WHERE TargetCompletionDate IS NOT NULL
      AND TargetCompletionDate < GETDATE()
      AND ISNULL(Status,'') NOT IN ('Done','Closed','Completed','Completed - Can Improve','Completed - On Track','Cancelled','Dropped')
    ORDER BY TargetCompletionDate ASC;
END
GO

-- ===== Dashboard: On Hold Demands =====
IF OBJECT_ID('sp_GetOnHoldDemands', 'P') IS NOT NULL DROP PROCEDURE sp_GetOnHoldDemands;
GO
CREATE PROCEDURE sp_GetOnHoldDemands
AS
BEGIN
    SET NOCOUNT ON;
    SELECT JiraID, Summary, ProjectName, Manager, TechLead, JiraCreated
    FROM JiraIssues
    WHERE Status IN ('Demand On Hold','On Hold')
    ORDER BY JiraCreated ASC;
END
GO

-- ===== Dashboard: Deferred Demands =====
IF OBJECT_ID('sp_GetDeferredDemands', 'P') IS NOT NULL DROP PROCEDURE sp_GetDeferredDemands;
GO
CREATE PROCEDURE sp_GetDeferredDemands
AS
BEGIN
    SET NOCOUNT ON;
    SELECT JiraID, Summary, ProjectName, Manager, TechLead, JiraCreated
    FROM JiraIssues
    WHERE Status IN ('Deferred')
    ORDER BY JiraCreated ASC;
END
GO

-- ===== Dashboard: Converted to Projects =====
IF OBJECT_ID('sp_GetConvertedDemands', 'P') IS NOT NULL DROP PROCEDURE sp_GetConvertedDemands;
GO
CREATE PROCEDURE sp_GetConvertedDemands
AS
BEGIN
    SET NOCOUNT ON;
    SELECT JiraID, Summary, ProjectName, Manager, TechLead, Status, JiraCreated
    FROM JiraIssues
    WHERE ProjectKey = 'DIBITP' OR IssueType = 'Project'
    ORDER BY JiraCreated DESC;
END
GO

-- ===== Dashboard: SME/PM Gantt Data =====
IF OBJECT_ID('sp_GetGanttData', 'P') IS NOT NULL DROP PROCEDURE sp_GetGanttData;
GO
CREATE PROCEDURE sp_GetGanttData @GroupBy NVARCHAR(20) = 'Manager'
AS
BEGIN
    SET NOCOUNT ON;
    IF @GroupBy = 'TechLead'
        SELECT ISNULL(NULLIF(LTRIM(RTRIM(TechLead)),''),'Unassigned') AS PersonName,
               JiraID, Summary, Status,
               Proposed_Baseline_0_Start_Date AS StartDate,
               Proposed_Baseline_0_End_Date AS EndDate,
               TargetCompletionDate
        FROM JiraIssues
        WHERE Proposed_Baseline_0_Start_Date IS NOT NULL OR Proposed_Baseline_0_End_Date IS NOT NULL
        ORDER BY TechLead, Proposed_Baseline_0_Start_Date;
    ELSE
        SELECT ISNULL(NULLIF(LTRIM(RTRIM(Manager)),''),'Unassigned') AS PersonName,
               JiraID, Summary, Status,
               Proposed_Baseline_0_Start_Date AS StartDate,
               Proposed_Baseline_0_End_Date AS EndDate,
               TargetCompletionDate
        FROM JiraIssues
        WHERE Proposed_Baseline_0_Start_Date IS NOT NULL OR Proposed_Baseline_0_End_Date IS NOT NULL
        ORDER BY Manager, Proposed_Baseline_0_Start_Date;
END
GO

-- ===== JIRA Hierarchy: Parent-Child mapping =====
IF OBJECT_ID('sp_GetJiraHierarchy', 'P') IS NOT NULL DROP PROCEDURE sp_GetJiraHierarchy;
GO
CREATE PROCEDURE sp_GetJiraHierarchy @parentId NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT JiraID, Summary, Status, IssueType, Manager, TechLead, ProjectRAG,
           TargetCompletionDate, Proposed_Baseline_0_Start_Date, Proposed_Baseline_0_End_Date,
           ParentJiraID, ProjectKey
    FROM JiraIssues
    WHERE ParentJiraID = @parentId OR JiraID = @parentId
    ORDER BY CASE WHEN JiraID = @parentId THEN 0 ELSE 1 END, JiraID;
END
GO

-- ===== Add ProjectKey and ParentJiraID columns if not present =====
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('JiraIssues') AND name = 'ProjectKey')
    ALTER TABLE JiraIssues ADD ProjectKey NVARCHAR(20) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('JiraIssues') AND name = 'ParentJiraID')
    ALTER TABLE JiraIssues ADD ParentJiraID NVARCHAR(50) NULL;
GO
