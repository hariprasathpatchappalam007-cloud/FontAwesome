-- =====================================================================
-- DFM - Additional tables for Req2.txt requirements
-- (multi-role users, PET masters & line items, notifications, attachments,
--  BPM workflow, per-project CAPEX history)
-- Run this AFTER 02_CreateTables.sql.
-- =====================================================================
USE DFM;
GO

-- ===== Multi-role assignment (a user can be Requestor, Approver, or both) =====
IF OBJECT_ID('dbo.UserRoleAssignments','U') IS NULL
CREATE TABLE dbo.UserRoleAssignments (
    AssignmentID INT IDENTITY(1,1) PRIMARY KEY,
    Username     NVARCHAR(100) NOT NULL,
    RoleType     NVARCHAR(20)  NOT NULL,   -- 'Requestor' or 'Approver'
    CreatedDate  DATETIME      NOT NULL DEFAULT(GETDATE()),
    CreatedBy    NVARCHAR(100) NULL,
    CONSTRAINT UQ_UserRoleAssignments UNIQUE (Username, RoleType)
);
GO

-- Seed: every existing user gets at least the Requestor role; users with
-- existing 'Approver' or 'Admin' role also get the Approver assignment.
IF NOT EXISTS (SELECT 1 FROM dbo.UserRoleAssignments)
BEGIN
    INSERT INTO dbo.UserRoleAssignments(Username, RoleType, CreatedBy)
    SELECT u.Username, 'Requestor', 'system' FROM dbo.AppUsers u;

    INSERT INTO dbo.UserRoleAssignments(Username, RoleType, CreatedBy)
    SELECT u.Username, 'Approver', 'system'
    FROM dbo.AppUsers u INNER JOIN dbo.UserRoles r ON u.RoleID = r.RoleID
    WHERE r.RoleName IN ('Admin','Approver');
END
GO

-- ===== Notifications =====
IF OBJECT_ID('dbo.Notifications','U') IS NULL
CREATE TABLE dbo.Notifications (
    NotificationID INT IDENTITY(1,1) PRIMARY KEY,
    Recipient      NVARCHAR(100) NOT NULL,
    Subject        NVARCHAR(300) NOT NULL,
    Message        NVARCHAR(MAX) NULL,
    LinkUrl        NVARCHAR(500) NULL,
    IsRead         BIT NOT NULL DEFAULT(0),
    CreatedDate    DATETIME NOT NULL DEFAULT(GETDATE()),
    ProjectID      INT NULL,
    NotifType      NVARCHAR(50) NULL  -- ApprovalRequest / Approved / Rejected / RouteBack / BPM ...
);
GO
CREATE INDEX IX_Notifications_Recipient ON dbo.Notifications(Recipient, IsRead);
GO

-- ===== PET Cost Type master =====
IF OBJECT_ID('dbo.PetCostType','U') IS NULL
CREATE TABLE dbo.PetCostType (
    CostTypeID  INT IDENTITY(1,1) PRIMARY KEY,
    SortOrder   INT NULL,
    Category    NVARCHAR(200) NOT NULL UNIQUE,
    IsActive    BIT NOT NULL DEFAULT(1),
    CreatedDate DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- ===== PET Department master =====
IF OBJECT_ID('dbo.PetDepartment','U') IS NULL
CREATE TABLE dbo.PetDepartment (
    DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
    Department   NVARCHAR(100) NOT NULL UNIQUE,
    Prefix       NVARCHAR(20)  NOT NULL,
    IsActive     BIT NOT NULL DEFAULT(1)
);
GO

-- ===== PET Currency master =====
IF OBJECT_ID('dbo.PetCurrency','U') IS NULL
CREATE TABLE dbo.PetCurrency (
    CurrencyID  INT IDENTITY(1,1) PRIMARY KEY,
    Code        NVARCHAR(10)  NOT NULL UNIQUE,
    Name        NVARCHAR(100) NULL,
    RateToLocal DECIMAL(18,6) NOT NULL DEFAULT(1),
    IsActive    BIT NOT NULL DEFAULT(1)
);
GO
IF NOT EXISTS (SELECT 1 FROM dbo.PetCurrency)
INSERT INTO dbo.PetCurrency(Code, Name, RateToLocal) VALUES
('AED','UAE Dirham',1.0000),
('USD','US Dollar',3.6725),
('EUR','Euro',4.0500),
('GBP','British Pound',4.6500),
('INR','Indian Rupee',0.0440),
('SAR','Saudi Riyal',0.9790);
GO

-- ===== PET Form line items per Project =====
IF OBJECT_ID('dbo.PetForm','U') IS NULL
CREATE TABLE dbo.PetForm (
    PetID            INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID        INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    SerialNo         INT NOT NULL,
    LineDate         DATETIME NOT NULL DEFAULT(GETDATE()),
    Department       NVARCHAR(100) NULL,
    LineCode         NVARCHAR(50)  NULL,    -- e.g. CET-15
    ExpHead          NVARCHAR(50)  NULL,    -- Capex / Opex
    Topic            NVARCHAR(300) NULL,
    Vendor           NVARCHAR(200) NULL,
    Description      NVARCHAR(MAX) NULL,
    CostType         NVARCHAR(200) NULL,
    UnitType         NVARCHAR(100) NULL,
    Units            DECIMAL(18,4) NOT NULL DEFAULT(0),
    UnitPrice        DECIMAL(18,4) NOT NULL DEFAULT(0),
    BaseCurrency     NVARCHAR(10)  NULL,
    AmtFCY           DECIMAL(18,2) NOT NULL DEFAULT(0),
    AmtLCY           DECIMAL(18,2) NOT NULL DEFAULT(0),
    ContingencyPct   DECIMAL(9,4)  NOT NULL DEFAULT(0),
    FinalAmtLCY      DECIMAL(18,2) NOT NULL DEFAULT(0),
    YearlyRecurrence INT NOT NULL DEFAULT(1),
    Comments         NVARCHAR(MAX) NULL,
    CreatedBy        NVARCHAR(100) NULL,
    CreatedDate      DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- Generic file attachments (Co-Pilot uploads, supporting docs, etc.)
IF OBJECT_ID('dbo.Attachments','U') IS NULL
CREATE TABLE dbo.Attachments (
    AttachmentID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID    INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    FileName     NVARCHAR(300) NOT NULL,
    StoredPath   NVARCHAR(500) NOT NULL,
    DocType      NVARCHAR(50)  NULL,   -- Invoice / Memo / Other
    SizeBytes    BIGINT NOT NULL DEFAULT(0),
    UploadedBy   NVARCHAR(100) NOT NULL,
    UploadedDate DATETIME NOT NULL DEFAULT(GETDATE()),
    ExtractedJson NVARCHAR(MAX) NULL    -- result of the document scan
);
GO

-- BPM (Business Process Management) creation request - happens after PET approval + Co-Pilot
IF OBJECT_ID('dbo.BpmRequests','U') IS NULL
CREATE TABLE dbo.BpmRequests (
    BpmID          INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID      INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    BpmReference   NVARCHAR(100) NULL,    -- offline BPM ticket id
    InvoiceNo      NVARCHAR(100) NULL,
    InvoiceDate    DATETIME      NULL,
    InvoiceAmount  DECIMAL(18,2) NOT NULL DEFAULT(0),
    Currency       NVARCHAR(10)  NULL,
    Vendor         NVARCHAR(200) NULL,
    MemoSubject    NVARCHAR(300) NULL,
    Status         NVARCHAR(30)  NOT NULL DEFAULT('Draft'),  -- Draft / Submitted / Closed
    CreatedBy      NVARCHAR(100) NOT NULL,
    CreatedDate    DATETIME      NOT NULL DEFAULT(GETDATE()),
    ClosedDate     DATETIME      NULL,
    Notes          NVARCHAR(MAX) NULL
);
GO

-- Per-project CAPEX/OPEX history (auditable record of allocations against a budget source)
IF OBJECT_ID('dbo.CapexHistory','U') IS NULL
CREATE TABLE dbo.CapexHistory (
    HistoryID    INT IDENTITY(1,1) PRIMARY KEY,
    SourceType   NVARCHAR(20)  NOT NULL,   -- CAPEX / OPEX / AMC
    SourceID     NVARCHAR(50)  NOT NULL,
    ProjectID    INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    Action       NVARCHAR(30)  NOT NULL,   -- Locked / Released / Utilized / BudgetUpdate
    Amount       DECIMAL(18,2) NOT NULL DEFAULT(0),
    PrevBudget   DECIMAL(18,2) NULL,
    NewBudget    DECIMAL(18,2) NULL,
    PrevUtil     DECIMAL(18,2) NULL,
    NewUtil      DECIMAL(18,2) NULL,
    PrevLocked   DECIMAL(18,2) NULL,
    NewLocked    DECIMAL(18,2) NULL,
    Notes        NVARCHAR(500) NULL,
    ActionBy     NVARCHAR(100) NOT NULL,
    ActionDate   DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- Ensure Projects has the additional state fields needed by the new flow.
IF COL_LENGTH('dbo.Projects','ApprovedAmount') IS NULL
    ALTER TABLE dbo.Projects ADD ApprovedAmount DECIMAL(18,2) NOT NULL DEFAULT(0);
IF COL_LENGTH('dbo.Projects','CurrentStage') IS NULL
    ALTER TABLE dbo.Projects ADD CurrentStage NVARCHAR(50) NOT NULL DEFAULT('Registration');
IF COL_LENGTH('dbo.Projects','UpdateMode') IS NULL
    ALTER TABLE dbo.Projects ADD UpdateMode NVARCHAR(20) NULL;  -- 'New' / 'ExistingUpdate'
GO
