-- =====================================================================
-- DFM Schema
-- =====================================================================
USE DFM;
GO

-- =========== Roles & Users ===========
IF OBJECT_ID('dbo.UserRoles','U') IS NULL
CREATE TABLE dbo.UserRoles (
    RoleID      INT IDENTITY(1,1) PRIMARY KEY,
    RoleName    NVARCHAR(50) NOT NULL UNIQUE,
    Description NVARCHAR(200) NULL
);
GO

IF OBJECT_ID('dbo.AppUsers','U') IS NULL
CREATE TABLE dbo.AppUsers (
    UserID         INT IDENTITY(1,1) PRIMARY KEY,
    Username       NVARCHAR(100) NOT NULL UNIQUE,
    PasswordHash   NVARCHAR(200) NULL,
    PasswordSalt   NVARCHAR(200) NULL,
    FullName       NVARCHAR(150) NOT NULL,
    Email          NVARCHAR(150) NULL,
    RoleID         INT NOT NULL FOREIGN KEY REFERENCES dbo.UserRoles(RoleID),
    IsEnabled      BIT NOT NULL DEFAULT(1),
    CreatedDate    DATETIME NOT NULL DEFAULT(GETDATE()),
    LastLoginDate  DATETIME NULL,
    CreatedBy      NVARCHAR(100) NULL
);
GO

-- =========== Theme & User settings (one-time configuration) ===========
IF OBJECT_ID('dbo.UserSettings','U') IS NULL
CREATE TABLE dbo.UserSettings (
    SettingID    INT IDENTITY(1,1) PRIMARY KEY,
    Username     NVARCHAR(100) NOT NULL UNIQUE,
    ThemeName    NVARCHAR(50)  NOT NULL DEFAULT('ocean'),
    FontSize     NVARCHAR(20)  NOT NULL DEFAULT('Large'),
    DefaultPage  NVARCHAR(100) NULL,
    Notifications BIT NOT NULL DEFAULT(1),
    UpdatedDate  DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- =========== CAPEX / OPEX / AMC Master ===========
IF OBJECT_ID('dbo.CapexMaster','U') IS NULL
CREATE TABLE dbo.CapexMaster (
    CapexID                 NVARCHAR(50) NOT NULL PRIMARY KEY,
    Description             NVARCHAR(1000) NOT NULL,
    Budget                  DECIMAL(18,2) NOT NULL DEFAULT(0),
    Utilization             DECIMAL(18,2) NOT NULL DEFAULT(0),
    AvailableBudget         DECIMAL(18,2) NOT NULL DEFAULT(0),
    LockedAmount            DECIMAL(18,2) NOT NULL DEFAULT(0),
    BudgetAfterLockedAmount DECIMAL(18,2) NOT NULL DEFAULT(0),
    ClaimAmount             DECIMAL(18,2) NOT NULL DEFAULT(0),
    NetBalance              DECIMAL(18,2) NOT NULL DEFAULT(0),
    IsActive                BIT NOT NULL DEFAULT(1),
    CreatedDate             DATETIME NOT NULL DEFAULT(GETDATE()),
    ModifiedDate            DATETIME NULL,
    ModifiedBy              NVARCHAR(100) NULL
);
GO

IF OBJECT_ID('dbo.OpexMaster','U') IS NULL
CREATE TABLE dbo.OpexMaster (
    OpexID                  NVARCHAR(50) NOT NULL PRIMARY KEY,
    Description             NVARCHAR(1000) NOT NULL,
    Budget                  DECIMAL(18,2) NOT NULL DEFAULT(0),
    Utilization             DECIMAL(18,2) NOT NULL DEFAULT(0),
    AvailableBudget         DECIMAL(18,2) NOT NULL DEFAULT(0),
    LockedAmount            DECIMAL(18,2) NOT NULL DEFAULT(0),
    BudgetAfterLockedAmount DECIMAL(18,2) NOT NULL DEFAULT(0),
    ClaimAmount             DECIMAL(18,2) NOT NULL DEFAULT(0),
    NetBalance              DECIMAL(18,2) NOT NULL DEFAULT(0),
    IsActive                BIT NOT NULL DEFAULT(1),
    CreatedDate             DATETIME NOT NULL DEFAULT(GETDATE()),
    ModifiedDate            DATETIME NULL,
    ModifiedBy              NVARCHAR(100) NULL
);
GO

IF OBJECT_ID('dbo.AmcMaster','U') IS NULL
CREATE TABLE dbo.AmcMaster (
    AmcID                   NVARCHAR(50) NOT NULL PRIMARY KEY,
    Description             NVARCHAR(1000) NOT NULL,
    Budget                  DECIMAL(18,2) NOT NULL DEFAULT(0),
    Utilization             DECIMAL(18,2) NOT NULL DEFAULT(0),
    AvailableBudget         DECIMAL(18,2) NOT NULL DEFAULT(0),
    LockedAmount            DECIMAL(18,2) NOT NULL DEFAULT(0),
    BudgetAfterLockedAmount DECIMAL(18,2) NOT NULL DEFAULT(0),
    ClaimAmount             DECIMAL(18,2) NOT NULL DEFAULT(0),
    NetBalance              DECIMAL(18,2) NOT NULL DEFAULT(0),
    IsActive                BIT NOT NULL DEFAULT(1),
    CreatedDate             DATETIME NOT NULL DEFAULT(GETDATE()),
    ModifiedDate            DATETIME NULL,
    ModifiedBy              NVARCHAR(100) NULL
);
GO

-- =========== Approver master ===========
IF OBJECT_ID('dbo.ApproverMaster','U') IS NULL
CREATE TABLE dbo.ApproverMaster (
    ApproverID    INT IDENTITY(1,1) PRIMARY KEY,
    ApproverName  NVARCHAR(150) NOT NULL,
    Email         NVARCHAR(150) NULL,
    Department    NVARCHAR(100) NULL,
    ApprovalLevel INT NOT NULL DEFAULT(1),
    IsActive      BIT NOT NULL DEFAULT(1),
    CreatedDate   DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- =========== JIRA configuration ===========
IF OBJECT_ID('dbo.JiraConfig','U') IS NULL
CREATE TABLE dbo.JiraConfig (
    ConfigID    INT IDENTITY(1,1) PRIMARY KEY,
    BaseUrl     NVARCHAR(300) NULL,
    UserEmail   NVARCHAR(150) NULL,
    ApiToken    NVARCHAR(300) NULL,
    ProjectKey  NVARCHAR(50)  NULL,
    UpdatedDate DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- Per-user/visibility selection of JIRA custom fields
IF OBJECT_ID('dbo.JiraCustomFieldConfig','U') IS NULL
CREATE TABLE dbo.JiraCustomFieldConfig (
    ID            INT IDENTITY(1,1) PRIMARY KEY,
    FieldKey      NVARCHAR(100) NOT NULL,    -- e.g. customfield_10010
    FieldName     NVARCHAR(150) NOT NULL,
    DisplayOrder  INT NOT NULL DEFAULT(0),
    IsVisible     BIT NOT NULL DEFAULT(1),
    UpdatedBy     NVARCHAR(100) NULL,
    UpdatedDate   DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- Cached/sample list of JIRA IDs (used for dropdown)
IF OBJECT_ID('dbo.JiraIssues','U') IS NULL
CREATE TABLE dbo.JiraIssues (
    JiraID        NVARCHAR(50) NOT NULL PRIMARY KEY,
    Summary       NVARCHAR(500) NULL,
    ProjectName   NVARCHAR(300) NULL,
    StartDate     NVARCHAR(50)  NULL,
    EndDate       NVARCHAR(50)  NULL,
    OverallStatus NVARCHAR(100) NULL,
    ProjectStage  NVARCHAR(100) NULL,
    ProjectType   NVARCHAR(100) NULL,
    DemandType    NVARCHAR(100) NULL,
    ProjectRAG    NVARCHAR(50)  NULL,
    Department    NVARCHAR(200) NULL,
    Manager       NVARCHAR(150) NULL,
    TechLead      NVARCHAR(150) NULL,
    Sponsor       NVARCHAR(150) NULL,
    Stakeholder   NVARCHAR(200) NULL,
    Classification NVARCHAR(100) NULL,
    Objectives    NVARCHAR(MAX) NULL,
    CustomFieldsJson NVARCHAR(MAX) NULL,
    UpdatedDate   DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- =========== Projects (transaction) ===========
IF OBJECT_ID('dbo.Projects','U') IS NULL
CREATE TABLE dbo.Projects (
    ProjectID         INT IDENTITY(1,1) PRIMARY KEY,
    ProjectCode       AS ('PRJ-' + RIGHT('00000' + CAST(ProjectID AS VARCHAR(10)),5)) PERSISTED,
    JiraID            NVARCHAR(50) NULL,
    ProjectName       NVARCHAR(300) NOT NULL,
    ProjectType       NVARCHAR(20)  NOT NULL,   -- CAPEX | OPEX | AMC
    BudgetSourceID    NVARCHAR(50)  NULL,        -- CapexID/OpexID/AmcID
    RequestedAmount   DECIMAL(18,2) NOT NULL DEFAULT(0),
    LockedAmount      DECIMAL(18,2) NOT NULL DEFAULT(0),
    DebitedAmount     DECIMAL(18,2) NOT NULL DEFAULT(0),
    ApproverID        INT NULL FOREIGN KEY REFERENCES dbo.ApproverMaster(ApproverID),
    Status            NVARCHAR(30)  NOT NULL DEFAULT('Draft'), -- Draft | Pending | Approved | Rejected | Funded
    BaselinePlan      NVARCHAR(MAX) NULL,
    Comments          NVARCHAR(MAX) NULL,
    Version           INT NOT NULL DEFAULT(1),
    CreatedBy         NVARCHAR(100) NOT NULL,
    CreatedDate       DATETIME NOT NULL DEFAULT(GETDATE()),
    ModifiedBy        NVARCHAR(100) NULL,
    ModifiedDate      DATETIME NULL,
    SubmittedDate     DATETIME NULL,
    ApprovedDate      DATETIME NULL
);
GO

-- =========== Workflow / version / lock / debit / comment history ===========
IF OBJECT_ID('dbo.WorkflowHistory','U') IS NULL
CREATE TABLE dbo.WorkflowHistory (
    HistoryID     INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID     INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    Stage         NVARCHAR(50)  NOT NULL,   -- Draft / Submitted / Approved / Rejected / Modified
    ApprovalLevel INT NULL,
    ActionBy      NVARCHAR(100) NOT NULL,
    ActionDate    DATETIME NOT NULL DEFAULT(GETDATE()),
    Comments      NVARCHAR(MAX) NULL,
    Version       INT NOT NULL DEFAULT(1)
);
GO

IF OBJECT_ID('dbo.LockedAmountHistory','U') IS NULL
CREATE TABLE dbo.LockedAmountHistory (
    HistoryID    INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID    INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    SourceType   NVARCHAR(20) NOT NULL,
    SourceID     NVARCHAR(50) NOT NULL,
    Amount       DECIMAL(18,2) NOT NULL,
    Action       NVARCHAR(20)  NOT NULL, -- Locked | Released
    ActionBy     NVARCHAR(100) NOT NULL,
    ActionDate   DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

IF OBJECT_ID('dbo.DebitedAmountHistory','U') IS NULL
CREATE TABLE dbo.DebitedAmountHistory (
    HistoryID    INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID    INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    SourceType   NVARCHAR(20) NOT NULL,
    SourceID     NVARCHAR(50) NOT NULL,
    Amount       DECIMAL(18,2) NOT NULL,
    ActionBy     NVARCHAR(100) NOT NULL,
    ActionDate   DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

IF OBJECT_ID('dbo.ProjectVersionHistory','U') IS NULL
CREATE TABLE dbo.ProjectVersionHistory (
    VersionID     INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID     INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    Version       INT NOT NULL,
    SnapshotJson  NVARCHAR(MAX) NOT NULL,
    ChangedBy     NVARCHAR(100) NOT NULL,
    ChangedDate   DATETIME NOT NULL DEFAULT(GETDATE()),
    ChangeNotes   NVARCHAR(MAX) NULL
);
GO

IF OBJECT_ID('dbo.ProjectComments','U') IS NULL
CREATE TABLE dbo.ProjectComments (
    CommentID    INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID    INT NOT NULL FOREIGN KEY REFERENCES dbo.Projects(ProjectID),
    CommentText  NVARCHAR(MAX) NOT NULL,
    CommentedBy  NVARCHAR(100) NOT NULL,
    CommentedDate DATETIME NOT NULL DEFAULT(GETDATE())
);
GO
