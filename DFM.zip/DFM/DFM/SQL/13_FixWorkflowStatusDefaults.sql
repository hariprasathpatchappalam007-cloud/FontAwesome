-- =====================================================================
-- DFM - Fix #13: Workflow Stage Status Defaults
--
-- Problem (Observation 1):
--   PetApprovalStatus, PetStageStatus and BpmStageStatus were added with
--   DEFAULT('Pending').  This caused the "Pending with <Approver>" banner
--   and stepper to show "Pending" immediately after project creation,
--   before any approval step had actually been triggered.
--
-- Fix:
--   1. Reset the status columns to NULL for projects that have not yet
--      reached the corresponding workflow stage.
--   2. Drop the DEFAULT('Pending') constraints and replace them with
--      NULL defaults so future INSERTs start with NULL.
--
-- Run AFTER 12_ApproverUsernameLink.sql
-- =====================================================================
USE DFM;
GO

-- -----------------------------------------------------------------------
-- Step 1: Reset PetApprovalStatus to NULL for projects that have never
--         been submitted for PET approval (i.e., PetStageStatus is still
--         the DB default or the project is still in Project/PET stage).
-- -----------------------------------------------------------------------
UPDATE dbo.Projects
SET    PetApprovalStatus = NULL
WHERE  PetApprovalStatus = 'Pending'
  AND  (   PetStageStatus IS NULL
        OR PetStageStatus = 'Pending' )
  AND  (   CurrentStage IS NULL
        OR CurrentStage NOT IN ('PET Approval', 'BPM', 'Closed'));
GO

-- -----------------------------------------------------------------------
-- Step 2: Reset BpmStageStatus to NULL for projects that have not yet
--         entered the BPM stage.
-- -----------------------------------------------------------------------
UPDATE dbo.Projects
SET    BpmStageStatus = NULL
WHERE  BpmStageStatus = 'Pending'
  AND  (   CurrentStage IS NULL
        OR CurrentStage NOT IN ('BPM', 'Closed'));
GO

-- -----------------------------------------------------------------------
-- Step 3: Reset PetStageStatus to NULL for projects still at the
--         Project Registration / CAPEX stage (never started PET entry).
-- -----------------------------------------------------------------------
UPDATE dbo.Projects
SET    PetStageStatus = NULL
WHERE  PetStageStatus = 'Pending'
  AND  (   CurrentStage IS NULL
        OR CurrentStage IN ('Registration', ''));
GO

-- -----------------------------------------------------------------------
-- Step 4: Replace DEFAULT('Pending') constraints with NULL defaults
--         so future rows are inserted with NULL rather than 'Pending'.
-- -----------------------------------------------------------------------
DECLARE @sql NVARCHAR(500);

-- PetStageStatus
SELECT @sql = 'ALTER TABLE dbo.Projects DROP CONSTRAINT ' + dc.name
FROM   sys.default_constraints dc
JOIN   sys.columns c
       ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
WHERE  OBJECT_NAME(dc.parent_object_id) = 'Projects'
  AND  c.name = 'PetStageStatus';
IF @sql IS NOT NULL EXEC(@sql);
GO

DECLARE @sql NVARCHAR(500);
-- PetApprovalStatus
SELECT @sql = 'ALTER TABLE dbo.Projects DROP CONSTRAINT ' + dc.name
FROM   sys.default_constraints dc
JOIN   sys.columns c
       ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
WHERE  OBJECT_NAME(dc.parent_object_id) = 'Projects'
  AND  c.name = 'PetApprovalStatus';
IF @sql IS NOT NULL EXEC(@sql);
GO

DECLARE @sql NVARCHAR(500);
-- BpmStageStatus
SELECT @sql = 'ALTER TABLE dbo.Projects DROP CONSTRAINT ' + dc.name
FROM   sys.default_constraints dc
JOIN   sys.columns c
       ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
WHERE  OBJECT_NAME(dc.parent_object_id) = 'Projects'
  AND  c.name = 'BpmStageStatus';
IF @sql IS NOT NULL EXEC(@sql);
GO

PRINT 'Migration 13 complete: workflow stage status defaults reset to NULL.';
GO
