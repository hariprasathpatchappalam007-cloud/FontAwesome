-- ============================================================
-- Req6: Console reliability + Dashboard performance schema
--
-- Goals:
--   1. Fix DMGT-271 NULL JiraID upsert failure
--      ("Cannot insert the value NULL into column 'JiraID'").
--   2. Fix sp_ApplyHierarchyInheritance crash caused by reference
--      to a non-existent ProjectManager column.
--   3. Add additional inherited fields so DIBITP children pick up
--      Chief / Portfolio Head / PM / Demand Owner / Demand Type from
--      their DMGT parent (Req6: "Chief Data flow from parent to child").
--   4. Pre-aggregate ALL dashboard chart data into a single
--      DashboardReport table so Default.aspx never aggregates
--      JiraIssues at request time ("blink of the eye" load).
--   5. Persist a compact list of recent dashboard execution
--      scenarios for troubleshooting.
-- ============================================================

USE [DFM]
GO
SET NOCOUNT ON;
GO

-- ----- 1. Relax JiraID NOT NULL so the console insert no longer fails -------
-- The Req5 console writes JiraKey (e.g. DMGT-271) as the natural key.
-- The legacy JiraID column predates that flow. The cleanest non-breaking
-- fix is to (a) allow NULL on inserts and (b) back-fill JiraID = JiraKey
-- after every sync so legacy joins continue to work.
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('dbo.JiraIssues')
      AND name = 'JiraID' AND is_nullable = 0)
BEGIN
    -- Drop the PK on JiraID (if present) before relaxing nullability
    DECLARE @pk SYSNAME =
        (SELECT TOP 1 kc.name
         FROM sys.key_constraints kc
         WHERE kc.parent_object_id = OBJECT_ID('dbo.JiraIssues')
           AND kc.type = 'PK');
    IF @pk IS NOT NULL
        EXEC('ALTER TABLE dbo.JiraIssues DROP CONSTRAINT ' + @pk);

    ALTER TABLE dbo.JiraIssues ALTER COLUMN JiraID NVARCHAR(50) NULL;

    -- Promote JiraKey to the natural primary key (UNIQUE NOT NULL).
    -- We keep JiraID for legacy joins (e.g. Projects.JiraID).
    UPDATE dbo.JiraIssues SET JiraKey = JiraID WHERE ISNULL(JiraKey,'') = '';
    IF NOT EXISTS (SELECT 1 FROM sys.indexes
                   WHERE object_id = OBJECT_ID('dbo.JiraIssues')
                     AND name = 'PK_JiraIssues_JiraKey')
        ALTER TABLE dbo.JiraIssues
            ADD CONSTRAINT PK_JiraIssues_JiraKey PRIMARY KEY (JiraKey);
END
GO

-- Ensure JiraKey is NOT NULL (must be set before adding the PK above,
-- but defensively re-assert in case the PK already existed on JiraID).
UPDATE dbo.JiraIssues SET JiraKey = JiraID WHERE ISNULL(JiraKey,'') = '' AND JiraID IS NOT NULL;
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE object_id = OBJECT_ID('dbo.JiraIssues')
      AND name = 'JiraKey' AND is_nullable = 1)
BEGIN
    -- Only enforce NOT NULL when no NULLs remain (avoid breaking fresh dbs).
    IF NOT EXISTS (SELECT 1 FROM dbo.JiraIssues WHERE JiraKey IS NULL)
        ALTER TABLE dbo.JiraIssues ALTER COLUMN JiraKey NVARCHAR(50) NOT NULL;
END
GO

-- ----- 2. Helpful indexes that the new report SP relies on ------------------
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_Status')
    CREATE INDEX IX_JiraIssues_Status ON dbo.JiraIssues(Status);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_Chief')
    CREATE INDEX IX_JiraIssues_Chief ON dbo.JiraIssues(ChiefNameMapping);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_Manager')
    CREATE INDEX IX_JiraIssues_Manager ON dbo.JiraIssues(Manager);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_TechLead')
    CREATE INDEX IX_JiraIssues_TechLead ON dbo.JiraIssues(TechLead);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_JiraIssues_PortfolioHead')
    CREATE INDEX IX_JiraIssues_PortfolioHead ON dbo.JiraIssues(IdhPortfolioHead);
GO

-- ----- 3. Fix sp_ApplyHierarchyInheritance + add more inherited fields -----
-- The Req5 version referenced a column "ProjectManager" that does not exist
-- (the actual column is AssignedProjectManager). It also did not inherit
-- Portfolio Head / Demand Type / Demand Owner. Req6 extends this.
IF OBJECT_ID('dbo.sp_ApplyHierarchyInheritance','P') IS NOT NULL
    DROP PROCEDURE dbo.sp_ApplyHierarchyInheritance;
GO
CREATE PROCEDURE dbo.sp_ApplyHierarchyInheritance
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH P AS (
        SELECT JiraKey, ChiefNameMapping, Manager, TechLead,
               AssignedProjectManager, IdhPortfolioHead, DemandOwner,
               DemandType, Platform, PlatformVertical, PlatformName
        FROM   dbo.JiraIssues
        WHERE  ProjectKey = 'DMGT'
    )
    UPDATE c
    SET
        c.ChiefNameMapping      = COALESCE(NULLIF(c.ChiefNameMapping,''),      p.ChiefNameMapping),
        c.Manager               = COALESCE(NULLIF(c.Manager,''),               p.Manager),
        c.TechLead              = COALESCE(NULLIF(c.TechLead,''),              p.TechLead),
        c.AssignedProjectManager= COALESCE(NULLIF(c.AssignedProjectManager,''),p.AssignedProjectManager),
        c.IdhPortfolioHead      = COALESCE(NULLIF(c.IdhPortfolioHead,''),      p.IdhPortfolioHead),
        c.DemandOwner           = COALESCE(NULLIF(c.DemandOwner,''),           p.DemandOwner),
        c.DemandType            = COALESCE(NULLIF(c.DemandType,''),            p.DemandType),
        c.Platform              = COALESCE(NULLIF(c.Platform,''),              p.Platform),
        c.PlatformVertical      = COALESCE(NULLIF(c.PlatformVertical,''),      p.PlatformVertical),
        c.PlatformName          = COALESCE(NULLIF(c.PlatformName,''),          p.PlatformName)
    FROM dbo.JiraIssues c
    INNER JOIN P p ON p.JiraKey = c.ParentJiraID
    WHERE c.ProjectKey = 'DIBITP';

    -- Two-hop chain (DIBITP grandchildren under DIBITP)
    UPDATE c
    SET
        c.ChiefNameMapping      = COALESCE(NULLIF(c.ChiefNameMapping,''),      p.ChiefNameMapping),
        c.Manager               = COALESCE(NULLIF(c.Manager,''),               p.Manager),
        c.TechLead              = COALESCE(NULLIF(c.TechLead,''),              p.TechLead),
        c.AssignedProjectManager= COALESCE(NULLIF(c.AssignedProjectManager,''),p.AssignedProjectManager),
        c.IdhPortfolioHead      = COALESCE(NULLIF(c.IdhPortfolioHead,''),      p.IdhPortfolioHead),
        c.DemandOwner           = COALESCE(NULLIF(c.DemandOwner,''),           p.DemandOwner),
        c.DemandType            = COALESCE(NULLIF(c.DemandType,''),            p.DemandType),
        c.Platform              = COALESCE(NULLIF(c.Platform,''),              p.Platform),
        c.PlatformVertical      = COALESCE(NULLIF(c.PlatformVertical,''),      p.PlatformVertical),
        c.PlatformName          = COALESCE(NULLIF(c.PlatformName,''),          p.PlatformName)
    FROM dbo.JiraIssues c
    INNER JOIN dbo.JiraIssues p ON p.JiraKey = c.ParentJiraID
    WHERE c.ProjectKey = 'DIBITP' AND p.ProjectKey = 'DIBITP';

    -- Back-fill JiraID for any row that came in via the Req6 console
    -- (this lets legacy joins on Projects.JiraID keep working).
    UPDATE dbo.JiraIssues SET JiraID = JiraKey
    WHERE ISNULL(JiraID,'') = '' AND JiraKey IS NOT NULL;
END
GO

-- ============================================================
-- 4. New table: DashboardReport
--    A single pre-aggregated row-set the dashboard reads from.
--    One row per (Section, Bucket [, SubBucket]) with counts.
--    Sections used by Default.aspx:
--       'KPI'                 - headline numbers
--       'DemandStatus'        - active / on hold / cancelled / completed
--       'PlatformDemand'      - count per platform (DMGT only)
--       'PortfolioByPlatform' - portfolio head x platform
--       'DeliveryByVertical'  - delivered vs in-flight per vertical
--       'RagDistribution'     - Red/Amber/Green/Blue/Unknown
--       'AgingBuckets'        - open demand aging
--       'PMWorkload'          - top project managers
--       'TLWorkload'          - top tech leads
--       'ChiefOwnership'      - top chiefs
--       'MarketTrending'      - "what I don't see" hot items
-- ============================================================
IF OBJECT_ID('dbo.DashboardReport','U') IS NOT NULL
    DROP TABLE dbo.DashboardReport;
GO
CREATE TABLE dbo.DashboardReport (
    ReportID       INT IDENTITY(1,1) PRIMARY KEY,
    Section        NVARCHAR(50)  NOT NULL,
    Bucket         NVARCHAR(300) NOT NULL,
    SubBucket      NVARCHAR(300) NULL,
    TotalCount     INT NOT NULL DEFAULT 0,
    OpenCount      INT NOT NULL DEFAULT 0,
    ClosedCount    INT NOT NULL DEFAULT 0,
    RedCount       INT NOT NULL DEFAULT 0,
    AmberCount     INT NOT NULL DEFAULT 0,
    GreenCount     INT NOT NULL DEFAULT 0,
    SortOrder      INT NOT NULL DEFAULT 0,
    Extra          NVARCHAR(MAX) NULL,    -- optional JSON payload
    LastRefreshed  DATETIME NOT NULL DEFAULT GETDATE()
);
CREATE INDEX IX_DashRpt_Section ON dbo.DashboardReport(Section, SortOrder);
GO

-- ============================================================
-- 5. SP: refresh DashboardReport (called by console after sync)
-- ============================================================
IF OBJECT_ID('dbo.sp_RefreshDashboardReport','P') IS NOT NULL
    DROP PROCEDURE dbo.sp_RefreshDashboardReport;
GO
CREATE PROCEDURE dbo.sp_RefreshDashboardReport
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @now DATETIME = GETDATE();

    -- The dashboard's "Demand" sections must come from DMGT only (Req6).
    DECLARE @ClosedStatuses TABLE (S NVARCHAR(100));
    INSERT INTO @ClosedStatuses VALUES
        ('Done'),('Closed'),('Cancelled'),('Dropped'),('Completed'),
        ('Completed - Can Improve'),('Completed - On Track');

    TRUNCATE TABLE dbo.DashboardReport;

    -- ---------- 5.1 Headline KPIs ----------
    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'KPI', 'TotalDemand',
           COUNT(*), 1
    FROM dbo.JiraIssues WHERE ProjectKey = 'DMGT';

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'KPI', 'ActiveDemand',
           COUNT(*), 2
    FROM dbo.JiraIssues
    WHERE ProjectKey = 'DMGT'
      AND ISNULL(Status,'') NOT IN (SELECT S FROM @ClosedStatuses)
      AND ISNULL(Status,'') NOT IN ('Demand On Hold','On Hold','Deferred');

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'KPI', 'OnHold',
           COUNT(*), 3
    FROM dbo.JiraIssues
    WHERE ProjectKey = 'DMGT' AND Status IN ('Demand On Hold','On Hold');

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'KPI', 'Deferred',
           COUNT(*), 4
    FROM dbo.JiraIssues
    WHERE ProjectKey = 'DMGT' AND Status = 'Deferred';

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'KPI', 'ConvertedToProject',
           COUNT(*), 5
    FROM dbo.JiraIssues
    WHERE ProjectKey = 'DIBITP';

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'KPI', 'MissedDeliverables',
           COUNT(*), 6
    FROM dbo.JiraIssues
    WHERE ProjectKey = 'DMGT'
      AND TargetCompletionDate IS NOT NULL
      AND TargetCompletionDate < @now
      AND ISNULL(Status,'') NOT IN (SELECT S FROM @ClosedStatuses);

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, RedCount, AmberCount, GreenCount, SortOrder)
    SELECT 'KPI', 'RAG',
        COUNT(*),
        SUM(CASE WHEN OverallProjectRag = 'Red'   THEN 1 ELSE 0 END),
        SUM(CASE WHEN OverallProjectRag = 'Amber' THEN 1 ELSE 0 END),
        SUM(CASE WHEN OverallProjectRag = 'Green' THEN 1 ELSE 0 END),
        7
    FROM dbo.JiraIssues WHERE ProjectKey = 'DMGT';

    -- ---------- 5.2 Demand Status bars ----------
    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'DemandStatus', 'Active',
        COUNT(*), 1
    FROM dbo.JiraIssues
    WHERE ProjectKey='DMGT'
      AND ISNULL(Status,'') NOT IN (SELECT S FROM @ClosedStatuses)
      AND ISNULL(Status,'') NOT IN ('Demand On Hold','On Hold','Deferred');

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'DemandStatus', 'On Hold',  COUNT(*), 2
    FROM dbo.JiraIssues
    WHERE ProjectKey='DMGT' AND Status IN ('Demand On Hold','On Hold');

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'DemandStatus', 'Cancelled', COUNT(*), 3
    FROM dbo.JiraIssues
    WHERE ProjectKey='DMGT' AND Status IN ('Cancelled','Dropped','Deferred');

    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'DemandStatus', 'Completed', COUNT(*), 4
    FROM dbo.JiraIssues
    WHERE ProjectKey='DMGT' AND Status IN
        ('Completed','Completed - Can Improve','Completed - On Track','Done','Closed');

    -- ---------- 5.3 Demand by Platform (DMGT only - Req6) ----------
    ;WITH JiraData AS
(
    SELECT 
        ISNULL(NULLIF(LTRIM(RTRIM(JI.Platform)), ''), 'Unknown') AS PlatformName,
        CASE 
            WHEN CS.S IS NOT NULL THEN 1 
            ELSE 0 
        END AS IsClosed
    FROM dbo.JiraIssues JI
    LEFT JOIN @ClosedStatuses CS
        ON ISNULL(JI.Status, '') = CS.S
    WHERE JI.ProjectKey = 'DMGT'
),
PlatformSummary AS
(
    SELECT
        PlatformName,
        COUNT(*) AS TotalCount,
        SUM(CASE WHEN IsClosed = 0 THEN 1 ELSE 0 END) AS OpenCount,
        SUM(CASE WHEN IsClosed = 1 THEN 1 ELSE 0 END) AS ClosedCount
    FROM JiraData
    GROUP BY PlatformName
)

INSERT INTO dbo.DashboardReport
(
    Section,
    Bucket,
    TotalCount,
    OpenCount,
    ClosedCount,
    SortOrder
)
SELECT
    'PlatformDemand',
    PlatformName,
    TotalCount,
    OpenCount,
    ClosedCount,
    ROW_NUMBER() OVER (ORDER BY TotalCount DESC) AS SortOrder
FROM PlatformSummary;

    -- ---------- 5.4 Portfolio Head by Platform ----------
    ;WITH JiraData AS
(
    SELECT 
        ISNULL(NULLIF(LTRIM(RTRIM(JI.IdhPortfolioHead)), ''), 'Unassigned') AS PortfolioHead,
        ISNULL(NULLIF(LTRIM(RTRIM(JI.Platform)), ''), 'Unknown') AS PlatformName,
        CASE 
            WHEN CS.S IS NOT NULL THEN 1 
            ELSE 0 
        END AS IsClosed
    FROM dbo.JiraIssues JI
    LEFT JOIN @ClosedStatuses CS
        ON ISNULL(JI.Status, '') = CS.S
    WHERE JI.ProjectKey = 'DMGT'
),
PortfolioSummary AS
(
    SELECT
        PortfolioHead,
        PlatformName,
        COUNT(*) AS TotalCount,
        SUM(CASE WHEN IsClosed = 0 THEN 1 ELSE 0 END) AS OpenCount
    FROM JiraData
    GROUP BY 
        PortfolioHead,
        PlatformName
)

INSERT INTO dbo.DashboardReport
(
    Section,
    Bucket,
    SubBucket,
    TotalCount,
    OpenCount,
    SortOrder
)
SELECT
    'PortfolioByPlatform',
    PortfolioHead,
    PlatformName,
    TotalCount,
    OpenCount,
    ROW_NUMBER() OVER (ORDER BY TotalCount DESC) AS SortOrder
FROM PortfolioSummary;

    -- ---------- 5.5 Delivery Summary by Vertical ----------
    ;WITH JiraData AS
(
    SELECT 
        ISNULL(NULLIF(LTRIM(RTRIM(JI.PlatformVertical)), ''), 'Unknown') AS PlatformVertical,
        CASE 
            WHEN CS.S IS NOT NULL THEN 1 
            ELSE 0 
        END AS IsClosed
    FROM dbo.JiraIssues JI
    LEFT JOIN @ClosedStatuses CS
        ON ISNULL(JI.Status, '') = CS.S
    WHERE JI.ProjectKey = 'DMGT'
),
VerticalSummary AS
(
    SELECT
        PlatformVertical,
        COUNT(*) AS TotalCount,
        SUM(CASE WHEN IsClosed = 0 THEN 1 ELSE 0 END) AS OpenCount,
        SUM(CASE WHEN IsClosed = 1 THEN 1 ELSE 0 END) AS ClosedCount
    FROM JiraData
    GROUP BY PlatformVertical
)

INSERT INTO dbo.DashboardReport
(
    Section,
    Bucket,
    TotalCount,
    OpenCount,
    ClosedCount,
    SortOrder
)
SELECT
    'DeliveryByVertical',
    PlatformVertical,
    TotalCount,
    OpenCount,
    ClosedCount,
    ROW_NUMBER() OVER (ORDER BY TotalCount DESC) AS SortOrder
FROM VerticalSummary;

    -- ---------- 5.6 RAG Distribution ----------
    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'RagDistribution',
           ISNULL(NULLIF(LTRIM(RTRIM(OverallProjectRag)),''),'Unspecified'),
           COUNT(*),
           CASE ISNULL(NULLIF(LTRIM(RTRIM(OverallProjectRag)),''),'Unspecified')
                WHEN 'Red' THEN 1 WHEN 'Amber' THEN 2 WHEN 'Green' THEN 3
                WHEN 'Blue' THEN 4 ELSE 5 END
    FROM dbo.JiraIssues
    WHERE ProjectKey = 'DMGT'
    GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(OverallProjectRag)),''),'Unspecified');

    -- ---------- 5.7 Open Demand Aging Buckets ----------
    INSERT INTO dbo.DashboardReport(Section, Bucket, TotalCount, SortOrder)
    SELECT 'AgingBuckets', AgeBucket, COUNT(*),
           CASE AgeBucket WHEN '<3 Months' THEN 1 WHEN '3-6 Months' THEN 2
                          WHEN '7-12 Months' THEN 3 ELSE 4 END
    FROM (
        SELECT CASE
            WHEN DATEDIFF(MONTH, ISNULL(JiraCreated,@now), @now) < 3  THEN '<3 Months'
            WHEN DATEDIFF(MONTH, JiraCreated, @now) BETWEEN 3 AND 6   THEN '3-6 Months'
            WHEN DATEDIFF(MONTH, JiraCreated, @now) BETWEEN 7 AND 12  THEN '7-12 Months'
            ELSE '12+ Months' END AS AgeBucket
        FROM dbo.JiraIssues
        WHERE ProjectKey='DMGT'
          AND ISNULL(Status,'') NOT IN (SELECT S FROM @ClosedStatuses)
    ) X
    GROUP BY AgeBucket;

    -- ---------- 5.8 Team Performance: PM / TL / Chief ----------
    ------------------------------------------------------------
-- PM Workload
------------------------------------------------------------
;WITH JiraData AS
(
    SELECT
        ISNULL(
            NULLIF(LTRIM(RTRIM(JI.AssignedProjectManager)), ''),
            ISNULL(NULLIF(LTRIM(RTRIM(JI.Manager)), ''), 'Unassigned')
        ) AS PMName,
        CASE 
            WHEN CS.S IS NOT NULL THEN 1 
            ELSE 0 
        END AS IsClosed
    FROM dbo.JiraIssues JI
    LEFT JOIN @ClosedStatuses CS
        ON ISNULL(JI.Status, '') = CS.S
    WHERE JI.ProjectKey IN ('DMGT','DIBITP')
),
PMSummary AS
(
    SELECT
        PMName,
        COUNT(*) AS TotalCount,
        SUM(CASE WHEN IsClosed = 0 THEN 1 ELSE 0 END) AS OpenCount
    FROM JiraData
    GROUP BY PMName
)

INSERT INTO dbo.DashboardReport
(
    Section,
    Bucket,
    TotalCount,
    OpenCount,
    SortOrder
)
SELECT TOP 15
    'PMWorkload',
    PMName,
    TotalCount,
    OpenCount,
    ROW_NUMBER() OVER (ORDER BY TotalCount DESC) AS SortOrder
FROM PMSummary
ORDER BY TotalCount DESC;


------------------------------------------------------------
-- TL Workload
------------------------------------------------------------
;WITH JiraData AS
(
    SELECT
        ISNULL(NULLIF(LTRIM(RTRIM(JI.TechLead)), ''), 'Unassigned') AS TLName,
        CASE 
            WHEN CS.S IS NOT NULL THEN 1 
            ELSE 0 
        END AS IsClosed
    FROM dbo.JiraIssues JI
    LEFT JOIN @ClosedStatuses CS
        ON ISNULL(JI.Status, '') = CS.S
    WHERE JI.ProjectKey IN ('DMGT','DIBITP')
),
TLSummary AS
(
    SELECT
        TLName,
        COUNT(*) AS TotalCount,
        SUM(CASE WHEN IsClosed = 0 THEN 1 ELSE 0 END) AS OpenCount
    FROM JiraData
    GROUP BY TLName
)

INSERT INTO dbo.DashboardReport
(
    Section,
    Bucket,
    TotalCount,
    OpenCount,
    SortOrder
)
SELECT TOP 15
    'TLWorkload',
    TLName,
    TotalCount,
    OpenCount,
    ROW_NUMBER() OVER (ORDER BY TotalCount DESC) AS SortOrder
FROM TLSummary
ORDER BY TotalCount DESC;


------------------------------------------------------------
-- Chief Ownership
------------------------------------------------------------
;WITH JiraData AS
(
    SELECT
        ISNULL(NULLIF(LTRIM(RTRIM(JI.ChiefNameMapping)), ''), 'Unassigned') AS ChiefName,
        CASE 
            WHEN CS.S IS NOT NULL THEN 1 
            ELSE 0 
        END AS IsClosed
    FROM dbo.JiraIssues JI
    LEFT JOIN @ClosedStatuses CS
        ON ISNULL(JI.Status, '') = CS.S
    WHERE JI.ProjectKey = 'DMGT'
),
ChiefSummary AS
(
    SELECT
        ChiefName,
        COUNT(*) AS TotalCount,
        SUM(CASE WHEN IsClosed = 0 THEN 1 ELSE 0 END) AS OpenCount
    FROM JiraData
    GROUP BY ChiefName
)

INSERT INTO dbo.DashboardReport
(
    Section,
    Bucket,
    TotalCount,
    OpenCount,
    SortOrder
)
SELECT TOP 15
    'ChiefOwnership',
    ChiefName,
    TotalCount,
    OpenCount,
    ROW_NUMBER() OVER (ORDER BY TotalCount DESC) AS SortOrder
FROM ChiefSummary
ORDER BY TotalCount DESC;

    -- ---------- 5.9 "What I don't see" - Market Trending Items ----------
    -- Top 10 platforms that have a spike in NEW demand in the last 30 days
    -- AND a low "completed" ratio. These are the items to watch.
   ;WITH JiraData AS
(
    SELECT
        ISNULL(NULLIF(LTRIM(RTRIM(JI.Platform)), ''), 'Unknown') AS PlatformName,
        CASE 
            WHEN CS.S IS NOT NULL THEN 1 
            ELSE 0 
        END AS IsClosed
    FROM dbo.JiraIssues JI
    LEFT JOIN @ClosedStatuses CS
        ON ISNULL(JI.Status, '') = CS.S
    WHERE JI.ProjectKey = 'DMGT'
      AND JI.JiraCreated >= DATEADD(DAY, -30, @now)
),
MarketSummary AS
(
    SELECT
        PlatformName,
        COUNT(*) AS Trend30,
        SUM(CASE WHEN IsClosed = 0 THEN 1 ELSE 0 END) AS OpenCount,
        SUM(CASE WHEN IsClosed = 1 THEN 1 ELSE 0 END) AS ClosedCount
    FROM JiraData
    GROUP BY PlatformName
)

INSERT INTO dbo.DashboardReport
(
    Section,
    Bucket,
    TotalCount,
    OpenCount,
    ClosedCount,
    SortOrder,
    Extra
)
SELECT TOP 10
    'MarketTrending',
    PlatformName,
    Trend30,
    OpenCount,
    ClosedCount,
    ROW_NUMBER() OVER (ORDER BY Trend30 DESC) AS SortOrder,
    '{"window":"30d","metric":"newDemand"}'
FROM MarketSummary
ORDER BY Trend30 DESC;

    -- ---------- 5.10 Refresh filter dropdown values ----------
    IF OBJECT_ID('dbo.DashboardFilterValues','U') IS NOT NULL
    BEGIN
        DELETE FROM dbo.DashboardFilterValues;
        INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
            SELECT DISTINCT 'Platform', LTRIM(RTRIM(Platform))
            FROM dbo.JiraIssues
            WHERE ISNULL(Platform,'') <> '' AND ProjectKey='DMGT';
        INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
            SELECT DISTINCT 'Vertical', LTRIM(RTRIM(PlatformVertical))
            FROM dbo.JiraIssues
            WHERE ISNULL(PlatformVertical,'') <> '' AND ProjectKey='DMGT';
        INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
            SELECT DISTINCT 'Manager', LTRIM(RTRIM(Manager))
            FROM dbo.JiraIssues
            WHERE ISNULL(Manager,'') <> '';
        INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
            SELECT DISTINCT 'TechLead', LTRIM(RTRIM(TechLead))
            FROM dbo.JiraIssues
            WHERE ISNULL(TechLead,'') <> '';
        INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
            SELECT DISTINCT 'Chief', LTRIM(RTRIM(ChiefNameMapping))
            FROM dbo.JiraIssues
            WHERE ISNULL(ChiefNameMapping,'') <> '';
        INSERT INTO dbo.DashboardFilterValues(Dimension, Value)
            SELECT DISTINCT 'PortfolioHead', LTRIM(RTRIM(IdhPortfolioHead))
            FROM dbo.JiraIssues
            WHERE ISNULL(IdhPortfolioHead,'') <> '';
    END
END
GO

-- ============================================================
-- 6. Dashboard execution log (Req6: ~10-15 unique scenarios)
--    Populated by the web app via DashLog.ashx; read for support.
-- ============================================================
IF OBJECT_ID('dbo.DashboardExecLog','U') IS NULL
CREATE TABLE dbo.DashboardExecLog (
    LogID         BIGINT IDENTITY(1,1) PRIMARY KEY,
    Scenario      NVARCHAR(80)  NOT NULL,    -- 'DashboardLoad','FilterApplied','SectionRender','SectionEmpty',...
    Detail        NVARCHAR(800) NULL,
    DurationMs    INT NULL,
    UserName      NVARCHAR(128) NULL,
    LoggedAt      DATETIME NOT NULL DEFAULT GETDATE()
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_DashExec_Scen')
    CREATE INDEX IX_DashExec_Scen ON dbo.DashboardExecLog(Scenario, LoggedAt DESC);
GO

PRINT 'Req6: schema, JiraID fix, hierarchy SP fix and DashboardReport pipeline installed.';
GO
