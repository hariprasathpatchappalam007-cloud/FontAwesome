-- =====================================================================
-- DFM - Req3 schema additions
--   Run AFTER 05_SeedPetData.sql.
-- =====================================================================
USE DFM;
GO

-- ===== Req 41 - JIRA-style ProjectCode (DMGT-XXX) =====
-- The Projects table originally created the computed ProjectCode column as
-- 'PRJ-' + projectId. Drop and recreate that computed column so it uses
-- the actual JIRA ID when set, otherwise falls back to PRJ-NNNNN.
IF EXISTS (SELECT 1 FROM sys.computed_columns
           WHERE object_id = OBJECT_ID('dbo.Projects') AND name='ProjectCode')
BEGIN
    ALTER TABLE dbo.Projects DROP COLUMN ProjectCode;
END
GO
IF COL_LENGTH('dbo.Projects','ProjectCode') IS NULL
BEGIN
    ALTER TABLE dbo.Projects
        ADD ProjectCode AS (ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(JiraID,''))), ''),
                                   'PRJ-' + RIGHT('00000' + CAST(ProjectID AS VARCHAR(10)),5))) PERSISTED;
END
GO

-- ===== Req 4 - workflow stage flags on Project =====
IF COL_LENGTH('dbo.Projects','CapexStageStatus') IS NULL
    ALTER TABLE dbo.Projects ADD CapexStageStatus NVARCHAR(20) NULL DEFAULT('Pending');
IF COL_LENGTH('dbo.Projects','PetStageStatus') IS NULL
    ALTER TABLE dbo.Projects ADD PetStageStatus NVARCHAR(20) NULL DEFAULT('Pending');
IF COL_LENGTH('dbo.Projects','PetApprovalStatus') IS NULL
    ALTER TABLE dbo.Projects ADD PetApprovalStatus NVARCHAR(20) NULL DEFAULT('Pending');
IF COL_LENGTH('dbo.Projects','BpmStageStatus') IS NULL
    ALTER TABLE dbo.Projects ADD BpmStageStatus NVARCHAR(20) NULL DEFAULT('Pending');
GO

-- ===== Req 67-68 - JIRA Username/Password authentication =====
IF COL_LENGTH('dbo.JiraConfig','UserName') IS NULL
    ALTER TABLE dbo.JiraConfig ADD UserName NVARCHAR(150) NULL;
IF COL_LENGTH('dbo.JiraConfig','UserPassword') IS NULL
    ALTER TABLE dbo.JiraConfig ADD UserPassword NVARCHAR(300) NULL;
GO

-- Default Base URL (Req 66)
IF NOT EXISTS (SELECT 1 FROM dbo.JiraConfig)
BEGIN
    INSERT INTO dbo.JiraConfig (BaseUrl, ProjectKey, UserEmail, ApiToken, UserName, UserPassword)
    VALUES ('https://agile.dib.ae/planner','DMGT', '', '', '', '');
END
ELSE
BEGIN
    UPDATE dbo.JiraConfig
       SET BaseUrl = CASE WHEN ISNULL(BaseUrl,'') = '' THEN 'https://agile.dib.ae/planner' ELSE BaseUrl END
     WHERE ConfigID IN (SELECT MAX(ConfigID) FROM dbo.JiraConfig);
END
GO

-- ===== Req 43 - PET Field Guidance =====
IF OBJECT_ID('dbo.PetGuidance','U') IS NULL
CREATE TABLE dbo.PetGuidance (
    GuidanceID INT IDENTITY(1,1) PRIMARY KEY,
    FieldName  NVARCHAR(150) NOT NULL UNIQUE,
    Guidance   NVARCHAR(MAX) NOT NULL,
    UpdatedDate DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- ===== Req 33-35 - AI Audit Log =====
IF OBJECT_ID('dbo.AI_Audit_Log','U') IS NULL
CREATE TABLE dbo.AI_Audit_Log (
    LogID       INT IDENTITY(1,1) PRIMARY KEY,
    UserName    NVARCHAR(200) NOT NULL,
    Prompt      NVARCHAR(MAX) NULL,
    ResponseLen INT NULL,
    ProjectID   INT NULL,
    CreatedDate DATETIME NOT NULL DEFAULT(GETDATE())
);
GO

-- ===== Req 42 - PET Approver role =====
-- Ensure UserRoleAssignments supports PETApprover role.
IF NOT EXISTS (
    SELECT 1 FROM dbo.UserRoleAssignments ura
    WHERE ura.RoleType = 'PETApprover'
)
BEGIN
    -- Promote all existing Approvers to PETApprover as well.
    INSERT INTO dbo.UserRoleAssignments(Username, RoleType, CreatedBy)
    SELECT DISTINCT Username, 'PETApprover', 'system'
    FROM dbo.UserRoleAssignments WHERE RoleType = 'Approver'
      AND NOT EXISTS (
        SELECT 1 FROM dbo.UserRoleAssignments u2
        WHERE u2.Username = dbo.UserRoleAssignments.Username
          AND u2.RoleType = 'PETApprover');
END
GO

-- Optionally: an Admin role assignment so the new menu visibility works
IF NOT EXISTS (SELECT 1 FROM dbo.UserRoleAssignments WHERE RoleType = 'Admin')
BEGIN
    INSERT INTO dbo.UserRoleAssignments(Username, RoleType, CreatedBy)
    SELECT u.Username, 'Admin', 'system'
    FROM dbo.AppUsers u
    INNER JOIN dbo.UserRoles r ON u.RoleID = r.RoleID
    WHERE r.RoleName = 'Admin';
END
GO

-- ===== Req 18 - PET approved amount =====
IF COL_LENGTH('dbo.Projects','PetApprovedAmount') IS NULL
    ALTER TABLE dbo.Projects ADD PetApprovedAmount DECIMAL(18,2) NOT NULL DEFAULT(0);
GO

-- ===== Req 22 - Generic multi-attachment support =====
-- Attachments table already exists from 04_AdditionalTables.sql.
-- Ensure a Stage column so we know whether the upload belonged to PET / BPM / etc.
IF COL_LENGTH('dbo.Attachments','Stage') IS NULL
    ALTER TABLE dbo.Attachments ADD Stage NVARCHAR(20) NOT NULL DEFAULT('General');
GO

-- ===== Req 43 - Seed PET Guidance from CSV =====
IF NOT EXISTS (SELECT 1 FROM dbo.PetGuidance)
BEGIN
    INSERT INTO dbo.PetGuidance (FieldName, Guidance) VALUES
        ('Department',     'Select the Department from the dropdown list. Department-based prefix is used in auto-generated IDs.'),
        ('Cost Type',      'Select the cost type from the PET Cost Type master.'),
        ('Exp. Head',      'Pick Capex or Opex based on the nature of the expense.'),
        ('Topic',          'Mention a broader topic under which this particular cost will reside.'),
        ('Vendor',         'Enter the partner / vendor name. Use TBD if not yet known.'),
        ('Description',    'Reasonable details about the cost / transaction for which the funds are planned.'),
        ('Unit Type',      'Pick the appropriate unit (Man Days, Man Months, Licenses, etc.).'),
        ('Units',          'Number of units required under this cost line.'),
        ('Unit Price',     'Per-unit price as quoted in the proposal/estimate.'),
        ('Base CY',        'Currency of the proposal/estimate. AED is the local currency (LCY).'),
        ('Amt. FCY',       'Auto: Units x Unit Price in selected currency.'),
        ('Amt. LCY',       'Auto: Amt FCY converted to AED using the configured currency rate.'),
        ('Cont. %',        'Optional contingency / buffer percentage.'),
        ('Final Amt LCY',  'Auto: Amt LCY + contingency.'),
        ('Yearly Recurrence', 'For recurring annual costs select number of years; one-time = 1.'),
        ('Comments',       'Any additional notes or context.');
END
GO

-- ===== Allow manual master edits in CapexHistory (ProjectID becomes nullable) =====
IF EXISTS (SELECT 1 FROM sys.columns
           WHERE Object_ID = OBJECT_ID('dbo.CapexHistory') AND Name = 'ProjectID' AND is_nullable = 0)
BEGIN
    DECLARE @fk SYSNAME;
    SELECT @fk = name FROM sys.foreign_keys
    WHERE parent_object_id = OBJECT_ID('dbo.CapexHistory');
    IF @fk IS NOT NULL EXEC('ALTER TABLE dbo.CapexHistory DROP CONSTRAINT [' + @fk + ']');
    ALTER TABLE dbo.CapexHistory ALTER COLUMN ProjectID INT NULL;
    ALTER TABLE dbo.CapexHistory
        ADD CONSTRAINT FK_CapexHistory_Projects FOREIGN KEY (ProjectID) REFERENCES dbo.Projects(ProjectID);
END
GO

-- ===== Extend JiraIssues with the new JIRA fields captured during fetch =====
IF COL_LENGTH('dbo.JiraIssues','Status')                   IS NULL ALTER TABLE dbo.JiraIssues ADD Status NVARCHAR(100) NULL;
IF COL_LENGTH('dbo.JiraIssues','IssueType')                IS NULL ALTER TABLE dbo.JiraIssues ADD IssueType NVARCHAR(100) NULL;
IF COL_LENGTH('dbo.JiraIssues','Assignee')                 IS NULL ALTER TABLE dbo.JiraIssues ADD Assignee NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','Reporter')                 IS NULL ALTER TABLE dbo.JiraIssues ADD Reporter NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','AccountableExecLead')      IS NULL ALTER TABLE dbo.JiraIssues ADD AccountableExecLead NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','SmeLead')                  IS NULL ALTER TABLE dbo.JiraIssues ADD SmeLead NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','AccountableExec')          IS NULL ALTER TABLE dbo.JiraIssues ADD AccountableExec NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','IdhPortfolioHead')         IS NULL ALTER TABLE dbo.JiraIssues ADD IdhPortfolioHead NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','AssignedProjectManager')   IS NULL ALTER TABLE dbo.JiraIssues ADD AssignedProjectManager NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','DemandOwner')              IS NULL ALTER TABLE dbo.JiraIssues ADD DemandOwner NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','ChiefNameMapping')         IS NULL ALTER TABLE dbo.JiraIssues ADD ChiefNameMapping NVARCHAR(200) NULL;
IF COL_LENGTH('dbo.JiraIssues','TargetCompletionDate')     IS NULL ALTER TABLE dbo.JiraIssues ADD TargetCompletionDate DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','ProposedDemandPickupDate') IS NULL ALTER TABLE dbo.JiraIssues ADD ProposedDemandPickupDate DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','JiraCreated')              IS NULL ALTER TABLE dbo.JiraIssues ADD JiraCreated DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','JiraUpdated')              IS NULL ALTER TABLE dbo.JiraIssues ADD JiraUpdated DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','Platform')                 IS NULL ALTER TABLE dbo.JiraIssues ADD Platform NVARCHAR(200) NULL;

-- ===== Additional date / classification fields requested =====
IF COL_LENGTH('dbo.JiraIssues','Actual_Go_Live_Date')                  IS NULL ALTER TABLE dbo.JiraIssues ADD Actual_Go_Live_Date DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','Target_Completion_Date')               IS NULL ALTER TABLE dbo.JiraIssues ADD Target_Completion_Date DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','Proposed_Demand_Pick_up_Date')         IS NULL ALTER TABLE dbo.JiraIssues ADD Proposed_Demand_Pick_up_Date DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','Proposed_Baseline_0_End_Date')         IS NULL ALTER TABLE dbo.JiraIssues ADD Proposed_Baseline_0_End_Date DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','Proposed_Baseline_0_Start_Date')       IS NULL ALTER TABLE dbo.JiraIssues ADD Proposed_Baseline_0_Start_Date DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','Proposed_Baseline_0_submission_Date')  IS NULL ALTER TABLE dbo.JiraIssues ADD Proposed_Baseline_0_submission_Date DATETIME NULL;
IF COL_LENGTH('dbo.JiraIssues','Primary_Classification')               IS NULL ALTER TABLE dbo.JiraIssues ADD Primary_Classification NVARCHAR(200) NULL;
GO

PRINT 'Req3 schema applied.';
