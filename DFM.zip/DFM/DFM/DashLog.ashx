<%@ WebHandler Language="C#" Class="DFM.DashLogHandler" %>

using System;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;
using DFM.App_Code.Helpers;

namespace DFM
{
    /// <summary>
    /// Req6: receives client-side scenario log events from Default.aspx
    /// (DashboardLoad, FilterApplied, SectionRender, SectionEmpty, ExportClicked, etc.)
    /// and persists them via DashboardLog -> dbo.DashboardExecLog.
    /// </summary>
    public class DashLogHandler : IHttpHandler
    {
        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext ctx)
        {
            ctx.Response.ContentType = "application/json";
            try
            {
                string body;
                ctx.Request.InputStream.Position = 0;
                using (var sr = new StreamReader(ctx.Request.InputStream))
                    body = sr.ReadToEnd();

                string scenario = ctx.Request["scenario"];
                string detail   = ctx.Request["detail"];
                int? dur = null;
                int parsed; if (int.TryParse(ctx.Request["durationMs"], out parsed)) dur = parsed;

                if (string.IsNullOrEmpty(scenario) && !string.IsNullOrEmpty(body))
                {
                    var ser = new JavaScriptSerializer();
                    var obj = ser.Deserialize<System.Collections.Generic.Dictionary<string, object>>(body);
                    if (obj != null)
                    {
                        if (obj.ContainsKey("scenario") && obj["scenario"] != null) scenario = obj["scenario"].ToString();
                        if (obj.ContainsKey("detail")   && obj["detail"]   != null) detail   = obj["detail"].ToString();
                        if (obj.ContainsKey("durationMs") && obj["durationMs"] != null)
                        {
                            int d; if (int.TryParse(obj["durationMs"].ToString(), out d)) dur = d;
                        }
                    }
                }

                DashboardLog.Log(scenario ?? "Unknown", detail, dur);
                ctx.Response.Write("{\"ok\":true}");
            }
            catch (Exception ex)
            {
                ctx.Response.StatusCode = 500;
                ctx.Response.Write("{\"ok\":false,\"error\":\"" + ex.Message.Replace("\"", "'") + "\"}");
            }
        }
    }
}
