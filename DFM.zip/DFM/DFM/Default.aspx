<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="Default.aspx.cs" Inherits="DFM.DefaultPage" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">Dashboard</h1>

    <div class="filter-row">
        <div class="form-group">
            <label>Project Type</label>
            <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control" AutoPostBack="true"
                OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Text="All" Value="ALL" />
                <asp:ListItem Text="CAPEX" Value="CAPEX" />
                <asp:ListItem Text="OPEX" Value="OPEX" />
                <asp:ListItem Text="AMC" Value="AMC" />
            </asp:DropDownList>
        </div>
        <div class="form-group">
            <label>Workflow Status</label>
            <asp:DropDownList ID="ddlStatus" runat="server" CssClass="form-control" AutoPostBack="true"
                OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Text="All" Value="ALL" />
                <asp:ListItem Text="Draft" Value="Draft" />
                <asp:ListItem Text="Pending" Value="Pending" />
                <asp:ListItem Text="Approved" Value="Approved" />
                <asp:ListItem Text="Rejected" Value="Rejected" />
            </asp:DropDownList>
        </div>
        <div class="form-group" style="align-self: flex-end;">
            <asp:Button ID="btnExport" runat="server" Text="Export to Excel"
                CssClass="btn btn-success" OnClick="btnExport_Click" />
        </div>
        <div class="form-group" style="align-self: flex-end;">
            <asp:Button ID="btnRefresh" runat="server" Text="Refresh"
                CssClass="btn btn-secondary" OnClick="Filter_Changed" />
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="kpi-grid">
        <div class="kpi-card kpi-blue">
            <span class="glyphicon glyphicon-folder-open kpi-icon"></span>
            <div class="kpi-label">Total Projects</div>
            <div class="kpi-value"><asp:Literal ID="kTotalProjects" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="glyphicon glyphicon-piggy-bank kpi-icon"></span>
            <div class="kpi-label">CAPEX Budget</div>
            <div class="kpi-value"><asp:Literal ID="kCapexBudget" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-teal">
            <span class="glyphicon glyphicon-usd kpi-icon"></span>
            <div class="kpi-label">OPEX Budget</div>
            <div class="kpi-value"><asp:Literal ID="kOpexBudget" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-orange">
            <span class="glyphicon glyphicon-stats kpi-icon"></span>
            <div class="kpi-label">Utilized</div>
            <div class="kpi-value"><asp:Literal ID="kUtilized" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-purple">
            <span class="glyphicon glyphicon-lock kpi-icon"></span>
            <div class="kpi-label">Locked</div>
            <div class="kpi-value"><asp:Literal ID="kLocked" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-pink">
            <span class="glyphicon glyphicon-ok kpi-icon"></span>
            <div class="kpi-label">Available</div>
            <div class="kpi-value"><asp:Literal ID="kAvailable" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-slate">
            <span class="glyphicon glyphicon-hourglass kpi-icon"></span>
            <div class="kpi-label">Pending Approval</div>
            <div class="kpi-value"><asp:Literal ID="kPending" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="glyphicon glyphicon-thumbs-up kpi-icon"></span>
            <div class="kpi-label">Approved</div>
            <div class="kpi-value"><asp:Literal ID="kApproved" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-red">
            <span class="glyphicon glyphicon-thumbs-down kpi-icon"></span>
            <div class="kpi-label">Rejected</div>
            <div class="kpi-value"><asp:Literal ID="kRejected" runat="server" /></div>
        </div>
    </div>

    <!-- Project Type chips -->
    <div class="card-panel">
        <h3>Project counts by type</h3>
        <div style="display:flex; gap:14px; flex-wrap:wrap;">
            <div class="chip chip-capex" style="font-size:16px; padding:10px 18px;">
                CAPEX: <strong><asp:Literal ID="cCapex" runat="server" /></strong>
            </div>
            <div class="chip chip-opex"  style="font-size:16px; padding:10px 18px;">
                OPEX: <strong><asp:Literal ID="cOpex" runat="server" /></strong>
            </div>
            <div class="chip chip-amc"   style="font-size:16px; padding:10px 18px;">
                AMC: <strong><asp:Literal ID="cAmc" runat="server" /></strong>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(360px,1fr)); gap:18px;">
        <div class="card-panel">
            <h3>Budget vs Utilization</h3>
            <canvas id="chartBudget" height="220"></canvas>
        </div>
        <div class="card-panel">
            <h3>Project Status distribution</h3>
            <canvas id="chartStatus" height="220"></canvas>
        </div>
    </div>

    <!-- Recent + drilldown -->
    <div class="card-panel">
        <h3>Recently updated projects</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gvProjects" runat="server" AutoGenerateColumns="false" CssClass="dfm-table"
                GridLines="None" DataKeyNames="ProjectID" OnRowCommand="gvProjects_RowCommand">
                <Columns>
                    <asp:BoundField DataField="ProjectCode" HeaderText="Code" />
                    <asp:BoundField DataField="ProjectName" HeaderText="Project Name" />
                    <asp:TemplateField HeaderText="Type">
                        <ItemTemplate>
                            <span class='chip chip-<%# Eval("ProjectType").ToString().ToLower() %>'>
                                <%# Eval("ProjectType") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="JiraID" HeaderText="JIRA" />
                    <asp:BoundField DataField="ApproverName" HeaderText="Approver" />
                    <asp:BoundField DataField="RequestedAmount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:TemplateField HeaderText="Status">
                        <ItemTemplate>
                            <span class='badge-status badge-<%# Eval("Status").ToString().ToLower() %>'>
                                <%# Eval("Status") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="ModifiedDate" HeaderText="Updated" DataFormatString="{0:dd-MMM-yy HH:mm}" />
                    <asp:TemplateField HeaderText="Action">
                        <ItemTemplate>
                            <asp:LinkButton runat="server" CssClass="btn btn-sm" CommandName="OpenProject"
                                CommandArgument='<%# Eval("ProjectID") %>' Text="Open" />
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:18px;">No projects yet.</div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
    </div>

    <!-- JIRA-linked projects -->
    <div class="card-panel">
        <h3>JIRA-linked project summary</h3>
        <asp:GridView ID="gvJira" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="JiraID"      HeaderText="JIRA ID" />
                <asp:BoundField DataField="ProjectName" HeaderText="Project Name" />
                <asp:BoundField DataField="ProjectStage" HeaderText="Stage" />
                <asp:BoundField DataField="ProjectRAG"  HeaderText="RAG" />
                <asp:BoundField DataField="DemandType"  HeaderText="Demand Type" />
                <asp:BoundField DataField="Manager"     HeaderText="Manager" />
            </Columns>
            <EmptyDataTemplate>
                <div class="text-center text-muted" style="padding:18px;">No JIRA issues cached.</div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>

    <script>
        (function () {
            var capexBudget = <%= JsCapexBudget %>;
            var opexBudget  = <%= JsOpexBudget %>;
            var utilized    = <%= JsUtilized %>;
            var available   = <%= JsAvailable %>;
            var locked      = <%= JsLocked %>;

            var pending = <%= JsPending %>;
            var approved = <%= JsApproved %>;
            var rejected = <%= JsRejected %>;
            var draft    = <%= JsDraft %>;

            var c1 = document.getElementById('chartBudget');
            if (c1 && window.Chart) {
                new Chart(c1, {
                    type: 'bar',
                    data: {
                        labels: ['CAPEX Budget','OPEX Budget','Utilized','Locked','Available'],
                        datasets: [{
                            label: 'Amount',
                            data: [capexBudget, opexBudget, utilized, locked, available],
                            backgroundColor: ['#2563eb','#0891b2','#f97316','#7c3aed','#16a34a']
                        }]
                    },
                    options: { responsive: true, plugins: { legend: { display: false } } }
                });
            }
            var c2 = document.getElementById('chartStatus');
            if (c2 && window.Chart) {
                new Chart(c2, {
                    type: 'doughnut',
                    data: {
                        labels: ['Draft','Pending','Approved','Rejected'],
                        datasets: [{
                            data: [draft, pending, approved, rejected],
                            backgroundColor: ['#94a3b8','#f59e0b','#16a34a','#dc2626']
                        }]
                    },
                    options: { responsive: true }
                });
            }
        })();
    </script>
</asp:Content>
