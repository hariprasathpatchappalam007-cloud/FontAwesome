<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="Default.aspx.cs" Inherits="DFM.DefaultPage" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">
        <span class="glyphicon glyphicon-dashboard"></span> Dashboard
        <span class="dashboard-timestamp">
            <span class="glyphicon glyphicon-refresh"></span>
            Data Last Updated: <asp:Literal ID="litLastRefreshed" runat="server" />
        </span>
    </h1>

    <!-- Filter panel: collapsible (Req 2.2) -->
    <div class="dash-section" id="sec-filters">
        <div class="dash-sec-hdr" onclick="dfmSecTog('sec-filters')">
            <span><span class="glyphicon glyphicon-filter"></span> Filters</span>
            <span class="dash-sec-toggle glyphicon glyphicon-chevron-down"></span>
        </div>
        <div class="dash-sec-body">
        <div class="horizontal-filter-panel">
        <div class="filter-grid">
            <div class="form-group">
                <label>Project</label>
                <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control no-select2" AutoPostBack="true"
                    OnSelectedIndexChanged="Filter_Changed">
                    <asp:ListItem Text="All" Value="ALL" />
                    <asp:ListItem Text="CAPEX" Value="CAPEX" />
                    <asp:ListItem Text="OPEX" Value="OPEX" />
                    <asp:ListItem Text="AMC" Value="AMC" />
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>Approval Status</label>
                <asp:DropDownList ID="ddlStatus" runat="server" CssClass="form-control no-select2" AutoPostBack="true"
                    OnSelectedIndexChanged="Filter_Changed">
                    <asp:ListItem Text="All" Value="ALL" />
                    <asp:ListItem Text="Draft" Value="Draft" />
                    <asp:ListItem Text="Pending" Value="Pending" />
                    <asp:ListItem Text="Approved" Value="Approved" />
                    <asp:ListItem Text="Rejected" Value="Rejected" />
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>Requested By</label>
                <asp:DropDownList ID="ddlRequestedBy" runat="server" CssClass="form-control no-select2" AutoPostBack="true"
                    OnSelectedIndexChanged="Filter_Changed">
                    <asp:ListItem Text="All" Value="ALL" />
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>From Date</label>
                <asp:TextBox ID="txtFromDate" runat="server" CssClass="form-control" TextMode="Date" />
            </div>
            <div class="form-group">
                <label>To Date</label>
                <asp:TextBox ID="txtToDate" runat="server" CssClass="form-control" TextMode="Date" />
            </div>
        </div>
        <div class="filter-actions">
            <asp:Button ID="btnApply" runat="server" Text="Apply Filters" CssClass="btn btn-primary"
                OnClick="Filter_Changed" OnClientClick="DFM.showLoader('Applying filters...'); DFM.logScenario('FilterApplied','user clicked Apply');" />
            <asp:Button ID="btnRefresh" runat="server" Text="Refresh" CssClass="btn btn-secondary"
                OnClick="Filter_Changed" OnClientClick="DFM.showLoader('Refreshing...'); DFM.logScenario('DashboardRefresh','user clicked Refresh');" />
            <asp:Button ID="btnExport" runat="server" Text="Export Excel" CssClass="btn btn-success"
                OnClick="btnExport_Click" OnClientClick="DFM.showLoader('Exporting...'); DFM.logScenario('ExportClicked','user clicked Export');" />
        </div>
    </div>

        </div><!-- end horizontal-filter-panel -->
        </div><!-- end dash-sec-body -->

    <div>
    <div class="kpi-grid">
        <div class="kpi-card kpi-blue">
            <span class="glyphicon glyphicon-folder-open kpi-icon"></span>
            <div class="kpi-label">Projects</div>
            <div class="kpi-value"><asp:Literal ID="kTotalProjects" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="glyphicon glyphicon-briefcase kpi-icon"></span>
            <div class="kpi-label">CAPEX Budget</div>
            <div class="kpi-value"><asp:Literal ID="kCapexBudget" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-teal">
            <span class="glyphicon glyphicon-usd kpi-icon"></span>
            <div class="kpi-label">OPEX Budget</div>
            <div class="kpi-value"><asp:Literal ID="kOpexBudget" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-orange">
            <span class="glyphicon glyphicon-stats kpi-icon"></span>
            <div class="kpi-label">Utilized</div>
            <div class="kpi-value"><asp:Literal ID="kUtilized" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-purple">
            <span class="glyphicon glyphicon-lock kpi-icon"></span>
            <div class="kpi-label">Locked</div>
            <div class="kpi-value"><asp:Literal ID="kLocked" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-pink">
            <span class="glyphicon glyphicon-ok kpi-icon"></span>
            <div class="kpi-label">Available</div>
            <div class="kpi-value"><asp:Literal ID="kAvailable" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-slate">
            <span class="glyphicon glyphicon-hourglass kpi-icon"></span>
            <div class="kpi-label">Pending</div>
            <div class="kpi-value"><asp:Literal ID="kPending" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="glyphicon glyphicon-thumbs-up kpi-icon"></span>
            <div class="kpi-label">Approved</div>
            <div class="kpi-value"><asp:Literal ID="kApproved" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-red">
            <span class="glyphicon glyphicon-thumbs-down kpi-icon"></span>
            <div class="kpi-label">Rejected</div>
            <div class="kpi-value"><asp:Literal ID="kRejected" runat="server" /></div>
        </div>
    </div>

    <!-- Analytics section: collapsible (Req 2.3) -->
    <div class="dash-section" id="sec-analytics">
        <div class="dash-sec-hdr" onclick="dfmSecTog('sec-analytics')">
            <span><span class="glyphicon glyphicon-stats"></span> Analytics</span>
            <span class="dash-sec-toggle glyphicon glyphicon-chevron-down"></span>
        </div>
        <div class="dash-sec-body">
        <!-- Issue 5: 3-column chart row (slim bar + meter gauge + status mix) -->
        <div class="chart-row-3">
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-tasks"></span> Budget vs Utilization</h3>
            <div style="height:200px;"><canvas id="chartBudget"></canvas></div>
        </div>
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-dashboard"></span> Budget Utilization</h3>
            <div class="meter-gauge-wrap" style="height:200px;">
                <canvas id="meterGauge"></canvas>
                <div class="meter-gauge-label"><asp:Literal ID="litMeterPct" runat="server" /></div>
                <div class="meter-gauge-sub">utilized of total budget</div>
            </div>
        </div>
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-list-alt"></span> Status Mix</h3>
            <div style="height:200px;"><canvas id="chartStatus"></canvas></div>
        </div>
        </div><!-- end chart-row-3 -->
        </div><!-- end dash-sec-body -->
    </div><!-- end sec-analytics -->

    <!-- Pending Actions Tree View: collapsible (Req 2.4) -->
    <div class="dash-section" id="sec-pending">
        <div class="dash-sec-hdr" onclick="dfmSecTog('sec-pending')">
            <span><span class="glyphicon glyphicon-time"></span> Pending Actions</span>
            <span class="dash-sec-toggle glyphicon glyphicon-chevron-down"></span>
        </div>
        <div class="dash-sec-body">
        <div class="card-panel" style="border-top:none;border-radius:0 0 8px 8px;">
            <div id="projectTreeWrap">
                <asp:Literal ID="litTree" runat="server" />
            </div>
        </div>
        </div><!-- end dash-sec-body -->
    </div><!-- end sec-pending -->

    <!-- Budget Sources: collapsible (Req 2.5) -->
    <div class="dash-section" id="sec-budget">
        <div class="dash-sec-hdr" onclick="dfmSecTog('sec-budget')">
            <span><span class="glyphicon glyphicon-briefcase"></span> Budget Sources</span>
            <span class="dash-sec-toggle glyphicon glyphicon-chevron-down"></span>
        </div>
        <div class="dash-sec-body">
        <div class="card-panel" style="border-top:none;border-radius:0 0 8px 8px;">
            <div id="budgetCardList">
                <asp:Literal ID="litBudgetCards" runat="server" />
            </div>
        </div>
        </div><!-- end dash-sec-body -->
    </div><!-- end sec-budget -->

    </div><!-- end main dashboard content -->

    <script>
        (function () {
            var capexBudget = <%= JsCapexBudget %>;
            var opexBudget  = <%= JsOpexBudget %>;
            var utilized    = <%= JsUtilized %>;
            var available   = <%= JsAvailable %>;
            var locked      = <%= JsLocked %>;
            var totalBudget = capexBudget + opexBudget;
            var pct = totalBudget > 0 ? Math.min(100, Math.round((utilized / totalBudget) * 100)) : 0;

            var c1 = document.getElementById('chartBudget');
            if (c1 && window.Chart) {
                new Chart(c1, {
                    type: 'bar',
                    data: {
                        labels: ['CAPEX','OPEX','Utilized','Locked','Available'],
                        datasets: [{
                            label: 'Amount',
                            data: [capexBudget, opexBudget, utilized, locked, available],
                            backgroundColor: ['#1e40af','#0e7490','#b45309','#6b21a8','#15803d'],
                            barThickness: 14,
                            maxBarThickness: 16,
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { grid: { color: 'rgba(0,0,0,0.05)' } },
                            y: { grid: { display: false } }
                        }
                    }
                });
            }
            var cs = document.getElementById('chartStatus');
            var draftCnt    = <%= JsDraft %>;
            var pendingCnt  = <%= JsPending %>;
            var approvedCnt = <%= JsApproved %>;
            var rejectedCnt = <%= JsRejected %>;
            if (cs && window.Chart) {
                new Chart(cs, {
                    type: 'doughnut',
                    data: {
                        labels: ['Draft','Pending','Approved','Rejected'],
                        datasets: [{
                            data: [draftCnt, pendingCnt, approvedCnt, rejectedCnt],
                            backgroundColor: ['#94a3b8','#b45309','#15803d','#b91c1c'],
                            borderWidth: 1, borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false, cutout: '55%',
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            }

            // Req 49: Meter Gauge for budget utilization (half-doughnut)
            var c2 = document.getElementById('meterGauge');
            if (c2 && window.Chart) {
                var gaugeColor = pct < 60 ? '#15803d' : (pct < 85 ? '#b45309' : '#b91c1c');
                new Chart(c2, {
                    type: 'doughnut',
                    data: {
                        labels: ['Utilized','Remaining'],
                        datasets: [{
                            data: [pct, 100 - pct],
                            backgroundColor: [gaugeColor, '#e5e7eb'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        rotation: -90, circumference: 180, cutout: '72%',
                        plugins: { legend: { display: false }, tooltip: { enabled: false } }
                    }
                });
            }
        })();

        $(function () {
            try { DFM.hideLoader(); } catch (e) { }
        });

        // Tree view toggle
        function dfmTog(id) {
            var rows = document.querySelectorAll('.tree-row.' + id);
            var hidden = rows.length > 0 && rows[0].classList.contains('tree-hidden');
            rows.forEach(function (r) {
                if (hidden) {
                    r.classList.remove('tree-hidden');
                } else {
                    r.classList.add('tree-hidden');
                    // also collapse any nested children
                    r.className.split(' ').forEach(function (c) {
                        if (c !== 'tree-row' && c !== id && c !== 'tree-hidden') {
                            document.querySelectorAll('.tree-row.' + c).forEach(function (n) {
                                n.classList.add('tree-hidden');
                            });
                        }
                    });
                }
            });
            var btn = document.querySelector('[data-tog="' + id + '"]');
            if (btn) btn.textContent = hidden ? '\u25BE' : '\u25B8';
        }

        // Dashboard section collapse (Req 2.1-2.5)
        function dfmSecTog(id) {
            var sec = document.getElementById(id);
            if (!sec) return;
            var collapsed = sec.classList.contains('sec-collapsed');
            if (collapsed) {
                sec.classList.remove('sec-collapsed');
            } else {
                sec.classList.add('sec-collapsed');
            }
            var icon = sec.querySelector('.dash-sec-toggle');
            if (icon) icon.style.transform = collapsed ? 'rotate(0deg)' : 'rotate(-90deg)';
            try {
                var states = JSON.parse(localStorage.getItem('dfmDashSec') || '{}');
                states[id] = collapsed ? 'o' : 'c';
                localStorage.setItem('dfmDashSec', JSON.stringify(states));
            } catch (e) { }
        }

        // Restore section collapse states on page load (Req 2.8)
        $(function () {
            try {
                var states = JSON.parse(localStorage.getItem('dfmDashSec') || '{}');
                Object.keys(states).forEach(function (id) {
                    if (states[id] === 'c') {
                        var sec = document.getElementById(id);
                        if (!sec) return;
                        sec.classList.add('sec-collapsed');
                        var icon = sec.querySelector('.dash-sec-toggle');
                        if (icon) icon.style.transform = 'rotate(-90deg)';
                    }
                });
            } catch (e) { }
        });
    </script>
    <style>
        /* Budget cards */
        .budget-card-list { display:flex; flex-wrap:wrap; gap:10px; }
        .budget-card { flex:1 1 220px; min-width:200px; background:#fff; border:1px solid #e2e8f0;
            border-radius:10px; padding:12px 14px; cursor:pointer; transition:box-shadow .15s; }
        .budget-card:hover, .budget-card.active { box-shadow:0 0 0 2px var(--primary,#0b6efd); }
        .budget-card .bc-header { display:flex; justify-content:space-between; font-weight:700; font-size:.92em; }
        .budget-card .bc-type { font-size:.75em; font-weight:600; color:#64748b; margin-bottom:2px; }
        .budget-card .bc-desc { font-size:.8em; color:#475569; margin-bottom:4px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .budget-card .bc-used { font-size:.75em; color:#64748b; margin-bottom:6px; }
        .budget-card .bc-bar { height:6px; background:#e2e8f0; border-radius:99px; overflow:hidden; }
        .budget-card .bc-bar span { display:block; height:100%; background:var(--primary,#0b6efd); border-radius:99px; transition:width .3s; }
        /* Tree table */
        .tree-table { width:100%; border-collapse:collapse; font-size:.85em; }
        .tree-table th { background:#f1f5f9; padding:7px 10px; text-align:left; font-size:.8em; color:#475569; font-weight:700; border-bottom:1px solid #e2e8f0; white-space:nowrap; }
        .tree-table td { padding:6px 10px; border-bottom:1px solid #f1f5f9; vertical-align:middle; }
        .tree-table tr:hover td { background:#f8fafc; }
        .tree-hidden { display:none; }
        .tree-toggle { cursor:pointer; user-select:none; color:var(--primary,#0b6efd); font-size:1em; margin-right:4px; }
        td.indent1 { padding-left:28px; }
        td.indent2 { padding-left:50px; }
        td.indent3 { padding-left:72px; }
        .tree-badge { display:inline-block; padding:2px 8px; border-radius:999px; font-size:.75em; font-weight:600; }
        .tree-badge.ok  { background:#dcfce7; color:#15803d; }
        .tree-badge.warn { background:#fef3c7; color:#b45309; }
        .tree-badge.danger { background:#fee2e2; color:#b91c1c; }
        .tree-badge.info { background:#dbeafe; color:#1d4ed8; }
        .tree-badge.violet { background:#ede9fe; color:#6d28d9; }
        .tree-badge.muted { background:#f1f5f9; color:#64748b; }
    </style>
</asp:Content>
