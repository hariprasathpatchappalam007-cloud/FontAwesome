<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="Default.aspx.cs" Inherits="DFM.DefaultPage" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</h1>

    <!-- Req 50-52: 5-column layout -->
    <div class="filter-row">
        <div class="form-group">
            <label>Project Type</label>
            <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control" AutoPostBack="true"
                OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Text="All" Value="ALL" />
                <asp:ListItem Text="CAPEX" Value="CAPEX" />
                <asp:ListItem Text="OPEX" Value="OPEX" />
                <asp:ListItem Text="AMC" Value="AMC" />
            </asp:DropDownList>
        </div>
        <div class="form-group">
            <label>Workflow Status</label>
            <asp:DropDownList ID="ddlStatus" runat="server" CssClass="form-control" AutoPostBack="true"
                OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Text="All" Value="ALL" />
                <asp:ListItem Text="Draft" Value="Draft" />
                <asp:ListItem Text="Pending" Value="Pending" />
                <asp:ListItem Text="Approved" Value="Approved" />
                <asp:ListItem Text="Rejected" Value="Rejected" />
            </asp:DropDownList>
        </div>
        <div class="form-group col-span-2">&nbsp;</div>
        <div class="form-group">
            <label>&nbsp;</label>
            <div class="toolbar" style="margin:0;">
                <asp:Button ID="btnRefresh" runat="server" Text="Refresh"
                    CssClass="btn btn-secondary" OnClick="Filter_Changed" />
                <asp:Button ID="btnExport" runat="server" Text="Excel"
                    CssClass="btn btn-success" OnClick="btnExport_Click" />
            </div>
        </div>
    </div>

    <!-- Req 47, 50: smaller KPI cards -->
    <div class="kpi-grid">
        <div class="kpi-card kpi-blue">
            <span class="glyphicon glyphicon-folder-open kpi-icon"></span>
            <div class="kpi-label">Projects</div>
            <div class="kpi-value"><asp:Literal ID="kTotalProjects" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="glyphicon glyphicon-briefcase kpi-icon"></span>
            <div class="kpi-label">CAPEX Budget</div>
            <div class="kpi-value"><asp:Literal ID="kCapexBudget" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-teal">
            <span class="glyphicon glyphicon-usd kpi-icon"></span>
            <div class="kpi-label">OPEX Budget</div>
            <div class="kpi-value"><asp:Literal ID="kOpexBudget" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-orange">
            <span class="glyphicon glyphicon-stats kpi-icon"></span>
            <div class="kpi-label">Utilized</div>
            <div class="kpi-value"><asp:Literal ID="kUtilized" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-purple">
            <span class="glyphicon glyphicon-lock kpi-icon"></span>
            <div class="kpi-label">Locked</div>
            <div class="kpi-value"><asp:Literal ID="kLocked" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-pink">
            <span class="glyphicon glyphicon-ok kpi-icon"></span>
            <div class="kpi-label">Available</div>
            <div class="kpi-value"><asp:Literal ID="kAvailable" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-slate">
            <span class="glyphicon glyphicon-hourglass kpi-icon"></span>
            <div class="kpi-label">Pending</div>
            <div class="kpi-value"><asp:Literal ID="kPending" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="glyphicon glyphicon-thumbs-up kpi-icon"></span>
            <div class="kpi-label">Approved</div>
            <div class="kpi-value"><asp:Literal ID="kApproved" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-red">
            <span class="glyphicon glyphicon-thumbs-down kpi-icon"></span>
            <div class="kpi-label">Rejected</div>
            <div class="kpi-value"><asp:Literal ID="kRejected" runat="server" /></div>
        </div>
    </div>

    <!-- Issue 5: 3-column chart row (slim bar + meter gauge + status mix) -->
    <div class="chart-row-3">
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-tasks"></span> Budget vs Utilization</h3>
            <div style="height:200px;"><canvas id="chartBudget"></canvas></div>
        </div>
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-dashboard"></span> Budget Utilization</h3>
            <div class="meter-gauge-wrap" style="height:200px;">
                <canvas id="meterGauge"></canvas>
                <div class="meter-gauge-label"><asp:Literal ID="litMeterPct" runat="server" /></div>
                <div class="meter-gauge-sub">utilized of total budget</div>
            </div>
        </div>
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-list-alt"></span> Status Mix</h3>
            <div style="height:200px;"><canvas id="chartStatus"></canvas></div>
        </div>
    </div>

    <!-- Req 71: JIRA-based dashboard on landing page (driven by JIRADashBoard.csv) -->
    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-link"></span> JIRA Dashboard</h3>
        <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(160px,1fr));">
            <div class="kpi-card kpi-blue">
                <span class="glyphicon glyphicon-link kpi-icon"></span>
                <div class="kpi-label">Total Demands</div>
                <div class="kpi-value"><asp:Literal ID="kJiraTotal" runat="server" /></div>
            </div>
            <div class="kpi-card kpi-green">
                <span class="glyphicon glyphicon-ok kpi-icon"></span>
                <div class="kpi-label">Active</div>
                <div class="kpi-value"><asp:Literal ID="kJiraActive" runat="server" /></div>
            </div>
            <div class="kpi-card kpi-orange">
                <span class="glyphicon glyphicon-warning-sign kpi-icon"></span>
                <div class="kpi-label">Amber RAG</div>
                <div class="kpi-value"><asp:Literal ID="kJiraAmber" runat="server" /></div>
            </div>
            <div class="kpi-card kpi-red">
                <span class="glyphicon glyphicon-alert kpi-icon"></span>
                <div class="kpi-label">Red RAG</div>
                <div class="kpi-value"><asp:Literal ID="kJiraRed" runat="server" /></div>
            </div>
        </div>

        <%-- SQL-driven bar charts: Demand Status + Platform-wise from JiraIssues --%>
        <div class="jira-bar-row">
            <div class="jira-chart-card">
                <h4><span class="glyphicon glyphicon-stats"></span> Demand Status Summary</h4>
                <div class="jira-bar-wrap" style="height:280px;"><canvas id="chartDemandStatus"></canvas></div>
            </div>
            <div class="jira-chart-card">
                <h4><span class="glyphicon glyphicon-th-large"></span> Platform-wise Demand</h4>
                <div class="jira-bar-wrap" style="height:340px;"><canvas id="chartPlatform"></canvas></div>
            </div>
        </div>

        <%-- JIRA-based charts: RAG / Demand Type / Tech Lead / Manager --%>
        <div class="jira-charts-grid">
            <div class="jira-chart-card">
                <h4><span class="glyphicon glyphicon-alert"></span> RAG Distribution</h4>
                <div class="jira-chart-wrap"><canvas id="chartRag"></canvas></div>
            </div>
            <div class="jira-chart-card">
                <h4><span class="glyphicon glyphicon-flag"></span> Demand Type</h4>
                <div class="jira-chart-wrap"><canvas id="chartDemand"></canvas></div>
            </div>
            <div class="jira-chart-card">
                <h4><span class="glyphicon glyphicon-wrench"></span> Tech Lead Workload</h4>
                <div class="jira-chart-wrap"><canvas id="chartTechLead"></canvas></div>
            </div>
            <div class="jira-chart-card">
                <h4><span class="glyphicon glyphicon-user"></span> Manager Workload</h4>
                <div class="jira-chart-wrap"><canvas id="chartManager"></canvas></div>
            </div>
        </div>

    </div>

    <script>
        (function () {
            var capexBudget = <%= JsCapexBudget %>;
            var opexBudget  = <%= JsOpexBudget %>;
            var utilized    = <%= JsUtilized %>;
            var available   = <%= JsAvailable %>;
            var locked      = <%= JsLocked %>;
            var totalBudget = capexBudget + opexBudget;
            var pct = totalBudget > 0 ? Math.min(100, Math.round((utilized / totalBudget) * 100)) : 0;

            var c1 = document.getElementById('chartBudget');
            if (c1 && window.Chart) {
                new Chart(c1, {
                    type: 'bar',
                    data: {
                        labels: ['CAPEX','OPEX','Utilized','Locked','Available'],
                        datasets: [{
                            label: 'Amount',
                            data: [capexBudget, opexBudget, utilized, locked, available],
                            backgroundColor: ['#1e40af','#0e7490','#b45309','#6b21a8','#15803d'],
                            barThickness: 14,
                            maxBarThickness: 16,
                            borderRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { grid: { color: 'rgba(0,0,0,0.05)' } },
                            y: { grid: { display: false } }
                        }
                    }
                });
            }
            var cs = document.getElementById('chartStatus');
            var draftCnt    = <%= JsDraft %>;
            var pendingCnt  = <%= JsPending %>;
            var approvedCnt = <%= JsApproved %>;
            var rejectedCnt = <%= JsRejected %>;
            if (cs && window.Chart) {
                new Chart(cs, {
                    type: 'doughnut',
                    data: {
                        labels: ['Draft','Pending','Approved','Rejected'],
                        datasets: [{
                            data: [draftCnt, pendingCnt, approvedCnt, rejectedCnt],
                            backgroundColor: ['#94a3b8','#b45309','#15803d','#b91c1c'],
                            borderWidth: 1, borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false, cutout: '55%',
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            }

            // ===== JIRA-based charts =====
            var ragLabels    = <%= JsRagLabels %>;
            var ragData      = <%= JsRagData %>;
            var ragColors    = <%= JsRagColors %>;
            var demandLabels = <%= JsDemandLabels %>;
            var demandData   = <%= JsDemandData %>;
            var techLabels   = <%= JsTechLeadLabels %>;
            var techData     = <%= JsTechLeadData %>;
            var mgrLabels    = <%= JsManagerLabels %>;
            var mgrData      = <%= JsManagerData %>;

            // shared bar-chart palette for Tech Lead / Manager
            var paletteBar = [
                '#1e40af','#0e7490','#15803d','#b45309','#6b21a8',
                '#be185d','#0891b2','#dc2626','#475569','#7c3aed'
            ];
            var paletteSlice = [
                '#3b82f6','#06b6d4','#22c55e','#f97316','#a855f7',
                '#ec4899','#0ea5e9','#ef4444','#64748b','#8b5cf6','#fbbf24','#10b981'
            ];

            function ensureColors(arr, base) {
                var out = [];
                for (var i = 0; i < arr.length; i++) out.push(base[i % base.length]);
                return out;
            }

            // 1) RAG doughnut with fixed traffic-light colours
            var cR = document.getElementById('chartRag');
            if (cR && window.Chart && ragLabels.length) {
                new Chart(cR, {
                    type: 'doughnut',
                    data: { labels: ragLabels, datasets: [{ data: ragData, backgroundColor: ragColors, borderWidth: 1, borderColor: '#fff' }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, cutout: '55%',
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            }

            // 2) Demand Type pie
            var cD = document.getElementById('chartDemand');
            if (cD && window.Chart && demandLabels.length) {
                new Chart(cD, {
                    type: 'pie',
                    data: { labels: demandLabels, datasets: [{ data: demandData, backgroundColor: ensureColors(demandLabels, paletteSlice), borderWidth: 1, borderColor: '#fff' }] },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            }

            // 3) Tech Lead horizontal bar
            var cT = document.getElementById('chartTechLead');
            if (cT && window.Chart && techLabels.length) {
                new Chart(cT, {
                    type: 'bar',
                    data: { labels: techLabels, datasets: [{ label: 'Issues', data: techData, backgroundColor: ensureColors(techLabels, paletteBar), barThickness: 14, maxBarThickness: 16 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: { x: { grid: { color: 'rgba(0,0,0,0.05)' } }, y: { grid: { display: false } } }
                    }
                });
            }

            // 5) Demand Status bar (SQL-driven from JiraIssues)
            var dsLabels = <%= JsDemandStatusLabels %>;
            var dsData   = <%= JsDemandStatusData %>;
            var dsColors = <%= JsDemandStatusColors %>;
            var cDS = document.getElementById('chartDemandStatus');
            if (cDS && window.Chart && dsLabels.length) {
                new Chart(cDS, {
                    type: 'bar',
                    data: { labels: dsLabels, datasets: [{ label: 'Issues', data: dsData, backgroundColor: dsColors, borderColor: '#0d1b3d', borderWidth: 1, barThickness: 28, maxBarThickness: 36 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            title:  { display: false }
                        },
                        scales: {
                            x: { grid: { display: false }, ticks: { font: { size: 11, weight: 'bold' } } },
                            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { precision: 0 } }
                        }
                    }
                });
            }

            // 6) Platform-wise bar (SQL-driven from JiraIssues.Platform with CASE WHEN bucketing)
            var plLabels = <%= JsPlatformLabels %>;
            var plData   = <%= JsPlatformData %>;
            var plColors = <%= JsPlatformColors %>;
            var cPL = document.getElementById('chartPlatform');
            if (cPL && window.Chart && plLabels.length) {
                new Chart(cPL, {
                    type: 'bar',
                    data: { labels: plLabels, datasets: [{ label: 'Issues', data: plData, backgroundColor: plColors, borderColor: '#0d1b3d', borderWidth: 1, barThickness: 18, maxBarThickness: 22 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { precision: 0 } },
                            y: { grid: { display: false }, ticks: { font: { size: 11, weight: 'bold' } } }
                        }
                    }
                });
            }

            // 4) Manager horizontal bar
            var cM = document.getElementById('chartManager');
            if (cM && window.Chart && mgrLabels.length) {
                new Chart(cM, {
                    type: 'bar',
                    data: { labels: mgrLabels, datasets: [{ label: 'Issues', data: mgrData, backgroundColor: ensureColors(mgrLabels, paletteBar), barThickness: 14, maxBarThickness: 16 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: { x: { grid: { color: 'rgba(0,0,0,0.05)' } }, y: { grid: { display: false } } }
                    }
                });
            }

            // Req 49: Meter Gauge for budget utilization (half-doughnut)
            var c2 = document.getElementById('meterGauge');
            if (c2 && window.Chart) {
                var gaugeColor = pct < 60 ? '#15803d' : (pct < 85 ? '#b45309' : '#b91c1c');
                new Chart(c2, {
                    type: 'doughnut',
                    data: {
                        labels: ['Utilized','Remaining'],
                        datasets: [{
                            data: [pct, 100 - pct],
                            backgroundColor: [gaugeColor, '#e5e7eb'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        rotation: -90,
                        circumference: 180,
                        cutout: '72%',
                        plugins: {
                            legend: { display: false },
                            tooltip: { enabled: false }
                        }
                    }
                });
            }
        })();
    </script>
</asp:Content>
