<%@ WebHandler Language="C#" Class="DFM.AIHandler" %>

using System;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM
{
    // Req 33-35: server-side proxy for Gemini AI used by the unified Workflow.aspx
    public class AIHandler : IHttpHandler, System.Web.SessionState.IReadOnlySessionState
    {
        // Default key matches Requirement/GenAI.js, can be overridden via Web.config -> appSettings/GeminiApiKey
        private const string DefaultApiKey = "AIzaSyCnL8UGfQG0b77o1OJ0jF4VLshP9sBIYGk";

        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            string user = AuthHelper.CurrentUser ?? "anonymous";
            string body;
            using (var sr = new StreamReader(context.Request.InputStream))
                body = sr.ReadToEnd();

            string prompt = "";
            int? projectId = null;
            try
            {
                var jss = new JavaScriptSerializer();
                var data = jss.Deserialize<System.Collections.Generic.Dictionary<string, object>>(body);
                if (data != null)
                {
                    if (data.ContainsKey("prompt") && data["prompt"] != null) prompt = data["prompt"].ToString();
                    if (data.ContainsKey("projectId") && data["projectId"] != null)
                    {
                        int p; if (int.TryParse(data["projectId"].ToString(), out p) && p > 0) projectId = p;
                    }
                }
            }
            catch { }
            if (string.IsNullOrWhiteSpace(prompt))
            {
                context.Response.Write("Empty prompt.");
                return;
            }

            string apiKey = System.Configuration.ConfigurationManager.AppSettings["GeminiApiKey"];
            if (string.IsNullOrEmpty(apiKey)) apiKey = DefaultApiKey;

            string responseText;
            try
            {
                responseText = CallGemini(apiKey, prompt);
            }
            catch (Exception ex)
            {
                responseText = "Error calling Gemini API: " + ex.Message;
            }

            try { WorkflowDAL.LogAiCall(user, prompt, responseText == null ? 0 : responseText.Length, projectId); }
            catch { }

            context.Response.Write(responseText ?? "");
        }

        private string CallGemini(string apiKey, string prompt)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "POST";
            req.ContentType = "application/json";
            req.Headers["X-goog-api-key"] = apiKey;
            req.Timeout = 60000;

            var jss = new JavaScriptSerializer();
            var payload = new
            {
                contents = new[] {
                    new { parts = new[] { new { text = prompt } } }
                }
            };
            string json = jss.Serialize(payload);
            byte[] data = Encoding.UTF8.GetBytes(json);
            req.ContentLength = data.Length;
            using (var rs = req.GetRequestStream()) rs.Write(data, 0, data.Length);

            try
            {
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (var rs = resp.GetResponseStream())
                using (var sr = new StreamReader(rs))
                {
                    string raw = sr.ReadToEnd();
                    return ExtractText(raw, jss);
                }
            }
            catch (WebException wex)
            {
                if (wex.Response != null)
                {
                    using (var sr = new StreamReader(wex.Response.GetResponseStream()))
                    {
                        string err = sr.ReadToEnd();
                        if (((HttpWebResponse)wex.Response).StatusCode == (HttpStatusCode)429)
                            return "Rate limit exceeded. Please wait a minute.";
                        return "AI service error: " + err;
                    }
                }
                return "AI service unreachable: " + wex.Message;
            }
        }

        private string ExtractText(string raw, JavaScriptSerializer jss)
        {
            try
            {
                var root = jss.Deserialize<System.Collections.Generic.Dictionary<string, object>>(raw);
                if (root == null || !root.ContainsKey("candidates")) return "No response";
                var cand = root["candidates"] as System.Collections.ArrayList;
                if (cand == null || cand.Count == 0) return "No response";
                var first = cand[0] as System.Collections.Generic.Dictionary<string, object>;
                if (first == null) return "No response";
                var content = first.ContainsKey("content") ? first["content"] as System.Collections.Generic.Dictionary<string, object> : null;
                if (content == null || !content.ContainsKey("parts")) return "No response";
                var parts = content["parts"] as System.Collections.ArrayList;
                if (parts == null || parts.Count == 0) return "No response";
                var p0 = parts[0] as System.Collections.Generic.Dictionary<string, object>;
                if (p0 == null || !p0.ContainsKey("text")) return "No response";
                return p0["text"].ToString();
            }
            catch { return raw; }
        }
    }
}
