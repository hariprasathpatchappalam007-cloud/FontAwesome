namespace DFM
{
    public partial class SiteMaster
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.ContentPlaceHolder HeadContent;
        protected global::System.Web.UI.WebControls.ContentPlaceHolder MainContent;
        protected global::System.Web.UI.WebControls.Label lblUserName;
        protected global::System.Web.UI.WebControls.Label lblUserRole;
        protected global::System.Web.UI.WebControls.Literal litTopUser;
        protected global::System.Web.UI.WebControls.Literal litActiveRole;
        protected global::System.Web.UI.WebControls.Literal litNotifBadge;
        protected global::System.Web.UI.WebControls.Repeater rptNotif;
        protected global::System.Web.UI.WebControls.Panel pnlNoNotif;
        protected global::System.Web.UI.WebControls.Panel pnlRoleSwitcher;
        protected global::System.Web.UI.WebControls.LinkButton btnRoleApprover;
        protected global::System.Web.UI.WebControls.LinkButton btnRoleRequestor;
        protected global::System.Web.UI.WebControls.LinkButton btnLogout;
        protected global::System.Web.UI.WebControls.LinkButton btnLogout2;
    }
}
