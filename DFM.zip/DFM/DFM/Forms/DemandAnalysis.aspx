<%@ Page Title="Demand Analysis" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="DemandAnalysis.aspx.cs" Inherits="DFM.Forms.DemandAnalysis" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-flag"></span> Demand Analysis
        <span class="dashboard-timestamp"><span class="glyphicon glyphicon-refresh"></span>
            Data Last Updated: <asp:Literal ID="litTs" runat="server" /></span>
    </h1>

    <div class="kpi-grid">
        <div class="kpi-card kpi-blue"><span class="glyphicon glyphicon-list-alt kpi-icon"></span>
            <div class="kpi-label">Total Demands</div><div class="kpi-value"><asp:Literal ID="kTotal" runat="server" /></div></div>
        <div class="kpi-card kpi-teal"><span class="glyphicon glyphicon-transfer kpi-icon"></span>
            <div class="kpi-label">Converted</div><div class="kpi-value"><asp:Literal ID="kConv" runat="server" /></div></div>
        <div class="kpi-card kpi-orange"><span class="glyphicon glyphicon-time kpi-icon"></span>
            <div class="kpi-label">In Progress</div><div class="kpi-value"><asp:Literal ID="kProg" runat="server" /></div></div>
        <div class="kpi-card kpi-slate"><span class="glyphicon glyphicon-pause kpi-icon"></span>
            <div class="kpi-label">On Hold</div><div class="kpi-value"><asp:Literal ID="kHold" runat="server" /></div></div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-stats"></span> Demand Conversion Trend</h3>
        <div id="hcTrend" style="height:380px;"></div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-th-large"></span> Demand by Platform</h3>
        <div id="hcByPlatform" style="height:380px;"></div>
    </div>

    <script>
        (function () {
            var trend = <%= JsTrend %>, plat = <%= JsPlat %>;
            if (window.Highcharts && trend.length && document.getElementById('hcTrend')) {
                Highcharts.chart('hcTrend', {
                    chart: { type: 'line' }, title: { text: null },
                    xAxis: { type: 'category' }, yAxis: { title: { text: 'Demands' }, allowDecimals: false },
                    series: [{ name: 'Demands Created', data: trend.map(function(t){return [t.month, t.cnt];}), color: '#1e40af' }]
                });
            }
            if (window.Highcharts && plat.length && document.getElementById('hcByPlatform')) {
                Highcharts.chart('hcByPlatform', {
                    chart: { type: 'pie' }, title: { text: null },
                    series: [{ name: 'Demands', data: plat.map(function(p){return { name: p.bucket, y: p.total }; }) }]
                });
            }
        })();
    </script>
</asp:Content>
