namespace DFM.Forms
{
    public partial class ExecutiveDashboard
    {
        protected global::System.Web.UI.WebControls.Literal litTs;
        protected global::System.Web.UI.WebControls.Literal kTotal;
        protected global::System.Web.UI.WebControls.Literal kActive;
        protected global::System.Web.UI.WebControls.Literal kClosed;
        protected global::System.Web.UI.WebControls.Literal kDeliv;
        protected global::System.Web.UI.WebControls.Literal kRisk;
    }
}
