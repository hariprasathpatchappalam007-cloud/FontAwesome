namespace DFM.Forms
{
    public partial class JiraIntegration
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.TextBox txtJql;
        protected global::System.Web.UI.WebControls.Button btnFetch;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
