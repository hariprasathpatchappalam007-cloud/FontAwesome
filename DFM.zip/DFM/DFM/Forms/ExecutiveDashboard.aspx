<%@ Page Title="Executive Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ExecutiveDashboard.aspx.cs" Inherits="DFM.Forms.ExecutiveDashboard" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-stats"></span> Executive Dashboard
        <span class="dashboard-timestamp"><span class="glyphicon glyphicon-refresh"></span>
            Data Last Updated: <asp:Literal ID="litTs" runat="server" /></span>
    </h1>

    <div class="kpi-grid">
        <div class="kpi-card kpi-blue"><span class="glyphicon glyphicon-folder-open kpi-icon"></span>
            <div class="kpi-label">Total Demands</div><div class="kpi-value"><asp:Literal ID="kTotal" runat="server" /></div></div>
        <div class="kpi-card kpi-green"><span class="glyphicon glyphicon-ok kpi-icon"></span>
            <div class="kpi-label">Active Projects</div><div class="kpi-value"><asp:Literal ID="kActive" runat="server" /></div></div>
        <div class="kpi-card kpi-slate"><span class="glyphicon glyphicon-check kpi-icon"></span>
            <div class="kpi-label">Closed Projects</div><div class="kpi-value"><asp:Literal ID="kClosed" runat="server" /></div></div>
        <div class="kpi-card kpi-teal"><span class="glyphicon glyphicon-thumbs-up kpi-icon"></span>
            <div class="kpi-label">Delivery %</div><div class="kpi-value"><asp:Literal ID="kDeliv" runat="server" /></div></div>
        <div class="kpi-card kpi-red"><span class="glyphicon glyphicon-warning-sign kpi-icon"></span>
            <div class="kpi-label">Risk %</div><div class="kpi-value"><asp:Literal ID="kRisk" runat="server" /></div></div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-th-large"></span> Portfolio Health by Platform</h3>
        <div id="hcPortfolio" style="height:380px;"></div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-tasks"></span> Delivery Summary by Vertical</h3>
        <div id="hcVertical" style="height:380px;"></div>
    </div>

    <script>
        (function () {
            var portfolio = <%= JsPortfolio %>;
            var vertical  = <%= JsVertical %>;
            if (window.Highcharts && portfolio.length && document.getElementById('hcPortfolio')) {
                Highcharts.chart('hcPortfolio', {
                    chart: { type: 'column' }, title: { text: null },
                    xAxis: { type: 'category' }, yAxis: { title: { text: 'Count' }, allowDecimals: false },
                    legend: { enabled: true },
                    plotOptions: { column: { stacking: 'normal' } },
                    series: [
                        { name: 'Open',   data: portfolio.map(function(p){return [p.bucket, p.open];}),   color: '#b45309' },
                        { name: 'Closed', data: portfolio.map(function(p){return [p.bucket, p.closed];}), color: '#15803d' }
                    ]
                });
            }
            if (window.Highcharts && vertical.length && document.getElementById('hcVertical')) {
                Highcharts.chart('hcVertical', {
                    chart: { type: 'bar' }, title: { text: null },
                    xAxis: { type: 'category' }, yAxis: { title: { text: 'Demands' }, allowDecimals: false },
                    legend: { enabled: false },
                    series: [{ name: 'Total', data: vertical.map(function(v){return [v.bucket, v.total];}), colorByPoint: true }]
                });
            }
        })();
    </script>
</asp:Content>
