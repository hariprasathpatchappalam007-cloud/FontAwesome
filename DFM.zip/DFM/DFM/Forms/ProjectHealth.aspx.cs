using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;

namespace DFM.Forms
{
    public partial class ProjectHealth : System.Web.UI.Page
    {
        public string JsRag { get; private set; }
        public ProjectHealth() { JsRag = "[]"; }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                kGreen.Text = CountByRag("Green").ToString();
                kAmber.Text = CountByRag("Amber").ToString();
                kRed.Text   = CountByRag("Red").ToString();
                JsRag = BuildRagJson();
                DataRow ts = Db.QueryRow("SELECT MAX(LastSyncDate) AS LastSync FROM DashboardSummary");
                litTs.Text = (ts != null && ts["LastSync"] != DBNull.Value)
                    ? Convert.ToDateTime(ts["LastSync"]).ToString("dd-MMM-yyyy hh:mm tt")
                    : DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt");
            }
            catch { litTs.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt"); }

            if (!IsPostBack) BindGrid();
        }

        private void BindGrid()
        {
            try
            {
                gv.DataSource = Db.Query(@"SELECT TOP 200 JiraKey, ISNULL(Summary,'') AS Summary,
                    ISNULL(OverallProjectRag,'') AS OverallProjectRag,
                    ISNULL(ScheduleRag,'') AS ScheduleRag,
                    ISNULL(BudgetRag,'') AS BudgetRag,
                    ISNULL(RaidRag,'') AS RaidRag,
                    ISNULL(Manager,'') AS Manager
                    FROM JiraIssues
                    WHERE OverallProjectRag IN ('Red','Amber') AND ProjectKey='DIBITP'
                    ORDER BY OverallProjectRag, JiraKey");
                gv.DataBind();
            }
            catch { }
        }

        protected void gv_Paging(object sender, GridViewPageEventArgs e) { gv.PageIndex = e.NewPageIndex; BindGrid(); }

        private static int CountByRag(string r)
        {
            try
            {
                DataRow x = Db.QueryRow("SELECT COUNT(*) AS C FROM JiraIssues WHERE OverallProjectRag=@rag", new SqlParameter("@rag", r));
                return x == null || x["C"] == DBNull.Value ? 0 : Convert.ToInt32(x["C"]);
            }
            catch { return 0; }
        }

        private static string BuildRagJson()
        {
            try
            {
                DataTable dt = Db.Query("SELECT Bucket, TotalCount FROM DashboardSummary WHERE Dimension='RAG' ORDER BY TotalCount DESC");
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    sb.Append("{\"bucket\":\"").Append((dt.Rows[i]["Bucket"] ?? "").ToString().Replace("\"", "\\\""))
                      .Append("\",\"total\":").Append(dt.Rows[i]["TotalCount"]).Append("}");
                }
                sb.Append("]");
                return sb.ToString();
            }
            catch { return "[]"; }
        }
    }
}
