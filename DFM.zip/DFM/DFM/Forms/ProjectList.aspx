<%@ Page Title="Project List" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ProjectList.aspx.cs" Inherits="DFM.Forms.ProjectList" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">Project List</h1>

    <div class="filter-row">
        <div class="form-group">
            <label>Type</label>
            <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Value="ALL">All</asp:ListItem>
                <asp:ListItem Value="CAPEX" />
                <asp:ListItem Value="OPEX" />
                <asp:ListItem Value="AMC" />
            </asp:DropDownList>
        </div>
        <div class="form-group">
            <label>Status</label>
            <asp:DropDownList ID="ddlStatus" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Value="ALL">All</asp:ListItem>
                <asp:ListItem>Draft</asp:ListItem>
                <asp:ListItem>Pending</asp:ListItem>
                <asp:ListItem>Approved</asp:ListItem>
                <asp:ListItem>Rejected</asp:ListItem>
            </asp:DropDownList>
        </div>
        <div class="form-group" style="align-self: flex-end;">
            <asp:Button ID="btnExport" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
        </div>
        <div class="form-group" style="align-self: flex-end;">
            <asp:HyperLink ID="lnkNew" runat="server" NavigateUrl="~/Forms/ProjectRegistration.aspx"
                CssClass="btn btn-primary" Text="+ New Project" />
        </div>
    </div>

    <div class="card-panel">
        <h3>All projects</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
                DataKeyNames="ProjectID">
                <Columns>
                    <asp:HyperLinkField DataNavigateUrlFields="ProjectID"
                        DataNavigateUrlFormatString="~/Forms/ProjectRegistration.aspx?id={0}"
                        DataTextField="ProjectCode" HeaderText="Code" />
                    <asp:BoundField DataField="ProjectName" HeaderText="Project Name" />
                    <asp:TemplateField HeaderText="Type">
                        <ItemTemplate>
                            <span class='chip chip-<%# Eval("ProjectType").ToString().ToLower() %>'><%# Eval("ProjectType") %></span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="JiraID" HeaderText="JIRA" />
                    <asp:BoundField DataField="BudgetSourceID" HeaderText="Budget Source" />
                    <asp:BoundField DataField="ApproverName" HeaderText="Approver" />
                    <asp:BoundField DataField="RequestedAmount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="LockedAmount"   HeaderText="Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="DebitedAmount"  HeaderText="Debited" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:TemplateField HeaderText="Status">
                        <ItemTemplate>
                            <span class='badge-status badge-<%# Eval("Status").ToString().ToLower() %>'><%# Eval("Status") %></span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="CreatedBy" HeaderText="Created By" />
                    <asp:BoundField DataField="CreatedDate" HeaderText="Created" DataFormatString="{0:dd-MMM-yy}" />
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
