<%@ Page Title="Project List" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ProjectList.aspx.cs" Inherits="DFM.Forms.ProjectList" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-list-alt"></span> Project List</h1>

    <!-- Req 4-5: workflow-stage view, plus history link -->
    <div class="filter-row">
        <div class="form-group">
            <label>Type</label>
            <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Value="ALL">All</asp:ListItem>
                <asp:ListItem Value="CAPEX" />
                <asp:ListItem Value="OPEX" />
                <asp:ListItem Value="AMC" />
            </asp:DropDownList>
        </div>
        <div class="form-group">
            <label>Workflow Stage</label>
            <asp:DropDownList ID="ddlStage" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Value="ALL">All</asp:ListItem>
                <asp:ListItem>Registration</asp:ListItem>
                <asp:ListItem>PET</asp:ListItem>
                <asp:ListItem Value="PET Approval">PET Approval</asp:ListItem>
                <asp:ListItem>BPM</asp:ListItem>
                <asp:ListItem>Closed</asp:ListItem>
            </asp:DropDownList>
        </div>
        <div class="form-group col-span-2">
            <label>Search (JIRA ID / Name)</label>
            <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" AutoPostBack="true" OnTextChanged="Filter_Changed" />
        </div>
        <div class="form-group">
            <label>&nbsp;</label>
            <div class="toolbar" style="margin:0;">
                <asp:Button ID="btnExport" runat="server" Text="Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
                <asp:HyperLink ID="lnkNew" runat="server" NavigateUrl="~/Forms/Workflow.aspx"
                    CssClass="btn btn-primary" Text="+ New" />
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3>All projects</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
                DataKeyNames="ProjectID" AllowPaging="true" PageSize="20"
                OnPageIndexChanging="gv_PageIndexChanging">
                <PagerStyle CssClass="pager" />
                <Columns>
                    <asp:HyperLinkField DataNavigateUrlFields="ProjectID"
                        DataNavigateUrlFormatString="~/Forms/Workflow.aspx?id={0}"
                        DataTextField="ProjectCode" HeaderText="JIRA / Code" />
                    <asp:BoundField DataField="ProjectName" HeaderText="Project Name" />
                    <asp:TemplateField HeaderText="Type">
                        <ItemTemplate>
                            <span class='chip chip-<%# Eval("ProjectType").ToString().ToLower() %>'><%# Eval("ProjectType") %></span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="BudgetSourceID" HeaderText="Budget" />
                    <asp:BoundField DataField="RequestedAmount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <%-- Req 4: workflow stage status columns --%>
                    <asp:TemplateField HeaderText="CAPEX">
                        <ItemTemplate>
                            <span class='badge-status badge-<%# StageCss(Eval("CapexStageStatus")) %>'>
                                <%# Eval("CapexStageStatus") == null || Eval("CapexStageStatus") == System.DBNull.Value ? "Pending" : Eval("CapexStageStatus") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="PET">
                        <ItemTemplate>
                            <span class='badge-status badge-<%# StageCss(Eval("PetStageStatus")) %>'>
                                <%# Eval("PetStageStatus") == null || Eval("PetStageStatus") == System.DBNull.Value ? "Pending" : Eval("PetStageStatus") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="PET Approval">
                        <ItemTemplate>
                            <span class='badge-status badge-<%# StageCss(Eval("PetApprovalStatus")) %>'>
                                <%# Eval("PetApprovalStatus") == null || Eval("PetApprovalStatus") == System.DBNull.Value ? "Pending" : Eval("PetApprovalStatus") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="BPM">
                        <ItemTemplate>
                            <span class='badge-status badge-<%# StageCss(Eval("BpmStageStatus")) %>'>
                                <%# Eval("BpmStageStatus") == null || Eval("BpmStageStatus") == System.DBNull.Value ? "Pending" : Eval("BpmStageStatus") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="ApproverName" HeaderText="Approver" />
                    <asp:TemplateField HeaderText="Actions">
                        <ItemTemplate>
                            <a class="btn btn-xs" href='<%# ResolveUrl("~/Forms/Workflow.aspx?id=" + Eval("ProjectID")) %>'>
                                <span class="glyphicon glyphicon-pencil"></span> Open
                            </a>
                            <%-- Req 5: workflow history link --%>
                            <a class="btn btn-xs btn-secondary" href='<%# ResolveUrl("~/Forms/ProjectHistory.aspx?id=" + Eval("ProjectID")) %>'>
                                <span class="glyphicon glyphicon-time"></span> History
                            </a>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:14px;">No projects.</div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
