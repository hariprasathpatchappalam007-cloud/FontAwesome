<%@ Page Title="Project List" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ProjectList.aspx.cs" Inherits="DFM.Forms.ProjectList" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-list-alt"></span> Project List</h1>

    <!-- Req 4-5: workflow-stage view, plus history link -->
    <div class="filter-row">
        <div class="form-group">
            <label>Type</label>
            <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Value="ALL">All</asp:ListItem>
                <asp:ListItem Value="CAPEX" />
                <asp:ListItem Value="OPEX" />
                <asp:ListItem Value="AMC" />
            </asp:DropDownList>
        </div>
        <div class="form-group">
            <label>Workflow Stage</label>
            <asp:DropDownList ID="ddlStage" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                <asp:ListItem Value="ALL">All</asp:ListItem>
                <asp:ListItem>Registration</asp:ListItem>
                <asp:ListItem>PET</asp:ListItem>
                <asp:ListItem Value="PET Approval">PET Approval</asp:ListItem>
                <asp:ListItem>BPM</asp:ListItem>
                <asp:ListItem>Closed</asp:ListItem>
            </asp:DropDownList>
        </div>
        <div class="form-group col-span-2">
            <label>Search (JIRA ID / Name)</label>
            <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" AutoPostBack="true" OnTextChanged="Filter_Changed" />
        </div>
        <div class="form-group">
            <label>&nbsp;</label>
            <div class="toolbar" style="margin:0;">
                <asp:Button ID="btnExport" runat="server" Text="Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
                <asp:HyperLink ID="lnkNew" runat="server" NavigateUrl="~/Forms/Workflow.aspx"
                    CssClass="btn btn-primary" Text="+ New" />
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3>All Projects</h3>
        <div id="projectTreeWrap">
            <asp:Literal ID="litTree" runat="server" />
        </div>
    </div>

    <script>
        function dfmTog(id) {
            var parts = id.split(' ');
            var targetCls = parts[parts.length - 1];
            var rows = document.querySelectorAll('.tree-row.' + targetCls);
            var hidden = rows.length > 0 && rows[0].classList.contains('tree-hidden');
            rows.forEach(function (r) {
                if (hidden) { r.classList.remove('tree-hidden'); }
                else {
                    r.classList.add('tree-hidden');
                    r.className.split(' ').forEach(function (c) {
                        if (c !== 'tree-row' && c !== targetCls && c !== 'tree-hidden') {
                            document.querySelectorAll('.tree-row.' + c).forEach(function (n) { n.classList.add('tree-hidden'); });
                            var nb = document.querySelector('[data-tog="' + c + '"]');
                            if (nb) nb.textContent = '\u25B8';
                        }
                    });
                }
            });
            var btn = document.querySelector('[data-tog="' + targetCls + '"]');
            if (btn) btn.textContent = hidden ? '\u25BE' : '\u25B8';
        }
    </script>
    <style>
        .tree-table { width:100%; border-collapse:collapse; font-size:.85em; }
        .tree-table th { background:#f1f5f9; padding:7px 10px; text-align:left; font-size:.8em; color:#475569; font-weight:700; border-bottom:1px solid #e2e8f0; white-space:nowrap; }
        .tree-table td { padding:6px 10px; border-bottom:1px solid #f1f5f9; vertical-align:middle; }
        .tree-table tr:hover td { background:#f8fafc; }
        .tree-hidden { display:none; }
        .tree-toggle { cursor:pointer; user-select:none; color:var(--primary,#0b6efd); font-size:1em; margin-right:4px; }
        td.indent1 { padding-left:28px; } td.indent2 { padding-left:50px; } td.indent3 { padding-left:72px; }
        .tree-badge { display:inline-block; padding:2px 8px; border-radius:999px; font-size:.75em; font-weight:600; }
        .tree-badge.ok { background:#dcfce7; color:#15803d; } .tree-badge.warn { background:#fef3c7; color:#b45309; }
        .tree-badge.danger { background:#fee2e2; color:#b91c1c; } .tree-badge.info { background:#dbeafe; color:#1d4ed8; }
        .tree-badge.violet { background:#ede9fe; color:#6d28d9; } .tree-badge.muted { background:#f1f5f9; color:#64748b; }
    </style>
</asp:Content>
