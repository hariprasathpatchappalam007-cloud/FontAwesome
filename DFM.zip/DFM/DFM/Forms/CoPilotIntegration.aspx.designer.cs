namespace DFM.Forms
{
    public partial class CoPilotIntegration
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.DropDownList ddlProject;
        protected global::System.Web.UI.WebControls.Literal litStatus;
        protected global::System.Web.UI.WebControls.DropDownList ddlDocType;
        protected global::System.Web.UI.WebControls.FileUpload fuDoc;
        protected global::System.Web.UI.WebControls.Button btnUpload;
        protected global::System.Web.UI.WebControls.GridView gv;
        protected global::System.Web.UI.WebControls.HyperLink lnkBpm;
    }
}
