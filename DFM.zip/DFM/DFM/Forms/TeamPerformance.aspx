<%@ Page Title="Team Performance" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="TeamPerformance.aspx.cs" Inherits="DFM.Forms.TeamPerformance" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-user"></span> Team Performance
        <span class="dashboard-timestamp"><span class="glyphicon glyphicon-refresh"></span>
            Data Last Updated: <asp:Literal ID="litTs" runat="server" /></span>
    </h1>

    <div class="jira-bar-row">
        <div class="jira-chart-card">
            <h4><span class="glyphicon glyphicon-briefcase"></span> Project Manager Workload</h4>
            <div id="hcMgr" style="height:380px;"></div>
        </div>
        <div class="jira-chart-card">
            <h4><span class="glyphicon glyphicon-wrench"></span> Tech Lead Workload</h4>
            <div id="hcTech" style="height:380px;"></div>
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-king"></span> Chief-wise Demand Ownership</h3>
        <div id="hcChief" style="height:380px;"></div>
    </div>

    <script>
        (function () {
            var mgr = <%= JsMgr %>, tech = <%= JsTech %>, chief = <%= JsChief %>;
            function bar(id, data, color) {
                if (!window.Highcharts || !data.length || !document.getElementById(id)) return;
                Highcharts.chart(id, {
                    chart: { type: 'bar' }, title: { text: null },
                    xAxis: { type: 'category' }, yAxis: { title: { text: 'Count' }, allowDecimals: false },
                    legend: { enabled: true },
                    plotOptions: { series: { stacking: 'normal' } },
                    series: [
                        { name: 'Open',   data: data.map(function(d){return [d.bucket, d.open];}),   color: color || '#b45309' },
                        { name: 'Closed', data: data.map(function(d){return [d.bucket, d.closed];}), color: '#15803d' }
                    ]
                });
            }
            bar('hcMgr', mgr);
            bar('hcTech', tech);
            bar('hcChief', chief, '#1e40af');
        })();
    </script>
</asp:Content>
