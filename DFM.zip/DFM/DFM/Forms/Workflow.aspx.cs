using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class Workflow : System.Web.UI.Page
    {
        // ===== Project / Stage state (ViewState backed) =====
        protected int CurrentProjectId
        {
            get { object o = ViewState["pid"]; return o == null ? 0 : (int)o; }
            set { ViewState["pid"] = value; }
        }
        protected string CurrentProjectIdJs
        {
            get { return CurrentProjectId > 0 ? CurrentProjectId.ToString() : "0"; }
        }

        // Stage values: "Project", "PET", "PETApproval", "BPM", "Closed"
        private string CurrentStageKey
        {
            get { object o = ViewState["stage"]; return o == null ? "Project" : (string)o; }
            set { ViewState["stage"] = value; }
        }

        // JSON of currency code -> rate-to-AED for the inline JS calculator.
        public string PetRatesJs { get; private set; }

        // Accordion class strings used by <%= %> in markup.
        public string ProjectAccordionClass { get; set; }
        public string PetAccordionClass { get; set; }
        public string PetApprovalAccordionClass { get; set; }
        public string BpmAccordionClass { get; set; }
        public string HistoryAccordionClass { get; set; }

        // Req 6: true when there are PET items not yet tagged to a submission version
        private bool HasUnsubmittedPet { get; set; }

        private Dictionary<string, string> _guidance;
        public string GetGuidance(string field)
        {
            if (_guidance == null)
            {
                _guidance = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    DataTable g = WorkflowDAL.GetPetGuidance();
                    foreach (DataRow r in g.Rows)
                        _guidance[r["FieldName"].ToString()] = r["Guidance"].ToString();
                }
                catch { }
                if (_guidance.Count == 0)
                {
                    try
                    {
                        string path = Path.Combine(
                            System.Configuration.ConfigurationManager.AppSettings["RequirementFolder"] ?? "",
                            "PET Guidance.csv");
                        if (File.Exists(path))
                        {
                            using (var sr = new StreamReader(path, Encoding.UTF8, true))
                            {
                                sr.ReadLine();
                                string line;
                                while ((line = sr.ReadLine()) != null)
                                {
                                    var f = CsvImporter.ParseCsvLine(line);
                                    if (f.Count >= 2 && !string.IsNullOrEmpty(f[0]))
                                        _guidance[f[0].Trim()] = (f[1] ?? "").Trim();
                                }
                            }
                        }
                    }
                    catch { }
                }
            }
            string v;
            return _guidance.TryGetValue(field, out v) ? Server.HtmlEncode(v) : "";
        }

        // ===== Lifecycle =====
        protected void Page_Load(object sender, EventArgs e)
        {
            ProjectAccordionClass = "";
            PetAccordionClass = "collapsed";
            PetApprovalAccordionClass = "collapsed";
            BpmAccordionClass = "collapsed";
            HistoryAccordionClass = "";

            if (!IsPostBack)
            {
                LoadJiraDropdown();
                LoadApprovers();
                LoadPetMasters();
                LoadCurrencies();
                LoadGL();
                LoadVendors();
                LoadSources();

                int qid;
                if (int.TryParse(Request.QueryString["id"], out qid) && qid > 0)
                {
                    CurrentProjectId = qid;
                    LoadProject(qid);
                }
                else
                {
                    // Fresh project
                    BuildStepper(null);
                    CurrentStageKey = "Project";
                }
                BindBudgetGrid();
            }

            // ApplyStageGating runs every request so visibility / read-only stays
            // consistent after postback actions that change the stage.
            ApplyStageGating();
        }

        // ===== Stage detection =====
        private string DetectStage(DataRow prj)
        {
            if (prj == null) return "Project";
            string current    = prj["CurrentStage"] == DBNull.Value ? "" : prj["CurrentStage"].ToString();
            string petStatus  = SafeStr(prj, "PetStageStatus");
            string petAppr    = SafeStr(prj, "PetApprovalStatus");
            string bpmStatus  = SafeStr(prj, "BpmStageStatus");

            if (string.Equals(bpmStatus, "Closed",    StringComparison.OrdinalIgnoreCase)) return "Closed";
            // Req 1.5: once BPM is started (Submitted or later) it remains active even during re-approval cycles
            if (string.Equals(bpmStatus, "Submitted", StringComparison.OrdinalIgnoreCase)) return "BPM";
            if (string.Equals(petAppr,   "Approved",  StringComparison.OrdinalIgnoreCase)) return "BPM";
            if (string.Equals(petAppr,   "Rejected",  StringComparison.OrdinalIgnoreCase)) return "Project";
            if (string.Equals(petStatus, "Submitted", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(petStatus, "Resubmitted", StringComparison.OrdinalIgnoreCase)) return "PETApproval";
            if (current == "PET" || (current == "Registration" && SafeStr(prj, "Status") != "Draft")) return "PET";
            return "Project";
        }

        private string SafeStr(DataRow r, string c)
        {
            if (!r.Table.Columns.Contains(c) || r[c] == DBNull.Value) return "";
            return r[c].ToString();
        }

        // ===== Stage-driven visibility + read-only =====
        private void ApplyStageGating()
        {
            string stage = CurrentStageKey;
            bool hasProject = CurrentProjectId > 0;

            // ---- Section visibility ----
            // PET is always visible once a project exists (Req 4: no freeze period)
            pnlPet.Visible          = hasProject;
            // Approval panel: show when there is a pending submission, or already in BPM/Closed
            pnlPetApproval.Visible  = stage == "PETApproval" || stage == "BPM" || stage == "Closed";
            pnlBpm.Visible          = stage == "BPM" || stage == "Closed";
            pnlAttach.Visible       = hasProject;

            // ---- Role detection ----
            string activeRole  = (Session["ActiveRole"] as string) ?? "";
            string sessionRole = (Session["Role"] as string) ?? "";
            // Obs 2: Expand role check to handle "PET Approver" role name variant and any role
            // containing the word "approver" (case-insensitive), so approvers can always see buttons.
            bool isRoleApprover = string.Equals(activeRole,  "Approver",     StringComparison.OrdinalIgnoreCase)
                               || string.Equals(sessionRole, "Approver",     StringComparison.OrdinalIgnoreCase)
                               || string.Equals(sessionRole, "Admin",        StringComparison.OrdinalIgnoreCase)
                               || string.Equals(activeRole,  "PET Approver", StringComparison.OrdinalIgnoreCase)
                               || string.Equals(sessionRole, "PET Approver", StringComparison.OrdinalIgnoreCase)
                               || (activeRole  != null && activeRole.IndexOf("Approver",  StringComparison.OrdinalIgnoreCase) >= 0)
                               || (sessionRole != null && sessionRole.IndexOf("Approver", StringComparison.OrdinalIgnoreCase) >= 0);
            // Also allow anyone who is the project's assigned approver (regardless of role)
            bool isProjectApprover = hasProject && IsAssignedApprover();
            bool isApprover = isRoleApprover || isProjectApprover;

            // ---- Action button visibility ----
            pnlProjectActions.Visible    = stage == "Project";
            // PET add/submit always visible once project saved (Req 4)
            pnlPetAddActions.Visible  = hasProject;
            // Req 6: hide Submit button once submitted & pending approval (no new/modified items)
            // Show it again if there are unversioned (new or modified) items
            bool petPendingApproval = false;
            if (hasProject)
            {
                object apprStatus = Db.Scalar(
                    "SELECT PetApprovalStatus FROM Projects WHERE ProjectID=@id",
                    Db.P("@id", CurrentProjectId));
                petPendingApproval = apprStatus != null && apprStatus != DBNull.Value
                    && string.Equals(apprStatus.ToString(), "Pending", StringComparison.OrdinalIgnoreCase);
            }
            pnlPetSubmitActions.Visible = hasProject && (HasUnsubmittedPet || !petPendingApproval);
            pnlApprovalActions.Visible   = stage == "PETApproval" && isApprover;
            pnlBpmActions.Visible        = stage == "BPM" || stage == "Closed";

            // ---- Editability ----
            bool projectEditable = (stage == "Project" || stage == "PET");
            SetEditable(new Control[] { ddlJira, ddlType, ddlSource, ddlApprover }, projectEditable);
            txtName.ReadOnly = true;

            // PET inputs: editable at all times once project exists (Req 4: no freeze)
            bool petEditable = hasProject;
            SetEditable(new Control[] { ddlDept, ddlCostType, ddlExpHead, txtTopic, txtVendor, txtDesc,
                                        txtUnits, txtUnitPrice, ddlCurrency, fuPetCsv }, petEditable);

            bool approvalEditable = stage == "PETApproval" && isApprover;
            SetEditable(new Control[] { txtApprovedAmount }, approvalEditable);

            bool bpmEditable = (stage == "BPM");
            SetEditable(new Control[] { ddlGL, txtMemoNumber, txtMemoAmount, ddlMemoVendor,
                txtMemoDateRaised, txtMemoLPO, txtMemoPODate, txtMemoAMS, txtMemoDesc }, bpmEditable);

            if (gvPet != null) gvPet.Columns[gvPet.Columns.Count - 1].Visible = petEditable;
            btnPetUpload.Visible = petEditable;
            fuPetCsv.Visible     = petEditable;
        }

        private void SetEditable(Control[] ctrls, bool editable)
        {
            foreach (Control c in ctrls)
            {
                var tb = c as TextBox;
                if (tb != null) { tb.ReadOnly = !editable; continue; }
                var dd = c as DropDownList;
                if (dd != null) { dd.Enabled = editable; continue; }
                var fu = c as FileUpload;
                if (fu != null) { fu.Enabled = editable; continue; }
            }
        }

        // ===== Loaders =====
        private void LoadJiraDropdown()
        {
            ddlJira.Items.Clear();
            ddlJira.Items.Add(new ListItem("-- Select JIRA ID --", ""));
            try
            {
                DataTable dt = Db.Query(
                    "SELECT JiraKey, ISNULL(Summary,'') AS Summary FROM JiraIssues WHERE ProjectKey='DMGT' ORDER BY JiraKey");
                foreach (DataRow r in dt.Rows)
                {
                    string id = r["JiraKey"].ToString();
                    string name = r["Summary"].ToString();
                    ddlJira.Items.Add(new ListItem(id + (string.IsNullOrEmpty(name) ? "" : " - " + name), id));
                }
            }
            catch { }
        }

        private void LoadApprovers()
        {
            ddlApprover.Items.Clear();
            ddlApprover.Items.Add(new ListItem("-- Select Approver --", ""));
            try
            {
                DataTable dt = MastersDAL.GetApprovers(true);
                foreach (DataRow r in dt.Rows)
                    ddlApprover.Items.Add(new ListItem(r["ApproverName"].ToString(), r["ApproverID"].ToString()));
            }
            catch { }
        }

        private void LoadPetMasters()
        {
            ddlDept.Items.Clear();
            ddlDept.Items.Add(new ListItem("-- Department --", ""));
            ddlCostType.Items.Clear();
            ddlCostType.Items.Add(new ListItem("-- Cost Type --", ""));
            try
            {
                foreach (DataRow r in PetDAL.GetDepartments().Rows)
                    ddlDept.Items.Add(new ListItem(r["Department"].ToString(), r["Department"].ToString()));
                foreach (DataRow r in PetDAL.GetCostTypes().Rows)
                    ddlCostType.Items.Add(new ListItem(r["Category"].ToString(), r["Category"].ToString()));
            }
            catch { }
        }

        private void LoadCurrencies()
        {
            ddlCurrency.Items.Clear();
            var sb = new StringBuilder();
            sb.Append("{");
            bool first = true;
            try
            {
                foreach (DataRow r in PetDAL.GetCurrencies().Rows)
                {
                    string code = r["Code"].ToString();
                    decimal rate = r["RateToLocal"] == DBNull.Value ? 1m : Convert.ToDecimal(r["RateToLocal"]);
                    ddlCurrency.Items.Add(new ListItem(code, code));
                    if (!first) sb.Append(",");
                    sb.Append("\"").Append(code).Append("\":")
                      .Append(rate.ToString("0.######", CultureInfo.InvariantCulture));
                    first = false;
                }
            }
            catch { }
            if (ddlCurrency.Items.Count == 0)
            {
                ddlCurrency.Items.Add(new ListItem("AED", "AED"));
                sb.Append("\"AED\":1");
            }
            sb.Append("}");
            PetRatesJs = sb.ToString();
            if (ddlCurrency.Items.FindByValue("AED") != null) ddlCurrency.SelectedValue = "AED";
        }

        private void LoadProject(int pid)
        {
            DataRow prj = ProjectsDAL.GetProject(pid);
            if (prj == null) return;

            string jira = prj["JiraID"] == DBNull.Value ? "" : prj["JiraID"].ToString();
            if (!string.IsNullOrEmpty(jira))
            {
                if (ddlJira.Items.FindByValue(jira) == null)
                    ddlJira.Items.Add(new ListItem(jira, jira));
                ddlJira.SelectedValue = jira;
                ShowJiraDetails(jira);
            }
            txtName.Text = prj["ProjectName"].ToString();
            ddlType.SelectedValue = prj["ProjectType"].ToString();
            ShowSourceLabel();
            LoadSources();
            string srcId = prj["BudgetSourceID"] == DBNull.Value ? "" : prj["BudgetSourceID"].ToString();
            if (ddlSource.Items.FindByValue(srcId) != null) ddlSource.SelectedValue = srcId;
            if (prj["ApproverID"] != DBNull.Value &&
                ddlApprover.Items.FindByValue(prj["ApproverID"].ToString()) != null)
                ddlApprover.SelectedValue = prj["ApproverID"].ToString();

            // Detect & store stage
            CurrentStageKey = DetectStage(prj);

            BindPet(pid);
            BindPetVersionHistory(pid);
            BindPetVersionTable(pid);
            BindHistory(pid);
            BindAttachments(pid);
            BindMemos(pid);
            BindBudgetGrid();
            BuildStepper(prj);

            // Pre-fill PET totals + approval amount
            decimal petTotal = PetDAL.GetTotalForProject(pid);
            txtPetTotal.Text = petTotal.ToString("F2", CultureInfo.InvariantCulture);
            decimal petApproved = prj.Table.Columns.Contains("PetApprovedAmount") && prj["PetApprovedAmount"] != DBNull.Value
                ? Convert.ToDecimal(prj["PetApprovedAmount"]) : 0m;
            txtApprovedAmount.Text = (petApproved > 0 ? petApproved : petTotal)
                .ToString("F2", CultureInfo.InvariantCulture);

            // Auto-open the relevant accordion when the user first arrives.
            ProjectAccordionClass     = "collapsed";
            PetAccordionClass         = "collapsed";
            PetApprovalAccordionClass = "collapsed";
            BpmAccordionClass         = "collapsed";
            switch (CurrentStageKey)
            {
                case "Project":     ProjectAccordionClass     = ""; break;
                case "PET":         PetAccordionClass         = ""; break;
                case "PETApproval": PetApprovalAccordionClass = ""; break;
                case "BPM":         BpmAccordionClass         = ""; break;
                case "Closed":      HistoryAccordionClass     = ""; break;
            }
        }

        private void ShowJiraDetails(string jiraId)
        {
            DataRow ji = null;
            try
            {
                ji = Db.QueryRow(
                    "SELECT * FROM JiraIssues WHERE JiraKey=@id",
                    Db.P("@id", jiraId));
            }
            catch { }
            if (ji == null)
            {
                ji = JiraClient.GetCachedIssue(jiraId);
            }
            litJiraId.Text = jiraId;
            if (ji == null) return;

            // Map Project Name from Summary (per requirement)
            string summary = ji.Table.Columns.Contains("Summary") && ji["Summary"] != DBNull.Value
                ? ji["Summary"].ToString()
                : (ji.Table.Columns.Contains("ProjectName") && ji["ProjectName"] != DBNull.Value
                    ? ji["ProjectName"].ToString() : "");

            litJiraName.Text    = Server.HtmlEncode(summary);
            litJProjectName.Text= Server.HtmlEncode(summary);
            litJStage.Text      = Safe(ji, "ProjectStage");
            litJRag.Text        = Safe(ji, "ProjectRAG");
            litJDemand.Text     = Safe(ji, "DemandType");
            litJMgr.Text        = Safe(ji, "Manager");
            litJTech.Text       = Safe(ji, "TechLead");
            litJSponsor.Text    = Safe(ji, "Sponsor");
            litJDept.Text       = Safe(ji, "Department");
            litJStart.Text      = Safe(ji, "StartDate");
            litJEnd.Text        = Safe(ji, "EndDate");
            litJStatus.Text     = Safe(ji, "OverallStatus");
            litJProjectType.Text= Safe(ji, "ProjectType");
            litJClassification.Text      = Safe(ji, "Classification");
            litJPlatform.Text            = Safe(ji, "Platform");
            litJPlatformVertical.Text    = Safe(ji, "PlatformVertical");
            litJIssueType.Text           = Safe(ji, "IssueType");
            litJStakeholder.Text         = Safe(ji, "Stakeholder");
            litJAssignee.Text            = Safe(ji, "Assignee");
            litJReporter.Text            = Safe(ji, "Reporter");
            litJAccExecLead.Text         = Safe(ji, "AccountableExecLead");
            litJSmeLead.Text             = Safe(ji, "SmeLead");
            litJAccExec.Text             = Safe(ji, "AccountableExec");
            litJPortfolioHead.Text       = Safe(ji, "IdhPortfolioHead");
            litJAssignedPM.Text          = Safe(ji, "AssignedProjectManager");
            litJDemandOwner.Text         = Safe(ji, "DemandOwner");
            litJChief.Text               = Safe(ji, "ChiefNameMapping");
            litJPrimaryClass.Text        = Safe(ji, "Primary_Classification");
            litJCreated.Text             = Safe(ji, "JiraCreated");
            litJUpdated.Text             = Safe(ji, "JiraUpdated");

            // Always set Project Name from JIRA Summary
            txtName.Text = summary;
        }
        private string Safe(DataRow r, string c)
        {
            if (!r.Table.Columns.Contains(c) || r[c] == DBNull.Value) return "";
            return Server.HtmlEncode(r[c].ToString());
        }

        // ===== Notification Modal (Req 7) =====
        private void ShowNotify(string type, string title, string msg)
        {
            // Also keep lblMsg populated for screen-reader / no-JS fallback
            lblMsg.Visible  = true;
            lblMsg.CssClass = type == "error" ? "alert-danger"
                            : type == "warning" ? "alert-warning"
                            : "alert-success";
            lblMsg.Text = title + ": " + msg;

            var sb = new StringBuilder();
            sb.Append("dfmShowNotify('")
              .Append(type.Replace("'", ""))
              .Append("','")
              .Append(title.Replace("\\", "\\\\").Replace("'", "\\'"))
              .Append("','")
              .Append(msg.Replace("\\", "\\\\").Replace("'", "\\'"))
              .Append("');");
            ClientScript.RegisterStartupScript(GetType(), "dfmNotify", sb.ToString(), true);
        }

        // ===== PET Version History Display =====
        private void BindPetVersionHistory(int pid)
        {
            if (litPetVersions == null) return;
            try
            {
                DataTable subs = PetDAL.GetSubmissions(pid);
                if (subs == null || subs.Rows.Count == 0) { litPetVersions.Text = ""; return; }
                var sb = new StringBuilder("<div class='pet-versions'>");
                foreach (DataRow r in subs.Rows)
                {
                    string st = r["Status"].ToString();
                    string badge = st == "Approved" ? "badge-success"
                                 : st == "Rejected" ? "badge-danger"
                                 : "badge-warning";
                    string dt = r["SubmittedDate"] == DBNull.Value ? ""
                        : Convert.ToDateTime(r["SubmittedDate"]).ToString("dd-MMM-yy");
                    sb.AppendFormat(
                        "<span class='pet-ver-badge {0}'>PET v{1} <small>{2}</small> <em>{3}</em></span>",
                        badge, r["PetVersion"], st, dt);
                }
                sb.Append("</div>");
                litPetVersions.Text = sb.ToString();
            }
            catch { }
        }

        // Builds the full version-history table for the PET Approval panel (Req 1.4, 7)
        private void BindPetVersionTable(int pid)
        {
            if (litPetVersionTable == null) return;
            try
            {
                DataTable subs = PetDAL.GetSubmissions(pid);
                // Resolve approver name from Projects table
                DataRow prj = ProjectsDAL.GetProject(pid);
                string approverName = "";
                if (prj != null && prj["ApproverID"] != DBNull.Value)
                {
                    DataRow ar = Db.QueryRow(
                        "SELECT ApproverName FROM ApproverMaster WHERE ApproverID=@id",
                        Db.P("@id", Convert.ToInt32(prj["ApproverID"])));
                    if (ar != null) approverName = ar["ApproverName"].ToString();
                }

                // Set the pending-with banner in accordion header.
                // Obs 1: Only show the banner when PET has actually been submitted for approval
                // (PetStageStatus = 'Submitted' or 'Resubmitted'), not just because the DB column
                // has a default value of 'Pending'.
                if (litPendingWithBanner != null)
                {
                    string petStageForBanner = prj != null && prj.Table.Columns.Contains("PetStageStatus") && prj["PetStageStatus"] != DBNull.Value
                        ? prj["PetStageStatus"].ToString() : "";
                    bool petActuallySubmitted = string.Equals(petStageForBanner, "Submitted",   StringComparison.OrdinalIgnoreCase)
                                            || string.Equals(petStageForBanner, "Resubmitted", StringComparison.OrdinalIgnoreCase);
                    bool isPendingApproval = prj != null
                        && prj.Table.Columns.Contains("PetApprovalStatus")
                        && prj["PetApprovalStatus"] != DBNull.Value
                        && string.Equals(prj["PetApprovalStatus"].ToString(), "Pending", StringComparison.OrdinalIgnoreCase)
                        && petActuallySubmitted;
                    litPendingWithBanner.Text = isPendingApproval && !string.IsNullOrEmpty(approverName)
                        ? string.Format(" <span class='pending-with-label' style='font-size:.8em;margin-left:8px;'><span class='glyphicon glyphicon-user'></span> Pending with: {0}</span>",
                            Server.HtmlEncode(approverName))
                        : "";
                }

                if (subs == null || subs.Rows.Count == 0)
                {
                    litPetVersionTable.Text = "<p class='text-muted' style='padding:6px;'>No PET submissions yet.</p>";
                    return;
                }

                // Per-version totals from PetForm (Req 7)
                DataTable versionTotals = Db.Query(
                    @"SELECT PetVersion, COUNT(*) AS LineCount, ISNULL(SUM(FinalAmtLCY),0) AS TotalAED
                      FROM PetForm WHERE ProjectID=@p AND PetVersion IS NOT NULL
                      GROUP BY PetVersion",
                    Db.P("@p", pid));

                var sb = new StringBuilder();
                sb.Append("<div class='pet-vtable-wrap'>");
                sb.Append("<table class='pet-vtable'>");
                sb.Append("<thead><tr><th>PET #</th><th>Version</th><th>Status</th><th>Items</th>");
                sb.Append("<th>Total (AED)</th><th>&#916; vs Prev</th>");
                sb.Append("<th>Submitted</th><th>Submitted By</th><th>Approver</th>");
                sb.Append("<th>Approved Date</th><th>Approved Amount</th></tr></thead>");
                sb.Append("<tbody>");

                // subs ordered DESC by PetVersion; iterate reversed for diff calc
                DataRow[] subRows = new DataRow[subs.Rows.Count];
                subs.Rows.CopyTo(subRows, 0);
                // Sort ascending for diff calculation, render descending
                System.Array.Sort(subRows, (a, b) => Convert.ToInt32(a["PetVersion"]).CompareTo(Convert.ToInt32(b["PetVersion"])));

                // Build a dictionary for display order (descending)
                for (int i = subRows.Length - 1; i >= 0; i--)
                {
                    DataRow r = subRows[i];
                    string st = r["Status"].ToString();
                    bool isPending = string.Equals(st, "Pending", StringComparison.OrdinalIgnoreCase);
                    string rowCss = isPending ? " class='pet-vrow-pending'" : "";
                    int ver = Convert.ToInt32(r["PetVersion"]);

                    // Get totals from PetForm for this version
                    DataRow[] vrows = versionTotals.Select("PetVersion=" + ver);
                    int items = vrows.Length > 0 ? Convert.ToInt32(vrows[0]["LineCount"]) : 0;
                    decimal vTotal = vrows.Length > 0 ? Convert.ToDecimal(vrows[0]["TotalAED"]) : 0m;

                    // Diff from previous version
                    decimal diff = 0m;
                    string diffHtml = "&mdash;";
                    if (i > 0)  // not the first version
                    {
                        DataRow prevRow = subRows[i - 1];
                        int prevVer = Convert.ToInt32(prevRow["PetVersion"]);
                        DataRow[] prevVRows = versionTotals.Select("PetVersion=" + prevVer);
                        decimal prevTotal = prevVRows.Length > 0 ? Convert.ToDecimal(prevVRows[0]["TotalAED"]) : 0m;
                        diff = vTotal - prevTotal;
                        string diffSign = diff >= 0 ? "+" : "";
                        string diffCss = diff > 0 ? "color:#16a34a;font-weight:600" : diff < 0 ? "color:#dc2626;font-weight:600" : "color:#64748b";
                        diffHtml = string.Format("<span style='{0}'>{1}AED {2}</span>",
                            diffCss, diffSign, diff.ToString("N0"));
                    }

                    string subDate  = r["SubmittedDate"] == DBNull.Value ? "" : Convert.ToDateTime(r["SubmittedDate"]).ToString("dd-MMM-yy");
                    string subBy    = r["SubmittedBy"]   == DBNull.Value ? "" : r["SubmittedBy"].ToString();
                    string appDate  = r["ApprovedDate"]  == DBNull.Value ? "" : Convert.ToDateTime(r["ApprovedDate"]).ToString("dd-MMM-yy");
                    string appAmt   = r["ApprovedAmount"] == DBNull.Value ? "" : Convert.ToDecimal(r["ApprovedAmount"]).ToString("N2");
                    string approver = isPending ? approverName : (r["ApprovedBy"] == DBNull.Value ? approverName : r["ApprovedBy"].ToString());

                    string statusBadge;
                    switch (st.ToLower())
                    {
                        case "approved": statusBadge = "<span class='pet-vtbl-badge vtbl-approved'>Approved</span>"; break;
                        case "rejected": statusBadge = "<span class='pet-vtbl-badge vtbl-rejected'>Rejected</span>"; break;
                        default:         statusBadge = "<span class='pet-vtbl-badge vtbl-pending'>Pending Approval</span>"; break;
                    }

                    sb.AppendFormat("<tr{0}>", rowCss);
                    sb.AppendFormat("<td><strong>PET-{0:D2}</strong></td>", pid);
                    sb.AppendFormat("<td><strong>V{0}</strong>{1}</td>", ver,
                        isPending ? " <span class='pet-vtbl-now'>&#9658; Current</span>" : "");
                    sb.AppendFormat("<td>{0}</td>", statusBadge);
                    sb.AppendFormat("<td class='text-center'>{0}</td>", items);
                    sb.AppendFormat("<td class='text-right'>AED {0}</td>", vTotal.ToString("N0"));
                    sb.AppendFormat("<td class='text-right'>{0}</td>", diffHtml);
                    sb.AppendFormat("<td>{0}</td>", subDate);
                    sb.AppendFormat("<td>{0}</td>", Server.HtmlEncode(subBy));
                    sb.AppendFormat("<td>{0}{1}</td>", Server.HtmlEncode(approver),
                        isPending ? " <span class='pet-vtbl-badge vtbl-pending' style='font-size:.72em;'>Awaiting</span>" : "");
                    sb.AppendFormat("<td>{0}</td>", appDate);
                    sb.AppendFormat("<td class='text-right'>{0}</td>", string.IsNullOrEmpty(appAmt) ? "&mdash;" : "AED " + appAmt);
                    sb.Append("</tr>");
                }
                sb.Append("</tbody></table></div>");

                // Req 3: Show PET line items for the current pending version so the approver
                // can clearly see PET ID/Version, approval amount and all line items.
                try
                {
                    DataRow pendingSub = PetDAL.GetPendingSubmission(pid);
                    if (pendingSub != null)
                    {
                        int pendingVer = Convert.ToInt32(pendingSub["PetVersion"]);
                        DataTable lineItems = PetDAL.GetByProjectAndVersion(pid, pendingVer);
                        if (lineItems != null && lineItems.Rows.Count > 0)
                        {
                            sb.Append("<div class='pet-approval-items mt-2'>");
                            sb.AppendFormat(
                                "<h5 style='margin:10px 0 6px;font-weight:700;color:var(--heading);'>" +
                                "<span class='glyphicon glyphicon-th-list'></span>&nbsp; " +
                                "PET-{0:D2} &middot; V{1} &mdash; Line Items Pending Approval</h5>",
                                pid, pendingVer);
                            sb.Append("<div class='gridview-wrapper'><table id='petApprItemsTbl' class='pet-vtable' style='width:100%;font-size:.85em;'>");
                            sb.Append("<thead><tr><th>#</th><th>Code</th><th>Dept</th><th>Cost Type</th><th>Topic</th><th>Vendor</th>");
                            sb.Append("<th class='text-right'>Units</th><th class='text-right'>Unit Price</th><th>CCY</th>");
                            sb.Append("<th class='text-right'>Amt FCY</th><th class='text-right'>Amount (AED)</th></tr></thead><tbody>");
                            decimal lineTotal = 0m;
                            foreach (DataRow lr in lineItems.Rows)
                            {
                                decimal lineAmt = lr["FinalAmtLCY"] == DBNull.Value ? 0m : Convert.ToDecimal(lr["FinalAmtLCY"]);
                                lineTotal += lineAmt;
                                sb.AppendFormat("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td>",
                                    lr["SerialNo"],
                                    Server.HtmlEncode(lr["LineCode"]    == DBNull.Value ? "" : lr["LineCode"].ToString()),
                                    Server.HtmlEncode(lr["Department"]  == DBNull.Value ? "" : lr["Department"].ToString()),
                                    Server.HtmlEncode(lr["CostType"]    == DBNull.Value ? "" : lr["CostType"].ToString()),
                                    Server.HtmlEncode(lr["Topic"]       == DBNull.Value ? "" : lr["Topic"].ToString()),
                                    Server.HtmlEncode(lr["Vendor"]      == DBNull.Value ? "" : lr["Vendor"].ToString()));
                                sb.AppendFormat(
                                    "<td class='text-right'>{0}</td><td class='text-right'>{1}</td><td>{2}</td>" +
                                    "<td class='text-right'>{3}</td><td class='text-right'><strong>{4}</strong></td></tr>",
                                    lr["Units"]       == DBNull.Value ? "0" : Convert.ToDecimal(lr["Units"]).ToString("N2"),
                                    lr["UnitPrice"]   == DBNull.Value ? "0" : Convert.ToDecimal(lr["UnitPrice"]).ToString("N2"),
                                    Server.HtmlEncode(lr["BaseCurrency"] == DBNull.Value ? "" : lr["BaseCurrency"].ToString()),
                                    lr["AmtFCY"]      == DBNull.Value ? "0" : Convert.ToDecimal(lr["AmtFCY"]).ToString("N2"),
                                    lineAmt.ToString("N2"));
                            }
                            sb.AppendFormat(
                                "<tr style='background:#f0f7ff;font-weight:700;'><td colspan='10' class='text-right'>" +
                                "Total (AED)</td><td class='text-right'>AED {0}</td></tr>",
                                lineTotal.ToString("N0"));
                            sb.Append("</tbody></table></div></div>");
                        }
                    }
                }
                catch { }

                litPetVersionTable.Text = sb.ToString();
            }
            catch { litPetVersionTable.Text = ""; }
        }

        protected void ddlJira_Changed(object sender, EventArgs e)
        {
            ShowJiraDetails(ddlJira.SelectedValue);
            if (!string.IsNullOrEmpty(ddlJira.SelectedValue) && CurrentProjectId == 0)
            {
                DataRow existing = Db.QueryRow(
                    "SELECT TOP 1 ProjectID FROM Projects WHERE JiraID=@j ORDER BY ProjectID DESC",
                    Db.P("@j", ddlJira.SelectedValue));
                if (existing != null)
                {
                    int pid = Convert.ToInt32(existing["ProjectID"]);
                    CurrentProjectId = pid;
                    LoadProject(pid);
                }
            }
        }

        protected void ddlType_Changed(object sender, EventArgs e)
        {
            ShowSourceLabel();
            LoadSources();
            BindBudgetGrid();
        }
        protected void ddlSource_Changed(object sender, EventArgs e) { BindBudgetGrid(); }

        private void ShowSourceLabel() { litSourceLabel.Text = ddlType.SelectedValue; }

        private void LoadGL()
        {
            ddlGL.Items.Clear();
            ddlGL.Items.Add(new ListItem("-- Select GL --", ""));
            try
            {
                DataTable dt = GLMasterDAL.GetAll(true);
                foreach (DataRow r in dt.Rows)
                    ddlGL.Items.Add(new ListItem(r["GLCode"] + " - " + r["Description"], r["GLCode"].ToString()));
            }
            catch { }
        }

        private void LoadVendors()
        {
            ddlMemoVendor.Items.Clear();
            ddlMemoVendor.Items.Add(new ListItem("-- Select Vendor --", ""));
            try
            {
                DataTable dt = VendorMasterDAL.GetAll(true);
                foreach (DataRow r in dt.Rows)
                    ddlMemoVendor.Items.Add(new ListItem(r["VendorName"].ToString(), r["VendorID"].ToString()));
            }
            catch { }
        }

        private void LoadSources()
        {
            ddlSource.Items.Clear();
            ddlSource.Items.Add(new ListItem("-- Select --", ""));
            DataTable dt;
            switch (ddlType.SelectedValue)
            {
                case "OPEX": dt = MastersDAL.GetOpex(); break;
                case "AMC":  dt = MastersDAL.GetAmc();  break;
                default:     dt = MastersDAL.GetCapex(); break;
            }
            foreach (DataRow r in dt.Rows)
            {
                string id = r[0].ToString();
                string d  = r["Description"].ToString();
                ddlSource.Items.Add(new ListItem(id + " - " + (d.Length > 80 ? d.Substring(0, 80) : d), id));
            }
        }

        private void BindBudgetGrid()
        {
            string sel = ddlSource.SelectedValue;
            if (string.IsNullOrEmpty(sel)) { pnlBudget.Visible = false; return; }
            DataRow row;
            switch (ddlType.SelectedValue)
            {
                case "OPEX": row = MastersDAL.GetOpexById(sel); break;
                case "AMC":  row = MastersDAL.GetAmcById(sel);  break;
                default:     row = MastersDAL.GetCapexById(sel); break;
            }
            if (row == null) { pnlBudget.Visible = false; return; }
            bBudget.Text = FormatMoney(row, "Budget");
            bUtil.Text   = FormatMoney(row, "Utilization");
            bAvail.Text  = FormatMoney(row, "AvailableBudget");
            bLock.Text   = FormatMoney(row, "LockedAmount");
            bNet.Text    = FormatMoney(row, "NetBalance");
            pnlBudget.Visible = true;
        }
        private string FormatMoney(DataRow r, string c)
        {
            if (!r.Table.Columns.Contains(c) || r[c] == DBNull.Value) return "0.00";
            return Convert.ToDecimal(r[c]).ToString("N2");
        }

        // ===== Stepper (Req 29-30) =====
        private void BuildStepper(DataRow prj)
        {
            string[] stages = new[] { "Project", "PET", "PET Approval", "BPM" };
            // Obs 1: Compute stage index first so "Pending" DB-default labels are not shown
            // for steps that have not yet been reached.
            string key = CurrentStageKey;
            int curIx = 0;
            switch (key)
            {
                case "Project":     curIx = 0; break;
                case "PET":         curIx = 1; break;
                case "PETApproval": curIx = 2; break;
                case "BPM":         curIx = 3; break;
                case "Closed":      curIx = 4; break;
            }
            string rawPetStage = prj != null && prj.Table.Columns.Contains("PetStageStatus")    && prj["PetStageStatus"]    != DBNull.Value ? prj["PetStageStatus"].ToString()    : "";
            string rawPetAppr  = prj != null && prj.Table.Columns.Contains("PetApprovalStatus") && prj["PetApprovalStatus"] != DBNull.Value ? prj["PetApprovalStatus"].ToString() : "";
            string rawBpmStat  = prj != null && prj.Table.Columns.Contains("BpmStageStatus")    && prj["BpmStageStatus"]    != DBNull.Value ? prj["BpmStageStatus"].ToString()    : "";
            // If the DB default 'Pending' is present but the stage has not yet been reached, display "Not Started".
            string petStepLabel = string.IsNullOrEmpty(rawPetStage) ? "Not Started"
                : (string.Equals(rawPetStage, "Pending", StringComparison.OrdinalIgnoreCase) && curIx < 1) ? "Not Started" : rawPetStage;
            string petApprLabel = string.IsNullOrEmpty(rawPetAppr) ? "Not Started"
                : (string.Equals(rawPetAppr, "Pending", StringComparison.OrdinalIgnoreCase) && curIx < 2) ? "Not Started" : rawPetAppr;
            string bpmLabel     = string.IsNullOrEmpty(rawBpmStat) ? "Not Started"
                : (string.Equals(rawBpmStat, "Pending", StringComparison.OrdinalIgnoreCase) && curIx < 3) ? "Not Started" : rawBpmStat;
            string[] sub = new[] {
                prj != null ? "OK" : "Draft",
                petStepLabel,
                petApprLabel,
                bpmLabel
            };
            var sb = new StringBuilder();
            for (int i = 0; i < stages.Length; i++)
            {
                string cls = i < curIx ? "done" : (i == curIx ? "active" : "pending");
                sb.AppendFormat("<div class='step {0}'><div class='step-num'>{1}</div>", cls, i + 1);
                sb.AppendFormat("<div class='step-label'>{0}</div>", Server.HtmlEncode(stages[i]));
                sb.AppendFormat("<div class='step-sub'>{0}</div></div>", Server.HtmlEncode(sub[i]));
                if (i < stages.Length - 1)
                {
                    string lineCls = i < curIx ? "step-line done" : "step-line";
                    sb.AppendFormat("<div class='{0}'></div>", lineCls);
                }
            }
            litStepper.Text = sb.ToString();
        }

        // ===== PROJECT actions =====
        protected void btnSaveProject_Click(object sender, EventArgs e) { SaveProject("Draft", false); }
        protected void btnSubmitProject_Click(object sender, EventArgs e) { SaveProject("Pending", true); }

        private void SaveProject(string status, bool advanceToPet)
        {
            string user = AuthHelper.CurrentUser;
            int approverId = 0; int.TryParse(ddlApprover.SelectedValue, out approverId);

            if (CurrentProjectId == 0 && !string.IsNullOrEmpty(ddlJira.SelectedValue))
            {
                DataRow existing = Db.QueryRow(
                    "SELECT TOP 1 ProjectID FROM Projects WHERE JiraID=@j ORDER BY ProjectID DESC",
                    Db.P("@j", ddlJira.SelectedValue));
                if (existing != null) CurrentProjectId = Convert.ToInt32(existing["ProjectID"]);
            }

            if (CurrentProjectId == 0)
            {
                CurrentProjectId = ProjectsDAL.CreateProject(ddlJira.SelectedValue, txtName.Text.Trim(),
                    ddlType.SelectedValue, ddlSource.SelectedValue, 0m, approverId, null, null, user, status);
                ProjectsDAL.AddWorkflow(CurrentProjectId,
                    status == "Pending" ? "Submitted" : "Draft", null, user, "Project saved", 1);
                Db.Exec("UPDATE Projects SET CurrentStage=@cs, CapexStageStatus=@css WHERE ProjectID=@id",
                    Db.P("@cs", advanceToPet ? "PET" : "Registration"),
                    Db.P("@css", advanceToPet ? "Approved" : "Pending"),
                    Db.P("@id", CurrentProjectId));
            }
            else
            {
                ProjectsDAL.UpdateProject(CurrentProjectId, txtName.Text.Trim(),
                    ddlSource.SelectedValue, 0m, approverId, null, null, user);
                if (advanceToPet)
                    Db.Exec("UPDATE Projects SET CurrentStage='PET', CapexStageStatus='Approved' WHERE ProjectID=@id",
                        Db.P("@id", CurrentProjectId));
                else
                {
                    // No additional update needed for draft save
                }
                ProjectsDAL.AddWorkflow(CurrentProjectId, "Modified", null, user, "Project details updated", 1);
            }

            // Refresh in-place
            LoadProject(CurrentProjectId);
            if (advanceToPet)
                ShowNotify("success", "Project Submitted",
                    "Project submitted successfully. Workflow moved to PET stage.");
            else
                ShowNotify("success", "Draft Saved", "Project draft saved successfully.");
        }

        // ===== PET section =====
        private void BindPet(int pid)
        {
            DataTable dt = PetDAL.GetByProject(pid);
            gvPet.DataSource = dt;
            gvPet.DataBind();
            litPetTotal.Text = PetDAL.GetTotalForProject(pid).ToString("N2");

            // Req 6: check whether any line items are unversioned (new, not yet submitted)
            object unver = Db.Scalar(
                "SELECT COUNT(*) FROM PetForm WHERE ProjectID=@p AND PetVersion IS NULL",
                Db.P("@p", pid));
            HasUnsubmittedPet = unver != null && unver != DBNull.Value && Convert.ToInt32(unver) > 0;
        }

        protected void btnAddPet_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0) { ShowNotify("warning", "Save Project First", "Please save the project before adding PET line items."); return; }

            string user = AuthHelper.CurrentUser;
            decimal units = 0, price = 0;
            decimal.TryParse(txtUnits.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out units);
            decimal.TryParse(txtUnitPrice.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out price);
            string ccy = string.IsNullOrEmpty(ddlCurrency.SelectedValue) ? "AED" : ddlCurrency.SelectedValue;
            decimal rate = PetDAL.GetRate(ccy);
            decimal amtFcy = units * price;
            decimal amtLcy = amtFcy * rate;   // Convert to AED (base currency)

            int editId = 0; int.TryParse(hfEditPetId.Value, out editId);

            if (editId > 0)
            {
                DataRow existing = PetDAL.GetById(editId);
                string lineCode = existing != null && existing["LineCode"] != DBNull.Value
                    ? existing["LineCode"].ToString()
                    : PetDAL.NextLineCode(ddlDept.SelectedValue ?? "");
                PetDAL.Update(editId, ddlDept.SelectedValue, lineCode, ddlExpHead.SelectedValue,
                    txtTopic.Text, txtVendor.Text, txtDesc.Text, ddlCostType.SelectedValue, "Lump Sum",
                    units, price, ccy, amtFcy, amtLcy, 0m, amtLcy, 1, null);
                lblMsg.Visible = true; lblMsg.Text = "Line item updated.";
            }
            else
            {
                string lineCode = PetDAL.NextLineCode(ddlDept.SelectedValue ?? "");
                PetDAL.Add(CurrentProjectId, ddlDept.SelectedValue, lineCode, ddlExpHead.SelectedValue,
                    txtTopic.Text, txtVendor.Text, txtDesc.Text, ddlCostType.SelectedValue, "Lump Sum",
                    units, price, ccy, amtFcy, amtLcy, 0m, amtLcy, 1, null, user);
            }

            ResetPetForm();
            BindPet(CurrentProjectId);
            txtPetTotal.Text = PetDAL.GetTotalForProject(CurrentProjectId).ToString("F2", CultureInfo.InvariantCulture);
        }

        protected void btnCancelEdit_Click(object sender, EventArgs e)
        {
            ResetPetForm();
        }

        private void ResetPetForm()
        {
            hfEditPetId.Value = "0";
            txtTopic.Text = ""; txtVendor.Text = ""; txtDesc.Text = "";
            txtUnits.Text = "1"; txtUnitPrice.Text = "";
            txtAmtFcy.Text = ""; txtAmtAed.Text = "";
            ddlDept.SelectedIndex = 0;
            ddlCostType.SelectedIndex = 0;
            ddlExpHead.SelectedIndex = 0;
            if (ddlCurrency.Items.FindByValue("AED") != null) ddlCurrency.SelectedValue = "AED";
            btnAddPet.Visible    = true;
            btnUpdatePet.Visible = false;
            btnCancelEdit.Visible = false;
        }

        protected void gvPet_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DelPet")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                PetDAL.Delete(id);
                BindPet(CurrentProjectId);
                txtPetTotal.Text = PetDAL.GetTotalForProject(CurrentProjectId).ToString("F2", CultureInfo.InvariantCulture);
                if (hfEditPetId.Value == id.ToString()) ResetPetForm();
            }
            else if (e.CommandName == "SavePetRow")
            {
                int id;
                if (!int.TryParse(e.CommandArgument?.ToString(), out id)) return;
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
                string dept      = ((TextBox)row.FindControl("txtGvDept")).Text.Trim();
                string costType  = ((TextBox)row.FindControl("txtGvCostType")).Text.Trim();
                string topic     = ((TextBox)row.FindControl("txtGvTopic")).Text.Trim();
                string vendor    = ((TextBox)row.FindControl("txtGvVendor")).Text.Trim();
                decimal units = 0m, unitPrice = 0m;
                decimal.TryParse(((TextBox)row.FindControl("txtGvUnits")).Text.Replace(",", ""), System.Globalization.NumberStyles.Any, CultureInfo.InvariantCulture, out units);
                decimal.TryParse(((TextBox)row.FindControl("txtGvUnitPrice")).Text.Replace(",", ""), System.Globalization.NumberStyles.Any, CultureInfo.InvariantCulture, out unitPrice);
                string ccy = ((TextBox)row.FindControl("txtGvCcy")).Text.Trim();
                if (string.IsNullOrEmpty(ccy)) ccy = "AED";
                decimal rate = PetDAL.GetRate(ccy);
                decimal fcy  = units * unitPrice;
                decimal aed  = fcy * rate;
                DataRow existing = PetDAL.GetById(id);
                if (existing == null) return;
                PetDAL.Update(id, dept,
                    SafeStr(existing, "LineCode"),
                    SafeStr(existing, "ExpHead"),
                    topic, vendor,
                    SafeStr(existing, "Description"),
                    costType,
                    SafeStr(existing, "UnitType"),
                    units, unitPrice, ccy, fcy, aed,
                    existing["ContingencyPct"] == DBNull.Value ? 0m : Convert.ToDecimal(existing["ContingencyPct"]),
                    aed,
                    existing["YearlyRecurrence"] == DBNull.Value ? 0 : Convert.ToInt32(existing["YearlyRecurrence"]),
                    SafeStr(existing, "Comments"));
                BindPet(CurrentProjectId);
                txtPetTotal.Text = PetDAL.GetTotalForProject(CurrentProjectId).ToString("F2", CultureInfo.InvariantCulture);
                ShowNotify("success", "Saved", "Line item updated.");
            }
            else if (e.CommandName == "EditPet")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                DataRow r = PetDAL.GetById(id);
                if (r == null) return;
                hfEditPetId.Value = id.ToString();
                if (r["Department"] != DBNull.Value)
                {
                    string d = r["Department"].ToString();
                    if (ddlDept.Items.FindByValue(d) != null) ddlDept.SelectedValue = d;
                }
                if (r["CostType"] != DBNull.Value)
                {
                    string c = r["CostType"].ToString();
                    if (ddlCostType.Items.FindByValue(c) != null) ddlCostType.SelectedValue = c;
                }
                if (r["ExpHead"] != DBNull.Value && ddlExpHead.Items.FindByValue(r["ExpHead"].ToString()) != null)
                    ddlExpHead.SelectedValue = r["ExpHead"].ToString();
                txtTopic.Text  = SafeStr(r, "Topic");
                txtVendor.Text = SafeStr(r, "Vendor");
                txtDesc.Text   = SafeStr(r, "Description");
                txtUnits.Text     = r["Units"]     == DBNull.Value ? "1" : Convert.ToDecimal(r["Units"]).ToString("F2", CultureInfo.InvariantCulture);
                txtUnitPrice.Text = r["UnitPrice"] == DBNull.Value ? ""  : Convert.ToDecimal(r["UnitPrice"]).ToString("F2", CultureInfo.InvariantCulture);
                string ccy = SafeStr(r, "BaseCurrency");
                if (!string.IsNullOrEmpty(ccy) && ddlCurrency.Items.FindByValue(ccy) != null)
                    ddlCurrency.SelectedValue = ccy;
                txtAmtFcy.Text = r["AmtFCY"]      == DBNull.Value ? "" : Convert.ToDecimal(r["AmtFCY"]).ToString("F2", CultureInfo.InvariantCulture);
                txtAmtAed.Text = r["FinalAmtLCY"] == DBNull.Value ? "" : Convert.ToDecimal(r["FinalAmtLCY"]).ToString("F2", CultureInfo.InvariantCulture);

                btnAddPet.Visible    = false;
                btnUpdatePet.Visible = true;
                btnCancelEdit.Visible = true;
                lblMsg.Visible = true; lblMsg.Text = "Editing line #" + (r["SerialNo"] == DBNull.Value ? id.ToString() : r["SerialNo"].ToString()) + ". Make changes and click Update.";
            }
        }

        // Highlight the row currently being edited
        protected void gvPet_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            int editId; if (!int.TryParse(hfEditPetId.Value, out editId) || editId == 0) return;
            int rowId = Convert.ToInt32(gvPet.DataKeys[e.Row.RowIndex].Value);
            if (rowId == editId) e.Row.CssClass = (e.Row.CssClass ?? "") + " pet-row-editing";
        }

        // Req 5: Pagination for PET line items grid.
        protected void gvPet_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvPet.PageIndex = e.NewPageIndex;
            if (CurrentProjectId > 0)
            {
                BindPet(CurrentProjectId);
                txtPetTotal.Text = PetDAL.GetTotalForProject(CurrentProjectId).ToString("F2", CultureInfo.InvariantCulture);
            }
        }

        protected void btnSubmitPet_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0) return;
            string user = AuthHelper.CurrentUser;
            DataRow prj = ProjectsDAL.GetProject(CurrentProjectId);
            int v = prj["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prj["Version"]);

            // Get next submission version (Req 4)
            int nextVersion = PetDAL.GetNextSubmissionVersion(CurrentProjectId);
            PetDAL.CreateSubmission(CurrentProjectId, nextVersion, user);

            // Tag all unsubmitted (NULL version) PET items with the new version
            Db.Exec("UPDATE PetForm SET PetVersion=@nv WHERE ProjectID=@id AND PetVersion IS NULL",
                Db.P("@nv", nextVersion), Db.P("@id", CurrentProjectId));

            // Advance stage to PET Approval (keeps BPM active if already there).
            // Obs 1: Explicitly set PetApprovalStatus='Pending' so the banner only shows after submission.
            Db.Exec(@"UPDATE Projects SET PetStageStatus='Submitted', PetApprovalStatus='Pending',
                      CurrentStage='PET Approval' WHERE ProjectID=@id",
                Db.P("@id", CurrentProjectId));
            ProjectsDAL.AddWorkflow(CurrentProjectId, "PET Submitted", null, user,
                string.Format("PET v{0} submitted for approval", nextVersion), v);

            int approverId = 0;
            if (prj["ApproverID"] != DBNull.Value) approverId = Convert.ToInt32(prj["ApproverID"]);
            if (approverId > 0)
            {
                DataRow ar = Db.QueryRow("SELECT ApproverName, Email FROM ApproverMaster WHERE ApproverID=@id",
                    Db.P("@id", approverId));
                if (ar != null)
                {
                    NotificationsDAL.Send(ar["ApproverName"].ToString(), "PET approval requested",
                        string.Format("Project {0} — PET v{1} needs approval.", prj["ProjectName"], nextVersion),
                        "~/Forms/Workflow.aspx?id=" + CurrentProjectId,
                        CurrentProjectId, "PETRequest");
                }
            }
            LoadProject(CurrentProjectId);
            ShowNotify("success", "PET Submitted",
                string.Format("PET v{0} submitted for approval. Workflow moved to PET Approver.", nextVersion));
        }

        // ===== PET CSV download/template/upload =====
        protected void btnPetDownload_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0) return;
            DataTable dt = PetDAL.GetByProject(CurrentProjectId);
            var sb = new StringBuilder();
            sb.AppendLine("SerialNo,Department,LineCode,ExpHead,Topic,Vendor,Description,CostType,UnitType,Units,UnitPrice,BaseCurrency,AmtFCY,AmtLCY,FinalAmtLCY,YearlyRecurrence,Comments");
            foreach (DataRow r in dt.Rows)
            {
                sb.AppendFormat("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16}{17}",
                    r["SerialNo"], CsvEsc(r["Department"]), CsvEsc(r["LineCode"]), CsvEsc(r["ExpHead"]),
                    CsvEsc(r["Topic"]), CsvEsc(r["Vendor"]), CsvEsc(r["Description"]),
                    CsvEsc(r["CostType"]), CsvEsc(r["UnitType"]),
                    Money(r["Units"]), Money(r["UnitPrice"]), CsvEsc(r["BaseCurrency"]),
                    Money(r["AmtFCY"]), Money(r["AmtLCY"]), Money(r["FinalAmtLCY"]),
                    r["YearlyRecurrence"], CsvEsc(r["Comments"]), Environment.NewLine);
            }
            WriteCsv("PET_" + CurrentProjectId + ".csv", sb.ToString());
        }

        protected void btnPetTemplate_Click(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            sb.AppendLine("SerialNo,Department,LineCode,ExpHead,Topic,Vendor,Description,CostType,UnitType,Units,UnitPrice,BaseCurrency,AmtFCY,AmtLCY,FinalAmtLCY,YearlyRecurrence,Comments");
            sb.AppendLine("1,IT,IT - 1,Capex,Sample Topic,Sample Vendor,Sample description,Hardware,Lump Sum,1,1000,AED,1000,1000,1000,1,");
            WriteCsv("PET_Template.csv", sb.ToString());
        }

        private void WriteCsv(string fileName, string content)
        {
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.Write(content);
            Response.End();
        }
        private string CsvEsc(object o)
        {
            if (o == null || o == DBNull.Value) return "";
            string s = o.ToString();
            if (s.Contains(",") || s.Contains("\"") || s.Contains("\n"))
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }
        private string Money(object o)
        {
            if (o == null || o == DBNull.Value) return "0";
            return Convert.ToDecimal(o).ToString("F2", CultureInfo.InvariantCulture);
        }

        protected void btnPetUpload_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0) { ShowNotify("warning", "Save Project First", "Please save the project before uploading PET."); return; }
            if (!fuPetCsv.HasFile) { ShowNotify("warning", "No File Selected", "Please select a CSV file to upload."); return; }
            string posted = Request.Form["petUploadMode"];
            string mode = string.Equals(posted, "Delete", StringComparison.OrdinalIgnoreCase) ? "Delete" : "Retain";
            string user = AuthHelper.CurrentUser;
            int n = 0;

            using (var sr = new StreamReader(fuPetCsv.PostedFile.InputStream))
            {
                if (mode == "Delete")
                    Db.Exec("DELETE FROM PetForm WHERE ProjectID=@id", Db.P("@id", CurrentProjectId));

                sr.ReadLine(); // header
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var f = CsvImporter.ParseCsvLine(line);
                    while (f.Count < 17) f.Add("");
                    PetDAL.Add(CurrentProjectId,
                        f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8],
                        CsvImporter.ParseDecimal(f[9]),
                        CsvImporter.ParseDecimal(f[10]),
                        f[11],
                        CsvImporter.ParseDecimal(f[12]),
                        CsvImporter.ParseDecimal(f[13]),
                        0m,
                        CsvImporter.ParseDecimal(f[14]),
                        ParseInt(f[15], 1),
                        f[16], user);
                    n++;
                }
            }
            BindPet(CurrentProjectId);
            ShowNotify("success", "Upload Complete",
                string.Format("{0} PET line items uploaded successfully ({1} mode).", n, mode));
        }
        private int ParseInt(string s, int def)
        {
            int v; return int.TryParse(s, out v) ? v : def;
        }

        // ===== PET Approval =====
        protected void btnApprovePet_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "PETApproval") return;
            if (!IsAssignedApprover())
            {
                ShowNotify("error", "Access Denied", "You are not the assigned approver for this project.");
                return;
            }
            decimal amt = 0m;
            decimal.TryParse(txtApprovedAmount.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
            // Approve current pending submission
            DataRow pending = PetDAL.GetPendingSubmission(CurrentProjectId);
            if (pending != null)
                PetDAL.ApproveSubmission(CurrentProjectId, Convert.ToInt32(pending["PetVersion"]),
                    amt, AuthHelper.CurrentUser, txtApproveComment.Value);
            WorkflowDAL.ApprovePet(CurrentProjectId, amt, AuthHelper.CurrentUser, txtApproveComment.Value);
            // Auto-refresh: show notify, then reload page after 1.5s to reflect new state
            int redirectPid = CurrentProjectId;
            ShowNotify("success", "PET Approved", "PET has been approved. BPM (Memo) section is now active.");
            ScriptManager.RegisterStartupScript(this, GetType(), "approvalRefresh",
                "setTimeout(function(){ window.location.href = window.location.pathname + '?id=" + redirectPid + "'; }, 1800);", true);
        }
        protected void btnRejectPet_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "PETApproval") return;
            if (!IsAssignedApprover())
            {
                ShowNotify("error", "Access Denied", "You are not the assigned approver for this project.");
                return;
            }
            DataRow pending = PetDAL.GetPendingSubmission(CurrentProjectId);
            if (pending != null)
                PetDAL.RejectSubmission(CurrentProjectId, Convert.ToInt32(pending["PetVersion"]),
                    AuthHelper.CurrentUser, txtApproveComment.Value);
            WorkflowDAL.RejectPet(CurrentProjectId, AuthHelper.CurrentUser, txtApproveComment.Value);
            int redirectPid = CurrentProjectId;
            ShowNotify("warning", "PET Rejected", "PET has been rejected. Workflow returned to Project stage.");
            ScriptManager.RegisterStartupScript(this, GetType(), "rejectionRefresh",
                "setTimeout(function(){ window.location.href = window.location.pathname + '?id=" + redirectPid + "'; }, 1800);", true);
        }

        private bool IsAssignedApprover()
        {
            try
            {
                DataRow prj = ProjectsDAL.GetProject(CurrentProjectId);
                if (prj == null || prj["ApproverID"] == DBNull.Value) return false;
                int approverId = Convert.ToInt32(prj["ApproverID"]);
                DataRow approver = Db.QueryRow(
                    "SELECT ApproverName, Email, Username FROM ApproverMaster WHERE ApproverID=@id",
                    Db.P("@id", approverId));
                if (approver == null) return false;

                string loginUsername = AuthHelper.CurrentUser;  // Session["Username"]
                string loginEmail    = (System.Web.HttpContext.Current.Session["Email"]    as string) ?? "";
                string loginFullName = (System.Web.HttpContext.Current.Session["FullName"] as string) ?? "";

                string apprUsername = approver.Table.Columns.Contains("Username") && approver["Username"] != DBNull.Value
                    ? approver["Username"].ToString() : "";
                string apprEmail    = approver["Email"] == DBNull.Value ? "" : approver["Email"].ToString();
                string apprName     = approver["ApproverName"].ToString();

                // Priority 1: explicit Username link (set in ApproverMaster admin)
                if (!string.IsNullOrEmpty(apprUsername) &&
                    string.Equals(apprUsername, loginUsername, StringComparison.OrdinalIgnoreCase))
                    return true;

                // Priority 2: email match
                if (!string.IsNullOrEmpty(apprEmail) && !string.IsNullOrEmpty(loginEmail) &&
                    string.Equals(apprEmail, loginEmail, StringComparison.OrdinalIgnoreCase))
                    return true;

                // Priority 3: full-name match (Session["FullName"] vs ApproverName)
                if (!string.IsNullOrEmpty(loginFullName) &&
                    string.Equals(apprName, loginFullName, StringComparison.OrdinalIgnoreCase))
                    return true;

                // Priority 4: legacy - ApproverName vs login username (backward compat)
                if (string.Equals(apprName, loginUsername, StringComparison.OrdinalIgnoreCase))
                    return true;

                // Priority 5: some systems use email as the login username
                if (!string.IsNullOrEmpty(apprEmail) &&
                    string.Equals(apprEmail, loginUsername, StringComparison.OrdinalIgnoreCase))
                    return true;

                return false;
            }
            catch { return false; }
        }

        // ===== INTERNAL MEMO / CAM (BPM section) =====

        private void BindMemos(int pid)
        {
            DataTable dt = MemoDAL.GetByProject(pid);
            gvMemos.DataSource = dt;
            gvMemos.DataBind();

            // After data-bind, inject invoice sub-rows for tree structure (CAM ↔ Invoice)
            if (gvMemos.Rows.Count > 0)
            {
                // Pre-fetch all invoices for this project at once (avoids N+1 queries)
                DataTable allInv = Db.Query(
                    @"SELECT i.*, m.MemoID AS ParentMemoID FROM MemoInvoices i
                      INNER JOIN CapexMemos m ON i.MemoID = m.MemoID
                      WHERE m.ProjectID=@p ORDER BY i.MemoID, i.InvoiceID",
                    Db.P("@p", pid));

                var tbl = (System.Web.UI.WebControls.Table)gvMemos.Controls[0];
                int colCount = gvMemos.Columns.Count;

                // Loop in REVERSE so earlier-row insertions don't shift indices
                for (int i = gvMemos.Rows.Count - 1; i >= 0; i--)
                {
                    int memoId = (int)gvMemos.DataKeys[i].Value;
                    DataRow[] invRows = allInv != null
                        ? allInv.Select("ParentMemoID=" + memoId)
                        : new DataRow[0];

                    // Build the invoice sub-row HTML
                    var sbInv = new StringBuilder();
                    sbInv.AppendFormat("<div class='inv-sub-panel' id='inv_sub_{0}' style='display:none;'>", memoId);
                    if (invRows.Length == 0)
                    {
                        sbInv.Append("<p class='text-muted' style='padding:6px 12px;font-size:.83em;'>No invoices recorded for this CAM yet.</p>");
                    }
                    else
                    {
                        sbInv.Append("<table class='inv-sub-table'><thead><tr>");
                        sbInv.Append("<th>Inv Memo#</th><th>Invoice#</th><th class='text-right'>Amount (AED)</th><th>Invoice Date</th><th>Entry Date</th><th>Status</th>");
                        sbInv.Append("</tr></thead><tbody>");
                        foreach (DataRow ir in invRows)
                        {
                            string istatus = ir["InvoiceStatus"].ToString();
                            string statusCss = string.Equals(istatus, "Paid", StringComparison.OrdinalIgnoreCase) ? "vtbl-approved"
                                : string.Equals(istatus, "Rejected", StringComparison.OrdinalIgnoreCase) ? "vtbl-rejected" : "vtbl-pending";
                            string invDate  = ir["InvoiceDate"]      == DBNull.Value ? "" : Convert.ToDateTime(ir["InvoiceDate"]).ToString("dd-MMM-yy");
                            string entDate  = ir["InvoiceEntryDate"] == DBNull.Value ? "" : Convert.ToDateTime(ir["InvoiceEntryDate"]).ToString("dd-MMM-yy");
                            decimal iamt    = ir["InvoiceAmountAED"] == DBNull.Value ? 0m : Convert.ToDecimal(ir["InvoiceAmountAED"]);
                            sbInv.AppendFormat("<tr><td>{0}</td><td><strong>{1}</strong></td><td class='text-right'>{2}</td><td>{3}</td><td>{4}</td>",
                                Server.HtmlEncode(ir["InvoiceMemoNumber"].ToString()),
                                Server.HtmlEncode(ir["InvoiceNumber"].ToString()),
                                iamt.ToString("N2"),
                                invDate, entDate);
                            sbInv.AppendFormat("<td><span class='pet-vtbl-badge {0}'>{1}</span></td></tr>", statusCss, Server.HtmlEncode(istatus));
                        }
                        sbInv.Append("</tbody></table>");
                    }
                    sbInv.Append("</div>");

                    // Create a new table sub-row spanning all columns
                    var subRow = new System.Web.UI.WebControls.GridViewRow(
                        -1, -1, System.Web.UI.WebControls.DataControlRowType.DataRow,
                        System.Web.UI.WebControls.DataControlRowState.Normal);
                    subRow.CssClass = "memo-inv-subrow";
                    var td = new System.Web.UI.WebControls.TableCell();
                    td.ColumnSpan = colCount;
                    td.Style["padding"] = "0";
                    td.Controls.Add(new System.Web.UI.LiteralControl(sbInv.ToString()));
                    subRow.Cells.Add(td);

                    // Insert immediately after the CAM row (+1 for header, +1 to go after it)
                    tbl.Rows.AddAt(i + 2, subRow);
                }
            }
        }

        private void BindInvoices(int memoId)
        {
            DataTable dt = MemoDAL.GetInvoices(memoId);
            gvInvoices.DataSource = dt;
            gvInvoices.DataBind();
            ShowSettlementSummary(memoId);
        }

        private void ShowSettlementSummary(int memoId)
        {
            DataTable st = MemoDAL.GetSettlementSummary(CurrentProjectId);
            if (st == null || st.Rows.Count == 0) return;
            decimal lpo = 0m, dis = 0m;
            foreach (DataRow s in st.Rows)
            {
                lpo += s["TotalLPOAmount"] == DBNull.Value ? 0m : Convert.ToDecimal(s["TotalLPOAmount"]);
                dis += s["AmountDisbursed"] == DBNull.Value ? 0m : Convert.ToDecimal(s["AmountDisbursed"]);
            }
            decimal pen = lpo - dis;
            decimal pctU = lpo > 0 ? (dis / lpo * 100) : 0;
            decimal pctR = 100 - pctU;
            litMemoLPOTotal.Text  = lpo.ToString("N2");
            litMemoDisbursed.Text = dis.ToString("N2");
            litMemoPending.Text   = pen.ToString("N2");
            litMemoPctUtil.Text   = pctU.ToString("F1");
            litMemoPctRem.Text    = pctR.ToString("F1");
        }

        protected void btnAddMemo_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "BPM") return;
            decimal amt = 0m;
            decimal.TryParse(txtMemoAmount.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
            int vendorId = 0; int.TryParse(ddlMemoVendor.SelectedValue, out vendorId);
            DateTime dt; DateTime? raised = null, poDate = null;
            if (DateTime.TryParse(txtMemoDateRaised.Text, out dt)) raised = dt;
            if (DateTime.TryParse(txtMemoPODate.Text, out dt)) poDate = dt;

            int editId = 0; int.TryParse(hfEditMemoId.Value, out editId);
            if (editId > 0)
            {
                MemoDAL.Update(editId, txtMemoNumber.Text.Trim(), amt, vendorId,
                    raised, txtMemoLPO.Text.Trim(), poDate, txtMemoAMS.Text.Trim(),
                    "Open", txtMemoDesc.Text.Trim(), ddlGL.SelectedValue);
                hfEditMemoId.Value = "0";
            }
            else
            {
                MemoDAL.Create(CurrentProjectId, txtMemoNumber.Text.Trim(), amt, vendorId,
                    raised, txtMemoLPO.Text.Trim(), poDate, txtMemoAMS.Text.Trim(),
                    txtMemoDesc.Text.Trim(), 1, AuthHelper.CurrentUser, ddlGL.SelectedValue);
            }
            ClearMemoForm();
            BindMemos(CurrentProjectId);
            ShowNotify("success", editId > 0 ? "Memo Updated" : "Memo Created",
                editId > 0 ? "Internal memo updated successfully." : "Internal memo created successfully.");
        }

        protected void btnCancelMemoEdit_Click(object sender, EventArgs e)
        {
            ClearMemoForm();
        }

        private void ClearMemoForm()
        {
            txtMemoNumber.Text = ""; txtMemoAmount.Text = ""; ddlMemoVendor.SelectedIndex = 0;
            txtMemoDateRaised.Text = ""; txtMemoLPO.Text = ""; txtMemoPODate.Text = "";
            txtMemoAMS.Text = ""; txtMemoDesc.Text = ""; hfEditMemoId.Value = "0";
        }

        protected void gvMemos_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id;
            if (!int.TryParse(e.CommandArgument?.ToString(), out id)) return;
            if (e.CommandName == "ViewInvoices")
            {
                hfSelectedMemoId.Value = id.ToString();
                DataRow memo = MemoDAL.GetById(id);
                string memoNum = memo != null ? memo["MemoNumber"].ToString() : "";
                litInvoiceMemoRef.Text = Server.HtmlEncode(string.IsNullOrEmpty(memoNum) ? id.ToString() : memoNum);
                // Req 5: auto-populate Invoice Memo# field with parent Memo#
                txtInvMemoNum.Text = memoNum;
                pnlInvoices.Visible = true;
                BindInvoices(id);
            }
            else if (e.CommandName == "EditMemo")
            {
                DataRow memo = MemoDAL.GetById(id);
                if (memo != null)
                {
                    txtMemoNumber.Text    = memo["MemoNumber"]  == DBNull.Value ? "" : memo["MemoNumber"].ToString();
                    txtMemoAmount.Text    = memo["ApprovedAmountAED"] == DBNull.Value ? "" : Convert.ToDecimal(memo["ApprovedAmountAED"]).ToString("F2", CultureInfo.InvariantCulture);
                    txtMemoDateRaised.Text= memo["DateRaised"]  == DBNull.Value ? "" : Convert.ToDateTime(memo["DateRaised"]).ToString("yyyy-MM-dd");
                    txtMemoLPO.Text       = memo["LPO_SO_Number"]== DBNull.Value ? "" : memo["LPO_SO_Number"].ToString();
                    txtMemoPODate.Text    = memo["PODate"]       == DBNull.Value ? "" : Convert.ToDateTime(memo["PODate"]).ToString("yyyy-MM-dd");
                    txtMemoAMS.Text       = memo["AMS_Number"]   == DBNull.Value ? "" : memo["AMS_Number"].ToString();
                    txtMemoDesc.Text      = memo["Description"]  == DBNull.Value ? "" : memo["Description"].ToString();
                    string glCode = memo["GLCode"] == DBNull.Value ? "" : memo["GLCode"].ToString();
                    if (!string.IsNullOrEmpty(glCode))
                    {
                        ListItem li = ddlGL.Items.FindByValue(glCode);
                        if (li != null) ddlGL.SelectedValue = glCode;
                    }
                    int vid = memo["VendorID"] == DBNull.Value ? 0 : Convert.ToInt32(memo["VendorID"]);
                    ListItem vli = ddlMemoVendor.Items.FindByValue(vid.ToString());
                    if (vli != null) ddlMemoVendor.SelectedValue = vid.ToString();
                    hfEditMemoId.Value = id.ToString();
                    // Force the BPM accordion open so user sees the edit form
                    ScriptManager.RegisterStartupScript(this, GetType(), "openBpmAcc",
                        "$(function(){ var a=document.getElementById('accBpm'); if(a) a.classList.remove('collapsed'); DFM.syncOpen(); });", true);
                    ShowNotify("info", "Edit CAM", "Memo loaded for editing. Make changes and click <strong>Add Memo</strong> to save.");
                }
            }
            else if (e.CommandName == "CloseMemo")
            {
                Db.Exec("UPDATE CapexMemos SET CAMStatus='Closed', ModifiedDate=GETDATE() WHERE MemoID=@id",
                    Db.P("@id", id));
                BindMemos(CurrentProjectId);
                ShowNotify("info", "CAM Closed", "CAM has been marked as Closed.");
            }
            else if (e.CommandName == "SaveMemoRow")
            {
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
                string memoNum    = ((TextBox)row.FindControl("txtGvMemoNum")).Text.Trim();
                decimal amt = 0m;
                decimal.TryParse(((TextBox)row.FindControl("txtGvMemoAmt")).Text.Replace(",", ""), NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
                string vendorName = ((TextBox)row.FindControl("txtGvMemoVendor")).Text.Trim();
                string dateStr    = ((TextBox)row.FindControl("txtGvMemoDate")).Text.Trim();
                string lpo        = ((TextBox)row.FindControl("txtGvMemoLPO")).Text.Trim();
                string ams        = ((TextBox)row.FindControl("txtGvMemoAMS")).Text.Trim();
                string status     = ((DropDownList)row.FindControl("ddlGvCamStatus")).SelectedValue;
                DateTime dt; DateTime? dateRaised = null;
                if (DateTime.TryParse(dateStr, out dt)) dateRaised = dt;
                int? vendorId = null;
                object vObj = Db.Scalar("SELECT TOP 1 VendorID FROM VendorMaster WHERE VendorName=@n", Db.P("@n", vendorName));
                if (vObj != null && vObj != DBNull.Value) vendorId = Convert.ToInt32(vObj);
                DataRow existing = MemoDAL.GetById(id);
                if (existing == null) return;
                if (!vendorId.HasValue && existing["VendorID"] != DBNull.Value)
                    vendorId = Convert.ToInt32(existing["VendorID"]);
                DateTime? poDate = existing["PODate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(existing["PODate"]);
                string glCode = existing["GLCode"] == DBNull.Value ? null : existing["GLCode"].ToString();
                MemoDAL.Update(id, memoNum, amt, vendorId, dateRaised, lpo, poDate, ams, status,
                    SafeStr(existing, "Description"), glCode);
                BindMemos(CurrentProjectId);
                ShowNotify("success", "Saved", "CAM updated successfully.");
            }
            else if (e.CommandName == "DelMemo")
            {
                MemoDAL.Delete(id);
                BindMemos(CurrentProjectId);
                pnlInvoices.Visible = false;
                hfSelectedMemoId.Value = "0";
                ShowNotify("info", "Memo Deleted", "Memo and its invoices have been removed.");
            }
        }

        protected void btnAddInvoice_Click(object sender, EventArgs e)
        {
            int memoId = 0; int.TryParse(hfSelectedMemoId.Value, out memoId);
            if (memoId == 0 || CurrentStageKey != "BPM") return;

            decimal amt = 0m;
            decimal.TryParse(txtInvAmount.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
            DateTime dt; DateTime? invDate = null, entryDate = null;
            if (DateTime.TryParse(txtInvDate.Text, out dt)) invDate = dt;
            if (DateTime.TryParse(txtInvEntryDate.Text, out dt)) entryDate = dt;

            int editId = 0; int.TryParse(hfEditInvoiceId.Value, out editId);
            try
            {
                if (editId > 0)
                {
                    MemoDAL.UpdateInvoice(editId, txtInvMemoNum.Text.Trim(), txtInvNumber.Text.Trim(),
                        amt, invDate, entryDate, ddlInvStatus.SelectedValue, txtInvDesc.Text.Trim());
                    hfEditInvoiceId.Value = "0";
                }
                else
                {
                    MemoDAL.AddInvoice(memoId, txtInvMemoNum.Text.Trim(), txtInvNumber.Text.Trim(),
                        amt, invDate, entryDate, ddlInvStatus.SelectedValue, txtInvDesc.Text.Trim(), AuthHelper.CurrentUser);
                }
            }
            catch (InvalidOperationException ex)
            {
                lblMsg.Visible = true; lblMsg.CssClass = "alert-danger";
                lblMsg.Text = ex.Message;
                return;
            }
            ClearInvoiceForm();
            BindInvoices(memoId);
            BindMemos(CurrentProjectId);
            ShowNotify("success", "Invoice Saved", "Invoice created successfully.");
        }

        private void ClearInvoiceForm()
        {
            txtInvMemoNum.Text = ""; txtInvNumber.Text = ""; txtInvAmount.Text = "";
            txtInvDate.Text = ""; txtInvEntryDate.Text = ""; ddlInvStatus.SelectedIndex = 0;
            txtInvDesc.Text = ""; hfEditInvoiceId.Value = "0";
        }

        protected void gvInvoices_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditInvoice")
            {
                int invId = Convert.ToInt32(e.CommandArgument);
                DataRow inv = MemoDAL.GetInvoice(invId);
                if (inv != null)
                {
                    txtInvMemoNum.Text    = inv["InvoiceMemoNumber"] == DBNull.Value ? "" : inv["InvoiceMemoNumber"].ToString();
                    txtInvNumber.Text     = inv["InvoiceNumber"]     == DBNull.Value ? "" : inv["InvoiceNumber"].ToString();
                    txtInvAmount.Text     = inv["InvoiceAmountAED"]  == DBNull.Value ? "" : Convert.ToDecimal(inv["InvoiceAmountAED"]).ToString("F2", CultureInfo.InvariantCulture);
                    txtInvDate.Text       = inv["InvoiceDate"]       == DBNull.Value ? "" : Convert.ToDateTime(inv["InvoiceDate"]).ToString("yyyy-MM-dd");
                    txtInvEntryDate.Text  = inv["InvoiceEntryDate"]  == DBNull.Value ? "" : Convert.ToDateTime(inv["InvoiceEntryDate"]).ToString("yyyy-MM-dd");
                    txtInvDesc.Text       = inv["InvoiceDescription"]== DBNull.Value ? "" : inv["InvoiceDescription"].ToString();
                    string st = inv["InvoiceStatus"] == DBNull.Value ? "" : inv["InvoiceStatus"].ToString();
                    if (!string.IsNullOrEmpty(st) && ddlInvStatus.Items.FindByValue(st) != null)
                        ddlInvStatus.SelectedValue = st;
                    hfEditInvoiceId.Value = invId.ToString();
                    pnlInvoices.Visible = true;
                    ScriptManager.RegisterStartupScript(this, GetType(), "openInvAcc",
                        "$(function(){ var a=document.getElementById('accInvoices'); if(a) a.classList.remove('collapsed'); DFM.syncOpen(); });", true);
                    ShowNotify("info", "Edit Invoice", "Invoice loaded for editing.");
                }
            }
            else if (e.CommandName == "SaveInvoiceRow")
            {
                int invId;
                if (!int.TryParse(e.CommandArgument?.ToString(), out invId)) return;
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;
                string invMemoNum   = ((TextBox)row.FindControl("txtGvInvMemoNum")).Text.Trim();
                string invNum       = ((TextBox)row.FindControl("txtGvInvNum")).Text.Trim();
                decimal amt = 0m;
                decimal.TryParse(((TextBox)row.FindControl("txtGvInvAmt")).Text.Replace(",", ""), NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
                string invDateStr   = ((TextBox)row.FindControl("txtGvInvDate")).Text.Trim();
                string entryDateStr = ((TextBox)row.FindControl("txtGvInvEntryDate")).Text.Trim();
                string status       = ((DropDownList)row.FindControl("ddlGvInvStatus")).SelectedValue;
                DateTime dt; DateTime? invDate = null, entryDate = null;
                if (DateTime.TryParse(invDateStr, out dt))   invDate = dt;
                if (DateTime.TryParse(entryDateStr, out dt)) entryDate = dt;
                DataRow inv = MemoDAL.GetInvoice(invId);
                string desc = inv != null && inv["InvoiceDescription"] != DBNull.Value ? inv["InvoiceDescription"].ToString() : "";
                MemoDAL.UpdateInvoice(invId, invMemoNum, invNum, amt, invDate, entryDate, status, desc);
                int memoId = 0;
                if (inv != null) int.TryParse(inv["MemoID"].ToString(), out memoId);
                if (memoId > 0)
                {
                    BindInvoices(memoId);
                    BindMemos(CurrentProjectId);
                }
                ShowNotify("success", "Saved", "Invoice updated successfully.");
            }
            else if (e.CommandName == "DelInvoice")
            {
                int invId = Convert.ToInt32(e.CommandArgument);
                MemoDAL.DeleteInvoice(invId);
                int memoId = 0; int.TryParse(hfSelectedMemoId.Value, out memoId);
                if (memoId > 0)
                {
                    MemoDAL.RecalcMemoTotals(memoId);
                    BindInvoices(memoId);
                }
                BindMemos(CurrentProjectId);
                lblMsg.Visible = true; lblMsg.CssClass = "alert-success";
                ShowNotify("info", "Invoice Deleted", "Invoice has been removed.");
            }
        }

        protected void btnMemoTemplate_Click(object sender, EventArgs e)
        {
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.AddHeader("Content-Disposition", "attachment; filename=MemoTemplate.csv");
            Response.Write("MemoNumber,ApprovedAmountAED,VendorCode,DateRaised,LPO_SO_Number,PODate,AMS_Number,Description\r\n");
            Response.End();
        }

        protected void btnMemoUpload_Click(object sender, EventArgs e)
        {
            if (!fuMemoCsv.HasFile || CurrentProjectId == 0) return;
            string user = AuthHelper.CurrentUser;
            int count = 0;
            using (var sr = new System.IO.StreamReader(fuMemoCsv.PostedFile.InputStream))
            {
                string header = sr.ReadLine(); // skip header
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] cols = line.Split(',');
                    if (cols.Length < 8) continue;
                    decimal amt = 0m; decimal.TryParse(cols[1].Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
                    // Lookup vendor by code
                    int vendorId = 0;
                    DataRow vr = Db.QueryRow("SELECT VendorID FROM VendorMaster WHERE VendorCode=@c", Db.P("@c", cols[2].Trim()));
                    if (vr != null) vendorId = Convert.ToInt32(vr["VendorID"]);
                    DateTime dt; DateTime? raised = null, poDate = null;
                    if (DateTime.TryParse(cols[3].Trim(), out dt)) raised = dt;
                    if (DateTime.TryParse(cols[5].Trim(), out dt)) poDate = dt;
                    MemoDAL.Create(CurrentProjectId, cols[0].Trim(), amt, vendorId,
                        raised, cols[4].Trim(), poDate, cols[6].Trim(), cols[7].Trim(), 1, user);
                    count++;
                }
            }
            BindMemos(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.CssClass = "alert-success";
            lblMsg.Text = count + " memo(s) uploaded.";
        }

        protected void btnInvoiceTemplate_Click(object sender, EventArgs e)
        {
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.AddHeader("Content-Disposition", "attachment; filename=InvoiceTemplate.csv");
            Response.Write("InvoiceMemoNumber,InvoiceNumber,InvoiceAmountAED,InvoiceDate,InvoiceEntryDate,InvoiceStatus,InvoiceDescription\r\n");
            Response.End();
        }

        protected void btnInvoiceUpload_Click(object sender, EventArgs e)
        {
            int memoId = 0; int.TryParse(hfSelectedMemoId.Value, out memoId);
            if (!fuInvoiceCsv.HasFile || memoId == 0) return;
            string user = AuthHelper.CurrentUser;
            int count = 0;
            using (var sr = new System.IO.StreamReader(fuInvoiceCsv.PostedFile.InputStream))
            {
                string header = sr.ReadLine(); // skip header
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] cols = line.Split(',');
                    if (cols.Length < 7) continue;
                    decimal amt = 0m; decimal.TryParse(cols[2].Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
                    DateTime dt; DateTime? invDate = null, entryDate = null;
                    if (DateTime.TryParse(cols[3].Trim(), out dt)) invDate = dt;
                    if (DateTime.TryParse(cols[4].Trim(), out dt)) entryDate = dt;
                    try
                    {
                        MemoDAL.AddInvoice(memoId, cols[0].Trim(), cols[1].Trim(), amt,
                            invDate, entryDate, cols[5].Trim(), cols[6].Trim(), user);
                        count++;
                    }
                    catch (InvalidOperationException) { /* skip rows exceeding LPO limit */ }
                }
            }
            BindInvoices(memoId);
            BindMemos(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.CssClass = "alert-success";
            ShowNotify("success", "Upload Complete", count + " invoice(s) uploaded successfully.");
        }

        protected void btnCloseBpm_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "BPM") return;
            string user = AuthHelper.CurrentUser;

            // Additional requirement: if new PET line items were added during the BPM stage
            // (Step 3 or 4) and have not yet been approved, auto-trigger a PET re-approval
            // workflow before allowing BPM to close (Step 5).
            object unverifiedCount = Db.Scalar(
                "SELECT COUNT(*) FROM PetForm WHERE ProjectID=@p AND PetVersion IS NULL",
                Db.P("@p", CurrentProjectId));
            bool hasNewPetItems = unverifiedCount != null && unverifiedCount != DBNull.Value
                && Convert.ToInt32(unverifiedCount) > 0;

            if (hasNewPetItems)
            {
                DataRow prjNew = ProjectsDAL.GetProject(CurrentProjectId);
                int vNew = prjNew == null || prjNew["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prjNew["Version"]);
                int nextVer = PetDAL.GetNextSubmissionVersion(CurrentProjectId);
                PetDAL.CreateSubmission(CurrentProjectId, nextVer, user);
                Db.Exec("UPDATE PetForm SET PetVersion=@nv WHERE ProjectID=@id AND PetVersion IS NULL",
                    Db.P("@nv", nextVer), Db.P("@id", CurrentProjectId));
                Db.Exec(@"UPDATE Projects SET PetStageStatus='Resubmitted', PetApprovalStatus='Pending',
                          CurrentStage='PET Approval' WHERE ProjectID=@id",
                    Db.P("@id", CurrentProjectId));
                ProjectsDAL.AddWorkflow(CurrentProjectId, "PET Resubmitted", null, user,
                    string.Format("New PET items added during BPM stage — PET v{0} auto-submitted for re-approval before BPM close.", nextVer), vNew);
                if (prjNew != null && prjNew["ApproverID"] != DBNull.Value)
                {
                    int approverId = Convert.ToInt32(prjNew["ApproverID"]);
                    DataRow ar = Db.QueryRow(
                        "SELECT ApproverName, Email FROM ApproverMaster WHERE ApproverID=@id",
                        Db.P("@id", approverId));
                    if (ar != null)
                        NotificationsDAL.Send(ar["ApproverName"].ToString(),
                            "PET Re-approval required",
                            string.Format("Project {0} — PET v{1} needs re-approval before BPM can be closed.",
                                prjNew["ProjectName"], nextVer),
                            "~/Forms/Workflow.aspx?id=" + CurrentProjectId,
                            CurrentProjectId, "PETRequest");
                }
                LoadProject(CurrentProjectId);
                ShowNotify("warning", "PET Re-approval Required",
                    string.Format("New PET items detected. PET v{0} has been auto-submitted for re-approval. BPM will close after approval.", nextVer));
                return;
            }

            // Enforce settlement rule: all memos must be closed and all invoices paid
            if (!MemoDAL.IsFullySettled(CurrentProjectId))
            {
                lblMsg.Visible = true; lblMsg.CssClass = "alert-danger";
                ShowNotify("warning", "Cannot Close BPM", "All memos must have status 'Closed' and all invoices must be 'Paid'.");
                return;
            }
            WorkflowDAL.CloseBpm(CurrentProjectId, user, txtBpmNotes.Value);
            LoadProject(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.CssClass = "alert-success";
            lblMsg.Text = "BPM closed. Workflow complete.";
        }

        // ===== Attachments =====
        private void BindAttachments(int pid)
        {
            DataTable dt;
            try { dt = Db.Query("SELECT * FROM Attachments WHERE ProjectID=@id ORDER BY UploadedDate DESC", Db.P("@id", pid)); }
            catch { dt = new DataTable(); }
            rptAttach.DataSource = dt; rptAttach.DataBind();
        }

        protected void btnUploadAttach_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || !fuAttach.HasFiles) return;
            string user = AuthHelper.CurrentUser;
            string stage = ddlAttachStage.SelectedValue;
            string folder = Server.MapPath("~/Uploads");
            if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
            int n = 0;
            foreach (HttpPostedFile file in fuAttach.PostedFiles)
            {
                if (file == null || file.ContentLength == 0) continue;
                string safe = Guid.NewGuid().ToString("N") + "_" + Path.GetFileName(file.FileName);
                string path = Path.Combine(folder, safe);
                file.SaveAs(path);
                string rel = "~/Uploads/" + safe;
                Db.Exec(@"INSERT INTO Attachments(ProjectID, FileName, StoredPath, DocType, SizeBytes, UploadedBy, Stage)
                          VALUES(@p, @fn, @sp, @dt, @sz, @u, @st)",
                    Db.P("@p", CurrentProjectId), Db.P("@fn", file.FileName),
                    Db.P("@sp", rel), Db.P("@dt", "Other"),
                    Db.P("@sz", (long)file.ContentLength), Db.P("@u", user), Db.P("@st", stage));
                n++;
            }
            BindAttachments(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.Text = "Uploaded " + n + " file(s).";
        }

        // ===== History / Audit table =====
        private void BindHistory(int pid)
        {
            DataTable dt = ProjectsDAL.GetWorkflowHistory(pid);
            DataView dv = new DataView(dt); dv.Sort = "ActionDate DESC";
            gvHistory.DataSource = dv;
            gvHistory.DataBind();
            pnlNoHistory.Visible = (dt.Rows.Count == 0);
        }

        protected void gvHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvHistory.PageIndex = e.NewPageIndex;
            if (CurrentProjectId > 0) BindHistory(CurrentProjectId);
        }
    }
}
