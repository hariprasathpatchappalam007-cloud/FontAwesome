using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class Workflow : System.Web.UI.Page
    {
        // ===== Project / Stage state (ViewState backed) =====
        protected int CurrentProjectId
        {
            get { object o = ViewState["pid"]; return o == null ? 0 : (int)o; }
            set { ViewState["pid"] = value; }
        }
        protected string CurrentProjectIdJs
        {
            get { return CurrentProjectId > 0 ? CurrentProjectId.ToString() : "0"; }
        }

        // Stage values: "Project", "PET", "PETApproval", "BPM", "Closed"
        private string CurrentStageKey
        {
            get { object o = ViewState["stage"]; return o == null ? "Project" : (string)o; }
            set { ViewState["stage"] = value; }
        }

        // JSON of currency code -> rate-to-AED for the inline JS calculator.
        public string PetRatesJs { get; private set; }

        // Accordion class strings used by <%= %> in markup.
        public string ProjectAccordionClass { get; set; }
        public string PetAccordionClass { get; set; }
        public string PetApprovalAccordionClass { get; set; }
        public string BpmAccordionClass { get; set; }
        public string HistoryAccordionClass { get; set; }

        private Dictionary<string, string> _guidance;
        public string GetGuidance(string field)
        {
            if (_guidance == null)
            {
                _guidance = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    DataTable g = WorkflowDAL.GetPetGuidance();
                    foreach (DataRow r in g.Rows)
                        _guidance[r["FieldName"].ToString()] = r["Guidance"].ToString();
                }
                catch { }
                if (_guidance.Count == 0)
                {
                    try
                    {
                        string path = Path.Combine(
                            System.Configuration.ConfigurationManager.AppSettings["RequirementFolder"] ?? "",
                            "PET Guidance.csv");
                        if (File.Exists(path))
                        {
                            using (var sr = new StreamReader(path, Encoding.UTF8, true))
                            {
                                sr.ReadLine();
                                string line;
                                while ((line = sr.ReadLine()) != null)
                                {
                                    var f = CsvImporter.ParseCsvLine(line);
                                    if (f.Count >= 2 && !string.IsNullOrEmpty(f[0]))
                                        _guidance[f[0].Trim()] = (f[1] ?? "").Trim();
                                }
                            }
                        }
                    }
                    catch { }
                }
            }
            string v;
            return _guidance.TryGetValue(field, out v) ? Server.HtmlEncode(v) : "";
        }

        // ===== Lifecycle =====
        protected void Page_Load(object sender, EventArgs e)
        {
            ProjectAccordionClass = "";
            PetAccordionClass = "collapsed";
            PetApprovalAccordionClass = "collapsed";
            BpmAccordionClass = "collapsed";
            HistoryAccordionClass = "";

            if (!IsPostBack)
            {
                LoadJiraDropdown();
                LoadApprovers();
                LoadPetMasters();
                LoadCurrencies();

                int qid;
                if (int.TryParse(Request.QueryString["id"], out qid) && qid > 0)
                {
                    CurrentProjectId = qid;
                    LoadProject(qid);
                }
                else
                {
                    // Fresh project
                    BuildStepper(null);
                    CurrentStageKey = "Project";
                }
                BindBudgetGrid();
            }

            // ApplyStageGating runs every request so visibility / read-only stays
            // consistent after postback actions that change the stage.
            ApplyStageGating();
        }

        // ===== Stage detection =====
        private string DetectStage(DataRow prj)
        {
            if (prj == null) return "Project";
            string current = prj["CurrentStage"] == DBNull.Value ? "" : prj["CurrentStage"].ToString();
            string petStatus  = SafeStr(prj, "PetStageStatus");
            string petAppr    = SafeStr(prj, "PetApprovalStatus");
            string bpmStatus  = SafeStr(prj, "BpmStageStatus");

            if (string.Equals(bpmStatus, "Closed", StringComparison.OrdinalIgnoreCase)) return "Closed";
            if (string.Equals(petAppr,   "Approved", StringComparison.OrdinalIgnoreCase)) return "BPM";
            if (string.Equals(petStatus, "Submitted", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(petAppr,   "Rejected", StringComparison.OrdinalIgnoreCase)) return "PETApproval";
            if (current == "PET" || current == "Registration" && SafeStr(prj, "Status") != "Draft") return "PET";
            if (current == "PET") return "PET";
            return "Project";
        }

        private string SafeStr(DataRow r, string c)
        {
            if (!r.Table.Columns.Contains(c) || r[c] == DBNull.Value) return "";
            return r[c].ToString();
        }

        // ===== Stage-driven visibility + read-only =====
        private void ApplyStageGating()
        {
            string stage = CurrentStageKey;

            // ---- Section visibility ----
            // Project section is always visible. PET shows once we've left Project stage.
            pnlPet.Visible          = stage != "Project";
            pnlPetApproval.Visible  = stage == "PETApproval" || stage == "BPM" || stage == "Closed";
            pnlBpm.Visible          = stage == "BPM" || stage == "Closed";
            pnlAttach.Visible       = CurrentProjectId > 0;   // attachments allowed once project exists

            // ---- Role detection ----
            // Stage drives most button visibility. Role only restricts the PET
            // Approve/Reject pair so that a pure requestor cannot self-approve.
            string activeRole = (Session["ActiveRole"] as string) ?? "";
            string sessionRole = (Session["Role"] as string) ?? "";
            bool isApprover = string.Equals(activeRole, "Approver", StringComparison.OrdinalIgnoreCase)
                           || string.Equals(sessionRole, "Approver", StringComparison.OrdinalIgnoreCase)
                           || string.Equals(sessionRole, "Admin", StringComparison.OrdinalIgnoreCase);

            // ---- Action button visibility (current stage only) ----
            pnlProjectActions.Visible    = stage == "Project";
            pnlPetAddActions.Visible     = stage == "PET";
            pnlPetSubmitActions.Visible  = stage == "PET";
            pnlApprovalActions.Visible   = stage == "PETApproval" && isApprover;
            pnlBpmActions.Visible        = stage == "BPM";

            // ---- Editability (read-only outside the active stage) ----
            // Project Identity fields: editable only when stage = Project
            bool projectEditable = (stage == "Project");
            SetEditable(new Control[] { ddlJira, txtName, ddlType, ddlUpdateMode, ddlSource, txtAmount, ddlApprover }, projectEditable);

            // PET inputs: editable only when stage = PET
            bool petEditable = (stage == "PET");
            SetEditable(new Control[] { ddlDept, ddlCostType, ddlExpHead, txtTopic, txtVendor, txtDesc,
                                        txtUnits, txtUnitPrice, ddlCurrency, fuPetCsv }, petEditable);
            // PET Approval inputs editable only when the approver acts at that stage.
            bool approvalEditable = stage == "PETApproval" && isApprover;
            SetEditable(new Control[] { txtApprovedAmount }, approvalEditable);

            // BPM inputs editable only at BPM stage
            bool bpmEditable = (stage == "BPM");
            SetEditable(new Control[] { txtBpmRef, txtInvoiceNo, txtInvoiceDate, txtInvoiceAmount, txtBpmVendor }, bpmEditable);

            // PET grid delete column: hide delete button when not editable
            if (gvPet != null) gvPet.Columns[gvPet.Columns.Count - 1].Visible = petEditable;

            // PET CSV upload only at PET stage (download/template stay available read-only).
            btnPetUpload.Visible = petEditable;
            fuPetCsv.Visible = petEditable;
        }

        private void SetEditable(Control[] ctrls, bool editable)
        {
            foreach (Control c in ctrls)
            {
                var tb = c as TextBox;
                if (tb != null) { tb.ReadOnly = !editable; continue; }
                var dd = c as DropDownList;
                if (dd != null) { dd.Enabled = editable; continue; }
                var fu = c as FileUpload;
                if (fu != null) { fu.Enabled = editable; continue; }
            }
        }

        // ===== Loaders =====
        private void LoadJiraDropdown()
        {
            ddlJira.Items.Clear();
            ddlJira.Items.Add(new ListItem("-- Select JIRA ID --", ""));
            try
            {
                DataTable dt = JiraClient.GetCachedIssues();
                foreach (DataRow r in dt.Rows)
                {
                    string id = r["JiraID"].ToString();
                    string name = r["ProjectName"] == DBNull.Value ? "" : r["ProjectName"].ToString();
                    ddlJira.Items.Add(new ListItem(id + (string.IsNullOrEmpty(name) ? "" : " - " + name), id));
                }
            }
            catch { }
        }

        private void LoadApprovers()
        {
            ddlApprover.Items.Clear();
            ddlApprover.Items.Add(new ListItem("-- Select Approver --", ""));
            try
            {
                DataTable dt = MastersDAL.GetApprovers(true);
                foreach (DataRow r in dt.Rows)
                    ddlApprover.Items.Add(new ListItem(r["ApproverName"].ToString(), r["ApproverID"].ToString()));
            }
            catch { }
        }

        private void LoadPetMasters()
        {
            ddlDept.Items.Clear();
            ddlDept.Items.Add(new ListItem("-- Department --", ""));
            ddlCostType.Items.Clear();
            ddlCostType.Items.Add(new ListItem("-- Cost Type --", ""));
            try
            {
                foreach (DataRow r in PetDAL.GetDepartments().Rows)
                    ddlDept.Items.Add(new ListItem(r["Department"].ToString(), r["Department"].ToString()));
                foreach (DataRow r in PetDAL.GetCostTypes().Rows)
                    ddlCostType.Items.Add(new ListItem(r["Category"].ToString(), r["Category"].ToString()));
            }
            catch { }
        }

        private void LoadCurrencies()
        {
            ddlCurrency.Items.Clear();
            var sb = new StringBuilder();
            sb.Append("{");
            bool first = true;
            try
            {
                foreach (DataRow r in PetDAL.GetCurrencies().Rows)
                {
                    string code = r["Code"].ToString();
                    decimal rate = r["RateToLocal"] == DBNull.Value ? 1m : Convert.ToDecimal(r["RateToLocal"]);
                    ddlCurrency.Items.Add(new ListItem(code, code));
                    if (!first) sb.Append(",");
                    sb.Append("\"").Append(code).Append("\":")
                      .Append(rate.ToString("0.######", CultureInfo.InvariantCulture));
                    first = false;
                }
            }
            catch { }
            if (ddlCurrency.Items.Count == 0)
            {
                ddlCurrency.Items.Add(new ListItem("AED", "AED"));
                sb.Append("\"AED\":1");
            }
            sb.Append("}");
            PetRatesJs = sb.ToString();
            if (ddlCurrency.Items.FindByValue("AED") != null) ddlCurrency.SelectedValue = "AED";
        }

        private void LoadProject(int pid)
        {
            DataRow prj = ProjectsDAL.GetProject(pid);
            if (prj == null) return;

            string jira = prj["JiraID"] == DBNull.Value ? "" : prj["JiraID"].ToString();
            if (!string.IsNullOrEmpty(jira))
            {
                if (ddlJira.Items.FindByValue(jira) == null)
                    ddlJira.Items.Add(new ListItem(jira, jira));
                ddlJira.SelectedValue = jira;
                ShowJiraDetails(jira);
            }
            txtName.Text = prj["ProjectName"].ToString();
            ddlType.SelectedValue = prj["ProjectType"].ToString();
            ShowSourceLabel();
            LoadSources();
            string srcId = prj["BudgetSourceID"] == DBNull.Value ? "" : prj["BudgetSourceID"].ToString();
            if (ddlSource.Items.FindByValue(srcId) != null) ddlSource.SelectedValue = srcId;
            if (prj["UpdateMode"] != DBNull.Value && !string.IsNullOrEmpty(prj["UpdateMode"].ToString()))
                ddlUpdateMode.SelectedValue = prj["UpdateMode"].ToString();
            txtAmount.Text = prj["RequestedAmount"] == DBNull.Value ? "" :
                Convert.ToDecimal(prj["RequestedAmount"]).ToString("F2", CultureInfo.InvariantCulture);
            if (prj["ApproverID"] != DBNull.Value &&
                ddlApprover.Items.FindByValue(prj["ApproverID"].ToString()) != null)
                ddlApprover.SelectedValue = prj["ApproverID"].ToString();

            // Detect & store stage
            CurrentStageKey = DetectStage(prj);

            BindPet(pid);
            BindHistory(pid);
            BindAttachments(pid);
            BindBudgetGrid();
            BuildStepper(prj);

            // Pre-fill PET totals + approval amount
            decimal petTotal = PetDAL.GetTotalForProject(pid);
            txtPetTotal.Text = petTotal.ToString("F2", CultureInfo.InvariantCulture);
            decimal petApproved = prj.Table.Columns.Contains("PetApprovedAmount") && prj["PetApprovedAmount"] != DBNull.Value
                ? Convert.ToDecimal(prj["PetApprovedAmount"]) : 0m;
            txtApprovedAmount.Text = (petApproved > 0 ? petApproved : petTotal)
                .ToString("F2", CultureInfo.InvariantCulture);

            // Auto-open the relevant accordion when the user first arrives.
            ProjectAccordionClass     = "collapsed";
            PetAccordionClass         = "collapsed";
            PetApprovalAccordionClass = "collapsed";
            BpmAccordionClass         = "collapsed";
            switch (CurrentStageKey)
            {
                case "Project":     ProjectAccordionClass     = ""; break;
                case "PET":         PetAccordionClass         = ""; break;
                case "PETApproval": PetApprovalAccordionClass = ""; break;
                case "BPM":         BpmAccordionClass         = ""; break;
                case "Closed":      HistoryAccordionClass     = ""; break;
            }
        }

        private void ShowJiraDetails(string jiraId)
        {
            DataRow ji = JiraClient.GetCachedIssue(jiraId);
            litJiraId.Text = jiraId;
            if (ji == null) return;
            litJiraName.Text = ji["ProjectName"] == DBNull.Value ? "" : Server.HtmlEncode(ji["ProjectName"].ToString());
            litJStage.Text   = Safe(ji, "ProjectStage");
            litJRag.Text     = Safe(ji, "ProjectRAG");
            litJDemand.Text  = Safe(ji, "DemandType");
            litJMgr.Text     = Safe(ji, "Manager");
            litJTech.Text    = Safe(ji, "TechLead");
            litJSponsor.Text = Safe(ji, "Sponsor");
            litJDept.Text    = Safe(ji, "Department");
            litJStart.Text   = Safe(ji, "StartDate");
            litJEnd.Text     = Safe(ji, "EndDate");
            litJStatus.Text  = Safe(ji, "OverallStatus");
            if (string.IsNullOrEmpty(txtName.Text) && ji["ProjectName"] != DBNull.Value)
                txtName.Text = ji["ProjectName"].ToString();
        }
        private string Safe(DataRow r, string c)
        {
            if (!r.Table.Columns.Contains(c) || r[c] == DBNull.Value) return "";
            return Server.HtmlEncode(r[c].ToString());
        }

        protected void ddlJira_Changed(object sender, EventArgs e)
        {
            ShowJiraDetails(ddlJira.SelectedValue);
            if (!string.IsNullOrEmpty(ddlJira.SelectedValue) && CurrentProjectId == 0)
            {
                DataRow existing = Db.QueryRow(
                    "SELECT TOP 1 ProjectID FROM Projects WHERE JiraID=@j ORDER BY ProjectID DESC",
                    Db.P("@j", ddlJira.SelectedValue));
                if (existing != null)
                {
                    int pid = Convert.ToInt32(existing["ProjectID"]);
                    CurrentProjectId = pid;
                    LoadProject(pid);
                }
            }
        }

        protected void ddlType_Changed(object sender, EventArgs e)
        {
            ShowSourceLabel(); LoadSources(); BindBudgetGrid();
        }
        protected void ddlSource_Changed(object sender, EventArgs e) { BindBudgetGrid(); }

        private void ShowSourceLabel() { litSourceLabel.Text = ddlType.SelectedValue; }

        private void LoadSources()
        {
            ddlSource.Items.Clear();
            ddlSource.Items.Add(new ListItem("-- Select --", ""));
            DataTable dt;
            switch (ddlType.SelectedValue)
            {
                case "OPEX": dt = MastersDAL.GetOpex(); break;
                case "AMC":  dt = MastersDAL.GetAmc();  break;
                default:     dt = MastersDAL.GetCapex(); break;
            }
            foreach (DataRow r in dt.Rows)
            {
                string id = r[0].ToString();
                string d  = r["Description"].ToString();
                ddlSource.Items.Add(new ListItem(id + " - " + (d.Length > 80 ? d.Substring(0, 80) : d), id));
            }
        }

        private void BindBudgetGrid()
        {
            string sel = ddlSource.SelectedValue;
            if (string.IsNullOrEmpty(sel)) { pnlBudget.Visible = false; return; }
            DataRow row;
            switch (ddlType.SelectedValue)
            {
                case "OPEX": row = MastersDAL.GetOpexById(sel); break;
                case "AMC":  row = MastersDAL.GetAmcById(sel);  break;
                default:     row = MastersDAL.GetCapexById(sel); break;
            }
            if (row == null) { pnlBudget.Visible = false; return; }
            bBudget.Text = FormatMoney(row, "Budget");
            bUtil.Text   = FormatMoney(row, "Utilization");
            bAvail.Text  = FormatMoney(row, "AvailableBudget");
            bLock.Text   = FormatMoney(row, "LockedAmount");
            bNet.Text    = FormatMoney(row, "NetBalance");
            pnlBudget.Visible = true;
        }
        private string FormatMoney(DataRow r, string c)
        {
            if (!r.Table.Columns.Contains(c) || r[c] == DBNull.Value) return "0.00";
            return Convert.ToDecimal(r[c]).ToString("N2");
        }

        // ===== Stepper (Req 29-30) =====
        private void BuildStepper(DataRow prj)
        {
            string[] stages = new[] { "Project", "PET", "PET Approval", "BPM" };
            string[] sub    = new[] {
                prj != null ? "OK" : "Draft",
                prj != null && prj.Table.Columns.Contains("PetStageStatus") && prj["PetStageStatus"] != DBNull.Value ? prj["PetStageStatus"].ToString() : "Pending",
                prj != null && prj.Table.Columns.Contains("PetApprovalStatus") && prj["PetApprovalStatus"] != DBNull.Value ? prj["PetApprovalStatus"].ToString() : "Pending",
                prj != null && prj.Table.Columns.Contains("BpmStageStatus") && prj["BpmStageStatus"] != DBNull.Value ? prj["BpmStageStatus"].ToString() : "Pending"
            };
            string key = CurrentStageKey;
            int curIx = 0;
            switch (key)
            {
                case "Project":     curIx = 0; break;
                case "PET":         curIx = 1; break;
                case "PETApproval": curIx = 2; break;
                case "BPM":         curIx = 3; break;
                case "Closed":      curIx = 4; break;
            }
            var sb = new StringBuilder();
            for (int i = 0; i < stages.Length; i++)
            {
                string cls = i < curIx ? "done" : (i == curIx ? "active" : "pending");
                sb.AppendFormat("<div class='step {0}'><div class='step-num'>{1}</div>", cls, i + 1);
                sb.AppendFormat("<div class='step-label'>{0}</div>", Server.HtmlEncode(stages[i]));
                sb.AppendFormat("<div class='step-sub'>{0}</div></div>", Server.HtmlEncode(sub[i]));
                if (i < stages.Length - 1)
                {
                    string lineCls = i < curIx ? "step-line done" : "step-line";
                    sb.AppendFormat("<div class='{0}'></div>", lineCls);
                }
            }
            litStepper.Text = sb.ToString();
        }

        // ===== PROJECT actions =====
        protected void btnSaveProject_Click(object sender, EventArgs e) { SaveProject("Draft", false); }
        protected void btnSubmitProject_Click(object sender, EventArgs e) { SaveProject("Pending", true); }

        private void SaveProject(string status, bool advanceToPet)
        {
            string user = AuthHelper.CurrentUser;
            decimal amt = 0m;
            decimal.TryParse(txtAmount.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
            int approverId = 0; int.TryParse(ddlApprover.SelectedValue, out approverId);

            if (CurrentProjectId == 0 && !string.IsNullOrEmpty(ddlJira.SelectedValue))
            {
                DataRow existing = Db.QueryRow(
                    "SELECT TOP 1 ProjectID FROM Projects WHERE JiraID=@j ORDER BY ProjectID DESC",
                    Db.P("@j", ddlJira.SelectedValue));
                if (existing != null) CurrentProjectId = Convert.ToInt32(existing["ProjectID"]);
            }

            if (CurrentProjectId == 0)
            {
                CurrentProjectId = ProjectsDAL.CreateProject(ddlJira.SelectedValue, txtName.Text.Trim(),
                    ddlType.SelectedValue, ddlSource.SelectedValue, amt, approverId, null, null, user, status);
                ProjectsDAL.AddWorkflow(CurrentProjectId,
                    status == "Pending" ? "Submitted" : "Draft", null, user, "Project saved", 1);
                Db.Exec("UPDATE Projects SET CurrentStage=@cs, UpdateMode=@um, CapexStageStatus=@css WHERE ProjectID=@id",
                    Db.P("@cs", advanceToPet ? "PET" : "Registration"),
                    Db.P("@um", ddlUpdateMode.SelectedValue),
                    Db.P("@css", advanceToPet ? "Approved" : "Pending"),
                    Db.P("@id", CurrentProjectId));
            }
            else
            {
                ProjectsDAL.UpdateProject(CurrentProjectId, txtName.Text.Trim(),
                    ddlSource.SelectedValue, amt, approverId, null, null, user);
                if (advanceToPet)
                    Db.Exec("UPDATE Projects SET CurrentStage='PET', UpdateMode=@um, CapexStageStatus='Approved' WHERE ProjectID=@id",
                        Db.P("@um", ddlUpdateMode.SelectedValue), Db.P("@id", CurrentProjectId));
                ProjectsDAL.AddWorkflow(CurrentProjectId, "Modified", null, user, "Project details updated", 1);
            }

            // Refresh in-place
            LoadProject(CurrentProjectId);
            lblMsg.Visible = true;
            lblMsg.Text = advanceToPet ? "Project saved. PET section is now active." : "Project draft saved.";
        }

        // ===== PET section =====
        private void BindPet(int pid)
        {
            DataTable dt = PetDAL.GetByProject(pid);
            gvPet.DataSource = dt;
            gvPet.DataBind();
            litPetTotal.Text = PetDAL.GetTotalForProject(pid).ToString("N2");
        }

        protected void btnAddPet_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0) { lblMsg.Visible = true; lblMsg.Text = "Save the project first."; return; }
            if (CurrentStageKey != "PET") return;

            string user = AuthHelper.CurrentUser;
            decimal units = 0, price = 0;
            decimal.TryParse(txtUnits.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out units);
            decimal.TryParse(txtUnitPrice.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out price);
            string ccy = string.IsNullOrEmpty(ddlCurrency.SelectedValue) ? "AED" : ddlCurrency.SelectedValue;
            decimal rate = PetDAL.GetRate(ccy);
            decimal amtFcy = units * price;
            decimal amtLcy = amtFcy * rate;   // Convert to AED (base currency)

            int editId = 0; int.TryParse(hfEditPetId.Value, out editId);

            if (editId > 0)
            {
                DataRow existing = PetDAL.GetById(editId);
                string lineCode = existing != null && existing["LineCode"] != DBNull.Value
                    ? existing["LineCode"].ToString()
                    : PetDAL.NextLineCode(ddlDept.SelectedValue ?? "");
                PetDAL.Update(editId, ddlDept.SelectedValue, lineCode, ddlExpHead.SelectedValue,
                    txtTopic.Text, txtVendor.Text, txtDesc.Text, ddlCostType.SelectedValue, "Lump Sum",
                    units, price, ccy, amtFcy, amtLcy, 0m, amtLcy, 1, null);
                lblMsg.Visible = true; lblMsg.Text = "Line item updated.";
            }
            else
            {
                string lineCode = PetDAL.NextLineCode(ddlDept.SelectedValue ?? "");
                PetDAL.Add(CurrentProjectId, ddlDept.SelectedValue, lineCode, ddlExpHead.SelectedValue,
                    txtTopic.Text, txtVendor.Text, txtDesc.Text, ddlCostType.SelectedValue, "Lump Sum",
                    units, price, ccy, amtFcy, amtLcy, 0m, amtLcy, 1, null, user);
            }

            ResetPetForm();
            BindPet(CurrentProjectId);
            txtPetTotal.Text = PetDAL.GetTotalForProject(CurrentProjectId).ToString("F2", CultureInfo.InvariantCulture);
        }

        protected void btnCancelEdit_Click(object sender, EventArgs e)
        {
            ResetPetForm();
        }

        private void ResetPetForm()
        {
            hfEditPetId.Value = "0";
            txtTopic.Text = ""; txtVendor.Text = ""; txtDesc.Text = "";
            txtUnits.Text = "1"; txtUnitPrice.Text = "";
            txtAmtFcy.Text = ""; txtAmtAed.Text = "";
            ddlDept.SelectedIndex = 0;
            ddlCostType.SelectedIndex = 0;
            ddlExpHead.SelectedIndex = 0;
            if (ddlCurrency.Items.FindByValue("AED") != null) ddlCurrency.SelectedValue = "AED";
            btnAddPet.Visible    = true;
            btnUpdatePet.Visible = false;
            btnCancelEdit.Visible = false;
        }

        protected void gvPet_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DelPet" && CurrentStageKey == "PET")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                PetDAL.Delete(id);
                BindPet(CurrentProjectId);
                txtPetTotal.Text = PetDAL.GetTotalForProject(CurrentProjectId).ToString("F2", CultureInfo.InvariantCulture);
                if (hfEditPetId.Value == id.ToString()) ResetPetForm();
            }
            else if (e.CommandName == "EditPet" && CurrentStageKey == "PET")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                DataRow r = PetDAL.GetById(id);
                if (r == null) return;
                hfEditPetId.Value = id.ToString();
                if (r["Department"] != DBNull.Value)
                {
                    string d = r["Department"].ToString();
                    if (ddlDept.Items.FindByValue(d) != null) ddlDept.SelectedValue = d;
                }
                if (r["CostType"] != DBNull.Value)
                {
                    string c = r["CostType"].ToString();
                    if (ddlCostType.Items.FindByValue(c) != null) ddlCostType.SelectedValue = c;
                }
                if (r["ExpHead"] != DBNull.Value && ddlExpHead.Items.FindByValue(r["ExpHead"].ToString()) != null)
                    ddlExpHead.SelectedValue = r["ExpHead"].ToString();
                txtTopic.Text  = SafeStr(r, "Topic");
                txtVendor.Text = SafeStr(r, "Vendor");
                txtDesc.Text   = SafeStr(r, "Description");
                txtUnits.Text     = r["Units"]     == DBNull.Value ? "1" : Convert.ToDecimal(r["Units"]).ToString("F2", CultureInfo.InvariantCulture);
                txtUnitPrice.Text = r["UnitPrice"] == DBNull.Value ? ""  : Convert.ToDecimal(r["UnitPrice"]).ToString("F2", CultureInfo.InvariantCulture);
                string ccy = SafeStr(r, "BaseCurrency");
                if (!string.IsNullOrEmpty(ccy) && ddlCurrency.Items.FindByValue(ccy) != null)
                    ddlCurrency.SelectedValue = ccy;
                txtAmtFcy.Text = r["AmtFCY"]      == DBNull.Value ? "" : Convert.ToDecimal(r["AmtFCY"]).ToString("F2", CultureInfo.InvariantCulture);
                txtAmtAed.Text = r["FinalAmtLCY"] == DBNull.Value ? "" : Convert.ToDecimal(r["FinalAmtLCY"]).ToString("F2", CultureInfo.InvariantCulture);

                btnAddPet.Visible    = false;
                btnUpdatePet.Visible = true;
                btnCancelEdit.Visible = true;
                lblMsg.Visible = true; lblMsg.Text = "Editing line #" + (r["SerialNo"] == DBNull.Value ? id.ToString() : r["SerialNo"].ToString()) + ". Make changes and click Update.";
            }
        }

        // Highlight the row currently being edited
        protected void gvPet_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType != DataControlRowType.DataRow) return;
            int editId; if (!int.TryParse(hfEditPetId.Value, out editId) || editId == 0) return;
            int rowId = Convert.ToInt32(gvPet.DataKeys[e.Row.RowIndex].Value);
            if (rowId == editId) e.Row.CssClass = (e.Row.CssClass ?? "") + " pet-row-editing";
        }

        protected void btnSubmitPet_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "PET") return;
            string user = AuthHelper.CurrentUser;
            DataRow prj = ProjectsDAL.GetProject(CurrentProjectId);
            int v = prj["Version"] == DBNull.Value ? 1 : Convert.ToInt32(prj["Version"]);
            Db.Exec(@"UPDATE Projects SET PetStageStatus='Submitted', CurrentStage='PET Approval'
                      WHERE ProjectID=@id", Db.P("@id", CurrentProjectId));
            ProjectsDAL.AddWorkflow(CurrentProjectId, "PET Submitted", null, user, "PET submitted for approval", v);

            int approverId = 0;
            if (prj["ApproverID"] != DBNull.Value) approverId = Convert.ToInt32(prj["ApproverID"]);
            if (approverId > 0)
            {
                DataRow ar = Db.QueryRow("SELECT ApproverName, Email FROM ApproverMaster WHERE ApproverID=@id",
                    Db.P("@id", approverId));
                if (ar != null)
                {
                    string recipient = ar["ApproverName"].ToString();
                    NotificationsDAL.Send(recipient, "PET approval requested",
                        "Project " + prj["ProjectName"] + " needs PET approval.",
                        "~/Forms/Workflow.aspx?id=" + CurrentProjectId,
                        CurrentProjectId, "PETRequest");
                }
            }
            LoadProject(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.Text = "PET submitted for approval.";
        }

        // ===== PET CSV download/template/upload =====
        protected void btnPetDownload_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0) return;
            DataTable dt = PetDAL.GetByProject(CurrentProjectId);
            var sb = new StringBuilder();
            sb.AppendLine("SerialNo,Department,LineCode,ExpHead,Topic,Vendor,Description,CostType,UnitType,Units,UnitPrice,BaseCurrency,AmtFCY,AmtLCY,FinalAmtLCY,YearlyRecurrence,Comments");
            foreach (DataRow r in dt.Rows)
            {
                sb.AppendFormat("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16}{17}",
                    r["SerialNo"], CsvEsc(r["Department"]), CsvEsc(r["LineCode"]), CsvEsc(r["ExpHead"]),
                    CsvEsc(r["Topic"]), CsvEsc(r["Vendor"]), CsvEsc(r["Description"]),
                    CsvEsc(r["CostType"]), CsvEsc(r["UnitType"]),
                    Money(r["Units"]), Money(r["UnitPrice"]), CsvEsc(r["BaseCurrency"]),
                    Money(r["AmtFCY"]), Money(r["AmtLCY"]), Money(r["FinalAmtLCY"]),
                    r["YearlyRecurrence"], CsvEsc(r["Comments"]), Environment.NewLine);
            }
            WriteCsv("PET_" + CurrentProjectId + ".csv", sb.ToString());
        }

        protected void btnPetTemplate_Click(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            sb.AppendLine("SerialNo,Department,LineCode,ExpHead,Topic,Vendor,Description,CostType,UnitType,Units,UnitPrice,BaseCurrency,AmtFCY,AmtLCY,FinalAmtLCY,YearlyRecurrence,Comments");
            sb.AppendLine("1,IT,IT - 1,Capex,Sample Topic,Sample Vendor,Sample description,Hardware,Lump Sum,1,1000,AED,1000,1000,1000,1,");
            WriteCsv("PET_Template.csv", sb.ToString());
        }

        private void WriteCsv(string fileName, string content)
        {
            Response.Clear();
            Response.ContentType = "text/csv";
            Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.Write(content);
            Response.End();
        }
        private string CsvEsc(object o)
        {
            if (o == null || o == DBNull.Value) return "";
            string s = o.ToString();
            if (s.Contains(",") || s.Contains("\"") || s.Contains("\n"))
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }
        private string Money(object o)
        {
            if (o == null || o == DBNull.Value) return "0";
            return Convert.ToDecimal(o).ToString("F2", CultureInfo.InvariantCulture);
        }

        protected void btnPetUpload_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0) { lblMsg.Visible = true; lblMsg.Text = "Save the project first."; return; }
            if (CurrentStageKey != "PET") return;
            if (!fuPetCsv.HasFile) { lblMsg.Visible = true; lblMsg.Text = "Pick a CSV file."; return; }
            string posted = Request.Form["petUploadMode"];
            string mode = string.Equals(posted, "Delete", StringComparison.OrdinalIgnoreCase) ? "Delete" : "Retain";
            string user = AuthHelper.CurrentUser;
            int n = 0;

            using (var sr = new StreamReader(fuPetCsv.PostedFile.InputStream))
            {
                if (mode == "Delete")
                    Db.Exec("DELETE FROM PetForm WHERE ProjectID=@id", Db.P("@id", CurrentProjectId));

                sr.ReadLine(); // header
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var f = CsvImporter.ParseCsvLine(line);
                    while (f.Count < 17) f.Add("");
                    PetDAL.Add(CurrentProjectId,
                        f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8],
                        CsvImporter.ParseDecimal(f[9]),
                        CsvImporter.ParseDecimal(f[10]),
                        f[11],
                        CsvImporter.ParseDecimal(f[12]),
                        CsvImporter.ParseDecimal(f[13]),
                        0m,
                        CsvImporter.ParseDecimal(f[14]),
                        ParseInt(f[15], 1),
                        f[16], user);
                    n++;
                }
            }
            lblMsg.Visible = true;
            lblMsg.Text = string.Format("Uploaded {0} lines (mode: {1}).", n, mode);
            BindPet(CurrentProjectId);
        }
        private int ParseInt(string s, int def)
        {
            int v; return int.TryParse(s, out v) ? v : def;
        }

        // ===== PET Approval =====
        protected void btnApprovePet_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "PETApproval") return;
            decimal amt = 0m;
            decimal.TryParse(txtApprovedAmount.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
            WorkflowDAL.ApprovePet(CurrentProjectId, amt, AuthHelper.CurrentUser, txtApproveComment.Value);
            LoadProject(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.Text = "PET approved. BPM section is now active.";
        }
        protected void btnRejectPet_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "PETApproval") return;
            WorkflowDAL.RejectPet(CurrentProjectId, AuthHelper.CurrentUser, txtApproveComment.Value);
            LoadProject(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.Text = "PET rejected.";
        }

        // ===== BPM =====
        protected void btnSubmitBpm_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "BPM") return;
            decimal amt = 0m;
            decimal.TryParse(txtInvoiceAmount.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out amt);
            DateTime invDate; DateTime? d = null;
            if (DateTime.TryParse(txtInvoiceDate.Text, out invDate)) d = invDate;
            PetDAL.CreateBpm(CurrentProjectId, txtBpmRef.Text, txtInvoiceNo.Text,
                d, amt, "AED", txtBpmVendor.Text, "PET-linked BPM", txtBpmNotes.Value, AuthHelper.CurrentUser);
            WorkflowDAL.SubmitBpm(CurrentProjectId, AuthHelper.CurrentUser, txtBpmNotes.Value);
            LoadProject(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.Text = "BPM submitted.";
        }
        protected void btnCloseBpm_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || CurrentStageKey != "BPM") return;
            WorkflowDAL.CloseBpm(CurrentProjectId, AuthHelper.CurrentUser, txtBpmNotes.Value);
            LoadProject(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.Text = "BPM closed. Workflow complete.";
        }

        // ===== Attachments =====
        private void BindAttachments(int pid)
        {
            DataTable dt;
            try { dt = Db.Query("SELECT * FROM Attachments WHERE ProjectID=@id ORDER BY UploadedDate DESC", Db.P("@id", pid)); }
            catch { dt = new DataTable(); }
            rptAttach.DataSource = dt; rptAttach.DataBind();
        }

        protected void btnUploadAttach_Click(object sender, EventArgs e)
        {
            if (CurrentProjectId == 0 || !fuAttach.HasFiles) return;
            string user = AuthHelper.CurrentUser;
            string stage = ddlAttachStage.SelectedValue;
            string folder = Server.MapPath("~/Uploads");
            if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
            int n = 0;
            foreach (HttpPostedFile file in fuAttach.PostedFiles)
            {
                if (file == null || file.ContentLength == 0) continue;
                string safe = Guid.NewGuid().ToString("N") + "_" + Path.GetFileName(file.FileName);
                string path = Path.Combine(folder, safe);
                file.SaveAs(path);
                string rel = "~/Uploads/" + safe;
                Db.Exec(@"INSERT INTO Attachments(ProjectID, FileName, StoredPath, DocType, SizeBytes, UploadedBy, Stage)
                          VALUES(@p, @fn, @sp, @dt, @sz, @u, @st)",
                    Db.P("@p", CurrentProjectId), Db.P("@fn", file.FileName),
                    Db.P("@sp", rel), Db.P("@dt", "Other"),
                    Db.P("@sz", (long)file.ContentLength), Db.P("@u", user), Db.P("@st", stage));
                n++;
            }
            BindAttachments(CurrentProjectId);
            lblMsg.Visible = true; lblMsg.Text = "Uploaded " + n + " file(s).";
        }

        // ===== History / Audit table =====
        private void BindHistory(int pid)
        {
            DataTable dt = ProjectsDAL.GetWorkflowHistory(pid);
            DataView dv = new DataView(dt); dv.Sort = "ActionDate DESC";
            gvHistory.DataSource = dv;
            gvHistory.DataBind();
            pnlNoHistory.Visible = (dt.Rows.Count == 0);
        }

        protected void gvHistory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvHistory.PageIndex = e.NewPageIndex;
            if (CurrentProjectId > 0) BindHistory(CurrentProjectId);
        }
    }
}
