namespace DFM.Forms
{
    public partial class BpmCreation
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.DropDownList ddlProject;
        protected global::System.Web.UI.WebControls.Literal litStatus;
        protected global::System.Web.UI.WebControls.TextBox txtRef;
        protected global::System.Web.UI.WebControls.TextBox txtVendor;
        protected global::System.Web.UI.WebControls.TextBox txtMemo;
        protected global::System.Web.UI.WebControls.TextBox txtInvNo;
        protected global::System.Web.UI.WebControls.TextBox txtInvDate;
        protected global::System.Web.UI.WebControls.TextBox txtInvAmt;
        protected global::System.Web.UI.WebControls.TextBox txtCcy;
        protected global::System.Web.UI.WebControls.TextBox txtNotes;
        protected global::System.Web.UI.WebControls.Button btnSubmit;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
