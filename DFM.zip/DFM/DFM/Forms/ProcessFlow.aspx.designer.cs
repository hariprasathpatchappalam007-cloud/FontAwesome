namespace DFM.Forms
{
    public partial class ProcessFlow
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.TextBox txtDmgtKey;
        protected global::System.Web.UI.WebControls.Button btnSearch;
        protected global::System.Web.UI.WebControls.Button btnLoadAll;
        protected global::System.Web.UI.WebControls.Panel pnlHierarchy;
        protected global::System.Web.UI.WebControls.Literal litFlowHtml;
        protected global::System.Web.UI.WebControls.Literal litRagSummary;
        protected global::System.Web.UI.WebControls.Panel pnlAll;
        protected global::System.Web.UI.WebControls.GridView gvAll;
    }
}
