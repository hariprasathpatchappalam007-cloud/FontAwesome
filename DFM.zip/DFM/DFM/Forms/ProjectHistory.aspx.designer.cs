namespace DFM.Forms
{
    public partial class ProjectHistory
    {
        protected global::System.Web.UI.WebControls.Literal litTitle;
        protected global::System.Web.UI.WebControls.Literal litSummary;
        protected global::System.Web.UI.WebControls.Repeater rptWorkflow;
        protected global::System.Web.UI.WebControls.Label lblNoWorkflow;
        protected global::System.Web.UI.WebControls.Repeater rptComments;
        protected global::System.Web.UI.WebControls.GridView gvVersions;
        protected global::System.Web.UI.WebControls.GridView gvLocked;
        protected global::System.Web.UI.WebControls.GridView gvDebited;
        protected global::System.Web.UI.WebControls.GridView gvCapex;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.HyperLink lnkBack;
    }
}
