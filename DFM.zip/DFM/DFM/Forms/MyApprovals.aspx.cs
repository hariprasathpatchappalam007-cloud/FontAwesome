using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class MyApprovals : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        private void Bind()
        {
            string user = AuthHelper.CurrentUser;
            string role = AuthHelper.CurrentRole;
            // Req 4: My Approvals shows PET pending approvals only.
            // The actual Approve/Reject happens on Workflow.aspx (no buttons here).
            string sql;
            if (string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                sql = @"SELECT p.*, a.ApproverName FROM Projects p
                        LEFT JOIN ApproverMaster a ON p.ApproverID=a.ApproverID
                        WHERE p.PetApprovalStatus='Pending' ORDER BY p.ModifiedDate DESC";
                gvPending.DataSource = Db.Query(sql);
            }
            else
            {
                sql = @"SELECT p.*, a.ApproverName FROM Projects p
                        INNER JOIN ApproverMaster a ON p.ApproverID=a.ApproverID
                        WHERE p.PetApprovalStatus='Pending'
                        AND (a.Username=@u OR a.Email=@u OR a.ApproverName=@u OR a.ApproverName=@n)
                        ORDER BY p.ModifiedDate DESC";
                string fullName = (System.Web.HttpContext.Current.Session["FullName"] as string) ?? user;
                gvPending.DataSource = Db.Query(sql, Db.P("@u", user), Db.P("@n", fullName));
            }
            gvPending.DataBind();

            // Recently processed PET approvals
            gvDone.DataSource = Db.Query(
                @"SELECT TOP 30 p.*, a.ApproverName FROM Projects p
                  LEFT JOIN ApproverMaster a ON p.ApproverID=a.ApproverID
                  WHERE p.PetApprovalStatus IN ('Approved','Rejected')
                  ORDER BY p.ModifiedDate DESC");
            gvDone.DataBind();
        }

        private void Msg(string m) { lblMsg.Visible = true; lblMsg.Text = m; }
    }
}
