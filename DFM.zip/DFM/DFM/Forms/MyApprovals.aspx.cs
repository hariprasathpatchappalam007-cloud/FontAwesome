using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class MyApprovals : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        private void Bind()
        {
            string user = AuthHelper.CurrentUser;
            string role = AuthHelper.CurrentRole;
            string sql;
            if (string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                sql = @"SELECT p.*, a.ApproverName FROM Projects p
                        LEFT JOIN ApproverMaster a ON p.ApproverID=a.ApproverID
                        WHERE p.Status='Pending' ORDER BY p.SubmittedDate";
                gvPending.DataSource = Db.Query(sql);
            }
            else
            {
                sql = @"SELECT p.*, a.ApproverName FROM Projects p
                        INNER JOIN ApproverMaster a ON p.ApproverID=a.ApproverID
                        WHERE p.Status='Pending' AND (a.Email=@u OR a.ApproverName=@u OR a.ApproverName=@n)
                        ORDER BY p.SubmittedDate";
                string fullName = (System.Web.HttpContext.Current.Session["FullName"] as string) ?? user;
                gvPending.DataSource = Db.Query(sql, Db.P("@u", user), Db.P("@n", fullName));
            }
            gvPending.DataBind();

            gvDone.DataSource = Db.Query(@"SELECT TOP 30 p.*, a.ApproverName FROM Projects p
                                           LEFT JOIN ApproverMaster a ON p.ApproverID=a.ApproverID
                                           WHERE p.Status IN ('Approved','Rejected','Closed','Funded')
                                           ORDER BY p.ApprovedDate DESC, p.ModifiedDate DESC");
            gvDone.DataBind();
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int id = Convert.ToInt32(e.CommandArgument);
            string user = AuthHelper.CurrentUser;

            // Pull the row controls (approved amount + comment)
            string approvedText = ""; string comment = "";
            foreach (GridViewRow row in gvPending.Rows)
            {
                if (Convert.ToInt32(gvPending.DataKeys[row.RowIndex].Value) != id) continue;
                TextBox tApp = row.FindControl("txtApproved") as TextBox;
                TextBox tCmt = row.FindControl("txtCmt") as TextBox;
                if (tApp != null) approvedText = tApp.Text;
                if (tCmt != null) comment = tCmt.Text;
                break;
            }

            // Self-approval check
            DataRow p = ProjectsDAL.GetProject(id);
            if (p == null) { Msg("Project not found."); return; }
            string requestor = p["CreatedBy"] == DBNull.Value ? "" : p["CreatedBy"].ToString();
            if (string.Equals(requestor, user, StringComparison.OrdinalIgnoreCase))
            {
                Msg("You cannot approve your own request.");
                return;
            }

            if (e.CommandName == "Approve")
            {
                decimal approved = CsvImporter.ParseDecimal(approvedText);
                decimal requested = p["RequestedAmount"] == DBNull.Value ? 0m : Convert.ToDecimal(p["RequestedAmount"]);
                if (approved <= 0) approved = requested;

                ApproveAndRouteBack(p, approved, user, comment);
                Msg("Project approved (" + approved.ToString("N2") + ") and routed back to Requestor.");
            }
            else if (e.CommandName == "Reject")
            {
                if (string.IsNullOrWhiteSpace(comment))
                {
                    Msg("Please enter a comment before rejecting.");
                    return;
                }
                ProjectsDAL.Reject(id, user, comment);
                if (!string.IsNullOrEmpty(requestor))
                    NotificationsDAL.Send(requestor, "Project rejected",
                        "Your project " + p["ProjectCode"] + " was rejected.",
                        "~/Forms/ProjectRegistration.aspx?id=" + id, id, "Rejected");
                Msg("Project rejected.");
            }
            Bind();
        }

        // Approve with the (possibly overridden) approved amount, then route back to Requestor.
        private void ApproveAndRouteBack(DataRow p, decimal approvedAmount, string approver, string comment)
        {
            int id = Convert.ToInt32(p["ProjectID"]);
            string ptype = p["ProjectType"].ToString();
            string srcId = p["BudgetSourceID"] == DBNull.Value ? "" : p["BudgetSourceID"].ToString();
            int version = p["Version"] == DBNull.Value ? 1 : Convert.ToInt32(p["Version"]);
            string requestor = p["CreatedBy"] == DBNull.Value ? "" : p["CreatedBy"].ToString();

            // Update project: Approved + locked = approvedAmount; routed back to Requestor stage.
            Db.Exec(@"UPDATE Projects
                      SET Status='Approved', CurrentStage='RoutedBackToRequestor',
                          ApprovedAmount=@a, LockedAmount=@a,
                          ApprovedDate=GETDATE(), ModifiedBy=@u, ModifiedDate=GETDATE()
                      WHERE ProjectID=@id",
                Db.P("@a", approvedAmount), Db.P("@u", approver), Db.P("@id", id));

            ProjectsDAL.AddWorkflow(id, "Approved", null, approver,
                (string.IsNullOrEmpty(comment) ? "" : comment + " | ") +
                "Approved amount: " + approvedAmount.ToString("N2"), version);
            ProjectsDAL.AddWorkflow(id, "RoutedBackToRequestor", null, approver,
                "Routed back to Requestor for Co-Pilot integration", version);

            // Locked-amount history
            Db.Exec(@"INSERT INTO LockedAmountHistory(ProjectID, SourceType, SourceID, Amount, Action, ActionBy)
                      VALUES(@id, @st, @src, @a, 'Locked', @u)",
                Db.P("@id", id), Db.P("@st", ptype), Db.P("@src", srcId),
                Db.P("@a", approvedAmount), Db.P("@u", approver));

            // CAPEX/OPEX/AMC master: lock the approved amount + reduce Available + AfterLocked
            string masterTbl = ptype == "OPEX" ? "OpexMaster" : ptype == "AMC" ? "AmcMaster" : "CapexMaster";
            string keyCol  = ptype == "OPEX" ? "OpexID"     : ptype == "AMC" ? "AmcID"     : "CapexID";

            DataRow before = Db.QueryRow(string.Format("SELECT * FROM {0} WHERE {1}=@id", masterTbl, keyCol),
                Db.P("@id", srcId));
            decimal prevBudget = before == null || before["Budget"]       == DBNull.Value ? 0 : Convert.ToDecimal(before["Budget"]);
            decimal prevUtil   = before == null || before["Utilization"]  == DBNull.Value ? 0 : Convert.ToDecimal(before["Utilization"]);
            decimal prevLocked = before == null || before["LockedAmount"] == DBNull.Value ? 0 : Convert.ToDecimal(before["LockedAmount"]);

            Db.Exec(string.Format(@"
UPDATE {0}
SET LockedAmount = ISNULL(LockedAmount,0) + @a,
    AvailableBudget = ISNULL(Budget,0) - ISNULL(Utilization,0) - (ISNULL(LockedAmount,0) + @a),
    BudgetAfterLockedAmount = ISNULL(Budget,0) - (ISNULL(LockedAmount,0) + @a),
    NetBalance = ISNULL(Budget,0) - ISNULL(Utilization,0) - (ISNULL(LockedAmount,0) + @a),
    ModifiedDate=GETDATE(), ModifiedBy=@u
WHERE {1}=@id", masterTbl, keyCol),
                Db.P("@a", approvedAmount), Db.P("@u", approver), Db.P("@id", srcId));

            DataRow after = Db.QueryRow(string.Format("SELECT * FROM {0} WHERE {1}=@id", masterTbl, keyCol),
                Db.P("@id", srcId));
            decimal newBudget = after == null || after["Budget"]       == DBNull.Value ? 0 : Convert.ToDecimal(after["Budget"]);
            decimal newUtil   = after == null || after["Utilization"]  == DBNull.Value ? 0 : Convert.ToDecimal(after["Utilization"]);
            decimal newLocked = after == null || after["LockedAmount"] == DBNull.Value ? 0 : Convert.ToDecimal(after["LockedAmount"]);

            // Per-project CAPEX/OPEX history
            Db.Exec(@"INSERT INTO CapexHistory(SourceType, SourceID, ProjectID, Action, Amount,
                        PrevBudget, NewBudget, PrevUtil, NewUtil, PrevLocked, NewLocked, Notes, ActionBy)
                      VALUES(@st, @sid, @pid, 'Locked', @amt, @pb, @nb, @pu, @nu, @pl, @nl, @notes, @u)",
                Db.P("@st", ptype), Db.P("@sid", srcId), Db.P("@pid", id),
                Db.P("@amt", approvedAmount),
                Db.P("@pb", prevBudget), Db.P("@nb", newBudget),
                Db.P("@pu", prevUtil),   Db.P("@nu", newUtil),
                Db.P("@pl", prevLocked), Db.P("@nl", newLocked),
                Db.P("@notes", "Approved by " + approver), Db.P("@u", approver));

            // Notify the Requestor: workflow has come back to them (Co-Pilot stage)
            if (!string.IsNullOrEmpty(requestor))
            {
                NotificationsDAL.Send(requestor, "Project approved - action required",
                    "Project " + p["ProjectCode"] + " approved at " + approvedAmount.ToString("N2") +
                    ". Proceed to Co-Pilot Integration.",
                    "~/Forms/CoPilotIntegration.aspx?projectId=" + id, id, "Approved");
            }
        }

        private void Msg(string m) { lblMsg.Visible = true; lblMsg.Text = m; }
    }
}
