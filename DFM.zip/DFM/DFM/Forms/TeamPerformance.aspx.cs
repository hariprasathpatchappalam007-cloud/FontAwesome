using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using DFM.App_Code.DAL;

namespace DFM.Forms
{
    public partial class TeamPerformance : System.Web.UI.Page
    {
        public string JsMgr { get; private set; }
        public string JsTech { get; private set; }
        public string JsChief { get; private set; }

        public TeamPerformance() { JsMgr = "[]"; JsTech = "[]"; JsChief = "[]"; }

        protected void Page_Load(object sender, EventArgs e)
        {
            JsMgr   = Build("Manager", 15);
            JsTech  = Build("TechLead", 15);
            JsChief = Build("Chief", 10);
            try
            {
                DataRow ts = Db.QueryRow("SELECT MAX(LastSyncDate) AS LastSync FROM DashboardSummary");
                litTs.Text = (ts != null && ts["LastSync"] != DBNull.Value)
                    ? Convert.ToDateTime(ts["LastSync"]).ToString("dd-MMM-yyyy hh:mm tt")
                    : DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt");
            }
            catch { litTs.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt"); }
        }

        private static string Build(string dim, int top)
        {
            try
            {
                DataTable dt = Db.Query("SELECT TOP " + top + " Bucket, OpenCount, ClosedCount FROM DashboardSummary WHERE Dimension=@dim ORDER BY (OpenCount+ClosedCount) DESC", new SqlParameter("@dim", dim));
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    sb.Append("{\"bucket\":\"").Append((dt.Rows[i]["Bucket"] ?? "").ToString().Replace("\\", "\\\\").Replace("\"", "\\\""))
                      .Append("\",\"open\":").Append(dt.Rows[i]["OpenCount"])
                      .Append(",\"closed\":").Append(dt.Rows[i]["ClosedCount"]).Append("}");
                }
                sb.Append("]");
                return sb.ToString();
            }
            catch { return "[]"; }
        }
    }
}
