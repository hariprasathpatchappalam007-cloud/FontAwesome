namespace DFM.Forms
{
    public partial class PetForm
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.DropDownList ddlProject;
        protected global::System.Web.UI.WebControls.DropDownList ddlMode;
        protected global::System.Web.UI.WebControls.Literal litBudgetSrc;
        protected global::System.Web.UI.WebControls.DropDownList ddlDept;
        protected global::System.Web.UI.WebControls.TextBox txtLineCode;
        protected global::System.Web.UI.WebControls.DropDownList ddlExpHead;
        protected global::System.Web.UI.WebControls.TextBox txtTopic;
        protected global::System.Web.UI.WebControls.TextBox txtVendor;
        protected global::System.Web.UI.WebControls.TextBox txtDesc;
        protected global::System.Web.UI.WebControls.DropDownList ddlCostType;
        protected global::System.Web.UI.WebControls.DropDownList ddlUnitType;
        protected global::System.Web.UI.WebControls.TextBox txtUnits;
        protected global::System.Web.UI.WebControls.TextBox txtPrice;
        protected global::System.Web.UI.WebControls.DropDownList ddlCcy;
        protected global::System.Web.UI.WebControls.TextBox txtContPct;
        protected global::System.Web.UI.WebControls.TextBox txtYrs;
        protected global::System.Web.UI.WebControls.TextBox txtComments;
        protected global::System.Web.UI.WebControls.Button btnAdd;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.GridView gv;
        protected global::System.Web.UI.WebControls.Literal litTotal;
    }
}
