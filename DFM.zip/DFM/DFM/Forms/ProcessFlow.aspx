<%@ Page Title="Business Process Flow" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ProcessFlow.aspx.cs" Inherits="DFM.Forms.ProcessFlow" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-random"></span> Business Process Flow</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <!-- Search / Filter -->
    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-search"></span> Search Demand</h3>
        <div class="filter-row">
            <div class="form-group col-span-2">
                <label>DMGT Issue Key</label>
                <asp:TextBox ID="txtDmgtKey" runat="server" CssClass="form-control" placeholder="e.g. DMGT-206" />
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <asp:Button ID="btnSearch" runat="server" Text="Load Hierarchy" CssClass="btn btn-primary" OnClick="btnSearch_Click" />
            </div>
            <div class="form-group col-span-2">
                <label>&nbsp;</label>
                <asp:Button ID="btnLoadAll" runat="server" Text="Show All Linked Demands" CssClass="btn btn-secondary" OnClick="btnLoadAll_Click" />
            </div>
        </div>
    </div>

    <!-- Hierarchy Display -->
    <asp:Panel ID="pnlHierarchy" runat="server" Visible="false">
    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-tree-conifer"></span> Demand → Project Hierarchy</h3>
        <p style="font-size:.85em;color:var(--text-muted);">
            DMGT (Demand) → DIBITP (Project/Child) → DIBITP (Grandchild). Click any node to expand details.
        </p>

        <!-- Flow Diagram -->
        <div id="processFlowContainer" style="overflow-x:auto; padding:20px 0;">
            <asp:Literal ID="litFlowHtml" runat="server" />
        </div>
    </div>

    <!-- Detail Panel -->
    <div class="card-panel" id="detailPanel" style="display:none;">
        <h3><span class="glyphicon glyphicon-info-sign"></span> Issue Details</h3>
        <div id="detailContent"></div>
    </div>

    <!-- RAG Status Summary -->
    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-signal"></span> RAG Status (derived from DIBITP hierarchy)</h3>
        <asp:Literal ID="litRagSummary" runat="server" />
    </div>
    </asp:Panel>

    <!-- All linked demands table -->
    <asp:Panel ID="pnlAll" runat="server" Visible="false">
    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list"></span> All Linked Demands (DMGT → DIBITP)</h3>
        <asp:GridView ID="gvAll" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            AllowPaging="true" PageSize="20" OnPageIndexChanging="gvAll_PageIndexChanging">
            <PagerStyle CssClass="pager" />
            <Columns>
                <asp:BoundField DataField="JiraKey" HeaderText="DMGT Key" />
                <asp:BoundField DataField="Summary" HeaderText="Summary" />
                <asp:BoundField DataField="Status" HeaderText="Status" />
                <asp:BoundField DataField="ParentJiraID" HeaderText="Parent Link" />
                <asp:BoundField DataField="ProjectKey" HeaderText="Project" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-primary" CommandName="ViewHierarchy"
                            CommandArgument='<%# Eval("JiraKey") %>' OnClick="btnViewHierarchy_Click">
                            <span class="glyphicon glyphicon-eye-open"></span> View
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
    </asp:Panel>

    <style>
        .flow-node { display:inline-block; border:2px solid #ccc; border-radius:8px; padding:12px 18px; margin:8px;
            min-width:180px; text-align:center; cursor:pointer; transition:all .2s; vertical-align:top; position:relative; }
        .flow-node:hover { box-shadow:0 4px 12px rgba(0,0,0,.15); transform:translateY(-2px); }
        .flow-node.parent { border-color:#1e40af; background:#eff6ff; }
        .flow-node.child { border-color:#0e7490; background:#ecfeff; }
        .flow-node.grandchild { border-color:#15803d; background:#f0fdf4; }
        .flow-node .node-key { font-weight:bold; font-size:1.05em; }
        .flow-node .node-status { font-size:.8em; margin-top:4px; }
        .flow-node .node-summary { font-size:.78em; color:#555; margin-top:4px; max-width:220px; overflow:hidden;
            text-overflow:ellipsis; white-space:nowrap; }
        .flow-arrow { display:inline-block; font-size:1.8em; color:#94a3b8; vertical-align:middle; margin:0 4px; }
        .flow-level { margin-bottom:16px; padding-left:40px; }
        .flow-level:first-child { padding-left:0; }
        .rag-badge { display:inline-block; padding:4px 14px; border-radius:4px; color:#fff; font-weight:bold; font-size:.9em; }
        .rag-red { background:#dc2626; }
        .rag-amber { background:#d97706; }
        .rag-green { background:#15803d; }
    </style>

    <script>
        function showDetail(key, summary, status, type) {
            var panel = document.getElementById('detailPanel');
            var content = document.getElementById('detailContent');
            if (panel && content) {
                content.innerHTML = '<table class="dfm-table" style="width:auto;"><tr><th>Key</th><td>' +
                    key + '</td></tr><tr><th>Summary</th><td>' + summary +
                    '</td></tr><tr><th>Status</th><td>' + status +
                    '</td></tr><tr><th>Type</th><td>' + type + '</td></tr></table>';
                panel.style.display = 'block';
                panel.scrollIntoView({ behavior: 'smooth' });
            }
        }
    </script>
</asp:Content>
