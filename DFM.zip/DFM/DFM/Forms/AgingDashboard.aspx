<%@ Page Title="Aging Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="AgingDashboard.aspx.cs" Inherits="DFM.Forms.AgingDashboard" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-hourglass"></span> Aging Dashboard
        <span class="dashboard-timestamp"><span class="glyphicon glyphicon-refresh"></span>
            Data Last Updated: <asp:Literal ID="litTs" runat="server" /></span>
    </h1>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-time"></span> Open Demand Aging Buckets</h3>
        <div id="hcAging" style="height:380px;"></div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list"></span> Aged Demands (3+ months still open)</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            AllowPaging="true" PageSize="20" OnPageIndexChanging="gv_Paging">
            <PagerStyle CssClass="pager" />
            <Columns>
                <asp:BoundField DataField="JiraKey" HeaderText="Key" />
                <asp:BoundField DataField="Summary" HeaderText="Summary" />
                <asp:BoundField DataField="Status" HeaderText="Status" />
                <asp:BoundField DataField="MonthsOpen" HeaderText="Months Open" />
                <asp:BoundField DataField="Manager" HeaderText="Manager" />
                <asp:BoundField DataField="TechLead" HeaderText="Tech Lead" />
            </Columns>
        </asp:GridView>
    </div>

    <script>
        (function () {
            var aging = <%= JsAging %>;
            if (window.Highcharts && aging.length && document.getElementById('hcAging')) {
                Highcharts.chart('hcAging', {
                    chart: { type: 'column' }, title: { text: null },
                    xAxis: { type: 'category' }, yAxis: { title: { text: 'Open Demands' }, allowDecimals: false },
                    legend: { enabled: false },
                    plotOptions: { series: { dataLabels: { enabled: true } } },
                    series: [{ name: 'Open', data: aging.map(function(a){
                        var c = a.bucket==='0-3 months'?'#15803d': a.bucket==='3-6 months'?'#d97706':
                                a.bucket==='7-12 months'?'#dc2626':'#7c2d12';
                        return { name: a.bucket, y: a.total, color: c };
                    }), colorByPoint: false }]
                });
            }
        })();
    </script>
</asp:Content>
