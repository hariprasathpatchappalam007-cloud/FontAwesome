namespace DFM.Forms
{
    public partial class ProjectHealth
    {
        protected global::System.Web.UI.WebControls.Literal litTs;
        protected global::System.Web.UI.WebControls.Literal kGreen;
        protected global::System.Web.UI.WebControls.Literal kAmber;
        protected global::System.Web.UI.WebControls.Literal kRed;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
