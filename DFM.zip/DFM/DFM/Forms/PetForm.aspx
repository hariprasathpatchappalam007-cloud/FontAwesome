<%@ Page Title="PET Form" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="PetForm.aspx.cs" Inherits="DFM.Forms.PetForm" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-th"></span> PET Form</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-folder-open"></span> Project</h3>
        <div class="form-row">
            <div class="form-group">
                <label>Project</label>
                <asp:DropDownList ID="ddlProject" runat="server" CssClass="form-control"
                    AutoPostBack="true" OnSelectedIndexChanged="ddlProject_Changed" />
            </div>
            <div class="form-group">
                <label>Mode</label>
                <asp:DropDownList ID="ddlMode" runat="server" CssClass="form-control">
                    <asp:ListItem Value="New">New Project Registration</asp:ListItem>
                    <asp:ListItem Value="ExistingUpdate">Existing Project Update</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>CAPEX (mandatory) / OPEX</label>
                <asp:Literal ID="litBudgetSrc" runat="server" />
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-plus"></span> Add line item</h3>
        <p class="text-muted">Field guidance is loaded from <code>PET Guidance.csv</code>. Cost Type and Department come from the PET masters.</p>

        <div class="form-row">
            <div class="form-group">
                <label>Department</label>
                <asp:DropDownList ID="ddlDept" runat="server" CssClass="form-control"
                    AutoPostBack="true" OnSelectedIndexChanged="ddlDept_Changed" />
            </div>
            <div class="form-group">
                <label>Auto-generated ID</label>
                <asp:TextBox ID="txtLineCode" runat="server" CssClass="form-control no-select2" ReadOnly="true" />
            </div>
            <div class="form-group">
                <label>Exp. Head</label>
                <asp:DropDownList ID="ddlExpHead" runat="server" CssClass="form-control">
                    <asp:ListItem>Capex</asp:ListItem>
                    <asp:ListItem>Opex</asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Topic</label>
                <asp:TextBox ID="txtTopic" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Vendor</label>
                <asp:TextBox ID="txtVendor" runat="server" CssClass="form-control" placeholder="TBD if not yet known" />
            </div>
        </div>

        <div class="form-row">
            <div class="form-group" style="flex:1 1 100%;">
                <label>Description</label>
                <asp:TextBox ID="txtDesc" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" />
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label>Cost Type</label>
                <asp:DropDownList ID="ddlCostType" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group" style="flex:0 0 180px;">
                <label>Unit Type</label>
                <asp:DropDownList ID="ddlUnitType" runat="server" CssClass="form-control">
                    <asp:ListItem>Man Days</asp:ListItem>
                    <asp:ListItem>Man Months</asp:ListItem>
                    <asp:ListItem>Hours</asp:ListItem>
                    <asp:ListItem>License</asp:ListItem>
                    <asp:ListItem>Lump Sum</asp:ListItem>
                    <asp:ListItem>Per Unit</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group" style="flex:0 0 110px;">
                <label>Units</label>
                <asp:TextBox ID="txtUnits" runat="server" CssClass="form-control" Text="0" />
            </div>
            <div class="form-group" style="flex:0 0 130px;">
                <label>Unit Price</label>
                <asp:TextBox ID="txtPrice" runat="server" CssClass="form-control" Text="0" />
            </div>
            <div class="form-group" style="flex:0 0 130px;">
                <label>Base CY</label>
                <asp:DropDownList ID="ddlCcy" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group" style="flex:0 0 110px;">
                <label>Cont. %</label>
                <asp:TextBox ID="txtContPct" runat="server" CssClass="form-control" Text="0" />
            </div>
            <div class="form-group" style="flex:0 0 110px;">
                <label>Yrs Recur.</label>
                <asp:TextBox ID="txtYrs" runat="server" CssClass="form-control" Text="1" />
            </div>
        </div>

        <div class="form-row">
            <div class="form-group" style="flex:1 1 100%;">
                <label>Comments</label>
                <asp:TextBox ID="txtComments" runat="server" CssClass="form-control" />
            </div>
        </div>

        <div class="toolbar">
            <asp:Button ID="btnAdd" runat="server" Text="Add Line" CssClass="btn btn-primary" OnClick="btnAdd_Click" />
            <div class="spacer"></div>
            <asp:Button ID="btnExport" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list-alt"></span> Line items</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table"
                GridLines="None" DataKeyNames="PetID" OnRowCommand="gv_RowCommand">
                <Columns>
                    <asp:BoundField DataField="SerialNo" HeaderText="#" />
                    <asp:BoundField DataField="LineDate" HeaderText="Date" DataFormatString="{0:dd-MMM-yy}" />
                    <asp:BoundField DataField="Department" HeaderText="Dept." />
                    <asp:BoundField DataField="LineCode" HeaderText="ID" />
                    <asp:BoundField DataField="ExpHead" HeaderText="Exp. Head" />
                    <asp:BoundField DataField="Topic" HeaderText="Topic" />
                    <asp:BoundField DataField="Vendor" HeaderText="Vendor" />
                    <asp:BoundField DataField="CostType" HeaderText="Cost Type" />
                    <asp:BoundField DataField="UnitType" HeaderText="Unit Type" />
                    <asp:BoundField DataField="Units" HeaderText="Units" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="UnitPrice" HeaderText="Unit Price" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="BaseCurrency" HeaderText="CY" />
                    <asp:BoundField DataField="AmtFCY" HeaderText="Amt FCY" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="AmtLCY" HeaderText="Amt LCY" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="ContingencyPct" HeaderText="Cont %" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="FinalAmtLCY" HeaderText="Final LCY" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="YearlyRecurrence" HeaderText="Yrs" />
                    <asp:TemplateField HeaderText="Action">
                        <ItemTemplate>
                            <asp:LinkButton runat="server" CssClass="btn btn-sm btn-danger" CommandName="DeleteRow"
                                CommandArgument='<%# Eval("PetID") %>'
                                OnClientClick="return confirm('Delete this line?');">
                                <span class="glyphicon glyphicon-trash"></span>
                            </asp:LinkButton>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:18px;">No line items yet.</div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>

        <div class="text-right mt-2" style="font-weight:800; font-size:1.1em; color:var(--heading);">
            Total Final Amount LCY: <asp:Literal ID="litTotal" runat="server" />
        </div>
    </div>
</asp:Content>
