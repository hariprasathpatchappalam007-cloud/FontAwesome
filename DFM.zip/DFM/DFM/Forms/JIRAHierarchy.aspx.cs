using System;
using System.Data;
using System.Text;
using DFM.App_Code.DAL;

namespace DFM.Forms
{
    public partial class JIRAHierarchy : System.Web.UI.Page
    {
        public string JsNodes { get; private set; }
        public JIRAHierarchy() { JsNodes = "[]"; }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = Db.Query(@"SELECT TOP 200 JiraKey, ISNULL(ParentJiraID,'') AS Parent
                    FROM JiraIssues WHERE ISNULL(ParentJiraID,'') <> ''");
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    sb.Append("{\"key\":\"").Append(dt.Rows[i]["JiraKey"]).Append("\",\"parent\":\"")
                      .Append(dt.Rows[i]["Parent"]).Append("\"}");
                }
                sb.Append("]");
                JsNodes = sb.ToString();
                DataRow ts = Db.QueryRow("SELECT MAX(LastSyncDate) AS LastSync FROM DashboardSummary");
                litTs.Text = (ts != null && ts["LastSync"] != DBNull.Value)
                    ? Convert.ToDateTime(ts["LastSync"]).ToString("dd-MMM-yyyy hh:mm tt")
                    : DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt");
            }
            catch { litTs.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt"); }
        }
    }
}
