namespace DFM.Forms
{
    public partial class MyApprovals
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.GridView gvPending;
        protected global::System.Web.UI.WebControls.GridView gvDone;
    }
}
