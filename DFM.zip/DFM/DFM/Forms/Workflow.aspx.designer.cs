namespace DFM.Forms
{
    public partial class Workflow
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.HiddenField hfOpenSections;
        protected global::System.Web.UI.WebControls.HiddenField hfFocus;
        protected global::System.Web.UI.WebControls.HiddenField hfScroll;
        protected global::System.Web.UI.WebControls.Panel pnlProjectActions;
        protected global::System.Web.UI.WebControls.Panel pnlPetAddActions;
        protected global::System.Web.UI.WebControls.Panel pnlPetSubmitActions;
        protected global::System.Web.UI.WebControls.Panel pnlApprovalActions;
        protected global::System.Web.UI.WebControls.Panel pnlBpmActions;

        // JIRA top
        protected global::System.Web.UI.WebControls.Literal litJiraId;
        protected global::System.Web.UI.WebControls.Literal litJiraName;
        protected global::System.Web.UI.WebControls.Literal litJStatus;
        protected global::System.Web.UI.WebControls.Literal litJProjectName;
        protected global::System.Web.UI.WebControls.Literal litJProjectType;
        protected global::System.Web.UI.WebControls.Literal litJDemand;
        protected global::System.Web.UI.WebControls.Literal litJRag;
        protected global::System.Web.UI.WebControls.Literal litJStage;
        protected global::System.Web.UI.WebControls.Literal litJDept;
        protected global::System.Web.UI.WebControls.Literal litJClassification;
        protected global::System.Web.UI.WebControls.Literal litJPlatform;
        protected global::System.Web.UI.WebControls.Literal litJPlatformVertical;
        protected global::System.Web.UI.WebControls.Literal litJIssueType;
        protected global::System.Web.UI.WebControls.Literal litJMgr;
        protected global::System.Web.UI.WebControls.Literal litJTech;
        protected global::System.Web.UI.WebControls.Literal litJSponsor;
        protected global::System.Web.UI.WebControls.Literal litJStakeholder;
        protected global::System.Web.UI.WebControls.Literal litJAssignee;
        protected global::System.Web.UI.WebControls.Literal litJReporter;
        protected global::System.Web.UI.WebControls.Literal litJAccExecLead;
        protected global::System.Web.UI.WebControls.Literal litJSmeLead;
        protected global::System.Web.UI.WebControls.Literal litJAccExec;
        protected global::System.Web.UI.WebControls.Literal litJPortfolioHead;
        protected global::System.Web.UI.WebControls.Literal litJAssignedPM;
        protected global::System.Web.UI.WebControls.Literal litJDemandOwner;
        protected global::System.Web.UI.WebControls.Literal litJChief;
        protected global::System.Web.UI.WebControls.Literal litJPrimaryClass;
        protected global::System.Web.UI.WebControls.Literal litJCreated;
        protected global::System.Web.UI.WebControls.Literal litJUpdated;
        protected global::System.Web.UI.WebControls.Literal litJStart;
        protected global::System.Web.UI.WebControls.Literal litJEnd;

        protected global::System.Web.UI.WebControls.Literal litStepper;

        // Project section
        protected global::System.Web.UI.WebControls.DropDownList ddlJira;
        protected global::System.Web.UI.WebControls.TextBox txtName;
        protected global::System.Web.UI.WebControls.DropDownList ddlType;
        protected global::System.Web.UI.WebControls.DropDownList ddlGL;
        protected global::System.Web.UI.WebControls.Literal litSourceLabel;
        protected global::System.Web.UI.WebControls.DropDownList ddlSource;
        protected global::System.Web.UI.WebControls.DropDownList ddlApprover;
        protected global::System.Web.UI.WebControls.Panel pnlBudget;
        protected global::System.Web.UI.WebControls.Literal bBudget;
        protected global::System.Web.UI.WebControls.Literal bUtil;
        protected global::System.Web.UI.WebControls.Literal bAvail;
        protected global::System.Web.UI.WebControls.Literal bLock;
        protected global::System.Web.UI.WebControls.Literal bNet;
        protected global::System.Web.UI.WebControls.LinkButton btnSaveProject;
        protected global::System.Web.UI.WebControls.LinkButton btnSubmitProject;

        // PET section
        protected global::System.Web.UI.WebControls.Panel pnlPet;
        protected global::System.Web.UI.WebControls.Literal litPetVersions;
        protected global::System.Web.UI.WebControls.Literal litPetVersionTable;
        protected global::System.Web.UI.WebControls.Literal litPendingWithBanner;
        protected global::System.Web.UI.WebControls.LinkButton btnPetDownload;
        protected global::System.Web.UI.WebControls.LinkButton btnPetTemplate;
        protected global::System.Web.UI.WebControls.FileUpload fuPetCsv;
        protected global::System.Web.UI.WebControls.LinkButton btnPetUpload;
        protected global::System.Web.UI.WebControls.DropDownList ddlDept;
        protected global::System.Web.UI.WebControls.DropDownList ddlCostType;
        protected global::System.Web.UI.WebControls.DropDownList ddlExpHead;
        protected global::System.Web.UI.WebControls.TextBox txtTopic;
        protected global::System.Web.UI.WebControls.TextBox txtVendor;
        protected global::System.Web.UI.WebControls.TextBox txtDesc;
        protected global::System.Web.UI.WebControls.TextBox txtUnits;
        protected global::System.Web.UI.WebControls.TextBox txtUnitPrice;
        protected global::System.Web.UI.WebControls.DropDownList ddlCurrency;
        protected global::System.Web.UI.WebControls.TextBox txtAmtFcy;
        protected global::System.Web.UI.WebControls.TextBox txtAmtAed;
        protected global::System.Web.UI.WebControls.HiddenField hfEditPetId;
        protected global::System.Web.UI.WebControls.LinkButton btnAddPet;
        protected global::System.Web.UI.WebControls.LinkButton btnUpdatePet;
        protected global::System.Web.UI.WebControls.LinkButton btnCancelEdit;
        protected global::System.Web.UI.WebControls.Literal litPetTotal;
        protected global::System.Web.UI.WebControls.GridView gvPet;
        protected global::System.Web.UI.WebControls.LinkButton btnSubmitPet;

        // PET Approval
        protected global::System.Web.UI.WebControls.Panel pnlPetApproval;
        protected global::System.Web.UI.WebControls.TextBox txtPetTotal;
        protected global::System.Web.UI.WebControls.TextBox txtApprovedAmount;
        protected global::System.Web.UI.WebControls.HiddenField txtApproveComment;
        protected global::System.Web.UI.WebControls.LinkButton btnApprovePet;
        protected global::System.Web.UI.WebControls.LinkButton btnRejectPet;

        // BPM / Internal Memo
        protected global::System.Web.UI.WebControls.Panel pnlBpm;
        protected global::System.Web.UI.WebControls.TextBox txtMemoNumber;
        protected global::System.Web.UI.WebControls.TextBox txtMemoAmount;
        protected global::System.Web.UI.WebControls.DropDownList ddlMemoVendor;
        protected global::System.Web.UI.WebControls.TextBox txtMemoDateRaised;
        protected global::System.Web.UI.WebControls.TextBox txtMemoLPO;
        protected global::System.Web.UI.WebControls.TextBox txtMemoPODate;
        protected global::System.Web.UI.WebControls.TextBox txtMemoAMS;
        protected global::System.Web.UI.WebControls.TextBox txtMemoDesc;
        protected global::System.Web.UI.WebControls.HiddenField hfEditMemoId;
        protected global::System.Web.UI.WebControls.LinkButton btnAddMemo;
        protected global::System.Web.UI.WebControls.LinkButton btnCancelMemoEdit;
        protected global::System.Web.UI.WebControls.LinkButton btnMemoTemplate;
        protected global::System.Web.UI.WebControls.FileUpload fuMemoCsv;
        protected global::System.Web.UI.WebControls.LinkButton btnMemoUpload;
        protected global::System.Web.UI.WebControls.GridView gvMemos;
        protected global::System.Web.UI.WebControls.Panel pnlInvoices;
        protected global::System.Web.UI.WebControls.Literal litInvoiceMemoRef;
        protected global::System.Web.UI.WebControls.TextBox txtInvMemoNum;
        protected global::System.Web.UI.WebControls.TextBox txtInvNumber;
        protected global::System.Web.UI.WebControls.TextBox txtInvAmount;
        protected global::System.Web.UI.WebControls.TextBox txtInvDate;
        protected global::System.Web.UI.WebControls.TextBox txtInvEntryDate;
        protected global::System.Web.UI.WebControls.DropDownList ddlInvStatus;
        protected global::System.Web.UI.WebControls.TextBox txtInvDesc;
        protected global::System.Web.UI.WebControls.HiddenField hfEditInvoiceId;
        protected global::System.Web.UI.WebControls.HiddenField hfSelectedMemoId;
        protected global::System.Web.UI.WebControls.LinkButton btnAddInvoice;
        protected global::System.Web.UI.WebControls.LinkButton btnInvoiceTemplate;
        protected global::System.Web.UI.WebControls.FileUpload fuInvoiceCsv;
        protected global::System.Web.UI.WebControls.LinkButton btnInvoiceUpload;
        protected global::System.Web.UI.WebControls.GridView gvInvoices;
        protected global::System.Web.UI.WebControls.Literal litMemoLPOTotal;
        protected global::System.Web.UI.WebControls.Literal litMemoDisbursed;
        protected global::System.Web.UI.WebControls.Literal litMemoPending;
        protected global::System.Web.UI.WebControls.Literal litMemoPctUtil;
        protected global::System.Web.UI.WebControls.Literal litMemoPctRem;
        protected global::System.Web.UI.WebControls.Panel pnlBpmClose;
        protected global::System.Web.UI.WebControls.HiddenField txtBpmNotes;
        protected global::System.Web.UI.WebControls.LinkButton btnCloseBpm;

        // Attachments
        protected global::System.Web.UI.WebControls.Panel pnlAttach;
        protected global::System.Web.UI.WebControls.FileUpload fuAttach;
        protected global::System.Web.UI.WebControls.DropDownList ddlAttachStage;
        protected global::System.Web.UI.WebControls.LinkButton btnUploadAttach;
        protected global::System.Web.UI.WebControls.Repeater rptAttach;

        // History
        protected global::System.Web.UI.WebControls.GridView gvHistory;
        protected global::System.Web.UI.WebControls.Panel pnlNoHistory;
    }
}
