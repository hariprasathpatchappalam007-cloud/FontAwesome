namespace DFM.Forms
{
    public partial class Workflow
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.HiddenField hfOpenSections;
        protected global::System.Web.UI.WebControls.HiddenField hfFocus;
        protected global::System.Web.UI.WebControls.HiddenField hfScroll;
        protected global::System.Web.UI.WebControls.Panel pnlProjectActions;
        protected global::System.Web.UI.WebControls.Panel pnlPetAddActions;
        protected global::System.Web.UI.WebControls.Panel pnlPetSubmitActions;
        protected global::System.Web.UI.WebControls.Panel pnlApprovalActions;
        protected global::System.Web.UI.WebControls.Panel pnlBpmActions;

        // JIRA top
        protected global::System.Web.UI.WebControls.Literal litJiraId;
        protected global::System.Web.UI.WebControls.Literal litJiraName;
        protected global::System.Web.UI.WebControls.Literal litJStage;
        protected global::System.Web.UI.WebControls.Literal litJRag;
        protected global::System.Web.UI.WebControls.Literal litJDemand;
        protected global::System.Web.UI.WebControls.Literal litJMgr;
        protected global::System.Web.UI.WebControls.Literal litJTech;
        protected global::System.Web.UI.WebControls.Literal litJSponsor;
        protected global::System.Web.UI.WebControls.Literal litJDept;
        protected global::System.Web.UI.WebControls.Literal litJStart;
        protected global::System.Web.UI.WebControls.Literal litJEnd;
        protected global::System.Web.UI.WebControls.Literal litJStatus;

        protected global::System.Web.UI.WebControls.Literal litStepper;

        // Project section
        protected global::System.Web.UI.WebControls.DropDownList ddlJira;
        protected global::System.Web.UI.WebControls.TextBox txtName;
        protected global::System.Web.UI.WebControls.DropDownList ddlType;
        protected global::System.Web.UI.WebControls.DropDownList ddlUpdateMode;
        protected global::System.Web.UI.WebControls.Literal litSourceLabel;
        protected global::System.Web.UI.WebControls.DropDownList ddlSource;
        protected global::System.Web.UI.WebControls.TextBox txtAmount;
        protected global::System.Web.UI.WebControls.DropDownList ddlApprover;
        protected global::System.Web.UI.WebControls.Panel pnlBudget;
        protected global::System.Web.UI.WebControls.Literal bBudget;
        protected global::System.Web.UI.WebControls.Literal bUtil;
        protected global::System.Web.UI.WebControls.Literal bAvail;
        protected global::System.Web.UI.WebControls.Literal bLock;
        protected global::System.Web.UI.WebControls.Literal bNet;
        protected global::System.Web.UI.WebControls.LinkButton btnSaveProject;
        protected global::System.Web.UI.WebControls.LinkButton btnSubmitProject;

        // PET section
        protected global::System.Web.UI.WebControls.Panel pnlPet;
        protected global::System.Web.UI.WebControls.LinkButton btnPetDownload;
        protected global::System.Web.UI.WebControls.LinkButton btnPetTemplate;
        protected global::System.Web.UI.WebControls.FileUpload fuPetCsv;
        protected global::System.Web.UI.WebControls.LinkButton btnPetUpload;
        protected global::System.Web.UI.WebControls.DropDownList ddlDept;
        protected global::System.Web.UI.WebControls.DropDownList ddlCostType;
        protected global::System.Web.UI.WebControls.DropDownList ddlExpHead;
        protected global::System.Web.UI.WebControls.TextBox txtTopic;
        protected global::System.Web.UI.WebControls.TextBox txtVendor;
        protected global::System.Web.UI.WebControls.TextBox txtDesc;
        protected global::System.Web.UI.WebControls.TextBox txtUnits;
        protected global::System.Web.UI.WebControls.TextBox txtUnitPrice;
        protected global::System.Web.UI.WebControls.DropDownList ddlCurrency;
        protected global::System.Web.UI.WebControls.TextBox txtAmtFcy;
        protected global::System.Web.UI.WebControls.TextBox txtAmtAed;
        protected global::System.Web.UI.WebControls.HiddenField hfEditPetId;
        protected global::System.Web.UI.WebControls.LinkButton btnAddPet;
        protected global::System.Web.UI.WebControls.LinkButton btnUpdatePet;
        protected global::System.Web.UI.WebControls.LinkButton btnCancelEdit;
        protected global::System.Web.UI.WebControls.Literal litPetTotal;
        protected global::System.Web.UI.WebControls.GridView gvPet;
        protected global::System.Web.UI.WebControls.LinkButton btnSubmitPet;

        // PET Approval
        protected global::System.Web.UI.WebControls.Panel pnlPetApproval;
        protected global::System.Web.UI.WebControls.TextBox txtPetTotal;
        protected global::System.Web.UI.WebControls.TextBox txtApprovedAmount;
        protected global::System.Web.UI.WebControls.HiddenField txtApproveComment;
        protected global::System.Web.UI.WebControls.LinkButton btnApprovePet;
        protected global::System.Web.UI.WebControls.LinkButton btnRejectPet;

        // BPM
        protected global::System.Web.UI.WebControls.Panel pnlBpm;
        protected global::System.Web.UI.WebControls.TextBox txtBpmRef;
        protected global::System.Web.UI.WebControls.TextBox txtInvoiceNo;
        protected global::System.Web.UI.WebControls.TextBox txtInvoiceDate;
        protected global::System.Web.UI.WebControls.TextBox txtInvoiceAmount;
        protected global::System.Web.UI.WebControls.TextBox txtBpmVendor;
        protected global::System.Web.UI.WebControls.HiddenField txtBpmNotes;
        protected global::System.Web.UI.WebControls.LinkButton btnSubmitBpm;
        protected global::System.Web.UI.WebControls.LinkButton btnCloseBpm;

        // Attachments
        protected global::System.Web.UI.WebControls.Panel pnlAttach;
        protected global::System.Web.UI.WebControls.FileUpload fuAttach;
        protected global::System.Web.UI.WebControls.DropDownList ddlAttachStage;
        protected global::System.Web.UI.WebControls.LinkButton btnUploadAttach;
        protected global::System.Web.UI.WebControls.Repeater rptAttach;

        // History
        protected global::System.Web.UI.WebControls.GridView gvHistory;
        protected global::System.Web.UI.WebControls.Panel pnlNoHistory;
    }
}
