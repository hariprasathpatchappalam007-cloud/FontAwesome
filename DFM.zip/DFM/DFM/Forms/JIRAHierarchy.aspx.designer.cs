namespace DFM.Forms
{
    public partial class JIRAHierarchy
    {
        protected global::System.Web.UI.WebControls.Literal litTs;
    }
}
