using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Script.Serialization;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class JiraIntegration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }

        private void Bind()
        {
            gv.DataSource = JiraClient.GetCachedIssues();
            gv.DataBind();
        }

        protected void btnFetch_Click(object sender, EventArgs e)
        {
            string jql = string.IsNullOrWhiteSpace(txtJql.Text)
                ? "project = " + JiraClient.GetConfig().ProjectKey + " ORDER BY updated DESC"
                : txtJql.Text;

            try
            {
                var issues = JiraClient.SearchIssues(jql, 100);
                int count = 0;
                foreach (Dictionary<string, object> issue in issues)
                {
                    string id = null;
                    if (issue.ContainsKey("key") && issue["key"] != null) id = issue["key"].ToString();
                    if (string.IsNullOrEmpty(id)) continue;

                    string summary = "";
                    string fieldsJson = "";
                    Dictionary<string, object> fields = issue.ContainsKey("fields")
                        ? issue["fields"] as Dictionary<string, object> : null;
                    if (fields != null)
                    {
                        if (fields.ContainsKey("summary") && fields["summary"] != null)
                            summary = fields["summary"].ToString();
                        JavaScriptSerializer jss = new JavaScriptSerializer();
                        jss.MaxJsonLength = int.MaxValue;
                        fieldsJson = jss.Serialize(fields);
                    }

                    Db.Exec(@"
IF EXISTS (SELECT 1 FROM JiraIssues WHERE JiraID=@id)
    UPDATE JiraIssues SET Summary=@s, ProjectName=@s, CustomFieldsJson=@j, UpdatedDate=GETDATE() WHERE JiraID=@id
ELSE
    INSERT INTO JiraIssues(JiraID, Summary, ProjectName, CustomFieldsJson) VALUES(@id, @s, @s, @j);",
                        Db.P("@id", id), Db.P("@s", summary), Db.P("@j", fieldsJson));
                    count++;
                }
                lblMsg.Visible = true;
                lblMsg.Text = "Fetched / updated " + count + " issue(s) from JIRA.";
                Bind();
            }
            catch (Exception ex)
            {
                lblMsg.Visible = true;
                lblMsg.Text = "JIRA fetch failed (showing cached data): " + ex.Message;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = JiraClient.GetCachedIssues();
            ExcelHelper.ExportToExcel(Response, dt, "JIRA_Issues_" + DateTime.Now.ToString("yyyyMMdd"));
        }
    }
}
