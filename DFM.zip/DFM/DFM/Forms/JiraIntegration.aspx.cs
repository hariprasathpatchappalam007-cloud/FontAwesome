using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class JiraIntegration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadFilters();
                Bind();
            }
        }

        private void LoadFilters()
        {
            DataTable dt = JiraClient.GetCachedIssues();
            var stages = new HashSet<string>();
            var rags = new HashSet<string>();
            foreach (DataRow r in dt.Rows)
            {
                if (r["ProjectStage"] != DBNull.Value)
                {
                    string v = r["ProjectStage"].ToString();
                    if (!string.IsNullOrEmpty(v)) stages.Add(v);
                }
                if (r["ProjectRAG"] != DBNull.Value)
                {
                    string v = r["ProjectRAG"].ToString();
                    if (!string.IsNullOrEmpty(v)) rags.Add(v);
                }
            }
            foreach (string s in stages) ddlFStage.Items.Add(new ListItem(s, s));
            foreach (string s in rags) ddlFRag.Items.Add(new ListItem(s, s));
        }

        private void Bind()
        {
            DataTable dt = JiraClient.GetCachedIssues();
            DataView dv = new DataView(dt);
            StringBuilder rf = new StringBuilder();
            string fid = (txtFId.Text ?? "").Trim();
            string fname = (txtFName.Text ?? "").Trim();
            string fstage = ddlFStage.SelectedValue;
            string frag = ddlFRag.SelectedValue;
            if (fid.Length > 0) rf.Append("JiraID LIKE '%" + fid.Replace("'", "''") + "%'");
            if (fname.Length > 0)
            {
                if (rf.Length > 0) rf.Append(" AND ");
                rf.Append("ProjectName LIKE '%" + fname.Replace("'", "''") + "%'");
            }
            if (!string.IsNullOrEmpty(fstage))
            {
                if (rf.Length > 0) rf.Append(" AND ");
                rf.Append("ProjectStage='" + fstage.Replace("'", "''") + "'");
            }
            if (!string.IsNullOrEmpty(frag))
            {
                if (rf.Length > 0) rf.Append(" AND ");
                rf.Append("ProjectRAG='" + frag.Replace("'", "''") + "'");
            }
            if (rf.Length > 0) dv.RowFilter = rf.ToString();
            gv.DataSource = dv;
            gv.DataBind();
        }

        protected void Filter_Changed(object sender, EventArgs e) { gv.PageIndex = 0; Bind(); }
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv.PageIndex = e.NewPageIndex;
            Bind();
        }

        // ====== JSON helpers ======
        private string GetNestedValue(Dictionary<string, object> dict, string key)
        {
            if (dict == null || !dict.ContainsKey(key) || dict[key] == null) return "";
            return dict[key].ToString();
        }
        private string GetNestedDictValue(Dictionary<string, object> dict, string key, string subKey)
        {
            if (dict == null || !dict.ContainsKey(key) || dict[key] == null) return "";
            var nested = dict[key] as Dictionary<string, object>;
            if (nested == null || !nested.ContainsKey(subKey) || nested[subKey] == null) return "";
            return nested[subKey].ToString();
        }
        // Best-effort scan: find any key/name that looks like a Platform field.
        private string ScanForPlatform(Dictionary<string, object> fields)
        {
            if (fields == null) return "";
            foreach (var kv in fields)
            {
                if (kv.Value == null) continue;
                string k = kv.Key.ToLowerInvariant();
                if (k.Contains("platform"))
                {
                    var d = kv.Value as Dictionary<string, object>;
                    if (d != null)
                    {
                        if (d.ContainsKey("value") && d["value"] != null) return d["value"].ToString();
                        if (d.ContainsKey("name") && d["name"] != null) return d["name"].ToString();
                    }
                    var s = kv.Value as string;
                    if (!string.IsNullOrEmpty(s)) return s;
                }
            }
            return "";
        }

        private object NullableDate(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return DBNull.Value;
            DateTime d;
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out d))
                return d;
            if (DateTime.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d))
                return d;
            return DBNull.Value;
        }

        /// <summary>
        /// Compute RAG from Target Completion Date.
        ///   days remaining &gt; 30           => Red
        ///   3 &lt; days remaining &lt; 30    => Amber
        ///   otherwise                        => Green
        /// </summary>
        private static string ComputeRag(object targetDate)
        {
            if (targetDate == null || targetDate == DBNull.Value) return "Green";
            DateTime d = Convert.ToDateTime(targetDate);
            int days = (int)Math.Floor((d.Date - DateTime.Today).TotalDays);
            if (days > 30) return "Red";
            if (days > 3)  return "Amber";
            return "Green";
        }

        protected void btnFetch_Click(object sender, EventArgs e)
        {
            string jql = string.IsNullOrWhiteSpace(txtJql.Text)
                ? "project = " + JiraClient.GetConfig().ProjectKey + " ORDER BY updated DESC"
                : txtJql.Text;

            try
            {
                var issues = JiraClient.SearchIssues(jql, 100);
                int count = 0;
                foreach (Dictionary<string, object> issue in issues)
                {
                    string id = null;
                    if (issue.ContainsKey("key") && issue["key"] != null) id = issue["key"].ToString();
                    if (string.IsNullOrEmpty(id)) continue;

                    string summary = "";
                    string fieldsJson = "";
                    string status = "", project = "", issueType = "", assignee = "", reporter = "";
                    string accExecLead = "", smeLead = "", accExec = "", idhPortfolioHead = "";
                    string assignedPm = "", demandOwner = "", chiefNameMapping = "", demandType = "";
                    string createdStr = "", updatedStr = "", targetCompletionDate = "", proposedDemandPickup = "";
                    string platform = "";

                    Dictionary<string, object> fields = issue.ContainsKey("fields")
                        ? issue["fields"] as Dictionary<string, object> : null;
                    if (fields != null)
                    {
                        if (fields.ContainsKey("summary") && fields["summary"] != null)
                            summary = fields["summary"].ToString();
                        JavaScriptSerializer jss = new JavaScriptSerializer();
                        jss.MaxJsonLength = int.MaxValue;
                        fieldsJson = jss.Serialize(fields);

                        status                = GetNestedDictValue(fields, "status",   "name");
                        project               = GetNestedDictValue(fields, "project",  "name");
                        issueType             = GetNestedDictValue(fields, "issuetype","name");
                        assignee              = GetNestedDictValue(fields, "assignee", "displayName");
                        reporter              = GetNestedDictValue(fields, "reporter", "displayName");
                        accExecLead           = GetNestedDictValue(fields, "customfield_13357", "displayName");
                        smeLead               = GetNestedDictValue(fields, "customfield_13358", "displayName");
                        accExec               = GetNestedDictValue(fields, "customfield_13379", "displayName");
                        idhPortfolioHead      = GetNestedDictValue(fields, "customfield_13376", "displayName");
                        assignedPm            = GetNestedDictValue(fields, "customfield_12603", "displayName");
                        demandOwner           = GetNestedDictValue(fields, "customfield_13317", "displayName");
                        chiefNameMapping      = GetNestedDictValue(fields, "customfield_14001", "displayName");
                        demandType            = GetNestedDictValue(fields, "customfield_13339", "value");
                        createdStr            = GetNestedValue(fields, "created");
                        updatedStr            = GetNestedValue(fields, "updated");
                        targetCompletionDate  = GetNestedValue(fields, "customfield_13306");
                        proposedDemandPickup  = GetNestedValue(fields, "customfield_13359");

                        // Platform - check the common customfield IDs and fall back to any
                        // field whose key/name contains "platform" so the dashboard buckets work.
                        if (string.IsNullOrEmpty(platform))
                            platform = GetNestedDictValue(fields, "customfield_10043", "value");
                        if (string.IsNullOrEmpty(platform))
                            platform = GetNestedDictValue(fields, "customfield_10044", "value");
                        if (string.IsNullOrEmpty(platform))
                            platform = ScanForPlatform(fields);
                    }

                    object targetD   = NullableDate(targetCompletionDate);
                    object proposedD = NullableDate(proposedDemandPickup);
                    object createdD  = NullableDate(createdStr);
                    object updatedD  = NullableDate(updatedStr);
                    string rag = ComputeRag(targetD);

                    // Map captured JIRA fields to existing + new columns on JiraIssues
                    Db.Exec(@"
IF EXISTS (SELECT 1 FROM JiraIssues WHERE JiraID=@id)
    UPDATE JiraIssues SET
        Summary=@s, ProjectName=@pn, OverallStatus=@st, Status=@st,
        IssueType=@it, ProjectType=@it, DemandType=@dt, ProjectRAG=@rag,
        Manager=@pm, TechLead=@sme, Sponsor=@ae, Stakeholder=@ael,
        Assignee=@asg, Reporter=@rep,
        AccountableExecLead=@ael, SmeLead=@sme, AccountableExec=@ae,
        IdhPortfolioHead=@iph, AssignedProjectManager=@pm,
        DemandOwner=@do, ChiefNameMapping=@cnm,
        TargetCompletionDate=@tcd, ProposedDemandPickupDate=@pdp,
        JiraCreated=@jc, JiraUpdated=@ju, Platform=@plt,
        CustomFieldsJson=@j, UpdatedDate=GETDATE()
    WHERE JiraID=@id
ELSE
    INSERT INTO JiraIssues(JiraID, Summary, ProjectName, OverallStatus, Status,
        IssueType, ProjectType, DemandType, ProjectRAG,
        Manager, TechLead, Sponsor, Stakeholder,
        Assignee, Reporter, AccountableExecLead, SmeLead, AccountableExec,
        IdhPortfolioHead, AssignedProjectManager, DemandOwner, ChiefNameMapping,
        TargetCompletionDate, ProposedDemandPickupDate, JiraCreated, JiraUpdated,
        Platform, CustomFieldsJson)
    VALUES(@id, @s, @pn, @st, @st, @it, @it, @dt, @rag,
        @pm, @sme, @ae, @ael,
        @asg, @rep, @ael, @sme, @ae,
        @iph, @pm, @do, @cnm,
        @tcd, @pdp, @jc, @ju, @plt, @j);",
                        Db.P("@id", id),
                        Db.P("@s",   summary),
                        Db.P("@pn",  string.IsNullOrEmpty(project) ? summary : project),
                        Db.P("@st",  status),
                        Db.P("@it",  issueType),
                        Db.P("@dt",  demandType),
                        Db.P("@rag", rag),
                        Db.P("@pm",  assignedPm),
                        Db.P("@sme", smeLead),
                        Db.P("@ae",  accExec),
                        Db.P("@ael", accExecLead),
                        Db.P("@asg", assignee),
                        Db.P("@rep", reporter),
                        Db.P("@iph", idhPortfolioHead),
                        Db.P("@do",  demandOwner),
                        Db.P("@cnm", chiefNameMapping),
                        Db.P("@tcd", targetD),
                        Db.P("@pdp", proposedD),
                        Db.P("@jc",  createdD),
                        Db.P("@ju",  updatedD),
                        Db.P("@plt", string.IsNullOrEmpty(platform) ? (object)DBNull.Value : platform),
                        Db.P("@j",   fieldsJson));
                    count++;
                }
                lblMsg.Visible = true;
                lblMsg.Text = "Fetched / updated " + count + " issue(s) from JIRA.";
                Bind();
            }
            catch (Exception ex)
            {
                lblMsg.Visible = true;
                lblMsg.Text = "JIRA fetch failed (showing cached data): " + ex.Message;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = JiraClient.GetCachedIssues();
            ExcelHelper.ExportToExcel(Response, dt, "JIRA_Issues_" + DateTime.Now.ToString("yyyyMMdd"));
        }
    }
}
