using System;
using System.Data;
using System.Text;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class ProjectList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }
        protected void Filter_Changed(object sender, EventArgs e) { Bind(); }

        private void Bind()
        {
            string ptype  = ddlType.SelectedValue;
            string stage  = ddlStage.SelectedValue;
            string search = (txtSearch.Text ?? "").Trim();

            try
            {
                DataSet ds = ProjectsDAL.GetProjectTreeData(ptype, null);
                DataTable projects = ds.Tables["Projects"];
                DataTable petTotals = ds.Tables["PETTotals"];
                DataTable memos     = ds.Tables["Memos"];
                DataTable invoices  = ds.Tables["Invoices"];

                // Apply stage / search filter client-side on the projects table
                if (!string.IsNullOrEmpty(stage) && stage != "ALL")
                    projects = new DataView(projects, "CurrentStage='" + stage.Replace("'","''") + "'", "", DataViewRowState.CurrentRows).ToTable();
                if (!string.IsNullOrEmpty(search))
                {
                    string s = search.Replace("'","''");
                    projects = new DataView(projects,
                        "ProjectCode LIKE '%" + s + "%' OR ProjectName LIKE '%" + s + "%'",
                        "", DataViewRowState.CurrentRows).ToTable();
                }

                if (projects.Rows.Count == 0)
                {
                    litTree.Text = "<p class='text-muted' style='padding:8px;'>No projects found.</p>";
                    return;
                }

                var sb = new StringBuilder();
                sb.Append("<table class='tree-table'>");
                sb.Append("<thead><tr><th>Node</th><th>Type</th><th>Amount (AED)</th><th>Stage / Status</th><th>Pending With</th><th>Details</th><th></th></tr></thead>");
                sb.Append("<tbody>");

                foreach (DataRow prj in projects.Rows)
                {
                    int pid = Convert.ToInt32(prj["ProjectID"]);
                    string pcode   = HtmlEnc(prj["ProjectCode"].ToString());
                    string pname   = HtmlEnc(prj["ProjectName"].ToString());
                    string ptype2  = prj["ProjectType"].ToString();
                    string pstatus = prj["Status"].ToString();
                    decimal pamt   = prj["RequestedAmount"] == DBNull.Value ? 0m : Convert.ToDecimal(prj["RequestedAmount"]);
                    string pstage  = prj["CurrentStage"] == DBNull.Value ? "" : prj["CurrentStage"].ToString();
                    string approver = prj.Table.Columns.Contains("ApproverName") && prj["ApproverName"] != DBNull.Value
                        ? prj["ApproverName"].ToString() : "";
                    string petApprSt = prj.Table.Columns.Contains("PetApprovalStatus") && prj["PetApprovalStatus"] != DBNull.Value
                        ? prj["PetApprovalStatus"].ToString() : "";
                    string pendingWith = string.Equals(petApprSt, "Pending", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(approver)
                        ? "<span class='pending-with-label'><span class='glyphicon glyphicon-user'></span> " + HtmlEnc(approver) + "</span>"
                        : "&mdash;";
                    string togId   = "p" + pid;

                    DataRow[] petRows  = petTotals.Select("ProjectID=" + pid);
                    DataRow[] memoRows = memos.Select("ProjectID=" + pid);
                    bool hasChildren   = petRows.Length > 0 || memoRows.Length > 0;

                    // Project row
                    sb.Append("<tr>");
                    sb.Append("<td>");
                    if (hasChildren)
                        sb.AppendFormat("<span class='tree-toggle' data-tog='{0}' onclick=\"dfmTog('{0}')\">&#9658;</span>", togId);
                    sb.AppendFormat("<strong>{0}</strong> {1}", pcode, pname);
                    sb.Append("</td>");
                    sb.AppendFormat("<td><span class='chip chip-{0}'>{0}</span></td>", ptype2.ToLower());
                    sb.AppendFormat("<td style='text-align:right'>AED {0} M</td>", (pamt / 1000000m).ToString("N2"));
                    sb.AppendFormat("<td>{0} {1}</td>", StatusBadge(pstatus), HtmlEnc(pstage));
                    sb.AppendFormat("<td>{0}</td>", pendingWith);
                    sb.AppendFormat("<td>{0}</td>", HtmlEnc(prj["CreatedBy"] == DBNull.Value ? "" : prj["CreatedBy"].ToString()));
                    sb.AppendFormat("<td><a class='btn btn-xs btn-primary' href='Workflow.aspx?id={0}'>Open</a> " +
                        "<a class='btn btn-xs btn-secondary' href='ProjectHistory.aspx?id={0}'>History</a></td>", pid);
                    sb.Append("</tr>");

                    // PET summary
                    if (petRows.Length > 0)
                    {
                        DataRow pet = petRows[0];
                        decimal petAmt = pet["TotalAED"] == DBNull.Value ? 0m : Convert.ToDecimal(pet["TotalAED"]);
                        int lines = Convert.ToInt32(pet["LineCount"]);
                        string petAppr = pet["PetApprovalStatus"] == DBNull.Value ? "Pending" : pet["PetApprovalStatus"].ToString();
                        string petPendingWith = string.Equals(petAppr, "Pending", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(approver)
                            ? "<span class='pending-with-label'><span class='glyphicon glyphicon-user'></span> " + HtmlEnc(approver) + "</span>"
                            : "&mdash;";
                        sb.AppendFormat("<tr class='tree-row {0} tree-hidden'>", togId);
                        sb.Append("<td class='indent1'>&#128196; PET Sheet</td>");
                        sb.Append("<td>PET</td>");
                        sb.AppendFormat("<td style='text-align:right'>AED {0} M</td>", (petAmt / 1000000m).ToString("N2"));
                        sb.AppendFormat("<td>{0}</td>", StatusBadge(petAppr));
                        sb.AppendFormat("<td>{0}</td>", petPendingWith);
                        sb.AppendFormat("<td>{0} line item{1}</td><td></td>", lines, lines == 1 ? "" : "s");
                        sb.Append("</tr>");
                    }

                    // Memos
                    foreach (DataRow memo in memoRows)
                    {
                        int mid = Convert.ToInt32(memo["MemoID"]);
                        string mnum  = HtmlEnc(memo["MemoNumber"].ToString());
                        string mvend = HtmlEnc(memo["VendorName"].ToString());
                        decimal mamt = memo["ApprovedAmountAED"] == DBNull.Value ? 0m : Convert.ToDecimal(memo["ApprovedAmountAED"]);
                        decimal mdis = memo["AmountDisbursed"] == DBNull.Value ? 0m : Convert.ToDecimal(memo["AmountDisbursed"]);
                        string mstatus = memo["CAMStatus"].ToString();
                        string lpo  = HtmlEnc(memo["LPO_SO_Number"].ToString());
                        string mTogId = "m" + mid;
                        DataRow[] invRows = invoices.Select("MemoID=" + mid);

                        sb.AppendFormat("<tr class='tree-row {0} tree-hidden'>", togId);
                        sb.Append("<td class='indent1'>");
                        if (invRows.Length > 0)
                            sb.AppendFormat("<span class='tree-toggle' data-tog='{0}' onclick=\"dfmTog('{1} {0}')\">&#9658;</span>", mTogId, togId);
                        sb.AppendFormat("&#129534; {0} &mdash; {1}", mnum, mvend);
                        sb.Append("</td><td>Memo</td>");
                        sb.AppendFormat("<td style='text-align:right'>AED {0} M</td>", (mamt / 1000000m).ToString("N2"));
                        sb.AppendFormat("<td>{0}</td>", StatusBadge(mstatus));
                        sb.Append("<td>&mdash;</td>");  // Pending With n/a for memos
                        sb.AppendFormat("<td>LPO: {0} &bull; Disbursed: AED {1} M</td><td></td>",
                            string.IsNullOrEmpty(lpo) ? "&mdash;" : lpo, (mdis / 1000000m).ToString("N2"));
                        sb.Append("</tr>");

                        foreach (DataRow inv in invRows)
                        {
                            string inum   = HtmlEnc(inv["InvoiceNumber"].ToString());
                            decimal iamt  = inv["InvoiceAmountAED"] == DBNull.Value ? 0m : Convert.ToDecimal(inv["InvoiceAmountAED"]);
                            string istatus = inv["InvoiceStatus"].ToString();
                            string idate  = inv["InvoiceDate"] == DBNull.Value ? "" :
                                Convert.ToDateTime(inv["InvoiceDate"]).ToString("MMM-yyyy");
                            sb.AppendFormat("<tr class='tree-row {0} {1} tree-hidden'>", togId, mTogId);
                            sb.AppendFormat("<td class='indent2'>&#128176; {0}</td><td>Invoice</td>", inum);
                            sb.AppendFormat("<td style='text-align:right'>AED {0} M</td>", (iamt / 1000000m).ToString("N2"));
                            sb.AppendFormat("<td>{0}</td><td>{1}</td><td></td>", StatusBadge(istatus), idate);
                            sb.Append("</tr>");
                        }
                    }
                }
                sb.Append("</tbody></table>");
                litTree.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                litTree.Text = "<p class='text-muted' style='padding:8px;'>Error loading projects: " + HtmlEnc(ex.Message) + "</p>";
            }
        }

        private static string StatusBadge(string s)
        {
            if (string.IsNullOrEmpty(s)) s = "Pending";
            string css;
            switch (s.ToLower())
            {
                case "approved": case "paid": case "issued": case "closed": css = "ok"; break;
                case "pending": css = "warn"; break;
                case "submitted": case "open": css = "info"; break;
                case "rejected": css = "danger"; break;
                default: css = "muted"; break;
            }
            return string.Format("<span class='tree-badge {0}'>{1}</span>", css, HtmlEnc(s));
        }

        private static string HtmlEnc(string s) { return string.IsNullOrEmpty(s) ? "" : System.Web.HttpUtility.HtmlEncode(s); }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            string ptype = ddlType.SelectedValue;
            DataTable dt = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype, null);
            ExcelHelper.ExportToExcel(Response, dt, "DFM_Projects_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }
    }
}
