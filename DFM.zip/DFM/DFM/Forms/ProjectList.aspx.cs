using System;
using System.Data;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class ProjectList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }
        protected void Filter_Changed(object sender, EventArgs e) { Bind(); }

        private void Bind()
        {
            string ptype = ddlType.SelectedValue;
            string status = ddlStatus.SelectedValue;
            gv.DataSource = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype,
                                                    status == "ALL" ? null : status);
            gv.DataBind();
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            string ptype = ddlType.SelectedValue;
            string status = ddlStatus.SelectedValue;
            DataTable dt = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype,
                                                   status == "ALL" ? null : status);
            ExcelHelper.ExportToExcel(Response, dt, "DFM_Projects_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }
    }
}
