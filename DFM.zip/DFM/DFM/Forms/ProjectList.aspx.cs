using System;
using System.Data;
using System.Text;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class ProjectList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(); }
        protected void Filter_Changed(object sender, EventArgs e) { gv.PageIndex = 0; Bind(); }
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e) { gv.PageIndex = e.NewPageIndex; Bind(); }

        private DataTable Fetch()
        {
            string ptype = ddlType.SelectedValue;
            DataTable dt = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype, null);
            DataView dv = new DataView(dt);
            StringBuilder f = new StringBuilder();
            string stage = ddlStage.SelectedValue;
            if (!string.IsNullOrEmpty(stage) && stage != "ALL")
                f.Append("CurrentStage='" + stage.Replace("'", "''") + "'");
            string q = (txtSearch.Text ?? "").Trim();
            if (!string.IsNullOrEmpty(q))
            {
                if (f.Length > 0) f.Append(" AND ");
                f.Append("(JiraID LIKE '%" + q.Replace("'", "''") + "%' OR ProjectName LIKE '%" + q.Replace("'", "''") + "%' OR ProjectCode LIKE '%" + q.Replace("'", "''") + "%')");
            }
            if (f.Length > 0) dv.RowFilter = f.ToString();
            return dv.ToTable();
        }

        private void Bind()
        {
            gv.DataSource = Fetch();
            gv.DataBind();
        }

        public string StageCss(object o)
        {
            string s = (o == null || o == DBNull.Value) ? "" : o.ToString();
            if (string.IsNullOrEmpty(s)) return "draft";
            switch (s.ToLowerInvariant())
            {
                case "approved":
                case "closed":
                case "done": return "approved";
                case "submitted": return "pending";
                case "inprogress":
                case "in progress": return "inprogress";
                case "rejected": return "rejected";
                default: return "draft";
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = Fetch();
            ExcelHelper.ExportToExcel(Response, dt, "DFM_Projects_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }
    }
}
