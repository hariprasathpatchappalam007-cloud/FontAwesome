<%@ Page Title="Source Workflow History" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="SourceHistory.aspx.cs" Inherits="DFM.Forms.SourceHistory" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">
        <span class="glyphicon glyphicon-time"></span>
        <asp:Literal ID="litTitle" runat="server" /> Workflow History
    </h1>

    <div class="card-panel">
        <h3>
            <asp:Literal ID="litSource" runat="server" />
            <small class="text-muted">- per-project debit / lock history</small>
        </h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
                AllowPaging="true" PageSize="20" OnPageIndexChanging="gv_PageIndexChanging">
                <PagerStyle CssClass="pager" />
                <Columns>
                    <asp:TemplateField HeaderText="Project / JIRA">
                        <ItemTemplate>
                            <%# Eval("ProjectID") == System.DBNull.Value
                                  ? "<span class='text-muted'>&mdash; Master edit &mdash;</span>"
                                  : ("<a href='" + ResolveUrl("~/Forms/Workflow.aspx?id=" + Eval("ProjectID")) + "'>"
                                     + (Eval("JiraID") == System.DBNull.Value || Eval("JiraID").ToString() == "" ? Eval("ProjectCode") : Eval("JiraID"))
                                     + "</a>") %>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="ProjectName" HeaderText="Project Name" />
                    <asp:TemplateField HeaderText="Action">
                        <ItemTemplate>
                            <span class='audit-stage audit-<%# Eval("Action").ToString().ToLower() %>'>
                                <%# Eval("Action") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="Amount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="PrevLocked" HeaderText="Prev Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="NewLocked" HeaderText="New Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="PrevUtil" HeaderText="Prev Util" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="NewUtil" HeaderText="New Util" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="Notes" HeaderText="Notes" />
                    <asp:BoundField DataField="ActionBy" HeaderText="By" />
                    <asp:BoundField DataField="ActionDate" HeaderText="Date" DataFormatString="{0:dd-MMM-yy HH:mm}" />
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:14px;">No history for this source.</div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
