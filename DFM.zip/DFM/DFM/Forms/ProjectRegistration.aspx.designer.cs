namespace DFM.Forms
{
    public partial class ProjectRegistration
    {
        protected global::System.Web.UI.WebControls.Label lblMsg;
        protected global::System.Web.UI.WebControls.DropDownList ddlJira;
        protected global::System.Web.UI.WebControls.TextBox txtName;
        protected global::System.Web.UI.WebControls.DropDownList ddlType;
        protected global::System.Web.UI.WebControls.DropDownList ddlUpdateMode;
        protected global::System.Web.UI.WebControls.Repeater rptJiraFields;
        protected global::System.Web.UI.WebControls.Literal litSourceLabel;
        protected global::System.Web.UI.WebControls.DropDownList ddlSource;
        protected global::System.Web.UI.WebControls.TextBox txtAmount;
        protected global::System.Web.UI.WebControls.DropDownList ddlApprover;
        protected global::System.Web.UI.WebControls.Panel pnlBudget;
        protected global::System.Web.UI.WebControls.Literal bBudget;
        protected global::System.Web.UI.WebControls.Literal bUtil;
        protected global::System.Web.UI.WebControls.Literal bAvail;
        protected global::System.Web.UI.WebControls.Literal bLock;
        protected global::System.Web.UI.WebControls.Literal bAfterLock;
        protected global::System.Web.UI.WebControls.Literal bClaim;
        protected global::System.Web.UI.WebControls.Literal bNet;
        protected global::System.Web.UI.WebControls.TextBox txtBaseline;
        protected global::System.Web.UI.WebControls.TextBox txtComment;
        protected global::System.Web.UI.WebControls.Button btnSaveDraft;
        protected global::System.Web.UI.WebControls.Button btnSubmit;
        protected global::System.Web.UI.WebControls.HyperLink lnkHistory;
        protected global::System.Web.UI.WebControls.Label lblStatus;
        protected global::System.Web.UI.WebControls.Panel pnlComments;
        protected global::System.Web.UI.WebControls.Repeater rptComments;
    }
}
