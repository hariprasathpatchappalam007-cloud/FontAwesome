using System;
using System.Data;
using System.Text;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;

namespace DFM.Forms
{
    public partial class AgingDashboard : System.Web.UI.Page
    {
        public string JsAging { get; private set; }
        public AgingDashboard() { JsAging = "[]"; }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = Db.Query("SELECT Bucket, OpenCount FROM DashboardSummary WHERE Dimension='Aging'");
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    sb.Append("{\"bucket\":\"").Append(dt.Rows[i]["Bucket"]).Append("\",\"total\":")
                      .Append(dt.Rows[i]["OpenCount"]).Append("}");
                }
                sb.Append("]");
                JsAging = sb.ToString();

                DataRow ts = Db.QueryRow("SELECT MAX(LastSyncDate) AS LastSync FROM DashboardSummary");
                litTs.Text = (ts != null && ts["LastSync"] != DBNull.Value)
                    ? Convert.ToDateTime(ts["LastSync"]).ToString("dd-MMM-yyyy hh:mm tt")
                    : DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt");
            }
            catch { litTs.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt"); }

            if (!IsPostBack) BindGrid();
        }

        private void BindGrid()
        {
            try
            {
                gv.DataSource = Db.Query(@"SELECT TOP 500 JiraKey, ISNULL(Summary,'') AS Summary,
                    ISNULL(Status,'') AS Status,
                    DATEDIFF(MONTH, ISNULL(CreatedDate, GETDATE()), GETDATE()) AS MonthsOpen,
                    ISNULL(Manager,'') AS Manager, ISNULL(TechLead,'') AS TechLead
                    FROM JiraIssues
                    WHERE Status NOT IN ('Done','Closed','Cancelled','Completed')
                      AND DATEDIFF(MONTH, ISNULL(CreatedDate, GETDATE()), GETDATE()) > 3
                    ORDER BY MonthsOpen DESC");
                gv.DataBind();
            }
            catch { }
        }

        protected void gv_Paging(object sender, GridViewPageEventArgs e) { gv.PageIndex = e.NewPageIndex; BindGrid(); }
    }
}
