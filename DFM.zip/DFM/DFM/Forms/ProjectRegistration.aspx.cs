using System;
using System.Data;
using System.Globalization;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class ProjectRegistration : System.Web.UI.Page
    {
        private int? ProjectId
        {
            get
            {
                int x;
                return int.TryParse(Request.QueryString["id"], out x) ? (int?)x : null;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindJiraDropdown();
                BindApprovers();
                BindSourceDropdown();
                if (ProjectId.HasValue) LoadExisting(ProjectId.Value);
            }
        }

        private void BindJiraDropdown()
        {
            var dt = JiraClient.GetCachedIssues();
            ddlJira.DataSource = dt;
            ddlJira.DataTextField = "JiraID";
            ddlJira.DataValueField = "JiraID";
            ddlJira.DataBind();
            ddlJira.Items.Insert(0, new ListItem("-- Select JIRA ID --", ""));
        }

        private void BindApprovers()
        {
            var dt = MastersDAL.GetApprovers(true);
            ddlApprover.DataSource = dt;
            ddlApprover.DataTextField = "ApproverName";
            ddlApprover.DataValueField = "ApproverID";
            ddlApprover.DataBind();
            ddlApprover.Items.Insert(0, new ListItem("-- Select approver --", ""));
        }

        private void BindSourceDropdown()
        {
            string type = ddlType.SelectedValue;
            DataTable src;
            string keyCol, descCol;
            if (type == "OPEX") { src = MastersDAL.GetOpex(); keyCol = "OpexID"; descCol = "Description"; litSourceLabel.Text = "OPEX"; }
            else if (type == "AMC") { src = MastersDAL.GetAmc();  keyCol = "AmcID";  descCol = "Description"; litSourceLabel.Text = "AMC"; }
            else { src = MastersDAL.GetCapex(); keyCol = "CapexID"; descCol = "Description"; litSourceLabel.Text = "CAPEX"; }

            ddlSource.Items.Clear();
            ddlSource.Items.Add(new ListItem("-- Search by ID or Description --", ""));
            foreach (DataRow r in src.Rows)
            {
                string id = r[keyCol].ToString();
                string desc = r[descCol].ToString();
                if (desc.Length > 90) desc = desc.Substring(0, 90) + "...";
                ddlSource.Items.Add(new ListItem(id + " — " + desc, id));
            }
        }

        protected void ddlType_Changed(object sender, EventArgs e)
        {
            BindSourceDropdown();
            pnlBudget.Visible = false;
        }

        protected void ddlSource_Changed(object sender, EventArgs e) { BindBudget(); }

        private void BindBudget()
        {
            string type = ddlType.SelectedValue;
            string id = ddlSource.SelectedValue;
            if (string.IsNullOrEmpty(id)) { pnlBudget.Visible = false; return; }

            DataRow row = null;
            if (type == "OPEX") row = MastersDAL.GetOpexById(id);
            else if (type == "AMC") row = Db.QueryRow("SELECT * FROM AmcMaster WHERE AmcID=@id", Db.P("@id", id));
            else row = MastersDAL.GetCapexById(id);

            if (row == null) { pnlBudget.Visible = false; return; }

            bBudget.Text    = Money(row, "Budget");
            bUtil.Text      = Money(row, "Utilization");
            bAvail.Text     = Money(row, "AvailableBudget");
            bLock.Text      = Money(row, "LockedAmount");
            bAfterLock.Text = Money(row, "BudgetAfterLockedAmount");
            bClaim.Text     = Money(row, "ClaimAmount");
            bNet.Text       = Money(row, "NetBalance");
            pnlBudget.Visible = true;
        }

        protected void ddlJira_Changed(object sender, EventArgs e)
        {
            string jid = ddlJira.SelectedValue;
            if (string.IsNullOrEmpty(jid)) return;
            var row = JiraClient.GetCachedIssue(jid);
            if (row == null) return;

            if (string.IsNullOrEmpty(txtName.Text))
                txtName.Text = row["ProjectName"] == DBNull.Value ? jid : row["ProjectName"].ToString();

            // Build the auto-populated JIRA field display from configured visible fields
            var visibleFields = MastersDAL.GetJiraFields();
            var rows = new System.Collections.Generic.List<object>();
            foreach (DataRow f in visibleFields.Rows)
            {
                if (!Convert.ToBoolean(f["IsVisible"])) continue;
                string key = f["FieldKey"].ToString();
                string name = f["FieldName"].ToString();
                string val = MapStockField(row, key, name);
                rows.Add(new { FieldName = name, Value = val });
            }
            rptJiraFields.DataSource = rows;
            rptJiraFields.DataBind();
        }

        // Map our seeded "customfield_xxx" keys to columns in JiraIssues.
        private static string MapStockField(DataRow row, string key, string name)
        {
            string col = null;
            switch (key)
            {
                case "customfield_project_name":  col = "ProjectName"; break;
                case "customfield_project_id":    col = "JiraID"; break;
                case "customfield_start_date":    col = "StartDate"; break;
                case "customfield_overall_status":col = "OverallStatus"; break;
                case "customfield_project_stage": col = "ProjectStage"; break;
                case "customfield_project_rag":   col = "ProjectRAG"; break;
                case "customfield_demand_type":   col = "DemandType"; break;
                case "customfield_project_type":  col = "ProjectType"; break;
                case "customfield_classification":col = "Classification"; break;
                case "customfield_tech_lead":     col = "TechLead"; break;
                case "customfield_manager":       col = "Manager"; break;
                case "customfield_sponsor":       col = "Sponsor"; break;
                case "customfield_department":    col = "Department"; break;
                case "customfield_stakeholder":   col = "Stakeholder"; break;
                case "customfield_objectives":    col = "Objectives"; break;
            }
            if (col != null && row.Table.Columns.Contains(col) && row[col] != DBNull.Value)
                return row[col].ToString();

            // Discovered (real JIRA) fields stored as JSON
            if (row.Table.Columns.Contains("CustomFieldsJson") && row["CustomFieldsJson"] != DBNull.Value)
            {
                try
                {
                    var jss = new JavaScriptSerializer();
                    var dict = jss.Deserialize<System.Collections.Generic.Dictionary<string, object>>(row["CustomFieldsJson"].ToString());
                    if (dict != null && dict.ContainsKey(key) && dict[key] != null) return dict[key].ToString();
                }
                catch { }
            }
            return "";
        }

        private void LoadExisting(int id)
        {
            var p = ProjectsDAL.GetProject(id);
            if (p == null) return;
            txtName.Text = p["ProjectName"].ToString();

            string ptype = p["ProjectType"].ToString();
            ddlType.ClearSelection();
            var ti = ddlType.Items.FindByValue(ptype); if (ti != null) ti.Selected = true;
            string mode = p["UpdateMode"] == DBNull.Value ? "New" : p["UpdateMode"].ToString();
            if (string.IsNullOrEmpty(mode)) mode = "New";
            ddlUpdateMode.ClearSelection();
            var mi = ddlUpdateMode.Items.FindByValue(mode); if (mi != null) mi.Selected = true;
            BindSourceDropdown();

            string src = p["BudgetSourceID"] == DBNull.Value ? "" : p["BudgetSourceID"].ToString();
            ddlSource.ClearSelection();
            var si = ddlSource.Items.FindByValue(src); if (si != null) si.Selected = true;
            BindBudget();

            txtAmount.Text = Convert.ToDecimal(p["RequestedAmount"]).ToString("N2");
            if (p["ApproverID"] != DBNull.Value)
            {
                ddlApprover.ClearSelection();
                var ai = ddlApprover.Items.FindByValue(p["ApproverID"].ToString()); if (ai != null) ai.Selected = true;
            }
            string jira = p["JiraID"] == DBNull.Value ? "" : p["JiraID"].ToString();
            if (!string.IsNullOrEmpty(jira))
            {
                var ji = ddlJira.Items.FindByValue(jira); if (ji != null) { ddlJira.ClearSelection(); ji.Selected = true; }
                ddlJira_Changed(null, EventArgs.Empty);
            }
            txtBaseline.Text = p["BaselinePlan"] == DBNull.Value ? "" : p["BaselinePlan"].ToString();

            string status = p["Status"].ToString();
            lblStatus.Text = status;
            lblStatus.CssClass = "badge-status badge-" + status.ToLower();

            lnkHistory.Visible = true;
            lnkHistory.NavigateUrl = "~/Forms/ProjectHistory.aspx?id=" + id;

            // Comments
            var dt = ProjectsDAL.GetComments(id);
            if (dt.Rows.Count > 0)
            {
                pnlComments.Visible = true;
                rptComments.DataSource = dt;
                rptComments.DataBind();
            }
        }

        protected void btnSaveDraft_Click(object sender, EventArgs e)  { SaveOrSubmit(false); }
        protected void btnSubmit_Click(object sender, EventArgs e)     { SaveOrSubmit(true);  }

        private void SaveOrSubmit(bool submit)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text)) { Msg("Project name is required."); return; }
            if (string.IsNullOrEmpty(ddlSource.SelectedValue)) { Msg("Please select a budget source (CAPEX/OPEX/AMC)."); return; }
            if (submit && string.IsNullOrEmpty(ddlApprover.SelectedValue)) { Msg("Please select an approver before submitting."); return; }

            decimal amt = CsvImporter.ParseDecimal(txtAmount.Text);
            int approverId; int.TryParse(ddlApprover.SelectedValue, out approverId);
            string user = AuthHelper.CurrentUser;

            int id;
            if (ProjectId.HasValue)
            {
                id = ProjectId.Value;
                ProjectsDAL.UpdateProject(id, txtName.Text.Trim(), ddlSource.SelectedValue,
                    amt, approverId, txtBaseline.Text, txtComment.Text, user);

                var current = ProjectsDAL.GetProject(id);
                int version = Convert.ToInt32(current["Version"]);
                ProjectsDAL.AddVersionSnapshot(id, version, SnapshotJson(current), user, txtComment.Text);
                if (!string.IsNullOrWhiteSpace(txtComment.Text))
                    ProjectsDAL.AddComment(id, txtComment.Text, user);
                ProjectsDAL.AddWorkflow(id, "Modified", null, user, txtComment.Text, version);

                if (submit)
                {
                    ProjectsDAL.SubmitProject(id, user);
                    ProjectsDAL.AddWorkflow(id, "Submitted", null, user, "Submitted for approval", version);
                    NotifyApproverOnSubmit(id, txtName.Text.Trim(), approverId);
                }
                Msg(submit ? "Project re-submitted." : "Draft updated.");
            }
            else
            {
                id = ProjectsDAL.CreateProject(ddlJira.SelectedValue, txtName.Text.Trim(),
                    ddlType.SelectedValue, ddlSource.SelectedValue,
                    amt, approverId, txtBaseline.Text, txtComment.Text, user,
                    submit ? "Pending" : "Draft");
                ProjectsDAL.AddWorkflow(id, submit ? "Submitted" : "Draft", null, user,
                    submit ? "Submitted for approval" : "Created as draft", 1);
                if (!string.IsNullOrWhiteSpace(txtComment.Text))
                    ProjectsDAL.AddComment(id, txtComment.Text, user);

                // Persist UpdateMode (New / ExistingUpdate)
                Db.Exec("UPDATE Projects SET UpdateMode=@m WHERE ProjectID=@id",
                    Db.P("@m", ddlUpdateMode.SelectedValue), Db.P("@id", id));

                if (submit) NotifyApproverOnSubmit(id, txtName.Text.Trim(), approverId);
                Msg(submit ? "Project submitted for approval." : "Draft saved.");
            }
            Response.Redirect("~/Forms/ProjectRegistration.aspx?id=" + id);
        }

        private void NotifyApproverOnSubmit(int projectId, string projectName, int approverId)
        {
            if (approverId <= 0) return;
            // Block self-approval at submit time too
            DataRow ap = Db.QueryRow(
                "SELECT ApproverName, Email FROM ApproverMaster WHERE ApproverID=@id",
                Db.P("@id", approverId));
            if (ap == null) return;
            string apName = ap["ApproverName"].ToString();
            string apEmail = ap["Email"] == DBNull.Value ? "" : ap["Email"].ToString();
            string user = AuthHelper.CurrentUser;
            if (string.Equals(apName, user, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(apEmail, user, StringComparison.OrdinalIgnoreCase))
            {
                Msg("Warning: the selected approver matches the requestor; the approver cannot approve their own request.");
            }
            string recipient = !string.IsNullOrEmpty(apEmail) ? apEmail : apName;
            NotificationsDAL.Send(recipient, "New project to approve",
                "Project '" + projectName + "' is awaiting your approval.",
                "~/Forms/MyApprovals.aspx", projectId, "ApprovalRequest");
        }

        private static string SnapshotJson(DataRow row)
        {
            var d = new System.Collections.Generic.Dictionary<string, object>();
            foreach (DataColumn c in row.Table.Columns)
                d[c.ColumnName] = row[c] == DBNull.Value ? null : row[c];
            return new JavaScriptSerializer().Serialize(d);
        }

        private void Msg(string m) { lblMsg.Visible = true; lblMsg.Text = m; }

        private static string Money(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return "0.00";
            return Convert.ToDecimal(r[col]).ToString("N2", CultureInfo.InvariantCulture);
        }
    }
}
