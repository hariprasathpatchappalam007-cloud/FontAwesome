<%@ Page Title="JIRA Integration" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="JiraIntegration.aspx.cs" Inherits="DFM.Forms.JiraIntegration" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-link"></span> JIRA Integration</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3>Fetch</h3>
        <div class="form-grid-5">
            <div class="form-group col-span-3">
                <label>JQL Query</label>
                <asp:TextBox ID="txtJql" runat="server" CssClass="form-control"
                    placeholder="project = DMGT ORDER BY updated DESC" />
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <asp:Button ID="btnFetch" runat="server" Text="Fetch from JIRA"
                    CssClass="btn btn-primary" OnClick="btnFetch_Click" />
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <asp:Button ID="btnExport" runat="server" Text="Export to Excel"
                    CssClass="btn btn-success" OnClick="btnExport_Click" />
            </div>
        </div>
    </div>

    <!-- Req 74: pagination + filter functionality -->
    <div class="card-panel">
        <h3>JIRA Issues</h3>
        <div class="filter-row">
            <div class="form-group">
                <label>Filter ID</label>
                <asp:TextBox ID="txtFId" runat="server" CssClass="form-control"
                    AutoPostBack="true" OnTextChanged="Filter_Changed" />
            </div>
            <div class="form-group col-span-2">
                <label>Filter Name</label>
                <asp:TextBox ID="txtFName" runat="server" CssClass="form-control"
                    AutoPostBack="true" OnTextChanged="Filter_Changed" />
            </div>
            <div class="form-group">
                <label>Stage</label>
                <asp:DropDownList ID="ddlFStage" runat="server" CssClass="form-control"
                    AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                    <asp:ListItem Value="">All</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>RAG</label>
                <asp:DropDownList ID="ddlFRag" runat="server" CssClass="form-control"
                    AutoPostBack="true" OnSelectedIndexChanged="Filter_Changed">
                    <asp:ListItem Value="">All</asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            AllowPaging="true" PageSize="15" OnPageIndexChanging="gv_PageIndexChanging">
            <PagerStyle CssClass="pager" />
            <Columns>
                <asp:TemplateField HeaderText="JIRA ID">
                    <ItemTemplate>
                        <a href='<%# ResolveUrl("~/Forms/Workflow.aspx") %>?jira=<%# Eval("JiraID") %>'>
                            <%# Eval("JiraID") %>
                        </a>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="ProjectName" HeaderText="Project Name" />
                <asp:BoundField DataField="ProjectStage" HeaderText="Stage" />
                <asp:BoundField DataField="ProjectRAG" HeaderText="RAG" />
                <asp:BoundField DataField="ProjectType" HeaderText="Type" />
                <asp:BoundField DataField="DemandType" HeaderText="Demand Type" />
                <asp:BoundField DataField="Manager" HeaderText="Manager" />
                <asp:BoundField DataField="TechLead" HeaderText="Tech Lead" />
                <asp:BoundField DataField="StartDate" HeaderText="Start" />
                <asp:BoundField DataField="EndDate" HeaderText="End" />
            </Columns>
            <EmptyDataTemplate>
                <div class="text-center text-muted" style="padding:14px;">No issues to display.</div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>
</asp:Content>
