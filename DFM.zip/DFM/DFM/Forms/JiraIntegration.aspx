<%@ Page Title="JIRA Integration" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="JiraIntegration.aspx.cs" Inherits="DFM.Forms.JiraIntegration" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">JIRA Integration</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="toolbar">
        <asp:TextBox ID="txtJql" runat="server" CssClass="form-control" Style="max-width:520px;"
            placeholder="JQL (default: project = DMGT ORDER BY updated DESC)" />
        <asp:Button ID="btnFetch" runat="server" Text="Fetch from JIRA" CssClass="btn btn-primary" OnClick="btnFetch_Click" />
        <div class="spacer"></div>
        <asp:Button ID="btnExport" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExport_Click" />
    </div>

    <div class="card-panel">
        <h3>JIRA issues</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="JiraID" HeaderText="JIRA ID" />
                <asp:BoundField DataField="ProjectName" HeaderText="Project Name" />
                <asp:BoundField DataField="ProjectStage" HeaderText="Stage" />
                <asp:BoundField DataField="ProjectRAG" HeaderText="RAG" />
                <asp:BoundField DataField="ProjectType" HeaderText="Type" />
                <asp:BoundField DataField="DemandType" HeaderText="Demand Type" />
                <asp:BoundField DataField="Manager" HeaderText="Manager" />
                <asp:BoundField DataField="TechLead" HeaderText="Tech Lead" />
                <asp:BoundField DataField="StartDate" HeaderText="Start" />
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
