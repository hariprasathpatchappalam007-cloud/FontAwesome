using System;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;

namespace DFM.Forms
{
    public partial class ProcessFlow : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string key = (txtDmgtKey.Text ?? "").Trim().ToUpper();
            if (string.IsNullOrEmpty(key))
            {
                lblMsg.Visible = true;
                lblMsg.Text = "Please enter a DMGT issue key.";
                return;
            }
            lblMsg.Visible = false;
            LoadHierarchy(key);
        }

        protected void btnLoadAll_Click(object sender, EventArgs e)
        {
            pnlHierarchy.Visible = false;
            pnlAll.Visible = true;

            string sql = @"SELECT JiraKey, Summary, Status, ISNULL(ParentJiraID,'') AS ParentJiraID,
                           ISNULL(ProjectKey,'DMGT') AS ProjectKey
                           FROM JiraIssues WHERE ProjectKey='DMGT'
                           ORDER BY JiraKey";
            DataTable dt = Db.Query(sql);
            gvAll.DataSource = dt;
            gvAll.DataBind();
        }

        protected void gvAll_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvAll.PageIndex = e.NewPageIndex;
            btnLoadAll_Click(sender, e);
        }

        protected void btnViewHierarchy_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string key = btn.CommandArgument;
            txtDmgtKey.Text = key;
            LoadHierarchy(key);
        }

        private void LoadHierarchy(string dmgtKey)
        {
            pnlAll.Visible = false;
            pnlHierarchy.Visible = true;

            // Get the parent DMGT issue
            string sqlParent = "SELECT TOP 1 JiraKey, Summary, Status, ISNULL(ProjectKey,'DMGT') AS ProjectKey FROM JiraIssues WHERE JiraKey=@p0";
            DataRow parent = Db.QueryRow(sqlParent, Db.P("@p0", dmgtKey) );

            if (parent == null)
            {
                lblMsg.Visible = true;
                lblMsg.Text = "Issue " + Server.HtmlEncode(dmgtKey) + " not found in the database.";
                pnlHierarchy.Visible = false;
                return;
            }

            // Get child DIBITP issues linked to this parent
            string sqlChildren = @"SELECT JiraKey, Summary, Status, ISNULL(ProjectKey,'') AS ProjectKey
                                   FROM JiraIssues WHERE ParentJiraID=@p0 AND ProjectKey='DIBITP'
                                   ORDER BY JiraKey";
            DataTable children = Db.Query(sqlChildren, Db.P("@p0", dmgtKey));

            // Build the flow HTML
            StringBuilder sb = new StringBuilder();
            string parentStatus = parent["Status"].ToString();
            string parentSummary = parent["Summary"].ToString();

            // Parent node
            sb.Append("<div class='flow-level'>");
            sb.AppendFormat("<div class='flow-node parent' onclick=\"showDetail('{0}','{1}','{2}','Demand')\">"
                + "<div class='node-key'>{0}</div>"
                + "<div class='node-status'><span class='badge-status badge-pending'>{2}</span></div>"
                + "<div class='node-summary' title='{1}'>{3}</div>"
                + "</div>",
                Server.HtmlEncode(dmgtKey),
                Server.HtmlEncode(parentSummary.Replace("'", "\\'")),
                Server.HtmlEncode(parentStatus),
                Server.HtmlEncode(parentSummary.Length > 50 ? parentSummary.Substring(0, 50) + "..." : parentSummary));
            sb.Append("</div>");

            // Track RAG statuses for children
            int totalChildren = children.Rows.Count;
            int completedCount = 0;
            int inProgressCount = 0;
            int blockedCount = 0;

            if (totalChildren > 0)
            {
                sb.Append("<div style='padding-left:20px;color:#94a3b8;font-size:1.2em;'>&#9660; Child Projects</div>");
                sb.Append("<div class='flow-level'>");

                foreach (DataRow child in children.Rows)
                {
                    string childKey = child["JiraKey"].ToString();
                    string childSummary = child["Summary"].ToString();
                    string childStatus = child["Status"].ToString();

                    // Track for RAG
                    string statusLower = childStatus.ToLower();
                    if (statusLower.Contains("done") || statusLower.Contains("closed") || statusLower.Contains("complete"))
                        completedCount++;
                    else if (statusLower.Contains("block") || statusLower.Contains("hold"))
                        blockedCount++;
                    else
                        inProgressCount++;

                    sb.AppendFormat("<div class='flow-node child' onclick=\"showDetail('{0}','{1}','{2}','Project')\">"
                        + "<div class='node-key'>{0}</div>"
                        + "<div class='node-status'><span class='badge-status badge-approved'>{2}</span></div>"
                        + "<div class='node-summary' title='{1}'>{3}</div>"
                        + "</div>",
                        Server.HtmlEncode(childKey),
                        Server.HtmlEncode(childSummary.Replace("'", "\\'")),
                        Server.HtmlEncode(childStatus),
                        Server.HtmlEncode(childSummary.Length > 50 ? childSummary.Substring(0, 50) + "..." : childSummary));

                    // Get grandchildren for this child
                    string sqlGrand = @"SELECT JiraKey, Summary, Status FROM JiraIssues
                                        WHERE ParentJiraID=@p0 AND ProjectKey='DIBITP' ORDER BY JiraKey";
                    DataTable grandChildren = Db.Query(sqlGrand, Db.P("@p0", dmgtKey));

                    if (grandChildren.Rows.Count > 0)
                    {
                        sb.Append("<div style='padding-left:40px;margin-top:4px;'>");
                        foreach (DataRow gc in grandChildren.Rows)
                        {
                            string gcKey = gc["JiraKey"].ToString();
                            string gcSummary = gc["Summary"].ToString();
                            string gcStatus = gc["Status"].ToString();

                            string gcStatusLower = gcStatus.ToLower();
                            if (gcStatusLower.Contains("done") || gcStatusLower.Contains("closed") || gcStatusLower.Contains("complete"))
                                completedCount++;
                            else if (gcStatusLower.Contains("block") || gcStatusLower.Contains("hold"))
                                blockedCount++;
                            else
                                inProgressCount++;

                            sb.AppendFormat("<div class='flow-node grandchild' onclick=\"showDetail('{0}','{1}','{2}','Sub-Project')\">"
                                + "<div class='node-key'>{0}</div>"
                                + "<div class='node-status'>{2}</div>"
                                + "<div class='node-summary' title='{1}'>{3}</div>"
                                + "</div>",
                                Server.HtmlEncode(gcKey),
                                Server.HtmlEncode(gcSummary.Replace("'", "\\'")),
                                Server.HtmlEncode(gcStatus),
                                Server.HtmlEncode(gcSummary.Length > 50 ? gcSummary.Substring(0, 50) + "..." : gcSummary));
                        }
                        sb.Append("</div>");
                    }
                }
                sb.Append("</div>");
            }
            else
            {
                sb.Append("<div class='alert-info' style='margin-top:12px;'>No child DIBITP projects linked to this demand.</div>");
            }

            litFlowHtml.Text = sb.ToString();

            // RAG Status calculation based on DIBITP hierarchy
            int totalAll = completedCount + inProgressCount + blockedCount;
            StringBuilder ragSb = new StringBuilder();
            if (totalAll == 0)
            {
                ragSb.Append("<span class='rag-badge rag-amber'>N/A</span> No DIBITP child issues found.");
            }
            else
            {
                string rag;
                string ragClass;
                if (blockedCount > 0)
                {
                    rag = "RED";
                    ragClass = "rag-red";
                }
                else if (completedCount == totalAll)
                {
                    rag = "GREEN";
                    ragClass = "rag-green";
                }
                else
                {
                    rag = "AMBER";
                    ragClass = "rag-amber";
                }

                ragSb.AppendFormat("<span class='rag-badge {0}'>{1}</span> ", ragClass, rag);
                ragSb.AppendFormat("&nbsp; Completed: {0} &nbsp;|&nbsp; In Progress: {1} &nbsp;|&nbsp; Blocked/On Hold: {2} &nbsp;|&nbsp; Total: {3}",
                    completedCount, inProgressCount, blockedCount, totalAll);
            }
            litRagSummary.Text = ragSb.ToString();
        }
    }
}
