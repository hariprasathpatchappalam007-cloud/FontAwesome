using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;

namespace DFM.Forms
{
    public partial class SourceHistory : System.Web.UI.Page
    {
        private string SourceType { get { return Request.QueryString["type"] ?? "CAPEX"; } }
        private string SourceId { get { return Request.QueryString["id"] ?? ""; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            litTitle.Text = Server.HtmlEncode(SourceType);
            litSource.Text = Server.HtmlEncode(SourceType + " " + SourceId);
            if (!IsPostBack) Bind();
        }
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv.PageIndex = e.NewPageIndex;
            Bind();
        }
        private void Bind()
        {
            DataTable dt = WorkflowDAL.GetSourceHistory(SourceType, SourceId);
            gv.DataSource = dt;
            gv.DataBind();
        }
    }
}
