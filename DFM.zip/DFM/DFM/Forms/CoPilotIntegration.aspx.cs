using System;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class CoPilotIntegration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindProjects();
                if (Request.QueryString["projectId"] != null)
                {
                    ListItem li = ddlProject.Items.FindByValue(Request.QueryString["projectId"]);
                    if (li != null) { ddlProject.ClearSelection(); li.Selected = true; }
                }
                LoadProject();
                BindAttachments();
            }
        }

        private void BindProjects()
        {
            DataTable dt = ProjectsDAL.GetProjects(null, "Approved");
            ddlProject.Items.Clear();
            ddlProject.Items.Add(new ListItem("-- Select project --", ""));
            foreach (DataRow r in dt.Rows)
                ddlProject.Items.Add(new ListItem(r["ProjectCode"] + " - " + r["ProjectName"],
                    r["ProjectID"].ToString()));
        }

        protected void ddlProject_Changed(object sender, EventArgs e)
        {
            LoadProject();
            BindAttachments();
        }

        private int Pid
        {
            get { int x; return int.TryParse(ddlProject.SelectedValue, out x) ? x : 0; }
        }

        private void LoadProject()
        {
            int pid = Pid;
            if (pid == 0) { litStatus.Text = "(none)"; lnkBpm.NavigateUrl = "#"; return; }
            DataRow p = ProjectsDAL.GetProject(pid);
            if (p == null) return;
            litStatus.Text = string.Format("<span class='badge-status badge-{0}'>{1}</span>",
                p["Status"].ToString().ToLower(), p["Status"]);
            lnkBpm.NavigateUrl = "~/Forms/BpmCreation.aspx?projectId=" + pid;
        }

        private void BindAttachments()
        {
            int pid = Pid;
            if (pid == 0) { gv.DataSource = null; gv.DataBind(); return; }
            gv.DataSource = PetDAL.GetAttachments(pid);
            gv.DataBind();
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            int pid = Pid;
            if (pid == 0) { Msg("Please select a project."); return; }
            if (!fuDoc.HasFiles) { Msg("Please choose one or more files."); return; }

            string root = Server.MapPath("~/Uploads/");
            if (!Directory.Exists(root)) Directory.CreateDirectory(root);

            int n = 0;
            foreach (HttpPostedFile pf in fuDoc.PostedFiles)
            {
                if (pf == null || pf.ContentLength == 0) continue;
                string safeName = Path.GetFileName(pf.FileName);
                string stamped = string.Format("p{0}_{1}_{2}",
                    pid, DateTime.Now.ToString("yyyyMMddHHmmss"), safeName);
                string fullPath = Path.Combine(root, stamped);
                pf.SaveAs(fullPath);

                // Simulated document scan - extract typical fields when possible
                string extractedJson = SimulateExtract(safeName, ddlDocType.SelectedValue, pf.ContentLength);

                PetDAL.AddAttachment(pid, safeName, "~/Uploads/" + stamped,
                    ddlDocType.SelectedValue, pf.ContentLength,
                    AuthHelper.CurrentUser, extractedJson);
                n++;
            }
            Msg(string.Format("Uploaded and scanned {0} file(s). Captured details are shown below.", n));
            BindAttachments();
        }

        // Stub for the OCR / classification step. Returns a small JSON describing
        // the captured fields. A real integration would call Azure Document
        // Intelligence / OpenAI Vision here.
        private static string SimulateExtract(string fileName, string docType, long size)
        {
            string vendor = "TBD";
            string ccy = "AED";
            string invNo = "INV-" + DateTime.Now.ToString("yyMMddHHmm");
            decimal amt = (size % 50000) / 100m;   // arbitrary, but stable per-file
            if (string.Equals(docType, "Memo", StringComparison.OrdinalIgnoreCase))
            {
                return string.Format(
                    "{{\"docType\":\"Memo\",\"subject\":\"Approval Memo - {0}\",\"summary\":\"Memo extracted from {0}\"}}",
                    fileName.Replace("\"","'"));
            }
            return string.Format(
                "{{\"docType\":\"Invoice\",\"vendor\":\"{0}\",\"invoiceNo\":\"{1}\",\"currency\":\"{2}\",\"amount\":{3}}}",
                vendor, invNo, ccy, amt.ToString(System.Globalization.CultureInfo.InvariantCulture));
        }

        private void Msg(string m) { lblMsg.Visible = true; lblMsg.Text = m; }
    }
}
