<%@ Page Title="Workflow" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    MaintainScrollPositionOnPostback="true"
    CodeBehind="Workflow.aspx.cs" Inherits="DFM.Forms.Workflow" %>
<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
    <style>
        .stage-progress { margin-bottom: 10px; }
        .pet-grid-mini th, .pet-grid-mini td { font-size: .85em; padding: 4px 6px; }
        .pet-row-editing td { background: linear-gradient(180deg, #fff3cd 0%, #ffe69c 100%) !important; }
        .pet-aed { background: linear-gradient(180deg, #ecfeff 0%, #cffafe 100%) !important; font-weight: 700 !important; color: #155e75 !important; }
        .attach-list a { display: inline-block; margin-right: 12px; }
    </style>
</asp:Content>
<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">

    <h1 class="page-title">
        <span class="glyphicon glyphicon-road"></span>
        Project Workflow
        <small style="font-weight:400; font-size:.62em; margin-left:8px; color:#5a6477;">
            Unified screen &middot; Project &rarr; PET &rarr; BPM
        </small>
    </h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <%-- Client-side state: open accordion ids + last focus + last scroll. --%>
    <asp:HiddenField ID="hfOpenSections" runat="server" />
    <asp:HiddenField ID="hfFocus" runat="server" />
    <asp:HiddenField ID="hfScroll" runat="server" />

    <!-- ========== JIRA top section (Req 28) ========== -->
    <div class="jira-top">
        <div>
            <span class="jira-id"><asp:Literal ID="litJiraId" runat="server" Text="DMGT-???" /></span>
            <strong><asp:Literal ID="litJiraName" runat="server" Text="(select a JIRA ID below)" /></strong>
        </div>
        <div class="jira-grid">
            <div><div class="lbl">Stage</div><div class="val"><asp:Literal ID="litJStage" runat="server" /></div></div>
            <div><div class="lbl">RAG</div><div class="val"><asp:Literal ID="litJRag" runat="server" /></div></div>
            <div><div class="lbl">Demand Type</div><div class="val"><asp:Literal ID="litJDemand" runat="server" /></div></div>
            <div><div class="lbl">Manager</div><div class="val"><asp:Literal ID="litJMgr" runat="server" /></div></div>
            <div><div class="lbl">Tech Lead</div><div class="val"><asp:Literal ID="litJTech" runat="server" /></div></div>
            <div><div class="lbl">Sponsor</div><div class="val"><asp:Literal ID="litJSponsor" runat="server" /></div></div>
            <div><div class="lbl">Department</div><div class="val"><asp:Literal ID="litJDept" runat="server" /></div></div>
            <div><div class="lbl">Start</div><div class="val"><asp:Literal ID="litJStart" runat="server" /></div></div>
            <div><div class="lbl">End</div><div class="val"><asp:Literal ID="litJEnd" runat="server" /></div></div>
            <div><div class="lbl">Status</div><div class="val"><asp:Literal ID="litJStatus" runat="server" /></div></div>
        </div>
    </div>

    <!-- ========== Workflow stepper (Req 29-30) ========== -->
    <div class="workflow-stepper stage-progress">
        <asp:Literal ID="litStepper" runat="server" />
    </div>

    <!-- =========== Section 1: PROJECT (Req 27 collapsible) ========== -->
    <div class="accordion <%= ProjectAccordionClass %>" id="accProject">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge">PROJECT</span>
            <span class="glyphicon glyphicon-folder-open"></span>
            Project Identity &amp; Budget Source
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <div class="form-grid-5">
                <div class="form-group">
                    <label>JIRA ID / Project ID
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              title="Req 2: JIRA ID == Project ID. Format: DMGT-XXX."></span>
                    </label>
                    <asp:DropDownList ID="ddlJira" runat="server" CssClass="form-control"
                        AutoPostBack="true" OnSelectedIndexChanged="ddlJira_Changed" />
                </div>
                <div class="form-group col-span-2">
                    <label>Project Name</label>
                    <asp:TextBox ID="txtName" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Project Type</label>
                    <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control" AutoPostBack="true"
                        OnSelectedIndexChanged="ddlType_Changed">
                        <asp:ListItem Value="CAPEX">CAPEX</asp:ListItem>
                        <asp:ListItem Value="OPEX">OPEX</asp:ListItem>
                        <asp:ListItem Value="AMC">AMC</asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>Update Mode</label>
                    <asp:DropDownList ID="ddlUpdateMode" runat="server" CssClass="form-control">
                        <asp:ListItem Value="New">New Project</asp:ListItem>
                        <asp:ListItem Value="ExistingUpdate">Existing Update</asp:ListItem>
                    </asp:DropDownList>
                </div>
            </div>

            <div class="form-grid-5">
                <div class="form-group col-span-3">
                    <label>
                        <asp:Literal ID="litSourceLabel" runat="server" Text="CAPEX" /> Source
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              title="Req 9: CAPEX linking functionality is available for all projects."></span>
                    </label>
                    <asp:DropDownList ID="ddlSource" runat="server" CssClass="form-control" AutoPostBack="true"
                        OnSelectedIndexChanged="ddlSource_Changed" />
                </div>
                <div class="form-group">
                    <label>Requested Amount</label>
                    <asp:TextBox ID="txtAmount" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>PET Approver</label>
                    <asp:DropDownList ID="ddlApprover" runat="server" CssClass="form-control" />
                </div>
            </div>

            <asp:Panel ID="pnlBudget" runat="server" Visible="false">
                <div class="budget-grid">
                    <div class="budget-cell budget">
                        <span class="bc-icon glyphicon glyphicon-briefcase"></span>
                        <div class="lbl">Budget</div>
                        <div class="val"><asp:Literal ID="bBudget" runat="server" /></div>
                    </div>
                    <div class="budget-cell utilized">
                        <span class="bc-icon glyphicon glyphicon-stats"></span>
                        <div class="lbl">Utilization</div>
                        <div class="val"><asp:Literal ID="bUtil" runat="server" /></div>
                    </div>
                    <div class="budget-cell available">
                        <span class="bc-icon glyphicon glyphicon-ok-circle"></span>
                        <div class="lbl">Available</div>
                        <div class="val"><asp:Literal ID="bAvail" runat="server" /></div>
                    </div>
                    <div class="budget-cell locked">
                        <span class="bc-icon glyphicon glyphicon-lock"></span>
                        <div class="lbl">Locked</div>
                        <div class="val"><asp:Literal ID="bLock" runat="server" /></div>
                    </div>
                    <div class="budget-cell netbal">
                        <span class="bc-icon glyphicon glyphicon-scale"></span>
                        <div class="lbl">Net Balance</div>
                        <div class="val"><asp:Literal ID="bNet" runat="server" /></div>
                    </div>
                </div>
            </asp:Panel>

            <asp:Panel ID="pnlProjectActions" runat="server">
            <div class="toolbar mt-2">
                <asp:LinkButton ID="btnSaveProject" runat="server" CssClass="btn btn-secondary"
                    OnClick="btnSaveProject_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-floppy-disk"></span> Save as Draft
                </asp:LinkButton>
                <asp:LinkButton ID="btnSubmitProject" runat="server"
                    CssClass="btn btn-primary" OnClick="btnSubmitProject_Click">
                    <span class="glyphicon glyphicon-circle-arrow-right"></span> Save &amp; Continue to PET
                </asp:LinkButton>
            </div>
            </asp:Panel>
        </div>
    </div>

    <!-- =========== Section 2: PET FORM (Req 10-13) ========== -->
    <asp:Panel ID="pnlPet" runat="server" Visible="false">
    <div class="accordion <%= PetAccordionClass %>" id="accPet">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge">PET</span>
            <span class="glyphicon glyphicon-list"></span>
            PET Form (Line Items)
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">

            <div class="toolbar">
                <asp:LinkButton ID="btnPetDownload" runat="server"
                    CssClass="btn btn-success" OnClick="btnPetDownload_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-download-alt"></span> Download CSV
                </asp:LinkButton>
                <asp:LinkButton ID="btnPetTemplate" runat="server"
                    CssClass="btn btn-info" OnClick="btnPetTemplate_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-file"></span> Template
                </asp:LinkButton>

                <span class="text-muted" style="margin-left:8px;">Upload PET CSV:</span>
                <asp:FileUpload ID="fuPetCsv" runat="server" />

                <label style="margin-left:8px;">
                    <input type="radio" name="petUploadMode" value="Retain" id="rbRetain" checked="checked" />
                    Retain Old Records
                </label>
                <label>
                    <input type="radio" name="petUploadMode" value="Delete" id="rbDelete" />
                    Delete Old Records
                </label>
                <asp:LinkButton ID="btnPetUpload" runat="server"
                    CssClass="btn btn-primary" OnClick="btnPetUpload_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-upload"></span> Upload
                </asp:LinkButton>
            </div>

            <!-- Inline add (5-col layout) -->
            <div class="form-grid-5">
                <div class="form-group">
                    <label>Department
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              title='<%= GetGuidance("Department") %>'></span>
                    </label>
                    <asp:DropDownList ID="ddlDept" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Cost Type
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              title='<%= GetGuidance("Cost Type") %>'></span>
                    </label>
                    <asp:DropDownList ID="ddlCostType" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Exp. Head</label>
                    <asp:DropDownList ID="ddlExpHead" runat="server" CssClass="form-control">
                        <asp:ListItem>Capex</asp:ListItem>
                        <asp:ListItem>Opex</asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>Topic</label>
                    <asp:TextBox ID="txtTopic" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Vendor</label>
                    <asp:TextBox ID="txtVendor" runat="server" CssClass="form-control" />
                </div>
            </div>
            <div class="form-grid-5">
                <div class="form-group col-span-5">
                    <label>Description</label>
                    <asp:TextBox ID="txtDesc" runat="server" CssClass="form-control" />
                </div>
            </div>
            <div class="form-grid-5">
                <div class="form-group">
                    <label>Units</label>
                    <asp:TextBox ID="txtUnits" runat="server" CssClass="form-control pet-calc" Text="1" />
                </div>
                <div class="form-group">
                    <label>Unit Price (FCY)</label>
                    <asp:TextBox ID="txtUnitPrice" runat="server" CssClass="form-control pet-calc" />
                </div>
                <div class="form-group">
                    <label>Currency</label>
                    <asp:DropDownList ID="ddlCurrency" runat="server" CssClass="form-control no-select2 pet-calc" />
                </div>
                <div class="form-group">
                    <label>Amount (FCY) <small class="text-muted">[auto]</small></label>
                    <asp:TextBox ID="txtAmtFcy" runat="server" CssClass="form-control no-select2" ReadOnly="true" />
                </div>
                <div class="form-group">
                    <label>Amount (AED) <small class="text-muted">[base]</small></label>
                    <asp:TextBox ID="txtAmtAed" runat="server" CssClass="form-control no-select2 pet-aed" ReadOnly="true" />
                </div>
            </div>
            <asp:HiddenField ID="hfEditPetId" runat="server" Value="0" />
            <asp:Panel ID="pnlPetAddActions" runat="server">
            <div class="toolbar">
                <asp:LinkButton ID="btnAddPet" runat="server"
                    CssClass="btn btn-success" OnClick="btnAddPet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-plus"></span> Add Line Item
                </asp:LinkButton>
                <asp:LinkButton ID="btnUpdatePet" runat="server" Visible="false"
                    CssClass="btn btn-primary" OnClick="btnAddPet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-floppy-disk"></span> Update Line
                </asp:LinkButton>
                <asp:LinkButton ID="btnCancelEdit" runat="server" Visible="false"
                    CssClass="btn btn-secondary" OnClick="btnCancelEdit_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-remove"></span> Cancel
                </asp:LinkButton>
                <div class="spacer"></div>
                <span><strong>Total (AED): <asp:Literal ID="litPetTotal" runat="server" Text="0.00" /></strong></span>
            </div>
            </asp:Panel>

            <div class="gridview-wrapper mt-2">
                <asp:GridView ID="gvPet" runat="server" AutoGenerateColumns="false" CssClass="dfm-table pet-grid-mini"
                    GridLines="None" DataKeyNames="PetID" OnRowCommand="gvPet_RowCommand"
                    OnRowDataBound="gvPet_RowDataBound">
                    <Columns>
                        <asp:BoundField DataField="SerialNo" HeaderText="#" ItemStyle-CssClass="text-center" />
                        <asp:BoundField DataField="LineCode" HeaderText="Code" />
                        <asp:BoundField DataField="Department" HeaderText="Dept" />
                        <asp:BoundField DataField="CostType" HeaderText="Cost Type" />
                        <asp:BoundField DataField="Topic" HeaderText="Topic" />
                        <asp:BoundField DataField="Vendor" HeaderText="Vendor" />
                        <asp:BoundField DataField="Units" HeaderText="Units" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UnitPrice" HeaderText="Unit Price" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BaseCurrency" HeaderText="CCY" ItemStyle-CssClass="text-center" />
                        <asp:BoundField DataField="AmtFCY" HeaderText="Amt FCY" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="FinalAmtLCY" HeaderText="Amount (AED)" DataFormatString="{0:N2}"
                            ItemStyle-CssClass="text-right font-bold" />
                        <asp:TemplateField HeaderText="Actions" ItemStyle-CssClass="text-center">
                            <ItemTemplate>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-info"
                                    CommandName="EditPet" CommandArgument='<%# Eval("PetID") %>'
                                    ToolTip="Edit this line">
                                    <span class="glyphicon glyphicon-pencil"></span>
                                </asp:LinkButton>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger"
                                    CommandName="DelPet" CommandArgument='<%# Eval("PetID") %>'
                                    OnClientClick="return confirm('Delete this line?');"
                                    ToolTip="Delete this line">
                                    <span class="glyphicon glyphicon-trash"></span>
                                </asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <EmptyDataTemplate>
                        <div class="text-center text-muted" style="padding:8px;">No PET line items yet.</div>
                    </EmptyDataTemplate>
                </asp:GridView>
            </div>

            <asp:Panel ID="pnlPetSubmitActions" runat="server">
            <div class="toolbar mt-2">
                <asp:LinkButton ID="btnSubmitPet" runat="server"
                    CssClass="btn btn-primary" OnClick="btnSubmitPet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-send"></span> Submit for PET Approval
                </asp:LinkButton>
            </div>
            </asp:Panel>
        </div>
    </div>
    </asp:Panel>

    <!-- =========== Section 3: PET APPROVAL (Req 14-18) ========== -->
    <asp:Panel ID="pnlPetApproval" runat="server" Visible="false">
    <div class="accordion <%= PetApprovalAccordionClass %>" id="accApproval">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge">PET APPROVAL</span>
            <span class="glyphicon glyphicon-ok-circle"></span>
            PET Approval
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <div class="form-grid-5">
                <div class="form-group">
                    <label>Total Requested</label>
                    <asp:TextBox ID="txtPetTotal" runat="server" CssClass="form-control no-select2" ReadOnly="true" />
                </div>
                <div class="form-group">
                    <label>Approved Amount
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              title="Req 18: Editable. Once approved, this is locked against the linked CAPEX/OPEX budget."></span>
                    </label>
                    <asp:TextBox ID="txtApprovedAmount" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group col-span-3">
                    <label>Approver Comments (Rich Text - Req 21)</label>
                    <div class="rte-toolbar">
                        <button type="button" onclick="DFM.rte(this,'bold')"><b>B</b></button>
                        <button type="button" onclick="DFM.rte(this,'italic')"><i>I</i></button>
                        <button type="button" onclick="DFM.rte(this,'underline')"><u>U</u></button>
                        <button type="button" onclick="DFM.rte(this,'insertUnorderedList')">&bull;</button>
                        <button type="button" onclick="DFM.rte(this,'insertOrderedList')">1.</button>
                    </div>
                    <div class="rte-editor" contenteditable="true" id="rteApproveComment"
                         data-target='<%= txtApproveComment.ClientID %>'></div>
                    <asp:HiddenField ID="txtApproveComment" runat="server" />
                </div>
            </div>
            <asp:Panel ID="pnlApprovalActions" runat="server">
            <div class="toolbar mt-2">
                <asp:LinkButton ID="btnApprovePet" runat="server"
                    CssClass="btn btn-success" OnClick="btnApprovePet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-ok"></span> Approve PET
                </asp:LinkButton>
                <asp:LinkButton ID="btnRejectPet" runat="server"
                    CssClass="btn btn-danger" OnClick="btnRejectPet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-remove"></span> Reject PET
                </asp:LinkButton>
            </div>
            </asp:Panel>
        </div>
    </div>
    </asp:Panel>

    <!-- =========== Section 4: BPM (Req 19-20) ========== -->
    <asp:Panel ID="pnlBpm" runat="server" Visible="false">
    <div class="accordion <%= BpmAccordionClass %>" id="accBpm">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge">BPM</span>
            <span class="glyphicon glyphicon-tasks"></span>
            BPM Stage
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <div class="form-grid-5">
                <div class="form-group">
                    <label>BPM Reference</label>
                    <asp:TextBox ID="txtBpmRef" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Invoice No</label>
                    <asp:TextBox ID="txtInvoiceNo" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Invoice Date</label>
                    <asp:TextBox ID="txtInvoiceDate" runat="server" CssClass="form-control" TextMode="Date" />
                </div>
                <div class="form-group">
                    <label>Invoice Amount</label>
                    <asp:TextBox ID="txtInvoiceAmount" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Vendor</label>
                    <asp:TextBox ID="txtBpmVendor" runat="server" CssClass="form-control" />
                </div>
            </div>
            <div class="form-grid-5">
                <div class="form-group col-span-5">
                    <label>BPM Closing Comments (Rich Text)</label>
                    <div class="rte-toolbar">
                        <button type="button" onclick="DFM.rte(this,'bold')"><b>B</b></button>
                        <button type="button" onclick="DFM.rte(this,'italic')"><i>I</i></button>
                        <button type="button" onclick="DFM.rte(this,'underline')"><u>U</u></button>
                        <button type="button" onclick="DFM.rte(this,'insertUnorderedList')">&bull;</button>
                    </div>
                    <div class="rte-editor" contenteditable="true" id="rteBpmNotes"
                         data-target='<%= txtBpmNotes.ClientID %>'></div>
                    <asp:HiddenField ID="txtBpmNotes" runat="server" />
                </div>
            </div>
            <asp:Panel ID="pnlBpmActions" runat="server">
            <div class="toolbar mt-2">
                <asp:LinkButton ID="btnSubmitBpm" runat="server"
                    CssClass="btn btn-primary" OnClick="btnSubmitBpm_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-send"></span> Submit BPM
                </asp:LinkButton>
                <asp:LinkButton ID="btnCloseBpm" runat="server"
                    CssClass="btn btn-success" OnClick="btnCloseBpm_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-ok-circle"></span> Mark BPM Closed
                </asp:LinkButton>
            </div>
            </asp:Panel>
        </div>
    </div>
    </asp:Panel>

    <!-- =========== Section 5: Attachments (Req 22) ========== -->
    <asp:Panel ID="pnlAttach" runat="server" Visible="false">
    <div class="accordion collapsed" id="accAttach">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge stage-active">ATTACHMENTS</span>
            <span class="glyphicon glyphicon-paperclip"></span>
            Attachments (Requestor &amp; Approver)
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <%-- Drag-and-drop zone targets the hidden FileUpload control --%>
            <div class="dropzone" id="dzAttach" onclick="document.getElementById('<%= fuAttach.ClientID %>').click();">
                <span class="glyphicon glyphicon-cloud-upload"></span>
                <div class="dz-title">Drop files here or click to browse</div>
                <div class="dz-hint">Multiple files supported. Files will upload when you click <strong>Upload</strong>.</div>
                <div class="dz-file-list" id="dzFiles"></div>
            </div>
            <div style="position:absolute; left:-9999px;">
                <asp:FileUpload ID="fuAttach" runat="server" AllowMultiple="true" />
            </div>
            <div class="toolbar">
                <label class="form-group" style="margin-bottom:0;">
                    <span style="font-size:.82em; font-weight:700;">Stage:</span>
                </label>
                <asp:DropDownList ID="ddlAttachStage" runat="server" CssClass="form-control no-select2" Style="width:160px;">
                    <asp:ListItem>PET</asp:ListItem>
                    <asp:ListItem>BPM</asp:ListItem>
                    <asp:ListItem>Approval</asp:ListItem>
                    <asp:ListItem>General</asp:ListItem>
                </asp:DropDownList>
                <asp:LinkButton ID="btnUploadAttach" runat="server"
                    CssClass="btn btn-primary" OnClick="btnUploadAttach_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-paperclip"></span> Upload Selected
                </asp:LinkButton>
            </div>

            <script>
                (function () {
                    var dz = document.getElementById('dzAttach');
                    var input = document.getElementById('<%= fuAttach.ClientID %>');
                    var list = document.getElementById('dzFiles');
                    if (!dz || !input) return;

                    function renderFiles() {
                        list.innerHTML = '';
                        var files = input.files;
                        if (!files || files.length === 0) return;
                        for (var i = 0; i < files.length; i++) {
                            var f = files[i];
                            var chip = document.createElement('span');
                            chip.className = 'dz-chip';
                            chip.innerHTML = '<span class="glyphicon glyphicon-ok"></span>' +
                                             '<span></span>';
                            chip.lastChild.textContent = f.name + ' (' + Math.ceil(f.size / 1024) + ' KB)';
                            list.appendChild(chip);
                        }
                    }

                    ['dragenter','dragover'].forEach(function (ev) {
                        dz.addEventListener(ev, function (e) {
                            e.preventDefault(); e.stopPropagation();
                            dz.classList.add('dragover');
                        });
                    });
                    ['dragleave','drop'].forEach(function (ev) {
                        dz.addEventListener(ev, function (e) {
                            e.preventDefault(); e.stopPropagation();
                            dz.classList.remove('dragover');
                        });
                    });
                    dz.addEventListener('drop', function (e) {
                        if (!e.dataTransfer || !e.dataTransfer.files) return;
                        // Assign dropped files to the hidden ASP.NET FileUpload control
                        try { input.files = e.dataTransfer.files; }
                        catch (err) { /* older browsers ignore - fall back to click-to-browse */ }
                        renderFiles();
                    });
                    input.addEventListener('change', renderFiles);
                })();
            </script>
            <asp:Repeater ID="rptAttach" runat="server">
                <HeaderTemplate><div class="attach-list mt-2"></HeaderTemplate>
                <ItemTemplate>
                    <a href='<%# ResolveUrl(Eval("StoredPath").ToString()) %>' target="_blank">
                        <span class="glyphicon glyphicon-paperclip"></span>
                        <%# Eval("FileName") %>
                        <small class="text-muted">(<%# Eval("Stage") %> &middot; <%# Eval("UploadedBy") %>)</small>
                    </a>
                </ItemTemplate>
                <FooterTemplate></div></FooterTemplate>
            </asp:Repeater>
        </div>
    </div>
    </asp:Panel>

    <!-- =========== Section 6: AI Chat (Req 33-35) ========== -->
    <div class="accordion collapsed" id="accAI">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge stage-active">AI</span>
            <span class="glyphicon glyphicon-flash"></span>
            Gemini AI Copilot
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body" style="padding:0;">
            <div class="ai-chat-panel" style="margin:0; border:0;">
                <div class="ai-chat-header">
                    <span class="glyphicon glyphicon-flash"></span> Gemini AI Copilot
                    <span class="text-muted" style="margin-left:auto; font-weight:400; font-size:.8em; opacity:.7;">
                        Powered by Gemini 2.0
                    </span>
                </div>
                <div class="ai-chat-messages" id="aiMessages">
                    <div class="ai">Hello! Ask me anything about this project, PET, or BPM workflow.</div>
                </div>
                <div class="ai-chat-input">
                    <textarea id="aiTxt" placeholder="Ask AI about this workflow..."></textarea>
                    <button type="button" class="btn btn-primary" onclick="DFM.aiSend()">
                        <span class="glyphicon glyphicon-send"></span> Send
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- =========== Section 7: Workflow History (Req 23-26) ========== -->
    <div class="accordion <%= HistoryAccordionClass %>" id="accHistory">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge stage-done">HISTORY</span>
            <span class="glyphicon glyphicon-time"></span>
            Workflow History
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <div class="gridview-wrapper">
                <asp:GridView ID="gvHistory" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table audit-table" GridLines="None"
                    AllowPaging="true" PageSize="15"
                    OnPageIndexChanging="gvHistory_PageIndexChanging">
                    <PagerStyle CssClass="pager" />
                    <Columns>
                        <asp:TemplateField HeaderText="#" ItemStyle-Width="40px" ItemStyle-CssClass="text-center">
                            <ItemTemplate>
                                <%# Container.DataItemIndex + 1 + (gvHistory.PageIndex * gvHistory.PageSize) %>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Stage" ItemStyle-Width="140px">
                            <ItemTemplate>
                                <span class='audit-stage audit-<%# Eval("Stage").ToString().ToLower().Replace(" ", "-") %>'>
                                    <%# Eval("Stage") %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="ActionBy" HeaderText="Action By" ItemStyle-Width="140px" />
                        <asp:BoundField DataField="ActionDate" HeaderText="Date / Time"
                            DataFormatString="{0:dd-MMM-yy HH:mm}" HtmlEncode="false"
                            ItemStyle-Width="140px" />
                        <asp:TemplateField HeaderText="Version" ItemStyle-Width="70px" ItemStyle-CssClass="text-center">
                            <ItemTemplate>
                                <span class="chip chip-capex">v<%# Eval("Version") %></span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Approval Level" ItemStyle-Width="90px" ItemStyle-CssClass="text-center">
                            <ItemTemplate>
                                <%# Eval("ApprovalLevel") == System.DBNull.Value ? "&mdash;" : Eval("ApprovalLevel") %>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Comments">
                            <ItemTemplate>
                                <%# Eval("Comments") == System.DBNull.Value || Eval("Comments").ToString() == "" ? "<span class='text-muted'>(no comments)</span>" : Eval("Comments") %>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <EmptyDataTemplate>
                        <div class="text-center text-muted" style="padding:14px;">No audit entries recorded yet.</div>
                    </EmptyDataTemplate>
                </asp:GridView>
            </div>
            <asp:Panel ID="pnlNoHistory" runat="server" CssClass="text-muted text-center" Visible="false">
                No history recorded yet.
            </asp:Panel>
        </div>
    </div>

    <!-- Floating AI button (Gemini style) -->
    <button type="button" class="ai-float-btn" onclick="DFM.scrollToAi()" title="Open AI Copilot">&#10022;</button>

    <script>
        // Bootstrap: ensure DFM namespace exists. app.js is loaded by the master page
        // AFTER this inline block, so we must create the object ourselves.
        window.DFM = window.DFM || {};

        // ===== Live FCY -> AED converter for the PET line-item editor =====
        DFM.petRates = <%= string.IsNullOrEmpty(PetRatesJs) ? "{\"AED\":1}" : PetRatesJs %>;
        DFM.petRecalc = function () {
            var u = parseFloat((document.getElementById('<%= txtUnits.ClientID %>') || {}).value || 0) || 0;
            var p = parseFloat((document.getElementById('<%= txtUnitPrice.ClientID %>') || {}).value || 0) || 0;
            var ccyEl = document.getElementById('<%= ddlCurrency.ClientID %>');
            var ccy = ccyEl ? (ccyEl.value || 'AED') : 'AED';
            var rate = DFM.petRates[ccy] || 1;
            var fcy = u * p;
            var aed = fcy * rate;
            var elF = document.getElementById('<%= txtAmtFcy.ClientID %>');
            var elA = document.getElementById('<%= txtAmtAed.ClientID %>');
            if (elF) elF.value = fcy.toFixed(2);
            if (elA) elA.value = aed.toFixed(2);
        };
        $(function () {
            $('.pet-calc').on('input change keyup', DFM.petRecalc);
            DFM.petRecalc();
        });

        // Sync RTE -> hidden field on submit
        $(function () {
            $('.rte-editor').each(function () {
                var $rte = $(this);
                var tid  = $rte.data('target');
                var $hf  = $('#' + tid);
                if ($hf.val()) $rte.html($hf.val());
                $rte.on('keyup blur', function () { $hf.val($rte.html()); });
            });
            // Force-sync on submit
            $('form').on('submit', function () {
                $('.rte-editor').each(function () {
                    var $rte = $(this);
                    var tid  = $rte.data('target');
                    $('#' + tid).val($rte.html());
                });
            });
        });

        DFM.rte = function (btn, cmd) {
            // Re-focus the editor inside this toolbar before exec
            var ed = btn.closest('.rte-toolbar').nextElementSibling;
            if (ed) ed.focus();
            document.execCommand(cmd, false, null);
        };

        DFM.toggleAcc = function (hdr) {
            var acc = hdr.parentElement;
            if (!acc) return;
            acc.classList.toggle('collapsed');
            DFM.syncOpen();
        };

        // ===== State retention across postbacks =====
        DFM.syncOpen = function () {
            var hf = document.getElementById('<%= hfOpenSections.ClientID %>');
            if (!hf) return;
            var open = [];
            document.querySelectorAll('.accordion').forEach(function (a) {
                if (a.id && !a.classList.contains('collapsed')) open.push(a.id);
            });
            hf.value = open.join(',');
        };

        DFM.restoreState = function () {
            var hfOpen = document.getElementById('<%= hfOpenSections.ClientID %>');
            if (hfOpen && hfOpen.value !== '') {
                var ids = hfOpen.value.split(',');
                document.querySelectorAll('.accordion').forEach(function (a) {
                    if (!a.id) return;
                    if (ids.indexOf(a.id) !== -1) a.classList.remove('collapsed');
                    else                          a.classList.add('collapsed');
                });
            }
            var hfFocus = document.getElementById('<%= hfFocus.ClientID %>');
            if (hfFocus && hfFocus.value) {
                var el = document.getElementById(hfFocus.value);
                if (el && typeof el.focus === 'function') {
                    setTimeout(function () { try { el.focus(); } catch (e) {} }, 0);
                }
            }
            // MaintainScrollPositionOnPostback handles the browser scroll, but
            // we also restore from our hidden field as a belt-and-braces fallback.
            var hfScroll = document.getElementById('<%= hfScroll.ClientID %>');
            if (hfScroll && hfScroll.value) {
                var y = parseInt(hfScroll.value, 10);
                if (!isNaN(y)) setTimeout(function () { window.scrollTo(0, y); }, 0);
            }
        };

        // Capture focus + scroll just before any postback so it can be restored after
        $(document).on('focus', 'input, textarea, select, [contenteditable=true]', function () {
            var hfFocus = document.getElementById('<%= hfFocus.ClientID %>');
            if (hfFocus && this.id) hfFocus.value = this.id;
        });
        // ASP.NET WebForms calls form.submit() programmatically which does NOT fire
        // the 'submit' DOM event. Sync state on click of any postback trigger instead.
        DFM.persistBeforePost = function () {
            var hfScroll = document.getElementById('<%= hfScroll.ClientID %>');
            if (hfScroll) hfScroll.value = (window.pageYOffset || document.documentElement.scrollTop || 0);
            DFM.syncOpen();
        };
        $(document).on('click', '.btn, .nav-item, [onclick^="__doPostBack"]', DFM.persistBeforePost);
        $(document).on('change', 'select[onchange], input[onchange]', DFM.persistBeforePost);
        // MS-AJAX (UpdatePanel) path - hook it too if a ScriptManager is later added.
        if (typeof Sys !== 'undefined' && Sys.WebForms && Sys.WebForms.PageRequestManager) {
            var prm = Sys.WebForms.PageRequestManager.getInstance();
            prm.add_initializeRequest(DFM.persistBeforePost);
            prm.add_endRequest(function () { DFM.restoreState(); });
        }
        // On every load, restore
        $(function () { DFM.restoreState(); });

        DFM.scrollToAi = function () {
            var el = document.getElementById('aiMessages');
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        };

        // Req 33-35: Gemini AI Chat via AIHandler.ashx (server-side proxy keeps key off client)
        DFM.aiSend = function () {
            var txt = document.getElementById('aiTxt');
            var msg = (txt.value || '').trim();
            if (!msg) return;
            var msgs = document.getElementById('aiMessages');
            msgs.innerHTML += '<div class="user">' + DFM.escapeHtml(msg) + '</div>';
            txt.value = '';
            var loadId = 'l_' + Date.now();
            msgs.innerHTML += '<div class="ai" id="' + loadId + '">Thinking...</div>';
            msgs.scrollTop = msgs.scrollHeight;

            fetch('<%= ResolveUrl("~/AIHandler.ashx") %>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: msg, projectId: <%= CurrentProjectIdJs %> })
            })
            .then(function (r) { return r.text(); })
            .then(function (t) {
                var el = document.getElementById(loadId); if (el) el.remove();
                msgs.innerHTML += '<div class="ai">' + DFM.escapeHtml(t) + '</div>';
                msgs.scrollTop = msgs.scrollHeight;
            })
            .catch(function () {
                var el = document.getElementById(loadId); if (el) el.remove();
                msgs.innerHTML += '<div class="ai">Error calling AI service.</div>';
            });
        };

        // Enter to send (Shift+Enter = newline)
        document.addEventListener('keydown', function (e) {
            if (e.target && e.target.id === 'aiTxt' && e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault(); DFM.aiSend();
            }
        });

        DFM.escapeHtml = function (s) {
            var d = document.createElement('div'); d.innerText = s; return d.innerHTML;
        };
    </script>
</asp:Content>
