<%@ Page Title="Workflow" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    MaintainScrollPositionOnPostback="true"
    CodeBehind="Workflow.aspx.cs" Inherits="DFM.Forms.Workflow" %>
<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
    <style>
        .stage-progress { margin-bottom: 10px; }
        .pet-grid-mini th, .pet-grid-mini td { font-size: .85em; padding: 4px 6px; }
        .pet-row-editing td { background: linear-gradient(180deg, #fff3cd 0%, #ffe69c 100%) !important; }
        .pet-aed { background: linear-gradient(180deg, #ecfeff 0%, #cffafe 100%) !important; font-weight: 700 !important; color: #155e75 !important; }
        .attach-list a { display: inline-block; margin-right: 12px; }
    </style>
</asp:Content>
<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">

    <h1 class="page-title">
        <span class="glyphicon glyphicon-road"></span>
        Project Workflow
        <small style="font-weight:400; font-size:.62em; margin-left:8px; color:#5a6477;">
            Unified screen &middot; Project &rarr; PET &rarr; BPM
        </small>
    </h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <%-- Client-side state: open accordion ids + last focus + last scroll. --%>
    <asp:HiddenField ID="hfOpenSections" runat="server" />
    <asp:HiddenField ID="hfFocus" runat="server" />
    <asp:HiddenField ID="hfScroll" runat="server" />

    <!-- ========== JIRA / Project Flow section (collapsible) ========== -->
    <div class="jira-top" id="jiraTopPanel">
        <div class="jira-collapse-hdr" onclick="dfmJiraToggle()" title="Click to expand / collapse">
            <div style="display:flex;align-items:baseline;gap:12px;">
                <span class="jira-id"><asp:Literal ID="litJiraId" runat="server" Text="DMGT-???" /></span>
                <strong style="font-size:1em;"><asp:Literal ID="litJiraName" runat="server" Text="(select a JIRA ID below)" /></strong>
                <span style="margin-left:8px;"><asp:Literal ID="litJStatus" runat="server" /></span>
            </div>
            <span id="jiraToggleIcon" class="glyphicon glyphicon-chevron-down jira-chev"></span>
        </div>
        <div id="jiraFieldsGrid" class="jira-grid jira-grid-wide">
            <div><div class="lbl">Project Name</div><div class="val"><asp:Literal ID="litJProjectName" runat="server" /></div></div>
            <div><div class="lbl">Project Type</div><div class="val"><asp:Literal ID="litJProjectType" runat="server" /></div></div>
            <div><div class="lbl">Demand Type</div><div class="val"><asp:Literal ID="litJDemand" runat="server" /></div></div>
            <div><div class="lbl">RAG</div><div class="val"><asp:Literal ID="litJRag" runat="server" /></div></div>
            <div><div class="lbl">Stage</div><div class="val"><asp:Literal ID="litJStage" runat="server" /></div></div>
            <div><div class="lbl">Department</div><div class="val"><asp:Literal ID="litJDept" runat="server" /></div></div>
            <div><div class="lbl">Classification</div><div class="val"><asp:Literal ID="litJClassification" runat="server" /></div></div>
            <div><div class="lbl">Platform</div><div class="val"><asp:Literal ID="litJPlatform" runat="server" /></div></div>
            <div><div class="lbl">Platform Vertical</div><div class="val"><asp:Literal ID="litJPlatformVertical" runat="server" /></div></div>
            <div><div class="lbl">Issue Type</div><div class="val"><asp:Literal ID="litJIssueType" runat="server" /></div></div>
            <div><div class="lbl">Manager</div><div class="val"><asp:Literal ID="litJMgr" runat="server" /></div></div>
            <div><div class="lbl">Tech Lead</div><div class="val"><asp:Literal ID="litJTech" runat="server" /></div></div>
            <div><div class="lbl">Sponsor</div><div class="val"><asp:Literal ID="litJSponsor" runat="server" /></div></div>
            <div><div class="lbl">Stakeholder</div><div class="val"><asp:Literal ID="litJStakeholder" runat="server" /></div></div>
            <div><div class="lbl">Assignee</div><div class="val"><asp:Literal ID="litJAssignee" runat="server" /></div></div>
            <div><div class="lbl">Reporter</div><div class="val"><asp:Literal ID="litJReporter" runat="server" /></div></div>
            <div><div class="lbl">Accountable Exec Lead</div><div class="val"><asp:Literal ID="litJAccExecLead" runat="server" /></div></div>
            <div><div class="lbl">SME Lead</div><div class="val"><asp:Literal ID="litJSmeLead" runat="server" /></div></div>
            <div><div class="lbl">Accountable Exec</div><div class="val"><asp:Literal ID="litJAccExec" runat="server" /></div></div>
            <div><div class="lbl">IDH Portfolio Head</div><div class="val"><asp:Literal ID="litJPortfolioHead" runat="server" /></div></div>
            <div><div class="lbl">Assigned PM</div><div class="val"><asp:Literal ID="litJAssignedPM" runat="server" /></div></div>
            <div><div class="lbl">Demand Owner</div><div class="val"><asp:Literal ID="litJDemandOwner" runat="server" /></div></div>
            <div><div class="lbl">Chief</div><div class="val"><asp:Literal ID="litJChief" runat="server" /></div></div>
            <div><div class="lbl">Primary Classification</div><div class="val"><asp:Literal ID="litJPrimaryClass" runat="server" /></div></div>
            <div><div class="lbl">JIRA Created</div><div class="val"><asp:Literal ID="litJCreated" runat="server" /></div></div>
            <div><div class="lbl">JIRA Updated</div><div class="val"><asp:Literal ID="litJUpdated" runat="server" /></div></div>
            <div><div class="lbl">Start</div><div class="val"><asp:Literal ID="litJStart" runat="server" /></div></div>
            <div><div class="lbl">End</div><div class="val"><asp:Literal ID="litJEnd" runat="server" /></div></div>
        </div>
    </div>

    <!-- ========== Workflow stepper (Req 29-30) ========== -->
    <div class="workflow-stepper stage-progress">
        <asp:Literal ID="litStepper" runat="server" />
    </div>

    <!-- =========== Section 1: PROJECT (Req 27 collapsible) ========== -->
    <div class="accordion <%= ProjectAccordionClass %>" id="accProject">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge">PROJECT</span>
            <span class="glyphicon glyphicon-folder-open"></span>
            Project Identity &amp; Budget Source
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <div class="form-grid-6">
                <div class="form-group">
                    <label>JIRA ID / Project ID
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              data-toggle="tooltip" data-placement="top"
                              title="Only DMGT project keys are displayed."></span>
                    </label>
                    <asp:DropDownList ID="ddlJira" runat="server" CssClass="form-control"
                        AutoPostBack="true" OnSelectedIndexChanged="ddlJira_Changed" />
                </div>
                <div class="form-group col-span-2">
                    <label>Project Name
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              data-toggle="tooltip" data-placement="top"
                              title="Auto-populated from JIRA Summary field."></span>
                    </label>
                    <asp:TextBox ID="txtName" runat="server" CssClass="form-control" ReadOnly="true" />
                </div>
                <div class="form-group">
                    <label>Project Type</label>
                    <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control" AutoPostBack="true"
                        OnSelectedIndexChanged="ddlType_Changed">
                        <asp:ListItem Value="CAPEX">CAPEX</asp:ListItem>
                        <asp:ListItem Value="OPEX">OPEX</asp:ListItem>
                        <asp:ListItem Value="AMC">AMC</asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>PET Approver</label>
                    <asp:DropDownList ID="ddlApprover" runat="server" CssClass="form-control" />
                </div>
            </div>

            <div class="form-grid-6">
                <div class="form-group col-span-4">
                    <label>
                        <asp:Literal ID="litSourceLabel" runat="server" Text="CAPEX" /> Source
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              data-toggle="tooltip" data-placement="top"
                              title="CAPEX/OPEX/AMC linking functionality is available for all projects."></span>
                    </label>
                    <asp:DropDownList ID="ddlSource" runat="server" CssClass="form-control" AutoPostBack="true"
                        OnSelectedIndexChanged="ddlSource_Changed" />
                </div>
                <div class="form-group col-span-2">
                    &nbsp;
                </div>
            </div>

            <asp:Panel ID="pnlBudget" runat="server" Visible="false">
                <div class="budget-grid">
                    <div class="budget-cell budget">
                        <span class="bc-icon glyphicon glyphicon-briefcase"></span>
                        <div class="lbl">Previous Balance</div>
                        <div class="val"><asp:Literal ID="bBudget" runat="server" /></div>
                    </div>
                    <div class="budget-cell utilized">
                        <span class="bc-icon glyphicon glyphicon-stats"></span>
                        <div class="lbl">Utilized Amount</div>
                        <div class="val"><asp:Literal ID="bUtil" runat="server" /></div>
                    </div>
                    <div class="budget-cell available">
                        <span class="bc-icon glyphicon glyphicon-ok-circle"></span>
                        <div class="lbl">Net Available Balance</div>
                        <div class="val"><asp:Literal ID="bAvail" runat="server" /></div>
                    </div>
                    <div class="budget-cell locked">
                        <span class="bc-icon glyphicon glyphicon-lock"></span>
                        <div class="lbl">Locked</div>
                        <div class="val"><asp:Literal ID="bLock" runat="server" /></div>
                    </div>
                    <div class="budget-cell netbal">
                        <span class="bc-icon glyphicon glyphicon-scale"></span>
                        <div class="lbl">Net Balance</div>
                        <div class="val"><asp:Literal ID="bNet" runat="server" /></div>
                    </div>
                </div>
            </asp:Panel>

            <asp:Panel ID="pnlProjectActions" runat="server">
            <div class="toolbar mt-2">
                <asp:LinkButton ID="btnSaveProject" runat="server" CssClass="btn btn-secondary"
                    OnClick="btnSaveProject_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-floppy-disk"></span> Save as Draft
                </asp:LinkButton>
                <asp:LinkButton ID="btnSubmitProject" runat="server"
                    CssClass="btn btn-primary" OnClick="btnSubmitProject_Click">
                    <span class="glyphicon glyphicon-circle-arrow-right"></span> Save &amp; Continue to PET
                </asp:LinkButton>
            </div>
            </asp:Panel>
        </div>
    </div>

    <!-- =========== Section 2: PET FORM (Req 10-13) ========== -->
    <asp:Panel ID="pnlPet" runat="server" Visible="false">
    <div class="accordion acc-pet <%= PetAccordionClass %>" id="accPet">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge">PET</span>
            <span class="glyphicon glyphicon-list"></span>
            PET Form (Line Items)
            <asp:Literal ID="litPetVersions" runat="server" />
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">

            <div class="toolbar">
                <asp:LinkButton ID="btnPetDownload" runat="server"
                    CssClass="btn btn-success" OnClick="btnPetDownload_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-download-alt"></span> Download CSV
                </asp:LinkButton>
                <asp:LinkButton ID="btnPetTemplate" runat="server"
                    CssClass="btn btn-info" OnClick="btnPetTemplate_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-file"></span> Template
                </asp:LinkButton>

                <span class="text-muted" style="margin-left:8px;">Upload PET CSV:</span>
                <asp:FileUpload ID="fuPetCsv" runat="server" />

                <label style="margin-left:8px;">
                    <input type="radio" name="petUploadMode" value="Retain" id="rbRetain" checked="checked" />
                    Retain Old Records
                </label>
                <label>
                    <input type="radio" name="petUploadMode" value="Delete" id="rbDelete" />
                    Delete Old Records
                </label>
                <asp:LinkButton ID="btnPetUpload" runat="server"
                    CssClass="btn btn-primary" OnClick="btnPetUpload_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-upload"></span> Upload
                </asp:LinkButton>
            </div>

            <!-- Inline add (6-col layout, Description spans rows 1+2) -->
            <div class="pet-entry-grid">
                <div class="form-group">
                    <label>Department
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              title='<%= GetGuidance("Department") %>'></span>
                    </label>
                    <asp:DropDownList ID="ddlDept" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Cost Type
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              title='<%= GetGuidance("Cost Type") %>'></span>
                    </label>
                    <asp:DropDownList ID="ddlCostType" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Exp. Head</label>
                    <asp:DropDownList ID="ddlExpHead" runat="server" CssClass="form-control">
                        <asp:ListItem>Capex</asp:ListItem>
                        <asp:ListItem>Opex</asp:ListItem>
                    </asp:DropDownList>
                </div>
                <div class="form-group">
                    <label>Topic</label>
                    <asp:TextBox ID="txtTopic" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Vendor</label>
                    <asp:TextBox ID="txtVendor" runat="server" CssClass="form-control" />
                </div>
                <%-- Description spans column 6, rows 1 and 2 --%>
                <div class="form-group pet-desc-span">
                    <label>Description</label>
                    <asp:TextBox ID="txtDesc" runat="server" CssClass="form-control" TextMode="MultiLine"
                        style="height:100%;min-height:72px;resize:none;" />
                </div>
                <div class="form-group">
                    <label>Units</label>
                    <asp:TextBox ID="txtUnits" runat="server" CssClass="form-control pet-calc" Text="1" />
                </div>
                <div class="form-group">
                    <label>Unit Price (FCY)</label>
                    <asp:TextBox ID="txtUnitPrice" runat="server" CssClass="form-control pet-calc" />
                </div>
                <div class="form-group">
                    <label>Currency</label>
                    <asp:DropDownList ID="ddlCurrency" runat="server" CssClass="form-control no-select2 pet-calc" />
                </div>
                <div class="form-group">
                    <label>Amount (FCY) <small class="text-muted">[auto]</small></label>
                    <asp:TextBox ID="txtAmtFcy" runat="server" CssClass="form-control no-select2" ReadOnly="true" />
                </div>
                <div class="form-group">
                    <label>Amount (AED) <small class="text-muted">[base]</small></label>
                    <asp:TextBox ID="txtAmtAed" runat="server" CssClass="form-control no-select2 pet-aed" ReadOnly="true" />
                </div>
            </div>
            <asp:HiddenField ID="hfEditPetId" runat="server" Value="0" />
            <asp:Panel ID="pnlPetAddActions" runat="server">
            <div class="toolbar">
                <asp:LinkButton ID="btnAddPet" runat="server"
                    CssClass="btn btn-success" OnClick="btnAddPet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-plus"></span> Add Line Item
                </asp:LinkButton>
                <asp:LinkButton ID="btnUpdatePet" runat="server" Visible="false"
                    CssClass="btn btn-primary" OnClick="btnAddPet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-floppy-disk"></span> Update Line
                </asp:LinkButton>
                <asp:LinkButton ID="btnCancelEdit" runat="server" Visible="false"
                    CssClass="btn btn-secondary" OnClick="btnCancelEdit_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-remove"></span> Cancel
                </asp:LinkButton>
                <div class="spacer"></div>
                <span><strong>Total (AED): <asp:Literal ID="litPetTotal" runat="server" Text="0.00" /></strong></span>
            </div>
            </asp:Panel>

            <div class="gridview-wrapper mt-2">
                <asp:GridView ID="gvPet" runat="server" AutoGenerateColumns="false" CssClass="dfm-table pet-grid-mini"
                    GridLines="None" DataKeyNames="PetID" OnRowCommand="gvPet_RowCommand"
                    OnRowDataBound="gvPet_RowDataBound"
                    AllowPaging="true" PageSize="10" OnPageIndexChanging="gvPet_PageIndexChanging">
                    <PagerStyle CssClass="pager" HorizontalAlign="Right" />
                    <Columns>
                        <asp:BoundField DataField="SerialNo" HeaderText="#" ItemStyle-CssClass="text-center" />
                        <asp:BoundField DataField="LineCode" HeaderText="Code" />
                        <asp:BoundField DataField="Department" HeaderText="Dept" />
                        <asp:BoundField DataField="CostType" HeaderText="Cost Type" />
                        <asp:BoundField DataField="Topic" HeaderText="Topic" />
                        <asp:BoundField DataField="Vendor" HeaderText="Vendor" />
                        <asp:BoundField DataField="Units" HeaderText="Units" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UnitPrice" HeaderText="Unit Price" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BaseCurrency" HeaderText="CCY" ItemStyle-CssClass="text-center" />
                        <asp:BoundField DataField="AmtFCY" HeaderText="Amt FCY" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="FinalAmtLCY" HeaderText="Amount (AED)" DataFormatString="{0:N2}"
                            ItemStyle-CssClass="text-right font-bold" />
                        <asp:TemplateField HeaderText="Actions" ItemStyle-CssClass="text-center">
                            <ItemTemplate>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-info"
                                    CommandName="EditPet" CommandArgument='<%# Eval("PetID") %>'
                                    ToolTip="Edit this line">
                                    <span class="glyphicon glyphicon-pencil"></span>
                                </asp:LinkButton>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger"
                                    CommandName="DelPet" CommandArgument='<%# Eval("PetID") %>'
                                    OnClientClick="return confirm('Delete this line?');"
                                    ToolTip="Delete this line">
                                    <span class="glyphicon glyphicon-trash"></span>
                                </asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <EmptyDataTemplate>
                        <div class="text-center text-muted" style="padding:8px;">No PET line items yet.</div>
                    </EmptyDataTemplate>
                </asp:GridView>
            </div>

            <asp:Panel ID="pnlPetSubmitActions" runat="server">
            <div class="toolbar mt-2">
                <asp:LinkButton ID="btnSubmitPet" runat="server"
                    CssClass="btn btn-primary" OnClick="btnSubmitPet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-send"></span> Submit for PET Approval
                </asp:LinkButton>
            </div>
            </asp:Panel>
        </div>
    </div>
    </asp:Panel>

    <!-- =========== Section 3: PET APPROVAL (Req 14-18) ========== -->
    <asp:Panel ID="pnlPetApproval" runat="server" Visible="false">
    <div class="accordion <%= PetApprovalAccordionClass %>" id="accApproval">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge">PET APPROVAL</span>
            <span class="glyphicon glyphicon-ok-circle"></span>
            PET Approval
            <asp:Literal ID="litPendingWithBanner" runat="server" />
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <%-- Version history table (Req 1.4) --%>
            <asp:Literal ID="litPetVersionTable" runat="server" />

            <div class="form-grid-5 mt-2">
                <div class="form-group">
                    <label>Total Requested</label>
                    <asp:TextBox ID="txtPetTotal" runat="server" CssClass="form-control no-select2" ReadOnly="true" />
                </div>
                <div class="form-group">
                    <label>Approved Amount
                        <span class="glyphicon glyphicon-info-sign field-help-icon"
                              title="Req 18: Editable. Once approved, this is locked against the linked CAPEX/OPEX budget."></span>
                    </label>
                    <asp:TextBox ID="txtApprovedAmount" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group col-span-3">
                    <label>Approver Comments (Rich Text - Req 21)</label>
                    <div class="rte-toolbar">
                        <button type="button" onclick="DFM.rte(this,'bold')"><b>B</b></button>
                        <button type="button" onclick="DFM.rte(this,'italic')"><i>I</i></button>
                        <button type="button" onclick="DFM.rte(this,'underline')"><u>U</u></button>
                        <button type="button" onclick="DFM.rte(this,'insertUnorderedList')">&bull;</button>
                        <button type="button" onclick="DFM.rte(this,'insertOrderedList')">1.</button>
                    </div>
                    <div class="rte-editor" contenteditable="true" id="rteApproveComment"
                         data-target='<%= txtApproveComment.ClientID %>'></div>
                    <asp:HiddenField ID="txtApproveComment" runat="server" />
                </div>
            </div>
            <asp:Panel ID="pnlApprovalActions" runat="server">
            <div class="toolbar mt-2">
                <asp:LinkButton ID="btnApprovePet" runat="server"
                    CssClass="btn btn-success" OnClick="btnApprovePet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-ok"></span> Approve PET
                </asp:LinkButton>
                <asp:LinkButton ID="btnRejectPet" runat="server"
                    CssClass="btn btn-danger" OnClick="btnRejectPet_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-remove"></span> Reject PET
                </asp:LinkButton>
            </div>
            </asp:Panel>
        </div>
    </div>
    </asp:Panel>

    <!-- =========== Section 4: INTERNAL MEMO / CAM (Req 6 BPM) ========== -->
    <asp:Panel ID="pnlBpm" runat="server" Visible="false">
    <div class="accordion acc-bpm <%= BpmAccordionClass %>" id="accBpm">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge">BPM</span>
            <span class="glyphicon glyphicon-tasks"></span>
            Internal Memo Creation
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">

            <%-- Memo entry form — Row 1: 7 fields, Row 2: AMS#, Desc, actions inline --%>
            <div class="memo-row1">
                <div class="form-group">
                    <label>GL#</label>
                    <asp:DropDownList ID="ddlGL" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Memo# / CAM ID</label>
                    <asp:TextBox ID="txtMemoNumber" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Approved Amount (AED)</label>
                    <asp:TextBox ID="txtMemoAmount" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Vendor</label>
                    <asp:DropDownList ID="ddlMemoVendor" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>Date Raised</label>
                    <asp:TextBox ID="txtMemoDateRaised" runat="server" CssClass="form-control" TextMode="Date" />
                </div>
                <div class="form-group">
                    <label>LPO/SO #</label>
                    <asp:TextBox ID="txtMemoLPO" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group">
                    <label>PO Date</label>
                    <asp:TextBox ID="txtMemoPODate" runat="server" CssClass="form-control" TextMode="Date" />
                </div>
            </div>
            <asp:HiddenField ID="hfEditMemoId" runat="server" Value="0" />
            <asp:Panel ID="pnlBpmActions" runat="server">
            <div class="memo-row2">
                <div class="form-group">
                    <label>AMS #</label>
                    <asp:TextBox ID="txtMemoAMS" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group memo-desc-cell">
                    <label>Description</label>
                    <asp:TextBox ID="txtMemoDesc" runat="server" CssClass="form-control" />
                </div>
                <div class="form-group memo-action-cell">
                    <label>&nbsp;</label>
                    <asp:LinkButton ID="btnAddMemo" runat="server"
                        CssClass="btn btn-primary btn-block" OnClick="btnAddMemo_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-plus"></span> <span id="btnAddMemoLbl">Add Memo</span>
                    </asp:LinkButton>
                </div>
                <div class="form-group memo-action-cell" id="divCancelMemoEdit" style="display:none;">
                    <label>&nbsp;</label>
                    <asp:LinkButton ID="btnCancelMemoEdit" runat="server"
                        CssClass="btn btn-secondary btn-block" OnClick="btnCancelMemoEdit_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-remove"></span> Cancel Edit
                    </asp:LinkButton>
                </div>
                <div class="form-group memo-action-cell">
                    <label>&nbsp;</label>
                    <asp:LinkButton ID="btnMemoTemplate" runat="server"
                        CssClass="btn btn-info btn-block" OnClick="btnMemoTemplate_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-file"></span> Download
                    </asp:LinkButton>
                </div>
                <div class="form-group memo-upload-cell">
                    <label>Upload Memo CSV</label>
                    <div class="memo-dropzone" id="memoDropZone" onclick="document.getElementById('<%= fuMemoCsv.ClientID %>').click();"
                         ondragover="event.preventDefault();this.classList.add('dz-over');"
                         ondragleave="this.classList.remove('dz-over');"
                         ondrop="event.preventDefault();this.classList.remove('dz-over');document.getElementById('<%= fuMemoCsv.ClientID %>').files=event.dataTransfer.files;document.getElementById('memoDropLabel').textContent=event.dataTransfer.files[0].name;">
                        <span class="glyphicon glyphicon-upload"></span>
                        <span id="memoDropLabel"> Drop CSV here or click to browse</span>
                        <asp:FileUpload ID="fuMemoCsv" runat="server" style="display:none;" onchange="document.getElementById('memoDropLabel').textContent=this.files[0]?this.files[0].name:'Drop CSV here or click to browse';" />
                    </div>
                </div>
                <div class="form-group memo-action-cell">
                    <label>&nbsp;</label>
                    <asp:LinkButton ID="btnMemoUpload" runat="server"
                        CssClass="btn btn-secondary btn-block" OnClick="btnMemoUpload_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-upload"></span> Upload
                    </asp:LinkButton>
                </div>
            </div>
            </asp:Panel>

            <%-- Memos Grid --%>
            <div class="gridview-wrapper mt-2">
                <asp:GridView ID="gvMemos" runat="server" AutoGenerateColumns="false" CssClass="dfm-table"
                    GridLines="None" DataKeyNames="MemoID" OnRowCommand="gvMemos_RowCommand">
                    <Columns>
                        <asp:BoundField DataField="MemoCode"   HeaderText="CAM ID"  ItemStyle-CssClass="memo-id-col" />
                        <asp:BoundField DataField="MemoNumber" HeaderText="Memo#" />
                        <asp:BoundField DataField="ApprovedAmountAED" HeaderText="Amount (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="VendorName" HeaderText="Vendor" />
                        <asp:BoundField DataField="DateRaised" HeaderText="Date Raised" DataFormatString="{0:dd-MMM-yy}" HtmlEncode="false" />
                        <asp:BoundField DataField="LPO_SO_Number" HeaderText="LPO/SO#" />
                        <asp:BoundField DataField="AMS_Number" HeaderText="AMS#" />
                        <asp:BoundField DataField="CAMStatus" HeaderText="Status" />
                        <asp:TemplateField HeaderText="Actions" ItemStyle-CssClass="text-center" ItemStyle-Width="130px">
                            <ItemTemplate>
                                <%-- Tree expand toggle --%>
                                <span class="tree-toggle cam-tog" data-id='<%# Eval("MemoID") %>'
                                      onclick="dfmTogCam(<%# Eval("MemoID") %>);"
                                      title="Expand / collapse invoices">&#9658;</span>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-warning"
                                    CommandName="EditMemo" CommandArgument='<%# Eval("MemoID") %>'
                                    CausesValidation="false" ToolTip="Edit this CAM">
                                    <span class="glyphicon glyphicon-pencil"></span>
                                </asp:LinkButton>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-secondary"
                                    CommandName="CloseMemo" CommandArgument='<%# Eval("MemoID") %>'
                                    CausesValidation="false"
                                    OnClientClick="return confirm('Close this CAM? It will be marked Closed.');"
                                    ToolTip="Close CAM">
                                    <span class="glyphicon glyphicon-ban-circle"></span>
                                </asp:LinkButton>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-info"
                                    CommandName="ViewInvoices" CommandArgument='<%# Eval("MemoID") %>'
                                    CausesValidation="false" ToolTip="Add / view invoices">
                                    <span class="glyphicon glyphicon-list-alt"></span>
                                </asp:LinkButton>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger"
                                    CommandName="DelMemo" CommandArgument='<%# Eval("MemoID") %>'
                                    OnClientClick="return confirm('Delete this memo and all its invoices?');"
                                    CausesValidation="false" ToolTip="Delete Memo">
                                    <span class="glyphicon glyphicon-trash"></span>
                                </asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <EmptyDataTemplate>
                        <div class="text-center text-muted" style="padding:8px;">No memos created yet.</div>
                    </EmptyDataTemplate>
                </asp:GridView>
            </div>

            <%-- Invoice Section (shown when a memo is selected) --%>
            <asp:Panel ID="pnlInvoices" runat="server" Visible="false">
            <div class="accordion collapsed" id="accInvoices" style="margin-top:8px;">
                <div class="accordion-header" onclick="DFM.toggleAcc(this)">
                    <span class="stage-badge stage-active">INVOICES</span>
                    <span class="glyphicon glyphicon-list-alt"></span>
                    Invoice Details &mdash; Memo: <asp:Literal ID="litInvoiceMemoRef" runat="server" />
                    <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
                </div>
                <div class="accordion-body">

                <%-- Invoice entry form --%>
                <div class="form-grid-6">
                    <div class="form-group">
                        <label>Invoice Memo#</label>
                        <asp:TextBox ID="txtInvMemoNum" runat="server" CssClass="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Invoice #</label>
                        <asp:TextBox ID="txtInvNumber" runat="server" CssClass="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Invoice Amount (AED)</label>
                        <asp:TextBox ID="txtInvAmount" runat="server" CssClass="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Invoice Date</label>
                        <asp:TextBox ID="txtInvDate" runat="server" CssClass="form-control" TextMode="Date" />
                    </div>
                    <div class="form-group">
                        <label>Entry/Process Date</label>
                        <asp:TextBox ID="txtInvEntryDate" runat="server" CssClass="form-control" TextMode="Date" />
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <asp:DropDownList ID="ddlInvStatus" runat="server" CssClass="form-control no-select2">
                            <asp:ListItem Value="Pending">Pending</asp:ListItem>
                            <asp:ListItem Value="Submitted">Submitted</asp:ListItem>
                            <asp:ListItem Value="Paid">Paid</asp:ListItem>
                            <asp:ListItem Value="Rejected">Rejected</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                </div>
                <div class="form-grid-6">
                    <div class="form-group col-span-6">
                        <label>Invoice Description</label>
                        <asp:TextBox ID="txtInvDesc" runat="server" CssClass="form-control" />
                    </div>
                </div>
                <asp:HiddenField ID="hfEditInvoiceId" runat="server" Value="0" />
                <asp:HiddenField ID="hfSelectedMemoId" runat="server" Value="0" />
                <div class="toolbar mt-1">
                    <asp:LinkButton ID="btnAddInvoice" runat="server"
                        CssClass="btn btn-success" OnClick="btnAddInvoice_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-plus"></span> Add Invoice
                    </asp:LinkButton>
                    <asp:LinkButton ID="btnInvoiceTemplate" runat="server"
                        CssClass="btn btn-info" OnClick="btnInvoiceTemplate_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-file"></span> Invoice Template
                    </asp:LinkButton>
                    <span class="text-muted" style="margin-left:8px;">Upload Invoice CSV:</span>
                    <asp:FileUpload ID="fuInvoiceCsv" runat="server" />
                    <asp:LinkButton ID="btnInvoiceUpload" runat="server"
                        CssClass="btn btn-secondary" OnClick="btnInvoiceUpload_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-upload"></span> Upload
                    </asp:LinkButton>
                </div>

                <%-- Invoices Grid --%>
                <div class="gridview-wrapper mt-2">
                    <asp:GridView ID="gvInvoices" runat="server" AutoGenerateColumns="false" CssClass="dfm-table"
                        GridLines="None" DataKeyNames="InvoiceID" OnRowCommand="gvInvoices_RowCommand">
                        <Columns>
                            <asp:BoundField DataField="InvoiceMemoNumber" HeaderText="Inv Memo#" />
                            <asp:BoundField DataField="InvoiceNumber" HeaderText="Invoice#" />
                            <asp:BoundField DataField="InvoiceAmountAED" HeaderText="Amount (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="InvoiceDate" HeaderText="Invoice Date" DataFormatString="{0:dd-MMM-yy}" HtmlEncode="false" />
                            <asp:BoundField DataField="InvoiceEntryDate" HeaderText="Entry Date" DataFormatString="{0:dd-MMM-yy}" HtmlEncode="false" />
                            <asp:BoundField DataField="InvoiceStatus" HeaderText="Status" />
                            <asp:TemplateField HeaderText="Actions" ItemStyle-CssClass="text-center">
                                <ItemTemplate>
                                    <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger"
                                        CommandName="DelInvoice" CommandArgument='<%# Eval("InvoiceID") %>'
                                        OnClientClick="return confirm('Delete this invoice?');"
                                        ToolTip="Delete Invoice">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </asp:LinkButton>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                        <EmptyDataTemplate>
                            <div class="text-center text-muted" style="padding:8px;">No invoices for this memo.</div>
                        </EmptyDataTemplate>
                    </asp:GridView>
                </div>

                <%-- Vendor Settlement Summary --%>
                <div class="budget-grid mt-2">
                    <div class="budget-cell budget">
                        <span class="bc-icon glyphicon glyphicon-briefcase"></span>
                        <div class="lbl">Total LPO</div>
                        <div class="val"><asp:Literal ID="litMemoLPOTotal" runat="server" Text="0.00" /></div>
                    </div>
                    <div class="budget-cell utilized">
                        <span class="bc-icon glyphicon glyphicon-stats"></span>
                        <div class="lbl">Disbursed</div>
                        <div class="val"><asp:Literal ID="litMemoDisbursed" runat="server" Text="0.00" /></div>
                    </div>
                    <div class="budget-cell available">
                        <span class="bc-icon glyphicon glyphicon-ok-circle"></span>
                        <div class="lbl">Pending Balance</div>
                        <div class="val"><asp:Literal ID="litMemoPending" runat="server" Text="0.00" /></div>
                    </div>
                    <div class="budget-cell locked">
                        <span class="bc-icon glyphicon glyphicon-stats"></span>
                        <div class="lbl">% Utilized</div>
                        <div class="val"><asp:Literal ID="litMemoPctUtil" runat="server" Text="0" />%</div>
                    </div>
                    <div class="budget-cell netbal">
                        <span class="bc-icon glyphicon glyphicon-scale"></span>
                        <div class="lbl">% Remaining</div>
                        <div class="val"><asp:Literal ID="litMemoPctRem" runat="server" Text="0" />%</div>
                    </div>
                </div>
                </div><%-- end accordion-body --%>
            </div><%-- end accInvoices accordion --%>
            </asp:Panel>

            <%-- BPM Closing --%>
            <asp:Panel ID="pnlBpmClose" runat="server">
            <div class="form-grid-6 mt-2">
                <div class="form-group col-span-6">
                    <label>BPM Closing Comments (Rich Text)</label>
                    <div class="rte-toolbar">
                        <button type="button" onclick="DFM.rte(this,'bold')"><b>B</b></button>
                        <button type="button" onclick="DFM.rte(this,'italic')"><i>I</i></button>
                        <button type="button" onclick="DFM.rte(this,'underline')"><u>U</u></button>
                        <button type="button" onclick="DFM.rte(this,'insertUnorderedList')">&bull;</button>
                    </div>
                    <div class="rte-editor" contenteditable="true" id="rteBpmNotes"
                         data-target='<%= txtBpmNotes.ClientID %>'></div>
                    <asp:HiddenField ID="txtBpmNotes" runat="server" />
                </div>
            </div>
            <div class="toolbar mt-2">
                <asp:LinkButton ID="btnCloseBpm" runat="server"
                    CssClass="btn btn-success" OnClick="btnCloseBpm_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-ok-circle"></span> Mark BPM Closed
                </asp:LinkButton>
            </div>
            </asp:Panel>
        </div>
    </div>
    </asp:Panel>

    <!-- =========== Section 5: Attachments (Req 22) ========== -->
    <asp:Panel ID="pnlAttach" runat="server" Visible="false">
    <div class="accordion collapsed" id="accAttach">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge stage-active">ATTACHMENTS</span>
            <span class="glyphicon glyphicon-paperclip"></span>
            Attachments (Requestor &amp; Approver)
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <%-- Drag-and-drop zone targets the hidden FileUpload control --%>
            <div class="dropzone" id="dzAttach" onclick="document.getElementById('<%= fuAttach.ClientID %>').click();">
                <span class="glyphicon glyphicon-cloud-upload"></span>
                <div class="dz-title">Drop files here or click to browse</div>
                <div class="dz-hint">Multiple files supported. Files will upload when you click <strong>Upload</strong>.</div>
                <div class="dz-file-list" id="dzFiles"></div>
            </div>
            <div style="position:absolute; left:-9999px;">
                <asp:FileUpload ID="fuAttach" runat="server" AllowMultiple="true" />
            </div>
            <div class="toolbar">
                <label class="form-group" style="margin-bottom:0;">
                    <span style="font-size:.82em; font-weight:700;">Stage:</span>
                </label>
                <asp:DropDownList ID="ddlAttachStage" runat="server" CssClass="form-control no-select2" Style="width:160px;">
                    <asp:ListItem>PET</asp:ListItem>
                    <asp:ListItem>BPM</asp:ListItem>
                    <asp:ListItem>Approval</asp:ListItem>
                    <asp:ListItem>General</asp:ListItem>
                </asp:DropDownList>
                <asp:LinkButton ID="btnUploadAttach" runat="server"
                    CssClass="btn btn-primary" OnClick="btnUploadAttach_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-paperclip"></span> Upload Selected
                </asp:LinkButton>
            </div>

            <script>
                (function () {
                    var dz = document.getElementById('dzAttach');
                    var input = document.getElementById('<%= fuAttach.ClientID %>');
                    var list = document.getElementById('dzFiles');
                    if (!dz || !input) return;

                    function renderFiles() {
                        list.innerHTML = '';
                        var files = input.files;
                        if (!files || files.length === 0) return;
                        for (var i = 0; i < files.length; i++) {
                            var f = files[i];
                            var chip = document.createElement('span');
                            chip.className = 'dz-chip';
                            chip.innerHTML = '<span class="glyphicon glyphicon-ok"></span>' +
                                             '<span></span>';
                            chip.lastChild.textContent = f.name + ' (' + Math.ceil(f.size / 1024) + ' KB)';
                            list.appendChild(chip);
                        }
                    }

                    ['dragenter','dragover'].forEach(function (ev) {
                        dz.addEventListener(ev, function (e) {
                            e.preventDefault(); e.stopPropagation();
                            dz.classList.add('dragover');
                        });
                    });
                    ['dragleave','drop'].forEach(function (ev) {
                        dz.addEventListener(ev, function (e) {
                            e.preventDefault(); e.stopPropagation();
                            dz.classList.remove('dragover');
                        });
                    });
                    dz.addEventListener('drop', function (e) {
                        if (!e.dataTransfer || !e.dataTransfer.files) return;
                        // Assign dropped files to the hidden ASP.NET FileUpload control
                        try { input.files = e.dataTransfer.files; }
                        catch (err) { /* older browsers ignore - fall back to click-to-browse */ }
                        renderFiles();
                    });
                    input.addEventListener('change', renderFiles);
                })();
            </script>
            <asp:Repeater ID="rptAttach" runat="server">
                <HeaderTemplate><div class="attach-list mt-2"></HeaderTemplate>
                <ItemTemplate>
                    <a href='<%# ResolveUrl(Eval("StoredPath").ToString()) %>' target="_blank">
                        <span class="glyphicon glyphicon-paperclip"></span>
                        <%# Eval("FileName") %>
                        <small class="text-muted">(<%# Eval("Stage") %> &middot; <%# Eval("UploadedBy") %>)</small>
                    </a>
                </ItemTemplate>
                <FooterTemplate></div></FooterTemplate>
            </asp:Repeater>
        </div>
    </div>
    </asp:Panel>

    <!-- =========== Section 6: Workflow History (Req 23-26) ========== -->
    <div class="accordion <%= HistoryAccordionClass %>" id="accHistory">
        <div class="accordion-header" onclick="DFM.toggleAcc(this)">
            <span class="stage-badge stage-done">HISTORY</span>
            <span class="glyphicon glyphicon-time"></span>
            Workflow History
            <span class="glyphicon glyphicon-chevron-down acc-chev"></span>
        </div>
        <div class="accordion-body">
            <div class="gridview-wrapper">
                <asp:GridView ID="gvHistory" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table audit-table" GridLines="None"
                    AllowPaging="true" PageSize="15"
                    OnPageIndexChanging="gvHistory_PageIndexChanging">
                    <PagerStyle CssClass="pager" />
                    <Columns>
                        <asp:TemplateField HeaderText="#" ItemStyle-Width="40px" ItemStyle-CssClass="text-center">
                            <ItemTemplate>
                                <%# Container.DataItemIndex + 1 + (gvHistory.PageIndex * gvHistory.PageSize) %>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Stage" ItemStyle-Width="140px">
                            <ItemTemplate>
                                <span class='audit-stage audit-<%# Eval("Stage").ToString().ToLower().Replace(" ", "-") %>'>
                                    <%# Eval("Stage") %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="ActionBy" HeaderText="Action By" ItemStyle-Width="140px" />
                        <asp:BoundField DataField="ActionDate" HeaderText="Date / Time"
                            DataFormatString="{0:dd-MMM-yy HH:mm}" HtmlEncode="false"
                            ItemStyle-Width="140px" />
                        <asp:TemplateField HeaderText="Version" ItemStyle-Width="70px" ItemStyle-CssClass="text-center">
                            <ItemTemplate>
                                <span class="chip chip-capex">v<%# Eval("Version") %></span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Approval Level" ItemStyle-Width="90px" ItemStyle-CssClass="text-center">
                            <ItemTemplate>
                                <%# Eval("ApprovalLevel") == System.DBNull.Value ? "&mdash;" : Eval("ApprovalLevel") %>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Comments">
                            <ItemTemplate>
                                <%# Eval("Comments") == System.DBNull.Value || Eval("Comments").ToString() == "" ? "<span class='text-muted'>(no comments)</span>" : Eval("Comments") %>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                    <EmptyDataTemplate>
                        <div class="text-center text-muted" style="padding:14px;">No audit entries recorded yet.</div>
                    </EmptyDataTemplate>
                </asp:GridView>
            </div>
            <asp:Panel ID="pnlNoHistory" runat="server" CssClass="text-muted text-center" Visible="false">
                No history recorded yet.
            </asp:Panel>
        </div>
    </div>

    <script>
        // Bootstrap: ensure DFM namespace exists. app.js is loaded by the master page
        // AFTER this inline block, so we must create the object ourselves.
        window.DFM = window.DFM || {};

        // Initialize jQuery tooltips for .field-help-icon
        $(function () {
            $('[data-toggle="tooltip"]').tooltip({ container: 'body', html: false, trigger: 'hover focus' });
        });

        // ===== Live FCY -> AED converter for the PET line-item editor =====
        DFM.petRates = <%= string.IsNullOrEmpty(PetRatesJs) ? "{\"AED\":1}" : PetRatesJs %>;
        DFM.petRecalc = function () {
            var u = parseFloat((document.getElementById('<%= txtUnits.ClientID %>') || {}).value || 0) || 0;
            var p = parseFloat((document.getElementById('<%= txtUnitPrice.ClientID %>') || {}).value || 0) || 0;
            var ccyEl = document.getElementById('<%= ddlCurrency.ClientID %>');
            var ccy = ccyEl ? (ccyEl.value || 'AED') : 'AED';
            var rate = DFM.petRates[ccy] || 1;
            var fcy = u * p;
            var aed = fcy * rate;
            var elF = document.getElementById('<%= txtAmtFcy.ClientID %>');
            var elA = document.getElementById('<%= txtAmtAed.ClientID %>');
            if (elF) elF.value = fcy.toFixed(2);
            if (elA) elA.value = aed.toFixed(2);
        };
        $(function () {
            $('.pet-calc').on('input change keyup', DFM.petRecalc);
            DFM.petRecalc();
        });

        // Sync RTE -> hidden field on submit
        $(function () {
            $('.rte-editor').each(function () {
                var $rte = $(this);
                var tid  = $rte.data('target');
                var $hf  = $('#' + tid);
                if ($hf.val()) $rte.html($hf.val());
                $rte.on('keyup blur', function () { $hf.val($rte.html()); });
            });
            // Force-sync on submit
            $('form').on('submit', function () {
                $('.rte-editor').each(function () {
                    var $rte = $(this);
                    var tid  = $rte.data('target');
                    $('#' + tid).val($rte.html());
                });
            });
        });

        DFM.rte = function (btn, cmd) {
            // Re-focus the editor inside this toolbar before exec
            var ed = btn.closest('.rte-toolbar').nextElementSibling;
            if (ed) ed.focus();
            document.execCommand(cmd, false, null);
        };

        DFM.toggleAcc = function (hdr) {
            var acc = hdr.parentElement;
            if (!acc) return;
            acc.classList.toggle('collapsed');
            DFM.syncOpen();
        };

        // ===== State retention across postbacks =====
        DFM.syncOpen = function () {
            var hf = document.getElementById('<%= hfOpenSections.ClientID %>');
            if (!hf) return;
            var open = [];
            document.querySelectorAll('.accordion').forEach(function (a) {
                if (a.id && !a.classList.contains('collapsed')) open.push(a.id);
            });
            hf.value = open.join(',');
        };

        DFM.restoreState = function () {
            var hfOpen = document.getElementById('<%= hfOpenSections.ClientID %>');
            if (hfOpen && hfOpen.value !== '') {
                var ids = hfOpen.value.split(',');
                document.querySelectorAll('.accordion').forEach(function (a) {
                    if (!a.id) return;
                    if (ids.indexOf(a.id) !== -1) a.classList.remove('collapsed');
                    else                          a.classList.add('collapsed');
                });
            }
            var hfFocus = document.getElementById('<%= hfFocus.ClientID %>');
            if (hfFocus && hfFocus.value) {
                var el = document.getElementById(hfFocus.value);
                if (el && typeof el.focus === 'function') {
                    setTimeout(function () { try { el.focus(); } catch (e) {} }, 0);
                }
            }
            // MaintainScrollPositionOnPostback handles the browser scroll, but
            // we also restore from our hidden field as a belt-and-braces fallback.
            var hfScroll = document.getElementById('<%= hfScroll.ClientID %>');
            if (hfScroll && hfScroll.value) {
                var y = parseInt(hfScroll.value, 10);
                if (!isNaN(y)) setTimeout(function () { window.scrollTo(0, y); }, 0);
            }
        };

        // Capture focus + scroll just before any postback so it can be restored after
        $(document).on('focus', 'input, textarea, select, [contenteditable=true]', function () {
            var hfFocus = document.getElementById('<%= hfFocus.ClientID %>');
            if (hfFocus && this.id) hfFocus.value = this.id;
        });
        // ASP.NET WebForms calls form.submit() programmatically which does NOT fire
        // the 'submit' DOM event. Sync state on click of any postback trigger instead.
        DFM.persistBeforePost = function () {
            var hfScroll = document.getElementById('<%= hfScroll.ClientID %>');
            if (hfScroll) hfScroll.value = (window.pageYOffset || document.documentElement.scrollTop || 0);
            DFM.syncOpen();
        };
        $(document).on('click', '.btn, .nav-item, [onclick^="__doPostBack"]', DFM.persistBeforePost);
        $(document).on('change', 'select[onchange], input[onchange]', DFM.persistBeforePost);
        // MS-AJAX (UpdatePanel) path - hook it too if a ScriptManager is later added.
        if (typeof Sys !== 'undefined' && Sys.WebForms && Sys.WebForms.PageRequestManager) {
            var prm = Sys.WebForms.PageRequestManager.getInstance();
            prm.add_initializeRequest(DFM.persistBeforePost);
            prm.add_endRequest(function () { DFM.restoreState(); });
        }
        // On every load, restore
        $(function () { DFM.restoreState(); });

        DFM.scrollToAi = function () {
            var el = document.getElementById('aiMessages');
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        };

        // ===== BPM CAM tree: expand/collapse invoice sub-rows =====
        function dfmTogCam(memoId) {
            var sub  = document.getElementById('inv_sub_' + memoId);
            var tog  = document.querySelector('.cam-tog[data-id="' + memoId + '"]');
            if (!sub) return;
            var open = sub.style.display !== 'none';
            sub.style.display = open ? 'none' : '';
            if (tog) tog.innerHTML = open ? '&#9658;' : '&#9660;';
        }

        // ===== CAM Edit-mode: update button label + show cancel ====
        $(function () {
            var hfEdit = document.getElementById('<%= hfEditMemoId.ClientID %>');
            if (!hfEdit) return;
            function syncMemoEditState() {
                var isEdit = hfEdit.value && hfEdit.value !== '0';
                var lbl = document.getElementById('btnAddMemoLbl');
                if (lbl) lbl.textContent = isEdit ? 'Update Memo' : 'Add Memo';
                var cancelDiv = document.getElementById('divCancelMemoEdit');
                if (cancelDiv) cancelDiv.style.display = isEdit ? '' : 'none';
            }
            syncMemoEditState();
            // Observe hidden-field changes (triggered by postback restore)
            var obs = new MutationObserver(syncMemoEditState);
            obs.observe(hfEdit, { attributes: true, childList: true, characterData: true });
        });

        // ===== Client-side pagination for approval line items table =====
        DFM.petApprPaginate = function () {
            var tbl = document.getElementById('petApprItemsTbl');
            if (!tbl) return;
            var PAGE_SIZE = 10;
            var tbody = tbl.querySelector('tbody');
            if (!tbody) return;
            var allRows = Array.prototype.slice.call(tbody.querySelectorAll('tr:not(.pet-appr-pager-row)'));
            var totalRows = allRows.length;
            if (totalRows <= PAGE_SIZE) return; // no pagination needed
            var totalPages = Math.ceil(totalRows / PAGE_SIZE);
            var curPage = 0;

            function show(page) {
                curPage = page;
                allRows.forEach(function (r, i) {
                    r.style.display = (i >= page * PAGE_SIZE && i < (page + 1) * PAGE_SIZE) ? '' : 'none';
                });
                renderPager();
            }

            function renderPager() {
                var existing = tbody.querySelector('.pet-appr-pager-row');
                if (existing) existing.parentNode.removeChild(existing);
                var pr = document.createElement('tr');
                pr.className = 'pet-appr-pager-row';
                var td = document.createElement('td');
                td.colSpan = 99;
                td.style.cssText = 'text-align:right;padding:6px 10px;';
                var html = '<span style="font-size:.82em;color:#64748b;margin-right:8px;">Page ' + (curPage+1) + ' / ' + totalPages + '</span>';
                if (curPage > 0) html += '<button type="button" class="btn btn-xs btn-secondary" onclick="DFM._petPagerGo(' + (curPage-1) + ')">&#8592; Prev</button> ';
                for (var p = 0; p < totalPages; p++) {
                    var active = p === curPage ? ' btn-primary' : ' btn-default';
                    html += '<button type="button" class="btn btn-xs' + active + '" onclick="DFM._petPagerGo(' + p + ')">' + (p+1) + '</button> ';
                }
                if (curPage < totalPages - 1) html += '<button type="button" class="btn btn-xs btn-secondary" onclick="DFM._petPagerGo(' + (curPage+1) + ')">Next &#8594;</button>';
                td.innerHTML = html;
                pr.appendChild(td);
                tbody.appendChild(pr);
            }

            DFM._petPagerGo = function (page) { show(page); };
            show(0);
        };

        $(function () { DFM.petApprPaginate(); });

        // Req 33-35: Gemini AI Chat via AIHandler.ashx (server-side proxy keeps key off client)
        DFM.aiSend = function () {
            var txt = document.getElementById('aiTxt');
            var msg = (txt.value || '').trim();
            if (!msg) return;
            var msgs = document.getElementById('aiMessages');
            msgs.innerHTML += '<div class="user">' + DFM.escapeHtml(msg) + '</div>';
            txt.value = '';
            var loadId = 'l_' + Date.now();
            msgs.innerHTML += '<div class="ai" id="' + loadId + '">Thinking...</div>';
            msgs.scrollTop = msgs.scrollHeight;

            fetch('<%= ResolveUrl("~/AIHandler.ashx") %>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: msg, projectId: <%= CurrentProjectIdJs %> })
            })
            .then(function (r) { return r.text(); })
            .then(function (t) {
                var el = document.getElementById(loadId); if (el) el.remove();
                msgs.innerHTML += '<div class="ai">' + DFM.escapeHtml(t) + '</div>';
                msgs.scrollTop = msgs.scrollHeight;
            })
            .catch(function () {
                var el = document.getElementById(loadId); if (el) el.remove();
                msgs.innerHTML += '<div class="ai">Error calling AI service.</div>';
            });
        };

        // Enter to send (Shift+Enter = newline)
        document.addEventListener('keydown', function (e) {
            if (e.target && e.target.id === 'aiTxt' && e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault(); DFM.aiSend();
            }
        });

        DFM.escapeHtml = function (s) {
            var d = document.createElement('div'); d.innerText = s; return d.innerHTML;
        };
    </script>

    <!-- ===== DFM Notification Modal (Req 7) ===== -->
    <div id="dfmNotifyOverlay" class="dfm-notify-overlay" style="display:none;" onclick="if(event.target===this)dfmHideNotify()">
        <div class="dfm-notify-box">
            <div class="dfm-notify-icon-wrap">
                <span id="dfmNIcon" class="glyphicon" style="font-size:36px;"></span>
            </div>
            <div id="dfmNTitle" class="dfm-notify-title"></div>
            <div id="dfmNMsg"   class="dfm-notify-msg"></div>
            <button class="btn btn-primary dfm-notify-close" onclick="dfmHideNotify()">OK</button>
        </div>
    </div>
    <script>
        function dfmShowNotify(type, title, msg) {
            var overlay = document.getElementById('dfmNotifyOverlay');
            // Move to document.body so position:fixed is relative to viewport, not any transformed ancestor
            if (overlay && overlay.parentNode !== document.body) {
                document.body.appendChild(overlay);
            }
            var icons  = { success: 'ok-circle',    error: 'remove-circle', warning: 'warning-sign', info: 'info-sign' };
            var colors = { success: '#22c55e', error: '#ef4444', warning: '#f59e0b', info: '#3b82f6' };
            var icon   = document.getElementById('dfmNIcon');
            icon.className = 'glyphicon glyphicon-' + (icons[type] || 'info-sign');
            icon.style.color = colors[type] || '#3b82f6';
            document.getElementById('dfmNTitle').textContent = title || '';
            document.getElementById('dfmNMsg').textContent   = msg   || '';
            if (overlay) overlay.style.display = 'flex';
        }
        function dfmHideNotify() {
            document.getElementById('dfmNotifyOverlay').style.display = 'none';
        }
        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') dfmHideNotify();
        });
        // JIRA section toggle (Req 1.1)
        function dfmJiraToggle() {
            var grid = document.getElementById('jiraFieldsGrid');
            var icon = document.getElementById('jiraToggleIcon');
            if (!grid) return;
            var hidden = grid.style.display === 'none';
            grid.style.display = hidden ? '' : 'none';
            if (icon) {
                icon.className = hidden
                    ? 'glyphicon glyphicon-chevron-down jira-chev'
                    : 'glyphicon glyphicon-chevron-right jira-chev';
            }
            try {
                localStorage.setItem('dfmJiraGrid', hidden ? 'o' : 'c');
            } catch(e) {}
        }
        // Restore JIRA section collapse state on load
        (function() {
            try {
                if (localStorage.getItem('dfmJiraGrid') === 'c') {
                    var grid = document.getElementById('jiraFieldsGrid');
                    var icon = document.getElementById('jiraToggleIcon');
                    if (grid) grid.style.display = 'none';
                    if (icon) icon.className = 'glyphicon glyphicon-chevron-right jira-chev';
                }
            } catch(e) {}
        })();
    </script>
</asp:Content>
