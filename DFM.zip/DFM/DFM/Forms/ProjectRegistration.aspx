<%@ Page Title="Project Registration" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ProjectRegistration.aspx.cs" Inherits="DFM.Forms.ProjectRegistration" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">Project Registration</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-link"></span> JIRA &amp; Project Identity</h3>
        <div class="form-row">
            <div class="form-group">
                <label>JIRA ID</label>
                <asp:DropDownList ID="ddlJira" runat="server" CssClass="form-control" AutoPostBack="true"
                    OnSelectedIndexChanged="ddlJira_Changed" />
            </div>
            <div class="form-group" style="flex:2 1 380px;">
                <label>Project Name</label>
                <asp:TextBox ID="txtName" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Project Type</label>
                <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control" AutoPostBack="true"
                    OnSelectedIndexChanged="ddlType_Changed">
                    <asp:ListItem Value="CAPEX">CAPEX</asp:ListItem>
                    <asp:ListItem Value="OPEX">OPEX</asp:ListItem>
                    <asp:ListItem Value="AMC">AMC</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>Mode</label>
                <asp:DropDownList ID="ddlUpdateMode" runat="server" CssClass="form-control">
                    <asp:ListItem Value="New">New Project Registration</asp:ListItem>
                    <asp:ListItem Value="ExistingUpdate">Existing Project Update</asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>

        <!-- Auto-populated JIRA fields (visibility configurable via Admin/JiraConfig) -->
        <asp:Repeater ID="rptJiraFields" runat="server">
            <HeaderTemplate>
                <div class="form-row">
            </HeaderTemplate>
            <ItemTemplate>
                <div class="form-group">
                    <label><%# Eval("FieldName") %></label>
                    <input type="text" class="form-control no-select2" readonly="readonly"
                           value='<%# Server.HtmlEncode((Eval("Value") ?? "").ToString()) %>' />
                </div>
            </ItemTemplate>
            <FooterTemplate>
                </div>
            </FooterTemplate>
        </asp:Repeater>
    </div>

    <div class="card-panel">
        <h3>Budget Source</h3>
        <div class="form-row">
            <div class="form-group" style="flex:2 1 420px;">
                <label>
                    <asp:Literal ID="litSourceLabel" runat="server" Text="CAPEX" /> selection
                    <small class="text-muted">(searchable by ID or Description)</small>
                </label>
                <asp:DropDownList ID="ddlSource" runat="server" CssClass="form-control" AutoPostBack="true"
                    OnSelectedIndexChanged="ddlSource_Changed" />
            </div>
            <div class="form-group">
                <label>Requested Amount</label>
                <asp:TextBox ID="txtAmount" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Approver</label>
                <asp:DropDownList ID="ddlApprover" runat="server" CssClass="form-control" />
            </div>
        </div>

        <asp:Panel ID="pnlBudget" runat="server" Visible="false">
            <div class="budget-grid">
                <div class="budget-cell">
                    <div class="lbl">Budget</div>
                    <div class="val"><asp:Literal ID="bBudget" runat="server" /></div>
                </div>
                <div class="budget-cell utilized">
                    <div class="lbl">Utilization</div>
                    <div class="val"><asp:Literal ID="bUtil" runat="server" /></div>
                </div>
                <div class="budget-cell available">
                    <div class="lbl">Available Budget</div>
                    <div class="val"><asp:Literal ID="bAvail" runat="server" /></div>
                </div>
                <div class="budget-cell locked">
                    <div class="lbl">Locked Amount</div>
                    <div class="val"><asp:Literal ID="bLock" runat="server" /></div>
                </div>
                <div class="budget-cell">
                    <div class="lbl">Budget after Locked</div>
                    <div class="val"><asp:Literal ID="bAfterLock" runat="server" /></div>
                </div>
                <div class="budget-cell">
                    <div class="lbl">Claim Amount</div>
                    <div class="val"><asp:Literal ID="bClaim" runat="server" /></div>
                </div>
                <div class="budget-cell netbal">
                    <div class="lbl">Net Balance</div>
                    <div class="val"><asp:Literal ID="bNet" runat="server" /></div>
                </div>
            </div>
        </asp:Panel>
    </div>

    <div class="card-panel">
        <h3>Baseline plan &amp; comments</h3>
        <div class="form-row">
            <div class="form-group" style="flex:1 1 100%;">
                <label>Baseline Plan</label>
                <asp:TextBox ID="txtBaseline" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="4" />
            </div>
        </div>
        <div class="form-row">
            <div class="form-group" style="flex:1 1 100%;">
                <label>Comment for this version</label>
                <asp:TextBox ID="txtComment" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="3"
                    placeholder="Required when modifying. Tracked in workflow comment history." />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSaveDraft" runat="server" Text="Save as Draft" CssClass="btn btn-secondary" OnClick="btnSaveDraft_Click" />
            <asp:Button ID="btnSubmit"    runat="server" Text="Submit for Approval" CssClass="btn btn-primary" OnClick="btnSubmit_Click" />
            <asp:HyperLink ID="lnkHistory" runat="server" CssClass="btn btn-info" Text="View History" Visible="false" />
            <div class="spacer"></div>
            <asp:Label ID="lblStatus" runat="server" CssClass="badge-status badge-draft" Text="Draft" />
        </div>
    </div>

    <asp:Panel ID="pnlComments" runat="server" CssClass="card-panel" Visible="false">
        <h3>Comment history</h3>
        <asp:Repeater ID="rptComments" runat="server">
            <ItemTemplate>
                <div class="history-item">
                    <div class="meta">
                        <span class="who"><%# Eval("CommentedBy") %></span>
                        <span class="when"><%# Eval("CommentedDate", "{0:dd-MMM-yyyy HH:mm}") %></span>
                    </div>
                    <div><%# Server.HtmlEncode(Eval("CommentText").ToString()).Replace("\n","<br/>") %></div>
                </div>
            </ItemTemplate>
        </asp:Repeater>
    </asp:Panel>
</asp:Content>
