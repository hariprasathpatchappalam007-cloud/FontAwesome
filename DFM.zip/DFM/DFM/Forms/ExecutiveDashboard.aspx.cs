using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using DFM.App_Code.DAL;

namespace DFM.Forms
{
    public partial class ExecutiveDashboard : System.Web.UI.Page
    {
        public string JsPortfolio { get; private set; }
        public string JsVertical  { get; private set; }

        public ExecutiveDashboard() { JsPortfolio = "[]"; JsVertical = "[]"; }

        protected void Page_Load(object sender, EventArgs e)
        {
            // Read from pre-aggregated summary tables (Req5)
            try
            {
                DataRow kpi = Db.QueryRowSP("sp_GetDashboardKPIs");
                if (kpi != null)
                {
                    int total = Conv(kpi, "TotalDemands");
                    int active = Conv(kpi, "ActiveProjects");
                    int closed = Conv(kpi, "ClosedProjects");
                    int red = Conv(kpi, "RedRag");
                    int amber = Conv(kpi, "AmberRag");
                    kTotal.Text = total.ToString("N0");
                    kActive.Text = active.ToString("N0");
                    kClosed.Text = closed.ToString("N0");
                    int totalProj = active + closed;
                    kDeliv.Text = totalProj > 0 ? (100.0 * closed / totalProj).ToString("F1") + "%" : "0%";
                    kRisk.Text = totalProj > 0 ? (100.0 * (red + amber) / totalProj).ToString("F1") + "%" : "0%";
                    litTs.Text = kpi["LastRefreshed"] == DBNull.Value
                        ? DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt")
                        : Convert.ToDateTime(kpi["LastRefreshed"]).ToString("dd-MMM-yyyy hh:mm tt");
                }
            }
            catch { litTs.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt"); }

            JsPortfolio = BuildJson("Platform");
            JsVertical  = BuildJson("Vertical");
        }

        private static int Conv(DataRow r, string c)
        {
            return r[c] == DBNull.Value ? 0 : Convert.ToInt32(r[c]);
        }

        private static string BuildJson(string dim)
        {
            try
            {
                DataTable dt = Db.Query("SELECT TOP 15 Bucket, TotalCount, OpenCount, ClosedCount FROM DashboardSummary WHERE Dimension=@dim ORDER BY TotalCount DESC", new SqlParameter("@dim", dim));
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    var r = dt.Rows[i];
                    sb.Append("{\"bucket\":\"").Append(Esc(r["Bucket"].ToString())).Append("\",")
                      .Append("\"total\":").Append(r["TotalCount"]).Append(",")
                      .Append("\"open\":").Append(r["OpenCount"]).Append(",")
                      .Append("\"closed\":").Append(r["ClosedCount"]).Append("}");
                }
                sb.Append("]");
                return sb.ToString();
            }
            catch { return "[]"; }
        }

        private static string Esc(string s)
        {
            return (s ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"");
        }
    }
}
