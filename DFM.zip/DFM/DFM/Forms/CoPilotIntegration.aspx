<%@ Page Title="Co-Pilot Integration" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="CoPilotIntegration.aspx.cs" Inherits="DFM.Forms.CoPilotIntegration" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-cloud-upload"></span> Co-Pilot Integration</h1>

    <p class="text-muted">
        Upload supporting documents (Invoice, Memo, etc.). Documents are scanned and key fields are
        captured automatically. After processing, click <strong>Create BPM Request</strong> to fill the BPM form.
    </p>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-folder-open"></span> Project</h3>
        <div class="form-row">
            <div class="form-group">
                <label>Project (Approved + ready for Co-Pilot)</label>
                <asp:DropDownList ID="ddlProject" runat="server" CssClass="form-control"
                    AutoPostBack="true" OnSelectedIndexChanged="ddlProject_Changed" />
            </div>
            <div class="form-group">
                <label>Status</label>
                <asp:Literal ID="litStatus" runat="server" />
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-upload"></span> Upload documents</h3>
        <div class="form-row">
            <div class="form-group">
                <label>Document Type</label>
                <asp:DropDownList ID="ddlDocType" runat="server" CssClass="form-control">
                    <asp:ListItem>Invoice</asp:ListItem>
                    <asp:ListItem>Memo</asp:ListItem>
                    <asp:ListItem>Other</asp:ListItem>
                </asp:DropDownList>
            </div>
            <div class="form-group" style="flex:2 1 420px;">
                <label>File(s) — multi-select supported</label>
                <asp:FileUpload ID="fuDoc" runat="server" CssClass="form-control no-select2" AllowMultiple="true" />
            </div>
            <div class="form-group" style="align-self:flex-end;">
                <asp:Button ID="btnUpload" runat="server" Text="Upload &amp; Scan" CssClass="btn btn-primary"
                    OnClick="btnUpload_Click" />
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-paperclip"></span> Uploaded documents</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="DocType"      HeaderText="Type" />
                <asp:BoundField DataField="FileName"     HeaderText="File" />
                <asp:BoundField DataField="SizeBytes"    HeaderText="Size (B)" DataFormatString="{0:N0}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="UploadedBy"   HeaderText="By" />
                <asp:BoundField DataField="UploadedDate" HeaderText="When" DataFormatString="{0:dd-MMM-yy HH:mm}" />
                <asp:BoundField DataField="ExtractedJson" HeaderText="Captured details" />
            </Columns>
            <EmptyDataTemplate>
                <div class="text-center text-muted" style="padding:18px;">No documents uploaded yet.</div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-tasks"></span> Next step</h3>
        <p>After uploading the Invoice and/or Memo, proceed to BPM creation. Captured details from the latest documents will pre-fill the BPM form.</p>
        <asp:HyperLink ID="lnkBpm" runat="server" CssClass="btn btn-primary"
            Text="Create BPM Request" />
    </div>
</asp:Content>
