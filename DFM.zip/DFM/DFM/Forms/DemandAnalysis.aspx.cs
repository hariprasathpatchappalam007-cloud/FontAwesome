using System;
using System.Data;
using System.Text;
using DFM.App_Code.DAL;

namespace DFM.Forms
{
    public partial class DemandAnalysis : System.Web.UI.Page
    {
        public string JsTrend { get; private set; }
        public string JsPlat  { get; private set; }
        public DemandAnalysis() { JsTrend = "[]"; JsPlat = "[]"; }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                kTotal.Text = SafeCount("SELECT COUNT(*) FROM JiraIssues WHERE ProjectKey='DMGT'").ToString("N0");
                kConv.Text  = SafeCount("SELECT COUNT(DISTINCT p.JiraKey) FROM JiraIssues p WHERE p.ProjectKey='DMGT' AND EXISTS(SELECT 1 FROM JiraIssues c WHERE c.ParentJiraID=p.JiraKey AND c.ProjectKey='DIBITP')").ToString("N0");
                kProg.Text  = SafeCount("SELECT COUNT(*) FROM JiraIssues WHERE ProjectKey='DMGT' AND Status NOT IN ('Done','Closed','Cancelled','Completed','On Hold','Deferred')").ToString("N0");
                kHold.Text  = SafeCount("SELECT COUNT(*) FROM JiraIssues WHERE ProjectKey='DMGT' AND Status='On Hold'").ToString("N0");

                // Trend by month (last 12 months)
                DataTable trend = Db.Query(@"SELECT TOP 12 CONVERT(VARCHAR(7),CreatedDate,120) AS M, COUNT(*) AS C
                    FROM JiraIssues WHERE ProjectKey='DMGT' AND CreatedDate IS NOT NULL
                      AND CreatedDate >= DATEADD(MONTH,-12,GETDATE())
                    GROUP BY CONVERT(VARCHAR(7),CreatedDate,120) ORDER BY M");
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < trend.Rows.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    sb.Append("{\"month\":\"").Append(trend.Rows[i]["M"]).Append("\",\"cnt\":").Append(trend.Rows[i]["C"]).Append("}");
                }
                sb.Append("]");
                JsTrend = sb.ToString();

                // Platform pie
                DataTable plat = Db.Query("SELECT TOP 10 Bucket, TotalCount FROM DashboardSummary WHERE Dimension='Platform' ORDER BY TotalCount DESC");
                StringBuilder sb2 = new StringBuilder("[");
                for (int i = 0; i < plat.Rows.Count; i++)
                {
                    if (i > 0) sb2.Append(",");
                    sb2.Append("{\"bucket\":\"").Append((plat.Rows[i]["Bucket"] ?? "").ToString().Replace("\\", "\\\\").Replace("\"", "\\\""))
                       .Append("\",\"total\":").Append(plat.Rows[i]["TotalCount"]).Append("}");
                }
                sb2.Append("]");
                JsPlat = sb2.ToString();

                DataRow ts = Db.QueryRow("SELECT MAX(LastSyncDate) AS LastSync FROM DashboardSummary");
                litTs.Text = (ts != null && ts["LastSync"] != DBNull.Value)
                    ? Convert.ToDateTime(ts["LastSync"]).ToString("dd-MMM-yyyy hh:mm tt")
                    : DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt");
            }
            catch { litTs.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt"); }
        }

        private static int SafeCount(string sql)
        {
            try { DataRow r = Db.QueryRow(sql); return r == null || r[0] == DBNull.Value ? 0 : Convert.ToInt32(r[0]); }
            catch { return 0; }
        }
    }
}
