using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class ProjectHistory : System.Web.UI.Page
    {
        private int Pid
        {
            get { int x; return int.TryParse(Request.QueryString["id"], out x) ? x : 0; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Pid == 0) { Response.Redirect("~/Forms/ProjectList.aspx"); return; }
            var p = ProjectsDAL.GetProject(Pid);
            if (p == null) { Response.Redirect("~/Forms/ProjectList.aspx"); return; }

            litTitle.Text = string.Format("{0} &mdash; {1}", p["ProjectCode"], Server.HtmlEncode(p["ProjectName"].ToString()));
            litSummary.Text = string.Format("Type: <strong>{0}</strong> &middot; Status: <strong>{1}</strong> &middot; Amount: {2:N2} &middot; Locked: {3:N2} &middot; Debited: {4:N2}",
                p["ProjectType"], p["Status"], p["RequestedAmount"], p["LockedAmount"], p["DebitedAmount"]);

            if (!IsPostBack)
            {
                BindAll();
            }

            lnkBack.NavigateUrl = "~/Forms/Workflow.aspx?id=" + Pid;
        }

        private void BindAll()
        {
            BindWorkflow();
            BindComments();
            gvVersions.DataSource = ProjectsDAL.GetVersionHistory(Pid); gvVersions.DataBind();

            gvLocked.DataSource = Db.Query("SELECT * FROM LockedAmountHistory WHERE ProjectID=@id ORDER BY ActionDate DESC", Db.P("@id", Pid));
            gvLocked.DataBind();
            gvCapex.DataSource = Db.Query("SELECT * FROM CapexHistory WHERE ProjectID=@id ORDER BY ActionDate DESC", Db.P("@id", Pid));
            gvCapex.DataBind();
            gvDebited.DataSource = Db.Query("SELECT * FROM DebitedAmountHistory WHERE ProjectID=@id ORDER BY ActionDate DESC", Db.P("@id", Pid));
            gvDebited.DataBind();
        }

        private void BindWorkflow()
        {
            DataTable wf = ProjectsDAL.GetWorkflowHistory(Pid);
            DataView dv = new DataView(wf); dv.Sort = "ActionDate DESC";
            gvWorkflow.DataSource = dv;
            gvWorkflow.DataBind();
            lblNoWorkflow.Visible = (wf.Rows.Count == 0);
        }

        private void BindComments()
        {
            DataTable c = ProjectsDAL.GetComments(Pid);
            gvComments.DataSource = c;
            gvComments.DataBind();
        }

        protected void gvWorkflow_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvWorkflow.PageIndex = e.NewPageIndex;
            BindWorkflow();
        }

        protected void gvComments_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvComments.PageIndex = e.NewPageIndex;
            BindComments();
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = ProjectsDAL.GetWorkflowHistory(Pid);
            ExcelHelper.ExportToExcel(Response, dt, "Project_" + Pid + "_WorkflowHistory_" + DateTime.Now.ToString("yyyyMMdd"));
        }
    }
}
