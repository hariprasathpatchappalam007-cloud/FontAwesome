using System;
using System.Data;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class ProjectHistory : System.Web.UI.Page
    {
        private int Pid
        {
            get { int x; return int.TryParse(Request.QueryString["id"], out x) ? x : 0; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Pid == 0) { Response.Redirect("~/Forms/ProjectList.aspx"); return; }
            var p = ProjectsDAL.GetProject(Pid);
            if (p == null) { Response.Redirect("~/Forms/ProjectList.aspx"); return; }

            litTitle.Text = string.Format("{0} &mdash; {1}", p["ProjectCode"], Server.HtmlEncode(p["ProjectName"].ToString()));
            litSummary.Text = string.Format("Type: <strong>{0}</strong> &middot; Status: <strong>{1}</strong> &middot; Amount: {2:N2} &middot; Locked: {3:N2} &middot; Debited: {4:N2}",
                p["ProjectType"], p["Status"], p["RequestedAmount"], p["LockedAmount"], p["DebitedAmount"]);

            DataTable wf = ProjectsDAL.GetWorkflowHistory(Pid);
            rptWorkflow.DataSource = wf; rptWorkflow.DataBind();
            lblNoWorkflow.Visible = (wf.Rows.Count == 0);
            rptComments.DataSource = ProjectsDAL.GetComments(Pid); rptComments.DataBind();
            gvVersions.DataSource = ProjectsDAL.GetVersionHistory(Pid); gvVersions.DataBind();

            gvLocked.DataSource = Db.Query("SELECT * FROM LockedAmountHistory WHERE ProjectID=@id ORDER BY ActionDate", Db.P("@id", Pid));
            gvLocked.DataBind();
            gvCapex.DataSource = Db.Query("SELECT * FROM CapexHistory WHERE ProjectID=@id ORDER BY ActionDate", Db.P("@id", Pid));
            gvCapex.DataBind();
            gvDebited.DataSource = Db.Query("SELECT * FROM DebitedAmountHistory WHERE ProjectID=@id ORDER BY ActionDate", Db.P("@id", Pid));
            gvDebited.DataBind();

            lnkBack.NavigateUrl = "~/Forms/ProjectRegistration.aspx?id=" + Pid;
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = ProjectsDAL.GetWorkflowHistory(Pid);
            ExcelHelper.ExportToExcel(Response, dt, "Project_" + Pid + "_WorkflowHistory_" + DateTime.Now.ToString("yyyyMMdd"));
        }
    }
}
