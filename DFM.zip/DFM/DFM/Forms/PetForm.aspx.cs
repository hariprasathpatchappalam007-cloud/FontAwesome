using System;
using System.Data;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class PetForm : System.Web.UI.Page
    {
        private int CurrentProjectId
        {
            get
            {
                int x;
                if (int.TryParse(ddlProject.SelectedValue, out x)) return x;
                if (int.TryParse(Request.QueryString["projectId"], out x)) return x;
                return 0;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindProjects();
                BindLookups();
                if (Request.QueryString["projectId"] != null)
                {
                    string pid = Request.QueryString["projectId"];
                    ListItem li = ddlProject.Items.FindByValue(pid);
                    if (li != null) { ddlProject.ClearSelection(); li.Selected = true; }
                }
                LoadProjectContext();
                BindLines();
                UpdateLineCode();
            }
        }

        private void BindProjects()
        {
            DataTable dt = ProjectsDAL.GetProjects(null, null);
            ddlProject.Items.Clear();
            ddlProject.Items.Add(new ListItem("-- Select project --", ""));
            foreach (DataRow r in dt.Rows)
            {
                ddlProject.Items.Add(new ListItem(
                    r["ProjectCode"] + " - " + r["ProjectName"], r["ProjectID"].ToString()));
            }
        }

        private void BindLookups()
        {
            // Departments
            DataTable d = PetDAL.GetDepartments();
            ddlDept.Items.Clear();
            ddlDept.Items.Add(new ListItem("-- Select department --", ""));
            foreach (DataRow r in d.Rows)
                ddlDept.Items.Add(new ListItem(r["Department"].ToString(), r["Department"].ToString()));

            // Cost types
            DataTable c = PetDAL.GetCostTypes();
            ddlCostType.Items.Clear();
            ddlCostType.Items.Add(new ListItem("-- Select cost type --", ""));
            foreach (DataRow r in c.Rows)
                ddlCostType.Items.Add(new ListItem(r["Category"].ToString(), r["Category"].ToString()));

            // Currencies
            DataTable cy = PetDAL.GetCurrencies();
            ddlCcy.Items.Clear();
            foreach (DataRow r in cy.Rows)
                ddlCcy.Items.Add(new ListItem(r["Code"].ToString(), r["Code"].ToString()));
            // Default to AED if present
            ListItem aed = ddlCcy.Items.FindByValue("AED");
            if (aed != null) { ddlCcy.ClearSelection(); aed.Selected = true; }
        }

        private void LoadProjectContext()
        {
            int pid = CurrentProjectId;
            if (pid == 0) { litBudgetSrc.Text = "(select a project)"; return; }
            DataRow p = ProjectsDAL.GetProject(pid);
            if (p == null) return;
            string mode = p["UpdateMode"] == DBNull.Value ? "" : p["UpdateMode"].ToString();
            if (!string.IsNullOrEmpty(mode))
            {
                ListItem mi = ddlMode.Items.FindByValue(mode);
                if (mi != null) { ddlMode.ClearSelection(); mi.Selected = true; }
            }
            string ptype = p["ProjectType"].ToString();
            string src = p["BudgetSourceID"] == DBNull.Value ? "" : p["BudgetSourceID"].ToString();
            litBudgetSrc.Text = string.Format("<strong>{0}</strong>: {1}",
                Server.HtmlEncode(ptype), Server.HtmlEncode(src));
        }

        protected void ddlProject_Changed(object sender, EventArgs e)
        {
            LoadProjectContext();
            BindLines();
            UpdateLineCode();
        }

        protected void ddlDept_Changed(object sender, EventArgs e) { UpdateLineCode(); }

        private void UpdateLineCode()
        {
            string dept = ddlDept.SelectedValue;
            if (string.IsNullOrEmpty(dept)) { txtLineCode.Text = ""; return; }
            txtLineCode.Text = PetDAL.NextLineCode(dept);
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            int pid = CurrentProjectId;
            if (pid == 0) { Msg("Please select a project first."); return; }

            // CAPEX is mandatory at PET creation per Req2
            DataRow p = ProjectsDAL.GetProject(pid);
            if (p == null) { Msg("Project not found."); return; }
            string ptype = p["ProjectType"].ToString();
            string src = p["BudgetSourceID"] == DBNull.Value ? "" : p["BudgetSourceID"].ToString();
            if (string.Equals(ptype, "CAPEX", StringComparison.OrdinalIgnoreCase) && string.IsNullOrEmpty(src))
            {
                Msg("CAPEX selection is mandatory before creating PET line items. Open the project and choose a CAPEX source.");
                return;
            }
            if (string.IsNullOrEmpty(ddlDept.SelectedValue)) { Msg("Department is required."); return; }
            if (string.IsNullOrEmpty(ddlCostType.SelectedValue)) { Msg("Cost type is required."); return; }

            // Computed amounts
            decimal units = CsvImporter.ParseDecimal(txtUnits.Text);
            decimal price = CsvImporter.ParseDecimal(txtPrice.Text);
            decimal contPct = CsvImporter.ParseDecimal(txtContPct.Text);
            int yrs; if (!int.TryParse(txtYrs.Text, out yrs)) yrs = 1;
            if (yrs <= 0) yrs = 1;

            string ccy = ddlCcy.SelectedValue;
            decimal rate = PetDAL.GetRate(ccy);
            decimal amtFcy = units * price;
            decimal amtLcy = amtFcy * rate;
            decimal finalLcy = amtLcy * (1 + contPct / 100m) * yrs;

            // Persist UpdateMode if changed
            if (string.IsNullOrEmpty(p["UpdateMode"] == DBNull.Value ? "" : p["UpdateMode"].ToString()))
            {
                Db.Exec("UPDATE Projects SET UpdateMode=@m WHERE ProjectID=@id",
                    Db.P("@m", ddlMode.SelectedValue), Db.P("@id", pid));
            }

            PetDAL.Add(pid, ddlDept.SelectedValue, txtLineCode.Text, ddlExpHead.SelectedValue,
                txtTopic.Text, txtVendor.Text, txtDesc.Text,
                ddlCostType.SelectedValue, ddlUnitType.SelectedValue,
                units, price, ccy, amtFcy, amtLcy, contPct, finalLcy, yrs,
                txtComments.Text, AuthHelper.CurrentUser);

            Msg("Line item added.");
            ClearLineFields();
            BindLines();
            UpdateLineCode();
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteRow")
            {
                PetDAL.Delete(Convert.ToInt32(e.CommandArgument));
                BindLines();
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            int pid = CurrentProjectId;
            if (pid == 0) { Msg("Select a project first."); return; }
            ExcelHelper.ExportToExcel(Response, PetDAL.GetByProject(pid),
                "PET_Lines_Project_" + pid + "_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        private void BindLines()
        {
            int pid = CurrentProjectId;
            if (pid == 0) { gv.DataSource = null; gv.DataBind(); litTotal.Text = "0.00"; return; }
            DataTable dt = PetDAL.GetByProject(pid);
            gv.DataSource = dt; gv.DataBind();
            litTotal.Text = PetDAL.GetTotalForProject(pid).ToString("N2");
        }

        private void ClearLineFields()
        {
            txtTopic.Text = txtVendor.Text = txtDesc.Text = txtComments.Text = "";
            txtUnits.Text = "0"; txtPrice.Text = "0"; txtContPct.Text = "0"; txtYrs.Text = "1";
        }

        private void Msg(string m) { lblMsg.Visible = true; lblMsg.Text = m; }
    }
}
