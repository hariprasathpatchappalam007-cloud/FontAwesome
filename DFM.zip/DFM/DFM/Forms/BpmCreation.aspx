<%@ Page Title="BPM Creation" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="BpmCreation.aspx.cs" Inherits="DFM.Forms.BpmCreation" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-tasks"></span> BPM Creation</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-folder-open"></span> Project</h3>
        <div class="form-row">
            <div class="form-group">
                <label>Project</label>
                <asp:DropDownList ID="ddlProject" runat="server" CssClass="form-control"
                    AutoPostBack="true" OnSelectedIndexChanged="ddlProject_Changed" />
            </div>
            <div class="form-group">
                <label>Project status</label>
                <asp:Literal ID="litStatus" runat="server" />
            </div>
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-edit"></span> BPM details</h3>
        <p class="text-muted">Pre-filled from the latest scanned document. Adjust as needed.</p>
        <div class="form-row">
            <div class="form-group">
                <label>BPM Reference (offline ticket)</label>
                <asp:TextBox ID="txtRef" runat="server" CssClass="form-control" placeholder="e.g. BPM-2026-00123" />
            </div>
            <div class="form-group">
                <label>Vendor</label>
                <asp:TextBox ID="txtVendor" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>Memo Subject</label>
                <asp:TextBox ID="txtMemo" runat="server" CssClass="form-control" />
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Invoice No.</label>
                <asp:TextBox ID="txtInvNo" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group" style="flex:0 0 200px;">
                <label>Invoice Date</label>
                <asp:TextBox ID="txtInvDate" runat="server" CssClass="form-control" TextMode="Date" />
            </div>
            <div class="form-group" style="flex:0 0 200px;">
                <label>Invoice Amount</label>
                <asp:TextBox ID="txtInvAmt" runat="server" CssClass="form-control" Text="0" />
            </div>
            <div class="form-group" style="flex:0 0 130px;">
                <label>Currency</label>
                <asp:TextBox ID="txtCcy" runat="server" CssClass="form-control" Text="AED" />
            </div>
        </div>
        <div class="form-row">
            <div class="form-group" style="flex:1 1 100%;">
                <label>Notes</label>
                <asp:TextBox ID="txtNotes" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="3" />
            </div>
        </div>
        <div class="toolbar">
            <asp:Button ID="btnSubmit" runat="server" Text="Submit BPM" CssClass="btn btn-primary" OnClick="btnSubmit_Click" />
        </div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list-alt"></span> BPM requests for this project</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            DataKeyNames="BpmID" OnRowCommand="gv_RowCommand">
            <Columns>
                <asp:BoundField DataField="BpmReference" HeaderText="Reference" />
                <asp:BoundField DataField="Vendor" HeaderText="Vendor" />
                <asp:BoundField DataField="InvoiceNo" HeaderText="Invoice" />
                <asp:BoundField DataField="InvoiceDate" HeaderText="Inv. Date" DataFormatString="{0:dd-MMM-yy}" />
                <asp:BoundField DataField="InvoiceAmount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="Currency" HeaderText="CY" />
                <asp:TemplateField HeaderText="Status">
                    <ItemTemplate>
                        <span class='badge-status badge-<%# Eval("Status").ToString().ToLower() %>'><%# Eval("Status") %></span>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="CreatedBy" HeaderText="Created By" />
                <asp:BoundField DataField="CreatedDate" HeaderText="Created" DataFormatString="{0:dd-MMM-yy HH:mm}" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-success" CommandName="Close"
                            CommandArgument='<%# Eval("BpmID") %>'
                            OnClientClick="return confirm('Mark BPM as Closed? This will close the workflow request and update CAPEX/OPEX final amounts.');"
                            Visible='<%# Eval("Status").ToString() != "Closed" %>'>
                            <span class="glyphicon glyphicon-ok"></span> Close
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
