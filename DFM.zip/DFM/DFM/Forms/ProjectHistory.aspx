<%@ Page Title="Project History" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ProjectHistory.aspx.cs" Inherits="DFM.Forms.ProjectHistory" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">Project History</h1>

    <div class="card-panel">
        <h3>
            <asp:Literal ID="litTitle" runat="server" />
        </h3>
        <p class="text-muted">
            <asp:Literal ID="litSummary" runat="server" />
        </p>
    </div>

    <div class="card-panel">
        <h3>Workflow stages</h3>
        <asp:Repeater ID="rptWorkflow" runat="server">
            <ItemTemplate>
                <div class="history-item">
                    <div class="meta">
                        <span class="who"><%# Eval("ActionBy") %></span>
                        <span class="when"><%# Eval("ActionDate","{0:dd-MMM-yyyy HH:mm}") %></span>
                        <span><strong>Stage:</strong> <%# Eval("Stage") %></span>
                        <span><strong>Version:</strong> v<%# Eval("Version") %></span>
                        <%# Eval("ApprovalLevel") != System.DBNull.Value ? "<span><strong>Level:</strong> " + Eval("ApprovalLevel") + "</span>" : "" %>
                    </div>
                    <div><%# Server.HtmlEncode((Eval("Comments") ?? "").ToString()) %></div>
                </div>
            </ItemTemplate>
        </asp:Repeater>
        <asp:Label ID="lblNoWorkflow" runat="server" Text="No workflow events yet." CssClass="text-muted" Visible="false" />
    </div>

    <div class="card-panel">
        <h3>Comment history</h3>
        <asp:Repeater ID="rptComments" runat="server">
            <ItemTemplate>
                <div class="history-item">
                    <div class="meta">
                        <span class="who"><%# Eval("CommentedBy") %></span>
                        <span class="when"><%# Eval("CommentedDate","{0:dd-MMM-yyyy HH:mm}") %></span>
                    </div>
                    <div><%# Server.HtmlEncode(Eval("CommentText").ToString()).Replace("\n","<br/>") %></div>
                </div>
            </ItemTemplate>
        </asp:Repeater>
    </div>

    <div class="card-panel">
        <h3>Version snapshots</h3>
        <asp:GridView ID="gvVersions" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="Version" HeaderText="Version" />
                <asp:BoundField DataField="ChangedBy" HeaderText="Changed By" />
                <asp:BoundField DataField="ChangedDate" HeaderText="When" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                <asp:BoundField DataField="ChangeNotes" HeaderText="Notes" />
            </Columns>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3>Locked amount history</h3>
        <asp:GridView ID="gvLocked" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="SourceType" HeaderText="Type" />
                <asp:BoundField DataField="SourceID" HeaderText="Source" />
                <asp:BoundField DataField="Amount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="Action" HeaderText="Action" />
                <asp:BoundField DataField="ActionBy" HeaderText="By" />
                <asp:BoundField DataField="ActionDate" HeaderText="When" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
            </Columns>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-piggy-bank"></span> CAPEX / OPEX history (project-wise)</h3>
        <p class="text-muted">Tracks budget allocations and utilizations for the budget source linked to this project.</p>
        <asp:GridView ID="gvCapex" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="SourceType" HeaderText="Type" />
                <asp:BoundField DataField="SourceID" HeaderText="Source" />
                <asp:BoundField DataField="Action" HeaderText="Action" />
                <asp:BoundField DataField="Amount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="PrevBudget" HeaderText="Prev Budget" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="NewBudget"  HeaderText="New Budget"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="PrevUtil"   HeaderText="Prev Util"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="NewUtil"    HeaderText="New Util"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="PrevLocked" HeaderText="Prev Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="NewLocked"  HeaderText="New Locked"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="Notes"      HeaderText="Notes" />
                <asp:BoundField DataField="ActionBy"   HeaderText="By" />
                <asp:BoundField DataField="ActionDate" HeaderText="When" DataFormatString="{0:dd-MMM-yy HH:mm}" />
            </Columns>
            <EmptyDataTemplate>
                <div class="text-center text-muted" style="padding:14px;">No CAPEX/OPEX history yet for this project.</div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3>Debited amount history</h3>
        <asp:GridView ID="gvDebited" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="SourceType" HeaderText="Type" />
                <asp:BoundField DataField="SourceID" HeaderText="Source" />
                <asp:BoundField DataField="Amount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="ActionBy" HeaderText="By" />
                <asp:BoundField DataField="ActionDate" HeaderText="When" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
            </Columns>
        </asp:GridView>
    </div>

    <div class="toolbar">
        <asp:Button ID="btnExport" runat="server" Text="Export full history to Excel"
            CssClass="btn btn-success" OnClick="btnExport_Click" />
        <asp:HyperLink ID="lnkBack" runat="server" CssClass="btn btn-secondary" Text="Back to Project" />
    </div>
</asp:Content>
