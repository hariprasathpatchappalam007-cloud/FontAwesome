<%@ Page Title="Project History" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ProjectHistory.aspx.cs" Inherits="DFM.Forms.ProjectHistory" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">Project History</h1>

    <div class="card-panel">
        <h3>
            <asp:Literal ID="litTitle" runat="server" />
        </h3>
        <p class="text-muted">
            <asp:Literal ID="litSummary" runat="server" />
        </p>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-time"></span> Workflow / Audit Trail</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gvWorkflow" runat="server" AutoGenerateColumns="false"
                CssClass="dfm-table audit-table" GridLines="None"
                AllowPaging="true" PageSize="15"
                OnPageIndexChanging="gvWorkflow_PageIndexChanging">
                <PagerStyle CssClass="pager" />
                <Columns>
                    <asp:TemplateField HeaderText="#" ItemStyle-Width="40px" ItemStyle-CssClass="text-center">
                        <ItemTemplate>
                            <%# Container.DataItemIndex + 1 + (gvWorkflow.PageIndex * gvWorkflow.PageSize) %>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="Stage" ItemStyle-Width="150px">
                        <ItemTemplate>
                            <span class='audit-stage audit-<%# Eval("Stage").ToString().ToLower().Replace(" ", "-") %>'>
                                <%# Eval("Stage") %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="ActionBy" HeaderText="Action By" ItemStyle-Width="140px" />
                    <asp:BoundField DataField="ActionDate" HeaderText="Date / Time"
                        DataFormatString="{0:dd-MMM-yyyy HH:mm}" HtmlEncode="false" ItemStyle-Width="150px" />
                    <asp:TemplateField HeaderText="Version" ItemStyle-Width="70px" ItemStyle-CssClass="text-center">
                        <ItemTemplate>
                            <span class="chip chip-capex">v<%# Eval("Version") %></span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="Level" ItemStyle-Width="60px" ItemStyle-CssClass="text-center">
                        <ItemTemplate>
                            <%# Eval("ApprovalLevel") == System.DBNull.Value ? "&mdash;" : Eval("ApprovalLevel") %>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:TemplateField HeaderText="Comments">
                        <ItemTemplate>
                            <%# Eval("Comments") == System.DBNull.Value || Eval("Comments").ToString() == "" ? "<span class='text-muted'>(no comments)</span>" : Server.HtmlEncode(Eval("Comments").ToString()).Replace("\n","<br/>") %>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:14px;">No workflow events yet.</div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
        <asp:Label ID="lblNoWorkflow" runat="server" Text="No workflow events yet." CssClass="text-muted" Visible="false" />
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-comment"></span> Comments</h3>
        <div class="gridview-wrapper">
            <asp:GridView ID="gvComments" runat="server" AutoGenerateColumns="false"
                CssClass="dfm-table audit-table" GridLines="None"
                AllowPaging="true" PageSize="15"
                OnPageIndexChanging="gvComments_PageIndexChanging">
                <PagerStyle CssClass="pager" />
                <Columns>
                    <asp:TemplateField HeaderText="#" ItemStyle-Width="40px" ItemStyle-CssClass="text-center">
                        <ItemTemplate>
                            <%# Container.DataItemIndex + 1 + (gvComments.PageIndex * gvComments.PageSize) %>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="CommentedBy" HeaderText="Commented By" ItemStyle-Width="160px" />
                    <asp:BoundField DataField="CommentedDate" HeaderText="Date / Time"
                        DataFormatString="{0:dd-MMM-yyyy HH:mm}" HtmlEncode="false" ItemStyle-Width="150px" />
                    <asp:TemplateField HeaderText="Comment">
                        <ItemTemplate>
                            <%# Server.HtmlEncode(Eval("CommentText").ToString()).Replace("\n","<br/>") %>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <EmptyDataTemplate>
                    <div class="text-center text-muted" style="padding:14px;">No comments recorded.</div>
                </EmptyDataTemplate>
            </asp:GridView>
        </div>
    </div>

    <div class="card-panel">
        <h3>Version snapshots</h3>
        <asp:GridView ID="gvVersions" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="Version" HeaderText="Version" />
                <asp:BoundField DataField="ChangedBy" HeaderText="Changed By" />
                <asp:BoundField DataField="ChangedDate" HeaderText="When" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                <asp:BoundField DataField="ChangeNotes" HeaderText="Notes" />
            </Columns>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3>Locked amount history</h3>
        <asp:GridView ID="gvLocked" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="SourceType" HeaderText="Type" />
                <asp:BoundField DataField="SourceID" HeaderText="Source" />
                <asp:BoundField DataField="Amount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="Action" HeaderText="Action" />
                <asp:BoundField DataField="ActionBy" HeaderText="By" />
                <asp:BoundField DataField="ActionDate" HeaderText="When" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
            </Columns>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-piggy-bank"></span> CAPEX / OPEX history (project-wise)</h3>
        <p class="text-muted">Tracks budget allocations and utilizations for the budget source linked to this project.</p>
        <asp:GridView ID="gvCapex" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="SourceType" HeaderText="Type" />
                <asp:BoundField DataField="SourceID" HeaderText="Source" />
                <asp:BoundField DataField="Action" HeaderText="Action" />
                <asp:BoundField DataField="Amount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="PrevBudget" HeaderText="Prev Budget" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="NewBudget"  HeaderText="New Budget"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="PrevUtil"   HeaderText="Prev Util"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="NewUtil"    HeaderText="New Util"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="PrevLocked" HeaderText="Prev Locked" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="NewLocked"  HeaderText="New Locked"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="Notes"      HeaderText="Notes" />
                <asp:BoundField DataField="ActionBy"   HeaderText="By" />
                <asp:BoundField DataField="ActionDate" HeaderText="When" DataFormatString="{0:dd-MMM-yy HH:mm}" />
            </Columns>
            <EmptyDataTemplate>
                <div class="text-center text-muted" style="padding:14px;">No CAPEX/OPEX history yet for this project.</div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3>Debited amount history</h3>
        <asp:GridView ID="gvDebited" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:BoundField DataField="SourceType" HeaderText="Type" />
                <asp:BoundField DataField="SourceID" HeaderText="Source" />
                <asp:BoundField DataField="Amount" HeaderText="Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="ActionBy" HeaderText="By" />
                <asp:BoundField DataField="ActionDate" HeaderText="When" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
            </Columns>
        </asp:GridView>
    </div>

    <div class="toolbar">
        <asp:Button ID="btnExport" runat="server" Text="Export full history to Excel"
            CssClass="btn btn-success" OnClick="btnExport_Click" />
        <asp:HyperLink ID="lnkBack" runat="server" CssClass="btn btn-secondary" Text="Back to Project" />
    </div>
</asp:Content>
