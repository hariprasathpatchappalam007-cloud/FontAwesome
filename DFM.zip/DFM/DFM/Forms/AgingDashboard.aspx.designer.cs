namespace DFM.Forms
{
    public partial class AgingDashboard
    {
        protected global::System.Web.UI.WebControls.Literal litTs;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
