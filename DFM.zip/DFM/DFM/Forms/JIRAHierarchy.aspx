<%@ Page Title="JIRA Hierarchy" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="JIRAHierarchy.aspx.cs" Inherits="DFM.Forms.JIRAHierarchy" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-tree-conifer"></span> JIRA Hierarchy
        <span class="dashboard-timestamp"><span class="glyphicon glyphicon-refresh"></span>
            Data Last Updated: <asp:Literal ID="litTs" runat="server" /></span>
    </h1>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-random"></span> DMGT &rarr; DIBITP Organization Tree</h3>
        <p style="font-size:.85em;color:var(--text-muted);">
            For interactive parent-child navigation with RAG roll-up, see
            <a href="<%= ResolveUrl("~/Forms/ProcessFlow.aspx") %>">Process Flow page</a>.
        </p>
        <div id="hcOrg" style="height:600px;"></div>
    </div>

    <script>
        (function () {
            var nodes = <%= JsNodes %>;
            if (!window.Highcharts || !nodes.length || !document.getElementById('hcOrg')) return;
            // Use sankey diagram as a fallback for tree visualization
            var data = [];
            nodes.forEach(function(n){
                if (n.parent) data.push([n.parent, n.key, 1]);
            });
            Highcharts.chart('hcOrg', {
                chart: { type: 'sankey' }, title: { text: null },
                series: [{
                    keys: ['from','to','weight'],
                    data: data,
                    type: 'sankey',
                    name: 'DMGT to DIBITP flow'
                }]
            });
        })();
    </script>
</asp:Content>
