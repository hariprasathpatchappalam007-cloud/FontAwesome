namespace DFM.Forms
{
    public partial class ProjectList
    {
        protected global::System.Web.UI.WebControls.DropDownList ddlType;
        protected global::System.Web.UI.WebControls.DropDownList ddlStage;
        protected global::System.Web.UI.WebControls.TextBox txtSearch;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.HyperLink lnkNew;
        protected global::System.Web.UI.WebControls.Literal litTree;
    }
}
