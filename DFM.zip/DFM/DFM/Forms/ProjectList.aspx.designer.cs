namespace DFM.Forms
{
    public partial class ProjectList
    {
        protected global::System.Web.UI.WebControls.DropDownList ddlType;
        protected global::System.Web.UI.WebControls.DropDownList ddlStatus;
        protected global::System.Web.UI.WebControls.Button btnExport;
        protected global::System.Web.UI.WebControls.HyperLink lnkNew;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
