namespace DFM.Forms
{
    public partial class SourceHistory
    {
        protected global::System.Web.UI.WebControls.Literal litTitle;
        protected global::System.Web.UI.WebControls.Literal litSource;
        protected global::System.Web.UI.WebControls.GridView gv;
    }
}
