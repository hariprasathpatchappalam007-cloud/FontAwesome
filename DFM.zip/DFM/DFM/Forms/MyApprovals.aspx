<%@ Page Title="My Approvals" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="MyApprovals.aspx.cs" Inherits="DFM.Forms.MyApprovals" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-thumbs-up"></span> My Approvals</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-hourglass"></span> Pending requests</h3>
        <p class="text-muted">Approvers can override the requested fund amount with the approved amount before approving. Self-approval is not allowed.</p>
        <asp:GridView ID="gvPending" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            DataKeyNames="ProjectID" OnRowCommand="gv_RowCommand">
            <Columns>
                <asp:HyperLinkField DataNavigateUrlFields="ProjectID"
                    DataNavigateUrlFormatString="~/Forms/ProjectRegistration.aspx?id={0}"
                    DataTextField="ProjectCode" HeaderText="Code" />
                <asp:BoundField DataField="ProjectName" HeaderText="Project" />
                <asp:TemplateField HeaderText="Type">
                    <ItemTemplate><span class='chip chip-<%# Eval("ProjectType").ToString().ToLower() %>'><%# Eval("ProjectType") %></span></ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="BudgetSourceID" HeaderText="Budget Source" />
                <asp:BoundField DataField="RequestedAmount" HeaderText="Requested" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:TemplateField HeaderText="Approved Amount">
                    <ItemTemplate>
                        <asp:TextBox runat="server" ID="txtApproved" CssClass="form-control no-select2" Text='<%# Eval("RequestedAmount", "{0:F2}") %>' />
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="ApproverName" HeaderText="Approver" />
                <asp:BoundField DataField="CreatedBy" HeaderText="Requestor" />
                <asp:BoundField DataField="SubmittedDate" HeaderText="Submitted" DataFormatString="{0:dd-MMM-yy HH:mm}" />
                <asp:TemplateField HeaderText="Comment">
                    <ItemTemplate>
                        <asp:TextBox runat="server" ID="txtCmt" CssClass="form-control no-select2" placeholder="Required for reject; optional for approve" />
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-success" CommandName="Approve"
                            CommandArgument='<%# Eval("ProjectID") %>'
                            OnClientClick="return confirm('Approve this project? Approved amount will be locked against the linked budget and routed back to the Requestor.');">
                            <span class="glyphicon glyphicon-ok"></span> Approve
                        </asp:LinkButton>
                        <asp:LinkButton runat="server" CssClass="btn btn-sm btn-danger" CommandName="Reject"
                            CommandArgument='<%# Eval("ProjectID") %>'>
                            <span class="glyphicon glyphicon-remove"></span> Reject
                        </asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
            <EmptyDataTemplate>
                <div class="text-center text-muted" style="padding:18px;">No pending requests.</div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-time"></span> Recently approved / rejected / closed</h3>
        <asp:GridView ID="gvDone" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:HyperLinkField DataNavigateUrlFields="ProjectID"
                    DataNavigateUrlFormatString="~/Forms/ProjectRegistration.aspx?id={0}"
                    DataTextField="ProjectCode" HeaderText="Code" />
                <asp:BoundField DataField="ProjectName" HeaderText="Project" />
                <asp:BoundField DataField="ProjectType" HeaderText="Type" />
                <asp:BoundField DataField="RequestedAmount" HeaderText="Requested" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="ApprovedAmount"  HeaderText="Approved"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="LockedAmount"   HeaderText="Locked"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="DebitedAmount"  HeaderText="Debited"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:TemplateField HeaderText="Status">
                    <ItemTemplate>
                        <span class='badge-status badge-<%# Eval("Status").ToString().ToLower() %>'><%# Eval("Status") %></span>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="ApprovedDate" HeaderText="When" DataFormatString="{0:dd-MMM-yy HH:mm}" />
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
