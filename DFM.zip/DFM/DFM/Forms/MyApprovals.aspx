<%@ Page Title="My Approvals" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="MyApprovals.aspx.cs" Inherits="DFM.Forms.MyApprovals" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-thumbs-up"></span> My Approvals</h1>

    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-hourglass"></span> Pending PET Approvals</h3>
        <p class="text-muted">Projects awaiting PET approval are listed below. Click <strong>View &amp; Approve</strong> to open the project and approve or reject in the Workflow screen.</p>
        <asp:GridView ID="gvPending" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            DataKeyNames="ProjectID">
            <Columns>
                <asp:HyperLinkField DataNavigateUrlFields="ProjectID"
                    DataNavigateUrlFormatString="~/Forms/Workflow.aspx?id={0}"
                    DataTextField="ProjectCode" HeaderText="Code" />
                <asp:BoundField DataField="ProjectName" HeaderText="Project" />
                <asp:TemplateField HeaderText="Type">
                    <ItemTemplate><span class='chip chip-<%# Eval("ProjectType").ToString().ToLower() %>'><%# Eval("ProjectType") %></span></ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="BudgetSourceID" HeaderText="Budget Source" />
                <asp:BoundField DataField="RequestedAmount" HeaderText="Requested (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="ApproverName" HeaderText="Approver" />
                <asp:BoundField DataField="CreatedBy" HeaderText="Requestor" />
                <asp:BoundField DataField="ModifiedDate" HeaderText="Submitted" DataFormatString="{0:dd-MMM-yy HH:mm}" />
                <asp:TemplateField HeaderText="Action">
                    <ItemTemplate>
                        <a href='<%# "~/Forms/Workflow.aspx?id=" + Eval("ProjectID") %>' class="btn btn-sm btn-primary">
                            <span class="glyphicon glyphicon-eye-open"></span> View &amp; Approve
                        </a>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
            <EmptyDataTemplate>
                <div class="text-center text-muted" style="padding:18px;">No pending PET approvals.</div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-time"></span> Recently approved / rejected PET requests</h3>
        <asp:GridView ID="gvDone" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None">
            <Columns>
                <asp:HyperLinkField DataNavigateUrlFields="ProjectID"
                    DataNavigateUrlFormatString="~/Forms/Workflow.aspx?id={0}"
                    DataTextField="ProjectCode" HeaderText="Code" />
                <asp:BoundField DataField="ProjectName" HeaderText="Project" />
                <asp:BoundField DataField="ProjectType" HeaderText="Type" />
                <asp:BoundField DataField="RequestedAmount"  HeaderText="Requested (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="PetApprovedAmount" HeaderText="PET Approved (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                <asp:BoundField DataField="ApproverName" HeaderText="Approver" />
                <asp:TemplateField HeaderText="PET Status">
                    <ItemTemplate>
                        <span class='badge-status badge-<%# Eval("PetApprovalStatus").ToString().ToLower() %>'><%# Eval("PetApprovalStatus") %></span>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="ModifiedDate" HeaderText="When" DataFormatString="{0:dd-MMM-yy HH:mm}" />
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>
