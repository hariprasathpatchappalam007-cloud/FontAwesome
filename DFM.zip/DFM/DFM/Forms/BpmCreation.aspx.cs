using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class BpmCreation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindProjects();
                if (Request.QueryString["projectId"] != null)
                {
                    ListItem li = ddlProject.Items.FindByValue(Request.QueryString["projectId"]);
                    if (li != null) { ddlProject.ClearSelection(); li.Selected = true; }
                }
                LoadContext();
                BindList();
            }
        }

        private int Pid
        {
            get { int x; return int.TryParse(ddlProject.SelectedValue, out x) ? x : 0; }
        }

        private void BindProjects()
        {
            DataTable dt = ProjectsDAL.GetProjects(null, "Approved");
            ddlProject.Items.Clear();
            ddlProject.Items.Add(new ListItem("-- Select project --", ""));
            foreach (DataRow r in dt.Rows)
                ddlProject.Items.Add(new ListItem(r["ProjectCode"] + " - " + r["ProjectName"], r["ProjectID"].ToString()));
        }

        protected void ddlProject_Changed(object sender, EventArgs e)
        {
            LoadContext();
            BindList();
        }

        private void LoadContext()
        {
            int pid = Pid;
            if (pid == 0) { litStatus.Text = "(none)"; return; }
            DataRow p = ProjectsDAL.GetProject(pid);
            if (p == null) return;
            litStatus.Text = string.Format("<span class='badge-status badge-{0}'>{1}</span>",
                p["Status"].ToString().ToLower(), p["Status"]);

            // Pre-fill from the most recent extracted attachment if fields are empty
            DataTable atts = PetDAL.GetAttachments(pid);
            foreach (DataRow a in atts.Rows)
            {
                string ej = a["ExtractedJson"] == DBNull.Value ? "" : a["ExtractedJson"].ToString();
                if (string.IsNullOrEmpty(ej)) continue;
                try
                {
                    JavaScriptSerializer jss = new JavaScriptSerializer();
                    Dictionary<string, object> d = jss.Deserialize<Dictionary<string, object>>(ej);
                    if (d == null) continue;
                    if (string.IsNullOrEmpty(txtVendor.Text) && d.ContainsKey("vendor")  && d["vendor"]  != null) txtVendor.Text = d["vendor"].ToString();
                    if (string.IsNullOrEmpty(txtInvNo.Text)  && d.ContainsKey("invoiceNo") && d["invoiceNo"] != null) txtInvNo.Text = d["invoiceNo"].ToString();
                    if (string.IsNullOrEmpty(txtCcy.Text)    && d.ContainsKey("currency") && d["currency"] != null) txtCcy.Text = d["currency"].ToString();
                    if (string.IsNullOrEmpty(txtMemo.Text)   && d.ContainsKey("subject")  && d["subject"]  != null) txtMemo.Text = d["subject"].ToString();
                    if (txtInvAmt.Text == "0" && d.ContainsKey("amount") && d["amount"] != null) txtInvAmt.Text = d["amount"].ToString();
                }
                catch { }
            }
        }

        private void BindList()
        {
            int pid = Pid;
            if (pid == 0) { gv.DataSource = null; gv.DataBind(); return; }
            gv.DataSource = PetDAL.GetBpmList(pid); gv.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int pid = Pid;
            if (pid == 0) { Msg("Select a project first."); return; }

            DateTime invDt; DateTime? invDate = null;
            if (DateTime.TryParse(txtInvDate.Text, out invDt)) invDate = invDt;
            decimal amt = CsvImporter.ParseDecimal(txtInvAmt.Text);

            int bpmId = PetDAL.CreateBpm(pid, txtRef.Text, txtInvNo.Text, invDate, amt,
                txtCcy.Text, txtVendor.Text, txtMemo.Text, txtNotes.Text, AuthHelper.CurrentUser);

            // Attach a workflow event so it shows in Project History
            DataRow p = ProjectsDAL.GetProject(pid);
            int v = p == null || p["Version"] == DBNull.Value ? 1 : Convert.ToInt32(p["Version"]);
            ProjectsDAL.AddWorkflow(pid, "BPM-Submitted", null, AuthHelper.CurrentUser,
                "BPM #" + bpmId + " (" + txtRef.Text + ") submitted", v);

            // Notify the requestor
            string requestor = p == null || p["CreatedBy"] == DBNull.Value ? "" : p["CreatedBy"].ToString();
            if (!string.IsNullOrEmpty(requestor))
                NotificationsDAL.Send(requestor, "BPM submitted",
                    "BPM " + txtRef.Text + " submitted for project " + p["ProjectCode"],
                    "~/Forms/BpmCreation.aspx?projectId=" + pid, pid, "BPM");

            Msg("BPM submitted.");
            BindList();
        }

        protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Close")
            {
                int bpmId = Convert.ToInt32(e.CommandArgument);
                CloseBpmAndUpdateBudgets(bpmId);
                BindList();
            }
        }

        private void CloseBpmAndUpdateBudgets(int bpmId)
        {
            DataRow b = PetDAL.GetBpm(bpmId);
            if (b == null) return;
            int pid = Convert.ToInt32(b["ProjectID"]);
            DataRow p = ProjectsDAL.GetProject(pid);
            if (p == null) return;

            string ptype = p["ProjectType"].ToString();
            string srcId = p["BudgetSourceID"] == DBNull.Value ? "" : p["BudgetSourceID"].ToString();
            decimal lockedAmt = p["LockedAmount"] == DBNull.Value ? 0m : Convert.ToDecimal(p["LockedAmount"]);
            decimal invoiceAmt = b["InvoiceAmount"] == DBNull.Value ? 0m : Convert.ToDecimal(b["InvoiceAmount"]);
            // Final amount used = invoice if provided; otherwise approved/locked.
            decimal finalAmt = invoiceAmt > 0 ? invoiceAmt : lockedAmt;

            // Snapshot the master BEFORE the close so we can show prev/new in CAPEX history.
            string masterTbl = ptype == "OPEX" ? "OpexMaster" : ptype == "AMC" ? "AmcMaster" : "CapexMaster";
            string keyCol  = ptype == "OPEX" ? "OpexID"     : ptype == "AMC" ? "AmcID"     : "CapexID";
            DataRow before = Db.QueryRow(string.Format("SELECT * FROM {0} WHERE {1}=@id", masterTbl, keyCol),
                Db.P("@id", srcId));

            decimal prevBudget   = before == null || before["Budget"]          == DBNull.Value ? 0 : Convert.ToDecimal(before["Budget"]);
            decimal prevUtil     = before == null || before["Utilization"]     == DBNull.Value ? 0 : Convert.ToDecimal(before["Utilization"]);
            decimal prevLocked   = before == null || before["LockedAmount"]    == DBNull.Value ? 0 : Convert.ToDecimal(before["LockedAmount"]);

            // On close: release locked, increase claim/utilization by finalAmt,
            // and recompute available + after-locked + net balance.
            Db.Exec(string.Format(@"
UPDATE {0}
SET LockedAmount         = ISNULL(LockedAmount,0) - @loc,
    Utilization          = ISNULL(Utilization,0)  + @final,
    ClaimAmount          = ISNULL(ClaimAmount,0)  + @final,
    AvailableBudget      = ISNULL(Budget,0) - (ISNULL(Utilization,0) + @final),
    BudgetAfterLockedAmount = ISNULL(Budget,0) - (ISNULL(LockedAmount,0) - @loc),
    NetBalance           = ISNULL(Budget,0) - (ISNULL(Utilization,0) + @final) - (ISNULL(LockedAmount,0) - @loc),
    ModifiedDate=GETDATE(), ModifiedBy=@u
WHERE {1}=@id", masterTbl, keyCol),
                Db.P("@loc", lockedAmt), Db.P("@final", finalAmt),
                Db.P("@u", AuthHelper.CurrentUser), Db.P("@id", srcId));

            // Re-read for new values
            DataRow after = Db.QueryRow(string.Format("SELECT * FROM {0} WHERE {1}=@id", masterTbl, keyCol),
                Db.P("@id", srcId));
            decimal newBudget   = after["Budget"]          == DBNull.Value ? 0 : Convert.ToDecimal(after["Budget"]);
            decimal newUtil     = after["Utilization"]     == DBNull.Value ? 0 : Convert.ToDecimal(after["Utilization"]);
            decimal newLocked   = after["LockedAmount"]    == DBNull.Value ? 0 : Convert.ToDecimal(after["LockedAmount"]);

            // Project-wise CAPEX/OPEX history
            Db.Exec(@"INSERT INTO CapexHistory(SourceType, SourceID, ProjectID, Action, Amount,
                        PrevBudget, NewBudget, PrevUtil, NewUtil, PrevLocked, NewLocked,
                        Notes, ActionBy)
                      VALUES(@st, @sid, @pid, 'BudgetUpdate', @amt, @pb, @nb, @pu, @nu, @pl, @nl, @notes, @u)",
                Db.P("@st", ptype), Db.P("@sid", srcId), Db.P("@pid", pid),
                Db.P("@amt", finalAmt),
                Db.P("@pb", prevBudget), Db.P("@nb", newBudget),
                Db.P("@pu", prevUtil),   Db.P("@nu", newUtil),
                Db.P("@pl", prevLocked), Db.P("@nl", newLocked),
                Db.P("@notes", "Closed via BPM #" + bpmId),
                Db.P("@u", AuthHelper.CurrentUser));

            // Mark project as Closed and route a notification
            Db.Exec(@"UPDATE Projects SET Status='Closed', CurrentStage='Closed',
                      DebitedAmount = @final, ModifiedBy=@u, ModifiedDate=GETDATE()
                      WHERE ProjectID=@id",
                Db.P("@final", finalAmt), Db.P("@u", AuthHelper.CurrentUser), Db.P("@id", pid));

            int v = p["Version"] == DBNull.Value ? 1 : Convert.ToInt32(p["Version"]);
            ProjectsDAL.AddWorkflow(pid, "Closed", null, AuthHelper.CurrentUser,
                "BPM #" + bpmId + " closed; CAPEX/OPEX updated.", v);

            // Close the BPM
            PetDAL.CloseBpm(bpmId, AuthHelper.CurrentUser);

            // Notify requestor
            string requestor = p["CreatedBy"] == DBNull.Value ? "" : p["CreatedBy"].ToString();
            if (!string.IsNullOrEmpty(requestor))
                NotificationsDAL.Send(requestor, "Workflow closed",
                    "BPM closed and " + ptype + " budget updated for " + p["ProjectCode"],
                    "~/Forms/ProjectHistory.aspx?id=" + pid, pid, "Closed");

            Msg("BPM closed. Budget, Utilization, Available, Locked and After-Locked amounts updated.");
        }

        private void Msg(string m) { lblMsg.Visible = true; lblMsg.Text = m; }
    }
}
