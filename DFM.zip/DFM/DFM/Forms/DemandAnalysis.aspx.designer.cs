namespace DFM.Forms
{
    public partial class DemandAnalysis
    {
        protected global::System.Web.UI.WebControls.Literal litTs;
        protected global::System.Web.UI.WebControls.Literal kTotal;
        protected global::System.Web.UI.WebControls.Literal kConv;
        protected global::System.Web.UI.WebControls.Literal kProg;
        protected global::System.Web.UI.WebControls.Literal kHold;
    }
}
