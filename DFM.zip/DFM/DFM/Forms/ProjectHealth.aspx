<%@ Page Title="Project Health" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="ProjectHealth.aspx.cs" Inherits="DFM.Forms.ProjectHealth" %>
<asp:Content ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><span class="glyphicon glyphicon-heart"></span> Project Health
        <span class="dashboard-timestamp"><span class="glyphicon glyphicon-refresh"></span>
            Data Last Updated: <asp:Literal ID="litTs" runat="server" /></span>
    </h1>

    <div class="kpi-grid">
        <div class="kpi-card kpi-green"><span class="glyphicon glyphicon-ok kpi-icon"></span>
            <div class="kpi-label">Green RAG</div><div class="kpi-value"><asp:Literal ID="kGreen" runat="server" /></div></div>
        <div class="kpi-card kpi-orange"><span class="glyphicon glyphicon-warning-sign kpi-icon"></span>
            <div class="kpi-label">Amber RAG</div><div class="kpi-value"><asp:Literal ID="kAmber" runat="server" /></div></div>
        <div class="kpi-card kpi-red"><span class="glyphicon glyphicon-alert kpi-icon"></span>
            <div class="kpi-label">Red RAG</div><div class="kpi-value"><asp:Literal ID="kRed" runat="server" /></div></div>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-alert"></span> RAG Distribution (Project / Schedule / Budget / RAID)</h3>
        <div id="hcRag" style="height:380px;"></div>
        <p style="font-size:.82em;color:var(--text-muted);margin-top:8px;">
            <strong>Project RAG</strong> is derived from <code>customfield_13509 - Overall Project RAG</code>.
        </p>
    </div>

    <div class="card-panel">
        <h3><span class="glyphicon glyphicon-list-alt"></span> Recent Red / Amber Projects</h3>
        <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="dfm-table" GridLines="None"
            AllowPaging="true" PageSize="20" OnPageIndexChanging="gv_Paging">
            <PagerStyle CssClass="pager" />
            <Columns>
                <asp:BoundField DataField="JiraKey" HeaderText="Key" />
                <asp:BoundField DataField="Summary" HeaderText="Summary" />
                <asp:BoundField DataField="OverallProjectRag" HeaderText="Overall RAG" />
                <asp:BoundField DataField="ScheduleRag" HeaderText="Schedule" />
                <asp:BoundField DataField="BudgetRag" HeaderText="Budget" />
                <asp:BoundField DataField="RaidRag" HeaderText="RAID" />
                <asp:BoundField DataField="Manager" HeaderText="Manager" />
            </Columns>
        </asp:GridView>
    </div>

    <script>
        (function () {
            var rag = <%= JsRag %>;
            if (window.Highcharts && rag.length && document.getElementById('hcRag')) {
                Highcharts.chart('hcRag', {
                    chart: { type: 'column' }, title: { text: null },
                    xAxis: { type: 'category' }, yAxis: { title: { text: 'Projects' }, allowDecimals: false },
                    plotOptions: { series: { dataLabels: { enabled: true } } },
                    series: [{ name: 'Projects', data: rag.map(function(r){
                        var c = r.bucket==='Red'?'#dc2626': r.bucket==='Amber'?'#d97706': r.bucket==='Green'?'#15803d':'#6b7280';
                        return { name: r.bucket, y: r.total, color: c };
                    }), colorByPoint: false }]
                });
            }
        })();
    </script>
</asp:Content>
