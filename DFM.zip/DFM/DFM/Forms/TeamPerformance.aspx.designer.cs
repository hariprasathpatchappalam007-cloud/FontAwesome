namespace DFM.Forms
{
    public partial class TeamPerformance
    {
        protected global::System.Web.UI.WebControls.Literal litTs;
    }
}
