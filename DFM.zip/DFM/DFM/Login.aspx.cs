using System;
using DFM.App_Code.Helpers;

namespace DFM
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && AuthHelper.IsWindowsAuth)
            {
                string winUser = null;
                if (User != null && User.Identity != null) winUser = User.Identity.Name;
                if (!string.IsNullOrEmpty(winUser))
                {
                    Session["Username"] = winUser;
                    Session["FullName"] = winUser;
                    Session["Role"] = "User";
                    Response.Redirect("~/Default.aspx");
                }
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string user = (txtUser.Text == null) ? "" : txtUser.Text.Trim();
            string pwd  = txtPwd.Text == null ? "" : txtPwd.Text;

            string err;
            if (AuthHelper.TryLogin(user, pwd, out err))
            {
                Response.Redirect("~/Default.aspx");
            }
            else
            {
                pnlError.Visible = true;
                litError.Text = System.Web.HttpUtility.HtmlEncode(err);
            }
        }
    }
}
