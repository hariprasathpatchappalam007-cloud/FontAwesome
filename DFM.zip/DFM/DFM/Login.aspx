<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="DFM.Login" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - DFM</title>
    <link href="<%= ResolveUrl("~/Content/Site.css") %>" rel="stylesheet" type="text/css" />
</head>
<body>
    <form id="form1" runat="server">
    <div class="login-shell">
        <div class="login-card">
            <h1>Demand Fund Management</h1>
            <p class="login-subtitle">Dubai Islamic Bank &middot; Sign in to continue</p>

            <asp:Panel ID="pnlError" runat="server" Visible="false" CssClass="alert-error">
                <asp:Literal ID="litError" runat="server" />
            </asp:Panel>

            <div class="alert-info">
                <strong>Test users</strong>: admin / approver / user1 &mdash; password <strong>Welcome@123</strong>
            </div>

            <div class="form-group">
                <label for="<%= txtUser.ClientID %>">Username</label>
                <asp:TextBox ID="txtUser" runat="server" CssClass="form-control" autocomplete="username" />
            </div>
            <div class="form-group">
                <label for="<%= txtPwd.ClientID %>">Password</label>
                <asp:TextBox ID="txtPwd" runat="server" TextMode="Password" CssClass="form-control" autocomplete="current-password" />
            </div>

            <asp:Button ID="btnLogin" runat="server" Text="Sign In" CssClass="btn btn-primary btn-login" OnClick="btnLogin_Click" />
        </div>
    </div>
    </form>
</body>
</html>
