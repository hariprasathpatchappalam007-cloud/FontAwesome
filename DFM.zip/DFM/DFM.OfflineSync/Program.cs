using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace DFM.OfflineSync
{
    internal static class Program
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["DFM"].ConnectionString;

        // Only these JIRA projects are synchronized into dbo.JiraIssues.
        private static readonly string[] AllowedProjectKeys = { "DMGT", "DIBITP", "IDC" };

        // CSV "Field Name" (case-insensitive) -> one or more dbo.JiraIssues text columns.
        // Column names here match the business field names used by the JIRA demand-details
        // JS config (Js/1.js), e.g. smeLead -> SmeLead, projectId -> ProjectId, etc.
        private static readonly Dictionary<string, string[]> TextFieldMap =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
            {
                { "Title", new[] { "Summary" } },
                { "Project Name", new[] { "Summary" } },
                { "PID Project Name", new[] { "Summary" } },
                { "Demand Title", new[] { "Summary" } },
                { "Status", new[] { "Status" } },
                { "Type", new[] { "ProjectType" } },
                { "Assignee", new[] { "Assignee" } },
                { "Reporter", new[] { "Reporter" } },
                { "Project ID", new[] { "ProjectId" } },
                { "Demand ID", new[] { "DemandId" } },
                { "Overall Project RAG", new[] { "ProjectRAG" } },
                { "SME Lead", new[] { "SmeLead" } },
                { "Size", new[] { "[Size]" } },
                { "Demand Owner", new[] { "DemandOwner" } },
                // customfield_13310 is exposed to the UI as both DemandDepartment (legacy) and
                // ProjectDepartment (per the requested projectDepartment field name).
                { "Demand Department", new[] { "DemandDepartment", "ProjectDepartment" } },
                { "Segment", new[] { "DemandSegment" } },
                { "Demand Segment", new[] { "DemandSegment" } },
                { "Demand Type", new[] { "DemandType" } },
                { "Primary Classification", new[] { "Classification" } },
                { "Platform", new[] { "Platform" } },
                { "Requirement", new[] { "Requirements" } },
                { "Description", new[] { "Requirements" } },
                { "Portfolio Executive Summary", new[] { "PortfolioExecutiveSummary" } },
                { "Accountable Executive Lead", new[] { "AccountableExecLead" } },
                { "Accountable Executive", new[] { "AccountableExec" } },
                { "Assigned Project Manager", new[] { "AssignedProjectManager" } },
                { "IDH Portfolio Head", new[] { "IdhPortfolioHead" } },
                { "Chief Name Mapping", new[] { "ChiefNameMapping" } },
            };

        // CSV "Field Name" (case-insensitive) -> dbo.JiraIssues date column.
        private static readonly Dictionary<string, string> DateFieldMap =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "Created", "Created" },
                { "Target Completion", "EndDate" },
                { "Proposed Baseline 0 End Date", "EndDate" },
                { "Planned Start", "ActivityPlannedStartDate" },
                { "Planned End", "ActivityPlannedEndDate" },
                { "Actual Start", "ActivityActualStartDate" },
                { "Actual End", "ActivityActualEndDate" },
            };

        private static readonly string[] JiraDateFormats =
        {
            "dd-MM-yyyy HH:mm", "dd-MMM-yy", "dd-MMM-yyyy", "d-MMM-yy", "d-MMM-yyyy",
        };

        // Stakeholder columns surfaced together as StakeholderFields, matching the
        // stakeholderFields array in the JIRA demand-details JS config.
        private static readonly string[] StakeholderColumns =
        {
            "Assignee", "AssignedProjectManager", "DemandOwner", "Reporter",
            "ChiefNameMapping", "IdhPortfolioHead", "AccountableExec", "SmeLead",
        };
        private static int Main()
        {
            try
            {
                var capex = ImportBudgets(ConfigurationManager.AppSettings["CapexCsv"], "CAPEX");
                var opex = ImportBudgets(ConfigurationManager.AppSettings["OpexCsv"], "OPEX");
                var jira = ImportJira(ConfigurationManager.AppSettings["JiraCsv"]);
                Console.WriteLine("Offline sync complete. CAPEX={0}, OPEX={1}, JIRA fields={2}", capex, opex, jira);
                return 0;
            }
            catch (Exception exception) { Console.Error.WriteLine(exception); return 1; }
        }

        private static int ImportBudgets(string path, string type)
        {
            RequireFile(path); var count = 0; var rows = ReadCsv(path);
            using (var connection = Open())
                for (var index = 1; index < rows.Count; index++)
                {
                    var row = rows[index]; if (row.Count < 10 || string.IsNullOrWhiteSpace(row[1])) continue;
                    using (var command = new SqlCommand(@"MERGE dbo.BudgetSources AS t USING(SELECT @type BudgetType,@id ExternalId)s ON t.BudgetType=s.BudgetType AND t.ExternalId=s.ExternalId WHEN MATCHED THEN UPDATE SET Description=@description,Budget=@budget,Utilization=@used,AvailableBudget=@available,LockedAmount=@locked,BudgetAfterLocked=@afterLocked,ClaimAmount=@claim,NetBalance=@net,SourceFile=@source,LastSyncUtc=SYSUTCDATETIME(),UpdatedUtc=SYSUTCDATETIME() WHEN NOT MATCHED THEN INSERT(BudgetType,ExternalId,Description,Budget,Utilization,AvailableBudget,LockedAmount,BudgetAfterLocked,ClaimAmount,NetBalance,SourceFile,LastSyncUtc) VALUES(@type,@id,@description,@budget,@used,@available,@locked,@afterLocked,@claim,@net,@source,SYSUTCDATETIME());", connection))
                    {
                        command.Parameters.AddWithValue("@type", type); command.Parameters.AddWithValue("@id", row[1].Trim()); command.Parameters.AddWithValue("@description", row[2].Trim());
                        command.Parameters.AddWithValue("@budget", Money(row[3])); command.Parameters.AddWithValue("@used", Money(row[4])); command.Parameters.AddWithValue("@available", Money(row[5])); command.Parameters.AddWithValue("@locked", Money(row[6])); command.Parameters.AddWithValue("@afterLocked", Money(row[7])); command.Parameters.AddWithValue("@claim", Money(row[8])); command.Parameters.AddWithValue("@net", Money(row[9])); command.Parameters.AddWithValue("@source", path); command.ExecuteNonQuery(); count++;
                    }
                }
            return count;
        }

        private static int ImportJira(string path)
        {
            RequireFile(path); var rows = ReadCsv(path); var count = 0;
            var issueGroups = new List<KeyValuePair<string, List<List<string>>>>();
            var issueIndex = new Dictionary<string, List<List<string>>>(StringComparer.OrdinalIgnoreCase);
            for (var index = 1; index < rows.Count; index++)
            {
                var row = rows[index];
                if (row.Count < 4 || string.IsNullOrWhiteSpace(row[0])) continue;
                var jiraKey = row[0].Trim();
                if (!IsAllowedProject(jiraKey)) continue;
                List<List<string>> group;
                if (!issueIndex.TryGetValue(jiraKey, out group))
                {
                    group = new List<List<string>>();
                    issueIndex[jiraKey] = group;
                    issueGroups.Add(new KeyValuePair<string, List<List<string>>>(jiraKey, group));
                }
                group.Add(row);
            }

            using (var connection = Open())
            {
                foreach (var issue in issueGroups)
                {
                    var jiraKey = issue.Key;
                    foreach (var row in issue.Value)
                    {
                        var section = row[1].Trim();
                        var field = row[2].Trim();
                        var value = row[3].Trim();
                        using (var command = new SqlCommand(@"MERGE dbo.JiraIssueFields AS t USING(SELECT @key JiraKey,@section SectionName,@field FieldName)s ON t.JiraKey=s.JiraKey AND t.SectionName=s.SectionName AND t.FieldName=s.FieldName WHEN MATCHED THEN UPDATE SET FieldValue=@value,SyncedUtc=SYSUTCDATETIME() WHEN NOT MATCHED THEN INSERT(JiraKey,SectionName,FieldName,FieldValue) VALUES(@key,@section,@field,@value);", connection))
                        {
                            command.Parameters.AddWithValue("@key", jiraKey);
                            command.Parameters.AddWithValue("@section", section);
                            command.Parameters.AddWithValue("@field", field);
                            command.Parameters.AddWithValue("@value", value);
                            command.ExecuteNonQuery();
                        }
                        count++;
                    }

                    UpsertJiraBusinessFields(connection, jiraKey, issue.Value);
                }
            }
            return count;
        }

        private static bool IsAllowedProject(string jiraKey)
        {
            var separator = jiraKey.IndexOf('-');
            if (separator <= 0) return false;
            var projectPrefix = jiraKey.Substring(0, separator);
            return AllowedProjectKeys.Any(allowed => string.Equals(allowed, projectPrefix, StringComparison.OrdinalIgnoreCase));
        }

        // Resolves every mapped business field for one issue's rows and performs a single
        // upsert into dbo.JiraIssues, using the same field names as the JIRA demand-details JS config.
        private static void UpsertJiraBusinessFields(SqlConnection connection, string jiraKey, List<List<string>> issueRows)
        {
            var textValues = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var dateValues = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
            var attachments = new List<string>();

            foreach (var row in issueRows)
            {
                var section = row[1].Trim();
                var field = row[2].Trim();
                var value = row[3].Trim();
                if (string.IsNullOrWhiteSpace(value)) continue;

                if (string.Equals(section, "Attachments", StringComparison.OrdinalIgnoreCase)) attachments.Add(value);

                string[] textColumns;
                if (TextFieldMap.TryGetValue(field, out textColumns))
                    foreach (var column in textColumns)
                        if (!textValues.ContainsKey(column)) textValues[column] = value;

                string dateColumn;
                DateTime parsedDate;
                if (DateFieldMap.TryGetValue(field, out dateColumn) && !dateValues.ContainsKey(dateColumn) && TryParseJiraDate(value, out parsedDate))
                    dateValues[dateColumn] = parsedDate;

                if (string.Equals(field, "is child of", StringComparison.OrdinalIgnoreCase) && !textValues.ContainsKey("DemandId"))
                {
                    var match = Regex.Match(value, @"^([A-Za-z]+-\d+)");
                    if (match.Success) textValues["DemandId"] = match.Groups[1].Value;
                }
            }

            // activityStartDate/activityEndDate mirror the Actual pair per the JS config comment.
            DateTime actualStart;
            if (dateValues.TryGetValue("ActivityActualStartDate", out actualStart)) dateValues["ActivityStartDate"] = actualStart;
            DateTime actualEnd;
            if (dateValues.TryGetValue("ActivityActualEndDate", out actualEnd)) dateValues["ActivityEndDate"] = actualEnd;

            string assignee;
            if (textValues.TryGetValue("Assignee", out assignee)) textValues["ActivityResponsible"] = assignee;

            var stakeholders = StakeholderColumns
                .Where(textValues.ContainsKey)
                .Select(column => "\"" + column + "\":\"" + JsonEscape(textValues[column]) + "\"");
            var stakeholderJson = "{" + string.Join(",", stakeholders) + "}";
            if (stakeholderJson != "{}") textValues["StakeholderFields"] = stakeholderJson;

            if (attachments.Count > 0)
                textValues["Attachments"] = "[" + string.Join(",", attachments.Select(a => "\"" + JsonEscape(a) + "\"")) + "]";

            if (textValues.Count == 0 && dateValues.Count == 0) return;

            var setClauses = new List<string>();
            using (var command = new SqlCommand { Connection = connection })
            {
                var parameterIndex = 0;
                foreach (var pair in textValues)
                {
                    var parameterName = "@t" + parameterIndex++;
                    setClauses.Add(pair.Key + "=" + parameterName);
                    command.Parameters.AddWithValue(parameterName, pair.Value);
                }
                foreach (var pair in dateValues)
                {
                    var parameterName = "@d" + parameterIndex++;
                    setClauses.Add(pair.Key + "=" + parameterName);
                    command.Parameters.AddWithValue(parameterName, pair.Value);
                }
                command.Parameters.AddWithValue("@key", jiraKey);
                command.CommandText =
                    "IF NOT EXISTS(SELECT 1 FROM dbo.JiraIssues WHERE JiraKey=@key) " +
                    "INSERT dbo.JiraIssues(JiraID,JiraKey,IssueType,ProjectType) VALUES(@key,@key,'Project','Project'); " +
                    "UPDATE dbo.JiraIssues SET " + string.Join(",", setClauses) + ",SyncedUtc=SYSUTCDATETIME() WHERE JiraKey=@key;";
                command.ExecuteNonQuery();
            }
        }

        private static bool TryParseJiraDate(string value, out DateTime result)
        {
            if (DateTime.TryParseExact(value, JiraDateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out result)) return true;
            return DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.None, out result);
        }

        private static string JsonEscape(string value)
        {
            return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", " ").Replace("\n", " ");
        }

        private static SqlConnection Open() { var connection = new SqlConnection(ConnectionString); connection.Open(); return connection; }
        private static decimal Money(string value) { decimal result; return decimal.TryParse((value ?? "").Replace(",", "").Trim(), NumberStyles.Number | NumberStyles.AllowCurrencySymbol, CultureInfo.InvariantCulture, out result) ? result : 0; }
        private static void RequireFile(string path) { if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) throw new FileNotFoundException("Offline source was not found.", path); }
        private static List<List<string>> ReadCsv(string path)
        {
            string text;
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var reader = new StreamReader(stream, Encoding.Default))
                text = reader.ReadToEnd();
            var result = new List<List<string>>(); var row = new List<string>(); var field = new StringBuilder(); var quoted = false;
            for (var index = 0; index < text.Length; index++) { var character = text[index]; if (character == '"') { if (quoted && index + 1 < text.Length && text[index + 1] == '"') { field.Append('"'); index++; } else quoted = !quoted; } else if (character == ',' && !quoted) { row.Add(field.ToString()); field.Length = 0; } else if ((character == '\r' || character == '\n') && !quoted) { if (character == '\r' && index + 1 < text.Length && text[index + 1] == '\n') index++; row.Add(field.ToString()); field.Length = 0; result.Add(row); row = new List<string>(); } else field.Append(character); }
            if (field.Length > 0 || row.Count > 0) { row.Add(field.ToString()); result.Add(row); } return result;
        }
    }
}
