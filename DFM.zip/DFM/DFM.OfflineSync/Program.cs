using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;

namespace DFM.OfflineSync
{
    internal static class Program
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["DFM"].ConnectionString;
        private static int Main()
        {
            try
            {
                var capex = ImportBudgets(ConfigurationManager.AppSettings["CapexCsv"], "CAPEX");
                var opex = ImportBudgets(ConfigurationManager.AppSettings["OpexCsv"], "OPEX");
                var jira = ImportJira(ConfigurationManager.AppSettings["JiraCsv"]);
                Console.WriteLine("Offline sync complete. CAPEX={0}, OPEX={1}, JIRA fields={2}", capex, opex, jira);
                return 0;
            }
            catch (Exception exception) { Console.Error.WriteLine(exception); return 1; }
        }

        private static int ImportBudgets(string path, string type)
        {
            RequireFile(path); var count = 0; var rows = ReadCsv(path);
            using (var connection = Open())
                for (var index = 1; index < rows.Count; index++)
                {
                    var row = rows[index]; if (row.Count < 10 || string.IsNullOrWhiteSpace(row[1])) continue;
                    using (var command = new SqlCommand(@"MERGE dbo.BudgetSources AS t USING(SELECT @type BudgetType,@id ExternalId)s ON t.BudgetType=s.BudgetType AND t.ExternalId=s.ExternalId WHEN MATCHED THEN UPDATE SET Description=@description,Budget=@budget,Utilization=@used,AvailableBudget=@available,LockedAmount=@locked,BudgetAfterLocked=@afterLocked,ClaimAmount=@claim,NetBalance=@net,SourceFile=@source,LastSyncUtc=SYSUTCDATETIME(),UpdatedUtc=SYSUTCDATETIME() WHEN NOT MATCHED THEN INSERT(BudgetType,ExternalId,Description,Budget,Utilization,AvailableBudget,LockedAmount,BudgetAfterLocked,ClaimAmount,NetBalance,SourceFile,LastSyncUtc) VALUES(@type,@id,@description,@budget,@used,@available,@locked,@afterLocked,@claim,@net,@source,SYSUTCDATETIME());", connection))
                    {
                        command.Parameters.AddWithValue("@type", type); command.Parameters.AddWithValue("@id", row[1].Trim()); command.Parameters.AddWithValue("@description", row[2].Trim());
                        command.Parameters.AddWithValue("@budget", Money(row[3])); command.Parameters.AddWithValue("@used", Money(row[4])); command.Parameters.AddWithValue("@available", Money(row[5])); command.Parameters.AddWithValue("@locked", Money(row[6])); command.Parameters.AddWithValue("@afterLocked", Money(row[7])); command.Parameters.AddWithValue("@claim", Money(row[8])); command.Parameters.AddWithValue("@net", Money(row[9])); command.Parameters.AddWithValue("@source", path); command.ExecuteNonQuery(); count++;
                    }
                }
            return count;
        }

        private static int ImportJira(string path)
        {
            RequireFile(path); var rows = ReadCsv(path); var count = 0;
            using (var connection = Open())
                for (var index = 1; index < rows.Count; index++)
                {
                    var row = rows[index]; if (row.Count < 4 || string.IsNullOrWhiteSpace(row[0])) continue;
                    using (var command = new SqlCommand(@"MERGE dbo.JiraIssueFields AS t USING(SELECT @key JiraKey,@section SectionName,@field FieldName)s ON t.JiraKey=s.JiraKey AND t.SectionName=s.SectionName AND t.FieldName=s.FieldName WHEN MATCHED THEN UPDATE SET FieldValue=@value,SyncedUtc=SYSUTCDATETIME() WHEN NOT MATCHED THEN INSERT(JiraKey,SectionName,FieldName,FieldValue) VALUES(@key,@section,@field,@value); IF NOT EXISTS(SELECT 1 FROM dbo.JiraIssues WHERE JiraKey=@key) INSERT dbo.JiraIssues(JiraID,JiraKey,Summary,Status,IssueType,ProjectType) VALUES(@key,@key,CASE WHEN @field='Title' THEN @value ELSE @key END,'Offline import','Project','Project'); UPDATE dbo.JiraIssues SET Summary=CASE WHEN @field IN('Title','Project Name','PID Project Name') THEN @value ELSE Summary END,Status=CASE WHEN @field='Status' THEN @value ELSE Status END,ProjectType=CASE WHEN @field='Type' THEN @value ELSE ProjectType END,AccountableExecLead=CASE WHEN @field='Accountable Executive Lead' THEN @value ELSE AccountableExecLead END,AccountableExec=CASE WHEN @field='Accountable Executive' THEN @value ELSE AccountableExec END,SmeLead=CASE WHEN @field='SME Lead' THEN @value ELSE SmeLead END,AssignedProjectManager=CASE WHEN @field='Assigned Project Manager' THEN @value ELSE AssignedProjectManager END,ProjectRAG=CASE WHEN @field='Overall Project RAG' THEN @value ELSE ProjectRAG END,Platform=CASE WHEN @field='Platform' THEN @value ELSE Platform END,DemandType=CASE WHEN @field='Demand Type' THEN @value ELSE DemandType END,DemandDepartment=CASE WHEN @field='Demand Department' THEN @value ELSE DemandDepartment END,DemandSegment=CASE WHEN @field='Segment' THEN @value ELSE DemandSegment END,Requirements=CASE WHEN @field IN('Requirement','Description') THEN @value ELSE Requirements END,PortfolioExecutiveSummary=CASE WHEN @field='Portfolio Executive Summary' THEN @value ELSE PortfolioExecutiveSummary END,SyncedUtc=SYSUTCDATETIME() WHERE JiraKey=@key;", connection))
                    {
                        command.Parameters.AddWithValue("@key", row[0].Trim()); command.Parameters.AddWithValue("@section", row[1].Trim()); command.Parameters.AddWithValue("@field", row[2].Trim()); command.Parameters.AddWithValue("@value", row[3].Trim()); command.ExecuteNonQuery(); count++;
                    }
                }
            return count;
        }

        private static SqlConnection Open() { var connection = new SqlConnection(ConnectionString); connection.Open(); return connection; }
        private static decimal Money(string value) { decimal result; return decimal.TryParse((value ?? "").Replace(",", "").Trim(), NumberStyles.Number | NumberStyles.AllowCurrencySymbol, CultureInfo.InvariantCulture, out result) ? result : 0; }
        private static void RequireFile(string path) { if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) throw new FileNotFoundException("Offline source was not found.", path); }
        private static List<List<string>> ReadCsv(string path)
        {
            var result = new List<List<string>>(); var row = new List<string>(); var field = new StringBuilder(); var quoted = false; var text = File.ReadAllText(path, Encoding.Default);
            for (var index = 0; index < text.Length; index++) { var character = text[index]; if (character == '"') { if (quoted && index + 1 < text.Length && text[index + 1] == '"') { field.Append('"'); index++; } else quoted = !quoted; } else if (character == ',' && !quoted) { row.Add(field.ToString()); field.Length = 0; } else if ((character == '\r' || character == '\n') && !quoted) { if (character == '\r' && index + 1 < text.Length && text[index + 1] == '\n') index++; row.Add(field.ToString()); field.Length = 0; result.Add(row); row = new List<string>(); } else field.Append(character); }
            if (field.Length > 0 || row.Count > 0) { row.Add(field.ToString()); result.Add(row); } return result;
        }
    }
}
