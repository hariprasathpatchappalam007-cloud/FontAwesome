using System.Reflection;
[assembly: AssemblyTitle("DFM.OfflineSync")]
[assembly: AssemblyCompany("DFM")]
[assembly: AssemblyProduct("DFM Offline Data Sync")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
