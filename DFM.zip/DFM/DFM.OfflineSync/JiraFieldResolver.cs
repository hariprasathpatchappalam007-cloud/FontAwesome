using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;

namespace DFM.OfflineSync
{
    // Resolves JIRA field display names (e.g. "Project Methodology") to their customfield_XXXXX id
    // via GET /rest/api/2/field, so new fields can be added by name instead of guessing numeric ids.
    internal static class JiraFieldResolver
    {
        private static Dictionary<string, string> _nameToId;

        public static void Load(string baseUrl, string user, string pass, int timeoutMs)
        {
            _nameToId = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                string url = baseUrl.TrimEnd('/') + "/rest/api/2/field";
                var req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "GET";
                req.Timeout = timeoutMs;
                req.ReadWriteTimeout = timeoutMs;
                req.Accept = "application/json";
                if (!string.IsNullOrEmpty(user))
                {
                    string token = Convert.ToBase64String(Encoding.UTF8.GetBytes(user + ":" + pass));
                    req.Headers["Authorization"] = "Basic " + token;
                }

                string body;
                using (var resp = (HttpWebResponse)req.GetResponse())
                using (var sr = new System.IO.StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    body = sr.ReadToEnd();

                var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var list = ser.Deserialize<ArrayList>(body);
                if (list == null) return;
                foreach (Dictionary<string, object> field in list)
                {
                    if (!field.ContainsKey("id") || !field.ContainsKey("name")) continue;
                    string id = field["id"] as string;
                    string name = field["name"] as string;
                    if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(name)) continue;
                    if (!_nameToId.ContainsKey(name)) _nameToId[name] = id;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("  JiraFieldResolver: could not load field metadata (" + ex.Message + "). Name-based fields will be skipped.");
            }
        }

        // Returns the customfield_XXXXX (or built-in) id for a display name, or null if unknown/not yet loaded.
        public static string GetId(string displayName)
        {
            if (_nameToId == null || string.IsNullOrEmpty(displayName)) return null;
            string id;
            return _nameToId.TryGetValue(displayName, out id) ? id : null;
        }
    }
}
