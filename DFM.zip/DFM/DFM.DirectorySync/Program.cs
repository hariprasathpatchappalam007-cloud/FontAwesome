using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices;

namespace DFM.DirectorySync
{
    internal static class Program
    {
        private static int Main()
        {
            var synced = 0;
            try
            {
                var domain = ConfigurationManager.AppSettings["DirectoryDomain"];
                var ou = ConfigurationManager.AppSettings["DirectoryOu"];
                using (var root = new DirectoryEntry("LDAP://" + ou))
                using (var search = new DirectorySearcher(root, "(&(objectCategory=person)(objectClass=user)(mail=*))", new[] { "mail", "displayName", "sAMAccountName", "objectGUID" }))
                using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DFM"].ConnectionString))
                {
                    search.PageSize = 1000;
                    connection.Open();
                    using (var session = new SqlCommand("SET QUOTED_IDENTIFIER ON; SET ANSI_NULLS ON; SET ANSI_PADDING ON; SET ANSI_WARNINGS ON; SET CONCAT_NULL_YIELDS_NULL ON; SET ARITHABORT ON; SET NUMERIC_ROUNDABORT OFF;", connection))
                        session.ExecuteNonQuery();
                    foreach (SearchResult result in search.FindAll())
                    {
                        using (var command = new SqlCommand("dbo.sp_SyncDirectoryUser", connection))
                        {
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@Email", Text(result, "mail"));
                            command.Parameters.AddWithValue("@DisplayName", Text(result, "displayName"));
                            command.Parameters.AddWithValue("@AccountName", domain + "\\" + Text(result, "sAMAccountName"));
                            command.Parameters.Add("@ObjectGuid", SqlDbType.UniqueIdentifier).Value = new Guid((byte[])result.Properties["objectGUID"][0]);
                            command.Parameters.AddWithValue("@DefaultRole", ConfigurationManager.AppSettings["DefaultRole"] ?? "Requestor");
                            command.ExecuteNonQuery();
                            synced++;
                        }
                    }
                }
                Console.WriteLine("Synchronized {0} directory users.", synced);
                return 0;
            }
            catch (Exception exception) { Console.Error.WriteLine(exception); return 1; }
        }

        private static string Text(SearchResult result, string name) { return result.Properties[name].Count == 0 ? "" : Convert.ToString(result.Properties[name][0]); }
    }
}
