using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices.AccountManagement;

namespace DFM.DirectorySync
{
    internal static class LdapHelper
    {
        public static PrincipalContext CreateValidatedContext(
            string domain,
            string container,
            string username,
            string password)
        {
            if (string.IsNullOrWhiteSpace(domain))
                throw new ConfigurationErrorsException("DirectoryDomain is required.");
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                throw new ConfigurationErrorsException(
                    "DirectoryUser and the DFM_AD_PASSWORD environment variable are required.");

            var accountName = NormalizeUsername(username);
            var context = string.IsNullOrWhiteSpace(container)
                ? new PrincipalContext(ContextType.Domain, domain, accountName, password)
                : new PrincipalContext(ContextType.Domain, domain, container, accountName, password);

            if (context.ValidateCredentials(accountName, password, ContextOptions.Negotiate))
                return context;

            context.Dispose();
            throw new UnauthorizedAccessException("Active Directory credentials are invalid.");
        }

        private static string NormalizeUsername(string username)
        {
            var separator = username.IndexOf('\\');
            return separator >= 0 ? username.Substring(separator + 1) : username;
        }
    }

    internal static class Program
    {
        private static int Main()
        {
            try
            {
                var domain = ConfigurationManager.AppSettings["DirectoryDomain"];
                var container = ConfigurationManager.AppSettings["DirectoryOu"];
                var username = ConfigurationManager.AppSettings["DirectoryUser"];
                var password = Environment.GetEnvironmentVariable("DFM_AD_PASSWORD");
                var defaultRole = ConfigurationManager.AppSettings["DefaultRole"] ?? "Requestor";

                using (var context = LdapHelper.CreateValidatedContext(
                    domain, container, username, password))
                using (var query = new UserPrincipal(context) { Enabled = true })
                using (var searcher = new PrincipalSearcher(query))
                using (var connection = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["DFM"].ConnectionString))
                {
                    connection.Open();
                    ConfigureSqlSession(connection);

                    var synchronized = 0;
                    foreach (var principal in searcher.FindAll())
                    {
                        using (var user = principal as UserPrincipal)
                        {
                            if (user == null || string.IsNullOrWhiteSpace(user.EmailAddress) || !user.Guid.HasValue)
                                continue;

                            SynchronizeUser(connection, domain, defaultRole, user);
                            synchronized++;
                        }
                    }

                    Console.WriteLine("Synchronized {0} directory users.", synchronized);
                }

                return 0;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine(exception);
                return 1;
            }
        }

        private static void ConfigureSqlSession(SqlConnection connection)
        {
            const string sql = "SET QUOTED_IDENTIFIER ON; SET ANSI_NULLS ON; " +
                "SET ANSI_PADDING ON; SET ANSI_WARNINGS ON; " +
                "SET CONCAT_NULL_YIELDS_NULL ON; SET ARITHABORT ON; " +
                "SET NUMERIC_ROUNDABORT OFF;";
            using (var command = new SqlCommand(sql, connection))
                command.ExecuteNonQuery();
        }

        private static void SynchronizeUser(
            SqlConnection connection,
            string domain,
            string defaultRole,
            UserPrincipal user)
        {
            using (var command = new SqlCommand("dbo.sp_SyncDirectoryUser", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@Email", SqlDbType.NVarChar, 254).Value = user.EmailAddress;
                command.Parameters.Add("@DisplayName", SqlDbType.NVarChar, 200).Value =
                    string.IsNullOrWhiteSpace(user.DisplayName) ? user.SamAccountName : user.DisplayName;
                command.Parameters.Add("@AccountName", SqlDbType.NVarChar, 200).Value =
                    domain + "\\" + user.SamAccountName;
                command.Parameters.Add("@ObjectGuid", SqlDbType.UniqueIdentifier).Value = user.Guid.Value;
                command.Parameters.Add("@DefaultRole", SqlDbType.NVarChar, 30).Value = defaultRole;
                command.ExecuteNonQuery();
            }
        }
    }
}
