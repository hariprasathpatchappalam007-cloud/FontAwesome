using System.Reflection;
[assembly: AssemblyTitle("DFM.DirectorySync")]
[assembly: AssemblyCompany("DFM")]
[assembly: AssemblyProduct("DFM Directory Sync")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
