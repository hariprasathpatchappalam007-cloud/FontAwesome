# Demand Fund Management (DFM)

ASP.NET Web Forms (.NET Framework 4.7.2) + C# + SQL Server application that
mirrors the existing `DemandFundManagement` project, with the additional
requirements from `Requirement\Req.txt`.

## Layout

```
DFM\
  DFM.sln
  DFM\
    DFM.csproj
    Web.config            -- Forms auth (default) / Windows auth supported
    Global.asax(.cs)      -- Auth bootstrap
    Site.Master           -- Sidebar nav, theme switcher, larger fonts
    Login.aspx            -- Forms login (admin / approver / user1, pwd Welcome@123)
    Default.aspx          -- Dashboard (KPIs, charts, filters, drill-down, export)
    Forms\
      ProjectRegistration.aspx   -- JIRA-id, CAPEX/OPEX/AMC search dropdown,
                                     budget/utilization/locked/net breakdown,
                                     comment + version tracking
      ProjectList.aspx           -- Filterable list, Export to Excel
      MyApprovals.aspx           -- Approve / reject (locks + debits master)
      ProjectHistory.aspx        -- Workflow / version / locked / debited / comment history
      JiraIntegration.aspx       -- Fetch issues from JIRA (cached fallback)
    Admin\
      CapexMaster.aspx           -- Maintained from Requirement\CAPEX.csv
      OpexMaster.aspx            -- Maintained from Requirement\OPEX.csv
      AmcMaster.aspx
      ApproverMaster.aspx        -- Configurable approver list
      JiraConfig.aspx            -- JIRA URL/token + custom-field visibility
      ThemeConfig.aspx           -- Theme picker with live preview
      UserSettings.aspx          -- One-time user preferences
      UserManagement.aspx        -- Manage Forms login accounts
    App_Code\
      DAL\Db.cs, MastersDAL.cs, ProjectsDAL.cs
      Helpers\AuthHelper.cs, PasswordHelper.cs, ExcelHelper.cs,
              JiraClient.cs, CsvImporter.cs
    Content\Site.css       -- Larger base font (17px), bold dark headings, colorful theme
    Scripts\app.js
    SQL\
      01_CreateDatabase.sql
      02_CreateTables.sql
      03_SeedData.sql
```

## Quick start

1. Run the SQL scripts (in order) against your SQL Server instance:
   `01_CreateDatabase.sql`, `02_CreateTables.sql`, `03_SeedData.sql`.
2. Update `Web.config` connection string `DFMConnection` (Server, DB).
3. Open `DFM.sln` in Visual Studio. Build, set `DFM` as startup, run.
4. Login with `admin` / `approver` / `user1` and password `Welcome@123`.
5. From **CAPEX Master** / **OPEX Master**, click "Import from Requirement
   Folder" to load the CSVs from `C:\Users\Abinaya\source\Calude\DFM\Requirement`.
6. Optionally configure JIRA in **Admin / JIRA Config**.

## Authentication modes

`Web.config` supports both:

* **Forms** (default, for testing): users in `AppUsers` table.
* **Windows**: change `<authentication mode="Windows" />`, set `<deny users="?" />`
  off, and set `AuthMode` AppSetting to `Windows`. `Global.asax` will
  auto-populate the session from `HttpContext.User.Identity.Name`.

## Approval flow

1. User registers a project (Draft) and submits it.
2. The chosen approver sees it in **My Approvals**.
3. On approve: the project's `RequestedAmount` is **locked + debited** against
   the linked CAPEX/OPEX/AMC master row, and full history is recorded in
   `WorkflowHistory`, `LockedAmountHistory`, `DebitedAmountHistory`,
   `ProjectVersionHistory`, `ProjectComments`.

## Excel export

All grids (CAPEX, OPEX, AMC, Approvers, Users, Projects, Dashboard, JIRA,
Project History) have an "Export to Excel" button using `ExcelHelper.cs`
(no third-party library; produces an `.xls` HTML workbook).
