USE master;
GO
-- Replace placeholders through your secret-management process before running.
CREATE LOGIN dfm_app WITH PASSWORD = 'CHANGE_ME_APP', CHECK_POLICY = ON, CHECK_EXPIRATION = ON;
CREATE LOGIN dfm_sync WITH PASSWORD = 'CHANGE_ME_SYNC', CHECK_POLICY = ON, CHECK_EXPIRATION = ON;
GO
USE DFM;
GO
CREATE USER dfm_app FOR LOGIN dfm_app;
CREATE USER dfm_sync FOR LOGIN dfm_sync;
GO
GRANT SELECT ON dbo.vw_ManagementDashboard TO dfm_app;
GRANT SELECT ON dbo.vw_ProjectPortfolio TO dfm_app;
GRANT SELECT ON dbo.vw_JiraProjectPicker TO dfm_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.UserSessions TO dfm_app;
GRANT SELECT, INSERT, UPDATE ON dbo.Users TO dfm_app;
GRANT SELECT ON dbo.Roles TO dfm_app;
GRANT SELECT ON dbo.UserRoles TO dfm_app;
GRANT SELECT ON dbo.SecurityQuestions TO dfm_app;
GRANT SELECT, INSERT, UPDATE ON dbo.PasswordResetTokens TO dfm_app;
GRANT SELECT ON dbo.BudgetSources TO dfm_app;
GRANT SELECT ON dbo.PETRequests TO dfm_app;
GRANT SELECT ON dbo.SpendItems TO dfm_app;
GRANT SELECT ON dbo.BudgetLines TO dfm_app;
GRANT SELECT ON dbo.Invoices TO dfm_app;
GRANT SELECT, INSERT ON dbo.Attachments TO dfm_app;
GRANT EXECUTE TO dfm_app;
GRANT SELECT, INSERT, UPDATE ON dbo.Users TO dfm_sync;
GRANT SELECT, INSERT ON dbo.UserRoles TO dfm_sync;
GRANT SELECT ON dbo.Roles TO dfm_sync;
GRANT SELECT, INSERT, UPDATE ON dbo.BudgetSources TO dfm_sync;
GRANT SELECT, INSERT, UPDATE ON dbo.JiraIssues TO dfm_sync;
GRANT SELECT, INSERT, UPDATE ON dbo.JiraIssueFields TO dfm_sync;
GRANT EXECUTE ON dbo.sp_SyncDirectoryUser TO dfm_sync;
GO
