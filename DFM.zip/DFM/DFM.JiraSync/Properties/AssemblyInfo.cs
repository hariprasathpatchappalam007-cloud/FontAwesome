using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("DFM.JiraSync")]
[assembly: AssemblyDescription("Console app to sync JIRA DMGT/DIBITP issues into the DFM SQL database and refresh the dashboard summary tables.")]
[assembly: AssemblyCompany("DIB")]
[assembly: AssemblyProduct("DFM")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("B8B6C9E2-5DD7-4F2A-A451-AB7C92C1A3B9")]
