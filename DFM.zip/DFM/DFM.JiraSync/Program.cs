using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;

namespace DFM.JiraSync
{
    /// <summary>
    /// Req5: Separate Console Application that synchronises JIRA (DMGT + DIBITP)
    /// into the DFM SQL Server database. Designed to run on a schedule so the
    /// web dashboard only ever reads from pre-aggregated summary tables.
    ///
    /// Logging:
    ///   - Start/End time, total pulled, inserted/updated/failed counts
    ///   - Exception logs and API response logs (to .\logs\)
    /// </summary>
    internal class Program
    {
        private static readonly string ConnStr =
            ConfigurationManager.ConnectionStrings["DFM"].ConnectionString;
        private static readonly string BaseUrl =
            ConfigurationManager.AppSettings["JiraBaseUrl"];
        private static readonly string JiraUser =
            ConfigurationManager.AppSettings["JiraUser"];
        private static readonly string JiraPass =
            ConfigurationManager.AppSettings["JiraPassword"];
        private static readonly int BatchSize =
            int.Parse(ConfigurationManager.AppSettings["BatchSize"] ?? "1000");
        private static readonly string[] Projects =
            (ConfigurationManager.AppSettings["Projects"] ?? "DMGT,DIBITP").Split(',');
        private static readonly string CsvOut =
            ConfigurationManager.AppSettings["OutputCsvPath"] ?? "JIRADashboard.csv";

        private static int _inserted, _updated, _failed, _pulled;

        public static int Main(string[] args)
        {
            DateTime start = DateTime.Now;
            EnsureLogDir();
            Log("===== DFM JIRA Sync started at " + start.ToString("yyyy-MM-dd HH:mm:ss") + " =====");

            int syncId = StartSyncLog(start);

            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                foreach (string p in Projects)
                {
                    string proj = p.Trim();
                    if (proj.Length == 0) continue;
                    Log("--- Syncing project: " + proj + " ---");
                    SyncProject(proj);
                }

                Log("Applying DMGT->DIBITP hierarchy inheritance...");
                ExecSp("sp_ApplyHierarchyInheritance");

                Log("Refreshing dashboard summary tables...");
                ExecSp("sp_RefreshDashboardSummary");

                Log("Exporting JIRADashboard.csv...");
                ExportCsv();

                DateTime end = DateTime.Now;
                FinishSyncLog(syncId, end, "Success", null);
                Log(string.Format("===== Completed. Pulled={0}, Inserted={1}, Updated={2}, Failed={3}. Duration={4} =====",
                    _pulled, _inserted, _updated, _failed, end - start));
                return 0;
            }
            catch (Exception ex)
            {
                Log("FATAL: " + ex);
                FinishSyncLog(syncId, DateTime.Now, "Failed", ex.ToString());
                return 1;
            }
        }

        // ---- JIRA fetch (batched) ----
        private static void SyncProject(string projectKey)
        {
            int startAt = 0;
            while (true)
            {
                string jql = "project=" + projectKey + " ORDER BY updated DESC";
                string url = BaseUrl.TrimEnd('/') +
                    "/rest/api/2/search?jql=" + Uri.EscapeDataString(jql) +
                    "&startAt=" + startAt + "&maxResults=" + BatchSize +
                    "&fields=summary,status,issuetype,priority,created,updated,duedate,assignee,reporter,issuelinks," +
                    "customfield_12609,customfield_11632,customfield_11610,customfield_13380," +
                    "customfield_13419,customfield_13511,customfield_13510,customfield_13505,customfield_13509," +
                    "customfield_13317,customfield_13358,customfield_13357,customfield_14001";

                string body = HttpGet(url);
                LogResponse(projectKey, startAt, body);

                var ser = new JavaScriptSerializer();
                ser.MaxJsonLength = int.MaxValue;
                var obj = ser.Deserialize<Dictionary<string, object>>(body);
                if (obj == null || !obj.ContainsKey("issues")) break;

                var issues = obj["issues"] as System.Collections.ArrayList;
                if (issues == null || issues.Count == 0) break;

                int total = obj.ContainsKey("total") ? Convert.ToInt32(obj["total"]) : 0;
                Log(string.Format("  Batch startAt={0}, fetched={1}, total={2}", startAt, issues.Count, total));

                foreach (Dictionary<string, object> issue in issues)
                {
                    try
                    {
                        UpsertIssue(issue, projectKey);
                        _pulled++;
                    }
                    catch (Exception ex)
                    {
                        _failed++;
                        Log("  Upsert failed for " + (issue.ContainsKey("key") ? issue["key"] : "?") + ": " + ex.Message);
                    }
                }

                startAt += issues.Count;
                if (startAt >= total || issues.Count < BatchSize) break;
            }
        }

        private static void UpsertIssue(Dictionary<string, object> issue, string projectKey)
        {
            string key = issue["key"].ToString();
            var fields = issue["fields"] as Dictionary<string, object>;
            if (fields == null) return;

            string summary = Get(fields, "summary");
            string status = GetNested(fields, "status", "name");
            string priority = GetNested(fields, "priority", "name");
            string parentJid = ExtractParentKey(fields);

            // Custom fields per Req5
            string platform         = GetNested(fields, "customfield_12609", "value");
            string platformVertical = GetNested(fields, "customfield_11632", "value");
            string platformName     = GetNested(fields, "customfield_11610", "value");
            string secPlatform      = GetNested(fields, "customfield_13380", "value");
            string activityRag      = GetNested(fields, "customfield_13419", "value");
            string scheduleRag      = GetNested(fields, "customfield_13511", "value");
            string budgetRag        = GetNested(fields, "customfield_13510", "value");
            string raidRag          = GetNested(fields, "customfield_13505", "value");
            string overallRag       = GetNested(fields, "customfield_13509", "value");
            string reporter         = GetNested(fields, "customfield_13317", "displayName");
            string manager          = GetNested(fields, "customfield_13358", "displayName");
            string techLead         = GetNested(fields, "customfield_13357", "displayName");
            string chief            = GetNested(fields, "customfield_14001", "displayName");
            DateTime? created       = ParseDate(Get(fields, "created"));
            DateTime? updated       = ParseDate(Get(fields, "updated"));

            using (var con = new SqlConnection(ConnStr))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandTimeout = 150;
                    cmd.CommandText = @"
IF EXISTS (SELECT 1 FROM JiraIssues WHERE JiraKey=@k)
BEGIN
    UPDATE JiraIssues SET Summary=@summary, Status=@status, Priority=@priority,
        ProjectKey=@proj, ParentJiraID=@parent,
        Platform=@plat, PlatformVertical=@pv, PlatformName=@pn, SecondaryPlatform=@sp,
        ActivityRagStatus=@arag, ScheduleRag=@srag, BudgetRag=@brag, RaidRag=@raidr,
        OverallProjectRag=@orag, ChiefNameMapping=@chief, Manager=@mgr, TechLead=@tl,
        CreatedDate=ISNULL(CreatedDate,@cre), UpdatedDate=@upd
    WHERE JiraKey=@k;
    SELECT 0;
END
ELSE
BEGIN
    INSERT INTO JiraIssues(JiraKey,Summary,Status,Priority,ProjectKey,ParentJiraID,
        Platform,PlatformVertical,PlatformName,SecondaryPlatform,
        ActivityRagStatus,ScheduleRag,BudgetRag,RaidRag,OverallProjectRag,
        ChiefNameMapping,Manager,TechLead,CreatedDate,UpdatedDate)
    VALUES(@k,@summary,@status,@priority,@proj,@parent,
        @plat,@pv,@pn,@sp,@arag,@srag,@brag,@raidr,@orag,
        @chief,@mgr,@tl,@cre,@upd);
    SELECT 1;
END";
                    cmd.Parameters.AddWithValue("@k", key);
                    cmd.Parameters.AddWithValue("@summary", (object)summary ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@status", (object)status ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@priority", (object)priority ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@proj", projectKey);
                    cmd.Parameters.AddWithValue("@parent", (object)parentJid ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@plat", (object)platform ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@pv", (object)platformVertical ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@pn", (object)platformName ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@sp", (object)secPlatform ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@arag", (object)activityRag ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@srag", (object)scheduleRag ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@brag", (object)budgetRag ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@raidr", (object)raidRag ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@orag", (object)overallRag ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@chief", (object)chief ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@mgr", (object)manager ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@tl", (object)techLead ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@cre", created.HasValue ? (object)created.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@upd", updated.HasValue ? (object)updated.Value : DBNull.Value);

                    object r = cmd.ExecuteScalar();
                    int isInsert = r == null || r == DBNull.Value ? 0 : Convert.ToInt32(r);
                    if (isInsert == 1) _inserted++; else _updated++;
                }
            }
        }

        // ---- helpers ----
        private static string ExtractParentKey(Dictionary<string, object> fields)
        {
            if (!fields.ContainsKey("issuelinks") || fields["issuelinks"] == null) return null;
            var links = fields["issuelinks"] as System.Collections.ArrayList;
            if (links == null) return null;
            foreach (Dictionary<string, object> link in links)
            {
                var type = link["type"] as Dictionary<string, object>;
                string typeName = type != null && type.ContainsKey("name") ? type["name"].ToString() : "";
                string inward = type != null && type.ContainsKey("inward") ? type["inward"].ToString() : "";
                if (typeName.IndexOf("Parent", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    inward.IndexOf("child of", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    if (link.ContainsKey("inwardIssue"))
                    {
                        var iss = link["inwardIssue"] as Dictionary<string, object>;
                        if (iss != null && iss.ContainsKey("key")) return iss["key"].ToString();
                    }
                }
            }
            return null;
        }

        private static string Get(Dictionary<string, object> d, string k)
        {
            return d != null && d.ContainsKey(k) && d[k] != null ? d[k].ToString() : null;
        }
        private static string GetNested(Dictionary<string, object> d, string outer, string inner)
        {
            if (d == null || !d.ContainsKey(outer) || d[outer] == null) return null;
            var inn = d[outer] as Dictionary<string, object>;
            return Get(inn, inner);
        }
        private static DateTime? ParseDate(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            DateTime dt;
            return DateTime.TryParse(s, out dt) ? (DateTime?)dt : null;
        }

        private static string HttpGet(string url)
        {
            var req = (HttpWebRequest)WebRequest.Create(url);
            req.Timeout = 150000;
            req.Method = "GET";
            req.Accept = "application/json";
            if (!string.IsNullOrEmpty(JiraUser))
            {
                string token = Convert.ToBase64String(Encoding.UTF8.GetBytes(JiraUser + ":" + JiraPass));
                req.Headers["Authorization"] = "Basic " + token;
            }
            using (var resp = (HttpWebResponse)req.GetResponse())
            using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
            {
                return sr.ReadToEnd();
            }
        }

        // ---- SQL log helpers ----
        private static int StartSyncLog(DateTime start)
        {
            try
            {
                using (var con = new SqlConnection(ConnStr))
                {
                    con.Open();
                    using (var cmd = con.CreateCommand())
                    {
                        cmd.CommandText = "INSERT INTO JiraSyncLog(StartTime,Status) VALUES(@s,'Running'); SELECT CAST(SCOPE_IDENTITY() AS INT);";
                        cmd.Parameters.AddWithValue("@s", start);
                        return Convert.ToInt32(cmd.ExecuteScalar());
                    }
                }
            }
            catch { return -1; }
        }

        private static void FinishSyncLog(int id, DateTime end, string status, string exception)
        {
            if (id <= 0) return;
            try
            {
                using (var con = new SqlConnection(ConnStr))
                {
                    con.Open();
                    using (var cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"UPDATE JiraSyncLog
                            SET EndTime=@e, Status=@st, TotalPulled=@p, Inserted=@i, Updated=@u, Failed=@f, ExceptionLog=@x
                            WHERE SyncID=@id";
                        cmd.Parameters.AddWithValue("@e", end);
                        cmd.Parameters.AddWithValue("@st", status);
                        cmd.Parameters.AddWithValue("@p", _pulled);
                        cmd.Parameters.AddWithValue("@i", _inserted);
                        cmd.Parameters.AddWithValue("@u", _updated);
                        cmd.Parameters.AddWithValue("@f", _failed);
                        cmd.Parameters.AddWithValue("@x", (object)exception ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch { }
        }

        private static void ExecSp(string spName)
        {
            using (var con = new SqlConnection(ConnStr))
            {
                con.Open();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandTimeout = 300;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = spName;
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void ExportCsv()
        {
            string path = CsvOut;
            using (var w = new StreamWriter(path, false, Encoding.UTF8))
            {
                w.WriteLine("JiraKey,ProjectKey,ParentJiraID,Summary,Status,Priority,Platform,PlatformVertical,OverallProjectRag,Manager,TechLead,ChiefNameMapping,CreatedDate,UpdatedDate");
                using (var con = new SqlConnection(ConnStr))
                {
                    con.Open();
                    using (var cmd = con.CreateCommand())
                    {
                        cmd.CommandText = @"SELECT JiraKey,ProjectKey,ISNULL(ParentJiraID,''),ISNULL(Summary,''),
                            ISNULL(Status,''),ISNULL(Priority,''),ISNULL(Platform,''),ISNULL(PlatformVertical,''),
                            ISNULL(OverallProjectRag,''),ISNULL(Manager,''),ISNULL(TechLead,''),ISNULL(ChiefNameMapping,''),
                            ISNULL(CONVERT(VARCHAR(19),CreatedDate,120),''),ISNULL(CONVERT(VARCHAR(19),UpdatedDate,120),'')
                            FROM JiraIssues";
                        using (var rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                var sb = new StringBuilder();
                                for (int i = 0; i < rdr.FieldCount; i++)
                                {
                                    if (i > 0) sb.Append(',');
                                    string v = rdr.GetValue(i).ToString().Replace("\"", "\"\"");
                                    if (v.IndexOfAny(new[] { ',', '"', '\n' }) >= 0) v = "\"" + v + "\"";
                                    sb.Append(v);
                                }
                                w.WriteLine(sb);
                            }
                        }
                    }
                }
            }
        }

        // ---- logging ----
        private static string _logDir;
        private static void EnsureLogDir()
        {
            _logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
            Directory.CreateDirectory(_logDir);
        }
        private static void Log(string msg)
        {
            string line = DateTime.Now.ToString("HH:mm:ss") + " " + msg;
            Console.WriteLine(line);
            try { File.AppendAllText(Path.Combine(_logDir, "sync-" + DateTime.Now.ToString("yyyy-MM-dd") + ".log"), line + Environment.NewLine); }
            catch { }
        }
        private static void LogResponse(string proj, int startAt, string body)
        {
            try
            {
                string fn = string.Format("api-{0}-{1}-{2}.json", proj, startAt, DateTime.Now.ToString("HHmmss"));
                File.WriteAllText(Path.Combine(_logDir, fn), body);
            }
            catch { }
        }
    }
}
