<%@ Page Language="C#" MasterPageFile="~masterurl/custom.master" Inherits="Microsoft.SharePoint.WebPartPages.WebPartPage, Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>
<%@ Register TagPrefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>
<%@ Register TagPrefix="WebPartPages" Namespace="Microsoft.SharePoint.WebPartPages" Assembly="Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>

<asp:Content ContentPlaceHolderID="PlaceHolderPageTitle" runat="server">
    DIB Workflow Designer
</asp:Content>

<asp:Content ContentPlaceHolderID="PlaceHolderPageTitleInTitleArea" runat="server">
    Workflow Designer
</asp:Content>

<asp:Content ContentPlaceHolderID="PlaceHolderMain" runat="server">

    <!-- ======================== WORKFLOW DESIGNER ======================== -->
    <div class="dib-card" style="padding:0;overflow:hidden;">
        <div class="dib-card-header" style="padding:16px 24px;margin:0;border:none;">
            <h3><i class="fas fa-project-diagram"></i> Workflow Designer</h3>
            <div style="display:flex;gap:8px;align-items:center;">
                <input type="text" id="wfName" placeholder="Workflow Name" value="New Workflow"
                       style="padding:6px 12px;border:1px solid #E8EDEB;border-radius:6px;font-size:14px;width:200px;" />
                <span class="dib-status-badge draft">Draft</span>
            </div>
        </div>

        <div class="dib-workflow-designer">
            <!-- Toolbox -->
            <div class="dib-wf-toolbox">
                <div class="dib-wf-toolbox-header">
                    <h3><i class="fas fa-puzzle-piece"></i> Components</h3>
                </div>
                <div class="dib-wf-toolbox-search">
                    <input type="text" placeholder="Search components..." />
                </div>
                <div class="dib-wf-toolbox-items">
                    <!-- Populated by JS -->
                </div>
            </div>

            <!-- Canvas -->
            <div class="dib-wf-canvas-container">
                <div class="dib-wf-canvas-toolbar">
                    <button id="wfBtnSave" title="Save (Ctrl+S)"><i class="fas fa-save"></i></button>
                    <button id="wfBtnUndo" title="Undo"><i class="fas fa-undo"></i></button>
                    <button id="wfBtnRedo" title="Redo"><i class="fas fa-redo"></i></button>
                    <button id="wfBtnZoomIn" title="Zoom In"><i class="fas fa-search-plus"></i></button>
                    <button id="wfBtnZoomOut" title="Zoom Out"><i class="fas fa-search-minus"></i></button>
                    <button id="wfBtnFitView" title="Fit View"><i class="fas fa-expand"></i></button>
                    <button id="wfBtnExport" title="Export JSON"><i class="fas fa-file-export"></i></button>
                    <button id="wfBtnClear" title="Clear Canvas"><i class="fas fa-trash-alt"></i></button>
                </div>
                <div class="dib-wf-canvas">
                    <svg class="dib-wf-connections" xmlns="http://www.w3.org/2000/svg"></svg>
                </div>
            </div>

            <!-- Properties Panel -->
            <div class="dib-wf-properties">
                <div class="dib-wf-properties-header">
                    <h3><i class="fas fa-sliders-h"></i> Properties</h3>
                </div>
                <div class="dib-wf-properties-body">
                    <div style="text-align:center;padding:40px 20px;color:#9BADA3;">
                        <i class="fas fa-mouse-pointer" style="font-size:32px;margin-bottom:12px;display:block;"></i>
                        <p>Drag a component from the toolbox onto the canvas to begin building your workflow.</p>
                        <p style="font-size:12px;margin-top:16px;">Connect nodes by dragging from output ports (bottom/right) to input ports (top).</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ======================== TASK BOARD ======================== -->
    <div class="dib-card" style="margin-top:24px;">
        <div class="dib-card-header">
            <h3><i class="fas fa-tasks"></i> Task Board</h3>
            <div style="display:flex;gap:8px;">
                <select class="dib-form-control" style="width:150px;padding:6px 10px;font-size:13px;">
                    <option>All Tasks</option>
                    <option>My Tasks</option>
                    <option>Unassigned</option>
                </select>
                <button class="dib-btn dib-btn-primary" onclick="DIBTaskAllocation.showNewTaskModal()">
                    <i class="fas fa-plus"></i> New Task
                </button>
            </div>
        </div>
        <div id="dibTaskBoard">
            <!-- Populated by JS -->
        </div>
    </div>

    <!-- ======================== WORKFLOW DASHBOARD WIDGETS ======================== -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;margin-top:24px;">

        <!-- Active Workflows -->
        <div class="dib-card">
            <div class="dib-card-header">
                <h3><i class="fas fa-play-circle"></i> Active Workflows</h3>
            </div>
            <div style="text-align:center;padding:20px;">
                <div style="font-size:48px;font-weight:700;color:#005B3A;">12</div>
                <div style="color:#6B7C73;font-size:13px;">Currently Running</div>
            </div>
        </div>

        <!-- Pending Approvals -->
        <div class="dib-card">
            <div class="dib-card-header">
                <h3><i class="fas fa-hourglass-half"></i> Pending Approvals</h3>
            </div>
            <div style="text-align:center;padding:20px;">
                <div style="font-size:48px;font-weight:700;color:#F9A825;">5</div>
                <div style="color:#6B7C73;font-size:13px;">Awaiting Response</div>
            </div>
        </div>

        <!-- Completed Today -->
        <div class="dib-card">
            <div class="dib-card-header">
                <h3><i class="fas fa-check-double"></i> Completed Today</h3>
            </div>
            <div style="text-align:center;padding:20px;">
                <div style="font-size:48px;font-weight:700;color:#2E7D32;">8</div>
                <div style="color:#6B7C73;font-size:13px;">Tasks Finished</div>
            </div>
        </div>

        <!-- Overdue Tasks -->
        <div class="dib-card">
            <div class="dib-card-header">
                <h3><i class="fas fa-exclamation-triangle"></i> Overdue</h3>
            </div>
            <div style="text-align:center;padding:20px;">
                <div style="font-size:48px;font-weight:700;color:#D32F2F;">3</div>
                <div style="color:#6B7C73;font-size:13px;">Need Attention</div>
            </div>
        </div>
    </div>

</asp:Content>
