/* ============================================================
   DIB Workflow Designer - Drag & Drop Module
   SharePoint Server Subscription Edition
   ============================================================ */

var DIBWorkflowDesigner = (function () {
    'use strict';

    // ---- State ----
    var state = {
        nodes: [],
        connections: [],
        selectedNode: null,
        selectedConnection: null,
        dragState: null,       // { type: 'move'|'connect', nodeId, startPort, offsetX, offsetY }
        nextNodeId: 1,
        nextConnId: 1,
        zoom: 1,
        panX: 0,
        panY: 0,
        isDirty: false,
        workflowId: null,
        workflowName: 'Untitled Workflow'
    };

    // ---- Node Type Registry ----
    var nodeTypes = {
        start: { label: 'Start', icon: 'fa-play', category: 'Flow', color: 'start', ports: { out: ['bottom'] } },
        end: { label: 'End', icon: 'fa-stop', category: 'Flow', color: 'end', ports: { in: ['top'] } },
        task: { label: 'Task', icon: 'fa-clipboard-check', category: 'Actions', color: 'task', ports: { in: ['top'], out: ['bottom'] } },
        approval: { label: 'Approval', icon: 'fa-thumbs-up', category: 'Actions', color: 'approval', ports: { in: ['top'], out: ['bottom'] } },
        decision: { label: 'Decision', icon: 'fa-code-branch', category: 'Logic', color: 'decision', ports: { in: ['top'], out: ['bottom', 'right'] } },
        email: { label: 'Send Email', icon: 'fa-envelope', category: 'Actions', color: 'email', ports: { in: ['top'], out: ['bottom'] } },
        timer: { label: 'Wait / Timer', icon: 'fa-clock', category: 'Logic', color: 'timer', ports: { in: ['top'], out: ['bottom'] } },
        parallel: { label: 'Parallel Split', icon: 'fa-arrows-split-up-and-left', category: 'Logic', color: 'parallel', ports: { in: ['top'], out: ['bottom', 'right'] } },
        condition: { label: 'Condition', icon: 'fa-filter', category: 'Logic', color: 'condition', ports: { in: ['top'], out: ['bottom', 'right'] } },
        webhook: { label: 'Webhook', icon: 'fa-link', category: 'Integration', color: 'webhook', ports: { in: ['top'], out: ['bottom'] } }
    };

    // ---- DOM References ----
    var canvas, svgLayer, toolbox, propertiesPanel, canvasContainer;

    // ============================================================
    //  INITIALIZATION
    // ============================================================
    function init(options) {
        options = options || {};
        canvasContainer = document.querySelector('.dib-wf-canvas-container');
        canvas = document.querySelector('.dib-wf-canvas');
        svgLayer = document.querySelector('.dib-wf-connections');
        toolbox = document.querySelector('.dib-wf-toolbox-items');
        propertiesPanel = document.querySelector('.dib-wf-properties-body');

        if (!canvas) return;

        renderToolbox();
        bindCanvasEvents();
        bindToolbarEvents();
        bindKeyboardShortcuts();

        if (options.workflowId) {
            loadWorkflow(options.workflowId);
        }
    }

    // ============================================================
    //  TOOLBOX RENDERING
    // ============================================================
    function renderToolbox() {
        if (!toolbox) return;

        var categories = {};
        for (var type in nodeTypes) {
            var nt = nodeTypes[type];
            if (!categories[nt.category]) categories[nt.category] = [];
            categories[nt.category].push({ type: type, config: nt });
        }

        var html = '';
        for (var cat in categories) {
            html += '<div class="dib-wf-toolbox-category"><h4>' + escapeHtml(cat) + '</h4>';
            categories[cat].forEach(function (item) {
                html += '<div class="dib-wf-tool-item" draggable="true" data-node-type="' + item.type + '">';
                html += '<div class="dib-wf-tool-icon ' + item.config.color + '"><i class="fas ' + item.config.icon + '"></i></div>';
                html += '<span>' + escapeHtml(item.config.label) + '</span>';
                html += '</div>';
            });
            html += '</div>';
        }
        toolbox.innerHTML = html;

        // Bind drag events on toolbox items
        var items = toolbox.querySelectorAll('.dib-wf-tool-item');
        for (var i = 0; i < items.length; i++) {
            items[i].addEventListener('dragstart', onToolDragStart);
        }

        // Toolbox search
        var searchInput = document.querySelector('.dib-wf-toolbox-search input');
        if (searchInput) {
            searchInput.addEventListener('input', function () {
                var query = this.value.toLowerCase();
                var allItems = toolbox.querySelectorAll('.dib-wf-tool-item');
                for (var j = 0; j < allItems.length; j++) {
                    var text = allItems[j].textContent.toLowerCase();
                    allItems[j].style.display = text.indexOf(query) >= 0 ? '' : 'none';
                }
            });
        }
    }

    // ============================================================
    //  DRAG & DROP FROM TOOLBOX
    // ============================================================
    function onToolDragStart(e) {
        var nodeType = this.getAttribute('data-node-type');
        e.dataTransfer.setData('text/plain', nodeType);
        e.dataTransfer.effectAllowed = 'copy';
    }

    function bindCanvasEvents() {
        // Drop from toolbox
        canvas.addEventListener('dragover', function (e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        });

        canvas.addEventListener('drop', function (e) {
            e.preventDefault();
            var nodeType = e.dataTransfer.getData('text/plain');
            if (!nodeTypes[nodeType]) return;

            var rect = canvas.getBoundingClientRect();
            var x = (e.clientX - rect.left) / state.zoom;
            var y = (e.clientY - rect.top) / state.zoom;

            addNode(nodeType, x, y);
        });

        // Click on canvas to deselect
        canvas.addEventListener('click', function (e) {
            if (e.target === canvas || e.target.closest('.dib-wf-canvas') === canvas && !e.target.closest('.dib-wf-node')) {
                deselectAll();
            }
        });
    }

    // ============================================================
    //  NODE MANAGEMENT
    // ============================================================
    function addNode(type, x, y, properties) {
        var config = nodeTypes[type];
        if (!config) return null;

        var node = {
            id: 'node_' + state.nextNodeId++,
            type: type,
            x: Math.round(x),
            y: Math.round(y),
            label: config.label,
            description: '',
            assignee: null,
            dueDate: null,
            priority: 'medium',
            properties: properties || {}
        };

        state.nodes.push(node);
        renderNode(node);
        selectNode(node.id);
        markDirty();

        return node;
    }

    function renderNode(node) {
        var config = nodeTypes[node.type];
        var el = document.createElement('div');
        el.className = 'dib-wf-node';
        el.id = node.id;
        el.style.left = node.x + 'px';
        el.style.top = node.y + 'px';
        el.setAttribute('data-node-id', node.id);

        var portsHtml = '';
        var allPorts = [];
        if (config.ports.in) {
            config.ports.in.forEach(function (dir) {
                portsHtml += '<div class="dib-wf-port port-' + dir + '" data-port-dir="' + dir + '" data-port-type="in"></div>';
                allPorts.push({ dir: dir, type: 'in' });
            });
        }
        if (config.ports.out) {
            config.ports.out.forEach(function (dir) {
                portsHtml += '<div class="dib-wf-port port-' + dir + '" data-port-dir="' + dir + '" data-port-type="out"></div>';
                allPorts.push({ dir: dir, type: 'out' });
            });
        }

        var assigneeHtml = '';
        if (node.assignee) {
            var initials = getInitials(node.assignee);
            assigneeHtml = '<div class="assignee"><div class="assignee-avatar">' + escapeHtml(initials) + '</div>' + escapeHtml(node.assignee) + '</div>';
        }

        el.innerHTML =
            '<div class="dib-wf-node-header ' + config.color + '">' +
            '<i class="fas ' + config.icon + '"></i> ' + escapeHtml(node.label) +
            '</div>' +
            '<div class="dib-wf-node-body">' +
            (node.description ? '<p>' + escapeHtml(node.description) + '</p>' : '<p class="placeholder">Click to configure</p>') +
            assigneeHtml +
            '</div>' +
            portsHtml;

        canvas.appendChild(el);

        // Bind node events
        el.addEventListener('mousedown', onNodeMouseDown);
        el.addEventListener('click', function (e) {
            e.stopPropagation();
            selectNode(node.id);
        });

        // Bind port events
        var ports = el.querySelectorAll('.dib-wf-port');
        for (var i = 0; i < ports.length; i++) {
            ports[i].addEventListener('mousedown', onPortMouseDown);
        }
    }

    function updateNodeElement(node) {
        var el = document.getElementById(node.id);
        if (!el) return;

        el.style.left = node.x + 'px';
        el.style.top = node.y + 'px';

        var config = nodeTypes[node.type];
        var header = el.querySelector('.dib-wf-node-header');
        if (header) {
            header.innerHTML = '<i class="fas ' + config.icon + '"></i> ' + escapeHtml(node.label);
        }

        var body = el.querySelector('.dib-wf-node-body');
        if (body) {
            var assigneeHtml = '';
            if (node.assignee) {
                var initials = getInitials(node.assignee);
                assigneeHtml = '<div class="assignee"><div class="assignee-avatar">' + escapeHtml(initials) + '</div>' + escapeHtml(node.assignee) + '</div>';
            }
            body.innerHTML = (node.description ? '<p>' + escapeHtml(node.description) + '</p>' : '<p class="placeholder">Click to configure</p>') + assigneeHtml;
        }
    }

    function removeNode(nodeId) {
        // Remove connections
        state.connections = state.connections.filter(function (c) {
            return c.fromNode !== nodeId && c.toNode !== nodeId;
        });

        // Remove from state
        state.nodes = state.nodes.filter(function (n) { return n.id !== nodeId; });

        // Remove DOM
        var el = document.getElementById(nodeId);
        if (el) el.remove();

        renderConnections();
        deselectAll();
        markDirty();
    }

    function selectNode(nodeId) {
        deselectAll();
        var node = getNode(nodeId);
        if (!node) return;

        state.selectedNode = nodeId;
        var el = document.getElementById(nodeId);
        if (el) el.classList.add('selected');

        renderProperties(node);
    }

    function deselectAll() {
        state.selectedNode = null;
        state.selectedConnection = null;
        var allSelected = canvas.querySelectorAll('.selected');
        for (var i = 0; i < allSelected.length; i++) {
            allSelected[i].classList.remove('selected');
        }
        if (propertiesPanel) {
            propertiesPanel.innerHTML = '<div style="text-align:center;padding:40px 20px;color:var(--dib-text-light);"><i class="fas fa-mouse-pointer" style="font-size:32px;margin-bottom:12px;display:block;"></i><p>Select a node to view its properties</p></div>';
        }
    }

    // ============================================================
    //  NODE DRAGGING (MOVE)
    // ============================================================
    function onNodeMouseDown(e) {
        if (e.target.classList.contains('dib-wf-port')) return;
        e.preventDefault();

        var nodeEl = e.target.closest('.dib-wf-node');
        if (!nodeEl) return;

        var nodeId = nodeEl.getAttribute('data-node-id');
        var node = getNode(nodeId);
        if (!node) return;

        var rect = canvas.getBoundingClientRect();
        state.dragState = {
            type: 'move',
            nodeId: nodeId,
            offsetX: e.clientX - nodeEl.offsetLeft,
            offsetY: e.clientY - nodeEl.offsetTop
        };

        nodeEl.classList.add('dragging');
        document.addEventListener('mousemove', onNodeMouseMove);
        document.addEventListener('mouseup', onNodeMouseUp);
    }

    function onNodeMouseMove(e) {
        if (!state.dragState || state.dragState.type !== 'move') return;

        var nodeEl = document.getElementById(state.dragState.nodeId);
        if (!nodeEl) return;

        var x = e.clientX - state.dragState.offsetX;
        var y = e.clientY - state.dragState.offsetY;

        // Snap to grid (20px)
        x = Math.round(x / 20) * 20;
        y = Math.round(y / 20) * 20;

        nodeEl.style.left = x + 'px';
        nodeEl.style.top = y + 'px';

        var node = getNode(state.dragState.nodeId);
        if (node) {
            node.x = x;
            node.y = y;
        }

        renderConnections();
    }

    function onNodeMouseUp(e) {
        if (state.dragState && state.dragState.type === 'move') {
            var nodeEl = document.getElementById(state.dragState.nodeId);
            if (nodeEl) nodeEl.classList.remove('dragging');
            markDirty();
        }
        state.dragState = null;
        document.removeEventListener('mousemove', onNodeMouseMove);
        document.removeEventListener('mouseup', onNodeMouseUp);
    }

    // ============================================================
    //  PORT CONNECTIONS (DRAG TO CONNECT)
    // ============================================================
    function onPortMouseDown(e) {
        e.stopPropagation();
        e.preventDefault();

        var port = e.target;
        var nodeEl = port.closest('.dib-wf-node');
        var portType = port.getAttribute('data-port-type');

        if (portType !== 'out') return; // Only start connections from output ports

        var nodeId = nodeEl.getAttribute('data-node-id');
        var portDir = port.getAttribute('data-port-dir');

        state.dragState = {
            type: 'connect',
            fromNode: nodeId,
            fromPort: portDir,
            tempLine: null
        };

        // Create temporary SVG line
        if (svgLayer) {
            var line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            line.setAttribute('class', 'dib-wf-connection');
            line.setAttribute('stroke-dasharray', '5,5');
            svgLayer.appendChild(line);
            state.dragState.tempLine = line;
        }

        document.addEventListener('mousemove', onConnectMouseMove);
        document.addEventListener('mouseup', onConnectMouseUp);
    }

    function onConnectMouseMove(e) {
        if (!state.dragState || state.dragState.type !== 'connect') return;
        if (!state.dragState.tempLine) return;

        var fromNode = getNode(state.dragState.fromNode);
        var fromEl = document.getElementById(state.dragState.fromNode);
        if (!fromNode || !fromEl) return;

        var startPos = getPortPosition(fromEl, state.dragState.fromPort);
        var rect = canvas.getBoundingClientRect();
        var endX = e.clientX - rect.left;
        var endY = e.clientY - rect.top;

        var path = createCurvedPath(startPos.x, startPos.y, endX, endY);
        state.dragState.tempLine.setAttribute('d', path);
    }

    function onConnectMouseUp(e) {
        if (!state.dragState || state.dragState.type !== 'connect') return;

        // Remove temp line
        if (state.dragState.tempLine) {
            state.dragState.tempLine.remove();
        }

        // Check if dropped on a port
        var target = document.elementFromPoint(e.clientX, e.clientY);
        if (target && target.classList.contains('dib-wf-port') && target.getAttribute('data-port-type') === 'in') {
            var toNodeEl = target.closest('.dib-wf-node');
            var toNodeId = toNodeEl.getAttribute('data-node-id');
            var toPort = target.getAttribute('data-port-dir');

            if (toNodeId !== state.dragState.fromNode) {
                addConnection(state.dragState.fromNode, state.dragState.fromPort, toNodeId, toPort);
            }
        }

        state.dragState = null;
        document.removeEventListener('mousemove', onConnectMouseMove);
        document.removeEventListener('mouseup', onConnectMouseUp);
    }

    // ============================================================
    //  CONNECTION MANAGEMENT
    // ============================================================
    function addConnection(fromNode, fromPort, toNode, toPort, label) {
        // Check for duplicate
        var exists = state.connections.some(function (c) {
            return c.fromNode === fromNode && c.toNode === toNode;
        });
        if (exists) return;

        // Prevent self-connection
        if (fromNode === toNode) return;

        var conn = {
            id: 'conn_' + state.nextConnId++,
            fromNode: fromNode,
            fromPort: fromPort,
            toNode: toNode,
            toPort: toPort,
            label: label || ''
        };

        state.connections.push(conn);
        renderConnections();
        markDirty();
    }

    function removeConnection(connId) {
        state.connections = state.connections.filter(function (c) { return c.id !== connId; });
        renderConnections();
        markDirty();
    }

    function renderConnections() {
        if (!svgLayer) return;
        svgLayer.innerHTML = '';

        state.connections.forEach(function (conn) {
            var fromEl = document.getElementById(conn.fromNode);
            var toEl = document.getElementById(conn.toNode);
            if (!fromEl || !toEl) return;

            var startPos = getPortPosition(fromEl, conn.fromPort);
            var endPos = getPortPosition(toEl, conn.toPort);

            var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            path.setAttribute('d', createCurvedPath(startPos.x, startPos.y, endPos.x, endPos.y));
            path.setAttribute('class', 'dib-wf-connection');
            path.setAttribute('data-conn-id', conn.id);
            path.style.pointerEvents = 'stroke';

            path.addEventListener('click', function (e) {
                e.stopPropagation();
                if (confirm('Remove this connection?')) {
                    removeConnection(conn.id);
                }
            });

            svgLayer.appendChild(path);

            // Arrow marker
            var arrowSize = 8;
            var arrow = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
            arrow.setAttribute('points', '-' + arrowSize + ',-' + (arrowSize / 2) + ' 0,0 -' + arrowSize + ',' + (arrowSize / 2));
            arrow.setAttribute('fill', '#005B3A');
            arrow.setAttribute('transform', 'translate(' + endPos.x + ',' + endPos.y + ')');
            svgLayer.appendChild(arrow);

            // Connection label
            if (conn.label) {
                var midX = (startPos.x + endPos.x) / 2;
                var midY = (startPos.y + endPos.y) / 2;
                var text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                text.setAttribute('x', midX);
                text.setAttribute('y', midY - 8);
                text.setAttribute('class', 'dib-wf-connection-label');
                text.textContent = conn.label;
                svgLayer.appendChild(text);
            }
        });
    }

    // ============================================================
    //  PROPERTIES PANEL
    // ============================================================
    function renderProperties(node) {
        if (!propertiesPanel) return;
        var config = nodeTypes[node.type];

        var html = '';
        html += '<div class="dib-wf-prop-group"><label>Node Type</label>';
        html += '<input type="text" value="' + escapeAttr(config.label) + '" disabled /></div>';

        html += '<div class="dib-wf-prop-group"><label>Label</label>';
        html += '<input type="text" id="propLabel" value="' + escapeAttr(node.label) + '" /></div>';

        html += '<div class="dib-wf-prop-group"><label>Description</label>';
        html += '<textarea id="propDescription" rows="3">' + escapeHtml(node.description || '') + '</textarea></div>';

        if (node.type === 'task' || node.type === 'approval') {
            html += '<div class="dib-wf-prop-group"><label>Assignee</label>';
            html += '<input type="text" id="propAssignee" value="' + escapeAttr(node.assignee || '') + '" placeholder="Enter name or email" /></div>';

            html += '<div class="dib-wf-prop-group"><label>Due Date</label>';
            html += '<input type="date" id="propDueDate" value="' + escapeAttr(node.dueDate || '') + '" /></div>';

            html += '<div class="dib-wf-prop-group"><label>Priority</label>';
            html += '<select id="propPriority">';
            html += '<option value="low"' + (node.priority === 'low' ? ' selected' : '') + '>Low</option>';
            html += '<option value="medium"' + (node.priority === 'medium' ? ' selected' : '') + '>Medium</option>';
            html += '<option value="high"' + (node.priority === 'high' ? ' selected' : '') + '>High</option>';
            html += '</select></div>';
        }

        if (node.type === 'email') {
            html += '<div class="dib-wf-prop-group"><label>To (Email)</label>';
            html += '<input type="text" id="propEmailTo" value="' + escapeAttr(node.properties.emailTo || '') + '" /></div>';

            html += '<div class="dib-wf-prop-group"><label>Subject</label>';
            html += '<input type="text" id="propEmailSubject" value="' + escapeAttr(node.properties.emailSubject || '') + '" /></div>';

            html += '<div class="dib-wf-prop-group"><label>Body</label>';
            html += '<textarea id="propEmailBody" rows="4">' + escapeHtml(node.properties.emailBody || '') + '</textarea></div>';
        }

        if (node.type === 'timer') {
            html += '<div class="dib-wf-prop-group"><label>Wait Duration (hours)</label>';
            html += '<input type="number" id="propTimerHours" value="' + escapeAttr(node.properties.timerHours || '24') + '" min="1" /></div>';
        }

        if (node.type === 'condition' || node.type === 'decision') {
            html += '<div class="dib-wf-prop-group"><label>Condition Expression</label>';
            html += '<textarea id="propCondition" rows="3">' + escapeHtml(node.properties.condition || '') + '</textarea></div>';

            html += '<div class="dib-wf-prop-group"><label>True Label</label>';
            html += '<input type="text" id="propTrueLabel" value="' + escapeAttr(node.properties.trueLabel || 'Yes') + '" /></div>';

            html += '<div class="dib-wf-prop-group"><label>False Label</label>';
            html += '<input type="text" id="propFalseLabel" value="' + escapeAttr(node.properties.falseLabel || 'No') + '" /></div>';
        }

        html += '<div style="margin-top:20px;">';
        html += '<button class="dib-btn dib-btn-primary" onclick="DIBWorkflowDesigner.applyProperties()" style="width:100%;margin-bottom:8px;">Apply Changes</button>';
        html += '<button class="dib-btn dib-btn-danger" onclick="DIBWorkflowDesigner.deleteSelected()" style="width:100%;">Delete Node</button>';
        html += '</div>';

        propertiesPanel.innerHTML = html;
    }

    function applyProperties() {
        var node = getNode(state.selectedNode);
        if (!node) return;

        var label = document.getElementById('propLabel');
        var description = document.getElementById('propDescription');
        var assignee = document.getElementById('propAssignee');
        var dueDate = document.getElementById('propDueDate');
        var priority = document.getElementById('propPriority');

        if (label) node.label = label.value;
        if (description) node.description = description.value;
        if (assignee) node.assignee = assignee.value;
        if (dueDate) node.dueDate = dueDate.value;
        if (priority) node.priority = priority.value;

        // Type-specific properties
        var emailTo = document.getElementById('propEmailTo');
        var emailSubject = document.getElementById('propEmailSubject');
        var emailBody = document.getElementById('propEmailBody');
        var timerHours = document.getElementById('propTimerHours');
        var condition = document.getElementById('propCondition');
        var trueLabel = document.getElementById('propTrueLabel');
        var falseLabel = document.getElementById('propFalseLabel');

        if (emailTo) node.properties.emailTo = emailTo.value;
        if (emailSubject) node.properties.emailSubject = emailSubject.value;
        if (emailBody) node.properties.emailBody = emailBody.value;
        if (timerHours) node.properties.timerHours = timerHours.value;
        if (condition) node.properties.condition = condition.value;
        if (trueLabel) node.properties.trueLabel = trueLabel.value;
        if (falseLabel) node.properties.falseLabel = falseLabel.value;

        updateNodeElement(node);
        renderConnections();
        markDirty();
    }

    function deleteSelected() {
        if (state.selectedNode) {
            if (confirm('Delete this node and all its connections?')) {
                removeNode(state.selectedNode);
            }
        }
    }

    // ============================================================
    //  TOOLBAR ACTIONS
    // ============================================================
    function bindToolbarEvents() {
        bindToolbarBtn('wfBtnSave', saveWorkflow);
        bindToolbarBtn('wfBtnUndo', undo);
        bindToolbarBtn('wfBtnRedo', redo);
        bindToolbarBtn('wfBtnZoomIn', function () { setZoom(state.zoom + 0.1); });
        bindToolbarBtn('wfBtnZoomOut', function () { setZoom(state.zoom - 0.1); });
        bindToolbarBtn('wfBtnFitView', fitView);
        bindToolbarBtn('wfBtnClear', clearCanvas);
        bindToolbarBtn('wfBtnExport', exportWorkflow);
    }

    function bindToolbarBtn(id, handler) {
        var btn = document.getElementById(id);
        if (btn) btn.addEventListener('click', handler);
    }

    function setZoom(level) {
        state.zoom = Math.max(0.3, Math.min(2, level));
        if (canvas) {
            canvas.style.transform = 'scale(' + state.zoom + ')';
            canvas.style.transformOrigin = '0 0';
        }
    }

    function fitView() {
        if (state.nodes.length === 0) return;
        setZoom(1);
        // Scroll to first node
        var firstNode = state.nodes[0];
        if (canvasContainer) {
            canvasContainer.scrollLeft = Math.max(0, firstNode.x - 100);
            canvasContainer.scrollTop = Math.max(0, firstNode.y - 100);
        }
    }

    function clearCanvas() {
        if (!confirm('Clear the entire canvas? This cannot be undone.')) return;
        state.nodes = [];
        state.connections = [];
        var nodeEls = canvas.querySelectorAll('.dib-wf-node');
        for (var i = 0; i < nodeEls.length; i++) {
            nodeEls[i].remove();
        }
        if (svgLayer) svgLayer.innerHTML = '';
        deselectAll();
        markDirty();
    }

    // ============================================================
    //  KEYBOARD SHORTCUTS
    // ============================================================
    function bindKeyboardShortcuts() {
        document.addEventListener('keydown', function (e) {
            // Delete key - remove selected node
            if (e.key === 'Delete' && state.selectedNode) {
                deleteSelected();
            }
            // Ctrl+S - save
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                saveWorkflow();
            }
            // Escape - deselect
            if (e.key === 'Escape') {
                deselectAll();
            }
        });
    }

    // ============================================================
    //  SAVE / LOAD (SharePoint REST API)
    // ============================================================
    function saveWorkflow() {
        var data = {
            name: state.workflowName,
            nodes: state.nodes,
            connections: state.connections,
            metadata: {
                lastModified: new Date().toISOString(),
                version: '1.0'
            }
        };

        var listName = 'DIBWorkflowDefinitions';
        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items";

        var payload = {
            __metadata: { type: getListItemType(listName) },
            Title: state.workflowName,
            WorkflowJSON: JSON.stringify(data),
            Status: 'Draft'
        };

        if (state.workflowId) {
            // Update existing
            url += '(' + state.workflowId + ')';
            spRequest(url, 'MERGE', payload, function () {
                showToast('Workflow saved successfully', 'success');
                state.isDirty = false;
            });
        } else {
            // Create new
            spRequest(url, 'POST', payload, function (response) {
                state.workflowId = response.d.Id;
                showToast('Workflow created successfully', 'success');
                state.isDirty = false;
            });
        }
    }

    function loadWorkflow(id) {
        var listName = 'DIBWorkflowDefinitions';
        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items(" + parseInt(id, 10) + ")";

        spRequest(url, 'GET', null, function (response) {
            var data = JSON.parse(response.d.WorkflowJSON);
            state.workflowId = id;
            state.workflowName = data.name;
            state.nodes = data.nodes || [];
            state.connections = data.connections || [];

            // Re-calculate next IDs
            state.nextNodeId = 1;
            state.nextConnId = 1;
            state.nodes.forEach(function (n) {
                var num = parseInt(n.id.replace('node_', ''), 10);
                if (num >= state.nextNodeId) state.nextNodeId = num + 1;
            });
            state.connections.forEach(function (c) {
                var num = parseInt(c.id.replace('conn_', ''), 10);
                if (num >= state.nextConnId) state.nextConnId = num + 1;
            });

            // Render
            state.nodes.forEach(function (n) { renderNode(n); });
            renderConnections();
        });
    }

    function exportWorkflow() {
        var data = {
            name: state.workflowName,
            nodes: state.nodes,
            connections: state.connections,
            exportedAt: new Date().toISOString()
        };

        var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = (state.workflowName || 'workflow') + '.json';
        a.click();
        URL.revokeObjectURL(a.href);
    }

    // ============================================================
    //  SHAREPOINT REST HELPER
    // ============================================================
    function spRequest(url, method, data, success, error) {
        var headers = {
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/json;odata=verbose'
        };

        if (method === 'MERGE' || method === 'DELETE') {
            headers['IF-MATCH'] = '*';
            headers['X-HTTP-Method'] = method;
            method = 'POST';
        }

        // Get request digest
        var digest = document.getElementById('__REQUESTDIGEST');
        if (digest) {
            headers['X-RequestDigest'] = digest.value;
        }

        var xhr = new XMLHttpRequest();
        xhr.open(method, url, true);

        for (var h in headers) {
            xhr.setRequestHeader(h, headers[h]);
        }

        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                var response = xhr.responseText ? JSON.parse(xhr.responseText) : null;
                if (success) success(response);
            } else {
                console.error('SP REST Error:', xhr.status, xhr.responseText);
                if (error) error(xhr);
                else showToast('Error saving workflow. Please try again.', 'error');
            }
        };

        xhr.onerror = function () {
            console.error('Network error');
            if (error) error(xhr);
        };

        xhr.send(data ? JSON.stringify(data) : null);
    }

    function getListItemType(listName) {
        return 'SP.Data.' + listName.charAt(0).toUpperCase() + listName.slice(1).replace(/\s/g, '_x0020_') + 'ListItem';
    }

    // ============================================================
    //  UTILITY FUNCTIONS
    // ============================================================
    function getNode(id) {
        for (var i = 0; i < state.nodes.length; i++) {
            if (state.nodes[i].id === id) return state.nodes[i];
        }
        return null;
    }

    function getPortPosition(nodeEl, portDir) {
        var rect = nodeEl.getBoundingClientRect();
        var canvasRect = canvas.getBoundingClientRect();
        var x, y;

        switch (portDir) {
            case 'top':
                x = nodeEl.offsetLeft + nodeEl.offsetWidth / 2;
                y = nodeEl.offsetTop;
                break;
            case 'bottom':
                x = nodeEl.offsetLeft + nodeEl.offsetWidth / 2;
                y = nodeEl.offsetTop + nodeEl.offsetHeight;
                break;
            case 'left':
                x = nodeEl.offsetLeft;
                y = nodeEl.offsetTop + nodeEl.offsetHeight / 2;
                break;
            case 'right':
                x = nodeEl.offsetLeft + nodeEl.offsetWidth;
                y = nodeEl.offsetTop + nodeEl.offsetHeight / 2;
                break;
        }

        return { x: x, y: y };
    }

    function createCurvedPath(x1, y1, x2, y2) {
        var midY = (y1 + y2) / 2;
        return 'M ' + x1 + ' ' + y1 + ' C ' + x1 + ' ' + midY + ', ' + x2 + ' ' + midY + ', ' + x2 + ' ' + y2;
    }

    function markDirty() {
        state.isDirty = true;
    }

    function undo() { /* Placeholder for undo stack */ }
    function redo() { /* Placeholder for redo stack */ }

    function getInitials(name) {
        if (!name) return '?';
        var parts = name.split(/[\s@]+/);
        return (parts[0][0] + (parts.length > 1 ? parts[1][0] : '')).toUpperCase();
    }

    function escapeHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    function escapeAttr(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function showToast(message, type) {
        var toast = document.createElement('div');
        toast.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:14px 24px;border-radius:8px;color:#fff;font-size:14px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,0.2);transition:opacity 0.3s;';
        toast.style.background = type === 'success' ? '#2E7D32' : type === 'error' ? '#D32F2F' : '#1565C0';
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(function () { toast.style.opacity = '0'; }, 2500);
        setTimeout(function () { toast.remove(); }, 3000);
    }

    // ============================================================
    //  PUBLIC API
    // ============================================================
    return {
        init: init,
        addNode: addNode,
        addConnection: addConnection,
        saveWorkflow: saveWorkflow,
        loadWorkflow: loadWorkflow,
        exportWorkflow: exportWorkflow,
        applyProperties: applyProperties,
        deleteSelected: deleteSelected,
        clearCanvas: clearCanvas,
        getState: function () { return state; }
    };

})();

// Auto-init when SP scripts are loaded
if (typeof SP !== 'undefined' && SP.SOD) {
    SP.SOD.executeOrDelayUntilScriptLoaded(function () {
        DIBWorkflowDesigner.init();
    }, 'sp.js');
} else if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
        DIBWorkflowDesigner.init();
    });
} else {
    DIBWorkflowDesigner.init();
}
