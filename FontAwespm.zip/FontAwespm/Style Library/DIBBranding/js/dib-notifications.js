/* ============================================================
   DIB Notifications Module
   Real-time notification system for workflow events
   SharePoint Server Subscription Edition
   ============================================================ */

var DIBNotifications = (function () {
    'use strict';

    var state = {
        notifications: [],
        unreadCount: 0,
        panelOpen: false,
        pollInterval: null,
        pollIntervalMs: 30000, // 30 seconds
        listName: 'DIBWorkflowNotifications',
        currentUserId: null
    };

    // ============================================================
    //  INITIALIZATION
    // ============================================================
    function init(options) {
        options = options || {};
        state.listName = options.listName || state.listName;
        state.pollIntervalMs = options.pollIntervalMs || state.pollIntervalMs;

        getCurrentUserId(function () {
            loadNotifications();
            startPolling();
        });

        // Close panel when clicking outside
        document.addEventListener('click', function (e) {
            var panel = document.getElementById('dibNotificationPanel');
            var bell = document.getElementById('dibNotificationBell');
            if (panel && state.panelOpen) {
                if (!panel.contains(e.target) && !bell.contains(e.target)) {
                    closePanel();
                }
            }
        });
    }

    // ============================================================
    //  NOTIFICATION PANEL
    // ============================================================
    function togglePanel() {
        if (state.panelOpen) {
            closePanel();
        } else {
            openPanel();
        }
    }

    function openPanel() {
        var panel = document.getElementById('dibNotificationPanel');
        if (panel) {
            panel.style.display = 'block';
            state.panelOpen = true;
            renderNotificationList();
        }
    }

    function closePanel() {
        var panel = document.getElementById('dibNotificationPanel');
        if (panel) {
            panel.style.display = 'none';
            state.panelOpen = false;
        }
    }

    function renderNotificationList() {
        var list = document.getElementById('dibNotificationList');
        if (!list) return;

        if (state.notifications.length === 0) {
            list.innerHTML = '<div style="text-align:center;padding:40px 20px;color:#9BADA3;"><i class="fas fa-bell-slash" style="font-size:32px;margin-bottom:12px;display:block;"></i><p>No notifications</p></div>';
            return;
        }

        var html = '';
        state.notifications.forEach(function (notif) {
            var iconClass = getIconClass(notif.type);
            var timeAgo = getTimeAgo(notif.timestamp);

            html += '<div class="dib-notification-item' + (notif.read ? '' : ' unread') + '" data-notif-id="' + notif.id + '" onclick="DIBNotifications.onNotificationClick(\'' + notif.id + '\')">';
            html += '<div class="dib-notification-icon ' + notif.type + '"><i class="fas ' + iconClass + '"></i></div>';
            html += '<div class="dib-notification-content">';
            html += '<h4>' + escapeHtml(notif.title) + '</h4>';
            html += '<p>' + escapeHtml(notif.message) + '</p>';
            html += '</div>';
            html += '<span class="dib-notification-time">' + timeAgo + '</span>';
            html += '</div>';
        });

        list.innerHTML = html;
    }

    function updateBadge() {
        var badge = document.getElementById('dibNotificationBadge');
        if (!badge) return;

        state.unreadCount = state.notifications.filter(function (n) { return !n.read; }).length;
        badge.textContent = state.unreadCount;
        badge.style.display = state.unreadCount > 0 ? 'flex' : 'none';
    }

    // ============================================================
    //  NOTIFICATION ACTIONS
    // ============================================================
    function addNotification(data) {
        var notification = {
            id: 'notif_' + Date.now(),
            type: data.type || 'task',            // task, approval, complete, alert
            title: data.title || 'Notification',
            message: data.message || '',
            read: false,
            timestamp: new Date().toISOString(),
            taskId: data.taskId || null,
            workflowId: data.workflowId || null,
            link: data.link || null
        };

        state.notifications.unshift(notification);
        updateBadge();

        if (state.panelOpen) {
            renderNotificationList();
        }

        // Save to SharePoint
        saveNotificationToSP(notification);

        // Show desktop notification if supported
        showDesktopNotification(notification);

        // Show toast
        showToast(notification.title, notification.type);

        // Send email notification
        sendEmailForNotification(notification, data);

        return notification;
    }

    function onNotificationClick(notifId) {
        var notif = getNotification(notifId);
        if (!notif) return;

        // Mark as read
        notif.read = true;
        updateBadge();
        renderNotificationList();
        markReadInSP(notifId);

        // Navigate to linked item
        if (notif.link) {
            window.location.href = notif.link;
        }
    }

    function markAllRead() {
        state.notifications.forEach(function (n) {
            if (!n.read) {
                n.read = true;
                markReadInSP(n.id);
            }
        });
        state.unreadCount = 0;
        updateBadge();
        renderNotificationList();
    }

    function clearAll() {
        state.notifications = [];
        state.unreadCount = 0;
        updateBadge();
        renderNotificationList();
    }

    // ============================================================
    //  EMAIL NOTIFICATION BRIDGE
    //  Routes in-app notifications to email via DIBEmailNotifications
    // ============================================================
    function sendEmailForNotification(notification, originalData) {
        if (typeof DIBEmailNotifications === 'undefined') return;

        var recipientEmail = originalData.recipientEmail || null;
        var recipientName = originalData.recipientName || null;

        // Map notification type to email template
        var templateMap = {
            'task':     'taskAssigned',
            'approval': 'approvalRequired',
            'complete': 'workflowCompleted',
            'alert':    'taskOverdue'
        };

        // Use explicit template if provided, otherwise map from type
        var templateName = originalData.emailTemplate || templateMap[notification.type];
        if (!templateName) return;

        var emailData = {
            taskTitle: originalData.taskTitle || notification.title,
            workflowName: originalData.workflowName || notification.title,
            description: originalData.description || notification.message,
            priority: originalData.priority || 'medium',
            dueDate: originalData.dueDate || '',
            assignedBy: originalData.assignedBy || '',
            assigneeName: originalData.assigneeName || recipientName || '',
            oldStatus: originalData.oldStatus || '',
            newStatus: originalData.newStatus || '',
            updatedBy: originalData.updatedBy || '',
            requestedBy: originalData.requestedBy || '',
            decision: originalData.decision || '',
            approverName: originalData.approverName || '',
            comments: originalData.comments || '',
            initiatedBy: originalData.initiatedBy || '',
            commenterName: originalData.commenterName || '',
            comment: originalData.comment || '',
            taskUrl: originalData.taskUrl || notification.link || '',
            workflowUrl: originalData.workflowUrl || notification.link || '',
            approvalUrl: originalData.approvalUrl || notification.link || '',
            daysOverdue: originalData.daysOverdue || '',
            status: originalData.status || '',
            duration: originalData.duration || ''
        };

        // Resolve recipient and send
        if (recipientEmail) {
            DIBEmailNotifications.sendTemplatedEmail(templateName, recipientEmail, emailData);
        } else if (recipientName) {
            DIBEmailNotifications.resolveUserEmail(recipientName, function (email) {
                if (email) {
                    DIBEmailNotifications.sendTemplatedEmail(templateName, email, emailData);
                }
            });
        }
    }

    // ============================================================
    //  DESKTOP NOTIFICATIONS
    // ============================================================
    function showDesktopNotification(notif) {
        if (!('Notification' in window)) return;

        if (Notification.permission === 'granted') {
            createDesktopNotif(notif);
        } else if (Notification.permission !== 'denied') {
            Notification.requestPermission(function (permission) {
                if (permission === 'granted') {
                    createDesktopNotif(notif);
                }
            });
        }
    }

    function createDesktopNotif(notif) {
        var n = new Notification('DIB Workflow - ' + notif.title, {
            body: notif.message,
            icon: _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl + '/Style Library/DIBBranding/images/dib-logo.png' : '',
            tag: notif.id
        });

        n.onclick = function () {
            window.focus();
            onNotificationClick(notif.id);
            n.close();
        };

        setTimeout(function () { n.close(); }, 5000);
    }

    // ============================================================
    //  TOAST NOTIFICATIONS (IN-PAGE)
    // ============================================================
    function showToast(message, type) {
        var colors = {
            task: '#1565C0',
            approval: '#F9A825',
            complete: '#2E7D32',
            alert: '#D32F2F',
            success: '#2E7D32',
            error: '#D32F2F',
            info: '#1565C0'
        };

        var icons = {
            task: 'fa-clipboard-check',
            approval: 'fa-thumbs-up',
            complete: 'fa-check-circle',
            alert: 'fa-exclamation-triangle',
            success: 'fa-check-circle',
            error: 'fa-times-circle',
            info: 'fa-info-circle'
        };

        var toast = document.createElement('div');
        toast.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:14px 24px 14px 20px;border-radius:8px;color:#fff;font-size:14px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,0.2);display:flex;align-items:center;gap:10px;max-width:400px;animation:dibToastIn 0.3s ease;';
        toast.style.background = colors[type] || colors.info;
        toast.innerHTML = '<i class="fas ' + (icons[type] || icons.info) + '"></i> ' + escapeHtml(message);

        // Add CSS animation
        if (!document.getElementById('dibToastStyles')) {
            var style = document.createElement('style');
            style.id = 'dibToastStyles';
            style.textContent = '@keyframes dibToastIn{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}@keyframes dibToastOut{from{transform:translateY(0);opacity:1}to{transform:translateY(20px);opacity:0}}';
            document.head.appendChild(style);
        }

        document.body.appendChild(toast);

        setTimeout(function () {
            toast.style.animation = 'dibToastOut 0.3s ease forwards';
        }, 3000);
        setTimeout(function () { toast.remove(); }, 3300);
    }

    // ============================================================
    //  POLLING FOR NEW NOTIFICATIONS
    // ============================================================
    function startPolling() {
        if (state.pollInterval) clearInterval(state.pollInterval);
        state.pollInterval = setInterval(function () {
            loadNotifications();
        }, state.pollIntervalMs);
    }

    function stopPolling() {
        if (state.pollInterval) {
            clearInterval(state.pollInterval);
            state.pollInterval = null;
        }
    }

    // ============================================================
    //  SHAREPOINT INTEGRATION
    // ============================================================
    function loadNotifications() {
        if (!state.currentUserId) return;

        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + state.listName + "')/items";
        url += "?$filter=RecipientId eq " + state.currentUserId;
        url += "&$orderby=Created desc&$top=50";

        spGet(url, function (data) {
            state.notifications = (data.d.results || []).map(function (item) {
                return {
                    id: 'notif_' + item.Id,
                    spId: item.Id,
                    type: item.NotificationType || 'task',
                    title: item.Title || '',
                    message: item.Message || '',
                    read: item.IsRead || false,
                    timestamp: item.Created,
                    taskId: item.RelatedTaskId || null,
                    workflowId: item.RelatedWorkflowId || null,
                    link: item.LinkUrl || null
                };
            });

            updateBadge();
            if (state.panelOpen) {
                renderNotificationList();
            }
        });
    }

    function saveNotificationToSP(notif) {
        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + state.listName + "')/items";

        var payload = {
            __metadata: { type: getListItemType(state.listName) },
            Title: notif.title,
            Message: notif.message,
            NotificationType: notif.type,
            IsRead: false,
            RelatedTaskId: notif.taskId,
            RelatedWorkflowId: notif.workflowId,
            LinkUrl: notif.link
        };

        spPost(url, payload);
    }

    function markReadInSP(notifId) {
        var notif = getNotification(notifId);
        if (!notif || !notif.spId) return;

        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + state.listName + "')/items(" + notif.spId + ")";

        var payload = {
            __metadata: { type: getListItemType(state.listName) },
            IsRead: true
        };

        spMerge(url, payload);
    }

    function getCurrentUserId(callback) {
        if (_spPageContextInfo && _spPageContextInfo.userId) {
            state.currentUserId = _spPageContextInfo.userId;
            if (callback) callback();
            return;
        }

        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        spGet(siteUrl + '/_api/web/currentuser', function (data) {
            state.currentUserId = data.d.Id;
            if (callback) callback();
        }, function () {
            state.currentUserId = 0;
            if (callback) callback();
        });
    }

    // ============================================================
    //  SP REST HELPERS
    // ============================================================
    function getDigest() {
        var el = document.getElementById('__REQUESTDIGEST');
        return el ? el.value : '';
    }

    function spGet(url, success, error) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                success(JSON.parse(xhr.responseText));
            } else {
                if (error) error(xhr);
            }
        };
        xhr.onerror = function () { if (error) error(xhr); };
        xhr.send();
    }

    function spPost(url, data, success) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('Content-Type', 'application/json;odata=verbose');
        xhr.setRequestHeader('X-RequestDigest', getDigest());
        xhr.onload = function () {
            if (success && xhr.status >= 200 && xhr.status < 300) {
                success(JSON.parse(xhr.responseText));
            }
        };
        xhr.send(JSON.stringify(data));
    }

    function spMerge(url, data, success) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('Content-Type', 'application/json;odata=verbose');
        xhr.setRequestHeader('X-RequestDigest', getDigest());
        xhr.setRequestHeader('IF-MATCH', '*');
        xhr.setRequestHeader('X-HTTP-Method', 'MERGE');
        xhr.onload = function () { if (success) success(); };
        xhr.send(JSON.stringify(data));
    }

    function getListItemType(listName) {
        return 'SP.Data.' + listName.charAt(0).toUpperCase() + listName.slice(1).replace(/\s/g, '_x0020_') + 'ListItem';
    }

    // ============================================================
    //  UTILITY
    // ============================================================
    function getNotification(id) {
        for (var i = 0; i < state.notifications.length; i++) {
            if (state.notifications[i].id === id) return state.notifications[i];
        }
        return null;
    }

    function getIconClass(type) {
        var icons = {
            task: 'fa-clipboard-check',
            approval: 'fa-thumbs-up',
            complete: 'fa-check-circle',
            alert: 'fa-exclamation-triangle'
        };
        return icons[type] || 'fa-bell';
    }

    function getTimeAgo(timestamp) {
        if (!timestamp) return '';
        var now = new Date();
        var then = new Date(timestamp);
        var diffMs = now - then;
        var diffMins = Math.floor(diffMs / 60000);
        var diffHours = Math.floor(diffMs / 3600000);
        var diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return diffMins + 'm ago';
        if (diffHours < 24) return diffHours + 'h ago';
        if (diffDays < 7) return diffDays + 'd ago';
        return then.toLocaleDateString();
    }

    function escapeHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    // ============================================================
    //  PUBLIC API
    // ============================================================
    return {
        init: init,
        togglePanel: togglePanel,
        addNotification: addNotification,
        onNotificationClick: onNotificationClick,
        markAllRead: markAllRead,
        clearAll: clearAll,
        showToast: showToast,
        getState: function () { return state; }
    };

})();

// Auto-init
if (typeof SP !== 'undefined' && SP.SOD) {
    SP.SOD.executeOrDelayUntilScriptLoaded(function () {
        DIBNotifications.init();
    }, 'sp.js');
} else if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
        DIBNotifications.init();
    });
} else {
    DIBNotifications.init();
}
