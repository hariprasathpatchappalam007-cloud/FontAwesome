/* ============================================================
   DIB Task Allocation Module
   Kanban board with drag-and-drop task management
   SharePoint Server Subscription Edition
   ============================================================ */

var DIBTaskAllocation = (function () {
    'use strict';

    var state = {
        tasks: [],
        columns: [
            { id: 'todo', label: 'To Do', icon: 'fa-clipboard-list' },
            { id: 'in-progress', label: 'In Progress', icon: 'fa-spinner' },
            { id: 'review', label: 'Under Review', icon: 'fa-search' },
            { id: 'done', label: 'Completed', icon: 'fa-check-circle' }
        ],
        draggedTask: null,
        currentUser: null,
        listName: 'DIBWorkflowTasks'
    };

    // ============================================================
    //  INITIALIZATION
    // ============================================================
    function init(options) {
        options = options || {};
        state.listName = options.listName || state.listName;

        getCurrentUser(function () {
            loadTasks(function () {
                renderBoard();
                bindEvents();
            });
        });
    }

    // ============================================================
    //  RENDER BOARD
    // ============================================================
    function renderBoard() {
        var container = document.getElementById('dibTaskBoard');
        if (!container) return;

        var html = '<div class="dib-task-board">';

        state.columns.forEach(function (col) {
            var colTasks = state.tasks.filter(function (t) { return t.status === col.id; });

            html += '<div class="dib-task-column ' + col.id + '" data-column="' + col.id + '">';
            html += '<div class="dib-task-column-header">';
            html += '<h3><i class="fas ' + col.icon + '"></i> ' + escapeHtml(col.label) + '</h3>';
            html += '<span class="dib-task-column-count">' + colTasks.length + '</span>';
            html += '</div>';
            html += '<div class="dib-task-column-body" data-column="' + col.id + '">';

            colTasks.forEach(function (task) {
                html += renderTaskCard(task);
            });

            html += '</div></div>';
        });

        html += '</div>';

        // Add new task button
        html += '<div style="margin-top:16px;">';
        html += '<button class="dib-btn dib-btn-primary" onclick="DIBTaskAllocation.showNewTaskModal()"><i class="fas fa-plus"></i> New Task</button>';
        html += '</div>';

        container.innerHTML = html;
        bindDragDropEvents();
    }

    function renderTaskCard(task) {
        var html = '';
        html += '<div class="dib-task-card" draggable="true" data-task-id="' + task.id + '">';
        html += '<div class="dib-task-card-priority ' + task.priority + '"></div>';

        // Tags
        if (task.tags && task.tags.length > 0) {
            html += '<div class="dib-task-card-tags">';
            task.tags.forEach(function (tag) {
                html += '<span class="dib-task-tag ' + tag.toLowerCase() + '">' + escapeHtml(tag) + '</span>';
            });
            html += '</div>';
        }

        html += '<h4>' + escapeHtml(task.title) + '</h4>';

        if (task.description) {
            html += '<p>' + escapeHtml(truncate(task.description, 80)) + '</p>';
        }

        html += '<div class="dib-task-card-meta">';

        // Assignees
        html += '<div class="dib-task-card-assignees">';
        if (task.assignees) {
            task.assignees.forEach(function (user) {
                html += '<div class="dib-task-card-avatar" title="' + escapeAttr(user.name) + '">' + getInitials(user.name) + '</div>';
            });
        }
        html += '</div>';

        // Due date
        if (task.dueDate) {
            var isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'done';
            html += '<div class="dib-task-card-due' + (isOverdue ? ' overdue' : '') + '">';
            html += '<i class="fas fa-calendar-alt"></i> ' + formatDate(task.dueDate);
            html += '</div>';
        }

        html += '</div>';
        html += '</div>';

        return html;
    }

    // ============================================================
    //  DRAG & DROP FOR TASK CARDS
    // ============================================================
    function bindDragDropEvents() {
        // Task card drag events
        var cards = document.querySelectorAll('.dib-task-card');
        for (var i = 0; i < cards.length; i++) {
            cards[i].addEventListener('dragstart', onTaskDragStart);
            cards[i].addEventListener('dragend', onTaskDragEnd);
            cards[i].addEventListener('click', onTaskClick);
        }

        // Column drop zones
        var columns = document.querySelectorAll('.dib-task-column-body');
        for (var j = 0; j < columns.length; j++) {
            columns[j].addEventListener('dragover', onColumnDragOver);
            columns[j].addEventListener('dragleave', onColumnDragLeave);
            columns[j].addEventListener('drop', onColumnDrop);
        }
    }

    function onTaskDragStart(e) {
        var taskId = this.getAttribute('data-task-id');
        state.draggedTask = taskId;
        e.dataTransfer.setData('text/plain', taskId);
        e.dataTransfer.effectAllowed = 'move';
        this.classList.add('dragging');
    }

    function onTaskDragEnd(e) {
        this.classList.remove('dragging');
        state.draggedTask = null;
        // Remove all drag-over highlights
        var cols = document.querySelectorAll('.dib-task-column-body');
        for (var i = 0; i < cols.length; i++) {
            cols[i].classList.remove('drag-over');
        }
    }

    function onColumnDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        this.classList.add('drag-over');
    }

    function onColumnDragLeave(e) {
        this.classList.remove('drag-over');
    }

    function onColumnDrop(e) {
        e.preventDefault();
        this.classList.remove('drag-over');

        var taskId = e.dataTransfer.getData('text/plain');
        var newStatus = this.getAttribute('data-column');

        if (!taskId || !newStatus) return;

        moveTask(taskId, newStatus);
    }

    function moveTask(taskId, newStatus) {
        var task = getTask(taskId);
        if (!task) return;

        var oldStatus = task.status;
        if (oldStatus === newStatus) return;

        task.status = newStatus;

        // Update SharePoint list
        updateTaskInSP(task, function () {
            renderBoard();

            // Send notification if task status changed (in-app + email)
            if (newStatus !== oldStatus) {
                var notifType = newStatus === 'done' ? 'complete' : (newStatus === 'review' ? 'approval' : 'task');
                var recipientName = task.assignees && task.assignees.length > 0 ? task.assignees[0].name : null;

                DIBNotifications.addNotification({
                    type: notifType,
                    title: 'Task Updated: ' + task.title,
                    message: 'Moved from "' + getLabelForStatus(oldStatus) + '" to "' + getLabelForStatus(newStatus) + '"',
                    taskId: taskId,
                    recipientName: recipientName,
                    emailTemplate: 'taskStatusChanged',
                    taskTitle: task.title,
                    oldStatus: getLabelForStatus(oldStatus),
                    newStatus: getLabelForStatus(newStatus),
                    updatedBy: state.currentUser ? state.currentUser.name : 'System'
                });
            }
        });
    }

    // ============================================================
    //  TASK CLICK / EDIT
    // ============================================================
    function onTaskClick(e) {
        var taskId = this.getAttribute('data-task-id');
        showEditTaskModal(taskId);
    }

    // ============================================================
    //  NEW TASK MODAL
    // ============================================================
    function showNewTaskModal() {
        showTaskModal(null);
    }

    function showEditTaskModal(taskId) {
        var task = getTask(taskId);
        showTaskModal(task);
    }

    function showTaskModal(task) {
        var isNew = !task;
        var title = isNew ? 'Create New Task' : 'Edit Task';

        var overlay = document.createElement('div');
        overlay.className = 'dib-modal-overlay';
        overlay.id = 'dibTaskModal';

        var html = '<div class="dib-modal">';
        html += '<div class="dib-modal-header"><h2>' + title + '</h2>';
        html += '<button class="dib-modal-close" onclick="DIBTaskAllocation.closeModal()">&times;</button></div>';
        html += '<div class="dib-modal-body">';

        html += '<div class="dib-form-group"><label>Title <span class="required">*</span></label>';
        html += '<input type="text" class="dib-form-control" id="taskTitle" value="' + escapeAttr(task ? task.title : '') + '" /></div>';

        html += '<div class="dib-form-group"><label>Description</label>';
        html += '<textarea class="dib-form-control" id="taskDescription" rows="3">' + escapeHtml(task ? task.description : '') + '</textarea></div>';

        html += '<div class="dib-form-group"><label>Priority</label>';
        html += '<select class="dib-form-control" id="taskPriority">';
        html += '<option value="low"' + (task && task.priority === 'low' ? ' selected' : '') + '>Low</option>';
        html += '<option value="medium"' + (!task || task.priority === 'medium' ? ' selected' : '') + '>Medium</option>';
        html += '<option value="high"' + (task && task.priority === 'high' ? ' selected' : '') + '>High</option>';
        html += '</select></div>';

        html += '<div class="dib-form-group"><label>Assign To</label>';
        html += '<input type="text" class="dib-form-control" id="taskAssignee" placeholder="Enter name or email" value="' + escapeAttr(task && task.assignees && task.assignees.length > 0 ? task.assignees[0].name : '') + '" /></div>';

        html += '<div class="dib-form-group"><label>Due Date</label>';
        html += '<input type="date" class="dib-form-control" id="taskDueDate" value="' + escapeAttr(task ? task.dueDate : '') + '" /></div>';

        html += '<div class="dib-form-group"><label>Status</label>';
        html += '<select class="dib-form-control" id="taskStatus">';
        state.columns.forEach(function (col) {
            html += '<option value="' + col.id + '"' + (task && task.status === col.id ? ' selected' : '') + '>' + escapeHtml(col.label) + '</option>';
        });
        html += '</select></div>';

        html += '<div class="dib-form-group"><label>Tags (comma-separated)</label>';
        html += '<input type="text" class="dib-form-control" id="taskTags" placeholder="e.g. Finance, Compliance" value="' + escapeAttr(task && task.tags ? task.tags.join(', ') : '') + '" /></div>';

        html += '</div>';
        html += '<div class="dib-modal-footer">';
        if (!isNew) {
            html += '<button class="dib-btn dib-btn-danger" onclick="DIBTaskAllocation.deleteTask(\'' + task.id + '\')">Delete</button>';
        }
        html += '<button class="dib-btn dib-btn-outline" onclick="DIBTaskAllocation.closeModal()">Cancel</button>';
        html += '<button class="dib-btn dib-btn-primary" onclick="DIBTaskAllocation.saveTask(\'' + (task ? task.id : '') + '\')">Save</button>';
        html += '</div></div>';

        overlay.innerHTML = html;
        document.body.appendChild(overlay);

        // Close on overlay click
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) closeModal();
        });
    }

    function saveTask(taskId) {
        var title = document.getElementById('taskTitle').value.trim();
        if (!title) {
            alert('Please enter a task title');
            return;
        }

        var assigneeName = document.getElementById('taskAssignee').value.trim();
        var tagsRaw = document.getElementById('taskTags').value;
        var tags = tagsRaw ? tagsRaw.split(',').map(function (t) { return t.trim(); }).filter(Boolean) : [];

        var taskData = {
            title: title,
            description: document.getElementById('taskDescription').value.trim(),
            priority: document.getElementById('taskPriority').value,
            status: document.getElementById('taskStatus').value,
            dueDate: document.getElementById('taskDueDate').value,
            assignees: assigneeName ? [{ name: assigneeName }] : [],
            tags: tags
        };

        if (taskId) {
            // Update existing
            var task = getTask(taskId);
            if (task) {
                Object.assign(task, taskData);
                updateTaskInSP(task, function () {
                    renderBoard();
                    closeModal();
                });
            }
        } else {
            // Create new
            taskData.id = 'task_' + Date.now();
            state.tasks.push(taskData);
            createTaskInSP(taskData, function (spId) {
                taskData.spId = spId;
                renderBoard();
                closeModal();

                // Notify assignee (in-app + email)
                if (taskData.assignees.length > 0) {
                    DIBNotifications.addNotification({
                        type: 'task',
                        title: 'New Task Assigned',
                        message: '"' + taskData.title + '" has been assigned to ' + taskData.assignees[0].name,
                        taskId: taskData.id,
                        recipientName: taskData.assignees[0].name,
                        emailTemplate: 'taskAssigned',
                        taskTitle: taskData.title,
                        description: taskData.description,
                        priority: taskData.priority,
                        dueDate: taskData.dueDate,
                        assignedBy: state.currentUser ? state.currentUser.name : 'System'
                    });
                }
            });
        }
    }

    function deleteTask(taskId) {
        if (!confirm('Delete this task permanently?')) return;

        var task = getTask(taskId);
        state.tasks = state.tasks.filter(function (t) { return t.id !== taskId; });

        if (task && task.spId) {
            deleteTaskFromSP(task.spId);
        }

        renderBoard();
        closeModal();
    }

    function closeModal() {
        var modal = document.getElementById('dibTaskModal');
        if (modal) modal.remove();
    }

    // ============================================================
    //  SHAREPOINT CRUD
    // ============================================================
    function loadTasks(callback) {
        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + state.listName + "')/items?$top=500&$orderby=Created desc";

        spGet(url, function (data) {
            state.tasks = (data.d.results || []).map(function (item) {
                var tags = [];
                try { tags = JSON.parse(item.Tags || '[]'); } catch (ex) { /* ignore */ }
                var assignees = [];
                try { assignees = JSON.parse(item.AssignedToJSON || '[]'); } catch (ex) { /* ignore */ }

                return {
                    id: 'task_' + item.Id,
                    spId: item.Id,
                    title: item.Title || '',
                    description: item.Description1 || '',
                    status: item.Status || 'todo',
                    priority: item.Priority || 'medium',
                    dueDate: item.DueDate ? item.DueDate.split('T')[0] : '',
                    assignees: assignees,
                    tags: tags
                };
            });

            if (callback) callback();
        }, function () {
            // If list doesn't exist or error, use empty state
            state.tasks = [];
            if (callback) callback();
        });
    }

    function createTaskInSP(task, callback) {
        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + state.listName + "')/items";

        var payload = {
            __metadata: { type: getListItemType(state.listName) },
            Title: task.title,
            Description1: task.description,
            Status: task.status,
            Priority: task.priority,
            DueDate: task.dueDate || null,
            AssignedToJSON: JSON.stringify(task.assignees),
            Tags: JSON.stringify(task.tags)
        };

        spPost(url, payload, function (response) {
            if (callback) callback(response.d.Id);
        });
    }

    function updateTaskInSP(task, callback) {
        if (!task.spId) { if (callback) callback(); return; }
        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + state.listName + "')/items(" + task.spId + ")";

        var payload = {
            __metadata: { type: getListItemType(state.listName) },
            Title: task.title,
            Description1: task.description,
            Status: task.status,
            Priority: task.priority,
            DueDate: task.dueDate || null,
            AssignedToJSON: JSON.stringify(task.assignees),
            Tags: JSON.stringify(task.tags)
        };

        spMerge(url, payload, callback);
    }

    function deleteTaskFromSP(spId) {
        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + "/_api/web/lists/getbytitle('" + state.listName + "')/items(" + spId + ")";
        spDelete(url);
    }

    // ============================================================
    //  SP REST HELPERS
    // ============================================================
    function getDigest() {
        var el = document.getElementById('__REQUESTDIGEST');
        return el ? el.value : '';
    }

    function spGet(url, success, error) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                success(JSON.parse(xhr.responseText));
            } else {
                if (error) error(xhr);
            }
        };
        xhr.onerror = function () { if (error) error(xhr); };
        xhr.send();
    }

    function spPost(url, data, success) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('Content-Type', 'application/json;odata=verbose');
        xhr.setRequestHeader('X-RequestDigest', getDigest());
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                if (success) success(JSON.parse(xhr.responseText));
            }
        };
        xhr.send(JSON.stringify(data));
    }

    function spMerge(url, data, success) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('Content-Type', 'application/json;odata=verbose');
        xhr.setRequestHeader('X-RequestDigest', getDigest());
        xhr.setRequestHeader('IF-MATCH', '*');
        xhr.setRequestHeader('X-HTTP-Method', 'MERGE');
        xhr.onload = function () { if (success) success(); };
        xhr.send(JSON.stringify(data));
    }

    function spDelete(url) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('X-RequestDigest', getDigest());
        xhr.setRequestHeader('IF-MATCH', '*');
        xhr.setRequestHeader('X-HTTP-Method', 'DELETE');
        xhr.send();
    }

    function getListItemType(listName) {
        return 'SP.Data.' + listName.charAt(0).toUpperCase() + listName.slice(1).replace(/\s/g, '_x0020_') + 'ListItem';
    }

    function getCurrentUser(callback) {
        var siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
        var url = siteUrl + '/_api/web/currentuser';
        spGet(url, function (data) {
            state.currentUser = {
                id: data.d.Id,
                name: data.d.Title,
                email: data.d.Email
            };
            if (callback) callback();
        }, function () {
            state.currentUser = { id: 0, name: 'Unknown', email: '' };
            if (callback) callback();
        });
    }

    // ============================================================
    //  UTILITY
    // ============================================================
    function getTask(id) {
        for (var i = 0; i < state.tasks.length; i++) {
            if (state.tasks[i].id === id) return state.tasks[i];
        }
        return null;
    }

    function getLabelForStatus(statusId) {
        for (var i = 0; i < state.columns.length; i++) {
            if (state.columns[i].id === statusId) return state.columns[i].label;
        }
        return statusId;
    }

    function getInitials(name) {
        if (!name) return '?';
        var parts = name.split(/[\s@]+/);
        return (parts[0][0] + (parts.length > 1 ? parts[1][0] : '')).toUpperCase();
    }

    function truncate(str, max) {
        if (!str || str.length <= max) return str;
        return str.substring(0, max) + '...';
    }

    function formatDate(dateStr) {
        if (!dateStr) return '';
        var d = new Date(dateStr);
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return months[d.getMonth()] + ' ' + d.getDate();
    }

    function escapeHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    function escapeAttr(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // Bind events
    function bindEvents() {
        // Refresh on window focus
        window.addEventListener('focus', function () {
            loadTasks(function () { renderBoard(); });
        });
    }

    // ============================================================
    //  PUBLIC API
    // ============================================================
    return {
        init: init,
        renderBoard: renderBoard,
        showNewTaskModal: showNewTaskModal,
        saveTask: saveTask,
        deleteTask: deleteTask,
        closeModal: closeModal,
        moveTask: moveTask,
        getState: function () { return state; }
    };

})();

// Auto-init
if (typeof SP !== 'undefined' && SP.SOD) {
    SP.SOD.executeOrDelayUntilScriptLoaded(function () {
        DIBTaskAllocation.init();
    }, 'sp.js');
} else if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
        DIBTaskAllocation.init();
    });
} else {
    DIBTaskAllocation.init();
}
