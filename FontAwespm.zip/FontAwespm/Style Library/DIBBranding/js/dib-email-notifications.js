/* ============================================================
   DIB Email Notifications Module
   Sends email notifications via SharePoint REST API
   (SP.Utilities.Utility.SendEmail)
   SharePoint Server Subscription Edition
   ============================================================ */

var DIBEmailNotifications = (function () {
    'use strict';

    // ---- Configuration ----
    var config = {
        enabled: true,
        fromDisplayName: 'DIB Workflow System',
        siteUrl: '',
        templateDefaults: {
            headerColor: '#005B3A',
            accentColor: '#C8A951',
            logoUrl: '',
            footerText: 'Dubai Islamic Bank - Workflow Management System'
        }
    };

    // ---- Email Templates ----
    var templates = {

        // --- Task Assigned ---
        taskAssigned: {
            subject: '[DIB Workflow] New Task Assigned: {{taskTitle}}',
            body: function (data) {
                return buildEmailHtml({
                    preheader: 'A new task has been assigned to you.',
                    heading: 'New Task Assigned',
                    icon: '&#128203;',
                    sections: [
                        { label: 'Task', value: data.taskTitle },
                        { label: 'Description', value: data.description || 'No description provided.' },
                        { label: 'Priority', value: capitalize(data.priority || 'medium'), highlight: getPriorityColor(data.priority) },
                        { label: 'Due Date', value: data.dueDate || 'Not set' },
                        { label: 'Assigned By', value: data.assignedBy || 'System' }
                    ],
                    ctaText: 'View Task',
                    ctaUrl: data.taskUrl || data.siteUrl || config.siteUrl,
                    message: 'Please review and take action on this task at your earliest convenience.'
                });
            }
        },

        // --- Task Status Changed ---
        taskStatusChanged: {
            subject: '[DIB Workflow] Task Updated: {{taskTitle}}',
            body: function (data) {
                return buildEmailHtml({
                    preheader: 'Task status has been updated.',
                    heading: 'Task Status Updated',
                    icon: '&#128260;',
                    sections: [
                        { label: 'Task', value: data.taskTitle },
                        { label: 'Previous Status', value: data.oldStatus },
                        { label: 'New Status', value: data.newStatus, highlight: getStatusColor(data.newStatus) },
                        { label: 'Updated By', value: data.updatedBy || 'System' }
                    ],
                    ctaText: 'View Task',
                    ctaUrl: data.taskUrl || config.siteUrl
                });
            }
        },

        // --- Approval Required ---
        approvalRequired: {
            subject: '[DIB Workflow] Approval Required: {{taskTitle}}',
            body: function (data) {
                return buildEmailHtml({
                    preheader: 'Your approval is needed.',
                    heading: 'Approval Required',
                    icon: '&#9989;',
                    sections: [
                        { label: 'Workflow', value: data.workflowName || 'N/A' },
                        { label: 'Item', value: data.taskTitle },
                        { label: 'Description', value: data.description || '' },
                        { label: 'Requested By', value: data.requestedBy || 'System' },
                        { label: 'Due By', value: data.dueDate || 'As soon as possible' }
                    ],
                    ctaText: 'Review &amp; Approve',
                    ctaUrl: data.approvalUrl || config.siteUrl,
                    message: 'This workflow step requires your approval to proceed. Please review the details and take action.',
                    urgency: true
                });
            }
        },

        // --- Approval Completed ---
        approvalCompleted: {
            subject: '[DIB Workflow] Approval {{decision}}: {{taskTitle}}',
            body: function (data) {
                var isApproved = (data.decision || '').toLowerCase() === 'approved';
                return buildEmailHtml({
                    preheader: 'Approval decision has been made.',
                    heading: 'Approval ' + capitalize(data.decision || 'Completed'),
                    icon: isApproved ? '&#9989;' : '&#10060;',
                    sections: [
                        { label: 'Item', value: data.taskTitle },
                        { label: 'Decision', value: capitalize(data.decision || 'N/A'), highlight: isApproved ? '#2E7D32' : '#D32F2F' },
                        { label: 'Decided By', value: data.approverName || 'N/A' },
                        { label: 'Comments', value: data.comments || 'No comments.' }
                    ],
                    ctaText: 'View Details',
                    ctaUrl: data.taskUrl || config.siteUrl
                });
            }
        },

        // --- Workflow Started ---
        workflowStarted: {
            subject: '[DIB Workflow] Workflow Started: {{workflowName}}',
            body: function (data) {
                return buildEmailHtml({
                    preheader: 'A workflow has been initiated.',
                    heading: 'Workflow Started',
                    icon: '&#9654;',
                    sections: [
                        { label: 'Workflow', value: data.workflowName },
                        { label: 'Initiated By', value: data.initiatedBy || 'System' },
                        { label: 'Started At', value: formatDateTime(new Date()) },
                        { label: 'Description', value: data.description || '' }
                    ],
                    ctaText: 'View Workflow',
                    ctaUrl: data.workflowUrl || config.siteUrl
                });
            }
        },

        // --- Workflow Completed ---
        workflowCompleted: {
            subject: '[DIB Workflow] Workflow Completed: {{workflowName}}',
            body: function (data) {
                return buildEmailHtml({
                    preheader: 'Workflow has been completed.',
                    heading: 'Workflow Completed',
                    icon: '&#127942;',
                    sections: [
                        { label: 'Workflow', value: data.workflowName },
                        { label: 'Status', value: 'Completed', highlight: '#2E7D32' },
                        { label: 'Completed At', value: formatDateTime(new Date()) },
                        { label: 'Duration', value: data.duration || 'N/A' }
                    ],
                    ctaText: 'View Summary',
                    ctaUrl: data.workflowUrl || config.siteUrl
                });
            }
        },

        // --- Task Overdue ---
        taskOverdue: {
            subject: '[DIB Workflow] OVERDUE: {{taskTitle}}',
            body: function (data) {
                return buildEmailHtml({
                    preheader: 'A task is past its due date.',
                    heading: 'Task Overdue',
                    icon: '&#9888;',
                    sections: [
                        { label: 'Task', value: data.taskTitle },
                        { label: 'Due Date', value: data.dueDate, highlight: '#D32F2F' },
                        { label: 'Assigned To', value: data.assigneeName || 'Unassigned' },
                        { label: 'Days Overdue', value: data.daysOverdue || '1' }
                    ],
                    ctaText: 'Take Action',
                    ctaUrl: data.taskUrl || config.siteUrl,
                    message: 'This task has passed its due date. Please take immediate action or update the timeline.',
                    urgency: true
                });
            }
        },

        // --- Task Reminder ---
        taskReminder: {
            subject: '[DIB Workflow] Reminder: {{taskTitle}} due {{dueDate}}',
            body: function (data) {
                return buildEmailHtml({
                    preheader: 'Upcoming task deadline reminder.',
                    heading: 'Task Reminder',
                    icon: '&#128276;',
                    sections: [
                        { label: 'Task', value: data.taskTitle },
                        { label: 'Due Date', value: data.dueDate },
                        { label: 'Status', value: data.status || 'In Progress' },
                        { label: 'Priority', value: capitalize(data.priority || 'medium') }
                    ],
                    ctaText: 'View Task',
                    ctaUrl: data.taskUrl || config.siteUrl,
                    message: 'This is a reminder that the above task is approaching its deadline.'
                });
            }
        },

        // --- Comment / Mention ---
        commentAdded: {
            subject: '[DIB Workflow] New comment on: {{taskTitle}}',
            body: function (data) {
                return buildEmailHtml({
                    preheader: data.commenterName + ' commented on a task.',
                    heading: 'New Comment',
                    icon: '&#128172;',
                    sections: [
                        { label: 'Task', value: data.taskTitle },
                        { label: 'Comment By', value: data.commenterName || 'Unknown' }
                    ],
                    ctaText: 'View Comment',
                    ctaUrl: data.taskUrl || config.siteUrl,
                    message: '"' + (data.comment || '') + '"'
                });
            }
        }
    };

    // ============================================================
    //  INITIALIZATION
    // ============================================================
    function init(options) {
        options = options || {};
        config.enabled = options.enabled !== false;
        config.siteUrl = (_spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '') || options.siteUrl || '';
        config.templateDefaults.logoUrl = config.siteUrl + '/Style Library/DIBBranding/images/dib-logo.png';

        if (options.fromDisplayName) config.fromDisplayName = options.fromDisplayName;
    }

    // ============================================================
    //  SEND EMAIL (SharePoint REST API)
    //  Uses SP.Utilities.Utility.SendEmail — sends from SharePoint
    //  system account; recipients must be valid SharePoint users.
    // ============================================================
    function sendEmail(to, subject, body, callback, errorCallback) {
        if (!config.enabled) {
            if (callback) callback();
            return;
        }

        // Normalize recipients
        var recipients = Array.isArray(to) ? to : [to];
        recipients = recipients.filter(function (r) { return r && r.trim(); });

        if (recipients.length === 0) {
            console.warn('DIBEmailNotifications: No recipients specified.');
            if (callback) callback();
            return;
        }

        var siteUrl = config.siteUrl;
        var url = siteUrl + '/_api/SP.Utilities.Utility.SendEmail';

        var payload = {
            properties: {
                __metadata: { type: 'SP.Utilities.EmailProperties' },
                To: { results: recipients },
                Subject: subject,
                Body: body,
                AdditionalHeaders: {
                    __metadata: { type: 'Collection(SP.KeyValue)' },
                    results: [
                        {
                            __metadata: { type: 'SP.KeyValue' },
                            Key: 'content-type',
                            Value: 'text/html',
                            ValueType: 'Edm.String'
                        }
                    ]
                }
            }
        };

        var digest = getDigest();

        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('Content-Type', 'application/json;odata=verbose');
        xhr.setRequestHeader('X-RequestDigest', digest);

        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                console.log('DIBEmailNotifications: Email sent to ' + recipients.join(', '));
                if (callback) callback();
            } else {
                console.error('DIBEmailNotifications: Failed to send email.', xhr.status, xhr.responseText);
                if (errorCallback) errorCallback(xhr);
            }
        };

        xhr.onerror = function () {
            console.error('DIBEmailNotifications: Network error sending email.');
            if (errorCallback) errorCallback(xhr);
        };

        xhr.send(JSON.stringify(payload));
    }

    // ============================================================
    //  TEMPLATE-BASED SENDING
    // ============================================================
    function sendTemplatedEmail(templateName, recipients, data, callback) {
        var template = templates[templateName];
        if (!template) {
            console.error('DIBEmailNotifications: Unknown template "' + templateName + '"');
            return;
        }

        data = data || {};
        data.siteUrl = data.siteUrl || config.siteUrl;

        var subject = resolveTemplate(template.subject, data);
        var body = typeof template.body === 'function' ? template.body(data) : template.body;

        sendEmail(recipients, subject, body, callback);
    }

    // ---- Convenience Methods ----

    function sendTaskAssigned(recipientEmail, data, callback) {
        sendTemplatedEmail('taskAssigned', recipientEmail, data, callback);
    }

    function sendTaskStatusChanged(recipientEmail, data, callback) {
        sendTemplatedEmail('taskStatusChanged', recipientEmail, data, callback);
    }

    function sendApprovalRequired(recipientEmail, data, callback) {
        sendTemplatedEmail('approvalRequired', recipientEmail, data, callback);
    }

    function sendApprovalCompleted(recipientEmail, data, callback) {
        sendTemplatedEmail('approvalCompleted', recipientEmail, data, callback);
    }

    function sendWorkflowStarted(recipientEmail, data, callback) {
        sendTemplatedEmail('workflowStarted', recipientEmail, data, callback);
    }

    function sendWorkflowCompleted(recipientEmail, data, callback) {
        sendTemplatedEmail('workflowCompleted', recipientEmail, data, callback);
    }

    function sendTaskOverdue(recipientEmail, data, callback) {
        sendTemplatedEmail('taskOverdue', recipientEmail, data, callback);
    }

    function sendTaskReminder(recipientEmail, data, callback) {
        sendTemplatedEmail('taskReminder', recipientEmail, data, callback);
    }

    function sendCommentNotification(recipientEmail, data, callback) {
        sendTemplatedEmail('commentAdded', recipientEmail, data, callback);
    }

    // ============================================================
    //  EMAIL HTML BUILDER
    //  Inline CSS for maximum email client compatibility
    // ============================================================
    function buildEmailHtml(opts) {
        var hdrColor = config.templateDefaults.headerColor;
        var accentColor = config.templateDefaults.accentColor;
        var logoUrl = config.templateDefaults.logoUrl;
        var footerText = config.templateDefaults.footerText;

        var html = '';
        html += '<!DOCTYPE html><html><head><meta charset="utf-8"/>';
        html += '<meta name="viewport" content="width=device-width,initial-scale=1.0"/>';
        html += '<title>' + escapeHtml(opts.heading) + '</title>';
        html += '</head><body style="margin:0;padding:0;background:#f4f6f5;font-family:Segoe UI,Helvetica Neue,Arial,sans-serif;">';

        // Preheader (hidden preview text)
        if (opts.preheader) {
            html += '<div style="display:none;max-height:0;overflow:hidden;">' + escapeHtml(opts.preheader) + '</div>';
        }

        // Outer table
        html += '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f5;padding:24px 0;">';
        html += '<tr><td align="center">';

        // Inner container
        html += '<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">';

        // Header banner
        html += '<tr><td style="background:' + hdrColor + ';padding:24px 32px;text-align:center;">';
        if (logoUrl) {
            html += '<img src="' + escapeHtml(logoUrl) + '" alt="Dubai Islamic Bank" style="height:40px;margin-bottom:8px;filter:brightness(0) invert(1);" /><br/>';
        }
        html += '<span style="color:' + accentColor + ';font-size:12px;text-transform:uppercase;letter-spacing:2px;">Workflow Management System</span>';
        html += '</td></tr>';

        // Icon + Heading
        html += '<tr><td style="padding:32px 32px 16px;text-align:center;">';
        if (opts.icon) {
            html += '<div style="font-size:40px;margin-bottom:8px;">' + opts.icon + '</div>';
        }
        html += '<h1 style="margin:0;font-size:22px;color:' + hdrColor + ';font-weight:600;">' + escapeHtml(opts.heading) + '</h1>';
        html += '</td></tr>';

        // Urgency banner
        if (opts.urgency) {
            html += '<tr><td style="padding:0 32px;">';
            html += '<div style="background:#FFF3E0;border-left:4px solid #E65100;padding:10px 16px;border-radius:4px;font-size:13px;color:#E65100;font-weight:600;">';
            html += '&#9888; Action Required — Please respond promptly.';
            html += '</div></td></tr>';
        }

        // Detail sections
        if (opts.sections && opts.sections.length > 0) {
            html += '<tr><td style="padding:16px 32px 8px;">';
            html += '<table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #E8EDEB;border-radius:6px;overflow:hidden;">';
            opts.sections.forEach(function (s, i) {
                if (!s.value) return;
                var bg = i % 2 === 0 ? '#f7f9f8' : '#ffffff';
                html += '<tr style="background:' + bg + ';">';
                html += '<td style="padding:10px 16px;font-size:13px;color:#6B7C73;font-weight:600;width:140px;vertical-align:top;">' + escapeHtml(s.label) + '</td>';
                html += '<td style="padding:10px 16px;font-size:14px;color:#1E2D26;">';
                if (s.highlight) {
                    html += '<span style="display:inline-block;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600;background:' + s.highlight + '22;color:' + s.highlight + ';">' + escapeHtml(s.value) + '</span>';
                } else {
                    html += escapeHtml(s.value);
                }
                html += '</td></tr>';
            });
            html += '</table></td></tr>';
        }

        // Message
        if (opts.message) {
            html += '<tr><td style="padding:16px 32px 8px;">';
            html += '<p style="margin:0;font-size:14px;color:#4A5A53;line-height:1.6;">' + escapeHtml(opts.message) + '</p>';
            html += '</td></tr>';
        }

        // CTA Button
        if (opts.ctaText && opts.ctaUrl) {
            html += '<tr><td style="padding:20px 32px 32px;text-align:center;">';
            html += '<a href="' + escapeHtml(opts.ctaUrl) + '" style="display:inline-block;padding:12px 32px;background:' + hdrColor + ';color:#ffffff;text-decoration:none;border-radius:6px;font-size:14px;font-weight:600;">';
            html += escapeHtml(opts.ctaText);
            html += '</a></td></tr>';
        }

        // Footer
        html += '<tr><td style="background:#f7f9f8;padding:20px 32px;text-align:center;border-top:1px solid #E8EDEB;">';
        html += '<p style="margin:0 0 4px;font-size:12px;color:#9BADA3;">' + escapeHtml(footerText) + '</p>';
        html += '<p style="margin:0;font-size:11px;color:#bcc8c2;">This is an automated notification. Please do not reply directly to this email.</p>';
        html += '</td></tr>';

        html += '</table>';  // inner
        html += '</td></tr></table>';  // outer
        html += '</body></html>';

        return html;
    }

    // ============================================================
    //  UTILITY
    // ============================================================
    function resolveTemplate(templateStr, data) {
        return templateStr.replace(/\{\{(\w+)\}\}/g, function (match, key) {
            return data[key] !== undefined && data[key] !== null ? data[key] : '';
        });
    }

    function getDigest() {
        var el = document.getElementById('__REQUESTDIGEST');
        return el ? el.value : '';
    }

    function escapeHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(String(str)));
        return div.innerHTML;
    }

    function capitalize(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    function formatDateTime(d) {
        if (!d) return '';
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return months[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear() + ' ' +
               padZero(d.getHours()) + ':' + padZero(d.getMinutes());
    }

    function padZero(n) { return n < 10 ? '0' + n : '' + n; }

    function getPriorityColor(priority) {
        var colors = { high: '#D32F2F', medium: '#F9A825', low: '#2E7D32' };
        return colors[(priority || '').toLowerCase()] || '#1565C0';
    }

    function getStatusColor(status) {
        var colors = {
            'todo': '#1565C0', 'to do': '#1565C0',
            'in-progress': '#F9A825', 'in progress': '#F9A825',
            'review': '#7B1FA2', 'under review': '#7B1FA2',
            'done': '#2E7D32', 'completed': '#2E7D32'
        };
        return colors[(status || '').toLowerCase()] || '#1565C0';
    }

    // ============================================================
    //  RESOLVE USER EMAIL FROM SHAREPOINT
    // ============================================================
    function resolveUserEmail(nameOrEmail, callback) {
        // If it already looks like an email, return it
        if (nameOrEmail && nameOrEmail.indexOf('@') >= 0) {
            callback(nameOrEmail);
            return;
        }

        // Try to resolve via SharePoint people search
        var siteUrl = config.siteUrl;
        var url = siteUrl + "/_api/web/siteusers?$filter=Title eq '" + encodeURIComponent(nameOrEmail) + "'&$select=Email,Title";

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                var data = JSON.parse(xhr.responseText);
                var results = data.d.results || [];
                if (results.length > 0 && results[0].Email) {
                    callback(results[0].Email);
                } else {
                    console.warn('DIBEmailNotifications: Could not resolve email for "' + nameOrEmail + '"');
                    callback(null);
                }
            } else {
                callback(null);
            }
        };
        xhr.onerror = function () { callback(null); };
        xhr.send();
    }

    // ============================================================
    //  PUBLIC API
    // ============================================================
    return {
        init: init,
        sendEmail: sendEmail,
        sendTemplatedEmail: sendTemplatedEmail,
        sendTaskAssigned: sendTaskAssigned,
        sendTaskStatusChanged: sendTaskStatusChanged,
        sendApprovalRequired: sendApprovalRequired,
        sendApprovalCompleted: sendApprovalCompleted,
        sendWorkflowStarted: sendWorkflowStarted,
        sendWorkflowCompleted: sendWorkflowCompleted,
        sendTaskOverdue: sendTaskOverdue,
        sendTaskReminder: sendTaskReminder,
        sendCommentNotification: sendCommentNotification,
        resolveUserEmail: resolveUserEmail,
        getTemplates: function () { return Object.keys(templates); },
        setEnabled: function (enabled) { config.enabled = enabled; }
    };

})();

// Auto-init
if (typeof SP !== 'undefined' && SP.SOD) {
    SP.SOD.executeOrDelayUntilScriptLoaded(function () {
        DIBEmailNotifications.init();
    }, 'sp.js');
} else if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
        DIBEmailNotifications.init();
    });
} else {
    DIBEmailNotifications.init();
}
