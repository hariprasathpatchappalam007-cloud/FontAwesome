<# ============================================================
   DIB SharePoint Workflow - Deployment Script
   SharePoint Server Subscription Edition
   ============================================================
   
   PREREQUISITES:
   - SharePoint Server Subscription Edition
   - Site Collection Administrator access
   - SharePoint Management Shell or PnP PowerShell
   ============================================================ #>

param(
    [Parameter(Mandatory=$true)]
    [string]$SiteUrl,
    
    [Parameter(Mandatory=$false)]
    [PSCredential]$Credential
)

# ---- Configuration ----
$ErrorActionPreference = "Stop"

Write-Host "============================================" -ForegroundColor Green
Write-Host " DIB Workflow Management System - Deployer" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""

# ---- Connect to SharePoint ----
Write-Host "[1/6] Connecting to SharePoint..." -ForegroundColor Cyan
try {
    if ($Credential) {
        Connect-PnPOnline -Url $SiteUrl -Credentials $Credential
    } else {
        Connect-PnPOnline -Url $SiteUrl -Interactive
    }
    Write-Host "  Connected to $SiteUrl" -ForegroundColor Green
} catch {
    Write-Host "  ERROR: Could not connect. Ensure PnP.PowerShell is installed." -ForegroundColor Red
    Write-Host "  Install with: Install-Module PnP.PowerShell -Force" -ForegroundColor Yellow
    exit 1
}

# ---- Upload Branding Assets to Style Library ----
Write-Host ""
Write-Host "[2/6] Uploading branding assets to Style Library..." -ForegroundColor Cyan

$localBase = Split-Path -Parent $PSScriptRoot
$styleLibPath = "Style Library/DIBBranding"

# Create folder structure
$folders = @("css", "css/fontawesome", "css/fontawesome/webfonts", "js", "images")
foreach ($folder in $folders) {
    $serverPath = "$styleLibPath/$folder"
    try {
        Resolve-PnPFolder -SiteRelativePath $serverPath | Out-Null
        Write-Host "  Folder exists: $serverPath" -ForegroundColor DarkGray
    } catch {
        $parts = $folder -split "/"
        $parentPath = $styleLibPath
        foreach ($part in $parts) {
            $checkPath = "$parentPath/$part"
            try { Resolve-PnPFolder -SiteRelativePath $checkPath | Out-Null }
            catch { Add-PnPFolder -Name $part -Folder $parentPath -ErrorAction SilentlyContinue }
            $parentPath = $checkPath
        }
        Write-Host "  Created folder: $serverPath" -ForegroundColor Green
    }
}

# Upload CSS files
$cssFiles = Get-ChildItem -Path "$localBase\Style Library\DIBBranding\css" -Filter "*.css" -File
foreach ($file in $cssFiles) {
    Add-PnPFile -Path $file.FullName -Folder "$styleLibPath/css" -ErrorAction SilentlyContinue
    Write-Host "  Uploaded: css/$($file.Name)" -ForegroundColor Green
}

# Upload Font Awesome files
$faPath = "$localBase\Style Library\DIBBranding\css\fontawesome"
if (Test-Path $faPath) {
    $faFiles = Get-ChildItem -Path $faPath -Filter "*.css" -File
    foreach ($file in $faFiles) {
        Add-PnPFile -Path $file.FullName -Folder "$styleLibPath/css/fontawesome" -ErrorAction SilentlyContinue
        Write-Host "  Uploaded: css/fontawesome/$($file.Name)" -ForegroundColor Green
    }
    $webfontsPath = "$faPath\webfonts"
    if (Test-Path $webfontsPath) {
        $fontFiles = Get-ChildItem -Path $webfontsPath -File
        foreach ($file in $fontFiles) {
            Add-PnPFile -Path $file.FullName -Folder "$styleLibPath/css/fontawesome/webfonts" -ErrorAction SilentlyContinue
            Write-Host "  Uploaded: css/fontawesome/webfonts/$($file.Name)" -ForegroundColor Green
        }
    }
} else {
    Write-Host "  WARNING: Font Awesome not found at $faPath" -ForegroundColor Yellow
    Write-Host "  Download from https://fontawesome.com/download and extract to:" -ForegroundColor Yellow
    Write-Host "    Style Library\DIBBranding\css\fontawesome\all.min.css" -ForegroundColor Yellow
    Write-Host "    Style Library\DIBBranding\css\fontawesome\webfonts\*" -ForegroundColor Yellow
}

# Upload JS files
$jsFiles = Get-ChildItem -Path "$localBase\Style Library\DIBBranding\js" -Filter "*.js"
foreach ($file in $jsFiles) {
    Add-PnPFile -Path $file.FullName -Folder "$styleLibPath/js" -ErrorAction SilentlyContinue
    Write-Host "  Uploaded: js/$($file.Name)" -ForegroundColor Green
}

# Upload logo if exists
$logoPath = "$localBase\dib-logo.png"
if (Test-Path $logoPath) {
    Add-PnPFile -Path $logoPath -Folder "$styleLibPath/images" -ErrorAction SilentlyContinue
    Write-Host "  Uploaded: images/dib-logo.png" -ForegroundColor Green
}

# ---- Upload Master Page ----
Write-Host ""
Write-Host "[3/6] Deploying master page..." -ForegroundColor Cyan

$masterPagePath = "$localBase\MasterPages\DIBBranded.master"
if (Test-Path $masterPagePath) {
    Add-PnPFile -Path $masterPagePath -Folder "_catalogs/masterpage" -Publish -PublishComment "DIB Branded Master Page"
    Write-Host "  Uploaded: DIBBranded.master" -ForegroundColor Green
} else {
    Write-Host "  WARNING: Master page file not found at $masterPagePath" -ForegroundColor Yellow
}

# ---- Upload Page Layout ----
Write-Host ""
Write-Host "[4/6] Deploying page layout..." -ForegroundColor Cyan

$pageLayoutPath = "$localBase\PageLayouts\WorkflowDesigner.aspx"
if (Test-Path $pageLayoutPath) {
    Add-PnPFile -Path $pageLayoutPath -Folder "_catalogs/masterpage" -Publish -PublishComment "DIB Workflow Designer Page Layout"
    Write-Host "  Uploaded: WorkflowDesigner.aspx" -ForegroundColor Green
}

# ---- Create SharePoint Lists ----
Write-Host ""
Write-Host "[5/6] Creating SharePoint lists..." -ForegroundColor Cyan

# --- DIBWorkflowDefinitions List ---
$listExists = Get-PnPList -Identity "DIBWorkflowDefinitions" -ErrorAction SilentlyContinue
if (-not $listExists) {
    New-PnPList -Title "DIBWorkflowDefinitions" -Template GenericList -Url "Lists/DIBWorkflowDefinitions"
    
    Add-PnPField -List "DIBWorkflowDefinitions" -DisplayName "WorkflowJSON" -InternalName "WorkflowJSON" -Type Note -AddToDefaultView
    Add-PnPField -List "DIBWorkflowDefinitions" -DisplayName "Status" -InternalName "Status" -Type Choice -Choices "Draft","Active","Paused","Archived" -AddToDefaultView
    Add-PnPField -List "DIBWorkflowDefinitions" -DisplayName "Version" -InternalName "Version" -Type Text -AddToDefaultView
    
    Write-Host "  Created list: DIBWorkflowDefinitions" -ForegroundColor Green
} else {
    Write-Host "  List exists: DIBWorkflowDefinitions" -ForegroundColor DarkGray
}

# --- DIBWorkflowTasks List ---
$listExists = Get-PnPList -Identity "DIBWorkflowTasks" -ErrorAction SilentlyContinue
if (-not $listExists) {
    New-PnPList -Title "DIBWorkflowTasks" -Template GenericList -Url "Lists/DIBWorkflowTasks"
    
    Add-PnPField -List "DIBWorkflowTasks" -DisplayName "Description" -InternalName "Description1" -Type Note -AddToDefaultView
    Add-PnPField -List "DIBWorkflowTasks" -DisplayName "Status" -InternalName "Status" -Type Choice -Choices "todo","in-progress","review","done" -AddToDefaultView
    Add-PnPField -List "DIBWorkflowTasks" -DisplayName "Priority" -InternalName "Priority" -Type Choice -Choices "low","medium","high" -AddToDefaultView
    Add-PnPField -List "DIBWorkflowTasks" -DisplayName "DueDate" -InternalName "DueDate" -Type DateTime -AddToDefaultView
    Add-PnPField -List "DIBWorkflowTasks" -DisplayName "AssignedToJSON" -InternalName "AssignedToJSON" -Type Note
    Add-PnPField -List "DIBWorkflowTasks" -DisplayName "Tags" -InternalName "Tags" -Type Note
    Add-PnPField -List "DIBWorkflowTasks" -DisplayName "RelatedWorkflowId" -InternalName "RelatedWorkflowId" -Type Number
    
    Write-Host "  Created list: DIBWorkflowTasks" -ForegroundColor Green
} else {
    Write-Host "  List exists: DIBWorkflowTasks" -ForegroundColor DarkGray
}

# --- DIBWorkflowNotifications List ---
$listExists = Get-PnPList -Identity "DIBWorkflowNotifications" -ErrorAction SilentlyContinue
if (-not $listExists) {
    New-PnPList -Title "DIBWorkflowNotifications" -Template GenericList -Url "Lists/DIBWorkflowNotifications"
    
    Add-PnPField -List "DIBWorkflowNotifications" -DisplayName "Message" -InternalName "Message" -Type Note -AddToDefaultView
    Add-PnPField -List "DIBWorkflowNotifications" -DisplayName "NotificationType" -InternalName "NotificationType" -Type Choice -Choices "task","approval","complete","alert" -AddToDefaultView
    Add-PnPField -List "DIBWorkflowNotifications" -DisplayName "IsRead" -InternalName "IsRead" -Type Boolean -AddToDefaultView
    Add-PnPField -List "DIBWorkflowNotifications" -DisplayName "RecipientId" -InternalName "RecipientId" -Type Number
    Add-PnPField -List "DIBWorkflowNotifications" -DisplayName "RelatedTaskId" -InternalName "RelatedTaskId" -Type Text
    Add-PnPField -List "DIBWorkflowNotifications" -DisplayName "RelatedWorkflowId" -InternalName "RelatedWorkflowId" -Type Text
    Add-PnPField -List "DIBWorkflowNotifications" -DisplayName "LinkUrl" -InternalName "LinkUrl" -Type Text
    
    Write-Host "  Created list: DIBWorkflowNotifications" -ForegroundColor Green
} else {
    Write-Host "  List exists: DIBWorkflowNotifications" -ForegroundColor DarkGray
}

# ---- Set Master Page ----
Write-Host ""
Write-Host "[6/6] Applying master page to site..." -ForegroundColor Cyan

try {
    $web = Get-PnPWeb
    $masterPageUrl = $web.ServerRelativeUrl + "/_catalogs/masterpage/DIBBranded.master"
    Set-PnPMasterPage -MasterPageServerRelativeUrl $masterPageUrl -CustomMasterPageServerRelativeUrl $masterPageUrl
    Write-Host "  Applied DIBBranded.master as site master page" -ForegroundColor Green
} catch {
    Write-Host "  WARNING: Could not auto-apply master page. Apply manually via Site Settings > Master Page." -ForegroundColor Yellow
}

# ---- Done ----
Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host " Deployment Complete!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "  1. Navigate to Site Settings > Master Page and verify DIBBranded.master is selected" -ForegroundColor White
Write-Host "  2. Create a new page using the WorkflowDesigner page layout" -ForegroundColor White
Write-Host "  3. Upload your DIB logo to: Style Library/DIBBranding/images/dib-logo.png" -ForegroundColor White
Write-Host "  4. Grant appropriate permissions to the workflow lists" -ForegroundColor White
Write-Host ""

Disconnect-PnPOnline
