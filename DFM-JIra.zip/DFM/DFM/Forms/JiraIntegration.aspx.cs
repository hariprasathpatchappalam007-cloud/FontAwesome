using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM.Forms
{
    public partial class JiraIntegration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadFilters();
                Bind();
            }
        }

        private void LoadFilters()
        {
            DataTable dt = JiraClient.GetCachedIssues();
            var stages = new System.Collections.Generic.HashSet<string>();
            var rags = new System.Collections.Generic.HashSet<string>();
            foreach (DataRow r in dt.Rows)
            {
                if (r["ProjectStage"] != DBNull.Value)
                {
                    string v = r["ProjectStage"].ToString();
                    if (!string.IsNullOrEmpty(v)) stages.Add(v);
                }
                if (r["ProjectRAG"] != DBNull.Value)
                {
                    string v = r["ProjectRAG"].ToString();
                    if (!string.IsNullOrEmpty(v)) rags.Add(v);
                }
            }
            foreach (string s in stages) ddlFStage.Items.Add(new ListItem(s, s));
            foreach (string s in rags) ddlFRag.Items.Add(new ListItem(s, s));
        }

        private void Bind()
        {
            DataTable dt = JiraClient.GetCachedIssues();
            DataView dv = new DataView(dt);
            StringBuilder rf = new StringBuilder();
            string fid = (txtFId.Text ?? "").Trim();
            string fname = (txtFName.Text ?? "").Trim();
            string fstage = ddlFStage.SelectedValue;
            string frag = ddlFRag.SelectedValue;
            if (fid.Length > 0) rf.Append("JiraID LIKE '%" + fid.Replace("'", "''") + "%'");
            if (fname.Length > 0)
            {
                if (rf.Length > 0) rf.Append(" AND ");
                rf.Append("ProjectName LIKE '%" + fname.Replace("'", "''") + "%'");
            }
            if (!string.IsNullOrEmpty(fstage))
            {
                if (rf.Length > 0) rf.Append(" AND ");
                rf.Append("ProjectStage='" + fstage.Replace("'", "''") + "'");
            }
            if (!string.IsNullOrEmpty(frag))
            {
                if (rf.Length > 0) rf.Append(" AND ");
                rf.Append("ProjectRAG='" + frag.Replace("'", "''") + "'");
            }
            if (rf.Length > 0) dv.RowFilter = rf.ToString();
            gv.DataSource = dv;
            gv.DataBind();
        }

        protected void Filter_Changed(object sender, EventArgs e) { gv.PageIndex = 0; Bind(); }
        protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gv.PageIndex = e.NewPageIndex;
            Bind();
        }

        protected void btnFetch_Click(object sender, EventArgs e)
        {
            string jql = string.IsNullOrWhiteSpace(txtJql.Text)
                ? "project = " + JiraClient.GetConfig().ProjectKey + " ORDER BY updated DESC"
                : txtJql.Text;

            try
            {
                var issues = JiraClient.SearchIssues(jql, 100);
                int count = 0;
                foreach (Dictionary<string, object> issue in issues)
                {
                    string id = null;
                    if (issue.ContainsKey("key") && issue["key"] != null) id = issue["key"].ToString();
                    if (string.IsNullOrEmpty(id)) continue;

                    string summary = "";
                    string fieldsJson = "";
                    Dictionary<string, object> fields = issue.ContainsKey("fields")
                        ? issue["fields"] as Dictionary<string, object> : null;
                    if (fields != null)
                    {
                        if (fields.ContainsKey("summary") && fields["summary"] != null)
                            summary = fields["summary"].ToString();
                        JavaScriptSerializer jss = new JavaScriptSerializer();
                        jss.MaxJsonLength = int.MaxValue;
                        fieldsJson = jss.Serialize(fields);
                    }

                    Db.Exec(@"
IF EXISTS (SELECT 1 FROM JiraIssues WHERE JiraID=@id)
    UPDATE JiraIssues SET Summary=@s, ProjectName=@s, CustomFieldsJson=@j, UpdatedDate=GETDATE() WHERE JiraID=@id
ELSE
    INSERT INTO JiraIssues(JiraID, Summary, ProjectName, CustomFieldsJson) VALUES(@id, @s, @s, @j);",
                        Db.P("@id", id), Db.P("@s", summary), Db.P("@j", fieldsJson));
                    count++;
                }
                lblMsg.Visible = true;
                lblMsg.Text = "Fetched / updated " + count + " issue(s) from JIRA.";
                Bind();
            }
            catch (Exception ex)
            {
                lblMsg.Visible = true;
                lblMsg.Text = "JIRA fetch failed (showing cached data): " + ex.Message;
            }
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = JiraClient.GetCachedIssues();
            ExcelHelper.ExportToExcel(Response, dt, "JIRA_Issues_" + DateTime.Now.ToString("yyyyMMdd"));
        }
    }
}
