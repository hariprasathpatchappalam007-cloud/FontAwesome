using System;
using System.Data;
using System.Web.UI;
using DemandFundManagement.App_Code.DAL;
using DemandFundManagement.App_Code.Security;

namespace DemandFundManagement
{
    public partial class ChangePassword : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnChangePassword_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid)
                return;

            try
            {
                int userId = Session["UserID"] != null ? Convert.ToInt32(Session["UserID"]) : 0;
                if (userId == 0)
                {
                    Response.Redirect("~/Login.aspx");
                    return;
                }

                DataRow user = DatabaseHelper.GetUserById(userId);
                if (user == null)
                {
                    ShowMessage("User not found.", true);
                    return;
                }

                // Verify current password
                string currentHash = user["PasswordHash"].ToString();
                string currentSalt = user["PasswordSalt"].ToString();

                if (!PasswordHelper.VerifyPassword(txtCurrentPassword.Text, currentHash, currentSalt))
                {
                    ShowMessage("Current password is incorrect.", true);
                    return;
                }

                // Set new password
                string newSalt = PasswordHelper.GenerateSalt();
                string newHash = PasswordHelper.HashPassword(txtNewPassword.Text, newSalt);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";

                DatabaseHelper.ResetUserPassword(userId, newHash, newSalt, currentUser);
                ShowMessage("Password changed successfully.", false);
            }
            catch (Exception ex)
            {
                ShowMessage("Error: " + ex.Message, true);
            }
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
