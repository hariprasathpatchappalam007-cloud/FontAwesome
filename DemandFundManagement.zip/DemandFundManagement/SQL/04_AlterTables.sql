-- ============================================
-- DemandFundManagement - ALTER TABLE Migration
-- Run this ONCE on existing databases to add
-- new FK columns and remove deprecated columns
-- ============================================

USE [DemandFundManagement]
GO

-- ============================================
-- 1. Create new metadata tables
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Technology_Vertical')
BEGIN
    CREATE TABLE [dbo].[Technology_Vertical] (
        [ID]                    INT PRIMARY KEY,
        [Technology_Vertical]   NVARCHAR(200) NOT NULL,
        [IsActive]              BIT NOT NULL DEFAULT 1
    )
    PRINT 'Created table: Technology_Vertical'
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Project_Type')
BEGIN
    CREATE TABLE [dbo].[Project_Type] (
        [ID]            INT PRIMARY KEY,
        [Project_Type]  NVARCHAR(200) NOT NULL,
        [IsActive]      BIT NOT NULL DEFAULT 1
    )
    PRINT 'Created table: Project_Type'
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'GL_Code')
BEGIN
    CREATE TABLE [dbo].[GL_Code] (
        [ID]        INT PRIMARY KEY,
        [GL_Code]   NVARCHAR(100) NOT NULL,
        [IsActive]  BIT NOT NULL DEFAULT 1
    )
    PRINT 'Created table: GL_Code'
END
GO

-- ============================================
-- 2. Insert seed data into new tables
-- ============================================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Technology_Vertical])
BEGIN
    INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (1, 'Core Banking')
    INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (2, 'Digital Banking')
    INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (3, 'Data & Analytics')
    INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (4, 'Infrastructure')
    INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (5, 'Security')
    INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (6, 'Integration')
    INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (7, 'Others')
    PRINT 'Inserted seed data: Technology_Vertical'
END
GO

IF NOT EXISTS (SELECT 1 FROM [dbo].[Project_Type])
BEGIN
    INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (1, 'New Development')
    INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (2, 'Enhancement')
    INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (3, 'Maintenance')
    INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (4, 'Migration')
    INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (5, 'Infrastructure')
    INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (6, 'Others')
    PRINT 'Inserted seed data: Project_Type'
END
GO

IF NOT EXISTS (SELECT 1 FROM [dbo].[GL_Code])
BEGIN
    INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (1, 'GL-1001')
    INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (2, 'GL-1002')
    INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (3, 'GL-2001')
    INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (4, 'GL-2002')
    INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (5, 'GL-3001')
    PRINT 'Inserted seed data: GL_Code'
END
GO

-- ============================================
-- 3. Add MetadataConfig entries for new tables
-- ============================================
IF NOT EXISTS (SELECT 1 FROM [dbo].[MetadataConfig] WHERE [TableName] = 'Technology_Vertical')
    INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Technology_Vertical', 'Technology Vertical', 'Technology_Vertical', 1, 14)
IF NOT EXISTS (SELECT 1 FROM [dbo].[MetadataConfig] WHERE [TableName] = 'Project_Type')
    INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Project_Type', 'Project Type', 'Project_Type', 1, 15)
IF NOT EXISTS (SELECT 1 FROM [dbo].[MetadataConfig] WHERE [TableName] = 'GL_Code')
    INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('GL_Code', 'GL Code', 'GL_Code', 1, 16)
GO

PRINT 'MetadataConfig entries added.'
GO

-- ============================================
-- 4. Add new FK columns to DemandFund
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'DemandFund' AND COLUMN_NAME = 'GL_CodeID')
    ALTER TABLE [dbo].[DemandFund] ADD [GL_CodeID] INT NULL
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'DemandFund' AND COLUMN_NAME = 'Technology_VerticalID')
    ALTER TABLE [dbo].[DemandFund] ADD [Technology_VerticalID] INT NULL
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'DemandFund' AND COLUMN_NAME = 'Project_TypeID')
    ALTER TABLE [dbo].[DemandFund] ADD [Project_TypeID] INT NULL
GO

PRINT 'New FK columns added to DemandFund.'
GO

-- ============================================
-- 5. Add foreign key constraints
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DemandFund_GLCode')
    ALTER TABLE [dbo].[DemandFund] ADD CONSTRAINT FK_DemandFund_GLCode FOREIGN KEY ([GL_CodeID]) REFERENCES [GL_Code]([ID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DemandFund_TechVertical')
    ALTER TABLE [dbo].[DemandFund] ADD CONSTRAINT FK_DemandFund_TechVertical FOREIGN KEY ([Technology_VerticalID]) REFERENCES [Technology_Vertical]([ID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DemandFund_ProjectType')
    ALTER TABLE [dbo].[DemandFund] ADD CONSTRAINT FK_DemandFund_ProjectType FOREIGN KEY ([Project_TypeID]) REFERENCES [Project_Type]([ID])
GO

PRINT 'Foreign key constraints added.'
GO

-- ============================================
-- 6. Drop old FK constraint for DAMO_ID
-- ============================================
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DemandFund_DAMO')
    ALTER TABLE [dbo].[DemandFund] DROP CONSTRAINT FK_DemandFund_DAMO
GO

-- ============================================
-- 7. Drop deprecated columns (optional - 
--    uncomment when ready to remove old data)
-- ============================================
-- WARNING: These columns contain existing data.
-- Only drop after verifying the migration is complete.

-- IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'DemandFund' AND COLUMN_NAME = 'DAMO_ID')
--     ALTER TABLE [dbo].[DemandFund] DROP COLUMN [DAMO_ID]
-- GO
-- IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'DemandFund' AND COLUMN_NAME = 'Description_2')
--     ALTER TABLE [dbo].[DemandFund] DROP COLUMN [Description_2]
-- GO
-- IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'DemandFund' AND COLUMN_NAME = 'GL_Code')
--     ALTER TABLE [dbo].[DemandFund] DROP COLUMN [GL_Code]
-- GO
-- IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'DemandFund' AND COLUMN_NAME = 'Technology_Vertical')
--     ALTER TABLE [dbo].[DemandFund] DROP COLUMN [Technology_Vertical]
-- GO
-- IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'DemandFund' AND COLUMN_NAME = 'Project_Type')
--     ALTER TABLE [dbo].[DemandFund] DROP COLUMN [Project_Type]
-- GO

PRINT 'Migration completed successfully.'
GO
