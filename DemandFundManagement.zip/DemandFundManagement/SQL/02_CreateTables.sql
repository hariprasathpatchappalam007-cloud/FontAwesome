-- ============================================
-- DemandFundManagement - Table Creation Script
-- Vendor: Dubai Islamic Bank
-- ============================================

USE [DemandFundManagement]
GO

-- ============================================
-- 1. Application Users Table
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'AppUsers')
BEGIN
    CREATE TABLE [dbo].[AppUsers] (
        [UserID]        INT IDENTITY(1,1) PRIMARY KEY,
        [Username]      NVARCHAR(100) NOT NULL UNIQUE,
        [PasswordHash]  NVARCHAR(256) NOT NULL,
        [PasswordSalt]  NVARCHAR(256) NOT NULL,
        [FullName]      NVARCHAR(200) NOT NULL,
        [Email]         NVARCHAR(200) NULL,
        [RoleID]        INT NOT NULL DEFAULT 2,  -- 1=Admin, 2=Normal
        [IsEnabled]     BIT NOT NULL DEFAULT 1,
        [CreatedDate]   DATETIME NOT NULL DEFAULT GETDATE(),
        [CreatedBy]     NVARCHAR(100) NULL,
        [ModifiedDate]  DATETIME NULL,
        [ModifiedBy]    NVARCHAR(100) NULL,
        [LastLoginDate] DATETIME NULL
    )
END
GO

-- ============================================
-- 2. User Roles Table
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'UserRoles')
BEGIN
    CREATE TABLE [dbo].[UserRoles] (
        [RoleID]    INT PRIMARY KEY,
        [RoleName]  NVARCHAR(50) NOT NULL UNIQUE,
        [IsActive]  BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 3. Metadata: Business Team
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'BusinessTeam')
BEGIN
    CREATE TABLE [dbo].[BusinessTeam] (
        [ID]                    INT PRIMARY KEY,
        [Business_Team_Desc]    NVARCHAR(200) NOT NULL,
        [IsActive]              BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 4. Metadata: DAMO Type
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'DAMO_Type')
BEGIN
    CREATE TABLE [dbo].[DAMO_Type] (
        [ID]        INT PRIMARY KEY,
        [DAMO_Type] NVARCHAR(100) NOT NULL,
        [IsActive]  BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 5. Metadata: Engineering Team
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'EngineeringTeam')
BEGIN
    CREATE TABLE [dbo].[EngineeringTeam] (
        [ID]                INT PRIMARY KEY,
        [Engineering_Lead]  NVARCHAR(200) NOT NULL,
        [IsActive]          BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 6. Metadata: Fund Approval
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'FundApproval')
BEGIN
    CREATE TABLE [dbo].[FundApproval] (
        [ID]                    INT PRIMARY KEY,
        [Fund_Approval_Type]    NVARCHAR(100) NOT NULL,
        [IsActive]              BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 7. Metadata: Funding Source Type
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Funding_Source_Type')
BEGIN
    CREATE TABLE [dbo].[Funding_Source_Type] (
        [ID]                    INT PRIMARY KEY,
        [Funding_Source_Type]   NVARCHAR(100) NOT NULL,
        [IsActive]              BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 8. Metadata: Initiative Type
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Initiative_Type')
BEGIN
    CREATE TABLE [dbo].[Initiative_Type] (
        [ID]                INT PRIMARY KEY,
        [Initiative_Type]   NVARCHAR(100) NOT NULL,
        [IsActive]          BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 9. Metadata: Phase Description
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Phase_Description')
BEGIN
    CREATE TABLE [dbo].[Phase_Description] (
        [ID]                INT PRIMARY KEY,
        [Phase_Description] NVARCHAR(200) NOT NULL,
        [IsActive]          BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 10. Metadata: Platform Owner
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Platform_Owner')
BEGIN
    CREATE TABLE [dbo].[Platform_Owner] (
        [ID]                INT PRIMARY KEY,
        [Platform_Owner]    NVARCHAR(200) NOT NULL,
        [IsActive]          BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 11. Metadata: Portfolio Head
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Portfolio_Head')
BEGIN
    CREATE TABLE [dbo].[Portfolio_Head] (
        [ID]                INT PRIMARY KEY,
        [Portfolio_Head]    NVARCHAR(200) NOT NULL,
        [IsActive]          BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 12. Metadata: Primary Vertical
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Primary_Vertical')
BEGIN
    CREATE TABLE [dbo].[Primary_Vertical] (
        [ID]                INT PRIMARY KEY,
        [Primary_Vertical]  NVARCHAR(200) NOT NULL,
        [IsActive]          BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 13. Metadata: Spend Category
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Spend_Category')
BEGIN
    CREATE TABLE [dbo].[Spend_Category] (
        [ID]                INT PRIMARY KEY,
        [Spend_Category]    NVARCHAR(200) NOT NULL,
        [IsActive]          BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 14. Metadata: Spend Type
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Spend_Type')
BEGIN
    CREATE TABLE [dbo].[Spend_Type] (
        [ID]            INT PRIMARY KEY,
        [Spend_Type]    NVARCHAR(200) NOT NULL,
        [IsActive]      BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 15. Metadata: TShirt Size
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'TShirt_Size')
BEGIN
    CREATE TABLE [dbo].[TShirt_Size] (
        [ID]            INT PRIMARY KEY,
        [TShirt_Size]   NVARCHAR(50) NOT NULL,
        [IsActive]      BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 16a. Metadata: Technology Vertical
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Technology_Vertical')
BEGIN
    CREATE TABLE [dbo].[Technology_Vertical] (
        [ID]                    INT PRIMARY KEY,
        [Technology_Vertical]   NVARCHAR(200) NOT NULL,
        [IsActive]              BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 16b. Metadata: Project Type
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Project_Type')
BEGIN
    CREATE TABLE [dbo].[Project_Type] (
        [ID]            INT PRIMARY KEY,
        [Project_Type]  NVARCHAR(200) NOT NULL,
        [IsActive]      BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 16c. Metadata: GL Code
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'GL_Code')
BEGIN
    CREATE TABLE [dbo].[GL_Code] (
        [ID]        INT PRIMARY KEY,
        [GL_Code]   NVARCHAR(100) NOT NULL,
        [IsActive]  BIT NOT NULL DEFAULT 1
    )
END
GO

-- ============================================
-- 17. Metadata Configuration Table (Generic)
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'MetadataConfig')
BEGIN
    CREATE TABLE [dbo].[MetadataConfig] (
        [ConfigID]      INT IDENTITY(1,1) PRIMARY KEY,
        [TableName]     NVARCHAR(100) NOT NULL,
        [DisplayName]   NVARCHAR(200) NOT NULL,
        [ValueColumn]   NVARCHAR(100) NOT NULL,
        [IsConfigurable] BIT NOT NULL DEFAULT 1,
        [SortOrder]     INT NOT NULL DEFAULT 0
    )
END
GO

-- ============================================
-- 17. Main Transaction Table: DemandFund
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'DemandFund')
BEGIN
    CREATE TABLE [dbo].[DemandFund] (
        [ID]                    INT IDENTITY(1,1) PRIMARY KEY,
        [InitiativeTitle]       NVARCHAR(500) NULL,
        [Description]           NVARCHAR(MAX) NULL,
        [Demand_TypeID]         INT NULL,
        [DAMO_Approved]         BIT NOT NULL DEFAULT 0,
        [Engineering_LeadID]    INT NULL,
        [Funding_SourceID]      INT NULL,
        [Funds_Approved_ByID]   INT NULL,
        [CAPEX_OPEX_ID]         INT NULL,
        [GL_CodeID]             INT NULL,
        [Phase_DescriptionID]   INT NULL,
        [Primary_Business_Owner] NVARCHAR(500) NULL,
        [Remarks]               NVARCHAR(MAX) NULL,
        [Business_VerticalID]   INT NULL,
        [Digital_Project]       BIT NOT NULL DEFAULT 0,
        [Delivery_Manager]      NVARCHAR(200) NULL,
        [Initiative_TypeID]     INT NULL,
        [Platform_OwnerID]      INT NULL,
        [Portfolio_HeadID]      INT NULL,
        [Technology_VerticalID] INT NULL,
        [Initiative_SizeID]     INT NULL,
        [Project_TypeID]        INT NULL,
        [Document1_FileName]    NVARCHAR(500) NULL,
        [Document1_Path]        NVARCHAR(1000) NULL,
        [AdditionalDoc_FileName] NVARCHAR(500) NULL,
        [AdditionalDoc_Path]    NVARCHAR(1000) NULL,
        [CreatedDate]           DATETIME NOT NULL DEFAULT GETDATE(),
        [CreatedBy]             NVARCHAR(100) NULL,
        [ModifiedDate]          DATETIME NULL,
        [ModifiedBy]            NVARCHAR(100) NULL,
        [IsActive]              BIT NOT NULL DEFAULT 1,

        CONSTRAINT FK_DemandFund_DemandType FOREIGN KEY ([Demand_TypeID]) REFERENCES [DAMO_Type]([ID]),
        CONSTRAINT FK_DemandFund_EngLead FOREIGN KEY ([Engineering_LeadID]) REFERENCES [EngineeringTeam]([ID]),
        CONSTRAINT FK_DemandFund_FundSource FOREIGN KEY ([Funding_SourceID]) REFERENCES [Funding_Source_Type]([ID]),
        CONSTRAINT FK_DemandFund_FundApproval FOREIGN KEY ([Funds_Approved_ByID]) REFERENCES [FundApproval]([ID]),
        CONSTRAINT FK_DemandFund_Phase FOREIGN KEY ([Phase_DescriptionID]) REFERENCES [Phase_Description]([ID]),
        CONSTRAINT FK_DemandFund_BizVertical FOREIGN KEY ([Business_VerticalID]) REFERENCES [Primary_Vertical]([ID]),
        CONSTRAINT FK_DemandFund_InitType FOREIGN KEY ([Initiative_TypeID]) REFERENCES [Initiative_Type]([ID]),
        CONSTRAINT FK_DemandFund_PlatformOwner FOREIGN KEY ([Platform_OwnerID]) REFERENCES [Platform_Owner]([ID]),
        CONSTRAINT FK_DemandFund_PortfolioHead FOREIGN KEY ([Portfolio_HeadID]) REFERENCES [Portfolio_Head]([ID]),
        CONSTRAINT FK_DemandFund_TShirt FOREIGN KEY ([Initiative_SizeID]) REFERENCES [TShirt_Size]([ID]),
        CONSTRAINT FK_DemandFund_GLCode FOREIGN KEY ([GL_CodeID]) REFERENCES [GL_Code]([ID]),
        CONSTRAINT FK_DemandFund_ProjectType FOREIGN KEY ([Project_TypeID]) REFERENCES [Project_Type]([ID]),
        CONSTRAINT FK_DemandFund_TechVertical FOREIGN KEY ([Technology_VerticalID]) REFERENCES [Technology_Vertical]([ID])
    )
END
GO

-- ============================================
-- 18. Audit Log Table
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'AuditLog')
BEGIN
    CREATE TABLE [dbo].[AuditLog] (
        [LogID]         INT IDENTITY(1,1) PRIMARY KEY,
        [TableName]     NVARCHAR(100) NOT NULL,
        [Action]        NVARCHAR(50) NOT NULL,
        [RecordID]      INT NULL,
        [OldValues]     NVARCHAR(MAX) NULL,
        [NewValues]     NVARCHAR(MAX) NULL,
        [ActionDate]    DATETIME NOT NULL DEFAULT GETDATE(),
        [ActionBy]      NVARCHAR(100) NULL
    )
END
GO

PRINT 'All tables created successfully.'
GO
