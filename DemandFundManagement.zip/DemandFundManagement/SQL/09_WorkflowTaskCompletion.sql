-- Add CompletionPercentage to WorkflowTasks for tracking task progress
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('WorkflowTasks') AND name = 'CompletionPercentage')
BEGIN
    ALTER TABLE WorkflowTasks ADD CompletionPercentage INT NOT NULL DEFAULT 0;
END
GO
