-- ============================================
-- DemandFundManagement - Workflow Designer Tables
-- Visual Workflow Definitions + Messaging
-- ============================================

USE [DemandFundManagement]
GO

-- ============================================
-- 1. Workflow Definitions (stores designer JSON)
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WorkflowDefinitions')
BEGIN
    CREATE TABLE [dbo].[WorkflowDefinitions] (
        [DefinitionID]  INT IDENTITY(1,1) PRIMARY KEY,
        [Name]          NVARCHAR(300) NOT NULL,
        [Description]   NVARCHAR(2000) NULL,
        [WorkflowJSON]  NVARCHAR(MAX) NOT NULL,
        [Status]        NVARCHAR(50) NOT NULL DEFAULT 'Draft',  -- Draft, Published, Archived
        [CreatedDate]   DATETIME NOT NULL DEFAULT GETDATE(),
        [CreatedBy]     NVARCHAR(100) NULL,
        [ModifiedDate]  DATETIME NULL,
        [ModifiedBy]    NVARCHAR(100) NULL,
        [IsActive]      BIT NOT NULL DEFAULT 1
    )
    PRINT 'Created table: WorkflowDefinitions'
END
GO

-- ============================================
-- 2. Workflow Messages (in-app chat)
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WorkflowMessages')
BEGIN
    CREATE TABLE [dbo].[WorkflowMessages] (
        [MessageID]     INT IDENTITY(1,1) PRIMARY KEY,
        [SenderID]      INT NOT NULL,
        [ReceiverID]    INT NOT NULL,
        [Message]       NVARCHAR(4000) NOT NULL,
        [IsRead]        BIT NOT NULL DEFAULT 0,
        [SentDate]      DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Messages_Sender FOREIGN KEY ([SenderID]) REFERENCES [AppUsers]([UserID]),
        CONSTRAINT FK_Messages_Receiver FOREIGN KEY ([ReceiverID]) REFERENCES [AppUsers]([UserID])
    )
    PRINT 'Created table: WorkflowMessages'
END
GO

PRINT 'Workflow Designer tables created successfully.'
GO
