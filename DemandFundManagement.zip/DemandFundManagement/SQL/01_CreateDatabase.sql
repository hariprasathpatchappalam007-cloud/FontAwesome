-- ============================================
-- DemandFundManagement Database Creation Script
-- Vendor: Dubai Islamic Bank
-- ============================================

USE [master]
GO

-- Create SQL Login for the application
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'DFMAppUser')
BEGIN
    CREATE LOGIN [DFMAppUser] WITH PASSWORD = N'D!B_DFM@2026#Secure', 
        DEFAULT_DATABASE = [DemandFundManagement], 
        CHECK_EXPIRATION = OFF, 
        CHECK_POLICY = ON
END
GO

-- Create Database
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'DemandFundManagement')
BEGIN
    CREATE DATABASE [DemandFundManagement]
END
GO

USE [DemandFundManagement]
GO

-- Create Database User mapped to the login
-- NOTE: All role management is handled at the application level.
-- The DB user has db_owner to perform all CRUD operations.
-- Access control (Admin vs Normal) is enforced by the application, not the database.
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'DFMAppUser')
BEGIN
    CREATE USER [DFMAppUser] FOR LOGIN [DFMAppUser]
    ALTER ROLE [db_owner] ADD MEMBER [DFMAppUser]
END
GO
