-- ============================================
-- DemandFundManagement - Workflow Engine Tables
-- Runtime Instances, Steps, Email Config, Decision Rules
-- ============================================

USE [DemandFundManagement]
GO

-- ============================================
-- 1. Alter WorkflowDefinitions: add LinkedTable column
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'WorkflowDefinitions' AND COLUMN_NAME = 'LinkedTable')
BEGIN
    ALTER TABLE [dbo].[WorkflowDefinitions] ADD [LinkedTable] NVARCHAR(100) NULL
    PRINT 'Added LinkedTable to WorkflowDefinitions'
END
GO

-- ============================================
-- 2. Workflow Instances (runtime execution of a workflow)
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WorkflowInstances')
BEGIN
    CREATE TABLE [dbo].[WorkflowInstances] (
        [InstanceID]        INT IDENTITY(1,1) PRIMARY KEY,
        [DefinitionID]      INT NOT NULL,
        [LinkedTable]       NVARCHAR(100) NOT NULL,
        [LinkedRecordID]    INT NOT NULL,
        [Status]            NVARCHAR(50) NOT NULL DEFAULT 'Running',  -- Running, Completed, Cancelled, Error
        [CurrentNodeId]     INT NULL,
        [InitiatedByUserID] INT NOT NULL,
        [InitiatedByName]   NVARCHAR(200) NULL,
        [StartedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        [CompletedDate]     DATETIME NULL,
        [WorkflowJSON]      NVARCHAR(MAX) NULL,  -- snapshot of definition at start
        [CreatedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_WFInst_Def FOREIGN KEY ([DefinitionID]) REFERENCES [WorkflowDefinitions]([DefinitionID]),
        CONSTRAINT FK_WFInst_User FOREIGN KEY ([InitiatedByUserID]) REFERENCES [AppUsers]([UserID])
    )
    PRINT 'Created table: WorkflowInstances'
END
GO

-- ============================================
-- 3. Workflow Instance Steps (tracks each node execution)
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WorkflowInstanceSteps')
BEGIN
    CREATE TABLE [dbo].[WorkflowInstanceSteps] (
        [StepID]            INT IDENTITY(1,1) PRIMARY KEY,
        [InstanceID]        INT NOT NULL,
        [NodeId]            INT NOT NULL,           -- matches node.id from workflow JSON
        [NodeType]          NVARCHAR(50) NOT NULL,
        [NodeLabel]         NVARCHAR(500) NULL,
        [Status]            NVARCHAR(50) NOT NULL DEFAULT 'Pending', -- Pending, Active, Completed, Skipped, Rejected
        [AssignedToUserID]  INT NULL,
        [AssignedToName]    NVARCHAR(200) NULL,
        [ActionDate]        DATETIME NULL,
        [ActionBy]          NVARCHAR(200) NULL,
        [Comments]          NVARCHAR(4000) NULL,
        [CreatedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_WFStep_Inst FOREIGN KEY ([InstanceID]) REFERENCES [WorkflowInstances]([InstanceID]),
        CONSTRAINT FK_WFStep_User FOREIGN KEY ([AssignedToUserID]) REFERENCES [AppUsers]([UserID])
    )
    PRINT 'Created table: WorkflowInstanceSteps'
END
GO

-- ============================================
-- 4. Link WorkflowTasks to Instances
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'WorkflowTasks' AND COLUMN_NAME = 'InstanceID')
BEGIN
    ALTER TABLE [dbo].[WorkflowTasks] ADD [InstanceID] INT NULL
    ALTER TABLE [dbo].[WorkflowTasks] ADD [StepID] INT NULL
    ALTER TABLE [dbo].[WorkflowTasks] ADD [LinkedTable] NVARCHAR(100) NULL
    ALTER TABLE [dbo].[WorkflowTasks] ADD [LinkedRecordID] INT NULL
    PRINT 'Added InstanceID, StepID, LinkedTable, LinkedRecordID to WorkflowTasks'
END
GO

-- ============================================
-- 5. Add LinkedTable/RecordID to WorkflowNotifications
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'WorkflowNotifications' AND COLUMN_NAME = 'InstanceID')
BEGIN
    ALTER TABLE [dbo].[WorkflowNotifications] ADD [InstanceID] INT NULL
    ALTER TABLE [dbo].[WorkflowNotifications] ADD [LinkedTable] NVARCHAR(100) NULL
    ALTER TABLE [dbo].[WorkflowNotifications] ADD [LinkedRecordID] INT NULL
    PRINT 'Added InstanceID, LinkedTable, LinkedRecordID to WorkflowNotifications'
END
GO

PRINT 'Workflow Engine tables created/updated successfully'
GO
