-- ============================================
-- DemandFundManagement - Data Insertion Script
-- Vendor: Dubai Islamic Bank
-- ============================================

USE [DemandFundManagement]
GO

-- ============================================
-- 1. User Roles
-- ============================================
IF NOT EXISTS (SELECT 1 FROM UserRoles)
BEGIN
    INSERT INTO [dbo].[UserRoles] ([RoleID], [RoleName], [IsActive]) VALUES (1, 'Admin', 1)
    INSERT INTO [dbo].[UserRoles] ([RoleID], [RoleName], [IsActive]) VALUES (2, 'Normal', 1)
END
GO

-- ============================================
-- 2. Default Admin User (Password: Admin@123)
--    Salt and Hash generated using SHA256
--    IMPORTANT: Change password on first login
-- ============================================
IF NOT EXISTS (SELECT 1 FROM AppUsers WHERE Username = 'admin')
BEGIN
    INSERT INTO [dbo].[AppUsers] ([Username], [PasswordHash], [PasswordSalt], [FullName], [Email], [RoleID], [IsEnabled], [CreatedBy])
    VALUES ('admin', 'PLACEHOLDER_HASH', 'PLACEHOLDER_SALT', 'System Administrator', 'admin@dib.ae', 1, 1, 'SYSTEM')
END
GO

-- ============================================
-- 3. Business Team
-- ============================================
DELETE FROM [dbo].[BusinessTeam]
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (1, 'Liabilties Business')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (2, 'Business Banking')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (3, 'Compliance')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (4, 'Risk')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (5, 'General Consumer Banking')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (6, 'Personal Finance')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (7, 'Digital Transformation - Digital')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (8, 'TMO')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (9, 'Corporate')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (10, 'Home Finance')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (11, 'General Assets')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (12, 'Auto Finance')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (13, 'Cards')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (14, 'Regulatory')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (15, 'Payments')
INSERT INTO [dbo].[BusinessTeam] ([ID], [Business_Team_Desc]) VALUES (16, 'Others')
GO

-- ============================================
-- 4. DAMO Type
-- ============================================
DELETE FROM [dbo].[DAMO_Type]
INSERT INTO [dbo].[DAMO_Type] ([ID], [DAMO_Type]) VALUES (1, 'Service Request')
INSERT INTO [dbo].[DAMO_Type] ([ID], [DAMO_Type]) VALUES (2, 'Fast Track')
INSERT INTO [dbo].[DAMO_Type] ([ID], [DAMO_Type]) VALUES (3, 'Strategic')
INSERT INTO [dbo].[DAMO_Type] ([ID], [DAMO_Type]) VALUES (4, 'N/A')
GO

-- ============================================
-- 5. Engineering Team
-- ============================================
DELETE FROM [dbo].[EngineeringTeam]
INSERT INTO [dbo].[EngineeringTeam] ([ID], [Engineering_Lead]) VALUES (1, 'Tarek')
INSERT INTO [dbo].[EngineeringTeam] ([ID], [Engineering_Lead]) VALUES (2, 'Habibur Rahman')
GO

-- ============================================
-- 6. Fund Approval
-- ============================================
DELETE FROM [dbo].[FundApproval]
INSERT INTO [dbo].[FundApproval] ([ID], [Fund_Approval_Type]) VALUES (1, 'ITC')
INSERT INTO [dbo].[FundApproval] ([ID], [Fund_Approval_Type]) VALUES (2, 'Memo')
INSERT INTO [dbo].[FundApproval] ([ID], [Fund_Approval_Type]) VALUES (3, 'Tech_Internal')
INSERT INTO [dbo].[FundApproval] ([ID], [Fund_Approval_Type]) VALUES (4, 'Others')
GO

-- ============================================
-- 7. Funding Source Type
-- ============================================
DELETE FROM [dbo].[Funding_Source_Type]
INSERT INTO [dbo].[Funding_Source_Type] ([ID], [Funding_Source_Type]) VALUES (2, 'Others')
INSERT INTO [dbo].[Funding_Source_Type] ([ID], [Funding_Source_Type]) VALUES (3, 'OPEX')
INSERT INTO [dbo].[Funding_Source_Type] ([ID], [Funding_Source_Type]) VALUES (4, 'CAPEX')
GO

-- ============================================
-- 8. Initiative Type
-- ============================================
DELETE FROM [dbo].[Initiative_Type]
INSERT INTO [dbo].[Initiative_Type] ([ID], [Initiative_Type]) VALUES (1, 'Tech_Internal')
INSERT INTO [dbo].[Initiative_Type] ([ID], [Initiative_Type]) VALUES (2, 'DAMO')
INSERT INTO [dbo].[Initiative_Type] ([ID], [Initiative_Type]) VALUES (3, 'L3 Incidents')
INSERT INTO [dbo].[Initiative_Type] ([ID], [Initiative_Type]) VALUES (4, 'Internal_Enhancements')
INSERT INTO [dbo].[Initiative_Type] ([ID], [Initiative_Type]) VALUES (5, 'Others')
INSERT INTO [dbo].[Initiative_Type] ([ID], [Initiative_Type]) VALUES (6, 'Not Yet Defined')
GO

-- ============================================
-- 9. Phase Description
-- ============================================
DELETE FROM [dbo].[Phase_Description]
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (2, 'Concept')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (3, 'Initial Discussion and Expansion')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (4, 'Design Approach')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (5, 'Pipeline')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (6, 'Story Gromming / Architecture Detailing')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (7, 'Development')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (8, 'Sprint Development')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (9, 'UAT')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (10, 'Staging')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (11, 'Production Rollout')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (12, 'Future Plan')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (13, 'Planned')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (14, 'Under Progress')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (15, 'Completed')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (16, 'Cancelled')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (17, 'Closed')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (18, 'Dropped')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (19, 'Hold')
INSERT INTO [dbo].[Phase_Description] ([ID], [Phase_Description]) VALUES (20, 'Future - To be Started')
GO

-- ============================================
-- 10. Platform Owner
-- ============================================
DELETE FROM [dbo].[Platform_Owner]
INSERT INTO [dbo].[Platform_Owner] ([ID], [Platform_Owner]) VALUES (1, 'Srini CB')
INSERT INTO [dbo].[Platform_Owner] ([ID], [Platform_Owner]) VALUES (2, 'Mahimraj Mahesh')
INSERT INTO [dbo].[Platform_Owner] ([ID], [Platform_Owner]) VALUES (3, 'Archana')
INSERT INTO [dbo].[Platform_Owner] ([ID], [Platform_Owner]) VALUES (4, 'Fathullah')
GO

-- ============================================
-- 11. Portfolio Head
-- ============================================
DELETE FROM [dbo].[Portfolio_Head]
INSERT INTO [dbo].[Portfolio_Head] ([ID], [Portfolio_Head]) VALUES (1, 'Syed Nouman Bokhari')
INSERT INTO [dbo].[Portfolio_Head] ([ID], [Portfolio_Head]) VALUES (2, 'Naveed Rashid')
INSERT INTO [dbo].[Portfolio_Head] ([ID], [Portfolio_Head]) VALUES (3, 'Ramzi Rizwan')
INSERT INTO [dbo].[Portfolio_Head] ([ID], [Portfolio_Head]) VALUES (4, 'Ebrahim Marzoughi')
GO

-- ============================================
-- 12. Primary Vertical
-- ============================================
DELETE FROM [dbo].[Primary_Vertical]
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (1, 'Enterprise Core Business Technologies')
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (3, 'Enterprise Data & Analytics Technologies')
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (5, 'Enterprise Infrastructure Services (EIS)')
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (7, 'Enterprise Architecture & Integration (EA & EI)')
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (9, 'Innovation Delivery Hub (IDH)')
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (11, 'Enterprise Risk & Compliance')
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (13, 'Enterprise RTB Services')
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (15, 'Enterprise IT Governance & Subsidiaries')
INSERT INTO [dbo].[Primary_Vertical] ([ID], [Primary_Vertical]) VALUES (17, 'Consumer Banking Engineering Team (CET)')
GO

-- ============================================
-- 13. Spend Category
-- ============================================
DELETE FROM [dbo].[Spend_Category]
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (1, 'Hardware & Infra')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (2, 'AMC - Hardware & Infra')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (3, 'Software Licensing')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (4, 'AMC - Software Licensing')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (5, 'Escrow')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (6, 'Project Governance')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (7, 'Project Governance')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (8, 'Business Analysis')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (9, 'Architecture /Design')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (10, 'Other Professional Services')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (11, 'Training')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (12, 'Integration')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (13, 'Development')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (14, 'AMC - Support Operations')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (15, 'Quality Assurance Professional Services')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (16, 'Security Testing')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (17, 'Training')
INSERT INTO [dbo].[Spend_Category] ([ID], [Spend_Category]) VALUES (18, 'Others')
GO

-- ============================================
-- 14. Spend Type
-- ============================================
DELETE FROM [dbo].[Spend_Type]
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (1, 'Hardware Purchase')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (2, 'Hardware Rental')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (3, 'Hardware AMC')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (4, 'Software License Purchase')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (5, 'Software License Subscription')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (6, 'Software License AMC')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (7, 'Escrow Agreement')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (8, 'Project Management Services')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (9, 'Project Coordinator')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (10, 'Business Analysis')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (11, 'Architecture /Design')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (12, 'SME Consulting Services')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (13, 'Training')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (14, 'Application/Interface Development')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (15, 'Software Customization')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (16, 'Software Installation & Configuration')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (17, 'Hardware Installation & Configuration')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (18, 'Annual Support Operations')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (19, 'QA Functional Testing')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (20, 'QA Integration Testing')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (21, 'QA Performance Testing')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (22, 'QA Load Testing')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (23, 'SEC Penetration Testing')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (24, 'UAT Functional Testing')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (25, 'Professional Certification')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (26, 'Quality Assurance (External)')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (27, 'Travel & Accommodation')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (28, 'Travel & Accommodation')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (29, 'Premises Rent')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (30, 'Premises Fit out')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (31, 'Buffer')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (32, 'Others')
INSERT INTO [dbo].[Spend_Type] ([ID], [Spend_Type]) VALUES (33, 'General Funding')
GO

-- ============================================
-- 15. TShirt Size
-- ============================================
DELETE FROM [dbo].[TShirt_Size]
INSERT INTO [dbo].[TShirt_Size] ([ID], [TShirt_Size]) VALUES (1, 'XS')
INSERT INTO [dbo].[TShirt_Size] ([ID], [TShirt_Size]) VALUES (2, 'S')
INSERT INTO [dbo].[TShirt_Size] ([ID], [TShirt_Size]) VALUES (3, 'M')
INSERT INTO [dbo].[TShirt_Size] ([ID], [TShirt_Size]) VALUES (4, 'L')
INSERT INTO [dbo].[TShirt_Size] ([ID], [TShirt_Size]) VALUES (5, 'XL')
INSERT INTO [dbo].[TShirt_Size] ([ID], [TShirt_Size]) VALUES (6, 'XXL')
GO

-- ============================================
-- 16. Metadata Configuration
-- ============================================
DELETE FROM [dbo].[MetadataConfig]
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('BusinessTeam', 'Business Team', 'Business_Team_Desc', 1, 1)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('DAMO_Type', 'DAMO Type', 'DAMO_Type', 1, 2)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('EngineeringTeam', 'Engineering Team', 'Engineering_Lead', 1, 3)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('FundApproval', 'Fund Approval', 'Fund_Approval_Type', 1, 4)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Funding_Source_Type', 'Funding Source Type', 'Funding_Source_Type', 1, 5)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Initiative_Type', 'Initiative Type', 'Initiative_Type', 1, 6)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Phase_Description', 'Phase Description', 'Phase_Description', 1, 7)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Platform_Owner', 'Platform Owner', 'Platform_Owner', 1, 8)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Portfolio_Head', 'Portfolio Head', 'Portfolio_Head', 1, 9)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Primary_Vertical', 'Primary Vertical', 'Primary_Vertical', 1, 10)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Spend_Category', 'Spend Category', 'Spend_Category', 1, 11)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Spend_Type', 'Spend Type', 'Spend_Type', 1, 12)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('TShirt_Size', 'T-Shirt Size', 'TShirt_Size', 1, 13)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Technology_Vertical', 'Technology Vertical', 'Technology_Vertical', 1, 14)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('Project_Type', 'Project Type', 'Project_Type', 1, 15)
INSERT INTO [dbo].[MetadataConfig] ([TableName], [DisplayName], [ValueColumn], [IsConfigurable], [SortOrder]) VALUES ('GL_Code', 'GL Code', 'GL_Code', 1, 16)
GO

-- ============================================
-- 17. Technology Vertical
-- ============================================
DELETE FROM [dbo].[Technology_Vertical]
INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (1, 'Core Banking')
INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (2, 'Digital Banking')
INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (3, 'Data & Analytics')
INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (4, 'Infrastructure')
INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (5, 'Security')
INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (6, 'Integration')
INSERT INTO [dbo].[Technology_Vertical] ([ID], [Technology_Vertical]) VALUES (7, 'Others')
GO

-- ============================================
-- 18. Project Type
-- ============================================
DELETE FROM [dbo].[Project_Type]
INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (1, 'New Development')
INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (2, 'Enhancement')
INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (3, 'Maintenance')
INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (4, 'Migration')
INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (5, 'Infrastructure')
INSERT INTO [dbo].[Project_Type] ([ID], [Project_Type]) VALUES (6, 'Others')
GO

-- ============================================
-- 19. GL Code
-- ============================================
DELETE FROM [dbo].[GL_Code]
INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (1, 'GL-1001')
INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (2, 'GL-1002')
INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (3, 'GL-2001')
INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (4, 'GL-2002')
INSERT INTO [dbo].[GL_Code] ([ID], [GL_Code]) VALUES (5, 'GL-3001')
GO

PRINT 'All data inserted successfully.'
GO
