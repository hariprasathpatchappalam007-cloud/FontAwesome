-- ============================================
-- DemandFundManagement - Workflow Tables
-- Task Assignment, Approvals, Status, Notifications
-- ============================================

USE [DemandFundManagement]
GO

-- ============================================
-- 1. Workflow Tasks
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WorkflowTasks')
BEGIN
    CREATE TABLE [dbo].[WorkflowTasks] (
        [TaskID]            INT IDENTITY(1,1) PRIMARY KEY,
        [Title]             NVARCHAR(500) NOT NULL,
        [Description]       NVARCHAR(4000) NULL,
        [Status]            NVARCHAR(50) NOT NULL DEFAULT 'Backlog',  -- Backlog, ToDo, InProgress, Review, Done
        [Priority]          NVARCHAR(20) NOT NULL DEFAULT 'Medium',   -- Low, Medium, High, Critical
        [AssignedToUserID]  INT NULL,
        [AssignedToName]    NVARCHAR(200) NULL,
        [DemandFundID]      INT NULL,
        [DueDate]           DATE NULL,
        [SortOrder]         INT NOT NULL DEFAULT 0,
        [CreatedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        [CreatedBy]         NVARCHAR(100) NULL,
        [ModifiedDate]      DATETIME NULL,
        [ModifiedBy]        NVARCHAR(100) NULL,
        [IsActive]          BIT NOT NULL DEFAULT 1,
        CONSTRAINT FK_WorkflowTasks_AssignedTo FOREIGN KEY ([AssignedToUserID]) REFERENCES [AppUsers]([UserID]),
        CONSTRAINT FK_WorkflowTasks_DemandFund FOREIGN KEY ([DemandFundID]) REFERENCES [DemandFund]([ID])
    )
    PRINT 'Created table: WorkflowTasks'
END
GO

-- ============================================
-- 2. Workflow Approvals
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WorkflowApprovals')
BEGIN
    CREATE TABLE [dbo].[WorkflowApprovals] (
        [ApprovalID]        INT IDENTITY(1,1) PRIMARY KEY,
        [TaskID]            INT NOT NULL,
        [ApproverUserID]    INT NOT NULL,
        [ApproverName]      NVARCHAR(200) NULL,
        [ApprovalStatus]    NVARCHAR(50) NOT NULL DEFAULT 'Pending', -- Pending, Approved, Rejected
        [Comments]          NVARCHAR(4000) NULL,
        [ApprovalDate]      DATETIME NULL,
        [CreatedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        [CreatedBy]         NVARCHAR(100) NULL,
        CONSTRAINT FK_WorkflowApprovals_Task FOREIGN KEY ([TaskID]) REFERENCES [WorkflowTasks]([TaskID]),
        CONSTRAINT FK_WorkflowApprovals_Approver FOREIGN KEY ([ApproverUserID]) REFERENCES [AppUsers]([UserID])
    )
    PRINT 'Created table: WorkflowApprovals'
END
GO

-- ============================================
-- 3. Workflow Status History
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WorkflowStatusHistory')
BEGIN
    CREATE TABLE [dbo].[WorkflowStatusHistory] (
        [HistoryID]         INT IDENTITY(1,1) PRIMARY KEY,
        [TaskID]            INT NOT NULL,
        [OldStatus]         NVARCHAR(50) NULL,
        [NewStatus]         NVARCHAR(50) NOT NULL,
        [ChangedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        [ChangedBy]         NVARCHAR(100) NULL,
        [Remarks]           NVARCHAR(1000) NULL,
        CONSTRAINT FK_StatusHistory_Task FOREIGN KEY ([TaskID]) REFERENCES [WorkflowTasks]([TaskID])
    )
    PRINT 'Created table: WorkflowStatusHistory'
END
GO

-- ============================================
-- 4. Workflow Notifications
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'WorkflowNotifications')
BEGIN
    CREATE TABLE [dbo].[WorkflowNotifications] (
        [NotificationID]    INT IDENTITY(1,1) PRIMARY KEY,
        [UserID]            INT NOT NULL,
        [TaskID]            INT NULL,
        [Message]           NVARCHAR(1000) NOT NULL,
        [NotificationType]  NVARCHAR(50) NOT NULL DEFAULT 'Info', -- Info, Assignment, Approval, StatusChange
        [IsRead]            BIT NOT NULL DEFAULT 0,
        [CreatedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Notifications_User FOREIGN KEY ([UserID]) REFERENCES [AppUsers]([UserID]),
        CONSTRAINT FK_Notifications_Task FOREIGN KEY ([TaskID]) REFERENCES [WorkflowTasks]([TaskID])
    )
    PRINT 'Created table: WorkflowNotifications'
END
GO

PRINT 'Workflow tables created successfully.'
GO
