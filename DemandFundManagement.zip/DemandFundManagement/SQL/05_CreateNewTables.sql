-- ============================================
-- DemandFundManagement - New Tables
-- Spending Allocation, Approved Funding Programs, Funding Line Items
-- ============================================

USE [DemandFundManagement]
GO

-- ============================================
-- 1. Spending Allocation
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'SpendingAllocation')
BEGIN
    CREATE TABLE [dbo].[SpendingAllocation] (
        [ID]                INT IDENTITY(1,1) PRIMARY KEY,
        [Date]              DATE NULL,
        [FundingLineItem]   NVARCHAR(500) NULL,
        [Description]       NVARCHAR(2000) NULL,
        [AllocationType]    NVARCHAR(200) NULL,
        [Year]              NVARCHAR(10) NULL,
        [PlannedDate]       DATE NULL,
        [Team]              NVARCHAR(200) NULL,
        [Platform]          NVARCHAR(200) NULL,
        [Vendor]            NVARCHAR(200) NULL,
        [DRMCategory]       NVARCHAR(200) NULL,
        [DRMProgram]        NVARCHAR(200) NULL,
        [MemoDate]          DATE NULL,
        [CAMID]             NVARCHAR(100) NULL,
        [ActualAmount]      DECIMAL(18,2) NULL,
        [AllocationAmount]  DECIMAL(18,2) NULL,
        [LPONumber]         NVARCHAR(100) NULL,
        [AMSRequestNumber]  NVARCHAR(100) NULL,
        [Requester]         NVARCHAR(200) NULL,
        [Remarks]           NVARCHAR(4000) NULL,
        [Remarks2]          NVARCHAR(4000) NULL,
        [CreatedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        [CreatedBy]         NVARCHAR(100) NULL,
        [ModifiedDate]      DATETIME NULL,
        [ModifiedBy]        NVARCHAR(100) NULL
    )
END
GO

-- ============================================
-- 2. Approved Funding Programs
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'ApprovedFundingPrograms')
BEGIN
    CREATE TABLE [dbo].[ApprovedFundingPrograms] (
        [ID]                INT IDENTITY(1,1) PRIMARY KEY,
        [Title]             NVARCHAR(500) NULL,
        [Type]              NVARCHAR(200) NULL,
        [DemandID]          NVARCHAR(100) NULL,
        [Approver]          NVARCHAR(200) NULL,
        [PrimaryLead]       NVARCHAR(200) NULL,
        [GL]                NVARCHAR(100) NULL,
        [CAPEX]             DECIMAL(18,2) NULL,
        [CAPEXType]         NVARCHAR(200) NULL,
        [Status]            NVARCHAR(100) NULL,
        [FundAmount]        DECIMAL(18,2) NULL,
        [Consumed]          DECIMAL(18,2) NULL,
        [Available]         DECIMAL(18,2) NULL,
        [Planned]           DECIMAL(18,2) NULL,
        [ApprovalForm]      NVARCHAR(500) NULL,
        [Remarks]           NVARCHAR(4000) NULL,
        [ProgramOwner]      NVARCHAR(200) NULL,
        [CreatedDate]       DATETIME NOT NULL DEFAULT GETDATE(),
        [CreatedBy]         NVARCHAR(100) NULL,
        [ModifiedDate]      DATETIME NULL,
        [ModifiedBy]        NVARCHAR(100) NULL
    )
END
GO

-- ============================================
-- 3. Funding Line Items
-- ============================================
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'FundingLineItems')
BEGIN
    CREATE TABLE [dbo].[FundingLineItems] (
        [ID]                    INT IDENTITY(1,1) PRIMARY KEY,
        [ProgramTitle]          NVARCHAR(500) NULL,
        [Title]                 NVARCHAR(500) NULL,
        [AllocationType]        NVARCHAR(200) NULL,
        [AllocationSubType]     NVARCHAR(200) NULL,
        [LineItemID]            NVARCHAR(100) NULL,
        [SubCAPEXID]            NVARCHAR(100) NULL,
        [Vendor]                NVARCHAR(200) NULL,
        [Amount]                DECIMAL(18,2) NULL,
        [Consumed]              DECIMAL(18,2) NULL,
        [BlockedAmount]         DECIMAL(18,2) NULL,
        [RemainingAmount]       DECIMAL(18,2) NULL,
        [CreatedDate]           DATETIME NOT NULL DEFAULT GETDATE(),
        [CreatedBy]             NVARCHAR(100) NULL,
        [ModifiedDate]          DATETIME NULL,
        [ModifiedBy]            NVARCHAR(100) NULL
    )
END
GO
