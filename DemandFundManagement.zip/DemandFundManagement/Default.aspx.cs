using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDashboard();
                LoadChartData();
            }
        }

        private void LoadDashboard()
        {
            try
            {
                // Total demands
                object total = DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM DemandFund WHERE IsActive = 1");
                lblTotalDemands.Text = Convert.ToInt32(total).ToString();

                // Active demands (not completed/closed)
                object active = DatabaseHelper.ExecuteScalar(
                    @"SELECT COUNT(*) FROM DemandFund d 
                      LEFT JOIN Phase_Description p ON d.Phase_DescriptionID = p.ID
                      WHERE d.IsActive = 1 AND (p.Phase_Description NOT IN ('Completed','Closed','Cancelled','Dropped') OR d.Phase_DescriptionID IS NULL)");
                lblActiveDemands.Text = Convert.ToInt32(active).ToString();

                // In Progress
                object inProgress = DatabaseHelper.ExecuteScalar(
                    @"SELECT COUNT(*) FROM DemandFund d 
                      INNER JOIN Phase_Description p ON d.Phase_DescriptionID = p.ID
                      WHERE d.IsActive = 1 AND p.Phase_Description = 'Under Progress'");
                lblInProgress.Text = Convert.ToInt32(inProgress).ToString();

                // Completed
                object completed = DatabaseHelper.ExecuteScalar(
                    @"SELECT COUNT(*) FROM DemandFund d 
                      INNER JOIN Phase_Description p ON d.Phase_DescriptionID = p.ID
                      WHERE d.IsActive = 1 AND p.Phase_Description = 'Completed'");
                lblCompleted.Text = Convert.ToInt32(completed).ToString();

                // Digital Projects
                object digital = DatabaseHelper.ExecuteScalar(
                    "SELECT COUNT(*) FROM DemandFund WHERE IsActive = 1 AND Digital_Project = 1");
                lblDigitalProjects.Text = Convert.ToInt32(digital).ToString();

                // New table counts
                object spendCount = DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM SpendingAllocation");
                lblTotalSpending.Text = Convert.ToInt32(spendCount).ToString();

                object progCount = DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM ApprovedFundingPrograms");
                lblTotalFundingPrograms.Text = Convert.ToInt32(progCount).ToString();

                object liCount = DatabaseHelper.ExecuteScalar("SELECT COUNT(*) FROM FundingLineItems");
                lblTotalLineItems.Text = Convert.ToInt32(liCount).ToString();

                // Financial summaries
                object totalActual = DatabaseHelper.ExecuteScalar("SELECT ISNULL(SUM(ActualAmount), 0) FROM SpendingAllocation");
                lblTotalActualAmount.Text = Convert.ToDecimal(totalActual).ToString("N0");

                object totalAlloc = DatabaseHelper.ExecuteScalar("SELECT ISNULL(SUM(AllocationAmount), 0) FROM SpendingAllocation");
                lblTotalAllocationAmount.Text = Convert.ToDecimal(totalAlloc).ToString("N0");

                object totalFund = DatabaseHelper.ExecuteScalar("SELECT ISNULL(SUM(FundAmount), 0) FROM ApprovedFundingPrograms");
                lblTotalFundAmount.Text = Convert.ToDecimal(totalFund).ToString("N0");

                object totalConsumed = DatabaseHelper.ExecuteScalar("SELECT ISNULL(SUM(Consumed), 0) FROM ApprovedFundingPrograms");
                lblTotalConsumed.Text = Convert.ToDecimal(totalConsumed).ToString("N0");

                object totalAvail = DatabaseHelper.ExecuteScalar("SELECT ISNULL(SUM(Available), 0) FROM ApprovedFundingPrograms");
                lblTotalAvailable.Text = Convert.ToDecimal(totalAvail).ToString("N0");

                // Recent demands grid
                DataTable dt = DatabaseHelper.GetDemandFundList();
                gvRecentDemands.DataSource = dt;
                gvRecentDemands.DataBind();

                // Recent spending
                DataTable dtSpend = DatabaseHelper.GetSpendingAllocations();
                gvRecentSpending.DataSource = dtSpend;
                gvRecentSpending.DataBind();

                // Recent programs
                DataTable dtProg = DatabaseHelper.GetApprovedFundingPrograms();
                gvRecentPrograms.DataSource = dtProg;
                gvRecentPrograms.DataBind();

                // Recent line items
                DataTable dtLI = DatabaseHelper.GetFundingLineItems();
                gvRecentLineItems.DataSource = dtLI;
                gvRecentLineItems.DataBind();

                // Workflow Stats
                try
                {
                    int userId = Session["UserID"] != null ? Convert.ToInt32(Session["UserID"]) : 0;
                    DataTable wfStats = DatabaseHelper.GetWorkflowDashboardStats(userId);
                    if (wfStats.Rows.Count > 0)
                    {
                        DataRow ws = wfStats.Rows[0];
                        lblWfCompleted.Text = ws["CompletedTasks"].ToString();
                        lblWfPending.Text = ws["PendingTasks"].ToString();
                        lblWfMyActions.Text = ws["MyPendingActions"].ToString();
                        lblWfRunning.Text = ws["RunningWorkflows"].ToString();
                        lblWfCompletedWf.Text = ws["CompletedWorkflows"].ToString();
                    }
                }
                catch { /* tables may not exist yet */ }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Dashboard Error: " + ex.Message);
            }
        }

        private void LoadChartData()
        {
            try
            {
                // Phase Distribution
                DataTable phaseData = DatabaseHelper.GetDashboardPhaseDistribution();
                SetChartData(phaseData, "PhaseName", "Count", hdnPhaseLabels, hdnPhaseData);

                // Initiative Type Distribution
                DataTable initTypeData = DatabaseHelper.GetDashboardInitiativeTypeDistribution();
                SetChartData(initTypeData, "TypeName", "Count", hdnInitTypeLabels, hdnInitTypeData);

                // Business Vertical Distribution
                DataTable verticalData = DatabaseHelper.GetDashboardBusinessVerticalDistribution();
                SetChartData(verticalData, "VerticalName", "Count", hdnVerticalLabels, hdnVerticalData);

                // Funding Source Distribution
                DataTable fundingData = DatabaseHelper.GetDashboardFundingSourceDistribution();
                SetChartData(fundingData, "SourceName", "Count", hdnFundingLabels, hdnFundingData);

                // Monthly Trend
                DataTable monthlyData = DatabaseHelper.GetDashboardMonthlyTrend();
                SetChartData(monthlyData, "MonthLabel", "Count", hdnMonthlyLabels, hdnMonthlyData);

                // Spending by Team
                DataTable spendTeam = DatabaseHelper.GetDashboardSpendingByTeam();
                SetChartDataDecimal(spendTeam, "TeamName", "TotalAmount", hdnSpendTeamLabels, hdnSpendTeamData);

                // Program Status Distribution
                DataTable progStatus = DatabaseHelper.GetDashboardProgramStatusDistribution();
                SetChartData(progStatus, "StatusName", "Count", hdnProgramStatusLabels, hdnProgramStatusData);

                // Spending by Platform
                DataTable spendPlat = DatabaseHelper.GetDashboardSpendingByPlatform();
                SetChartDataDecimal(spendPlat, "PlatformName", "TotalAmount", hdnSpendPlatformLabels, hdnSpendPlatformData);

                // Line Items by Vendor
                DataTable liVendor = DatabaseHelper.GetDashboardLineItemsByVendor();
                SetChartDataDecimal(liVendor, "VendorName", "TotalAmount", hdnLineItemVendorLabels, hdnLineItemVendorData);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Chart Data Error: " + ex.Message);
            }
        }

        private void SetChartData(DataTable dt, string labelCol, string dataCol,
            HiddenField hdnLabels, HiddenField hdnData)
        {
            List<string> labels = new List<string>();
            List<string> data = new List<string>();

            foreach (DataRow row in dt.Rows)
            {
                string label = row[labelCol] != DBNull.Value ? row[labelCol].ToString() : "N/A";
                label = label.Replace("\\", "\\\\").Replace("\"", "\\\"");
                labels.Add("\"" + label + "\"");
                data.Add(Convert.ToInt32(row[dataCol]).ToString());
            }

            hdnLabels.Value = "[" + string.Join(",", labels) + "]";
            hdnData.Value = "[" + string.Join(",", data) + "]";
        }

        private void SetChartDataDecimal(DataTable dt, string labelCol, string dataCol,
            HiddenField hdnLabels, HiddenField hdnData)
        {
            List<string> labels = new List<string>();
            List<string> data = new List<string>();

            foreach (DataRow row in dt.Rows)
            {
                string label = row[labelCol] != DBNull.Value ? row[labelCol].ToString() : "N/A";
                label = label.Replace("\\", "\\\\").Replace("\"", "\\\"");
                labels.Add("\"" + label + "\"");
                data.Add(Convert.ToDecimal(row[dataCol]).ToString("0.##"));
            }

            hdnLabels.Value = "[" + string.Join(",", labels) + "]";
            hdnData.Value = "[" + string.Join(",", data) + "]";
        }

        protected void gvRecentDemands_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvRecentDemands.PageIndex = e.NewPageIndex;
            LoadDashboard();
        }

        protected void gvRecentSpending_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvRecentSpending.PageIndex = e.NewPageIndex;
            LoadDashboard();
        }

        protected void gvRecentPrograms_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvRecentPrograms.PageIndex = e.NewPageIndex;
            LoadDashboard();
        }

        protected void gvRecentLineItems_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvRecentLineItems.PageIndex = e.NewPageIndex;
            LoadDashboard();
        }
    }
}
