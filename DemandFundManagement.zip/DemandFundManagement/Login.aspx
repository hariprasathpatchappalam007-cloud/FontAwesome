<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="DemandFundManagement.Login" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Demand Fund Management</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet" />
    <link href="Content/Site.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript">
        (function () {
            var t = localStorage.getItem('dfm-theme') || 'green';
            document.documentElement.setAttribute('data-theme', t);
        })();
    </script>
</head>
<body>
    <form id="form1" runat="server">
        <div class="login-wrapper">
            <div class="login-box">
                <h2>Demand Fund Management</h2>
                <div class="vendor-name">Dubai Islamic Bank</div>

                <asp:Panel ID="pnlMessage" runat="server" Visible="false">
                    <asp:Label ID="lblMessage" runat="server" />
                </asp:Panel>

                <div class="form-group">
                    <label for="txtUsername">Username</label>
                    <asp:TextBox ID="txtUsername" runat="server" CssClass="form-control" placeholder="Enter your username" MaxLength="100" />
                    <asp:RequiredFieldValidator ID="rfvUsername" runat="server" ControlToValidate="txtUsername"
                        ErrorMessage="Username is required" Display="Dynamic" ForeColor="Red" Font-Size="12px" />
                </div>

                <div class="form-group">
                    <label for="txtPassword">Password</label>
                    <asp:TextBox ID="txtPassword" runat="server" CssClass="form-control" TextMode="Password" placeholder="Enter your password" MaxLength="100" />
                    <asp:RequiredFieldValidator ID="rfvPassword" runat="server" ControlToValidate="txtPassword"
                        ErrorMessage="Password is required" Display="Dynamic" ForeColor="Red" Font-Size="12px" />
                </div>

                <asp:Button ID="btnLogin" runat="server" Text="Sign In" CssClass="btn btn-primary" OnClick="btnLogin_Click" />
                <div style="text-align:center; margin-top:20px; color:var(--text-muted); font-size:12px;">
                    <span class="glyphicon glyphicon-lock"></span> Secure Login
                </div>
                <div class="login-theme-switcher">
                    <button type="button" class="theme-btn theme-btn-green" onclick="setTheme('green')" title="Green"></button>
                    <button type="button" class="theme-btn theme-btn-light" onclick="setTheme('light')" title="Light"></button>
                    <button type="button" class="theme-btn theme-btn-blue" onclick="setTheme('blue')" title="Light Blue"></button>
                    <button type="button" class="theme-btn theme-btn-night" onclick="setTheme('night')" title="Night"></button>
                    <button type="button" class="theme-btn theme-btn-pink" onclick="setTheme('pink')" title="Pink"></button>
                    <button type="button" class="theme-btn theme-btn-aqua" onclick="setTheme('aqua')" title="Aqua"></button>
                    <button type="button" class="theme-btn theme-btn-forest" onclick="setTheme('forest')" title="Forest"></button>
                    <button type="button" class="theme-btn theme-btn-wood" onclick="setTheme('wood')" title="Wood"></button>
                </div>
            </div>
        </div>
    </form>
    <script type="text/javascript">
        function setTheme(theme) {
            document.body.setAttribute('data-theme', theme);
            document.documentElement.setAttribute('data-theme', theme);
            localStorage.setItem('dfm-theme', theme);
        }
        (function () {
            var saved = localStorage.getItem('dfm-theme') || 'green';
            document.body.setAttribute('data-theme', saved);
        })();
    </script>
</body>
</html>
