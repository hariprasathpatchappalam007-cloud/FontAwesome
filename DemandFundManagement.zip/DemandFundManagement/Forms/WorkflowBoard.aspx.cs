using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class WorkflowBoard : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDropdowns();
                BindBoard();
                BindNotifications();
            }
            else
            {
                // Handle task load via __doPostBack
                string eventArg = Request["__EVENTARGUMENT"];
                if (!string.IsNullOrEmpty(eventArg) && eventArg.StartsWith("LOAD|"))
                {
                    int taskId;
                    if (int.TryParse(eventArg.Substring(5), out taskId) && taskId > 0)
                    {
                        LoadTaskForEdit(taskId);
                    }
                }
            }
        }

        private void LoadDropdowns()
        {
            // Users dropdown
            DataTable users = DatabaseHelper.GetAllUsers();
            ddlAssignTo.Items.Clear();
            ddlAssignTo.Items.Add(new ListItem("-- Select --", ""));
            foreach (DataRow row in users.Rows)
            {
                ddlAssignTo.Items.Add(new ListItem(row["FullName"].ToString(), row["UserID"].ToString()));
            }

            ddlApprover.Items.Clear();
            ddlApprover.Items.Add(new ListItem("-- Select Approver --", ""));
            foreach (DataRow row in users.Rows)
            {
                ddlApprover.Items.Add(new ListItem(row["FullName"].ToString(), row["UserID"].ToString()));
            }

            // Demand Fund dropdown
            DataTable demands = DatabaseHelper.GetDemandFundList();
            ddlDemandFund.Items.Clear();
            ddlDemandFund.Items.Add(new ListItem("-- None --", ""));
            foreach (DataRow row in demands.Rows)
            {
                string title = row["InitiativeTitle"].ToString();
                if (title.Length > 60) title = title.Substring(0, 57) + "...";
                ddlDemandFund.Items.Add(new ListItem("#" + row["ID"] + " - " + title, row["ID"].ToString()));
            }
        }

        private void BindBoard()
        {
            DataTable allTasks = DatabaseHelper.GetWorkflowTasks();

            DataView dvBacklog = new DataView(allTasks);
            dvBacklog.RowFilter = "Status = 'Backlog'";
            dvBacklog.Sort = "SortOrder ASC";
            rptBacklog.DataSource = dvBacklog;
            rptBacklog.DataBind();
            lblBacklogCount.Text = dvBacklog.Count.ToString();

            DataView dvToDo = new DataView(allTasks);
            dvToDo.RowFilter = "Status = 'ToDo'";
            dvToDo.Sort = "SortOrder ASC";
            rptToDo.DataSource = dvToDo;
            rptToDo.DataBind();
            lblToDoCount.Text = dvToDo.Count.ToString();

            DataView dvInProgress = new DataView(allTasks);
            dvInProgress.RowFilter = "Status = 'InProgress'";
            dvInProgress.Sort = "SortOrder ASC";
            rptInProgress.DataSource = dvInProgress;
            rptInProgress.DataBind();
            lblInProgressCount.Text = dvInProgress.Count.ToString();

            DataView dvReview = new DataView(allTasks);
            dvReview.RowFilter = "Status = 'Review'";
            dvReview.Sort = "SortOrder ASC";
            rptReview.DataSource = dvReview;
            rptReview.DataBind();
            lblReviewCount.Text = dvReview.Count.ToString();

            DataView dvDone = new DataView(allTasks);
            dvDone.RowFilter = "Status = 'Done'";
            dvDone.Sort = "SortOrder ASC";
            rptDone.DataSource = dvDone;
            rptDone.DataBind();
            lblDoneCount.Text = dvDone.Count.ToString();
        }

        private void BindNotifications()
        {
            if (Session["UserID"] == null) return;
            int userId = Convert.ToInt32(Session["UserID"]);

            int unread = DatabaseHelper.GetUnreadNotificationCount(userId);
            if (unread > 0)
            {
                lblNotifCount.Text = unread > 99 ? "99+" : unread.ToString();
                lblNotifCount.Visible = true;
            }
            else
            {
                lblNotifCount.Visible = false;
            }

            DataTable notifs = DatabaseHelper.GetNotifications(userId);
            if (notifs.Rows.Count > 0)
            {
                rptNotifications.DataSource = notifs;
                rptNotifications.DataBind();
                pnlNoNotifs.Visible = false;
            }
            else
            {
                pnlNoNotifs.Visible = true;
            }
        }

        private void LoadTaskForEdit(int taskId)
        {
            DataRow task = DatabaseHelper.GetWorkflowTaskById(taskId);
            if (task == null) return;

            LoadDropdowns();

            hfEditTaskId.Value = taskId.ToString();
            txtTaskTitle.Text = task["Title"].ToString();
            txtDescription.Text = task["Description"] != DBNull.Value ? task["Description"].ToString() : "";
            ddlPriority.SelectedValue = task["Priority"].ToString();
            ddlStatus.SelectedValue = task["Status"].ToString();

            if (task["AssignedToUserID"] != DBNull.Value)
            {
                string uid = task["AssignedToUserID"].ToString();
                if (ddlAssignTo.Items.FindByValue(uid) != null)
                    ddlAssignTo.SelectedValue = uid;
            }

            if (task["DemandFundID"] != DBNull.Value)
            {
                string did = task["DemandFundID"].ToString();
                if (ddlDemandFund.Items.FindByValue(did) != null)
                    ddlDemandFund.SelectedValue = did;
            }

            if (task["DueDate"] != DBNull.Value)
                txtDueDate.Text = Convert.ToDateTime(task["DueDate"]).ToString("yyyy-MM-dd");

            // Show approval section
            pnlApproval.Visible = true;
            btnDeleteTask.Visible = true;

            // Show completion percentage panel for workflow-linked tasks
            pnlCompletion.Visible = false;
            if (task.Table.Columns.Contains("InstanceID") && task["InstanceID"] != DBNull.Value)
            {
                pnlCompletion.Visible = true;
                int pct = task.Table.Columns.Contains("CompletionPercentage") && task["CompletionPercentage"] != DBNull.Value
                    ? Convert.ToInt32(task["CompletionPercentage"]) : 0;
                rangeCompletionBoard.Value = pct.ToString();
            }

            DataTable approvals = DatabaseHelper.GetApprovalsByTaskId(taskId);
            gvApprovals.DataSource = approvals;
            gvApprovals.DataBind();

            DataTable history = DatabaseHelper.GetStatusHistory(taskId);
            gvHistory.DataSource = history;
            gvHistory.DataBind();

            // Load pending approvals for current user
            if (Session["UserID"] != null)
            {
                int userId = Convert.ToInt32(Session["UserID"]);
                DataTable pending = DatabaseHelper.ExecuteQuery(
                    @"SELECT a.ApprovalID, t.Title, t.CreatedBy 
                      FROM WorkflowApprovals a 
                      INNER JOIN WorkflowTasks t ON a.TaskID = t.TaskID 
                      WHERE a.ApproverUserID = @UserID AND a.ApprovalStatus = 'Pending' AND a.TaskID = @TaskID",
                    new System.Data.SqlClient.SqlParameter("@UserID", userId),
                    new System.Data.SqlClient.SqlParameter("@TaskID", taskId));
                rptPendingApprovals.DataSource = pending;
                rptPendingApprovals.DataBind();
            }

            // Show workflow approve/reject if this task is linked to an approval step
            btnApproveWfStep.Visible = false;
            btnRejectWfStep.Visible = false;
            if (task.Table.Columns.Contains("InstanceID") && task["InstanceID"] != DBNull.Value
                && task.Table.Columns.Contains("StepID") && task["StepID"] != DBNull.Value)
            {
                int stepId = Convert.ToInt32(task["StepID"]);
                DataTable stepRow = DatabaseHelper.GetWorkflowTaskByInstanceStep(
                    Convert.ToInt32(task["InstanceID"]), stepId);
                if (stepRow != null && stepRow.Rows.Count > 0)
                {
                    // Check if the step is an approval type
                    DataTable steps = DatabaseHelper.GetWorkflowInstanceSteps(Convert.ToInt32(task["InstanceID"]));
                    foreach (DataRow s in steps.Rows)
                    {
                        if (Convert.ToInt32(s["StepID"]) == stepId && s["NodeType"].ToString() == "approval"
                            && s["Status"].ToString() == "Running")
                        {
                            btnApproveWfStep.Visible = true;
                            btnRejectWfStep.Visible = true;
                            break;
                        }
                    }
                }
            }

            ViewState["ShowModal"] = "task";
        }

        protected void btnSaveTask_Click(object sender, EventArgs e)
        {
            // Check if this is a load request
            string eventArg = Request["__EVENTARGUMENT"];
            if (!string.IsNullOrEmpty(eventArg) && eventArg.StartsWith("LOAD|"))
                return;

            if (string.IsNullOrWhiteSpace(txtTaskTitle.Text))
            {
                ShowMessage("Task title is required.", true);
                ViewState["ShowModal"] = "task";
                return;
            }

            string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
            int? assignedUserId = string.IsNullOrEmpty(ddlAssignTo.SelectedValue) ? (int?)null : int.Parse(ddlAssignTo.SelectedValue);
            string assignedName = assignedUserId.HasValue ? ddlAssignTo.SelectedItem.Text : null;
            int? demandFundId = string.IsNullOrEmpty(ddlDemandFund.SelectedValue) ? (int?)null : int.Parse(ddlDemandFund.SelectedValue);
            DateTime? dueDate = string.IsNullOrEmpty(txtDueDate.Text) ? (DateTime?)null : DateTime.Parse(txtDueDate.Text);

            int taskId = 0;
            int.TryParse(hfEditTaskId.Value, out taskId);

            if (taskId > 0)
            {
                // Update
                string oldStatus = "";
                DataRow existing = DatabaseHelper.GetWorkflowTaskById(taskId);
                if (existing != null) oldStatus = existing["Status"].ToString();

                DatabaseHelper.UpdateWorkflowTask(taskId, txtTaskTitle.Text, txtDescription.Text,
                    ddlPriority.SelectedValue, assignedUserId, assignedName, demandFundId, dueDate, currentUser);

                // Update completion percentage for workflow tasks
                if (pnlCompletion.Visible)
                {
                    int pct = 0;
                    string pctStr = Request.Form[rangeCompletionBoard.UniqueID];
                    if (!string.IsNullOrEmpty(pctStr)) int.TryParse(pctStr, out pct);
                    if (pct < 0) pct = 0; if (pct > 100) pct = 100;
                    DatabaseHelper.UpdateTaskCompletionPercentage(taskId, pct);
                }

                // Update status if changed
                if (oldStatus != ddlStatus.SelectedValue)
                {
                    DatabaseHelper.UpdateWorkflowTaskStatus(taskId, ddlStatus.SelectedValue, currentUser);
                    // If moved to Done and linked to workflow, advance
                    if (ddlStatus.SelectedValue == "Done")
                    {
                        TryAdvanceWorkflowForTask(taskId, "Approve");
                    }
                }

                // Notify if assignment changed
                if (assignedUserId.HasValue && existing != null &&
                    (existing["AssignedToUserID"] == DBNull.Value || Convert.ToInt32(existing["AssignedToUserID"]) != assignedUserId.Value))
                {
                    DatabaseHelper.InsertNotification(assignedUserId.Value, taskId,
                        string.Format("You have been assigned to task \"{0}\"", txtTaskTitle.Text), "Assignment");
                }

                ShowMessage("Task updated successfully.", false);
            }
            else
            {
                // Insert
                int newId = DatabaseHelper.InsertWorkflowTask(txtTaskTitle.Text, txtDescription.Text,
                    ddlStatus.SelectedValue, ddlPriority.SelectedValue,
                    assignedUserId, assignedName, demandFundId, dueDate, currentUser);

                // Notify assigned user
                if (assignedUserId.HasValue)
                {
                    DatabaseHelper.InsertNotification(assignedUserId.Value, newId,
                        string.Format("You have been assigned to task \"{0}\"", txtTaskTitle.Text), "Assignment");
                }

                ShowMessage("Task created successfully.", false);
            }

            // Reset form
            ClearTaskForm();
            BindBoard();
            BindNotifications();
        }

        protected void btnDeleteTask_Click(object sender, EventArgs e)
        {
            int taskId;
            if (int.TryParse(hfEditTaskId.Value, out taskId) && taskId > 0)
            {
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
                DatabaseHelper.DeleteWorkflowTask(taskId, currentUser);
                ShowMessage("Task deleted.", false);
            }
            ClearTaskForm();
            BindBoard();
        }

        protected void btnApplyMoves_Click(object sender, EventArgs e)
        {
            string moves = hfTaskMoves.Value;
            if (string.IsNullOrEmpty(moves)) return;

            string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
            string[] entries = moves.Split(';');

            foreach (string entry in entries)
            {
                if (string.IsNullOrEmpty(entry)) continue;
                string[] parts = entry.Split('|');
                if (parts.Length != 3) continue;

                int taskId, sortOrder;
                if (!int.TryParse(parts[0], out taskId) || !int.TryParse(parts[2], out sortOrder))
                    continue;

                string newStatus = parts[1];
                DatabaseHelper.UpdateWorkflowTaskStatus(taskId, newStatus, currentUser);
                DatabaseHelper.UpdateWorkflowTaskSortOrder(taskId, newStatus, sortOrder);

                // If moved to Done and task is linked to a workflow instance, advance the workflow
                if (newStatus == "Done")
                {
                    TryAdvanceWorkflowForTask(taskId, "Approve");
                }
            }

            hfTaskMoves.Value = "";
            BindBoard();
            BindNotifications();
        }

        private void TryAdvanceWorkflowForTask(int taskId, string action)
        {
            DataRow task = DatabaseHelper.GetWorkflowTaskById(taskId);
            if (task == null) return;

            // For user-task type steps, require 100% completion before advancing
            if (task.Table.Columns.Contains("StepID") && task["StepID"] != DBNull.Value)
            {
                DataTable steps = null;
                if (task.Table.Columns.Contains("InstanceID") && task["InstanceID"] != DBNull.Value)
                    steps = DatabaseHelper.GetWorkflowInstanceSteps(Convert.ToInt32(task["InstanceID"]));

                if (steps != null)
                {
                    int stepId = Convert.ToInt32(task["StepID"]);
                    foreach (DataRow s in steps.Rows)
                    {
                        if (Convert.ToInt32(s["StepID"]) == stepId && s["NodeType"].ToString() == "user-task")
                        {
                            int pct = task.Table.Columns.Contains("CompletionPercentage") && task["CompletionPercentage"] != DBNull.Value
                                ? Convert.ToInt32(task["CompletionPercentage"]) : 0;
                            if (pct < 100)
                            {
                                ShowMessage("Task must be at 100% completion before the workflow can advance. Current: " + pct + "%. Use My Tasks to update progress.", true);
                                // Revert status back from Done
                                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "System";
                                DatabaseHelper.UpdateWorkflowTaskStatus(taskId, "InProgress", currentUser);
                                return;
                            }
                            break;
                        }
                    }
                }
            }

            if (task.Table.Columns.Contains("InstanceID") && task["InstanceID"] != DBNull.Value
                && task.Table.Columns.Contains("StepID") && task["StepID"] != DBNull.Value)
            {
                int instanceId = Convert.ToInt32(task["InstanceID"]);
                int stepId = Convert.ToInt32(task["StepID"]);
                // Call the workflow engine to advance
                try
                {
                    WorkflowDesigner.CompleteWorkflowStep(instanceId, stepId, action, "Completed from Workflow Board");
                }
                catch { /* log if needed */ }
            }
        }

        protected void btnRequestApproval_Click(object sender, EventArgs e)
        {
            int taskId;
            if (!int.TryParse(hfEditTaskId.Value, out taskId) || taskId == 0)
                return;

            if (string.IsNullOrEmpty(ddlApprover.SelectedValue))
            {
                ShowMessage("Please select an approver.", true);
                ViewState["ShowModal"] = "task";
                return;
            }

            string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
            int approverUserId = int.Parse(ddlApprover.SelectedValue);
            string approverName = ddlApprover.SelectedItem.Text;

            DatabaseHelper.InsertApproval(taskId, approverUserId, approverName, txtApprovalComments.Text, currentUser);

            ShowMessage("Approval request sent.", false);
            LoadTaskForEdit(taskId);
            BindBoard();
            BindNotifications();
        }

        protected void btnApproveTask_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            int approvalId;
            if (int.TryParse(btn.CommandArgument, out approvalId))
            {
                DatabaseHelper.UpdateApprovalStatus(approvalId, "Approved", null);
                ShowMessage("Task approved.", false);
            }

            int taskId;
            if (int.TryParse(hfEditTaskId.Value, out taskId) && taskId > 0)
                LoadTaskForEdit(taskId);

            BindBoard();
            BindNotifications();
        }

        protected void btnRejectTask_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            int approvalId;
            if (int.TryParse(btn.CommandArgument, out approvalId))
            {
                DatabaseHelper.UpdateApprovalStatus(approvalId, "Rejected", null);
                ShowMessage("Task rejected.", false);
            }

            int taskId;
            if (int.TryParse(hfEditTaskId.Value, out taskId) && taskId > 0)
                LoadTaskForEdit(taskId);

            BindBoard();
            BindNotifications();
        }

        protected void btnMarkAllRead_Click(object sender, EventArgs e)
        {
            if (Session["UserID"] != null)
            {
                DatabaseHelper.MarkAllNotificationsRead(Convert.ToInt32(Session["UserID"]));
                BindNotifications();
            }
        }

        private void ClearTaskForm()
        {
            hfEditTaskId.Value = "0";
            txtTaskTitle.Text = "";
            txtDescription.Text = "";
            ddlPriority.SelectedValue = "Medium";
            ddlStatus.SelectedIndex = 0;
            ddlAssignTo.SelectedIndex = 0;
            ddlDemandFund.SelectedIndex = 0;
            txtDueDate.Text = "";
            txtApprovalComments.Text = "";
            pnlApproval.Visible = false;
            btnDeleteTask.Visible = false;
            ViewState["ShowModal"] = "";
        }

        protected string TruncateName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "Unassigned";
            return name.Length > 15 ? name.Substring(0, 12) + "..." : name;
        }

        protected string GetNotifIcon(string type)
        {
            switch (type)
            {
                case "Assignment": return "glyphicon-user";
                case "Approval": return "glyphicon-thumbs-up";
                case "StatusChange": return "glyphicon-transfer";
                default: return "glyphicon-info-sign";
            }
        }

        protected string GetNotifClickAction(object stepNodeType, object taskId)
        {
            string nodeType = stepNodeType != null && stepNodeType != DBNull.Value ? stepNodeType.ToString() : "";
            string tid = taskId != null && taskId != DBNull.Value ? taskId.ToString() : "";
            if (nodeType == "approval")
                return "window.location.href='" + ResolveUrl("~/Forms/MyApprovals.aspx") + "?taskId=" + tid + "';";
            if (nodeType == "user-task")
                return "window.location.href='" + ResolveUrl("~/Forms/MyTasks.aspx") + "?taskId=" + tid + "';";
            if (!string.IsNullOrEmpty(tid))
                return "showTaskModal(" + tid + ");";
            return "";
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }

        protected void btnApproveWfStep_Click(object sender, EventArgs e)
        {
            HandleWfStepAction("Approve");
        }

        protected void btnRejectWfStep_Click(object sender, EventArgs e)
        {
            HandleWfStepAction("Reject");
        }

        private void HandleWfStepAction(string action)
        {
            int taskId;
            if (!int.TryParse(hfEditTaskId.Value, out taskId) || taskId == 0) return;

            DataRow task = DatabaseHelper.GetWorkflowTaskById(taskId);
            if (task == null || task["InstanceID"] == DBNull.Value || task["StepID"] == DBNull.Value) return;

            int instanceId = Convert.ToInt32(task["InstanceID"]);
            int stepId = Convert.ToInt32(task["StepID"]);

            try
            {
                WorkflowDesigner.CompleteWorkflowStep(instanceId, stepId, action, action + " from Workflow Board");

                if (action == "Reject")
                    DatabaseHelper.UpdateWorkflowTaskStatus(taskId, "Done",
                        Session["Username"] != null ? Session["Username"].ToString() : "System");

                ShowMessage("Workflow step " + action.ToLower() + "d.", false);
            }
            catch (Exception ex)
            {
                ShowMessage("Error: " + ex.Message, true);
            }

            BindBoard();
            BindNotifications();
        }

        [System.Web.Services.WebMethod(EnableSession = true)]
        public static string MarkNotificationRead(int notificationId)
        {
            DatabaseHelper.ExecuteNonQuery(
                "UPDATE WorkflowNotifications SET IsRead = 1 WHERE NotificationID = @NID",
                new System.Data.SqlClient.SqlParameter("@NID", notificationId));
            return "OK";
        }
    }
}
