using System;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class MyApprovals : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserID"] == null) Response.Redirect("~/Login.aspx");
            if (!IsPostBack)
            {
                BindGrid();
                string taskIdParam = Request.QueryString["taskId"];
                int taskId;
                if (!string.IsNullOrEmpty(taskIdParam) && int.TryParse(taskIdParam, out taskId) && taskId > 0)
                {
                    LoadApprovalAction(taskId);
                }
            }
        }

        private void BindGrid()
        {
            int userId = Convert.ToInt32(Session["UserID"]);
            DataTable dt = DatabaseHelper.GetMyWorkflowApprovals(userId);
            gvMyApprovals.DataSource = dt;
            gvMyApprovals.DataBind();
        }

        protected void gvMyApprovals_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "ActionApproval") return;
            int taskId;
            if (!int.TryParse(e.CommandArgument.ToString(), out taskId)) return;
            LoadApprovalAction(taskId);
        }

        private void LoadApprovalAction(int taskId)
        {
            DataRow task = DatabaseHelper.GetWorkflowTaskById(taskId);
            if (task == null) return;

            hfTaskId.Value = taskId.ToString();
            hfInstanceId.Value = task["InstanceID"] != DBNull.Value ? task["InstanceID"].ToString() : "";
            hfStepId.Value = task["StepID"] != DBNull.Value ? task["StepID"].ToString() : "";

            lblApprovalTitle.Text = Server.HtmlEncode(task["Title"].ToString());
            lblDescription.Text = task["Description"] != DBNull.Value ? Server.HtmlEncode(task["Description"].ToString()) : "";
            lblLinkedTable.Text = task["LinkedTable"] != DBNull.Value ? task["LinkedTable"].ToString() : "";
            lblRecordId.Text = task["LinkedRecordID"] != DBNull.Value ? task["LinkedRecordID"].ToString() : "";
            lblRequestedBy.Text = task["CreatedBy"] != DBNull.Value ? Server.HtmlEncode(task["CreatedBy"].ToString()) : "";

            // Get workflow name
            if (task["InstanceID"] != DBNull.Value)
            {
                DataRow inst = DatabaseHelper.GetWorkflowInstanceById(Convert.ToInt32(task["InstanceID"]));
                if (inst != null)
                {
                    int defId = Convert.ToInt32(inst["DefinitionID"]);
                    DataTable wfDef = DatabaseHelper.ExecuteQuery(
                        "SELECT Name FROM WorkflowDefinitions WHERE DefinitionID=@ID",
                        new System.Data.SqlClient.SqlParameter("@ID", defId));
                    lblWorkflowName.Text = wfDef.Rows.Count > 0 ? wfDef.Rows[0]["Name"].ToString() : "";
                }
            }

            // Load linked record details for review
            LoadRecordDetails(task);

            ViewState["ShowModal"] = "action";
        }

        private void LoadRecordDetails(DataRow task)
        {
            litRecordDetails.Text = "";
            if (task["LinkedTable"] == DBNull.Value || task["LinkedRecordID"] == DBNull.Value) return;

            string table = task["LinkedTable"].ToString();
            int recordId = Convert.ToInt32(task["LinkedRecordID"]);

            DataRow record = DatabaseHelper.GetLinkedRecord(table, recordId);
            if (record == null) { litRecordDetails.Text = "<em>Record not found.</em>"; return; }

            var sb = new StringBuilder();
            sb.Append("<table class='table table-condensed' style='margin:0;'>");
            foreach (DataColumn col in record.Table.Columns)
            {
                string val = record[col] != DBNull.Value ? Server.HtmlEncode(record[col].ToString()) : "<em>null</em>";
                sb.AppendFormat("<tr><td style='font-weight:600;width:40%;'>{0}</td><td>{1}</td></tr>",
                    Server.HtmlEncode(col.ColumnName), val);
            }
            sb.Append("</table>");
            litRecordDetails.Text = sb.ToString();
        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            HandleApprovalAction("Approve");
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtComments.Text))
            {
                ShowMessage("Comments are required when rejecting an approval.", true);
                LoadApprovalAction(int.Parse(hfTaskId.Value));
                return;
            }
            HandleApprovalAction("Reject");
        }

        private void HandleApprovalAction(string action)
        {
            int taskId, instanceId, stepId;
            if (!int.TryParse(hfTaskId.Value, out taskId) || taskId == 0) return;
            if (!int.TryParse(hfInstanceId.Value, out instanceId)) return;
            if (!int.TryParse(hfStepId.Value, out stepId)) return;

            string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
            string comments = txtComments.Text;

            try
            {
                WorkflowDesigner.CompleteWorkflowStep(instanceId, stepId, action,
                    comments + " (" + action + " by " + currentUser + " from My Approvals)");

                // Update task status
                DatabaseHelper.UpdateWorkflowTaskStatus(taskId, "Done", currentUser);

                if (action == "Reject")
                    ShowMessage("Approval rejected. Workflow has been ended.", false);
                else
                    ShowMessage("Approval granted. Workflow advanced to next stage.", false);
            }
            catch (Exception ex)
            {
                ShowMessage("Error: " + ex.Message, true);
            }

            BindGrid();
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
