using System;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class DemandFundList : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            DataTable dt = DatabaseHelper.GetDemandFundList();

            // Apply sorting if set
            if (ViewState["SortExpression"] != null)
            {
                DataView dv = dt.DefaultView;
                dv.Sort = ViewState["SortExpression"].ToString() + " " + (ViewState["SortDirection"] ?? "ASC").ToString();
                gvDemandFunds.DataSource = dv;
            }
            else
            {
                gvDemandFunds.DataSource = dt;
            }

            gvDemandFunds.DataBind();
        }

        protected void gvDemandFunds_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvDemandFunds.PageIndex = e.NewPageIndex;
            BindGrid();
        }

        protected void gvDemandFunds_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortDirection = "ASC";
            if (ViewState["SortExpression"] != null && ViewState["SortExpression"].ToString() == e.SortExpression)
            {
                sortDirection = (ViewState["SortDirection"] ?? "ASC").ToString() == "ASC" ? "DESC" : "ASC";
            }

            ViewState["SortExpression"] = e.SortExpression;
            ViewState["SortDirection"] = sortDirection;
            BindGrid();
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (!fuBulkUpload.HasFile)
            {
                ShowMessage("Please select a file to upload.", true);
                return;
            }

            string ext = Path.GetExtension(fuBulkUpload.FileName).ToLower();
            if (ext != ".csv" && ext != ".xls" && ext != ".xlsx")
            {
                ShowMessage("Only CSV and Excel files (.csv, .xls, .xlsx) are supported.", true);
                return;
            }

            try
            {
                DataTable dt = SpendingAllocation.ParseUploadedFile(fuBulkUpload, ext);
                if (dt.Rows.Count == 0)
                {
                    ShowMessage("The uploaded file contains no data rows.", true);
                    return;
                }

                DataTable mapped = MapDemandFundColumns(dt);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
                bool deleteExisting = rblUploadMode.SelectedValue == "replace";
                DatabaseHelper.BulkInsertDemandFunds(mapped, currentUser, deleteExisting);

                string modeMsg = deleteExisting ? "All previous data was replaced." : "New records were appended.";
                ShowMessage("Successfully uploaded " + mapped.Rows.Count + " records. " + modeMsg, false);
                BindGrid();
            }
            catch (Exception ex)
            {
                ShowMessage("Upload error: " + ex.Message, true);
            }
        }

        private DataTable MapDemandFundColumns(DataTable source)
        {
            DataTable mapped = new DataTable();
            string[] cols = { "InitiativeTitle", "Description", "DemandType", "DAMOApproved",
                "EngineeringLead", "FundingSource", "FundsApprovedBy", "GLCode",
                "PhaseDescription", "PrimaryBusinessOwner", "Remarks", "BusinessVertical",
                "DigitalProject", "DeliveryManager", "InitiativeType", "PlatformOwner",
                "PortfolioHead", "TechnologyVertical", "InitiativeSize", "ProjectType" };

            foreach (string c in cols)
                mapped.Columns.Add(c);

            var colMap = new System.Collections.Generic.Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < source.Columns.Count; i++)
            {
                string normalized = NormalizeHeader(source.Columns[i].ColumnName.Trim());
                colMap[normalized] = i;
            }

            foreach (DataRow srcRow in source.Rows)
            {
                DataRow newRow = mapped.NewRow();
                newRow["InitiativeTitle"] = GetVal(srcRow, colMap, "initiativetitle");
                newRow["Description"] = GetVal(srcRow, colMap, "description");
                newRow["DemandType"] = GetVal(srcRow, colMap, "demandtype", "damotype");
                newRow["DAMOApproved"] = GetVal(srcRow, colMap, "damoapproved");
                newRow["EngineeringLead"] = GetVal(srcRow, colMap, "engineeringlead");
                newRow["FundingSource"] = GetVal(srcRow, colMap, "fundingsource");
                newRow["FundsApprovedBy"] = GetVal(srcRow, colMap, "fundsapprovedby");
                newRow["GLCode"] = GetVal(srcRow, colMap, "glcode");
                newRow["PhaseDescription"] = GetVal(srcRow, colMap, "phasedescription", "phase");
                newRow["PrimaryBusinessOwner"] = GetVal(srcRow, colMap, "primarybusinessowner");
                newRow["Remarks"] = GetVal(srcRow, colMap, "remarks");
                newRow["BusinessVertical"] = GetVal(srcRow, colMap, "businessvertical");
                newRow["DigitalProject"] = GetVal(srcRow, colMap, "digitalproject");
                newRow["DeliveryManager"] = GetVal(srcRow, colMap, "deliverymanager");
                newRow["InitiativeType"] = GetVal(srcRow, colMap, "initiativetype");
                newRow["PlatformOwner"] = GetVal(srcRow, colMap, "platformowner");
                newRow["PortfolioHead"] = GetVal(srcRow, colMap, "portfoliohead");
                newRow["TechnologyVertical"] = GetVal(srcRow, colMap, "technologyvertical");
                newRow["InitiativeSize"] = GetVal(srcRow, colMap, "initiativesize", "tshirtsize");
                newRow["ProjectType"] = GetVal(srcRow, colMap, "projecttype");
                mapped.Rows.Add(newRow);
            }

            return mapped;
        }

        private static string NormalizeHeader(string header)
        {
            return System.Text.RegularExpressions.Regex.Replace(header, @"[\s_\-#]+", "").ToLower();
        }

        private static string GetVal(DataRow row, System.Collections.Generic.Dictionary<string, int> colMap,
            string key, string altKey = null)
        {
            int idx;
            if (colMap.TryGetValue(key, out idx))
                return row[idx] != DBNull.Value ? row[idx].ToString().Trim() : "";
            if (altKey != null && colMap.TryGetValue(altKey, out idx))
                return row[idx] != DBNull.Value ? row[idx].ToString().Trim() : "";
            return "";
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
