<%@ Page Title="My Approvals" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="MyApprovals.aspx.cs" Inherits="DemandFundManagement.Forms.MyApprovals" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title">
        <span class="glyphicon glyphicon-thumbs-up"></span> My Approvals
    </h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <asp:GridView ID="gvMyApprovals" runat="server" AutoGenerateColumns="false" CssClass="table table-bordered table-striped table-hover"
        EmptyDataText="No pending approvals assigned to you." OnRowCommand="gvMyApprovals_RowCommand" DataKeyNames="TaskID">
        <Columns>
            <asp:BoundField DataField="TaskID" HeaderText="#" ItemStyle-Width="50px" />
            <asp:BoundField DataField="WorkflowName" HeaderText="Workflow" />
            <asp:BoundField DataField="NodeLabel" HeaderText="Step" />
            <asp:BoundField DataField="Title" HeaderText="Approval Title" />
            <asp:BoundField DataField="Priority" HeaderText="Priority" ItemStyle-Width="80px" />
            <asp:BoundField DataField="LinkedTable" HeaderText="Table" />
            <asp:BoundField DataField="LinkedRecordID" HeaderText="Record #" ItemStyle-Width="70px" />
            <asp:BoundField DataField="CreatedBy" HeaderText="Requested By" />
            <asp:BoundField DataField="CreatedDate" HeaderText="Requested" DataFormatString="{0:dd-MMM-yyyy}" />
            <asp:TemplateField HeaderText="Action" ItemStyle-Width="120px">
                <ItemTemplate>
                    <asp:LinkButton ID="btnAction" runat="server" CssClass="btn btn-primary btn-xs"
                        CommandName="ActionApproval" CommandArgument='<%# Eval("TaskID") %>'>
                        <span class="glyphicon glyphicon-check"></span> Review
                    </asp:LinkButton>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
    </asp:GridView>

    <!-- Approval Action Modal -->
    <div class="modal-overlay" id="approvalActionModal" style="display:none;">
        <div class="modal-dialog" style="max-width:650px;">
            <div class="modal-header">
                <span class="glyphicon glyphicon-thumbs-up"></span> Approval Action
                <button type="button" class="modal-close" onclick="document.getElementById('approvalActionModal').style.display='none'">&times;</button>
            </div>
            <div class="modal-body">
                <asp:HiddenField ID="hfTaskId" runat="server" />
                <asp:HiddenField ID="hfInstanceId" runat="server" />
                <asp:HiddenField ID="hfStepId" runat="server" />
                <div class="form-row form-row-2">
                    <div class="form-col form-group">
                        <label>Approval Title</label>
                        <asp:Label ID="lblApprovalTitle" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                    <div class="form-col form-group">
                        <label>Workflow</label>
                        <asp:Label ID="lblWorkflowName" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <asp:Label ID="lblDescription" runat="server" CssClass="form-control" style="background:#f9f9f9;min-height:50px;" />
                </div>
                <div class="form-row form-row-3">
                    <div class="form-col form-group">
                        <label>Linked Table</label>
                        <asp:Label ID="lblLinkedTable" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                    <div class="form-col form-group">
                        <label>Record #</label>
                        <asp:Label ID="lblRecordId" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                    <div class="form-col form-group">
                        <label>Requested By</label>
                        <asp:Label ID="lblRequestedBy" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                </div>

                <div style="border:1px solid #ddd;border-radius:6px;padding:14px;margin-top:10px;background:#fafafa;">
                    <h5 style="margin:0 0 10px 0;font-weight:700;"><span class="glyphicon glyphicon-info-sign"></span> Record Details</h5>
                    <div id="recordDetails" runat="server" style="font-size:13px;max-height:200px;overflow-y:auto;">
                        <asp:Literal ID="litRecordDetails" runat="server" />
                    </div>
                </div>

                <div class="form-group" style="margin-top:12px;">
                    <label>Comments <span style="color:#999;">(required for rejection)</span></label>
                    <asp:TextBox ID="txtComments" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" MaxLength="2000" />
                </div>
            </div>
            <div class="modal-footer">
                <asp:Button ID="btnApprove" runat="server" Text="Approve" CssClass="btn btn-success" OnClick="btnApprove_Click"
                    OnClientClick="return confirm('Are you sure you want to approve this item?');" />
                <asp:Button ID="btnReject" runat="server" Text="Reject" CssClass="btn btn-danger" OnClick="btnReject_Click"
                    OnClientClick="return confirm('Are you sure you want to reject? This will end the workflow.');" />
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('approvalActionModal').style.display='none'">Cancel</button>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        var showModal = '<%= ViewState["ShowModal"] ?? "" %>';
        if (showModal === 'action') {
            document.getElementById('approvalActionModal').style.display = 'flex';
        }
    </script>
</asp:Content>
