using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Web.UI;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class WorkflowDesigner : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] != null)
                {
                    hfCurrentUserId.Value = Session["UserID"].ToString();
                    hfCurrentUserName.Value = Session["FullName"] != null ? Session["FullName"].ToString() : "";
                }
            }
        }

        #region WebMethods for Workflow CRUD

        [WebMethod(EnableSession = true)]
        public static int SaveWorkflow(int id, string name, string description, string workflowJson, string linkedTable)
        {
            string user = GetCurrentUser();
            if (id > 0)
            {
                DatabaseHelper.UpdateWorkflowDefinition(id, name, description, workflowJson, user);
                // Update linked table
                DatabaseHelper.ExecuteNonQuery(
                    "UPDATE WorkflowDefinitions SET LinkedTable=@Table WHERE DefinitionID=@ID",
                    new System.Data.SqlClient.SqlParameter("@Table", string.IsNullOrEmpty(linkedTable) ? (object)DBNull.Value : linkedTable),
                    new System.Data.SqlClient.SqlParameter("@ID", id));
                return id;
            }
            else
            {
                int newId = DatabaseHelper.InsertWorkflowDefinition(name, description, workflowJson, user);
                DatabaseHelper.ExecuteNonQuery(
                    "UPDATE WorkflowDefinitions SET LinkedTable=@Table WHERE DefinitionID=@ID",
                    new System.Data.SqlClient.SqlParameter("@Table", string.IsNullOrEmpty(linkedTable) ? (object)DBNull.Value : linkedTable),
                    new System.Data.SqlClient.SqlParameter("@ID", newId));
                return newId;
            }
        }

        [WebMethod(EnableSession = true)]
        public static object LoadWorkflow(int id)
        {
            DataRow row = DatabaseHelper.GetWorkflowDefinitionById(id);
            if (row == null) return null;
            return new
            {
                Id = Convert.ToInt32(row["DefinitionID"]),
                Name = row["Name"].ToString(),
                Description = row["Description"] != DBNull.Value ? row["Description"].ToString() : "",
                WorkflowJSON = row["WorkflowJSON"].ToString(),
                Status = row["Status"].ToString(),
                LinkedTable = row.Table.Columns.Contains("LinkedTable") && row["LinkedTable"] != DBNull.Value ? row["LinkedTable"].ToString() : ""
            };
        }

        [WebMethod(EnableSession = true)]
        public static List<object> GetWorkflowList()
        {
            DataTable dt = DatabaseHelper.GetWorkflowDefinitions();
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    Id = Convert.ToInt32(row["DefinitionID"]),
                    Name = row["Name"].ToString(),
                    Status = row["Status"].ToString()
                });
            }
            return list;
        }

        [WebMethod(EnableSession = true)]
        public static void PublishWorkflow(int id)
        {
            string user = GetCurrentUser();
            DatabaseHelper.UpdateWorkflowDefinitionStatus(id, "Published", user);
        }

        #endregion

        #region WebMethods for Table Fields & Roles

        [WebMethod(EnableSession = true)]
        public static List<object> GetTableFields(string tableName)
        {
            DataTable dt = DatabaseHelper.GetTableFields(tableName);
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    ColumnName = row["COLUMN_NAME"].ToString(),
                    DataType = row["DATA_TYPE"].ToString()
                });
            }
            return list;
        }

        [WebMethod(EnableSession = true)]
        public static List<object> GetRoles()
        {
            DataTable dt = DatabaseHelper.GetUserRoles();
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    RoleID = Convert.ToInt32(row["RoleID"]),
                    RoleName = row["RoleName"].ToString()
                });
            }
            return list;
        }

        [WebMethod(EnableSession = true)]
        public static List<object> GetActiveUsers()
        {
            DataTable dt = DatabaseHelper.GetAllUsers();
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                if (Convert.ToBoolean(row["IsEnabled"]))
                {
                    list.Add(new
                    {
                        UserID = Convert.ToInt32(row["UserID"]),
                        FullName = row["FullName"].ToString()
                    });
                }
            }
            return list;
        }

        [WebMethod(EnableSession = true)]
        public static List<object> GetPublishedWorkflows(string tableName)
        {
            DataTable dt = DatabaseHelper.GetPublishedWorkflowsForTable(tableName);
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    Id = Convert.ToInt32(row["DefinitionID"]),
                    Name = row["Name"].ToString(),
                    Description = row["Description"] != DBNull.Value ? row["Description"].ToString() : ""
                });
            }
            return list;
        }

        #endregion

        #region WebMethods for Workflow Execution

        [WebMethod(EnableSession = true)]
        public static object StartWorkflow(int definitionId, int recordId)
        {
            int userId = GetCurrentUserId();
            string userName = GetCurrentUser();

            // Load the workflow definition
            DataRow defRow = DatabaseHelper.GetWorkflowDefinitionById(definitionId);
            if (defRow == null) return new { Success = false, Message = "Workflow not found" };
            if (defRow["Status"].ToString() != "Published") return new { Success = false, Message = "Workflow is not published" };

            string linkedTable = defRow["LinkedTable"] != DBNull.Value ? defRow["LinkedTable"].ToString() : "";
            string wfJson = defRow["WorkflowJSON"].ToString();

            // Create instance
            int instanceId = DatabaseHelper.CreateWorkflowInstance(definitionId, linkedTable, recordId, userId, userName, wfJson);

            // Parse workflow JSON and execute from start node
            var serializer = new JavaScriptSerializer();
            var state = serializer.Deserialize<Dictionary<string, object>>(wfJson);
            var nodesList = state["nodes"] as System.Collections.ArrayList;
            var connsList = state["connections"] as System.Collections.ArrayList;

            // Find start node
            Dictionary<string, object> startNode = null;
            foreach (Dictionary<string, object> n in nodesList)
            {
                if (n["type"].ToString() == "start") { startNode = n; break; }
            }
            if (startNode == null) return new { Success = false, Message = "No start node found" };

            int startNodeId = Convert.ToInt32(startNode["id"]);
            DatabaseHelper.UpdateWorkflowInstanceCurrentNode(instanceId, startNodeId);

            // Mark start as completed and advance to next nodes
            int startStepId = DatabaseHelper.InsertWorkflowInstanceStep(instanceId, startNodeId, "start", "Start", "Completed", null, null);
            AdvanceWorkflow(instanceId, startNodeId, nodesList, connsList, linkedTable, recordId, userId, userName);

            return new { Success = true, InstanceId = instanceId, Message = "Workflow started" };
        }

        private static void AdvanceWorkflow(int instanceId, int completedNodeId,
            System.Collections.ArrayList nodesList, System.Collections.ArrayList connsList,
            string linkedTable, int recordId, int initiatorUserId, string initiatorUserName)
        {
            // Find connections from the completed node
            foreach (Dictionary<string, object> conn in connsList)
            {
                if (Convert.ToInt32(conn["srcNodeId"]) != completedNodeId) continue;

                int tgtNodeId = Convert.ToInt32(conn["tgtNodeId"]);
                Dictionary<string, object> targetNode = null;
                foreach (Dictionary<string, object> n in nodesList)
                {
                    if (Convert.ToInt32(n["id"]) == tgtNodeId) { targetNode = n; break; }
                }
                if (targetNode == null) continue;

                string nodeType = targetNode["type"].ToString();
                string nodeLabel = targetNode.ContainsKey("label") ? targetNode["label"].ToString() : nodeType;

                // Determine assignee
                int? assigneeId = null;
                string assigneeName = null;
                if (targetNode.ContainsKey("assignee") && targetNode["assignee"] != null && targetNode["assignee"].ToString() != "")
                {
                    assigneeId = Convert.ToInt32(targetNode["assignee"]);
                    assigneeName = targetNode.ContainsKey("assigneeName") ? targetNode["assigneeName"]?.ToString() : null;
                }

                switch (nodeType)
                {
                    case "end":
                        DatabaseHelper.InsertWorkflowInstanceStep(instanceId, tgtNodeId, nodeType, nodeLabel, "Completed", null, null);
                        DatabaseHelper.UpdateWorkflowInstanceStatus(instanceId, "Completed");
                        // Notify initiator
                        DatabaseHelper.InsertWorkflowNotification(initiatorUserId, null,
                            "Workflow completed for " + linkedTable + " #" + recordId, "Info");
                        break;

                    case "user-task":
                    case "approval":
                        int stepId = DatabaseHelper.InsertWorkflowInstanceStep(instanceId, tgtNodeId, nodeType, nodeLabel, "Pending",
                            assigneeId, assigneeName);
                        // Create a task on the Workflow Board
                        string priority = nodeType == "approval" ? "High" : "Medium";
                        int taskId = DatabaseHelper.InsertWorkflowTaskFromInstance(
                            nodeLabel, "Workflow task for " + linkedTable + " #" + recordId,
                            "ToDo", priority, assigneeId, assigneeName, instanceId, stepId,
                            linkedTable, recordId, initiatorUserName);
                        // Notify assignee
                        if (assigneeId.HasValue)
                        {
                            DatabaseHelper.InsertWorkflowNotification(assigneeId.Value, taskId,
                                "New " + nodeType + " assigned: " + nodeLabel, "Assignment");
                        }
                        DatabaseHelper.UpdateWorkflowInstanceCurrentNode(instanceId, tgtNodeId);
                        break;

                    case "email":
                        // Auto-execute: just log the step as completed (actual email sending can be added later)
                        DatabaseHelper.InsertWorkflowInstanceStep(instanceId, tgtNodeId, nodeType, nodeLabel, "Completed", null, null);
                        // Continue to next
                        AdvanceWorkflow(instanceId, tgtNodeId, nodesList, connsList, linkedTable, recordId, initiatorUserId, initiatorUserName);
                        break;

                    case "decision":
                    case "decision-table":
                        // Evaluate rules
                        bool conditionMet = EvaluateDecisionRules(targetNode, linkedTable, recordId);
                        DatabaseHelper.InsertWorkflowInstanceStep(instanceId, tgtNodeId, nodeType, nodeLabel, "Completed", null, null);

                        // Find the correct outgoing connection - only ONE path must execute
                        string outPort = conditionMet ? "out" : "out-no";

                        // Build a filtered connections list that excludes the wrong decision path
                        var filteredConns = new System.Collections.ArrayList();
                        foreach (Dictionary<string, object> fc in connsList)
                        {
                            int fcSrc = Convert.ToInt32(fc["srcNodeId"]);
                            // Keep all connections except wrong-port connections from this decision node
                            if (fcSrc == tgtNodeId)
                            {
                                string fcPort = fc.ContainsKey("srcPort") ? fc["srcPort"].ToString() : "";
                                if (fcPort != outPort) continue; // skip the wrong path
                            }
                            filteredConns.Add(fc);
                        }
                        // Advance using only the filtered connections so only the chosen path executes
                        AdvanceWorkflow(instanceId, tgtNodeId, nodesList, filteredConns, linkedTable, recordId, initiatorUserId, initiatorUserName);
                        break;

                    default:
                        // For other node types (delay-timer, db-task, compute, etc.) - auto-complete and advance
                        DatabaseHelper.InsertWorkflowInstanceStep(instanceId, tgtNodeId, nodeType, nodeLabel, "Completed", null, null);
                        AdvanceWorkflow(instanceId, tgtNodeId, nodesList, connsList, linkedTable, recordId, initiatorUserId, initiatorUserName);
                        break;
                }
            }
        }

        private static bool EvaluateDecisionRules(Dictionary<string, object> decisionNode, string linkedTable, int recordId)
        {
            if (!decisionNode.ContainsKey("decisionRules") || decisionNode["decisionRules"] == null)
                return true; // No rules = pass through

            var rules = decisionNode["decisionRules"] as System.Collections.ArrayList;
            if (rules == null || rules.Count == 0) return true;

            // Load the actual record data
            DataRow record = DatabaseHelper.GetLinkedRecord(linkedTable, recordId);
            if (record == null) return false;

            foreach (Dictionary<string, object> rule in rules)
            {
                string field = rule.ContainsKey("field") ? rule["field"].ToString() : "";
                string op = rule.ContainsKey("operator") ? rule["operator"].ToString() : "=";
                string ruleValue = rule.ContainsKey("value") ? rule["value"].ToString() : "";

                if (string.IsNullOrEmpty(field) || !record.Table.Columns.Contains(field)) continue;

                object dbVal = record[field];
                if (dbVal == DBNull.Value) dbVal = null;

                string dbStr = dbVal != null ? dbVal.ToString() : "";

                // Try numeric comparison
                decimal dbNum = 0, ruleNum = 0;
                bool isNumeric = decimal.TryParse(dbStr, out dbNum) && decimal.TryParse(ruleValue, out ruleNum);

                bool match = false;
                switch (op)
                {
                    case "=": match = isNumeric ? dbNum == ruleNum : dbStr.Equals(ruleValue, StringComparison.OrdinalIgnoreCase); break;
                    case "!=": match = isNumeric ? dbNum != ruleNum : !dbStr.Equals(ruleValue, StringComparison.OrdinalIgnoreCase); break;
                    case ">": match = isNumeric && dbNum > ruleNum; break;
                    case ">=": match = isNumeric && dbNum >= ruleNum; break;
                    case "<": match = isNumeric && dbNum < ruleNum; break;
                    case "<=": match = isNumeric && dbNum <= ruleNum; break;
                    case "contains": match = dbStr.IndexOf(ruleValue, StringComparison.OrdinalIgnoreCase) >= 0; break;
                }
                if (!match) return false; // All conditions must match
            }
            return true;
        }

        [WebMethod(EnableSession = true)]
        public static object CompleteWorkflowStep(int instanceId, int stepId, string action, string comments)
        {
            int userId = GetCurrentUserId();
            string userName = GetCurrentUser();

            // Update the step
            string status = action == "Reject" ? "Rejected" : "Completed";
            DatabaseHelper.UpdateWorkflowInstanceStepStatus(stepId, status, userName, comments);

            // Get instance details
            DataRow inst = DatabaseHelper.GetWorkflowInstanceById(instanceId);
            if (inst == null) return new { Success = false, Message = "Instance not found" };

            string linkedTable = inst["LinkedTable"].ToString();
            int recordId = Convert.ToInt32(inst["LinkedRecordID"]);
            int initiatorId = Convert.ToInt32(inst["InitiatedByUserID"]);
            string initiatorName = inst["InitiatedByName"] != DBNull.Value ? inst["InitiatedByName"].ToString() : "";
            string wfJson = inst["WorkflowJSON"].ToString();

            // Get the completed step to find the node
            DataTable steps = DatabaseHelper.GetWorkflowInstanceSteps(instanceId);
            DataRow completedStep = null;
            foreach (DataRow r in steps.Rows)
            {
                if (Convert.ToInt32(r["StepID"]) == stepId) { completedStep = r; break; }
            }
            if (completedStep == null) return new { Success = false, Message = "Step not found" };

            int nodeId = Convert.ToInt32(completedStep["NodeId"]);

            if (action == "Reject")
            {
                DatabaseHelper.UpdateWorkflowInstanceStatus(instanceId, "Rejected");
                DatabaseHelper.InsertWorkflowNotification(initiatorId, null,
                    "Workflow rejected at step: " + completedStep["NodeLabel"].ToString(), "Approval");
                return new { Success = true, Message = "Step rejected, workflow ended" };
            }

            // Parse JSON and advance
            var serializer = new JavaScriptSerializer();
            var state = serializer.Deserialize<Dictionary<string, object>>(wfJson);
            var nodesList = state["nodes"] as System.Collections.ArrayList;
            var connsList = state["connections"] as System.Collections.ArrayList;

            AdvanceWorkflow(instanceId, nodeId, nodesList, connsList, linkedTable, recordId, initiatorId, initiatorName);

            return new { Success = true, Message = "Step completed, workflow advanced" };
        }

        #endregion

        #region WebMethods for Workflow Management (Delete, Terminate, History)

        [WebMethod(EnableSession = true)]
        public static object DeleteWorkflowDefinition(int id)
        {
            string user = GetCurrentUser();
            DatabaseHelper.DeleteWorkflowDefinition(id, user);
            return new { Success = true, Message = "Workflow deleted" };
        }

        [WebMethod(EnableSession = true)]
        public static object TerminateWorkflow(int instanceId)
        {
            string user = GetCurrentUser();
            DatabaseHelper.TerminateWorkflowInstance(instanceId, user);
            return new { Success = true, Message = "Workflow terminated" };
        }

        [WebMethod(EnableSession = true)]
        public static List<object> GetWorkflowHistory(string tableName, int recordId)
        {
            DataTable dt = DatabaseHelper.GetWorkflowHistoryForRecord(tableName, recordId);
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    InstanceID = Convert.ToInt32(row["InstanceID"]),
                    WorkflowName = row["WorkflowName"].ToString(),
                    Status = row["Status"].ToString(),
                    InitiatedBy = row["InitiatedByName"].ToString(),
                    StartedDate = Convert.ToDateTime(row["StartedDate"]).ToString("dd-MMM-yyyy HH:mm"),
                    CompletedDate = row["CompletedDate"] != DBNull.Value ? Convert.ToDateTime(row["CompletedDate"]).ToString("dd-MMM-yyyy HH:mm") : ""
                });
            }
            return list;
        }

        [WebMethod(EnableSession = true)]
        public static List<object> GetWorkflowInstanceStepsData(int instanceId)
        {
            DataTable dt = DatabaseHelper.GetWorkflowInstanceSteps(instanceId);
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    StepID = Convert.ToInt32(row["StepID"]),
                    NodeType = row["NodeType"].ToString(),
                    NodeLabel = row["NodeLabel"] != DBNull.Value ? row["NodeLabel"].ToString() : "",
                    Status = row["Status"].ToString(),
                    AssignedTo = row["AssignedToName"] != DBNull.Value ? row["AssignedToName"].ToString() : "",
                    ActionDate = row["ActionDate"] != DBNull.Value ? Convert.ToDateTime(row["ActionDate"]).ToString("dd-MMM-yyyy HH:mm") : "",
                    ActionBy = row["ActionBy"] != DBNull.Value ? row["ActionBy"].ToString() : "",
                    Comments = row["Comments"] != DBNull.Value ? row["Comments"].ToString() : ""
                });
            }
            return list;
        }

        [WebMethod(EnableSession = true)]
        public static List<object> GetOngoingWorkflows()
        {
            DataTable dt = DatabaseHelper.GetOngoingWorkflows();
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    InstanceID = Convert.ToInt32(row["InstanceID"]),
                    WorkflowName = row["WorkflowName"].ToString(),
                    LinkedTable = row["LinkedTable"].ToString(),
                    LinkedRecordID = Convert.ToInt32(row["LinkedRecordID"]),
                    Status = row["Status"].ToString(),
                    InitiatedBy = row["InitiatedByName"] != DBNull.Value ? row["InitiatedByName"].ToString() : "",
                    StartedDate = Convert.ToDateTime(row["StartedDate"]).ToString("dd-MMM-yyyy HH:mm"),
                    CompletedDate = row["CompletedDate"] != DBNull.Value ? Convert.ToDateTime(row["CompletedDate"]).ToString("dd-MMM-yyyy HH:mm") : ""
                });
            }
            return list;
        }

        #endregion

        #region WebMethods for Messaging

        [WebMethod(EnableSession = true)]
        public static List<object> GetContacts()
        {
            int userId = GetCurrentUserId();
            DataTable dt = DatabaseHelper.GetMessageContacts(userId);
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    UserID = Convert.ToInt32(row["UserID"]),
                    FullName = row["FullName"].ToString(),
                    UnreadCount = Convert.ToInt32(row["UnreadCount"])
                });
            }
            return list;
        }

        [WebMethod(EnableSession = true)]
        public static List<object> GetMessages(int otherUserId)
        {
            int userId = GetCurrentUserId();
            DatabaseHelper.MarkMessagesRead(userId, otherUserId);
            DataTable dt = DatabaseHelper.GetMessages(userId, otherUserId);
            var list = new List<object>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new
                {
                    MessageID = Convert.ToInt32(row["MessageID"]),
                    SenderID = Convert.ToInt32(row["SenderID"]),
                    SenderName = row["SenderName"].ToString(),
                    Message = row["Message"].ToString(),
                    SentDate = Convert.ToDateTime(row["SentDate"]).ToString("MM/dd HH:mm")
                });
            }
            return list;
        }

        [WebMethod(EnableSession = true)]
        public static int SendChatMessage(int receiverId, string message)
        {
            int userId = GetCurrentUserId();
            if (string.IsNullOrWhiteSpace(message)) return 0;
            // Sanitize message
            message = HttpUtility.HtmlEncode(message);
            if (message.Length > 4000) message = message.Substring(0, 4000);
            return DatabaseHelper.SendMessage(userId, receiverId, message);
        }

        #endregion

        #region Helpers

        private static int GetCurrentUserId()
        {
            if (HttpContext.Current.Session["UserID"] != null)
                return Convert.ToInt32(HttpContext.Current.Session["UserID"]);
            return 0;
        }

        private static string GetCurrentUser()
        {
            if (HttpContext.Current.Session["Username"] != null)
                return HttpContext.Current.Session["Username"].ToString();
            return "Unknown";
        }

        #endregion
    }
}
