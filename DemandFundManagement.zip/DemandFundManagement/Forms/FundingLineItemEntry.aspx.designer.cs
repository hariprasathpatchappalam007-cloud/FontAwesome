namespace DemandFundManagement.Forms
{
    public partial class FundingLineItemEntry
    {
        protected global::System.Web.UI.WebControls.Label lblPageTitle;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hdnRecordID;
        protected global::System.Web.UI.WebControls.TextBox txtProgramTitle;
        protected global::System.Web.UI.WebControls.TextBox txtTitle;
        protected global::System.Web.UI.WebControls.TextBox txtAllocationType;
        protected global::System.Web.UI.WebControls.TextBox txtAllocationSubType;
        protected global::System.Web.UI.WebControls.TextBox txtLineItemID;
        protected global::System.Web.UI.WebControls.TextBox txtSubCAPEXID;
        protected global::System.Web.UI.WebControls.TextBox txtVendor;
        protected global::System.Web.UI.WebControls.TextBox txtAmount;
        protected global::System.Web.UI.WebControls.TextBox txtConsumed;
        protected global::System.Web.UI.WebControls.TextBox txtBlockedAmount;
        protected global::System.Web.UI.WebControls.TextBox txtRemainingAmount;
        protected global::System.Web.UI.WebControls.LinkButton btnSave;
        protected global::System.Web.UI.WebControls.LinkButton btnSaveNew;
        protected global::System.Web.UI.WebControls.HyperLink lnkCancel;
        protected global::System.Web.UI.WebControls.Panel pnlWorkflowTrigger;
        protected global::System.Web.UI.WebControls.HiddenField hdnRecordIDForWF;
    }
}
