<%@ Page Title="Workflow Board" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="WorkflowBoard.aspx.cs" Inherits="DemandFundManagement.Forms.WorkflowBoard" %>

<asp:Content ID="HeadContent" ContentPlaceHolderID="HeadContent" runat="server">
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
</asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title">
        <span class="glyphicon glyphicon-random"></span> Workflow Board
        <span class="notification-bell" id="notifBell" onclick="toggleNotifications()" title="Notifications">
            <span class="glyphicon glyphicon-bell"></span>
            <asp:Label ID="lblNotifCount" runat="server" CssClass="notif-badge" Visible="false" />
        </span>
    </h2>

    <!-- Notification Panel -->
    <div class="notif-panel" id="notifPanel" style="display:none;">
        <div class="notif-panel-header">
            <strong>Notifications</strong>
            <asp:LinkButton ID="btnMarkAllRead" runat="server" CssClass="btn btn-sm btn-secondary" OnClick="btnMarkAllRead_Click" CausesValidation="false">Mark all read</asp:LinkButton>
        </div>
        <asp:Repeater ID="rptNotifications" runat="server">
            <ItemTemplate>
                <div class='notif-item <%# Convert.ToBoolean(Eval("IsRead")) ? "" : "notif-unread" %>' style="cursor:pointer;"
                     onclick='markNotifRead(<%# Eval("NotificationID") %>, this); <%# GetNotifClickAction(Eval("StepNodeType"), Eval("TaskID")) %>'>
                    <span class='glyphicon <%# GetNotifIcon(Eval("NotificationType").ToString()) %>'></span>
                    <div class="notif-content">
                        <span class="notif-msg"><%# Server.HtmlEncode(Eval("Message").ToString()) %></span>
                        <span class="notif-time"><%# Eval("CreatedDate", "{0:dd-MMM-yyyy HH:mm}") %></span>
                    </div>
                </div>
            </ItemTemplate>
        </asp:Repeater>
        <asp:Panel ID="pnlNoNotifs" runat="server" CssClass="notif-empty">No notifications</asp:Panel>
    </div>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- New Task Button -->
    <div class="btn-group" style="margin-bottom:15px;">
        <button type="button" class="btn btn-primary" onclick="showTaskModal(0)">
            <span class="glyphicon glyphicon-plus"></span> New Task
        </button>
    </div>

    <!-- Hidden fields for AJAX-free drag updates -->
    <asp:HiddenField ID="hfTaskMoves" runat="server" />
    <asp:Button ID="btnApplyMoves" runat="server" OnClick="btnApplyMoves_Click" Style="display:none;" CausesValidation="false" />

    <!-- Kanban Board -->
    <div class="kanban-board">
        <!-- Backlog Column -->
        <div class="kanban-column">
            <div class="kanban-column-header kanban-col-backlog">
                <span class="glyphicon glyphicon-inbox"></span> Backlog
                <span class="kanban-count"><asp:Label ID="lblBacklogCount" runat="server" Text="0" /></span>
            </div>
            <div class="kanban-column-body" id="colBacklog" data-status="Backlog">
                <asp:Repeater ID="rptBacklog" runat="server">
                    <ItemTemplate>
                        <div class="kanban-card" data-taskid='<%# Eval("TaskID") %>' data-steptype='<%# Eval("StepNodeType") %>' ondblclick='handleCardClick(this)'>
                            <div class="kanban-card-header">
                                <span class='kanban-priority priority-<%# Eval("Priority").ToString().ToLower() %>'><%# Eval("Priority") %></span>
                                <span class="kanban-id">#<%# Eval("TaskID") %></span>
                            </div>
                            <div class="kanban-card-title"><%# Server.HtmlEncode(Eval("Title").ToString()) %></div>
                            <div class="kanban-card-footer">
                                <span class="kanban-assignee" title='<%# Server.HtmlEncode((Eval("AssignedToName") ?? "").ToString()) %>'>
                                    <span class="glyphicon glyphicon-user"></span>
                                    <%# Server.HtmlEncode(TruncateName((Eval("AssignedToName") ?? "Unassigned").ToString())) %>
                                </span>
                                <span class="kanban-due">
                                    <%# Eval("DueDate") != DBNull.Value ? Eval("DueDate", "{0:dd-MMM}") : "" %>
                                </span>
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
        </div>

        <!-- To Do Column -->
        <div class="kanban-column">
            <div class="kanban-column-header kanban-col-todo">
                <span class="glyphicon glyphicon-unchecked"></span> To Do
                <span class="kanban-count"><asp:Label ID="lblToDoCount" runat="server" Text="0" /></span>
            </div>
            <div class="kanban-column-body" id="colToDo" data-status="ToDo">
                <asp:Repeater ID="rptToDo" runat="server">
                    <ItemTemplate>
                        <div class="kanban-card" data-taskid='<%# Eval("TaskID") %>' data-steptype='<%# Eval("StepNodeType") %>' ondblclick='handleCardClick(this)'>
                            <div class="kanban-card-header">
                                <span class='kanban-priority priority-<%# Eval("Priority").ToString().ToLower() %>'><%# Eval("Priority") %></span>
                                <span class="kanban-id">#<%# Eval("TaskID") %></span>
                            </div>
                            <div class="kanban-card-title"><%# Server.HtmlEncode(Eval("Title").ToString()) %></div>
                            <div class="kanban-card-footer">
                                <span class="kanban-assignee" title='<%# Server.HtmlEncode((Eval("AssignedToName") ?? "").ToString()) %>'>
                                    <span class="glyphicon glyphicon-user"></span>
                                    <%# Server.HtmlEncode(TruncateName((Eval("AssignedToName") ?? "Unassigned").ToString())) %>
                                </span>
                                <span class="kanban-due">
                                    <%# Eval("DueDate") != DBNull.Value ? Eval("DueDate", "{0:dd-MMM}") : "" %>
                                </span>
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
        </div>

        <!-- In Progress Column -->
        <div class="kanban-column">
            <div class="kanban-column-header kanban-col-inprogress">
                <span class="glyphicon glyphicon-play"></span> In Progress
                <span class="kanban-count"><asp:Label ID="lblInProgressCount" runat="server" Text="0" /></span>
            </div>
            <div class="kanban-column-body" id="colInProgress" data-status="InProgress">
                <asp:Repeater ID="rptInProgress" runat="server">
                    <ItemTemplate>
                        <div class="kanban-card" data-taskid='<%# Eval("TaskID") %>' data-steptype='<%# Eval("StepNodeType") %>' ondblclick='handleCardClick(this)'>
                            <div class="kanban-card-header">
                                <span class='kanban-priority priority-<%# Eval("Priority").ToString().ToLower() %>'><%# Eval("Priority") %></span>
                                <span class="kanban-id">#<%# Eval("TaskID") %></span>
                            </div>
                            <div class="kanban-card-title"><%# Server.HtmlEncode(Eval("Title").ToString()) %></div>
                            <div class="kanban-card-footer">
                                <span class="kanban-assignee" title='<%# Server.HtmlEncode((Eval("AssignedToName") ?? "").ToString()) %>'>
                                    <span class="glyphicon glyphicon-user"></span>
                                    <%# Server.HtmlEncode(TruncateName((Eval("AssignedToName") ?? "Unassigned").ToString())) %>
                                </span>
                                <span class="kanban-due">
                                    <%# Eval("DueDate") != DBNull.Value ? Eval("DueDate", "{0:dd-MMM}") : "" %>
                                </span>
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
        </div>

        <!-- Review Column -->
        <div class="kanban-column">
            <div class="kanban-column-header kanban-col-review">
                <span class="glyphicon glyphicon-eye-open"></span> Review
                <span class="kanban-count"><asp:Label ID="lblReviewCount" runat="server" Text="0" /></span>
            </div>
            <div class="kanban-column-body" id="colReview" data-status="Review">
                <asp:Repeater ID="rptReview" runat="server">
                    <ItemTemplate>
                        <div class="kanban-card" data-taskid='<%# Eval("TaskID") %>' data-steptype='<%# Eval("StepNodeType") %>' ondblclick='handleCardClick(this)'>
                            <div class="kanban-card-header">
                                <span class='kanban-priority priority-<%# Eval("Priority").ToString().ToLower() %>'><%# Eval("Priority") %></span>
                                <span class="kanban-id">#<%# Eval("TaskID") %></span>
                            </div>
                            <div class="kanban-card-title"><%# Server.HtmlEncode(Eval("Title").ToString()) %></div>
                            <div class="kanban-card-footer">
                                <span class="kanban-assignee" title='<%# Server.HtmlEncode((Eval("AssignedToName") ?? "").ToString()) %>'>
                                    <span class="glyphicon glyphicon-user"></span>
                                    <%# Server.HtmlEncode(TruncateName((Eval("AssignedToName") ?? "Unassigned").ToString())) %>
                                </span>
                                <span class="kanban-due">
                                    <%# Eval("DueDate") != DBNull.Value ? Eval("DueDate", "{0:dd-MMM}") : "" %>
                                </span>
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
        </div>

        <!-- Done Column -->
        <div class="kanban-column">
            <div class="kanban-column-header kanban-col-done">
                <span class="glyphicon glyphicon-ok"></span> Done
                <span class="kanban-count"><asp:Label ID="lblDoneCount" runat="server" Text="0" /></span>
            </div>
            <div class="kanban-column-body" id="colDone" data-status="Done">
                <asp:Repeater ID="rptDone" runat="server">
                    <ItemTemplate>
                        <div class="kanban-card" data-taskid='<%# Eval("TaskID") %>' data-steptype='<%# Eval("StepNodeType") %>' ondblclick='handleCardClick(this)'>
                            <div class="kanban-card-header">
                                <span class='kanban-priority priority-<%# Eval("Priority").ToString().ToLower() %>'><%# Eval("Priority") %></span>
                                <span class="kanban-id">#<%# Eval("TaskID") %></span>
                            </div>
                            <div class="kanban-card-title"><%# Server.HtmlEncode(Eval("Title").ToString()) %></div>
                            <div class="kanban-card-footer">
                                <span class="kanban-assignee" title='<%# Server.HtmlEncode((Eval("AssignedToName") ?? "").ToString()) %>'>
                                    <span class="glyphicon glyphicon-user"></span>
                                    <%# Server.HtmlEncode(TruncateName((Eval("AssignedToName") ?? "Unassigned").ToString())) %>
                                </span>
                                <span class="kanban-due">
                                    <%# Eval("DueDate") != DBNull.Value ? Eval("DueDate", "{0:dd-MMM}") : "" %>
                                </span>
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
        </div>
    </div>

    <!-- Task Modal -->
    <div class="modal-overlay" id="taskModal" style="display:none;">
        <div class="modal-dialog">
            <div class="modal-header">
                <span class="glyphicon glyphicon-tasks"></span>
                <span id="modalTitle">New Task</span>
                <button type="button" class="modal-close" onclick="closeTaskModal()">&times;</button>
            </div>
            <div class="modal-body">
                <asp:HiddenField ID="hfEditTaskId" runat="server" Value="0" />

                <div class="form-row-4">
                    <div class="form-col-2x">
                        <div class="form-group">
                            <label>Task Title *</label>
                            <asp:TextBox ID="txtTaskTitle" runat="server" CssClass="form-control" MaxLength="500" />
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label>Priority</label>
                            <asp:DropDownList ID="ddlPriority" runat="server" CssClass="form-control">
                                <asp:ListItem Value="Low">Low</asp:ListItem>
                                <asp:ListItem Value="Medium" Selected="True">Medium</asp:ListItem>
                                <asp:ListItem Value="High">High</asp:ListItem>
                                <asp:ListItem Value="Critical">Critical</asp:ListItem>
                            </asp:DropDownList>
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label>Status</label>
                            <asp:DropDownList ID="ddlStatus" runat="server" CssClass="form-control">
                                <asp:ListItem Value="Backlog">Backlog</asp:ListItem>
                                <asp:ListItem Value="ToDo">To Do</asp:ListItem>
                                <asp:ListItem Value="InProgress">In Progress</asp:ListItem>
                                <asp:ListItem Value="Review">Review</asp:ListItem>
                                <asp:ListItem Value="Done">Done</asp:ListItem>
                            </asp:DropDownList>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <asp:TextBox ID="txtDescription" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="3" />
                </div>

                <div class="form-row-4">
                    <div class="form-col">
                        <div class="form-group">
                            <label>Assign To</label>
                            <asp:DropDownList ID="ddlAssignTo" runat="server" CssClass="form-control" />
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label>Due Date</label>
                            <asp:TextBox ID="txtDueDate" runat="server" CssClass="form-control" TextMode="Date" />
                        </div>
                    </div>
                    <div class="form-col-2x">
                        <div class="form-group">
                            <label>Linked Demand</label>
                            <asp:DropDownList ID="ddlDemandFund" runat="server" CssClass="form-control" />
                        </div>
                    </div>
                </div>

                <!-- Completion Percentage (for workflow tasks) -->
                <asp:Panel ID="pnlCompletion" runat="server" Visible="false">
                    <div class="form-group" style="margin-top:5px;">
                        <label style="font-weight:700;">Completion Percentage</label>
                        <div style="display:flex;align-items:center;gap:12px;">
                            <input type="range" id="rangeCompletionBoard" runat="server" min="0" max="100" step="5" value="0"
                                style="flex:1;" oninput="document.getElementById('lblPctBoard').textContent=this.value+'%';" />
                            <span id="lblPctBoard" style="font-size:16px;font-weight:700;min-width:45px;">0%</span>
                        </div>
                    </div>
                </asp:Panel>

                <!-- Approval Section (only for editing) -->
                <asp:Panel ID="pnlApproval" runat="server" Visible="false">
                    <div class="panel" style="margin-top:10px;">
                        <div class="panel-header"><span class="glyphicon glyphicon-thumbs-up"></span> Approvals</div>
                        <div class="panel-body">
                            <asp:GridView ID="gvApprovals" runat="server" AutoGenerateColumns="false"
                                CssClass="grid-view" EmptyDataText="No approvals requested.">
                                <Columns>
                                    <asp:BoundField DataField="ApproverName" HeaderText="Approver" />
                                    <asp:BoundField DataField="ApprovalStatus" HeaderText="Status" />
                                    <asp:BoundField DataField="Comments" HeaderText="Comments" />
                                    <asp:BoundField DataField="ApprovalDate" HeaderText="Date" DataFormatString="{0:dd-MMM-yyyy}" />
                                </Columns>
                            </asp:GridView>
                            <div class="form-row-4" style="margin-top:10px;">
                                <div class="form-col">
                                    <asp:DropDownList ID="ddlApprover" runat="server" CssClass="form-control" />
                                </div>
                                <div class="form-col-2x">
                                    <asp:TextBox ID="txtApprovalComments" runat="server" CssClass="form-control" placeholder="Comments..." />
                                </div>
                                <div class="form-col">
                                    <asp:Button ID="btnRequestApproval" runat="server" Text="Request Approval" CssClass="btn btn-warning btn-sm" OnClick="btnRequestApproval_Click" CausesValidation="false" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Status History -->
                    <div class="panel">
                        <div class="panel-header"><span class="glyphicon glyphicon-time"></span> Status History</div>
                        <div class="panel-body">
                            <asp:GridView ID="gvHistory" runat="server" AutoGenerateColumns="false"
                                CssClass="grid-view" EmptyDataText="No status changes recorded.">
                                <Columns>
                                    <asp:BoundField DataField="OldStatus" HeaderText="From" />
                                    <asp:BoundField DataField="NewStatus" HeaderText="To" />
                                    <asp:BoundField DataField="ChangedBy" HeaderText="Changed By" />
                                    <asp:BoundField DataField="ChangedDate" HeaderText="Date" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                                </Columns>
                            </asp:GridView>
                        </div>
                    </div>
                </asp:Panel>
            </div>
            <div class="modal-footer">
                <asp:Button ID="btnSaveTask" runat="server" Text="Save Task" CssClass="btn btn-primary" OnClick="btnSaveTask_Click" />
                <asp:Button ID="btnApproveWfStep" runat="server" Text="Approve" CssClass="btn btn-success" OnClick="btnApproveWfStep_Click" CausesValidation="false" Visible="false" />
                <asp:Button ID="btnRejectWfStep" runat="server" Text="Reject" CssClass="btn btn-danger" OnClick="btnRejectWfStep_Click" CausesValidation="false" Visible="false" />
                <asp:Button ID="btnDeleteTask" runat="server" Text="Delete" CssClass="btn btn-danger" OnClick="btnDeleteTask_Click" CausesValidation="false" Visible="false" />
                <button type="button" class="btn btn-secondary" onclick="closeTaskModal()">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Approval Action Modal -->
    <div class="modal-overlay" id="approvalModal" style="display:none;">
        <div class="modal-dialog" style="max-width:450px;">
            <div class="modal-header">
                <span class="glyphicon glyphicon-thumbs-up"></span> Pending Approvals
                <button type="button" class="modal-close" onclick="closeApprovalModal()">&times;</button>
            </div>
            <div class="modal-body">
                <asp:HiddenField ID="hfApprovalId" runat="server" Value="0" />
                <asp:HiddenField ID="hfApprovalAction" runat="server" Value="" />
                <asp:Repeater ID="rptPendingApprovals" runat="server">
                    <ItemTemplate>
                        <div class="approval-item">
                            <div><strong><%# Server.HtmlEncode(Eval("Title").ToString()) %></strong></div>
                            <div class="approval-meta">Requested by <%# Server.HtmlEncode(Eval("CreatedBy").ToString()) %></div>
                            <div class="approval-actions">
                                <asp:Button ID="btnApprove" runat="server" Text="Approve" CssClass="btn btn-success btn-sm"
                                    CommandArgument='<%# Eval("ApprovalID") %>' OnClick="btnApproveTask_Click" CausesValidation="false" />
                                <asp:Button ID="btnReject" runat="server" Text="Reject" CssClass="btn btn-danger btn-sm"
                                    CommandArgument='<%# Eval("ApprovalID") %>' OnClick="btnRejectTask_Click" CausesValidation="false" />
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeApprovalModal()">Close</button>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        // Initialize SortableJS for each kanban column
        document.addEventListener('DOMContentLoaded', function () {
            var columns = ['colBacklog', 'colToDo', 'colInProgress', 'colReview', 'colDone'];
            var moveLog = [];

            columns.forEach(function (colId) {
                var el = document.getElementById(colId);
                if (!el) return;

                Sortable.create(el, {
                    group: 'kanban',
                    animation: 200,
                    ghostClass: 'kanban-card-ghost',
                    dragClass: 'kanban-card-drag',
                    handle: '.kanban-card',
                    onEnd: function (evt) {
                        var taskId = evt.item.getAttribute('data-taskid');
                        var newStatus = evt.to.getAttribute('data-status');
                        var newIndex = evt.newIndex;

                        moveLog.push(taskId + '|' + newStatus + '|' + newIndex);

                        // Update hidden field and trigger postback
                        var hf = document.getElementById('<%= hfTaskMoves.ClientID %>');
                        hf.value = moveLog.join(';');

                        // Auto-save after drag
                        document.getElementById('<%= btnApplyMoves.ClientID %>').click();
                    }
                });
            });
        });

        function handleCardClick(el) {
            var stepType = el.getAttribute('data-steptype') || '';
            var taskId = parseInt(el.getAttribute('data-taskid')) || 0;
            if (stepType === 'user-task') {
                window.location.href = '<%= ResolveUrl("~/Forms/MyTasks.aspx") %>?taskId=' + taskId;
                return;
            }
            if (stepType === 'approval') {
                window.location.href = '<%= ResolveUrl("~/Forms/MyApprovals.aspx") %>?taskId=' + taskId;
                return;
            }
            showTaskModal(taskId);
        }

        function showTaskModal(taskId) {
            document.getElementById('<%= hfEditTaskId.ClientID %>').value = taskId;
            if (taskId > 0) {
                document.getElementById('modalTitle').textContent = 'Edit Task #' + taskId;
                // Trigger server-side load
                __doPostBack('<%= btnSaveTask.UniqueID %>', 'LOAD|' + taskId);
            } else {
                document.getElementById('modalTitle').textContent = 'New Task';
                document.getElementById('taskModal').style.display = 'flex';
            }
        }

        function closeTaskModal() {
            document.getElementById('taskModal').style.display = 'none';
        }

        function closeApprovalModal() {
            document.getElementById('approvalModal').style.display = 'none';
        }

        function toggleNotifications() {
            var panel = document.getElementById('notifPanel');
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        }

        // Close notification panel when clicking outside
        document.addEventListener('click', function (e) {
            var panel = document.getElementById('notifPanel');
            var bell = document.getElementById('notifBell');
            if (panel && bell && !panel.contains(e.target) && !bell.contains(e.target)) {
                panel.style.display = 'none';
            }
        });

        function markNotifRead(notifId, el) {
            $.ajax({
                type: 'POST', url: 'WorkflowBoard.aspx/MarkNotificationRead',
                data: JSON.stringify({ notificationId: notifId }),
                contentType: 'application/json',
                success: function() { $(el).removeClass('notif-unread'); }
            });
        }

        // Show modal after postback if needed
        var showModal = '<%= ViewState["ShowModal"] ?? "" %>';
        if (showModal === 'task') {
            document.getElementById('taskModal').style.display = 'flex';
            // Restore completion slider label
            var slider = document.getElementById('<%= rangeCompletionBoard.ClientID %>');
            if (slider) {
                var lbl = document.getElementById('lblPctBoard');
                if (lbl) lbl.textContent = slider.value + '%';
            }
        }
    </script>
</asp:Content>
