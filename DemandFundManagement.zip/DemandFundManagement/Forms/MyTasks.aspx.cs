using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class MyTasks : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserID"] == null) Response.Redirect("~/Login.aspx");
            if (!IsPostBack)
            {
                BindGrid();
                string taskIdParam = Request.QueryString["taskId"];
                int taskId;
                if (!string.IsNullOrEmpty(taskIdParam) && int.TryParse(taskIdParam, out taskId) && taskId > 0)
                {
                    LoadTaskAction(taskId);
                }
            }
        }

        private void BindGrid()
        {
            int userId = Convert.ToInt32(Session["UserID"]);
            DataTable dt = DatabaseHelper.GetMyWorkflowTasks(userId);
            gvMyTasks.DataSource = dt;
            gvMyTasks.DataBind();
        }

        protected void gvMyTasks_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "ActionTask") return;
            int taskId;
            if (!int.TryParse(e.CommandArgument.ToString(), out taskId)) return;
            LoadTaskAction(taskId);
        }

        private void LoadTaskAction(int taskId)
        {
            DataRow task = DatabaseHelper.GetWorkflowTaskById(taskId);
            if (task == null) return;

            hfTaskId.Value = taskId.ToString();
            hfInstanceId.Value = task["InstanceID"] != DBNull.Value ? task["InstanceID"].ToString() : "";
            hfStepId.Value = task["StepID"] != DBNull.Value ? task["StepID"].ToString() : "";

            lblTaskTitle.Text = Server.HtmlEncode(task["Title"].ToString());
            lblDescription.Text = task["Description"] != DBNull.Value ? Server.HtmlEncode(task["Description"].ToString()) : "";
            lblPriority.Text = task["Priority"].ToString();
            lblLinkedTable.Text = task["LinkedTable"] != DBNull.Value ? task["LinkedTable"].ToString() : "";
            lblRecordId.Text = task["LinkedRecordID"] != DBNull.Value ? task["LinkedRecordID"].ToString() : "";

            // Get workflow name from instance
            if (task["InstanceID"] != DBNull.Value)
            {
                DataRow inst = DatabaseHelper.GetWorkflowInstanceById(Convert.ToInt32(task["InstanceID"]));
                if (inst != null)
                {
                    int defId = Convert.ToInt32(inst["DefinitionID"]);
                    DataTable wfDef = DatabaseHelper.ExecuteQuery(
                        "SELECT Name FROM WorkflowDefinitions WHERE DefinitionID=@ID",
                        new System.Data.SqlClient.SqlParameter("@ID", defId));
                    lblWorkflowName.Text = wfDef.Rows.Count > 0 ? wfDef.Rows[0]["Name"].ToString() : "";
                }
            }

            int pct = task.Table.Columns.Contains("CompletionPercentage") && task["CompletionPercentage"] != DBNull.Value
                ? Convert.ToInt32(task["CompletionPercentage"]) : 0;
            ViewState["CurrentPct"] = pct.ToString();
            ViewState["ShowModal"] = "action";
        }

        protected void btnUpdateProgress_Click(object sender, EventArgs e)
        {
            int taskId;
            if (!int.TryParse(hfTaskId.Value, out taskId) || taskId == 0) return;

            int pct = 0;
            string pctStr = Request.Form["rangeCompletion"];
            if (!string.IsNullOrEmpty(pctStr)) int.TryParse(pctStr, out pct);

            if (pct < 0) pct = 0;
            if (pct > 100) pct = 100;

            DatabaseHelper.UpdateTaskCompletionPercentage(taskId, pct);
            ShowMessage("Progress updated to " + pct + "%.", false);
            BindGrid();

            if (pct < 100) LoadTaskAction(taskId);
        }

        protected void btnCompleteTask_Click(object sender, EventArgs e)
        {
            int taskId;
            if (!int.TryParse(hfTaskId.Value, out taskId) || taskId == 0) return;

            // Verify task is at 100%
            DataRow task = DatabaseHelper.GetWorkflowTaskById(taskId);
            if (task == null) return;

            int pct = task.Table.Columns.Contains("CompletionPercentage") && task["CompletionPercentage"] != DBNull.Value
                ? Convert.ToInt32(task["CompletionPercentage"]) : 0;

            if (pct < 100)
            {
                ShowMessage("Task must be at 100% completion before it can be completed. Current: " + pct + "%.", true);
                LoadTaskAction(taskId);
                return;
            }

            // Mark task as Done
            string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
            DatabaseHelper.UpdateWorkflowTaskStatus(taskId, "Done", currentUser);

            // Advance workflow
            if (task["InstanceID"] != DBNull.Value && task["StepID"] != DBNull.Value)
            {
                int instanceId = Convert.ToInt32(task["InstanceID"]);
                int stepId = Convert.ToInt32(task["StepID"]);
                try
                {
                    WorkflowDesigner.CompleteWorkflowStep(instanceId, stepId, "Approve", "Task completed from My Tasks");
                }
                catch (Exception ex)
                {
                    ShowMessage("Task completed but workflow advance failed: " + ex.Message, true);
                    BindGrid();
                    return;
                }
            }

            ShowMessage("Task completed and workflow advanced.", false);
            BindGrid();
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
