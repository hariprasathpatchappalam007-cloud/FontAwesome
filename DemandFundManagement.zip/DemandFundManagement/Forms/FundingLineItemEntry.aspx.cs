using System;
using System.Data;
using System.Web.UI;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class FundingLineItemEntry : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string idParam = Request.QueryString["id"];
                if (!string.IsNullOrEmpty(idParam))
                {
                    int id;
                    if (int.TryParse(idParam, out id) && id > 0)
                    {
                        hdnRecordID.Value = id.ToString();
                        hdnRecordIDForWF.Value = id.ToString();
                        lblPageTitle.Text = "Edit Funding Line Item (ID: " + id + ")";
                        LoadRecord(id);
                        pnlWorkflowTrigger.Visible = true;
                    }
                }
            }
        }

        private void LoadRecord(int id)
        {
            DataRow row = DatabaseHelper.GetFundingLineItemById(id);
            if (row == null) { ShowMessage("Record not found.", true); return; }

            txtProgramTitle.Text = row["ProgramTitle"] != DBNull.Value ? row["ProgramTitle"].ToString() : "";
            txtTitle.Text = row["Title"] != DBNull.Value ? row["Title"].ToString() : "";
            txtAllocationType.Text = row["AllocationType"] != DBNull.Value ? row["AllocationType"].ToString() : "";
            txtAllocationSubType.Text = row["AllocationSubType"] != DBNull.Value ? row["AllocationSubType"].ToString() : "";
            txtLineItemID.Text = row["LineItemID"] != DBNull.Value ? row["LineItemID"].ToString() : "";
            txtSubCAPEXID.Text = row["SubCAPEXID"] != DBNull.Value ? row["SubCAPEXID"].ToString() : "";
            txtVendor.Text = row["Vendor"] != DBNull.Value ? row["Vendor"].ToString() : "";
            txtAmount.Text = row["Amount"] != DBNull.Value ? Convert.ToDecimal(row["Amount"]).ToString("0.##") : "";
            txtConsumed.Text = row["Consumed"] != DBNull.Value ? Convert.ToDecimal(row["Consumed"]).ToString("0.##") : "";
            txtBlockedAmount.Text = row["BlockedAmount"] != DBNull.Value ? Convert.ToDecimal(row["BlockedAmount"]).ToString("0.##") : "";
            txtRemainingAmount.Text = row["RemainingAmount"] != DBNull.Value ? Convert.ToDecimal(row["RemainingAmount"]).ToString("0.##") : "";
        }

        protected void btnSave_Click(object sender, EventArgs e) { SaveRecord(false); }
        protected void btnSaveNew_Click(object sender, EventArgs e) { SaveRecord(true); }

        private void SaveRecord(bool redirectToNew)
        {
            try
            {
                decimal? amount = ParseDecimal(txtAmount.Text);
                decimal? consumed = ParseDecimal(txtConsumed.Text);
                decimal? blockedAmount = ParseDecimal(txtBlockedAmount.Text);
                decimal? remainingAmount = ParseDecimal(txtRemainingAmount.Text);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";

                int recordId = 0;
                int.TryParse(hdnRecordID.Value, out recordId);

                if (recordId > 0)
                {
                    DatabaseHelper.UpdateFundingLineItem(recordId, txtProgramTitle.Text.Trim(), txtTitle.Text.Trim(),
                        txtAllocationType.Text.Trim(), txtAllocationSubType.Text.Trim(), txtLineItemID.Text.Trim(),
                        txtSubCAPEXID.Text.Trim(), txtVendor.Text.Trim(), amount, consumed, blockedAmount,
                        remainingAmount, currentUser);
                    ShowMessage("Record updated successfully (ID: " + recordId + ").", false);
                }
                else
                {
                    int newId = DatabaseHelper.InsertFundingLineItem(txtProgramTitle.Text.Trim(), txtTitle.Text.Trim(),
                        txtAllocationType.Text.Trim(), txtAllocationSubType.Text.Trim(), txtLineItemID.Text.Trim(),
                        txtSubCAPEXID.Text.Trim(), txtVendor.Text.Trim(), amount, consumed, blockedAmount,
                        remainingAmount, currentUser);
                    ShowMessage("Record saved successfully (ID: " + newId + ").", false);
                    hdnRecordID.Value = newId.ToString();
                    hdnRecordIDForWF.Value = newId.ToString();
                    pnlWorkflowTrigger.Visible = true;
                }

                if (redirectToNew) Response.Redirect("~/Forms/FundingLineItemEntry.aspx");
            }
            catch (Exception ex) { ShowMessage("Error: " + ex.Message, true); }
        }

        private decimal? ParseDecimal(string val)
        {
            decimal d;
            return decimal.TryParse(val, out d) ? (decimal?)d : null;
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
