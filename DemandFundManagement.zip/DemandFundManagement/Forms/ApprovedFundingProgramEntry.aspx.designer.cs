namespace DemandFundManagement.Forms
{
    public partial class ApprovedFundingProgramEntry
    {
        protected global::System.Web.UI.WebControls.Label lblPageTitle;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hdnRecordID;
        protected global::System.Web.UI.WebControls.TextBox txtTitle;
        protected global::System.Web.UI.WebControls.TextBox txtType;
        protected global::System.Web.UI.WebControls.TextBox txtDemandID;
        protected global::System.Web.UI.WebControls.TextBox txtApprover;
        protected global::System.Web.UI.WebControls.TextBox txtPrimaryLead;
        protected global::System.Web.UI.WebControls.TextBox txtGL;
        protected global::System.Web.UI.WebControls.TextBox txtCAPEX;
        protected global::System.Web.UI.WebControls.TextBox txtCAPEXType;
        protected global::System.Web.UI.WebControls.TextBox txtStatus;
        protected global::System.Web.UI.WebControls.TextBox txtFundAmount;
        protected global::System.Web.UI.WebControls.TextBox txtConsumed;
        protected global::System.Web.UI.WebControls.TextBox txtAvailable;
        protected global::System.Web.UI.WebControls.TextBox txtPlanned;
        protected global::System.Web.UI.WebControls.TextBox txtApprovalForm;
        protected global::System.Web.UI.WebControls.TextBox txtRemarks;
        protected global::System.Web.UI.WebControls.TextBox txtProgramOwner;
        protected global::System.Web.UI.WebControls.LinkButton btnSave;
        protected global::System.Web.UI.WebControls.LinkButton btnSaveNew;
        protected global::System.Web.UI.WebControls.HyperLink lnkCancel;
        protected global::System.Web.UI.WebControls.Panel pnlWorkflowTrigger;
        protected global::System.Web.UI.WebControls.HiddenField hdnRecordIDForWF;
    }
}
