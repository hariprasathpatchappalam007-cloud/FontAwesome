<%@ Page Title="Demand Fund List" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="DemandFundList.aspx.cs" Inherits="DemandFundManagement.Forms.DemandFundList" %>



<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title"><span class="glyphicon glyphicon-list-alt"></span> Demand Fund List</h2>

    <div class="btn-group" style="margin-bottom:15px;">
        <asp:HyperLink ID="lnkNewEntry" runat="server" CssClass="btn btn-primary" NavigateUrl="~/Forms/DemandFundEntry.aspx"><span class="glyphicon glyphicon-plus"></span> New Demand Fund Entry</asp:HyperLink>
    </div>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- Bulk Upload Section -->
    <div class="panel">
        <div class="panel-header">
            <span class="glyphicon glyphicon-cloud-upload"></span> Bulk Upload
            <span class="bulk-upload-note">(Select upload mode below)</span>
        </div>
        <div class="panel-body">
            <div class="bulk-upload-row">
                <div class="bulk-upload-zone" id="bulkDropZone">
                    <span class="glyphicon glyphicon-file bulk-upload-icon"></span>
                    <span class="bulk-upload-hint">Drop Excel/CSV file here or click to browse</span>
                    <asp:FileUpload ID="fuBulkUpload" runat="server" CssClass="drop-zone-input" accept=".csv,.xls,.xlsx" />
                    <div class="bulk-upload-file" id="bulkFileInfo" style="display:none;">
                        <span class="glyphicon glyphicon-file"></span>
                        <span class="file-name" id="bulkFileName"></span>
                        <span class="file-size" id="bulkFileSize"></span>
                    </div>
                </div>
                <asp:LinkButton ID="btnUpload" runat="server" CssClass="btn btn-primary" OnClick="btnUpload_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-upload"></span> Upload
                </asp:LinkButton>
            </div>
            <div class="bulk-upload-mode" style="margin:10px 0;">
                <asp:RadioButtonList ID="rblUploadMode" runat="server" RepeatDirection="Horizontal" RepeatLayout="Flow" CssClass="upload-mode-radio">
                    <asp:ListItem Value="replace" Selected="True"> Delete existing &amp; replace</asp:ListItem>
                    <asp:ListItem Value="append"> Retain existing &amp; append</asp:ListItem>
                </asp:RadioButtonList>
            </div>
            <div class="bulk-upload-columns">
                <strong>Expected Columns:</strong> Initiative Title, Description, Demand Type, DAMO Approved, Engineering Lead, Funding Source, Funds Approved By, GL Code, Phase Description, Primary Business Owner, Remarks, Business Vertical, Digital Project, Delivery Manager, Initiative Type, Platform Owner, Portfolio Head, Technology Vertical, Initiative Size, Project Type
            </div>
        </div>
    </div>

    <div class="panel">
        <div class="panel-header"><span class="glyphicon glyphicon-th-list"></span> All Demand Fund Entries</div>
        <div class="panel-body" style="overflow-x:auto;">
            <asp:GridView ID="gvDemandFunds" runat="server" AutoGenerateColumns="false"
                CssClass="grid-view" EmptyDataText="No demand fund entries found."
                AllowPaging="true" PageSize="20" OnPageIndexChanging="gvDemandFunds_PageIndexChanging"
                AllowSorting="true" OnSorting="gvDemandFunds_Sorting">
                <Columns>
                    <asp:BoundField DataField="ID" HeaderText="ID" SortExpression="ID" ItemStyle-Width="50px" />
                    <asp:BoundField DataField="InitiativeTitle" HeaderText="Initiative Title" SortExpression="InitiativeTitle" />
                    <asp:BoundField DataField="DemandType" HeaderText="DAMO Type" />
                    <asp:TemplateField HeaderText="DAMO Approved">
                        <ItemTemplate>
                            <span class='<%# Convert.ToBoolean(Eval("DAMO_Approved")) ? "badge badge-active" : "badge badge-inactive" %>'>
                                <%# Convert.ToBoolean(Eval("DAMO_Approved")) ? "Yes" : "No" %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="Engineering_Lead" HeaderText="Eng. Lead" />
                    <asp:BoundField DataField="FundingSource" HeaderText="Funding Source" />
                    <asp:BoundField DataField="ProjectPhase" HeaderText="Phase" SortExpression="ProjectPhase" />
                    <asp:BoundField DataField="BusinessVertical" HeaderText="Business Vertical" />
                    <asp:BoundField DataField="Initiative_Type" HeaderText="Initiative Type" />
                    <asp:BoundField DataField="Platform_Owner" HeaderText="Platform Owner" />
                    <asp:BoundField DataField="Portfolio_Head" HeaderText="Portfolio Head" />
                    <asp:BoundField DataField="InitiativeSize" HeaderText="Size" />
                    <asp:BoundField DataField="Project_Type" HeaderText="Project Type" />
                    <asp:TemplateField HeaderText="Digital">
                        <ItemTemplate>
                            <span class='<%# Convert.ToBoolean(Eval("Digital_Project")) ? "badge badge-active" : "" %>'>
                                <%# Convert.ToBoolean(Eval("Digital_Project")) ? "Yes" : "" %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="CreatedDate" HeaderText="Created" DataFormatString="{0:dd-MMM-yyyy}" SortExpression="CreatedDate" />
                    <asp:HyperLinkField Text="Edit" DataNavigateUrlFields="ID"
                        DataNavigateUrlFormatString="~/Forms/DemandFundEntry.aspx?id={0}"
                        ItemStyle-Width="50px" ControlStyle-CssClass="btn btn-sm btn-primary" />
                </Columns>
                <PagerStyle CssClass="grid-pager" />
            </asp:GridView>
        </div>
    </div>

    <script type="text/javascript">
        (function () {
            var zone = document.getElementById('bulkDropZone');
            if (!zone) return;
            var input = zone.querySelector('input[type="file"]');
            zone.addEventListener('click', function (e) {
                if (e.target.type !== 'file') input.click();
            });
            zone.addEventListener('dragover', function (e) { e.preventDefault(); zone.classList.add('drop-zone-active'); });
            zone.addEventListener('dragleave', function (e) { e.preventDefault(); zone.classList.remove('drop-zone-active'); });
            zone.addEventListener('drop', function (e) {
                e.preventDefault(); zone.classList.remove('drop-zone-active');
                if (e.dataTransfer.files.length > 0) {
                    try { var dt = new DataTransfer(); dt.items.add(e.dataTransfer.files[0]); input.files = dt.files; } catch (ex) { }
                    showBulkFile(e.dataTransfer.files[0]);
                }
            });
            input.addEventListener('change', function () { if (input.files.length > 0) showBulkFile(input.files[0]); });

            function showBulkFile(file) {
                var info = document.getElementById('bulkFileInfo');
                document.getElementById('bulkFileName').textContent = file.name;
                var kb = (file.size / 1024).toFixed(1);
                document.getElementById('bulkFileSize').textContent = kb > 1024 ? (kb / 1024).toFixed(1) + ' MB' : kb + ' KB';
                info.style.display = 'flex';
            }
        })();
    </script>
</asp:Content>
