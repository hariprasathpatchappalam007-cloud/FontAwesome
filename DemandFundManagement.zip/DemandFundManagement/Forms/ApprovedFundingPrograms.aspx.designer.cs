namespace DemandFundManagement.Forms
{
    public partial class ApprovedFundingPrograms
    {
        protected global::System.Web.UI.WebControls.HyperLink lnkNewEntry;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.FileUpload fuBulkUpload;
        protected global::System.Web.UI.WebControls.LinkButton btnUpload;
        protected global::System.Web.UI.WebControls.RadioButtonList rblUploadMode;
        protected global::System.Web.UI.WebControls.GridView gvData;
        protected global::System.Web.UI.WebControls.Label lblRecordCount;
    }
}
