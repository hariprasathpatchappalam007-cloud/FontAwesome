namespace DemandFundManagement.Forms
{
    public partial class MyTasks
    {
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.GridView gvMyTasks;
        protected global::System.Web.UI.HtmlControls.HtmlGenericControl taskActionModal;
        protected global::System.Web.UI.WebControls.HiddenField hfTaskId;
        protected global::System.Web.UI.WebControls.HiddenField hfInstanceId;
        protected global::System.Web.UI.WebControls.HiddenField hfStepId;
        protected global::System.Web.UI.WebControls.Label lblTaskTitle;
        protected global::System.Web.UI.WebControls.Label lblWorkflowName;
        protected global::System.Web.UI.WebControls.Label lblDescription;
        protected global::System.Web.UI.WebControls.Label lblLinkedTable;
        protected global::System.Web.UI.WebControls.Label lblRecordId;
        protected global::System.Web.UI.WebControls.Label lblPriority;
        protected global::System.Web.UI.WebControls.TextBox txtComments;
        protected global::System.Web.UI.WebControls.Button btnUpdateProgress;
        protected global::System.Web.UI.WebControls.Button btnCompleteTask;
    }
}
