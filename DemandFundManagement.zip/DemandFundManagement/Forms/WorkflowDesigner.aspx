<%@ Page Title="Workflow Designer" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="WorkflowDesigner.aspx.cs" Inherits="DemandFundManagement.Forms.WorkflowDesigner" %>



<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

    <!-- Top Toolbar -->
    <div class="wfd-toolbar">
        <div class="wfd-toolbar-left">
            <span class="glyphicon glyphicon-pencil" style="color:var(--primary);font-size:18px;"></span>
            <span class="wfd-toolbar-title">Workflow Designer</span>
        </div>
        <div class="wfd-toolbar-center">
            <select id="ddlWorkflows" class="form-control no-select2" style="width:180px;display:inline-block;height:32px;" onchange="loadSelectedWorkflow()">
                <option value="0">-- New Workflow --</option>
            </select>
            <input type="text" id="txtWfName" class="form-control" placeholder="Workflow name..." style="width:180px;display:inline-block;height:32px;" />
            <select id="ddlLinkedTable" class="form-control no-select2" style="width:190px;display:inline-block;height:32px;" onchange="onLinkedTableChange()">
                <option value="">-- Select Table --</option>
                <option value="DemandFund">Demand Fund</option>
                <option value="SpendingAllocation">Spending Allocation</option>
                <option value="ApprovedFundingPrograms">Approved Funding</option>
                <option value="FundingLineItems">Funding Line Items</option>
            </select>
        </div>
        <div class="wfd-toolbar-right">
            <button type="button" class="btn btn-primary btn-sm" onclick="saveWorkflow()"><span class="glyphicon glyphicon-floppy-disk"></span> Save</button>
            <button type="button" class="btn btn-success btn-sm" onclick="publishWorkflow()"><span class="glyphicon glyphicon-ok"></span> Publish</button>
            <button type="button" class="btn btn-warning btn-sm" onclick="deleteWorkflow()"><span class="glyphicon glyphicon-remove"></span> Delete</button>
            <button type="button" class="btn btn-danger btn-sm" onclick="clearCanvas()"><span class="glyphicon glyphicon-trash"></span> Clear</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="toggleMsgPanel()" title="Messaging"><span class="glyphicon glyphicon-comment"></span></button>
        </div>
    </div>

    <!-- Hidden fields for server communication -->
    <asp:HiddenField ID="hfCurrentUserId" runat="server" />
    <asp:HiddenField ID="hfCurrentUserName" runat="server" />

    <div class="wfd-container">
        <!-- LEFT: Task Palette -->
        <div class="wfd-palette" id="wfdPalette">
            <div class="wfd-palette-header">Task Components</div>

            <div class="wfd-palette-item" draggable="true" data-type="start">
                <div class="wfd-palette-icon" style="background:#4CAF50;"><span class="glyphicon glyphicon-play"></span></div>
                <span>Start</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="end">
                <div class="wfd-palette-icon" style="background:#f44336;"><span class="glyphicon glyphicon-stop"></span></div>
                <span>End</span>
            </div>

            <div class="wfd-palette-divider"></div>

            <div class="wfd-palette-item" draggable="true" data-type="user-task">
                <div class="wfd-palette-icon" style="background:#2196F3;"><span class="glyphicon glyphicon-user"></span></div>
                <span>User Task</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="approval">
                <div class="wfd-palette-icon" style="background:#00BCD4;"><span class="glyphicon glyphicon-check"></span></div>
                <span>Approval Task</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="decision">
                <div class="wfd-palette-icon" style="background:#FF9800;"><span class="glyphicon glyphicon-random"></span></div>
                <span>Decision Task</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="decision-table">
                <div class="wfd-palette-icon" style="background:#9C27B0;"><span class="glyphicon glyphicon-th"></span></div>
                <span>Decision Table</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="web-service">
                <div class="wfd-palette-icon" style="background:#3F51B5;"><span class="glyphicon glyphicon-cloud"></span></div>
                <span>Web Service</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="email">
                <div class="wfd-palette-icon" style="background:#E91E63;"><span class="glyphicon glyphicon-envelope"></span></div>
                <span>Email Task</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="delay-timer">
                <div class="wfd-palette-icon" style="background:#FFC107;color:#333;"><span class="glyphicon glyphicon-time"></span></div>
                <span>Delay Timer</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="db-task">
                <div class="wfd-palette-icon" style="background:#795548;"><span class="glyphicon glyphicon-hdd"></span></div>
                <span>DB Task</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="call-workflow">
                <div class="wfd-palette-icon" style="background:#607D8B;"><span class="glyphicon glyphicon-retweet"></span></div>
                <span>Call Workflow</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="compute">
                <div class="wfd-palette-icon" style="background:#009688;"><span class="glyphicon glyphicon-cog"></span></div>
                <span>Compute Task</span>
            </div>
            <div class="wfd-palette-item" draggable="true" data-type="excel-report">
                <div class="wfd-palette-icon" style="background:#8BC34A;"><span class="glyphicon glyphicon-file"></span></div>
                <span>Excel Report</span>
            </div>
        </div>

        <!-- CENTER: Canvas -->
        <div class="wfd-canvas-wrapper" id="canvasWrapper">
            <div class="wfd-canvas" id="wfdCanvas">
                <svg class="wfd-svg" id="wfdSvg">
                    <defs>
                        <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                            <polygon points="0 0, 10 3.5, 0 7" fill="#4CAF50" />
                        </marker>
                    </defs>
                </svg>
                <!-- Nodes will be created dynamically here -->
            </div>
        </div>

        <!-- RIGHT: Messaging Panel -->
        <div class="wfd-msg-panel" id="msgPanel" style="display:none;">
            <div class="wfd-msg-header">
                <span class="glyphicon glyphicon-comment"></span> Messaging
                <button type="button" class="wfd-msg-close" onclick="toggleMsgPanel()">&times;</button>
            </div>

            <!-- Contact List -->
            <div class="wfd-msg-contacts" id="msgContacts">
                <div class="wfd-msg-search">
                    <span class="glyphicon glyphicon-search"></span>
                    <input type="text" id="msgSearch" placeholder="Search..." oninput="filterContacts()" />
                </div>
                <div class="wfd-msg-contact-list" id="contactList">
                    <!-- contacts loaded dynamically -->
                </div>
            </div>

            <!-- Chat View -->
            <div class="wfd-msg-chat" id="msgChat" style="display:none;">
                <div class="wfd-msg-chat-header" id="chatHeader">
                    <button type="button" class="wfd-msg-back" onclick="showContacts()"><span class="glyphicon glyphicon-chevron-left"></span></button>
                    <div class="wfd-msg-chat-avatar" id="chatAvatar"></div>
                    <span id="chatUserName"></span>
                </div>
                <div class="wfd-msg-chat-body" id="chatBody">
                    <!-- messages loaded dynamically -->
                </div>
                <div class="wfd-msg-chat-input">
                    <input type="text" id="msgInput" placeholder="Write your message..." onkeypress="if(event.key==='Enter')sendMsg();" />
                    <button type="button" class="wfd-msg-send" onclick="sendMsg()"><span class="glyphicon glyphicon-send"></span></button>
                </div>
            </div>
        </div>
    </div>

    <!-- Node Properties Modal -->
    <div class="modal-overlay" id="nodePropsModal" style="display:none;">
        <div class="modal-dialog" style="max-width:500px;">
            <div class="modal-header">
                <span class="glyphicon glyphicon-cog"></span> Node Properties
                <button type="button" class="modal-close" onclick="closeNodeProps()">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="propNodeId" />
                <div class="form-group">
                    <label>Label</label>
                    <input type="text" id="propLabel" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea id="propDescription" class="form-control" rows="3"></textarea>
                </div>
                <div class="form-group" id="propAssigneeGroup" style="display:none;">
                    <label>Assigned To</label>
                    <select id="propAssignee" class="form-control no-select2">
                        <option value="">-- Select User --</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="saveNodeProps()">Apply</button>
                <button type="button" class="btn btn-danger" onclick="deleteSelectedNode()"><span class="glyphicon glyphicon-trash"></span> Delete Node</button>
                <button type="button" class="btn btn-secondary" onclick="closeNodeProps()">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Email Config Modal -->
    <div class="modal-overlay" id="emailConfigModal" style="display:none;">
        <div class="modal-dialog" style="max-width:600px;">
            <div class="modal-header">
                <span class="glyphicon glyphicon-envelope"></span> Email Configuration
                <button type="button" class="modal-close" onclick="closeEmailConfig()">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="emailNodeId" />
                <div class="form-group">
                    <label>Label</label>
                    <input type="text" id="emailLabel" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Recipients</label>
                    <div style="margin-bottom:6px;">
                        <label style="font-weight:normal;margin-right:14px;"><input type="checkbox" id="emailToInitiator" /> Workflow Initiator</label>
                        <label style="font-weight:normal;margin-right:14px;"><input type="checkbox" id="emailToApprovers" /> Approver(s)</label>
                    </div>
                    <div class="form-group" style="margin-bottom:6px;">
                        <label style="font-weight:normal;">Specific Role</label>
                        <select id="emailToRole" class="form-control no-select2" style="height:32px;">
                            <option value="">-- None --</option>
                        </select>
                    </div>
                    <div class="form-group" style="margin-bottom:6px;">
                        <label style="font-weight:normal;">Specific Users</label>
                        <select id="emailToUsers" class="form-control no-select2" multiple="multiple" style="height:80px;">
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Subject <small style="color:var(--text-muted);">(use {{FieldName}} for dynamic values)</small></label>
                    <div style="display:flex;gap:6px;">
                        <input type="text" id="emailSubject" class="form-control" style="flex:1;" />
                        <button type="button" class="btn btn-default btn-sm" onclick="insertFieldToken('emailSubject')" title="Insert field"><span class="glyphicon glyphicon-plus"></span> Field</button>
                    </div>
                </div>
                <div class="form-group">
                    <label>Body <small style="color:var(--text-muted);">(use {{FieldName}} for dynamic values)</small></label>
                    <div style="display:flex;gap:6px;align-items:start;">
                        <textarea id="emailBody" class="form-control" rows="5" style="flex:1;"></textarea>
                        <button type="button" class="btn btn-default btn-sm" onclick="insertFieldToken('emailBody')" title="Insert field"><span class="glyphicon glyphicon-plus"></span> Field</button>
                    </div>
                </div>
                <div class="form-group" id="emailFieldPickerGroup" style="display:none;border:1px solid var(--border-color);border-radius:6px;padding:10px;background:var(--grid-stripe);">
                    <label>Select Field to Insert</label>
                    <select id="emailFieldPicker" class="form-control no-select2" style="height:32px;">
                        <option value="">-- Select Field --</option>
                    </select>
                    <div style="margin-top:6px;text-align:right;">
                        <button type="button" class="btn btn-primary btn-sm" onclick="confirmFieldInsert()">Insert</button>
                        <button type="button" class="btn btn-default btn-sm" onclick="cancelFieldInsert()">Cancel</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="saveEmailConfig()">Apply</button>
                <button type="button" class="btn btn-danger" onclick="deleteSelectedNode()"><span class="glyphicon glyphicon-trash"></span> Delete</button>
                <button type="button" class="btn btn-secondary" onclick="closeEmailConfig()">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Decision Rule Config Modal -->
    <div class="modal-overlay" id="decisionConfigModal" style="display:none;">
        <div class="modal-dialog" style="max-width:650px;">
            <div class="modal-header">
                <span class="glyphicon glyphicon-random"></span> Decision Rules
                <button type="button" class="modal-close" onclick="closeDecisionConfig()">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="decisionNodeId" />
                <div class="form-group">
                    <label>Label</label>
                    <input type="text" id="decisionLabel" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea id="decisionDescription" class="form-control" rows="2"></textarea>
                </div>
                <hr style="margin:10px 0;" />
                <label style="font-weight:700;">Condition Rules <small style="font-weight:normal;color:var(--text-muted);">(If ALL conditions match → Yes path, otherwise → No path)</small></label>
                <div id="decisionRulesContainer" style="margin-top:8px;"></div>
                <button type="button" class="btn btn-default btn-sm" onclick="addDecisionRule()" style="margin-top:6px;">
                    <span class="glyphicon glyphicon-plus"></span> Add Condition
                </button>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="saveDecisionConfig()">Apply</button>
                <button type="button" class="btn btn-danger" onclick="deleteSelectedNode()"><span class="glyphicon glyphicon-trash"></span> Delete</button>
                <button type="button" class="btn btn-secondary" onclick="closeDecisionConfig()">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Toast Container -->
    <div class="wfd-toast-container" id="toastContainer"></div>

    <script type="text/javascript">
    (function () {
        'use strict';

        // ============ STATE ============
        var nodes = [];
        var connections = [];
        var nextNodeId = 1;
        var nextConnId = 1;
        var currentWorkflowId = 0;

        // Interaction state
        var draggingNode = null;
        var dragOffsetX = 0, dragOffsetY = 0;
        var connectingFrom = null;
        var tempLine = null;
        var selectedNodeId = null;
        var selectedConnId = null;
        var cachedUsers = [];
        var cachedFields = [];
        var fieldInsertTarget = null;

        // Load active users for assignee dropdown
        (function loadAssigneeUsers() {
            $.ajax({
                type: 'POST', url: 'WorkflowDesigner.aspx/GetActiveUsers',
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    cachedUsers = res.d || [];
                    var sel = document.getElementById('propAssignee');
                    sel.innerHTML = '<option value="">-- Select User --</option>';
                    var emailUsers = document.getElementById('emailToUsers');
                    emailUsers.innerHTML = '';
                    cachedUsers.forEach(function (u) {
                        var opt = document.createElement('option');
                        opt.value = u.UserID;
                        opt.textContent = u.FullName;
                        sel.appendChild(opt);
                        var opt2 = opt.cloneNode(true);
                        emailUsers.appendChild(opt2);
                    });
                }
            });
        })();

        // Load roles for email config
        (function loadRoles() {
            $.ajax({
                type: 'POST', url: 'WorkflowDesigner.aspx/GetRoles',
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    var sel = document.getElementById('emailToRole');
                    sel.innerHTML = '<option value="">-- None --</option>';
                    (res.d || []).forEach(function (r) {
                        var opt = document.createElement('option');
                        opt.value = r.RoleID;
                        opt.textContent = r.RoleName;
                        sel.appendChild(opt);
                    });
                }
            });
        })();

        // Linked table change handler
        window.onLinkedTableChange = function () {
            var table = document.getElementById('ddlLinkedTable').value;
            cachedFields = [];
            if (!table) return;
            $.ajax({
                type: 'POST', url: 'WorkflowDesigner.aspx/GetTableFields',
                data: JSON.stringify({ tableName: table }),
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    cachedFields = res.d || [];
                    updateFieldPickers();
                }
            });
        };

        function updateFieldPickers() {
            var pickers = ['emailFieldPicker'];
            pickers.forEach(function (pickerId) {
                var sel = document.getElementById(pickerId);
                if (!sel) return;
                sel.innerHTML = '<option value="">-- Select Field --</option>';
                cachedFields.forEach(function (f) {
                    var opt = document.createElement('option');
                    opt.value = f.ColumnName;
                    opt.textContent = f.ColumnName + ' (' + f.DataType + ')';
                    sel.appendChild(opt);
                });
            });
            // Also update decision rule field selectors
            var ruleFields = document.querySelectorAll('.rule-field-select');
            ruleFields.forEach(function (sel) {
                var curVal = sel.value;
                sel.innerHTML = '<option value="">-- Field --</option>';
                cachedFields.forEach(function (f) {
                    var opt = document.createElement('option');
                    opt.value = f.ColumnName;
                    opt.textContent = f.ColumnName;
                    sel.appendChild(opt);
                });
                sel.value = curVal;
            });
        }

        var canvas = document.getElementById('wfdCanvas');
        var svg = document.getElementById('wfdSvg');
        var wrapper = document.getElementById('canvasWrapper');

        // ============ NODE TYPES ============
        var nodeTypes = {
            'start':          { label: 'Start',          icon: 'glyphicon-play',     color: '#4CAF50', shape: 'pill' },
            'end':            { label: 'End',            icon: 'glyphicon-stop',     color: '#f44336', shape: 'pill' },
            'user-task':      { label: 'User Task',      icon: 'glyphicon-user',     color: '#2196F3', shape: 'rect' },
            'approval':       { label: 'Approval Task',  icon: 'glyphicon-check',    color: '#00BCD4', shape: 'rect' },
            'decision':       { label: 'Decision',       icon: 'glyphicon-random',   color: '#FF9800', shape: 'diamond' },
            'decision-table': { label: 'Decision Table', icon: 'glyphicon-th',       color: '#9C27B0', shape: 'rect' },
            'web-service':    { label: 'Web Service',    icon: 'glyphicon-cloud',    color: '#3F51B5', shape: 'rect' },
            'email':          { label: 'Email Task',     icon: 'glyphicon-envelope', color: '#E91E63', shape: 'rect' },
            'delay-timer':    { label: 'Delay Timer',    icon: 'glyphicon-time',     color: '#FFC107', shape: 'rect' },
            'db-task':        { label: 'DB Task',        icon: 'glyphicon-hdd',      color: '#795548', shape: 'rect' },
            'call-workflow':  { label: 'Call Workflow',   icon: 'glyphicon-retweet',  color: '#607D8B', shape: 'rect' },
            'compute':        { label: 'Compute Task',   icon: 'glyphicon-cog',      color: '#009688', shape: 'rect' },
            'excel-report':   { label: 'Excel Report',   icon: 'glyphicon-file',     color: '#8BC34A', shape: 'rect' }
        };

        // ============ PALETTE DRAG ============
        var paletteItems = document.querySelectorAll('.wfd-palette-item');
        for (var i = 0; i < paletteItems.length; i++) {
            paletteItems[i].addEventListener('dragstart', function (e) {
                e.dataTransfer.setData('nodeType', this.getAttribute('data-type'));
                e.dataTransfer.effectAllowed = 'copy';
            });
        }

        canvas.addEventListener('dragover', function (e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        });

        canvas.addEventListener('drop', function (e) {
            e.preventDefault();
            var nodeType = e.dataTransfer.getData('nodeType');
            if (!nodeType || !nodeTypes[nodeType]) return;

            var rect = canvas.getBoundingClientRect();
            var x = e.clientX - rect.left + wrapper.scrollLeft;
            var y = e.clientY - rect.top + wrapper.scrollTop;

            // Snap to grid (20px)
            x = Math.round(x / 20) * 20;
            y = Math.round(y / 20) * 20;

            createNode(nodeType, x, y);
        });

        // ============ CREATE NODE ============
        function createNode(type, x, y, id, label, description) {
            var nt = nodeTypes[type];
            if (!nt) return null;

            var nodeId = id || nextNodeId++;
            if (!id && nodeId >= nextNodeId) nextNodeId = nodeId + 1;
            if (id && id >= nextNodeId) nextNodeId = id + 1;

            var nodeLabel = label || nt.label;
            var nodeDesc = description || '';

            var node = {
                id: nodeId,
                type: type,
                x: x,
                y: y,
                label: nodeLabel,
                description: nodeDesc
            };
            nodes.push(node);

            // Create DOM element
            var el = document.createElement('div');
            el.className = 'wfd-node wfd-shape-' + nt.shape;
            el.setAttribute('data-id', nodeId);
            el.style.left = x + 'px';
            el.style.top = y + 'px';
            el.style.borderColor = nt.color;

            var headerColor = nt.color;
            el.innerHTML =
                '<div class="wfd-node-header" style="background:' + headerColor + ';">' +
                    '<span class="glyphicon ' + nt.icon + '"></span>' +
                    '<span class="wfd-node-type">' + escapeHtml(nt.label) + '</span>' +
                    '<span class="glyphicon glyphicon-option-vertical wfd-node-menu" onclick="event.stopPropagation();window._wfd.openNodeProps(' + nodeId + ')"></span>' +
                '</div>' +
                '<div class="wfd-node-body">' +
                    '<span class="wfd-node-label">' + escapeHtml(nodeLabel) + '</span>' +
                '</div>' +
                '<div class="wfd-port wfd-port-in" data-node="' + nodeId + '" data-port="in" title="Input">' +
                    '<span class="glyphicon glyphicon-ok"></span>' +
                '</div>' +
                '<div class="wfd-port wfd-port-out" data-node="' + nodeId + '" data-port="out" title="Output">' +
                    '<span class="glyphicon glyphicon-ok"></span>' +
                '</div>';

            // For decision nodes, add a second output port
            if (type === 'decision') {
                el.innerHTML +=
                    '<div class="wfd-port wfd-port-out-no" data-node="' + nodeId + '" data-port="out-no" title="No / Reject">' +
                        '<span class="glyphicon glyphicon-remove"></span>' +
                    '</div>';
            }

            canvas.appendChild(el);

            // Node drag (move)
            setupNodeDrag(el, node);

            // Port click for connections
            var ports = el.querySelectorAll('.wfd-port');
            for (var p = 0; p < ports.length; p++) {
                ports[p].addEventListener('mousedown', function (e) {
                    e.stopPropagation();
                    var portType = this.getAttribute('data-port');
                    var portNodeId = parseInt(this.getAttribute('data-node'));

                    if (portType === 'in') {
                        // Completing a connection
                        if (connectingFrom) {
                            createConnection(connectingFrom.nodeId, connectingFrom.port, portNodeId, 'in');
                            cancelConnecting();
                        }
                    } else {
                        // Starting a connection
                        startConnecting(portNodeId, portType, e);
                    }
                });
            }

            showToast('Added: ' + nodeLabel, 'success');
            return node;
        }

        // ============ NODE DRAG (MOVE) ============
        function setupNodeDrag(el, node) {
            var header = el.querySelector('.wfd-node-header');
            header.addEventListener('mousedown', function (e) {
                if (e.target.classList.contains('wfd-node-menu')) return;
                e.preventDefault();
                e.stopPropagation();

                draggingNode = node;
                var rect = el.getBoundingClientRect();
                dragOffsetX = e.clientX - rect.left;
                dragOffsetY = e.clientY - rect.top;
                el.classList.add('wfd-node-dragging');
                selectNode(node.id);
            });
        }

        document.addEventListener('mousemove', function (e) {
            // Move node
            if (draggingNode) {
                var canvasRect = canvas.getBoundingClientRect();
                var x = e.clientX - canvasRect.left + wrapper.scrollLeft - dragOffsetX;
                var y = e.clientY - canvasRect.top + wrapper.scrollTop - dragOffsetY;

                x = Math.max(0, Math.round(x / 20) * 20);
                y = Math.max(0, Math.round(y / 20) * 20);

                draggingNode.x = x;
                draggingNode.y = y;

                var el = canvas.querySelector('[data-id="' + draggingNode.id + '"]');
                if (el) {
                    el.style.left = x + 'px';
                    el.style.top = y + 'px';
                }
                updateAllConnections();
            }

            // Temp connection line
            if (connectingFrom && tempLine) {
                var canvasRect = canvas.getBoundingClientRect();
                var mx = e.clientX - canvasRect.left + wrapper.scrollLeft;
                var my = e.clientY - canvasRect.top + wrapper.scrollTop;
                var sp = getPortPosition(connectingFrom.nodeId, connectingFrom.port);
                tempLine.setAttribute('d', bezierPath(sp.x, sp.y, mx, my));
            }
        });

        document.addEventListener('mouseup', function (e) {
            if (draggingNode) {
                var el = canvas.querySelector('[data-id="' + draggingNode.id + '"]');
                if (el) el.classList.remove('wfd-node-dragging');
                draggingNode = null;
            }
        });

        // Cancel connection on Escape or canvas click
        canvas.addEventListener('mousedown', function (e) {
            if (e.target === canvas || e.target === svg) {
                cancelConnecting();
                deselectAll();
            }
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                cancelConnecting();
                closeNodeProps();
            }
            if (e.key === 'Delete' && selectedNodeId) {
                deleteNode(selectedNodeId);
            }
            if (e.key === 'Delete' && selectedConnId) {
                deleteConnection(selectedConnId);
            }
        });

        // ============ CONNECTIONS ============
        function startConnecting(nodeId, port, e) {
            connectingFrom = { nodeId: nodeId, port: port };
            tempLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            tempLine.setAttribute('class', 'wfd-conn-temp');
            tempLine.setAttribute('marker-end', 'url(#arrowhead)');
            svg.appendChild(tempLine);
        }

        function cancelConnecting() {
            connectingFrom = null;
            if (tempLine) {
                tempLine.remove();
                tempLine = null;
            }
        }

        function createConnection(srcNodeId, srcPort, tgtNodeId, tgtPort, id, label) {
            // Prevent self-connections and duplicates
            if (srcNodeId === tgtNodeId) return;
            for (var i = 0; i < connections.length; i++) {
                if (connections[i].srcNodeId === srcNodeId && connections[i].srcPort === srcPort &&
                    connections[i].tgtNodeId === tgtNodeId) return;
            }

            var connId = id || nextConnId++;
            if (id && id >= nextConnId) nextConnId = id + 1;

            var conn = {
                id: connId,
                srcNodeId: srcNodeId,
                srcPort: srcPort,
                tgtNodeId: tgtNodeId,
                tgtPort: tgtPort,
                label: label || 'Connection Task'
            };
            connections.push(conn);
            renderConnection(conn);
            showToast('Connection created', 'info');
        }

        function renderConnection(conn) {
            var sp = getPortPosition(conn.srcNodeId, conn.srcPort);
            var tp = getPortPosition(conn.tgtNodeId, conn.tgtPort);
            if (!sp || !tp) return;

            // Path
            var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            path.setAttribute('d', bezierPath(sp.x, sp.y, tp.x, tp.y));
            path.setAttribute('class', 'wfd-conn-line');
            path.setAttribute('data-conn', conn.id);
            path.setAttribute('marker-end', 'url(#arrowhead)');
            path.addEventListener('click', function (e) {
                e.stopPropagation();
                selectConnection(conn.id);
            });
            svg.appendChild(path);

            // Source dot
            var dotS = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            dotS.setAttribute('cx', sp.x); dotS.setAttribute('cy', sp.y);
            dotS.setAttribute('r', 4); dotS.setAttribute('class', 'wfd-conn-dot');
            dotS.setAttribute('data-conn', conn.id);
            svg.appendChild(dotS);

            // Target dot
            var dotT = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            dotT.setAttribute('cx', tp.x); dotT.setAttribute('cy', tp.y);
            dotT.setAttribute('r', 4); dotT.setAttribute('class', 'wfd-conn-dot');
            dotT.setAttribute('data-conn', conn.id);
            svg.appendChild(dotT);

            // Label
            var mx = (sp.x + tp.x) / 2;
            var my = (sp.y + tp.y) / 2 - 10;
            var txt = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            txt.setAttribute('x', mx); txt.setAttribute('y', my);
            txt.setAttribute('class', 'wfd-conn-label');
            txt.setAttribute('data-conn', conn.id);
            txt.textContent = conn.label;
            txt.addEventListener('click', function (e) {
                e.stopPropagation();
                selectConnection(conn.id);
            });
            // Label background
            var bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            bg.setAttribute('class', 'wfd-conn-label-bg');
            bg.setAttribute('data-conn', conn.id);
            svg.appendChild(bg);
            svg.appendChild(txt);

            // Position label bg after text is rendered
            setTimeout(function () {
                var bbox = txt.getBBox();
                bg.setAttribute('x', bbox.x - 4);
                bg.setAttribute('y', bbox.y - 2);
                bg.setAttribute('width', bbox.width + 8);
                bg.setAttribute('height', bbox.height + 4);
                bg.setAttribute('rx', 3);
            }, 0);
        }

        function updateAllConnections() {
            // Remove all SVG connection elements (keep defs)
            var svgChildren = svg.querySelectorAll('[data-conn]');
            for (var i = 0; i < svgChildren.length; i++) svgChildren[i].remove();
            // Re-render all
            for (var c = 0; c < connections.length; c++) {
                renderConnection(connections[c]);
            }
        }

        function getPortPosition(nodeId, portName) {
            var el = canvas.querySelector('[data-id="' + nodeId + '"]');
            if (!el) return null;
            var port = el.querySelector('[data-port="' + portName + '"]');
            if (!port) {
                // Fallback for 'in' or 'out'
                port = el.querySelector('[data-port="' + (portName === 'in' ? 'in' : 'out') + '"]');
            }
            if (!port) return null;

            var nodeRect = el.getBoundingClientRect();
            var portRect = port.getBoundingClientRect();
            var canvasRect = canvas.getBoundingClientRect();

            return {
                x: portRect.left + portRect.width / 2 - canvasRect.left + wrapper.scrollLeft,
                y: portRect.top + portRect.height / 2 - canvasRect.top + wrapper.scrollTop
            };
        }

        function bezierPath(x1, y1, x2, y2) {
            var dx = Math.abs(x2 - x1) * 0.5;
            if (dx < 50) dx = 50;
            return 'M ' + x1 + ' ' + y1 +
                   ' C ' + (x1 + dx) + ' ' + y1 +
                   ' ' + (x2 - dx) + ' ' + y2 +
                   ' ' + x2 + ' ' + y2;
        }

        // ============ SELECTION ============
        function selectNode(nodeId) {
            deselectAll();
            selectedNodeId = nodeId;
            var el = canvas.querySelector('[data-id="' + nodeId + '"]');
            if (el) el.classList.add('wfd-node-selected');
        }

        function selectConnection(connId) {
            deselectAll();
            selectedConnId = connId;
            var paths = svg.querySelectorAll('path[data-conn="' + connId + '"]');
            for (var i = 0; i < paths.length; i++) paths[i].classList.add('wfd-conn-selected');
        }

        function deselectAll() {
            selectedNodeId = null;
            selectedConnId = null;
            var selNodes = canvas.querySelectorAll('.wfd-node-selected');
            for (var i = 0; i < selNodes.length; i++) selNodes[i].classList.remove('wfd-node-selected');
            var selConns = svg.querySelectorAll('.wfd-conn-selected');
            for (var i = 0; i < selConns.length; i++) selConns[i].classList.remove('wfd-conn-selected');
        }

        // ============ DELETE ============
        function deleteNode(nodeId) {
            // Remove connections to/from this node
            connections = connections.filter(function (c) {
                return c.srcNodeId !== nodeId && c.tgtNodeId !== nodeId;
            });
            nodes = nodes.filter(function (n) { return n.id !== nodeId; });
            var el = canvas.querySelector('[data-id="' + nodeId + '"]');
            if (el) el.remove();
            updateAllConnections();
            selectedNodeId = null;
            showToast('Node deleted', 'warning');
        }

        function deleteConnection(connId) {
            connections = connections.filter(function (c) { return c.id !== connId; });
            updateAllConnections();
            selectedConnId = null;
            showToast('Connection removed', 'warning');
        }

        // ============ NODE PROPERTIES ============
        window._wfd = {
            openNodeProps: function (nodeId) {
                var node = nodes.find(function (n) { return n.id === nodeId; });
                if (!node) return;
                selectNode(nodeId);

                // Route to specialized modal for email and decision nodes
                if (node.type === 'email') {
                    openEmailConfig(nodeId);
                    return;
                }
                if (node.type === 'decision' || node.type === 'decision-table') {
                    openDecisionConfig(nodeId);
                    return;
                }

                document.getElementById('propNodeId').value = nodeId;
                document.getElementById('propLabel').value = node.label;
                document.getElementById('propDescription').value = node.description || '';

                var assigneeGroup = document.getElementById('propAssigneeGroup');
                if (node.type === 'user-task' || node.type === 'approval') {
                    assigneeGroup.style.display = 'block';
                    document.getElementById('propAssignee').value = node.assignee || node.assigneeId || '';
                } else {
                    assigneeGroup.style.display = 'none';
                }

                document.getElementById('nodePropsModal').style.display = 'flex';
            }
        };

        window.closeNodeProps = function () {
            document.getElementById('nodePropsModal').style.display = 'none';
        };

        window.saveNodeProps = function () {
            var nodeId = parseInt(document.getElementById('propNodeId').value);
            var node = nodes.find(function (n) { return n.id === nodeId; });
            if (!node) return;

            node.label = document.getElementById('propLabel').value || node.label;
            node.description = document.getElementById('propDescription').value;

            if (node.type === 'user-task' || node.type === 'approval') {
                var sel = document.getElementById('propAssignee');
                node.assignee = sel.value;
                node.assigneeName = sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : '';
            }

            // Update DOM
            var el = canvas.querySelector('[data-id="' + nodeId + '"]');
            if (el) {
                var lbl = el.querySelector('.wfd-node-label');
                if (lbl) lbl.textContent = node.label;
            }

            closeNodeProps();
            showToast('Properties updated', 'success');
        };

        window.deleteSelectedNode = function () {
            var nodeId = parseInt(document.getElementById('propNodeId').value);
            if (nodeId) deleteNode(nodeId);
            closeNodeProps();
        };

        // ============ SERIALIZE / DESERIALIZE ============
        function serializeState() {
            return JSON.stringify({
                nodes: nodes.map(function (n) {
                    var obj = { id: n.id, type: n.type, x: n.x, y: n.y, label: n.label, description: n.description, assignee: n.assignee, assigneeName: n.assigneeName };
                    if (n.emailConfig) obj.emailConfig = n.emailConfig;
                    if (n.decisionRules) obj.decisionRules = n.decisionRules;
                    return obj;
                }),
                connections: connections.map(function (c) {
                    return { id: c.id, srcNodeId: c.srcNodeId, srcPort: c.srcPort, tgtNodeId: c.tgtNodeId, tgtPort: c.tgtPort, label: c.label };
                }),
                nextNodeId: nextNodeId,
                nextConnId: nextConnId
            });
        }

        function loadState(json) {
            clearCanvasInternal();
            var state = JSON.parse(json);
            nextNodeId = state.nextNodeId || 1;
            nextConnId = state.nextConnId || 1;

            for (var i = 0; i < state.nodes.length; i++) {
                var n = state.nodes[i];
                createNode(n.type, n.x, n.y, n.id, n.label, n.description);
                var nd = nodes.find(function (x) { return x.id === n.id; });
                if (nd) {
                    if (n.assignee) nd.assignee = n.assignee;
                    if (n.assigneeName) nd.assigneeName = n.assigneeName;
                    if (n.emailConfig) nd.emailConfig = n.emailConfig;
                    if (n.decisionRules) nd.decisionRules = n.decisionRules;
                }
            }
            for (var j = 0; j < state.connections.length; j++) {
                var c = state.connections[j];
                createConnection(c.srcNodeId, c.srcPort, c.tgtNodeId, c.tgtPort, c.id, c.label);
            }
        }

        function clearCanvasInternal() {
            nodes = [];
            connections = [];
            nextNodeId = 1;
            nextConnId = 1;
            // Remove all nodes from DOM
            var nodeEls = canvas.querySelectorAll('.wfd-node');
            for (var i = 0; i < nodeEls.length; i++) nodeEls[i].remove();
            // Remove SVG connections
            var svgChildren = svg.querySelectorAll('[data-conn]');
            for (var i = 0; i < svgChildren.length; i++) svgChildren[i].remove();
            if (tempLine) { tempLine.remove(); tempLine = null; }
        }

        // ============ SAVE / LOAD WORKFLOWS ============
        window.saveWorkflow = function () {
            var name = document.getElementById('txtWfName').value.trim();
            if (!name) { showToast('Please enter a workflow name', 'error'); return; }
            if (nodes.length === 0) { showToast('Canvas is empty. Add some tasks first.', 'error'); return; }
            var linkedTable = document.getElementById('ddlLinkedTable').value;
            if (!linkedTable) { showToast('Please select a linked table', 'error'); return; }

            var json = serializeState();
            $.ajax({
                type: 'POST',
                url: 'WorkflowDesigner.aspx/SaveWorkflow',
                data: JSON.stringify({ id: currentWorkflowId, name: name, description: '', workflowJson: json, linkedTable: linkedTable }),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (r) {
                    currentWorkflowId = r.d;
                    loadWorkflowList();
                    showToast('Workflow saved successfully!', 'success');
                },
                error: function () { showToast('Error saving workflow', 'error'); }
            });
        };

        window.publishWorkflow = function () {
            if (!currentWorkflowId) { showToast('Save the workflow first', 'error'); return; }
            $.ajax({
                type: 'POST',
                url: 'WorkflowDesigner.aspx/PublishWorkflow',
                data: JSON.stringify({ id: currentWorkflowId }),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function () {
                    showToast('Workflow published!', 'success');
                    loadWorkflowList();
                },
                error: function () { showToast('Error publishing workflow', 'error'); }
            });
        };

        window.clearCanvas = function () {
            if (nodes.length > 0 && !confirm('Clear all nodes and connections?')) return;
            clearCanvasInternal();
            currentWorkflowId = 0;
            document.getElementById('txtWfName').value = '';
            document.getElementById('ddlWorkflows').value = '0';
            document.getElementById('ddlLinkedTable').value = '';
            cachedFields = [];
            showToast('Canvas cleared', 'info');
        };

        window.deleteWorkflow = function () {
            if (!currentWorkflowId) { showToast('No workflow selected', 'error'); return; }
            if (!confirm('Are you sure you want to delete this workflow definition?')) return;
            $.ajax({
                type: 'POST',
                url: 'WorkflowDesigner.aspx/DeleteWorkflowDefinition',
                data: JSON.stringify({ id: currentWorkflowId }),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function () {
                    showToast('Workflow deleted', 'success');
                    clearCanvasInternal();
                    currentWorkflowId = 0;
                    document.getElementById('txtWfName').value = '';
                    document.getElementById('ddlLinkedTable').value = '';
                    loadWorkflowList();
                },
                error: function () { showToast('Error deleting workflow', 'error'); }
            });
        };

        window.loadSelectedWorkflow = function () {
            var sel = document.getElementById('ddlWorkflows');
            var id = parseInt(sel.value);
            if (!id) {
                clearCanvasInternal();
                currentWorkflowId = 0;
                document.getElementById('txtWfName').value = '';
                return;
            }
            $.ajax({
                type: 'POST',
                url: 'WorkflowDesigner.aspx/LoadWorkflow',
                data: JSON.stringify({ id: id }),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (r) {
                    var wf = r.d;
                    currentWorkflowId = wf.Id;
                    document.getElementById('txtWfName').value = wf.Name;
                    if (wf.LinkedTable) {
                        document.getElementById('ddlLinkedTable').value = wf.LinkedTable;
                        onLinkedTableChange();
                    }
                    loadState(wf.WorkflowJSON);
                    showToast('Workflow loaded: ' + wf.Name, 'success');
                },
                error: function () { showToast('Error loading workflow', 'error'); }
            });
        };

        function loadWorkflowList() {
            $.ajax({
                type: 'POST',
                url: 'WorkflowDesigner.aspx/GetWorkflowList',
                data: '{}',
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (r) {
                    var ddl = document.getElementById('ddlWorkflows');
                    ddl.innerHTML = '<option value="0">-- New Workflow --</option>';
                    var list = r.d;
                    for (var i = 0; i < list.length; i++) {
                        var opt = document.createElement('option');
                        opt.value = list[i].Id;
                        opt.textContent = list[i].Name + (list[i].Status === 'Published' ? ' [Published]' : '');
                        ddl.appendChild(opt);
                    }
                    if (currentWorkflowId) ddl.value = currentWorkflowId;
                }
            });
        }

        // ============ MESSAGING ============
        var currentChatUserId = 0;
        var currentUserId = 0;

        window.toggleMsgPanel = function () {
            var panel = document.getElementById('msgPanel');
            if (panel.style.display === 'none') {
                panel.style.display = 'flex';
                loadContacts();
            } else {
                panel.style.display = 'none';
            }
        };

        function loadContacts() {
            $.ajax({
                type: 'POST',
                url: 'WorkflowDesigner.aspx/GetContacts',
                data: '{}',
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (r) {
                    var list = document.getElementById('contactList');
                    list.innerHTML = '';
                    var contacts = r.d;
                    for (var i = 0; i < contacts.length; i++) {
                        var c = contacts[i];
                        var initials = getInitials(c.FullName);
                        var colors = ['#2196F3', '#4CAF50', '#FF9800', '#E91E63', '#9C27B0', '#00BCD4', '#795548'];
                        var bgColor = colors[i % colors.length];

                        var div = document.createElement('div');
                        div.className = 'wfd-msg-contact';
                        div.setAttribute('data-userid', c.UserID);
                        div.setAttribute('data-name', c.FullName);
                        div.innerHTML =
                            '<div class="wfd-msg-avatar" style="background:' + bgColor + ';">' + escapeHtml(initials) + '</div>' +
                            '<span class="wfd-msg-name">' + escapeHtml(c.FullName) + '</span>' +
                            (c.UnreadCount > 0 ? '<span class="wfd-msg-unread">' + c.UnreadCount + '</span>' : '');
                        div.addEventListener('click', (function (userId, name, bg) {
                            return function () { openChat(userId, name, bg); };
                        })(c.UserID, c.FullName, bgColor));
                        list.appendChild(div);
                    }
                }
            });
        }

        function openChat(userId, name, bgColor) {
            currentChatUserId = userId;
            document.getElementById('msgContacts').style.display = 'none';
            document.getElementById('msgChat').style.display = 'flex';
            document.getElementById('chatUserName').textContent = name;
            document.getElementById('chatAvatar').textContent = getInitials(name);
            document.getElementById('chatAvatar').style.background = bgColor || '#2196F3';
            loadMessages();
        }

        window.showContacts = function () {
            currentChatUserId = 0;
            document.getElementById('msgChat').style.display = 'none';
            document.getElementById('msgContacts').style.display = 'block';
            loadContacts();
        };

        function loadMessages() {
            if (!currentChatUserId) return;
            $.ajax({
                type: 'POST',
                url: 'WorkflowDesigner.aspx/GetMessages',
                data: JSON.stringify({ otherUserId: currentChatUserId }),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (r) {
                    var body = document.getElementById('chatBody');
                    body.innerHTML = '';
                    var msgs = r.d;
                    currentUserId = parseInt(document.getElementById('<%= hfCurrentUserId.ClientID %>').value);

                    for (var i = 0; i < msgs.length; i++) {
                        var m = msgs[i];
                        var isMine = m.SenderID === currentUserId;
                        var bubble = document.createElement('div');
                        bubble.className = 'wfd-msg-bubble ' + (isMine ? 'wfd-msg-mine' : 'wfd-msg-theirs');
                        bubble.innerHTML =
                            '<div class="wfd-msg-time">' + m.SentDate + '</div>' +
                            '<div class="wfd-msg-text">' + escapeHtml(m.Message) + '</div>';
                        body.appendChild(bubble);
                    }
                    body.scrollTop = body.scrollHeight;
                }
            });
        }

        window.sendMsg = function () {
            var input = document.getElementById('msgInput');
            var text = input.value.trim();
            if (!text || !currentChatUserId) return;

            $.ajax({
                type: 'POST',
                url: 'WorkflowDesigner.aspx/SendChatMessage',
                data: JSON.stringify({ receiverId: currentChatUserId, message: text }),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function () {
                    input.value = '';
                    loadMessages();
                },
                error: function () { showToast('Failed to send message', 'error'); }
            });
        };

        window.filterContacts = function () {
            var search = document.getElementById('msgSearch').value.toLowerCase();
            var items = document.querySelectorAll('.wfd-msg-contact');
            for (var i = 0; i < items.length; i++) {
                var name = items[i].getAttribute('data-name').toLowerCase();
                items[i].style.display = name.indexOf(search) > -1 ? 'flex' : 'none';
            }
        };

        // ============ EMAIL CONFIG ============
        function openEmailConfig(nodeId) {
            var node = nodes.find(function (n) { return n.id === nodeId; });
            if (!node) return;
            document.getElementById('emailNodeId').value = nodeId;
            document.getElementById('emailLabel').value = node.label;
            var cfg = node.emailConfig || {};
            document.getElementById('emailToInitiator').checked = !!cfg.toInitiator;
            document.getElementById('emailToApprovers').checked = !!cfg.toApprovers;
            document.getElementById('emailToRole').value = cfg.toRole || '';
            // Set selected users
            var sel = document.getElementById('emailToUsers');
            for (var i = 0; i < sel.options.length; i++) {
                sel.options[i].selected = cfg.toUsers && cfg.toUsers.indexOf(parseInt(sel.options[i].value)) > -1;
            }
            document.getElementById('emailSubject').value = cfg.subject || '';
            document.getElementById('emailBody').value = cfg.body || '';
            document.getElementById('emailFieldPickerGroup').style.display = 'none';
            document.getElementById('emailConfigModal').style.display = 'flex';
        }
        window.closeEmailConfig = function () { document.getElementById('emailConfigModal').style.display = 'none'; };

        window.saveEmailConfig = function () {
            var nodeId = parseInt(document.getElementById('emailNodeId').value);
            var node = nodes.find(function (n) { return n.id === nodeId; });
            if (!node) return;
            node.label = document.getElementById('emailLabel').value || node.label;
            var selUsers = document.getElementById('emailToUsers');
            var selectedUsers = [];
            for (var i = 0; i < selUsers.options.length; i++) {
                if (selUsers.options[i].selected) selectedUsers.push(parseInt(selUsers.options[i].value));
            }
            node.emailConfig = {
                toInitiator: document.getElementById('emailToInitiator').checked,
                toApprovers: document.getElementById('emailToApprovers').checked,
                toRole: document.getElementById('emailToRole').value,
                toUsers: selectedUsers,
                subject: document.getElementById('emailSubject').value,
                body: document.getElementById('emailBody').value
            };
            var el = canvas.querySelector('[data-id="' + nodeId + '"]');
            if (el) { var lbl = el.querySelector('.wfd-node-label'); if (lbl) lbl.textContent = node.label; }
            closeEmailConfig();
            showToast('Email configuration saved', 'success');
        };

        // Field token insertion
        window.insertFieldToken = function (targetId) {
            if (cachedFields.length === 0) {
                showToast('Select a linked table first to use dynamic fields', 'warning');
                return;
            }
            fieldInsertTarget = targetId;
            document.getElementById('emailFieldPickerGroup').style.display = 'block';
        };
        window.confirmFieldInsert = function () {
            var field = document.getElementById('emailFieldPicker').value;
            if (!field || !fieldInsertTarget) return;
            var el = document.getElementById(fieldInsertTarget);
            if (el.tagName === 'TEXTAREA') {
                var start = el.selectionStart, end = el.selectionEnd;
                var text = el.value;
                el.value = text.substring(0, start) + '{{' + field + '}}' + text.substring(end);
                el.focus();
                el.setSelectionRange(start + field.length + 4, start + field.length + 4);
            } else {
                el.value += '{{' + field + '}}';
            }
            cancelFieldInsert();
        };
        window.cancelFieldInsert = function () {
            fieldInsertTarget = null;
            document.getElementById('emailFieldPickerGroup').style.display = 'none';
        };

        // ============ DECISION RULE CONFIG ============
        function openDecisionConfig(nodeId) {
            var node = nodes.find(function (n) { return n.id === nodeId; });
            if (!node) return;
            document.getElementById('decisionNodeId').value = nodeId;
            document.getElementById('decisionLabel').value = node.label;
            document.getElementById('decisionDescription').value = node.description || '';
            var container = document.getElementById('decisionRulesContainer');
            container.innerHTML = '';
            var rules = node.decisionRules || [];
            if (rules.length === 0) {
                addDecisionRule();
            } else {
                rules.forEach(function (r) { addDecisionRule(r); });
            }
            document.getElementById('decisionConfigModal').style.display = 'flex';
        }
        window.closeDecisionConfig = function () { document.getElementById('decisionConfigModal').style.display = 'none'; };

        window.addDecisionRule = function (rule) {
            var container = document.getElementById('decisionRulesContainer');
            var idx = container.children.length;
            var div = document.createElement('div');
            div.className = 'decision-rule-row';
            div.style.cssText = 'display:flex;gap:6px;align-items:center;margin-bottom:6px;flex-wrap:wrap;';

            var fieldOpts = '<option value="">-- Field --</option>';
            cachedFields.forEach(function (f) {
                fieldOpts += '<option value="' + escapeHtml(f.ColumnName) + '"' +
                    (rule && rule.field === f.ColumnName ? ' selected' : '') + '>' + escapeHtml(f.ColumnName) + '</option>';
            });
            var opVal = rule ? rule.operator : '';
            var valVal = rule ? escapeHtml(rule.value) : '';

            div.innerHTML =
                '<select class="form-control no-select2 rule-field-select" style="flex:1;height:32px;min-width:120px;">' + fieldOpts + '</select>' +
                '<select class="form-control no-select2 rule-op-select" style="width:80px;height:32px;">' +
                    '<option value="="' + (opVal === '=' ? ' selected' : '') + '>=</option>' +
                    '<option value="!="' + (opVal === '!=' ? ' selected' : '') + '>!=</option>' +
                    '<option value=">"' + (opVal === '>' ? ' selected' : '') + '>&gt;</option>' +
                    '<option value=">="' + (opVal === '>=' ? ' selected' : '') + '>&gt;=</option>' +
                    '<option value="<"' + (opVal === '<' ? ' selected' : '') + '>&lt;</option>' +
                    '<option value="<="' + (opVal === '<=' ? ' selected' : '') + '>&lt;=</option>' +
                    '<option value="contains"' + (opVal === 'contains' ? ' selected' : '') + '>Contains</option>' +
                '</select>' +
                '<input type="text" class="form-control rule-value-input" placeholder="Value" value="' + valVal + '" style="flex:1;height:32px;min-width:80px;" />' +
                '<button type="button" class="btn btn-danger btn-sm" onclick="this.parentNode.remove()" title="Remove"><span class="glyphicon glyphicon-minus"></span></button>';
            container.appendChild(div);
            // Init Select2 on the new rule selects
            $(div).find('.rule-field-select').select2({ placeholder: '-- Field --', allowClear: true, width: '100%' });
            $(div).find('.rule-op-select').select2({ minimumResultsForSearch: Infinity, width: '80px' });
        };

        window.saveDecisionConfig = function () {
            var nodeId = parseInt(document.getElementById('decisionNodeId').value);
            var node = nodes.find(function (n) { return n.id === nodeId; });
            if (!node) return;
            node.label = document.getElementById('decisionLabel').value || node.label;
            node.description = document.getElementById('decisionDescription').value;
            var rows = document.querySelectorAll('#decisionRulesContainer .decision-rule-row');
            var rules = [];
            for (var i = 0; i < rows.length; i++) {
                var field = rows[i].querySelector('.rule-field-select').value;
                var op = rows[i].querySelector('.rule-op-select').value;
                var val = rows[i].querySelector('.rule-value-input').value;
                if (field) rules.push({ field: field, operator: op, value: val });
            }
            node.decisionRules = rules;
            var el = canvas.querySelector('[data-id="' + nodeId + '"]');
            if (el) { var lbl = el.querySelector('.wfd-node-label'); if (lbl) lbl.textContent = node.label; }
            closeDecisionConfig();
            showToast('Decision rules saved (' + rules.length + ' condition' + (rules.length !== 1 ? 's' : '') + ')', 'success');
        };

        // ============ TOASTS ============
        function showToast(message, type) {
            var container = document.getElementById('toastContainer');
            var toast = document.createElement('div');
            toast.className = 'wfd-toast wfd-toast-' + (type || 'info');
            var icons = { success: 'glyphicon-ok-circle', error: 'glyphicon-exclamation-sign', warning: 'glyphicon-warning-sign', info: 'glyphicon-info-sign' };
            toast.innerHTML = '<span class="glyphicon ' + (icons[type] || icons.info) + '"></span> ' + escapeHtml(message);
            container.appendChild(toast);
            setTimeout(function () { toast.classList.add('wfd-toast-show'); }, 10);
            setTimeout(function () {
                toast.classList.remove('wfd-toast-show');
                setTimeout(function () { toast.remove(); }, 300);
            }, 3500);
        }
        window.showToast = showToast;

        // ============ HELPERS ============
        function escapeHtml(text) {
            var div = document.createElement('div');
            div.appendChild(document.createTextNode(text || ''));
            return div.innerHTML;
        }

        function getInitials(name) {
            if (!name) return '?';
            var parts = name.split(' ');
            if (parts.length >= 2) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
            return name.substring(0, 2).toUpperCase();
        }

        // ============ INIT ============
        loadWorkflowList();

    })();
    </script>
</asp:Content>
