namespace DemandFundManagement.Forms
{
    public partial class MyApprovals
    {
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.GridView gvMyApprovals;
        protected global::System.Web.UI.WebControls.HiddenField hfTaskId;
        protected global::System.Web.UI.WebControls.HiddenField hfInstanceId;
        protected global::System.Web.UI.WebControls.HiddenField hfStepId;
        protected global::System.Web.UI.WebControls.Label lblApprovalTitle;
        protected global::System.Web.UI.WebControls.Label lblWorkflowName;
        protected global::System.Web.UI.WebControls.Label lblDescription;
        protected global::System.Web.UI.WebControls.Label lblLinkedTable;
        protected global::System.Web.UI.WebControls.Label lblRecordId;
        protected global::System.Web.UI.WebControls.Label lblRequestedBy;
        protected global::System.Web.UI.HtmlControls.HtmlGenericControl recordDetails;
        protected global::System.Web.UI.WebControls.Literal litRecordDetails;
        protected global::System.Web.UI.WebControls.TextBox txtComments;
        protected global::System.Web.UI.WebControls.Button btnApprove;
        protected global::System.Web.UI.WebControls.Button btnReject;
    }
}
