using System;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class FundingLineItems : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            DataTable dt = DatabaseHelper.GetFundingLineItems();
            gvData.DataSource = dt;
            gvData.DataBind();
            lblRecordCount.Text = dt.Rows.Count.ToString();
        }

        protected void gvData_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvData.PageIndex = e.NewPageIndex;
            BindGrid();
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (!fuBulkUpload.HasFile)
            {
                ShowMessage("Please select a file to upload.", true);
                return;
            }

            string ext = Path.GetExtension(fuBulkUpload.FileName).ToLower();
            if (ext != ".csv" && ext != ".xls" && ext != ".xlsx")
            {
                ShowMessage("Only CSV and Excel files (.csv, .xls, .xlsx) are supported.", true);
                return;
            }

            try
            {
                DataTable dt = SpendingAllocation.ParseUploadedFile(fuBulkUpload, ext);
                if (dt.Rows.Count == 0)
                {
                    ShowMessage("The uploaded file contains no data rows.", true);
                    return;
                }

                DataTable mapped = MapColumns(dt);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
                bool deleteExisting = rblUploadMode.SelectedValue == "replace";
                DatabaseHelper.BulkInsertFundingLineItems(mapped, currentUser, deleteExisting);

                string modeMsg = deleteExisting ? "All previous data was replaced." : "New records were appended.";
                ShowMessage("Successfully uploaded " + mapped.Rows.Count + " records. " + modeMsg, false);
                BindGrid();
            }
            catch (Exception ex)
            {
                ShowMessage("Upload error: " + ex.Message, true);
            }
        }

        private DataTable MapColumns(DataTable source)
        {
            DataTable mapped = new DataTable();
            string[] cols = { "ProgramTitle", "Title", "AllocationType", "AllocationSubType",
                "LineItemID", "SubCAPEXID", "Vendor", "Amount", "Consumed", "BlockedAmount", "RemainingAmount" };

            foreach (string c in cols)
                mapped.Columns.Add(c);

            var colMap = new System.Collections.Generic.Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < source.Columns.Count; i++)
            {
                string normalized = NormalizeHeader(source.Columns[i].ColumnName.Trim());
                colMap[normalized] = i;
            }

            foreach (DataRow srcRow in source.Rows)
            {
                DataRow newRow = mapped.NewRow();
                newRow["ProgramTitle"] = GetVal(srcRow, colMap, "programtitle");
                newRow["Title"] = GetVal(srcRow, colMap, "title");
                newRow["AllocationType"] = GetVal(srcRow, colMap, "allocationtype");
                newRow["AllocationSubType"] = GetVal(srcRow, colMap, "allocationsubtype");
                newRow["LineItemID"] = GetVal(srcRow, colMap, "lineitemid");
                newRow["SubCAPEXID"] = GetVal(srcRow, colMap, "subcapexid");
                newRow["Vendor"] = GetVal(srcRow, colMap, "vendor");
                newRow["Amount"] = GetVal(srcRow, colMap, "amount");
                newRow["Consumed"] = GetVal(srcRow, colMap, "consumed");
                newRow["BlockedAmount"] = GetVal(srcRow, colMap, "blockedamount");
                newRow["RemainingAmount"] = GetVal(srcRow, colMap, "remainingamount");
                mapped.Rows.Add(newRow);
            }

            return mapped;
        }

        private static string NormalizeHeader(string header)
        {
            return System.Text.RegularExpressions.Regex.Replace(header, @"[\s_\-#]+", "").ToLower();
        }

        private static string GetVal(DataRow row, System.Collections.Generic.Dictionary<string, int> colMap, string key)
        {
            int idx;
            if (colMap.TryGetValue(key, out idx))
                return row[idx] != DBNull.Value ? row[idx].ToString().Trim() : "";
            return "";
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
