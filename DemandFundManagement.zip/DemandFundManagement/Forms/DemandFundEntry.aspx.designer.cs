namespace DemandFundManagement.Forms
{
    public partial class DemandFundEntry
    {
        protected global::System.Web.UI.WebControls.Label lblPageTitle;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hdnDemandID;
        protected global::System.Web.UI.WebControls.TextBox txtInitiativeTitle;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvTitle;
        protected global::System.Web.UI.WebControls.TextBox txtDescription;
        protected global::System.Web.UI.WebControls.DropDownList ddlDemandType;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvDemandType;
        protected global::System.Web.UI.WebControls.CheckBox chkDAMOApproved;
        protected global::System.Web.UI.WebControls.DropDownList ddlInitiativeType;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvInitiativeType;
        protected global::System.Web.UI.WebControls.DropDownList ddlInitiativeSize;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvInitiativeSize;
        protected global::System.Web.UI.WebControls.DropDownList ddlProjectType;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvProjectType;
        protected global::System.Web.UI.WebControls.DropDownList ddlFundingSource;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvFundingSource;
        protected global::System.Web.UI.WebControls.DropDownList ddlFundsApprovedBy;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvFundsApprovedBy;
        protected global::System.Web.UI.WebControls.DropDownList ddlCapexOpex;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvCapexOpex;
        protected global::System.Web.UI.WebControls.DropDownList ddlGLCode;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvGLCode;
        protected global::System.Web.UI.WebControls.DropDownList ddlEngineeringLead;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvEngineeringLead;
        protected global::System.Web.UI.WebControls.TextBox txtPrimaryBusinessOwner;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvPrimaryBusinessOwner;
        protected global::System.Web.UI.WebControls.TextBox txtDeliveryManager;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvDeliveryManager;
        protected global::System.Web.UI.WebControls.DropDownList ddlPlatformOwner;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvPlatformOwner;
        protected global::System.Web.UI.WebControls.DropDownList ddlPortfolioHead;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvPortfolioHead;
        protected global::System.Web.UI.WebControls.DropDownList ddlPhaseDescription;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvPhaseDescription;
        protected global::System.Web.UI.WebControls.DropDownList ddlBusinessVertical;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvBusinessVertical;
        protected global::System.Web.UI.WebControls.DropDownList ddlTechnologyVertical;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvTechnologyVertical;
        protected global::System.Web.UI.WebControls.CheckBox chkDigitalProject;
        protected global::System.Web.UI.WebControls.TextBox txtRemarks;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvRemarks;
        protected global::System.Web.UI.WebControls.FileUpload fuDocument1;
        protected global::System.Web.UI.WebControls.HyperLink lnkExistingDoc1;
        protected global::System.Web.UI.WebControls.FileUpload fuAdditionalDoc;
        protected global::System.Web.UI.WebControls.Literal litExistingDocs;
        protected global::System.Web.UI.WebControls.LinkButton btnSave;
        protected global::System.Web.UI.WebControls.LinkButton btnSaveNew;
        protected global::System.Web.UI.WebControls.HyperLink lnkCancel;
        protected global::System.Web.UI.WebControls.Panel pnlWorkflowTrigger;
        protected global::System.Web.UI.WebControls.HiddenField hdnRecordIDForWF;
    }
}
