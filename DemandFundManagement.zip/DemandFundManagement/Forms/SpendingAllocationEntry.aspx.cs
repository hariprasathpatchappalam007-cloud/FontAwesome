using System;
using System.Data;
using System.Web.UI;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class SpendingAllocationEntry : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string idParam = Request.QueryString["id"];
                if (!string.IsNullOrEmpty(idParam))
                {
                    int id;
                    if (int.TryParse(idParam, out id) && id > 0)
                    {
                        hdnRecordID.Value = id.ToString();
                        hdnRecordIDForWF.Value = id.ToString();
                        lblPageTitle.Text = "Edit Spending Allocation (ID: " + id + ")";
                        LoadRecord(id);
                        pnlWorkflowTrigger.Visible = true;
                    }
                }
            }
        }

        private void LoadRecord(int id)
        {
            DataRow row = DatabaseHelper.GetSpendingAllocationById(id);
            if (row == null) { ShowMessage("Record not found.", true); return; }

            txtDate.Text = row["Date"] != DBNull.Value ? Convert.ToDateTime(row["Date"]).ToString("yyyy-MM-dd") : "";
            txtFundingLineItem.Text = row["FundingLineItem"] != DBNull.Value ? row["FundingLineItem"].ToString() : "";
            txtDescription.Text = row["Description"] != DBNull.Value ? row["Description"].ToString() : "";
            txtAllocationType.Text = row["AllocationType"] != DBNull.Value ? row["AllocationType"].ToString() : "";
            txtYear.Text = row["Year"] != DBNull.Value ? row["Year"].ToString() : "";
            txtPlannedDate.Text = row["PlannedDate"] != DBNull.Value ? Convert.ToDateTime(row["PlannedDate"]).ToString("yyyy-MM-dd") : "";
            txtTeam.Text = row["Team"] != DBNull.Value ? row["Team"].ToString() : "";
            txtPlatform.Text = row["Platform"] != DBNull.Value ? row["Platform"].ToString() : "";
            txtVendor.Text = row["Vendor"] != DBNull.Value ? row["Vendor"].ToString() : "";
            txtDRMCategory.Text = row["DRMCategory"] != DBNull.Value ? row["DRMCategory"].ToString() : "";
            txtDRMProgram.Text = row["DRMProgram"] != DBNull.Value ? row["DRMProgram"].ToString() : "";
            txtMemoDate.Text = row["MemoDate"] != DBNull.Value ? Convert.ToDateTime(row["MemoDate"]).ToString("yyyy-MM-dd") : "";
            txtCAMID.Text = row["CAMID"] != DBNull.Value ? row["CAMID"].ToString() : "";
            txtActualAmount.Text = row["ActualAmount"] != DBNull.Value ? Convert.ToDecimal(row["ActualAmount"]).ToString("0.##") : "";
            txtAllocationAmount.Text = row["AllocationAmount"] != DBNull.Value ? Convert.ToDecimal(row["AllocationAmount"]).ToString("0.##") : "";
            txtLPONumber.Text = row["LPONumber"] != DBNull.Value ? row["LPONumber"].ToString() : "";
            txtAMSRequestNumber.Text = row["AMSRequestNumber"] != DBNull.Value ? row["AMSRequestNumber"].ToString() : "";
            txtRequester.Text = row["Requester"] != DBNull.Value ? row["Requester"].ToString() : "";
            txtRemarks.Text = row["Remarks"] != DBNull.Value ? row["Remarks"].ToString() : "";
            txtRemarks2.Text = row["Remarks2"] != DBNull.Value ? row["Remarks2"].ToString() : "";
        }

        protected void btnSave_Click(object sender, EventArgs e) { SaveRecord(false); }
        protected void btnSaveNew_Click(object sender, EventArgs e) { SaveRecord(true); }

        private void SaveRecord(bool redirectToNew)
        {
            try
            {
                DateTime? date = ParseDate(txtDate.Text);
                DateTime? plannedDate = ParseDate(txtPlannedDate.Text);
                DateTime? memoDate = ParseDate(txtMemoDate.Text);
                decimal? actualAmount = ParseDecimal(txtActualAmount.Text);
                decimal? allocationAmount = ParseDecimal(txtAllocationAmount.Text);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";

                int recordId = 0;
                int.TryParse(hdnRecordID.Value, out recordId);

                if (recordId > 0)
                {
                    DatabaseHelper.UpdateSpendingAllocation(recordId, date, txtFundingLineItem.Text.Trim(),
                        txtDescription.Text.Trim(), txtAllocationType.Text.Trim(), txtYear.Text.Trim(),
                        plannedDate, txtTeam.Text.Trim(), txtPlatform.Text.Trim(), txtVendor.Text.Trim(),
                        txtDRMCategory.Text.Trim(), txtDRMProgram.Text.Trim(), memoDate, txtCAMID.Text.Trim(),
                        actualAmount, allocationAmount, txtLPONumber.Text.Trim(), txtAMSRequestNumber.Text.Trim(),
                        txtRequester.Text.Trim(), txtRemarks.Text.Trim(), txtRemarks2.Text.Trim(), currentUser);
                    ShowMessage("Record updated successfully (ID: " + recordId + ").", false);
                }
                else
                {
                    int newId = DatabaseHelper.InsertSpendingAllocation(date, txtFundingLineItem.Text.Trim(),
                        txtDescription.Text.Trim(), txtAllocationType.Text.Trim(), txtYear.Text.Trim(),
                        plannedDate, txtTeam.Text.Trim(), txtPlatform.Text.Trim(), txtVendor.Text.Trim(),
                        txtDRMCategory.Text.Trim(), txtDRMProgram.Text.Trim(), memoDate, txtCAMID.Text.Trim(),
                        actualAmount, allocationAmount, txtLPONumber.Text.Trim(), txtAMSRequestNumber.Text.Trim(),
                        txtRequester.Text.Trim(), txtRemarks.Text.Trim(), txtRemarks2.Text.Trim(), currentUser);
                    ShowMessage("Record saved successfully (ID: " + newId + ").", false);
                    hdnRecordID.Value = newId.ToString();
                    hdnRecordIDForWF.Value = newId.ToString();
                    pnlWorkflowTrigger.Visible = true;
                }

                if (redirectToNew) Response.Redirect("~/Forms/SpendingAllocationEntry.aspx");
            }
            catch (Exception ex) { ShowMessage("Error: " + ex.Message, true); }
        }

        private DateTime? ParseDate(string val)
        {
            DateTime d;
            return DateTime.TryParse(val, out d) ? (DateTime?)d : null;
        }

        private decimal? ParseDecimal(string val)
        {
            decimal d;
            return decimal.TryParse(val, out d) ? (decimal?)d : null;
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
