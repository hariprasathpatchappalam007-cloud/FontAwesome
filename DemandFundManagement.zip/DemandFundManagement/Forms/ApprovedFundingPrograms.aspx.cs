using System;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class ApprovedFundingPrograms : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            DataTable dt = DatabaseHelper.GetApprovedFundingPrograms();
            gvData.DataSource = dt;
            gvData.DataBind();
            lblRecordCount.Text = dt.Rows.Count.ToString();
        }

        protected void gvData_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvData.PageIndex = e.NewPageIndex;
            BindGrid();
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (!fuBulkUpload.HasFile)
            {
                ShowMessage("Please select a file to upload.", true);
                return;
            }

            string ext = Path.GetExtension(fuBulkUpload.FileName).ToLower();
            if (ext != ".csv" && ext != ".xls" && ext != ".xlsx")
            {
                ShowMessage("Only CSV and Excel files (.csv, .xls, .xlsx) are supported.", true);
                return;
            }

            try
            {
                DataTable dt = SpendingAllocation.ParseUploadedFile(fuBulkUpload, ext);
                if (dt.Rows.Count == 0)
                {
                    ShowMessage("The uploaded file contains no data rows.", true);
                    return;
                }

                DataTable mapped = MapColumns(dt);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
                bool deleteExisting = rblUploadMode.SelectedValue == "replace";
                DatabaseHelper.BulkInsertApprovedFundingPrograms(mapped, currentUser, deleteExisting);

                string modeMsg = deleteExisting ? "All previous data was replaced." : "New records were appended.";
                ShowMessage("Successfully uploaded " + mapped.Rows.Count + " records. " + modeMsg, false);
                BindGrid();
            }
            catch (Exception ex)
            {
                ShowMessage("Upload error: " + ex.Message, true);
            }
        }

        private DataTable MapColumns(DataTable source)
        {
            DataTable mapped = new DataTable();
            string[] cols = { "Title", "Type", "DemandID", "Approver", "PrimaryLead", "GL",
                "CAPEX", "CAPEXType", "Status", "FundAmount", "Consumed", "Available",
                "Planned", "ApprovalForm", "Remarks", "ProgramOwner" };

            foreach (string c in cols)
                mapped.Columns.Add(c);

            var colMap = new System.Collections.Generic.Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < source.Columns.Count; i++)
            {
                string normalized = NormalizeHeader(source.Columns[i].ColumnName.Trim());
                colMap[normalized] = i;
            }

            foreach (DataRow srcRow in source.Rows)
            {
                DataRow newRow = mapped.NewRow();
                newRow["Title"] = GetVal(srcRow, colMap, "title");
                newRow["Type"] = GetVal(srcRow, colMap, "type");
                newRow["DemandID"] = GetVal(srcRow, colMap, "demandid");
                newRow["Approver"] = GetVal(srcRow, colMap, "approver");
                newRow["PrimaryLead"] = GetVal(srcRow, colMap, "primarylead");
                newRow["GL"] = GetVal(srcRow, colMap, "gl");
                newRow["CAPEX"] = GetVal(srcRow, colMap, "capex");
                newRow["CAPEXType"] = GetVal(srcRow, colMap, "capextype");
                newRow["Status"] = GetVal(srcRow, colMap, "status");
                newRow["FundAmount"] = GetVal(srcRow, colMap, "fundamount");
                newRow["Consumed"] = GetVal(srcRow, colMap, "consumed");
                newRow["Available"] = GetVal(srcRow, colMap, "available");
                newRow["Planned"] = GetVal(srcRow, colMap, "planned");
                newRow["ApprovalForm"] = GetVal(srcRow, colMap, "approvalform");
                newRow["Remarks"] = GetVal(srcRow, colMap, "remarks");
                newRow["ProgramOwner"] = GetVal(srcRow, colMap, "programowner");
                mapped.Rows.Add(newRow);
            }

            return mapped;
        }

        private static string NormalizeHeader(string header)
        {
            return System.Text.RegularExpressions.Regex.Replace(header, @"[\s_\-#]+", "").ToLower();
        }

        private static string GetVal(DataRow row, System.Collections.Generic.Dictionary<string, int> colMap, string key)
        {
            int idx;
            if (colMap.TryGetValue(key, out idx))
                return row[idx] != DBNull.Value ? row[idx].ToString().Trim() : "";
            return "";
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
