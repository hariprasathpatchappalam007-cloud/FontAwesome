<%@ Page Title="Demand Fund Entry" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="DemandFundEntry.aspx.cs" Inherits="DemandFundManagement.Forms.DemandFundEntry" %>



<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title">
        <span class="glyphicon glyphicon-edit"></span> <asp:Label ID="lblPageTitle" runat="server" Text="New Demand Fund Entry" />
    </h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <asp:HiddenField ID="hdnDemandID" runat="server" Value="0" />

    <div class="entry-form">
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>Initiative Title <span style="color:red">*</span></label>
                <asp:TextBox ID="txtInitiativeTitle" runat="server" CssClass="form-control" MaxLength="500" />
                <asp:RequiredFieldValidator ID="rfvTitle" runat="server" ControlToValidate="txtInitiativeTitle"
                    ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Initiative Description</label>
                <asp:TextBox ID="txtDescription" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" MaxLength="2000" />
            </div>
            <div class="form-col form-group">
                <label>Demand Type <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlDemandType" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvDemandType" runat="server" ControlToValidate="ddlDemandType"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Initiative Type <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlInitiativeType" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvInitiativeType" runat="server" ControlToValidate="ddlInitiativeType"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>Initiative Size <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlInitiativeSize" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvInitiativeSize" runat="server" ControlToValidate="ddlInitiativeSize"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Project Type <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlProjectType" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvProjectType" runat="server" ControlToValidate="ddlProjectType"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Funding Source <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlFundingSource" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvFundingSource" runat="server" ControlToValidate="ddlFundingSource"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Funds Approved By <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlFundsApprovedBy" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvFundsApprovedBy" runat="server" ControlToValidate="ddlFundsApprovedBy"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>CAPEX / OPEX <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlCapexOpex" runat="server" CssClass="form-control searchable-dropdown">
                    <asp:ListItem Value="" Text="-- Select --" />
                    <asp:ListItem Value="1" Text="CAPEX" />
                    <asp:ListItem Value="2" Text="OPEX" />
                </asp:DropDownList>
                <asp:RequiredFieldValidator ID="rfvCapexOpex" runat="server" ControlToValidate="ddlCapexOpex"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>GL Code <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlGLCode" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvGLCode" runat="server" ControlToValidate="ddlGLCode"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Engineering Lead <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlEngineeringLead" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvEngineeringLead" runat="server" ControlToValidate="ddlEngineeringLead"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Primary Business Owner <span style="color:red">*</span></label>
                <div class="people-picker-wrap">
                    <asp:TextBox ID="txtPrimaryBusinessOwner" runat="server" CssClass="form-control" MaxLength="500"
                        placeholder="Search AD..." autocomplete="off" />
                    <span class="glyphicon glyphicon-search people-picker-icon"></span>
                    <div class="people-picker-results" id="ppResultsOwner"></div>
                </div>
                <asp:RequiredFieldValidator ID="rfvPrimaryBusinessOwner" runat="server" ControlToValidate="txtPrimaryBusinessOwner"
                    ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>Delivery Manager <span style="color:red">*</span></label>
                <div class="people-picker-wrap">
                    <asp:TextBox ID="txtDeliveryManager" runat="server" CssClass="form-control" MaxLength="200"
                        placeholder="Search AD..." autocomplete="off" />
                    <span class="glyphicon glyphicon-search people-picker-icon"></span>
                    <div class="people-picker-results" id="ppResultsManager"></div>
                </div>
                <asp:RequiredFieldValidator ID="rfvDeliveryManager" runat="server" ControlToValidate="txtDeliveryManager"
                    ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Platform Owner <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlPlatformOwner" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvPlatformOwner" runat="server" ControlToValidate="ddlPlatformOwner"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Portfolio Head <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlPortfolioHead" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvPortfolioHead" runat="server" ControlToValidate="ddlPortfolioHead"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Project Phase <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlPhaseDescription" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvPhaseDescription" runat="server" ControlToValidate="ddlPhaseDescription"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>Business Vertical <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlBusinessVertical" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvBusinessVertical" runat="server" ControlToValidate="ddlBusinessVertical"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Technology Vertical <span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlTechnologyVertical" runat="server" CssClass="form-control searchable-dropdown" />
                <asp:RequiredFieldValidator ID="rfvTechnologyVertical" runat="server" ControlToValidate="ddlTechnologyVertical"
                    InitialValue="" ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label class="checkbox-label"><asp:CheckBox ID="chkDAMOApproved" runat="server" /><span>DAMO Approved</span></label>
            </div>
            <div class="form-col form-group">
                <label class="checkbox-label"><asp:CheckBox ID="chkDigitalProject" runat="server" /><span>Digital Project</span></label>
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col-2x form-group">
                <label>Remarks <span style="color:red">*</span></label>
                <asp:TextBox ID="txtRemarks" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" />
                <asp:RequiredFieldValidator ID="rfvRemarks" runat="server" ControlToValidate="txtRemarks"
                    ErrorMessage="Required" Display="Dynamic" ForeColor="Red" Font-Size="11px" ValidationGroup="DemandFund" />
            </div>
            <div class="form-col form-group">
                <label>Document 1</label>
                <div class="drop-zone drop-zone-compact" id="dropZone1">
                    <span class="glyphicon glyphicon-cloud-upload drop-zone-icon"></span>
                    <span class="drop-zone-hint">Click or drop file</span>
                    <asp:FileUpload ID="fuDocument1" runat="server" CssClass="drop-zone-input" />
                    <div class="drop-zone-file" id="fileInfo1" style="display:none;">
                        <span class="glyphicon glyphicon-file"></span>
                        <span class="file-name" id="fileName1"></span>
                        <span class="file-size" id="fileSize1"></span>
                        <button type="button" class="drop-zone-remove" onclick="clearDropZone('dropZone1','fileInfo1');return false;">
                            <span class="glyphicon glyphicon-remove"></span>
                        </button>
                    </div>
                </div>
                <asp:HyperLink ID="lnkExistingDoc1" runat="server" Visible="false" CssClass="doc-link" Target="_blank" />
            </div>
            <div class="form-col form-group">
                <label>Additional Documents</label>
                <div class="drop-zone drop-zone-compact" id="dropZone2">
                    <span class="glyphicon glyphicon-cloud-upload drop-zone-icon"></span>
                    <span class="drop-zone-hint">Click or drop files</span>
                    <asp:FileUpload ID="fuAdditionalDoc" runat="server" CssClass="drop-zone-input" AllowMultiple="true" />
                    <div class="drop-zone-files" id="fileList2" style="display:none;"></div>
                </div>
                <asp:Literal ID="litExistingDocs" runat="server" />
            </div>
        </div>
    </div>

    <div class="btn-group">
        <asp:LinkButton ID="btnSave" runat="server" CssClass="btn btn-primary" OnClick="btnSave_Click" ValidationGroup="DemandFund">
            <span class="glyphicon glyphicon-floppy-disk"></span> Save
        </asp:LinkButton>
        <asp:LinkButton ID="btnSaveNew" runat="server" CssClass="btn btn-success" OnClick="btnSaveNew_Click" ValidationGroup="DemandFund">
            <span class="glyphicon glyphicon-floppy-saved"></span> Save &amp; New
        </asp:LinkButton>
        <asp:HyperLink ID="lnkCancel" runat="server" CssClass="btn btn-secondary" NavigateUrl="~/Forms/DemandFundList.aspx"><span class="glyphicon glyphicon-remove"></span> Cancel</asp:HyperLink>
    </div>

    <!-- Workflow Trigger Section (visible in edit mode) -->
    <asp:Panel ID="pnlWorkflowTrigger" runat="server" Visible="false" CssClass="wf-trigger-panel" style="margin-top:15px;">
        <h4 style="margin-bottom:10px;"><span class="glyphicon glyphicon-random" style="color:var(--primary);"></span> Start Workflow</h4>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <select id="ddlWorkflowTrigger" class="form-control no-select2" style="width:280px;display:inline-block;height:34px;">
                <option value="">-- Select Workflow --</option>
            </select>
            <button type="button" class="btn btn-primary btn-sm" onclick="triggerWorkflow()">
                <span class="glyphicon glyphicon-play"></span> Start Workflow
            </button>
        </div>
        <div id="wfTriggerResult" style="margin-top:8px;display:none;" class="alert"></div>

        <!-- Workflow History -->
        <div id="wfHistorySection" style="margin-top:15px;display:none;">
            <h5 style="font-weight:700;"><span class="glyphicon glyphicon-time"></span> Workflow History</h5>
            <table class="table table-bordered table-striped" style="font-size:13px;">
                <thead><tr><th>Instance</th><th>Workflow</th><th>Status</th><th>Started By</th><th>Started</th><th>Completed</th><th>Actions</th></tr></thead>
                <tbody id="wfHistoryBody"></tbody>
            </table>
        </div>

        <!-- Workflow Steps Modal -->
        <div class="modal-overlay" id="wfStepsModal" style="display:none;">
            <div class="modal-dialog" style="max-width:700px;">
                <div class="modal-header">
                    <span class="glyphicon glyphicon-list-alt"></span> Workflow Steps
                    <button type="button" class="modal-close" onclick="document.getElementById('wfStepsModal').style.display='none'">&times;</button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered table-striped" style="font-size:13px;">
                        <thead><tr><th>Step</th><th>Type</th><th>Status</th><th>Assigned To</th><th>Action By</th><th>Date</th><th>Comments</th></tr></thead>
                        <tbody id="wfStepsBody"></tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('wfStepsModal').style.display='none'">Close</button>
                </div>
            </div>
        </div>
    </asp:Panel>
    <asp:HiddenField ID="hdnRecordIDForWF" runat="server" />

    <script type="text/javascript">
        // People Picker for AD Users
        function initPeoplePicker(inputId, resultsId) {
            var input = document.getElementById(inputId);
            var results = document.getElementById(resultsId);
            if (!input || !results) return;

            var debounceTimer;
            input.addEventListener('input', function () {
                clearTimeout(debounceTimer);
                var query = input.value.trim();
                if (query.length < 2) { results.classList.remove('open'); return; }
                debounceTimer = setTimeout(function () { searchADUsers(query, results, input); }, 300);
            });
            input.addEventListener('blur', function () {
                setTimeout(function () { results.classList.remove('open'); }, 200);
            });
        }

        function searchADUsers(query, resultsDiv, inputEl) {
            resultsDiv.innerHTML = '<div class="people-picker-loading"><span class="glyphicon glyphicon-refresh"></span> Searching AD...</div>';
            resultsDiv.classList.add('open');

            // Simulate AD user lookup - replace with real LDAP/Graph API call in production
            var mockUsers = [
                { name: 'Ahmed Al Mansoori', dept: 'IT', email: 'ahmed.m@dib.ae' },
                { name: 'Sara Al Hashimi', dept: 'Business', email: 'sara.h@dib.ae' },
                { name: 'Mohammed Rashid', dept: 'Digital', email: 'mohammed.r@dib.ae' },
                { name: 'Fatima Al Zahra', dept: 'Finance', email: 'fatima.z@dib.ae' },
                { name: 'Khalid Omar', dept: 'Risk', email: 'khalid.o@dib.ae' },
                { name: 'Noor Al Sayed', dept: 'Compliance', email: 'noor.s@dib.ae' },
                { name: 'Ali Hassan', dept: 'Engineering', email: 'ali.h@dib.ae' },
                { name: 'Mariam Abdullah', dept: 'Operations', email: 'mariam.a@dib.ae' },
                { name: 'Omar Al Farsi', dept: 'Corporate', email: 'omar.f@dib.ae' },
                { name: 'Layla Ibrahim', dept: 'Payments', email: 'layla.i@dib.ae' }
            ];

            var filtered = mockUsers.filter(function (u) {
                return u.name.toLowerCase().indexOf(query.toLowerCase()) > -1 ||
                       u.email.toLowerCase().indexOf(query.toLowerCase()) > -1;
            });

            setTimeout(function () {
                if (filtered.length === 0) {
                    resultsDiv.innerHTML = '<div class="people-picker-loading">No users found</div>';
                    return;
                }
                var html = '';
                filtered.forEach(function (u) {
                    var initials = u.name.split(' ').map(function (w) { return w[0]; }).join('').substring(0, 2);
                    html += '<div class="people-picker-item" data-name="' + u.name + '" data-email="' + u.email + '">' +
                        '<span class="pp-avatar">' + initials + '</span>' +
                        '<span class="pp-name">' + u.name + '</span>' +
                        '<span class="pp-dept">' + u.dept + '</span>' +
                        '</div>';
                });
                resultsDiv.innerHTML = html;

                var items = resultsDiv.querySelectorAll('.people-picker-item');
                items.forEach(function (item) {
                    item.addEventListener('mousedown', function (e) {
                        e.preventDefault();
                        inputEl.value = item.getAttribute('data-name');
                        resultsDiv.classList.remove('open');
                    });
                });
            }, 300);
        }

        // Init people pickers
        $(document).ready(function () {
            var ownerInput = document.getElementById('<%= txtPrimaryBusinessOwner.ClientID %>');
            var managerInput = document.getElementById('<%= txtDeliveryManager.ClientID %>');
            if (ownerInput) initPeoplePicker(ownerInput.id, 'ppResultsOwner');
            if (managerInput) initPeoplePicker(managerInput.id, 'ppResultsManager');
        });

        // Drop zone handlers
        function initDropZone(zoneId, fileInfoId, fileNameId, fileSizeId) {
            var zone = document.getElementById(zoneId);
            if (!zone) return;
            var input = zone.querySelector('input[type="file"]');

            zone.addEventListener('click', function (e) {
                if (e.target.closest && (e.target.closest('.drop-zone-remove') || e.target.closest('.drop-zone-file'))) return;
                if (e.target.type !== 'file') input.click();
            });
            zone.addEventListener('dragover', function (e) {
                e.preventDefault();
                zone.classList.add('drop-zone-active');
            });
            zone.addEventListener('dragleave', function (e) {
                e.preventDefault();
                zone.classList.remove('drop-zone-active');
            });
            zone.addEventListener('drop', function (e) {
                e.preventDefault();
                zone.classList.remove('drop-zone-active');
                if (e.dataTransfer.files.length > 0) {
                    var assigned = false;
                    try {
                        var dt = new DataTransfer();
                        dt.items.add(e.dataTransfer.files[0]);
                        input.files = dt.files;
                        assigned = input.files.length > 0;
                    } catch (ex) { assigned = false; }
                    if (assigned) {
                        showFileInfo(fileInfoId, fileNameId, fileSizeId, e.dataTransfer.files[0]);
                    } else {
                        alert('Drag-and-drop is not supported in this browser. Please click the upload zone to browse for files.');
                    }
                }
            });
            input.addEventListener('change', function () {
                if (input.files.length > 0) {
                    showFileInfo(fileInfoId, fileNameId, fileSizeId, input.files[0]);
                }
            });
        }

        function showFileInfo(fileInfoId, fileNameId, fileSizeId, file) {
            var info = document.getElementById(fileInfoId);
            var name = document.getElementById(fileNameId);
            var size = document.getElementById(fileSizeId);
            if (!info) return;
            name.textContent = file.name;
            var kb = (file.size / 1024).toFixed(1);
            size.textContent = kb > 1024 ? (kb / 1024).toFixed(1) + ' MB' : kb + ' KB';
            info.style.display = 'flex';
        }

        function clearDropZone(zoneId, fileInfoId) {
            var zone = document.getElementById(zoneId);
            var info = document.getElementById(fileInfoId);
            if (zone) { var input = zone.querySelector('input[type="file"]'); if (input) input.value = ''; }
            if (info) info.style.display = 'none';
        }

        // Multi-file drop zone for Additional Documents
        function initDropZoneMulti(zoneId, fileListId) {
            var zone = document.getElementById(zoneId);
            if (!zone) return;
            var input = zone.querySelector('input[type="file"]');
            zone.addEventListener('click', function (e) {
                if (e.target.closest && (e.target.closest('.drop-zone-remove') || e.target.closest('.drop-zone-files') || e.target.closest('.drop-zone-file'))) return;
                if (e.target.type !== 'file') input.click();
            });
            zone.addEventListener('dragover', function (e) { e.preventDefault(); zone.classList.add('drop-zone-active'); });
            zone.addEventListener('dragleave', function (e) { e.preventDefault(); zone.classList.remove('drop-zone-active'); });
            zone.addEventListener('drop', function (e) {
                e.preventDefault(); zone.classList.remove('drop-zone-active');
                if (e.dataTransfer.files.length > 0) {
                    var assigned = false;
                    try { var dt = new DataTransfer(); for (var i = 0; i < e.dataTransfer.files.length; i++) dt.items.add(e.dataTransfer.files[i]); input.files = dt.files; assigned = input.files.length > 0; } catch (ex) { assigned = false; }
                    if (assigned) {
                        showMultiFileInfo(fileListId, e.dataTransfer.files, zoneId);
                    } else {
                        alert('Drag-and-drop is not supported in this browser. Please click the upload zone to browse for files.');
                    }
                }
            });
            input.addEventListener('change', function () {
                if (input.files.length > 0) showMultiFileInfo(fileListId, input.files, zoneId);
            });
        }

        function showMultiFileInfo(listId, files, zoneId) {
            var list = document.getElementById(listId);
            if (!list) return;
            var html = '';
            for (var i = 0; i < files.length; i++) {
                var f = files[i];
                var kb = (f.size / 1024).toFixed(1);
                var sizeStr = kb > 1024 ? (kb / 1024).toFixed(1) + ' MB' : kb + ' KB';
                html += '<div class="drop-zone-file" style="display:flex"><span class="glyphicon glyphicon-file"></span> <span class="file-name">' + f.name + '</span><span class="file-size">' + sizeStr + '</span></div>';
            }
            html += '<button type="button" class="drop-zone-remove" style="margin-top:4px" onclick="clearDropZoneMulti(\'' + zoneId + '\',\'' + listId + '\');return false;"><span class="glyphicon glyphicon-remove"></span> Clear</button>';
            list.innerHTML = html;
            list.style.display = 'block';
        }

        function clearDropZoneMulti(zoneId, listId) {
            var zone = document.getElementById(zoneId);
            var list = document.getElementById(listId);
            if (zone) { var input = zone.querySelector('input[type="file"]'); if (input) input.value = ''; }
            if (list) { list.innerHTML = ''; list.style.display = 'none'; }
        }

        initDropZone('dropZone1', 'fileInfo1', 'fileName1', 'fileSize1');
        initDropZoneMulti('dropZone2', 'fileList2');

        // Workflow Trigger
        (function loadWorkflows() {
            var recIdEl = document.getElementById('<%= hdnRecordIDForWF.ClientID %>');
            if (!recIdEl || !recIdEl.value || recIdEl.value === '0') return;
            $.ajax({
                type: 'POST', url: '<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/GetPublishedWorkflows") %>',
                data: JSON.stringify({ tableName: 'DemandFund' }),
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    var ddl = document.getElementById('ddlWorkflowTrigger');
                    if (!ddl) return;
                    ddl.innerHTML = '<option value="">-- Select Workflow --</option>';
                    (res.d || []).forEach(function (w) {
                        var opt = document.createElement('option');
                        opt.value = w.Id; opt.textContent = w.Name;
                        ddl.appendChild(opt);
                    });
                }
            });
        })();

        window.triggerWorkflow = function () {
            var ddl = document.getElementById('ddlWorkflowTrigger');
            var defId = ddl ? parseInt(ddl.value) : 0;
            if (!defId) { alert('Please select a workflow'); return; }
            var recIdEl = document.getElementById('<%= hdnRecordIDForWF.ClientID %>');
            var recId = recIdEl ? parseInt(recIdEl.value) : 0;
            if (!recId) { alert('Save the record first'); return; }
            $.ajax({
                type: 'POST', url: '<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/StartWorkflow") %>',
                data: JSON.stringify({ definitionId: defId, recordId: recId }),
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    var r = res.d;
                    var div = document.getElementById('wfTriggerResult');
                    div.style.display = 'block';
                    if (r.Success) {
                        div.className = 'alert alert-success';
                        div.innerHTML = '<span class="glyphicon glyphicon-ok"></span> ' + r.Message + ' (Instance #' + r.InstanceId + ')';
                        loadWorkflowHistory();
                    } else {
                        div.className = 'alert alert-danger';
                        div.innerHTML = '<span class="glyphicon glyphicon-exclamation-sign"></span> ' + r.Message;
                    }
                },
                error: function () {
                    var div = document.getElementById('wfTriggerResult');
                    div.style.display = 'block';
                    div.className = 'alert alert-danger';
                    div.innerHTML = 'Error starting workflow';
                }
            });
        };

        // Workflow History
        function loadWorkflowHistory() {
            var recIdEl = document.getElementById('<%= hdnRecordIDForWF.ClientID %>');
            var recId = recIdEl ? parseInt(recIdEl.value) : 0;
            if (!recId) return;
            $.ajax({
                type: 'POST', url: '<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/GetWorkflowHistory") %>',
                data: JSON.stringify({ tableName: 'DemandFund', recordId: recId }),
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    var items = res.d || [];
                    var section = document.getElementById('wfHistorySection');
                    var tbody = document.getElementById('wfHistoryBody');
                    if (items.length === 0) { section.style.display = 'none'; return; }
                    section.style.display = 'block';
                    var html = '';
                    items.forEach(function (w) {
                        var statusBadge = w.Status === 'Running' ? 'label-primary' : w.Status === 'Completed' ? 'label-success' : 'label-danger';
                        html += '<tr><td>#' + w.InstanceID + '</td><td>' + w.WorkflowName + '</td>' +
                            '<td><span class="label ' + statusBadge + '">' + w.Status + '</span></td>' +
                            '<td>' + w.InitiatedBy + '</td><td>' + w.StartedDate + '</td><td>' + (w.CompletedDate || '-') + '</td><td>' +
                            '<button type="button" class="btn btn-info btn-xs" onclick="viewWfSteps(' + w.InstanceID + ')"><span class="glyphicon glyphicon-list-alt"></span> Steps</button> ';
                        if (w.Status === 'Running') {
                            html += '<button type="button" class="btn btn-danger btn-xs" onclick="terminateWf(' + w.InstanceID + ')"><span class="glyphicon glyphicon-stop"></span> Stop</button>';
                        }
                        html += '</td></tr>';
                    });
                    tbody.innerHTML = html;
                }
            });
        }

        window.viewWfSteps = function (instanceId) {
            $.ajax({
                type: 'POST', url: '<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/GetWorkflowInstanceStepsData") %>',
                data: JSON.stringify({ instanceId: instanceId }),
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    var steps = res.d || [];
                    var tbody = document.getElementById('wfStepsBody');
                    var html = '';
                    steps.forEach(function (s) {
                        var statusBadge = s.Status === 'Completed' ? 'label-success' : s.Status === 'Pending' ? 'label-warning' : s.Status === 'Rejected' ? 'label-danger' : 'label-default';
                        html += '<tr><td>' + s.NodeLabel + '</td><td>' + s.NodeType + '</td>' +
                            '<td><span class="label ' + statusBadge + '">' + s.Status + '</span></td>' +
                            '<td>' + s.AssignedTo + '</td><td>' + s.ActionBy + '</td><td>' + s.ActionDate + '</td><td>' + s.Comments + '</td></tr>';
                    });
                    tbody.innerHTML = html || '<tr><td colspan="7" style="text-align:center;">No steps found</td></tr>';
                    document.getElementById('wfStepsModal').style.display = 'flex';
                }
            });
        };

        window.terminateWf = function (instanceId) {
            if (!confirm('Are you sure you want to stop this workflow?')) return;
            $.ajax({
                type: 'POST', url: '<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/TerminateWorkflow") %>',
                data: JSON.stringify({ instanceId: instanceId }),
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    if (res.d.Success) { loadWorkflowHistory(); }
                    else { alert(res.d.Message); }
                }
            });
        };

        // Auto-load history on page load
        $(document).ready(function () { loadWorkflowHistory(); });
    </script>
</asp:Content>
