<%@ Page Title="Spending Allocation" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="SpendingAllocation.aspx.cs" Inherits="DemandFundManagement.Forms.SpendingAllocation" %>



<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title"><span class="glyphicon glyphicon-usd"></span> Spending Allocation</h2>

    <div class="btn-group" style="margin-bottom:15px;">
        <asp:HyperLink ID="lnkNewEntry" runat="server" CssClass="btn btn-primary" NavigateUrl="~/Forms/SpendingAllocationEntry.aspx"><span class="glyphicon glyphicon-plus"></span> New Entry</asp:HyperLink>
    </div>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- Bulk Upload Section -->
    <div class="panel">
        <div class="panel-header">
            <span class="glyphicon glyphicon-cloud-upload"></span> Bulk Upload
            <span class="bulk-upload-note">(Select upload mode below)</span>
        </div>
        <div class="panel-body">
            <div class="bulk-upload-row">
                <div class="bulk-upload-zone" id="bulkDropZone">
                    <span class="glyphicon glyphicon-file bulk-upload-icon"></span>
                    <span class="bulk-upload-hint">Drop Excel/CSV file here or click to browse</span>
                    <asp:FileUpload ID="fuBulkUpload" runat="server" CssClass="drop-zone-input" accept=".csv,.xls,.xlsx" />
                    <div class="bulk-upload-file" id="bulkFileInfo" style="display:none;">
                        <span class="glyphicon glyphicon-file"></span>
                        <span class="file-name" id="bulkFileName"></span>
                        <span class="file-size" id="bulkFileSize"></span>
                    </div>
                </div>
                <asp:LinkButton ID="btnUpload" runat="server" CssClass="btn btn-primary" OnClick="btnUpload_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-upload"></span> Upload
                </asp:LinkButton>
                <asp:HyperLink ID="lnkTemplate" runat="server" CssClass="btn btn-secondary" NavigateUrl="javascript:void(0)">
                    <span class="glyphicon glyphicon-download"></span> Download Template
                </asp:HyperLink>
            </div>
            <div class="bulk-upload-mode" style="margin:10px 0;">
                <asp:RadioButtonList ID="rblUploadMode" runat="server" RepeatDirection="Horizontal" RepeatLayout="Flow" CssClass="upload-mode-radio">
                    <asp:ListItem Value="replace" Selected="True"> Delete existing &amp; replace</asp:ListItem>
                    <asp:ListItem Value="append"> Retain existing &amp; append</asp:ListItem>
                </asp:RadioButtonList>
            </div>
            <div class="bulk-upload-columns">
                <strong>Expected Columns:</strong> Date, Funding Line Item, Description, Allocation Type, Year, Planned Date, Team, Platform, Vendor, DRM Category, DRM Program, Memo Date, CAM ID, Actual Amount, Allocation Amount, LPO #, AMS Request #, Requester, Remarks, Remarks 2
            </div>
        </div>
    </div>

    <!-- Data Grid -->
    <div class="panel">
        <div class="panel-header">
            <span class="glyphicon glyphicon-th-list"></span> Spending Allocation Data
            <span class="record-count"><asp:Label ID="lblRecordCount" runat="server" Text="0" /> records</span>
        </div>
        <div class="panel-body" style="overflow-x:auto;">
            <asp:GridView ID="gvData" runat="server" AutoGenerateColumns="false"
                CssClass="grid-view" EmptyDataText="No data found. Use bulk upload to import data."
                AllowPaging="true" PageSize="25" OnPageIndexChanging="gvData_PageIndexChanging">
                <Columns>
                    <asp:HyperLinkField Text="Edit" DataNavigateUrlFields="ID" DataNavigateUrlFormatString="~/Forms/SpendingAllocationEntry.aspx?id={0}" ItemStyle-Width="50px" ControlStyle-CssClass="btn btn-sm btn-primary" />
                    <asp:BoundField DataField="ID" HeaderText="ID" ItemStyle-Width="50px" />
                    <asp:BoundField DataField="Date" HeaderText="Date" DataFormatString="{0:dd-MMM-yyyy}" />
                    <asp:BoundField DataField="FundingLineItem" HeaderText="Funding Line Item" />
                    <asp:BoundField DataField="Description" HeaderText="Description" />
                    <asp:BoundField DataField="AllocationType" HeaderText="Allocation Type" />
                    <asp:BoundField DataField="Year" HeaderText="Year" />
                    <asp:BoundField DataField="PlannedDate" HeaderText="Planned Date" DataFormatString="{0:dd-MMM-yyyy}" />
                    <asp:BoundField DataField="Team" HeaderText="Team" />
                    <asp:BoundField DataField="Platform" HeaderText="Platform" />
                    <asp:BoundField DataField="Vendor" HeaderText="Vendor" />
                    <asp:BoundField DataField="DRMCategory" HeaderText="DRM Category" />
                    <asp:BoundField DataField="DRMProgram" HeaderText="DRM Program" />
                    <asp:BoundField DataField="MemoDate" HeaderText="Memo Date" DataFormatString="{0:dd-MMM-yyyy}" />
                    <asp:BoundField DataField="CAMID" HeaderText="CAM ID" />
                    <asp:BoundField DataField="ActualAmount" HeaderText="Actual Amount" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="AllocationAmount" HeaderText="Allocation Amount" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="LPONumber" HeaderText="LPO #" />
                    <asp:BoundField DataField="AMSRequestNumber" HeaderText="AMS Request #" />
                    <asp:BoundField DataField="Requester" HeaderText="Requester" />
                    <asp:BoundField DataField="Remarks" HeaderText="Remarks" />
                    <asp:BoundField DataField="Remarks2" HeaderText="Remarks 2" />
                </Columns>
                <PagerStyle CssClass="grid-pager" />
            </asp:GridView>
        </div>
    </div>

    <script type="text/javascript">
        (function () {
            var zone = document.getElementById('bulkDropZone');
            if (!zone) return;
            var input = zone.querySelector('input[type="file"]');
            zone.addEventListener('click', function (e) {
                if (e.target.type !== 'file') input.click();
            });
            zone.addEventListener('dragover', function (e) { e.preventDefault(); zone.classList.add('drop-zone-active'); });
            zone.addEventListener('dragleave', function (e) { e.preventDefault(); zone.classList.remove('drop-zone-active'); });
            zone.addEventListener('drop', function (e) {
                e.preventDefault(); zone.classList.remove('drop-zone-active');
                if (e.dataTransfer.files.length > 0) {
                    try { var dt = new DataTransfer(); dt.items.add(e.dataTransfer.files[0]); input.files = dt.files; } catch (ex) { }
                    showBulkFile(e.dataTransfer.files[0]);
                }
            });
            input.addEventListener('change', function () { if (input.files.length > 0) showBulkFile(input.files[0]); });

            function showBulkFile(file) {
                var info = document.getElementById('bulkFileInfo');
                document.getElementById('bulkFileName').textContent = file.name;
                var kb = (file.size / 1024).toFixed(1);
                document.getElementById('bulkFileSize').textContent = kb > 1024 ? (kb / 1024).toFixed(1) + ' MB' : kb + ' KB';
                info.style.display = 'flex';
            }
        })();
    </script>
</asp:Content>
