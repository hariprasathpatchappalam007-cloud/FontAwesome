using System;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class SpendingAllocation : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            DataTable dt = DatabaseHelper.GetSpendingAllocations();
            gvData.DataSource = dt;
            gvData.DataBind();
            lblRecordCount.Text = dt.Rows.Count.ToString();
        }

        protected void gvData_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvData.PageIndex = e.NewPageIndex;
            BindGrid();
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (!fuBulkUpload.HasFile)
            {
                ShowMessage("Please select a file to upload.", true);
                return;
            }

            string ext = Path.GetExtension(fuBulkUpload.FileName).ToLower();
            if (ext != ".csv" && ext != ".xls" && ext != ".xlsx")
            {
                ShowMessage("Only CSV and Excel files (.csv, .xls, .xlsx) are supported.", true);
                return;
            }

            try
            {
                DataTable dt = ParseUploadedFile(fuBulkUpload, ext);
                if (dt.Rows.Count == 0)
                {
                    ShowMessage("The uploaded file contains no data rows.", true);
                    return;
                }

                // Map columns
                DataTable mapped = MapSpendingAllocationColumns(dt);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
                bool deleteExisting = rblUploadMode.SelectedValue == "replace";
                DatabaseHelper.BulkInsertSpendingAllocations(mapped, currentUser, deleteExisting);

                string modeMsg = deleteExisting ? "All previous data was replaced." : "New records were appended.";
                ShowMessage("Successfully uploaded " + mapped.Rows.Count + " records. " + modeMsg, false);
                BindGrid();
            }
            catch (Exception ex)
            {
                ShowMessage("Upload error: " + ex.Message, true);
            }
        }

        private DataTable MapSpendingAllocationColumns(DataTable source)
        {
            DataTable mapped = new DataTable();
            string[] cols = { "Date", "FundingLineItem", "Description", "AllocationType", "Year",
                "PlannedDate", "Team", "Platform", "Vendor", "DRMCategory", "DRMProgram",
                "MemoDate", "CAMID", "ActualAmount", "AllocationAmount", "LPONumber",
                "AMSRequestNumber", "Requester", "Remarks", "Remarks2" };

            foreach (string c in cols)
                mapped.Columns.Add(c);

            // Build column name mapping (flexible header matching)
            var colMap = new System.Collections.Generic.Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < source.Columns.Count; i++)
            {
                string header = source.Columns[i].ColumnName.Trim();
                string normalized = NormalizeHeader(header);
                colMap[normalized] = i;
            }

            foreach (DataRow srcRow in source.Rows)
            {
                DataRow newRow = mapped.NewRow();
                newRow["Date"] = GetMappedValue(srcRow, colMap, "date");
                newRow["FundingLineItem"] = GetMappedValue(srcRow, colMap, "fundinglineitem");
                newRow["Description"] = GetMappedValue(srcRow, colMap, "description");
                newRow["AllocationType"] = GetMappedValue(srcRow, colMap, "allocationtype");
                newRow["Year"] = GetMappedValue(srcRow, colMap, "year");
                newRow["PlannedDate"] = GetMappedValue(srcRow, colMap, "planneddate");
                newRow["Team"] = GetMappedValue(srcRow, colMap, "team");
                newRow["Platform"] = GetMappedValue(srcRow, colMap, "platform");
                newRow["Vendor"] = GetMappedValue(srcRow, colMap, "vendor");
                newRow["DRMCategory"] = GetMappedValue(srcRow, colMap, "drmcategory");
                newRow["DRMProgram"] = GetMappedValue(srcRow, colMap, "drmprogram");
                newRow["MemoDate"] = GetMappedValue(srcRow, colMap, "memodate");
                newRow["CAMID"] = GetMappedValue(srcRow, colMap, "camid");
                newRow["ActualAmount"] = GetMappedValue(srcRow, colMap, "actualamount");
                newRow["AllocationAmount"] = GetMappedValue(srcRow, colMap, "allocationamount");
                newRow["LPONumber"] = GetMappedValue(srcRow, colMap, "lpo", "lponumber");
                newRow["AMSRequestNumber"] = GetMappedValue(srcRow, colMap, "amsrequest", "amsrequestnumber");
                newRow["Requester"] = GetMappedValue(srcRow, colMap, "requester");
                newRow["Remarks"] = GetMappedValue(srcRow, colMap, "remarks");
                newRow["Remarks2"] = GetMappedValue(srcRow, colMap, "remarks2");
                mapped.Rows.Add(newRow);
            }

            return mapped;
        }

        private static string NormalizeHeader(string header)
        {
            return System.Text.RegularExpressions.Regex.Replace(header, @"[\s_\-#]+", "").ToLower();
        }

        private static string GetMappedValue(DataRow row, System.Collections.Generic.Dictionary<string, int> colMap,
            string key, string altKey = null)
        {
            int idx;
            if (colMap.TryGetValue(key, out idx))
                return row[idx] != DBNull.Value ? row[idx].ToString().Trim() : "";
            if (altKey != null && colMap.TryGetValue(altKey, out idx))
                return row[idx] != DBNull.Value ? row[idx].ToString().Trim() : "";
            return "";
        }

        internal static DataTable ParseUploadedFile(System.Web.UI.WebControls.FileUpload fu, string ext)
        {
            if (ext == ".csv")
            {
                return ParseCsv(fu.FileContent);
            }
            else
            {
                // For .xls/.xlsx - save temp file and parse
                string tempPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString() + ext);
                try
                {
                    fu.SaveAs(tempPath);
                    return ParseExcelOleDb(tempPath);
                }
                finally
                {
                    if (File.Exists(tempPath))
                        try { File.Delete(tempPath); } catch { }
                }
            }
        }

        internal static DataTable ParseCsv(Stream stream)
        {
            DataTable dt = new DataTable();
            using (var reader = new StreamReader(stream))
            {
                bool isHeader = true;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    string[] fields = SplitCsvLine(line);

                    if (isHeader)
                    {
                        foreach (string field in fields)
                            dt.Columns.Add(field.Trim().Trim('"'));
                        isHeader = false;
                    }
                    else
                    {
                        DataRow row = dt.NewRow();
                        for (int i = 0; i < fields.Length && i < dt.Columns.Count; i++)
                            row[i] = fields[i].Trim().Trim('"');
                        dt.Rows.Add(row);
                    }
                }
            }
            return dt;
        }

        private static string[] SplitCsvLine(string line)
        {
            var fields = new System.Collections.Generic.List<string>();
            bool inQuotes = false;
            var current = new System.Text.StringBuilder();
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    inQuotes = !inQuotes;
                }
                else if (c == ',' && !inQuotes)
                {
                    fields.Add(current.ToString());
                    current.Clear();
                }
                else
                {
                    current.Append(c);
                }
            }
            fields.Add(current.ToString());
            return fields.ToArray();
        }

        internal static DataTable ParseExcelOleDb(string filePath)
        {
            DataTable dt = new DataTable();
            string ext = Path.GetExtension(filePath).ToLower();
            string connStr;
            if (ext == ".xlsx")
                connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 12.0 Xml;HDR=YES;IMEX=1'";
            else
                connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=YES;IMEX=1'";

            using (var conn = new System.Data.OleDb.OleDbConnection(connStr))
            {
                conn.Open();
                DataTable schemaTable = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, null);
                if (schemaTable == null || schemaTable.Rows.Count == 0)
                    throw new Exception("No sheets found in the Excel file.");

                string sheetName = schemaTable.Rows[0]["TABLE_NAME"].ToString();
                using (var cmd = new System.Data.OleDb.OleDbCommand("SELECT * FROM [" + sheetName + "]", conn))
                {
                    using (var da = new System.Data.OleDb.OleDbDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }

            // Remove completely empty rows
            for (int i = dt.Rows.Count - 1; i >= 0; i--)
            {
                bool allEmpty = true;
                foreach (DataColumn col in dt.Columns)
                {
                    if (dt.Rows[i][col] != DBNull.Value && !string.IsNullOrWhiteSpace(dt.Rows[i][col].ToString()))
                    {
                        allEmpty = false;
                        break;
                    }
                }
                if (allEmpty) dt.Rows.RemoveAt(i);
            }

            return dt;
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
