<%@ Page Title="Spending Allocation Entry" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="SpendingAllocationEntry.aspx.cs" Inherits="DemandFundManagement.Forms.SpendingAllocationEntry" %>



<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title">
        <span class="glyphicon glyphicon-edit"></span> <asp:Label ID="lblPageTitle" runat="server" Text="New Spending Allocation" />
    </h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <asp:HiddenField ID="hdnRecordID" runat="server" Value="0" />

    <div class="entry-form">
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>Date</label>
                <asp:TextBox ID="txtDate" runat="server" CssClass="form-control" TextMode="Date" />
            </div>
            <div class="form-col form-group">
                <label>Funding Line Item</label>
                <asp:TextBox ID="txtFundingLineItem" runat="server" CssClass="form-control" MaxLength="500" />
            </div>
            <div class="form-col-2x form-group">
                <label>Description</label>
                <asp:TextBox ID="txtDescription" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" MaxLength="2000" />
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>Allocation Type</label>
                <asp:TextBox ID="txtAllocationType" runat="server" CssClass="form-control" MaxLength="200" />
            </div>
            <div class="form-col form-group">
                <label>Year</label>
                <asp:TextBox ID="txtYear" runat="server" CssClass="form-control" MaxLength="10" />
            </div>
            <div class="form-col form-group">
                <label>Planned Date</label>
                <asp:TextBox ID="txtPlannedDate" runat="server" CssClass="form-control" TextMode="Date" />
            </div>
            <div class="form-col form-group">
                <label>Team</label>
                <asp:TextBox ID="txtTeam" runat="server" CssClass="form-control" MaxLength="200" />
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>Platform</label>
                <asp:TextBox ID="txtPlatform" runat="server" CssClass="form-control" MaxLength="200" />
            </div>
            <div class="form-col form-group">
                <label>Vendor</label>
                <asp:TextBox ID="txtVendor" runat="server" CssClass="form-control" MaxLength="200" />
            </div>
            <div class="form-col form-group">
                <label>DRM Category</label>
                <asp:TextBox ID="txtDRMCategory" runat="server" CssClass="form-control" MaxLength="200" />
            </div>
            <div class="form-col form-group">
                <label>DRM Program</label>
                <asp:TextBox ID="txtDRMProgram" runat="server" CssClass="form-control" MaxLength="200" />
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>Memo Date</label>
                <asp:TextBox ID="txtMemoDate" runat="server" CssClass="form-control" TextMode="Date" />
            </div>
            <div class="form-col form-group">
                <label>CAM ID</label>
                <asp:TextBox ID="txtCAMID" runat="server" CssClass="form-control" MaxLength="100" />
            </div>
            <div class="form-col form-group">
                <label>Actual Amount</label>
                <asp:TextBox ID="txtActualAmount" runat="server" CssClass="form-control" />
            </div>
            <div class="form-col form-group">
                <label>Allocation Amount</label>
                <asp:TextBox ID="txtAllocationAmount" runat="server" CssClass="form-control" />
            </div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col form-group">
                <label>LPO #</label>
                <asp:TextBox ID="txtLPONumber" runat="server" CssClass="form-control" MaxLength="100" />
            </div>
            <div class="form-col form-group">
                <label>AMS Request #</label>
                <asp:TextBox ID="txtAMSRequestNumber" runat="server" CssClass="form-control" MaxLength="100" />
            </div>
            <div class="form-col form-group">
                <label>Requester</label>
                <asp:TextBox ID="txtRequester" runat="server" CssClass="form-control" MaxLength="200" />
            </div>
            <div class="form-col form-group">&nbsp;</div>
        </div>
        <div class="form-row form-row-4">
            <div class="form-col-2x form-group">
                <label>Remarks</label>
                <asp:TextBox ID="txtRemarks" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" MaxLength="4000" />
            </div>
            <div class="form-col-2x form-group">
                <label>Remarks 2</label>
                <asp:TextBox ID="txtRemarks2" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" MaxLength="4000" />
            </div>
        </div>
    </div>

    <div class="btn-group">
        <asp:LinkButton ID="btnSave" runat="server" CssClass="btn btn-primary" OnClick="btnSave_Click">
            <span class="glyphicon glyphicon-floppy-disk"></span> Save
        </asp:LinkButton>
        <asp:LinkButton ID="btnSaveNew" runat="server" CssClass="btn btn-success" OnClick="btnSaveNew_Click">
            <span class="glyphicon glyphicon-floppy-saved"></span> Save &amp; New
        </asp:LinkButton>
        <asp:HyperLink ID="lnkCancel" runat="server" CssClass="btn btn-secondary" NavigateUrl="~/Forms/SpendingAllocation.aspx">
            <span class="glyphicon glyphicon-remove"></span> Cancel
        </asp:HyperLink>
    </div>

    <asp:Panel ID="pnlWorkflowTrigger" runat="server" Visible="false" CssClass="wf-trigger-panel" style="margin-top:15px;">
        <h4 style="margin-bottom:10px;"><span class="glyphicon glyphicon-random" style="color:var(--primary);"></span> Start Workflow</h4>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <select id="ddlWorkflowTrigger" class="form-control no-select2" style="width:280px;display:inline-block;height:34px;">
                <option value="">-- Select Workflow --</option>
            </select>
            <button type="button" class="btn btn-primary btn-sm" onclick="triggerWorkflow()">
                <span class="glyphicon glyphicon-play"></span> Start Workflow
            </button>
        </div>
        <div id="wfTriggerResult" style="margin-top:8px;display:none;" class="alert"></div>
        <div id="wfHistorySection" style="margin-top:15px;display:none;">
            <h5 style="font-weight:700;"><span class="glyphicon glyphicon-time"></span> Workflow History</h5>
            <table class="table table-bordered table-striped" style="font-size:13px;"><thead><tr><th>Instance</th><th>Workflow</th><th>Status</th><th>Started By</th><th>Started</th><th>Completed</th><th>Actions</th></tr></thead><tbody id="wfHistoryBody"></tbody></table>
        </div>
        <div class="modal-overlay" id="wfStepsModal" style="display:none;"><div class="modal-dialog" style="max-width:700px;"><div class="modal-header"><span class="glyphicon glyphicon-list-alt"></span> Workflow Steps<button type="button" class="modal-close" onclick="document.getElementById('wfStepsModal').style.display='none'">&times;</button></div><div class="modal-body"><table class="table table-bordered table-striped" style="font-size:13px;"><thead><tr><th>Step</th><th>Type</th><th>Status</th><th>Assigned To</th><th>Action By</th><th>Date</th><th>Comments</th></tr></thead><tbody id="wfStepsBody"></tbody></table></div><div class="modal-footer"><button type="button" class="btn btn-secondary" onclick="document.getElementById('wfStepsModal').style.display='none'">Close</button></div></div></div>
    </asp:Panel>
    <asp:HiddenField ID="hdnRecordIDForWF" runat="server" />
    <script type="text/javascript">
        (function () {
            var recIdEl = document.getElementById('<%= hdnRecordIDForWF.ClientID %>');
            if (!recIdEl || !recIdEl.value || recIdEl.value === '0') return;
            $.ajax({
                type: 'POST', url: '<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/GetPublishedWorkflows") %>',
                data: JSON.stringify({ tableName: 'SpendingAllocation' }),
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    var ddl = document.getElementById('ddlWorkflowTrigger');
                    if (!ddl) return;
                    ddl.innerHTML = '<option value="">-- Select Workflow --</option>';
                    (res.d || []).forEach(function (w) {
                        var opt = document.createElement('option'); opt.value = w.Id; opt.textContent = w.Name;
                        ddl.appendChild(opt);
                    });
                }
            });
        })();
        window.triggerWorkflow = function () {
            var ddl = document.getElementById('ddlWorkflowTrigger');
            var defId = ddl ? parseInt(ddl.value) : 0;
            if (!defId) { alert('Please select a workflow'); return; }
            var recId = parseInt(document.getElementById('<%= hdnRecordIDForWF.ClientID %>').value) || 0;
            if (!recId) { alert('Save the record first'); return; }
            $.ajax({
                type: 'POST', url: '<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/StartWorkflow") %>',
                data: JSON.stringify({ definitionId: defId, recordId: recId }),
                contentType: 'application/json', dataType: 'json',
                success: function (res) {
                    var r = res.d, div = document.getElementById('wfTriggerResult');
                    div.style.display = 'block';
                    div.className = r.Success ? 'alert alert-success' : 'alert alert-danger';
                    div.innerHTML = r.Success ? '<span class="glyphicon glyphicon-ok"></span> ' + r.Message + ' (Instance #' + r.InstanceId + ')'
                        : '<span class="glyphicon glyphicon-exclamation-sign"></span> ' + r.Message;
                    if (r.Success) loadWorkflowHistory();
                },
                error: function () { var div = document.getElementById('wfTriggerResult'); div.style.display='block'; div.className='alert alert-danger'; div.innerHTML='Error starting workflow'; }
            });
        };
        function loadWorkflowHistory() {
            var recId = parseInt(document.getElementById('<%= hdnRecordIDForWF.ClientID %>').value) || 0;
            if (!recId) return;
            $.ajax({ type:'POST', url:'<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/GetWorkflowHistory") %>', data:JSON.stringify({tableName:'SpendingAllocation',recordId:recId}), contentType:'application/json', dataType:'json',
                success: function(res) { var items=res.d||[]; var s=document.getElementById('wfHistorySection'),tb=document.getElementById('wfHistoryBody'); if(!items.length){s.style.display='none';return;} s.style.display='block'; var h=''; items.forEach(function(w){var b=w.Status==='Running'?'label-primary':w.Status==='Completed'?'label-success':'label-danger'; h+='<tr><td>#'+w.InstanceID+'</td><td>'+w.WorkflowName+'</td><td><span class="label '+b+'">'+w.Status+'</span></td><td>'+w.InitiatedBy+'</td><td>'+w.StartedDate+'</td><td>'+(w.CompletedDate||'-')+'</td><td><button type="button" class="btn btn-info btn-xs" onclick="viewWfSteps('+w.InstanceID+')"><span class="glyphicon glyphicon-list-alt"></span></button> '; if(w.Status==='Running') h+='<button type="button" class="btn btn-danger btn-xs" onclick="terminateWf('+w.InstanceID+')"><span class="glyphicon glyphicon-stop"></span></button>'; h+='</td></tr>';}); tb.innerHTML=h; }
            });
        }
        window.viewWfSteps = function(id) { $.ajax({ type:'POST', url:'<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/GetWorkflowInstanceStepsData") %>', data:JSON.stringify({instanceId:id}), contentType:'application/json', dataType:'json', success:function(res){var s=res.d||[],tb=document.getElementById('wfStepsBody'),h=''; s.forEach(function(st){var b=st.Status==='Completed'?'label-success':st.Status==='Pending'?'label-warning':st.Status==='Rejected'?'label-danger':'label-default'; h+='<tr><td>'+st.NodeLabel+'</td><td>'+st.NodeType+'</td><td><span class="label '+b+'">'+st.Status+'</span></td><td>'+st.AssignedTo+'</td><td>'+st.ActionBy+'</td><td>'+st.ActionDate+'</td><td>'+st.Comments+'</td></tr>';}); tb.innerHTML=h||'<tr><td colspan="7" style="text-align:center">No steps</td></tr>'; document.getElementById('wfStepsModal').style.display='flex';}}); };
        window.terminateWf = function(id) { if(!confirm('Stop this workflow?')) return; $.ajax({ type:'POST', url:'<%= ResolveUrl("~/Forms/WorkflowDesigner.aspx/TerminateWorkflow") %>', data:JSON.stringify({instanceId:id}), contentType:'application/json', dataType:'json', success:function(res){if(res.d.Success) loadWorkflowHistory();}}); };
        $(document).ready(function(){loadWorkflowHistory();});
    </script>
</asp:Content>
