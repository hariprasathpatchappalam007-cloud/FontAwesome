using System;
using System.Data;
using System.Web.UI;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class ApprovedFundingProgramEntry : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string idParam = Request.QueryString["id"];
                if (!string.IsNullOrEmpty(idParam))
                {
                    int id;
                    if (int.TryParse(idParam, out id) && id > 0)
                    {
                        hdnRecordID.Value = id.ToString();
                        hdnRecordIDForWF.Value = id.ToString();
                        lblPageTitle.Text = "Edit Approved Funding Program (ID: " + id + ")";
                        LoadRecord(id);
                        pnlWorkflowTrigger.Visible = true;
                    }
                }
            }
        }

        private void LoadRecord(int id)
        {
            DataRow row = DatabaseHelper.GetApprovedFundingProgramById(id);
            if (row == null) { ShowMessage("Record not found.", true); return; }

            txtTitle.Text = row["Title"] != DBNull.Value ? row["Title"].ToString() : "";
            txtType.Text = row["Type"] != DBNull.Value ? row["Type"].ToString() : "";
            txtDemandID.Text = row["DemandID"] != DBNull.Value ? row["DemandID"].ToString() : "";
            txtApprover.Text = row["Approver"] != DBNull.Value ? row["Approver"].ToString() : "";
            txtPrimaryLead.Text = row["PrimaryLead"] != DBNull.Value ? row["PrimaryLead"].ToString() : "";
            txtGL.Text = row["GL"] != DBNull.Value ? row["GL"].ToString() : "";
            txtCAPEX.Text = row["CAPEX"] != DBNull.Value ? Convert.ToDecimal(row["CAPEX"]).ToString("0.##") : "";
            txtCAPEXType.Text = row["CAPEXType"] != DBNull.Value ? row["CAPEXType"].ToString() : "";
            txtStatus.Text = row["Status"] != DBNull.Value ? row["Status"].ToString() : "";
            txtFundAmount.Text = row["FundAmount"] != DBNull.Value ? Convert.ToDecimal(row["FundAmount"]).ToString("0.##") : "";
            txtConsumed.Text = row["Consumed"] != DBNull.Value ? Convert.ToDecimal(row["Consumed"]).ToString("0.##") : "";
            txtAvailable.Text = row["Available"] != DBNull.Value ? Convert.ToDecimal(row["Available"]).ToString("0.##") : "";
            txtPlanned.Text = row["Planned"] != DBNull.Value ? Convert.ToDecimal(row["Planned"]).ToString("0.##") : "";
            txtApprovalForm.Text = row["ApprovalForm"] != DBNull.Value ? row["ApprovalForm"].ToString() : "";
            txtRemarks.Text = row["Remarks"] != DBNull.Value ? row["Remarks"].ToString() : "";
            txtProgramOwner.Text = row["ProgramOwner"] != DBNull.Value ? row["ProgramOwner"].ToString() : "";
        }

        protected void btnSave_Click(object sender, EventArgs e) { SaveRecord(false); }
        protected void btnSaveNew_Click(object sender, EventArgs e) { SaveRecord(true); }

        private void SaveRecord(bool redirectToNew)
        {
            try
            {
                decimal? capex = ParseDecimal(txtCAPEX.Text);
                decimal? fundAmount = ParseDecimal(txtFundAmount.Text);
                decimal? consumed = ParseDecimal(txtConsumed.Text);
                decimal? available = ParseDecimal(txtAvailable.Text);
                decimal? planned = ParseDecimal(txtPlanned.Text);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";

                int recordId = 0;
                int.TryParse(hdnRecordID.Value, out recordId);

                if (recordId > 0)
                {
                    DatabaseHelper.UpdateApprovedFundingProgram(recordId, txtTitle.Text.Trim(), txtType.Text.Trim(),
                        txtDemandID.Text.Trim(), txtApprover.Text.Trim(), txtPrimaryLead.Text.Trim(),
                        txtGL.Text.Trim(), capex, txtCAPEXType.Text.Trim(), txtStatus.Text.Trim(),
                        fundAmount, consumed, available, planned, txtApprovalForm.Text.Trim(),
                        txtRemarks.Text.Trim(), txtProgramOwner.Text.Trim(), currentUser);
                    ShowMessage("Record updated successfully (ID: " + recordId + ").", false);
                }
                else
                {
                    int newId = DatabaseHelper.InsertApprovedFundingProgram(txtTitle.Text.Trim(), txtType.Text.Trim(),
                        txtDemandID.Text.Trim(), txtApprover.Text.Trim(), txtPrimaryLead.Text.Trim(),
                        txtGL.Text.Trim(), capex, txtCAPEXType.Text.Trim(), txtStatus.Text.Trim(),
                        fundAmount, consumed, available, planned, txtApprovalForm.Text.Trim(),
                        txtRemarks.Text.Trim(), txtProgramOwner.Text.Trim(), currentUser);
                    ShowMessage("Record saved successfully (ID: " + newId + ").", false);
                    hdnRecordID.Value = newId.ToString();
                    hdnRecordIDForWF.Value = newId.ToString();
                    pnlWorkflowTrigger.Visible = true;
                }

                if (redirectToNew) Response.Redirect("~/Forms/ApprovedFundingProgramEntry.aspx");
            }
            catch (Exception ex) { ShowMessage("Error: " + ex.Message, true); }
        }

        private decimal? ParseDecimal(string val)
        {
            decimal d;
            return decimal.TryParse(val, out d) ? (decimal?)d : null;
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
