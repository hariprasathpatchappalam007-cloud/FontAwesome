<%@ Page Title="JIRA Integration" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="JiraIntegration.aspx.cs" Inherits="DemandFundManagement.Forms.JiraIntegration" %>



<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title"><span class="glyphicon glyphicon-link"></span> JIRA Integration</h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- Connection Settings -->
    <div class="panel">
        <div class="panel-header">
            <span class="glyphicon glyphicon-cog"></span> JIRA Connection Settings
        </div>
        <div class="panel-body">
            <div class="form-row-4">
                <div class="form-col-2x">
                    <div class="form-group">
                        <label>JIRA Base URL</label>
                        <asp:TextBox ID="txtJiraUrl" runat="server" CssClass="form-control" placeholder="https://yourcompany.atlassian.net" />
                    </div>
                </div>
                <div class="form-col">
                    <div class="form-group">
                        <label>Email / Username</label>
                        <asp:TextBox ID="txtJiraEmail" runat="server" CssClass="form-control" placeholder="user@company.com" />
                    </div>
                </div>
                <div class="form-col">
                    <div class="form-group">
                        <label>API Token</label>
                        <asp:TextBox ID="txtJiraToken" runat="server" CssClass="form-control" TextMode="Password" placeholder="API Token" />
                    </div>
                </div>
            </div>
            <div class="form-row-4">
                <div class="form-col">
                    <div class="form-group">
                        <label>Project Key</label>
                        <asp:TextBox ID="txtProjectKey" runat="server" CssClass="form-control" placeholder="e.g. DFM" />
                    </div>
                </div>
                <div class="form-col">
                    <asp:Button ID="btnConnect" runat="server" Text="Connect & Fetch" CssClass="btn btn-primary" OnClick="btnConnect_Click" Style="margin-top:22px;" />
                </div>
                <div class="form-col">
                    <asp:Button ID="btnTestConnection" runat="server" Text="Test Connection" CssClass="btn btn-secondary" OnClick="btnTestConnection_Click" Style="margin-top:22px;" />
                </div>
                <div class="form-col">
                    <asp:Button ID="btnSaveSettings" runat="server" Text="Save Settings" CssClass="btn btn-success" OnClick="btnSaveSettings_Click" Style="margin-top:22px;" />
                </div>
            </div>
        </div>
    </div>

    <!-- Connection Status -->
    <asp:Panel ID="pnlConnectionStatus" runat="server" Visible="false">
        <div class="jira-connection-status">
            <span class="glyphicon glyphicon-ok-circle jira-status-ok"></span>
            <span>Connected to JIRA &mdash; Project: <strong><asp:Label ID="lblProjectName" runat="server" /></strong></span>
        </div>
    </asp:Panel>

    <!-- Summary Cards -->
    <asp:Panel ID="pnlSummary" runat="server" Visible="false">
        <div class="dashboard-cards">
            <div class="dash-card">
                <div class="dash-number"><asp:Label ID="lblTotalIssues" runat="server" Text="0" /></div>
                <div class="dash-label">Total Issues</div>
            </div>
            <div class="dash-card">
                <div class="dash-number" style="color:#2196F3;"><asp:Label ID="lblOpenIssues" runat="server" Text="0" /></div>
                <div class="dash-label">Open</div>
            </div>
            <div class="dash-card">
                <div class="dash-number" style="color:#FF9800;"><asp:Label ID="lblInProgressIssues" runat="server" Text="0" /></div>
                <div class="dash-label">In Progress</div>
            </div>
            <div class="dash-card">
                <div class="dash-number" style="color:#4CAF50;"><asp:Label ID="lblDoneIssues" runat="server" Text="0" /></div>
                <div class="dash-label">Done</div>
            </div>
        </div>
    </asp:Panel>

    <!-- Issues Grid -->
    <asp:Panel ID="pnlIssues" runat="server" Visible="false">
        <div class="panel">
            <div class="panel-header">
                <span class="glyphicon glyphicon-th-list"></span> JIRA Issues
                <span class="record-count"><asp:Label ID="lblIssueCount" runat="server" /> issues</span>
            </div>
            <div class="panel-body" style="overflow-x:auto;">
                <div class="jira-filter-row">
                    <div class="form-group" style="display:inline-block;margin-right:15px;">
                        <label>Status Filter</label>
                        <asp:DropDownList ID="ddlStatusFilter" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="ddlStatusFilter_SelectedIndexChanged">
                            <asp:ListItem Value="">All Statuses</asp:ListItem>
                            <asp:ListItem Value="To Do">To Do</asp:ListItem>
                            <asp:ListItem Value="In Progress">In Progress</asp:ListItem>
                            <asp:ListItem Value="Done">Done</asp:ListItem>
                            <asp:ListItem Value="Open">Open</asp:ListItem>
                            <asp:ListItem Value="Closed">Closed</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                    <div class="form-group" style="display:inline-block;margin-right:15px;">
                        <label>Type Filter</label>
                        <asp:DropDownList ID="ddlTypeFilter" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="ddlTypeFilter_SelectedIndexChanged">
                            <asp:ListItem Value="">All Types</asp:ListItem>
                            <asp:ListItem Value="Story">Story</asp:ListItem>
                            <asp:ListItem Value="Bug">Bug</asp:ListItem>
                            <asp:ListItem Value="Task">Task</asp:ListItem>
                            <asp:ListItem Value="Epic">Epic</asp:ListItem>
                            <asp:ListItem Value="Sub-task">Sub-task</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                    <asp:Button ID="btnRefresh" runat="server" Text="Refresh" CssClass="btn btn-primary btn-sm" OnClick="btnConnect_Click" Style="margin-top:18px;" />
                </div>

                <asp:GridView ID="gvJiraIssues" runat="server" AutoGenerateColumns="false"
                    CssClass="grid-view" EmptyDataText="No issues found."
                    AllowPaging="true" PageSize="20" OnPageIndexChanging="gvJiraIssues_PageIndexChanging">
                    <Columns>
                        <asp:TemplateField HeaderText="Key">
                            <ItemTemplate>
                                <a href='<%# Eval("IssueUrl") %>' target="_blank" class="jira-key-link">
                                    <%# Server.HtmlEncode(Eval("Key").ToString()) %>
                                </a>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Type">
                            <ItemTemplate>
                                <span class='jira-type jira-type-<%# Eval("IssueType").ToString().ToLower().Replace(" ", "").Replace("-","") %>'>
                                    <%# Server.HtmlEncode(Eval("IssueType").ToString()) %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="Summary" HeaderText="Summary" />
                        <asp:TemplateField HeaderText="Status">
                            <ItemTemplate>
                                <span class='jira-status jira-status-<%# Eval("Status").ToString().ToLower().Replace(" ", "") %>'>
                                    <%# Server.HtmlEncode(Eval("Status").ToString()) %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Priority">
                            <ItemTemplate>
                                <span class='kanban-priority priority-<%# (Eval("Priority") ?? "medium").ToString().ToLower() %>'>
                                    <%# Server.HtmlEncode((Eval("Priority") ?? "").ToString()) %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="Assignee" HeaderText="Assignee" />
                        <asp:BoundField DataField="Created" HeaderText="Created" DataFormatString="{0:dd-MMM-yyyy}" />
                        <asp:BoundField DataField="Updated" HeaderText="Updated" DataFormatString="{0:dd-MMM-yyyy}" />
                    </Columns>
                    <PagerStyle CssClass="grid-pager" />
                </asp:GridView>
            </div>
        </div>
    </asp:Panel>

    <!-- No Connection Prompt -->
    <asp:Panel ID="pnlNoConnection" runat="server">
        <div class="metadata-select-prompt">
            <span class="glyphicon glyphicon-cloud"></span>
            <h3>Connect to JIRA</h3>
            <p>Enter your JIRA credentials above and click <strong>Connect &amp; Fetch</strong> to view project issues.</p>
            <p style="font-size:12px;color:var(--text-muted);margin-top:20px;">
                <strong>How to get an API Token:</strong><br />
                1. Go to <a href="https://id.atlassian.com/manage-profile/security/api-tokens" target="_blank">Atlassian API Tokens</a><br />
                2. Click "Create API token" and copy the generated token<br />
                3. Paste it in the API Token field above
            </p>
        </div>
    </asp:Panel>
</asp:Content>
