using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class WorkflowInstances : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            DataTable dt = DatabaseHelper.GetOngoingWorkflows();
            DataView dv = new DataView(dt);

            string statusFilter = ddlStatusFilter.SelectedValue;
            string tableFilter = ddlTableFilter.SelectedValue;

            string filter = "";
            if (!string.IsNullOrEmpty(statusFilter))
                filter = "Status = '" + statusFilter.Replace("'", "''") + "'";
            if (!string.IsNullOrEmpty(tableFilter))
            {
                if (!string.IsNullOrEmpty(filter)) filter += " AND ";
                filter += "LinkedTable = '" + tableFilter.Replace("'", "''") + "'";
            }

            if (!string.IsNullOrEmpty(filter))
                dv.RowFilter = filter;

            gvInstances.DataSource = dv;
            gvInstances.DataBind();
        }

        protected void ddlStatusFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void gvInstances_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int instanceId;
            if (!int.TryParse(e.CommandArgument.ToString(), out instanceId)) return;

            if (e.CommandName == "ViewSteps")
            {
                lblInstanceId.Text = instanceId.ToString();
                DataTable steps = DatabaseHelper.GetWorkflowInstanceSteps(instanceId);
                gvSteps.DataSource = steps;
                gvSteps.DataBind();
                ViewState["ShowSteps"] = "true";
            }
            else if (e.CommandName == "Terminate")
            {
                string user = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";
                DatabaseHelper.TerminateWorkflowInstance(instanceId, user);
                ShowMessage("Workflow #" + instanceId + " terminated.", false);
                BindGrid();
            }
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
