<%@ Page Title="My Tasks" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="MyTasks.aspx.cs" Inherits="DemandFundManagement.Forms.MyTasks" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title">
        <span class="glyphicon glyphicon-tasks"></span> My Tasks
    </h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <asp:GridView ID="gvMyTasks" runat="server" AutoGenerateColumns="false" CssClass="table table-bordered table-striped table-hover"
        EmptyDataText="No pending tasks assigned to you." OnRowCommand="gvMyTasks_RowCommand" DataKeyNames="TaskID">
        <Columns>
            <asp:BoundField DataField="TaskID" HeaderText="#" ItemStyle-Width="50px" />
            <asp:BoundField DataField="WorkflowName" HeaderText="Workflow" />
            <asp:BoundField DataField="NodeLabel" HeaderText="Step" />
            <asp:BoundField DataField="Title" HeaderText="Task Title" />
            <asp:BoundField DataField="Priority" HeaderText="Priority" ItemStyle-Width="80px" />
            <asp:BoundField DataField="LinkedTable" HeaderText="Table" />
            <asp:BoundField DataField="LinkedRecordID" HeaderText="Record #" ItemStyle-Width="70px" />
            <asp:TemplateField HeaderText="Completion" ItemStyle-Width="140px">
                <ItemTemplate>
                    <div style="display:flex;align-items:center;gap:6px;">
                        <div style="flex:1;background:#e0e0e0;border-radius:4px;height:18px;overflow:hidden;">
                            <div style='background:var(--primary);height:100%;width:<%# Eval("CompletionPercentage") %>%;transition:width .3s;'></div>
                        </div>
                        <span style="font-size:12px;font-weight:600;"><%# Eval("CompletionPercentage") %>%</span>
                    </div>
                </ItemTemplate>
            </asp:TemplateField>
            <asp:BoundField DataField="CreatedDate" HeaderText="Assigned" DataFormatString="{0:dd-MMM-yyyy}" />
            <asp:TemplateField HeaderText="Action" ItemStyle-Width="120px">
                <ItemTemplate>
                    <asp:LinkButton ID="btnAction" runat="server" CssClass="btn btn-primary btn-xs"
                        CommandName="ActionTask" CommandArgument='<%# Eval("TaskID") %>'>
                        <span class="glyphicon glyphicon-pencil"></span> Action
                    </asp:LinkButton>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
    </asp:GridView>

    <!-- Task Action Modal -->
    <div class="modal-overlay" id="taskActionModal" style="display:none;">
        <div class="modal-dialog" style="max-width:650px;">
            <div class="modal-header">
                <span class="glyphicon glyphicon-tasks"></span> Task Action
                <button type="button" class="modal-close" onclick="document.getElementById('taskActionModal').style.display='none'">&times;</button>
            </div>
            <div class="modal-body">
                <asp:HiddenField ID="hfTaskId" runat="server" />
                <asp:HiddenField ID="hfInstanceId" runat="server" />
                <asp:HiddenField ID="hfStepId" runat="server" />
                <div class="form-row form-row-2">
                    <div class="form-col form-group">
                        <label>Task Title</label>
                        <asp:Label ID="lblTaskTitle" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                    <div class="form-col form-group">
                        <label>Workflow</label>
                        <asp:Label ID="lblWorkflowName" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <asp:Label ID="lblDescription" runat="server" CssClass="form-control" style="background:#f9f9f9;min-height:50px;" />
                </div>
                <div class="form-row form-row-3">
                    <div class="form-col form-group">
                        <label>Linked Table</label>
                        <asp:Label ID="lblLinkedTable" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                    <div class="form-col form-group">
                        <label>Record #</label>
                        <asp:Label ID="lblRecordId" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                    <div class="form-col form-group">
                        <label>Priority</label>
                        <asp:Label ID="lblPriority" runat="server" CssClass="form-control" style="background:#f9f9f9;" />
                    </div>
                </div>
                <div class="form-group">
                    <label style="font-weight:700;">Completion Percentage</label>
                    <div style="display:flex;align-items:center;gap:12px;">
                        <input type="range" id="rangeCompletion" min="0" max="100" step="5" value="0"
                            style="flex:1;" oninput="document.getElementById('lblPct').textContent=this.value+'%';" />
                        <span id="lblPct" style="font-size:16px;font-weight:700;min-width:45px;">0%</span>
                    </div>
                </div>
                <div class="form-group">
                    <label>Comments</label>
                    <asp:TextBox ID="txtComments" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" MaxLength="2000" />
                </div>
            </div>
            <div class="modal-footer">
                <asp:Button ID="btnUpdateProgress" runat="server" Text="Update Progress" CssClass="btn btn-info" OnClick="btnUpdateProgress_Click" />
                <asp:Button ID="btnCompleteTask" runat="server" Text="Complete Task (100%)" CssClass="btn btn-success" OnClick="btnCompleteTask_Click" />
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('taskActionModal').style.display='none'">Cancel</button>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        var showModal = '<%= ViewState["ShowModal"] ?? "" %>';
        if (showModal === 'action') {
            document.getElementById('taskActionModal').style.display = 'flex';
            var pct = parseInt('<%= ViewState["CurrentPct"] ?? "0" %>') || 0;
            document.getElementById('rangeCompletion').value = pct;
            document.getElementById('lblPct').textContent = pct + '%';
        }
    </script>
</asp:Content>
