<%@ Page Title="Workflow Instances" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="WorkflowInstances.aspx.cs" Inherits="DemandFundManagement.Forms.WorkflowInstances" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title">
        <span class="glyphicon glyphicon-random"></span> Workflow Instances
    </h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- Filter -->
    <div style="margin-bottom:15px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
        <asp:DropDownList ID="ddlStatusFilter" runat="server" CssClass="form-control" style="width:180px;" AutoPostBack="true" OnSelectedIndexChanged="ddlStatusFilter_SelectedIndexChanged">
            <asp:ListItem Value="">All Statuses</asp:ListItem>
            <asp:ListItem Value="Running">Running</asp:ListItem>
            <asp:ListItem Value="Completed">Completed</asp:ListItem>
            <asp:ListItem Value="Cancelled">Cancelled</asp:ListItem>
            <asp:ListItem Value="Rejected">Rejected</asp:ListItem>
        </asp:DropDownList>
        <asp:DropDownList ID="ddlTableFilter" runat="server" CssClass="form-control" style="width:200px;" AutoPostBack="true" OnSelectedIndexChanged="ddlStatusFilter_SelectedIndexChanged">
            <asp:ListItem Value="">All Tables</asp:ListItem>
            <asp:ListItem Value="DemandFund">Demand Fund</asp:ListItem>
            <asp:ListItem Value="SpendingAllocation">Spending Allocation</asp:ListItem>
            <asp:ListItem Value="ApprovedFundingPrograms">Approved Funding</asp:ListItem>
            <asp:ListItem Value="FundingLineItems">Funding Line Items</asp:ListItem>
        </asp:DropDownList>
    </div>

    <!-- Instances Grid -->
    <asp:GridView ID="gvInstances" runat="server" AutoGenerateColumns="false"
        CssClass="grid-view" EmptyDataText="No workflow instances found."
        OnRowCommand="gvInstances_RowCommand">
        <Columns>
            <asp:BoundField DataField="InstanceID" HeaderText="ID" />
            <asp:BoundField DataField="WorkflowName" HeaderText="Workflow" />
            <asp:BoundField DataField="LinkedTable" HeaderText="Table" />
            <asp:BoundField DataField="LinkedRecordID" HeaderText="Record #" />
            <asp:TemplateField HeaderText="Status">
                <ItemTemplate>
                    <span class='label <%# Eval("Status").ToString() == "Running" ? "label-primary" : Eval("Status").ToString() == "Completed" ? "label-success" : Eval("Status").ToString() == "Rejected" ? "label-danger" : "label-warning" %>'>
                        <%# Eval("Status") %>
                    </span>
                </ItemTemplate>
            </asp:TemplateField>
            <asp:BoundField DataField="InitiatedByName" HeaderText="Started By" />
            <asp:BoundField DataField="StartedDate" HeaderText="Started" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
            <asp:BoundField DataField="CompletedDate" HeaderText="Completed" DataFormatString="{0:dd-MMM-yyyy HH:mm}" NullDisplayText="-" />
            <asp:TemplateField HeaderText="Actions">
                <ItemTemplate>
                    <asp:LinkButton ID="btnViewSteps" runat="server" CommandName="ViewSteps" CommandArgument='<%# Eval("InstanceID") %>'
                        CssClass="btn btn-info btn-xs" CausesValidation="false" ToolTip="View Steps">
                        <span class="glyphicon glyphicon-list-alt"></span>
                    </asp:LinkButton>
                    <asp:LinkButton ID="btnTerminate" runat="server" CommandName="Terminate" CommandArgument='<%# Eval("InstanceID") %>'
                        CssClass="btn btn-danger btn-xs" CausesValidation="false" ToolTip="Terminate"
                        Visible='<%# Eval("Status").ToString() == "Running" %>'
                        OnClientClick="return confirm('Are you sure you want to terminate this workflow?');">
                        <span class="glyphicon glyphicon-stop"></span>
                    </asp:LinkButton>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
    </asp:GridView>

    <!-- Steps Modal -->
    <div class="modal-overlay" id="stepsModal" style="display:none;">
        <div class="modal-dialog" style="max-width:750px;">
            <div class="modal-header">
                <span class="glyphicon glyphicon-list-alt"></span> Workflow Steps - Instance #<asp:Label ID="lblInstanceId" runat="server" />
                <button type="button" class="modal-close" onclick="document.getElementById('stepsModal').style.display='none'">&times;</button>
            </div>
            <div class="modal-body">
                <asp:GridView ID="gvSteps" runat="server" AutoGenerateColumns="false"
                    CssClass="grid-view" EmptyDataText="No steps found.">
                    <Columns>
                        <asp:BoundField DataField="NodeLabel" HeaderText="Step" />
                        <asp:BoundField DataField="NodeType" HeaderText="Type" />
                        <asp:TemplateField HeaderText="Status">
                            <ItemTemplate>
                                <span class='label <%# Eval("Status").ToString() == "Completed" ? "label-success" : Eval("Status").ToString() == "Pending" ? "label-warning" : Eval("Status").ToString() == "Rejected" ? "label-danger" : "label-default" %>'>
                                    <%# Eval("Status") %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:BoundField DataField="AssignedToName" HeaderText="Assigned To" NullDisplayText="-" />
                        <asp:BoundField DataField="ActionBy" HeaderText="Action By" NullDisplayText="-" />
                        <asp:BoundField DataField="ActionDate" HeaderText="Date" DataFormatString="{0:dd-MMM-yyyy HH:mm}" NullDisplayText="-" />
                        <asp:BoundField DataField="Comments" HeaderText="Comments" NullDisplayText="" />
                    </Columns>
                </asp:GridView>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('stepsModal').style.display='none'">Close</button>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        var showSteps = '<%= ViewState["ShowSteps"] ?? "" %>';
        if (showSteps === 'true') {
            document.getElementById('stepsModal').style.display = 'flex';
        }
    </script>
</asp:Content>
