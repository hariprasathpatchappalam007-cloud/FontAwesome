namespace DemandFundManagement.Forms
{
    public partial class WorkflowInstances
    {
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.DropDownList ddlStatusFilter;
        protected global::System.Web.UI.WebControls.DropDownList ddlTableFilter;
        protected global::System.Web.UI.WebControls.GridView gvInstances;
        protected global::System.Web.UI.WebControls.Label lblInstanceId;
        protected global::System.Web.UI.WebControls.GridView gvSteps;
    }
}
