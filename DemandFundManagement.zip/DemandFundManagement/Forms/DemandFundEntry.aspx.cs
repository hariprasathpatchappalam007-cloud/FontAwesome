using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Forms
{
    public partial class DemandFundEntry : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Ensure file uploads are included in form POST data
            Page.Form.Enctype = "multipart/form-data";

            if (!IsPostBack)
            {
                LoadDropdowns();

                // Check if editing
                string idParam = Request.QueryString["id"];
                if (!string.IsNullOrEmpty(idParam))
                {
                    int demandId;
                    if (int.TryParse(idParam, out demandId) && demandId > 0)
                    {
                        hdnDemandID.Value = demandId.ToString();
                        hdnRecordIDForWF.Value = demandId.ToString();
                        lblPageTitle.Text = "Edit Demand Fund Entry (ID: " + demandId + ")";
                        LoadDemandFund(demandId);
                        pnlWorkflowTrigger.Visible = true;
                    }
                }

                // Show success message after redirect
                if (Request.QueryString["saved"] == "1")
                {
                    ShowMessage("Demand Fund entry saved successfully (ID: " + Request.QueryString["id"] + ").", false);
                }
            }
        }

        private void LoadDropdowns()
        {
            BindDropdown(ddlDemandType, "DAMO_Type", "DAMO_Type");
            BindDropdown(ddlEngineeringLead, "EngineeringTeam", "Engineering_Lead");
            BindDropdown(ddlFundingSource, "Funding_Source_Type", "Funding_Source_Type");
            BindDropdown(ddlFundsApprovedBy, "FundApproval", "Fund_Approval_Type");
            BindDropdown(ddlPhaseDescription, "Phase_Description", "Phase_Description");
            BindDropdown(ddlBusinessVertical, "Primary_Vertical", "Primary_Vertical");
            BindDropdown(ddlInitiativeType, "Initiative_Type", "Initiative_Type");
            BindDropdown(ddlPlatformOwner, "Platform_Owner", "Platform_Owner");
            BindDropdown(ddlPortfolioHead, "Portfolio_Head", "Portfolio_Head");
            BindDropdown(ddlInitiativeSize, "TShirt_Size", "TShirt_Size");
            BindDropdown(ddlTechnologyVertical, "Technology_Vertical", "Technology_Vertical");
            BindDropdown(ddlProjectType, "Project_Type", "Project_Type");
            BindDropdown(ddlGLCode, "GL_Code", "GL_Code");
        }

        private void BindDropdown(System.Web.UI.WebControls.DropDownList ddl, string tableName, string valueColumn)
        {
            try
            {
                DataTable dt = DatabaseHelper.GetActiveMetadata(tableName, valueColumn);
                ddl.DataSource = dt;
                ddl.DataTextField = "DisplayText";
                ddl.DataValueField = "ID";
                ddl.DataBind();
                ddl.Items.Insert(0, new System.Web.UI.WebControls.ListItem("-- Select --", ""));
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("BindDropdown Error (" + tableName + "): " + ex.Message);
            }
        }

        private void LoadDemandFund(int id)
        {
            DataRow row = DatabaseHelper.GetDemandFundById(id);
            if (row == null)
            {
                ShowMessage("Demand Fund entry not found.", true);
                return;
            }

            txtInitiativeTitle.Text = row["InitiativeTitle"] != DBNull.Value ? row["InitiativeTitle"].ToString() : "";
            txtDescription.Text = row["Description"] != DBNull.Value ? row["Description"].ToString() : "";

            SetDropdownValue(ddlDemandType, row["Demand_TypeID"]);
            chkDAMOApproved.Checked = row["DAMO_Approved"] != DBNull.Value && Convert.ToBoolean(row["DAMO_Approved"]);
            SetDropdownValue(ddlEngineeringLead, row["Engineering_LeadID"]);
            SetDropdownValue(ddlFundingSource, row["Funding_SourceID"]);
            SetDropdownValue(ddlFundsApprovedBy, row["Funds_Approved_ByID"]);
            SetDropdownValue(ddlCapexOpex, row["CAPEX_OPEX_ID"]);
            SetDropdownValue(ddlGLCode, row["GL_CodeID"]);
            SetDropdownValue(ddlPhaseDescription, row["Phase_DescriptionID"]);
            txtPrimaryBusinessOwner.Text = row["Primary_Business_Owner"] != DBNull.Value ? row["Primary_Business_Owner"].ToString() : "";
            txtRemarks.Text = row["Remarks"] != DBNull.Value ? row["Remarks"].ToString() : "";
            SetDropdownValue(ddlBusinessVertical, row["Business_VerticalID"]);
            chkDigitalProject.Checked = row["Digital_Project"] != DBNull.Value && Convert.ToBoolean(row["Digital_Project"]);
            txtDeliveryManager.Text = row["Delivery_Manager"] != DBNull.Value ? row["Delivery_Manager"].ToString() : "";
            SetDropdownValue(ddlInitiativeType, row["Initiative_TypeID"]);
            SetDropdownValue(ddlPlatformOwner, row["Platform_OwnerID"]);
            SetDropdownValue(ddlPortfolioHead, row["Portfolio_HeadID"]);
            SetDropdownValue(ddlTechnologyVertical, row["Technology_VerticalID"]);
            SetDropdownValue(ddlInitiativeSize, row["Initiative_SizeID"]);
            SetDropdownValue(ddlProjectType, row["Project_TypeID"]);

            // Show existing file download links
            if (row["Document1_FileName"] != DBNull.Value && !string.IsNullOrEmpty(row["Document1_FileName"].ToString()))
            {
                lnkExistingDoc1.Text = "<span class='glyphicon glyphicon-file'></span> " + Server.HtmlEncode(row["Document1_FileName"].ToString());
                lnkExistingDoc1.NavigateUrl = ResolveUrl(row["Document1_Path"].ToString());
                lnkExistingDoc1.Visible = true;
            }
            if (row["AdditionalDoc_FileName"] != DBNull.Value && !string.IsNullOrEmpty(row["AdditionalDoc_FileName"].ToString()))
            {
                string[] fileNames = row["AdditionalDoc_FileName"].ToString().Split('|');
                string[] filePaths = row["AdditionalDoc_Path"] != DBNull.Value ? row["AdditionalDoc_Path"].ToString().Split('|') : new string[0];
                var sb = new System.Text.StringBuilder();
                for (int i = 0; i < fileNames.Length && i < filePaths.Length; i++)
                {
                    if (!string.IsNullOrEmpty(fileNames[i].Trim()))
                    {
                        string url = ResolveUrl(filePaths[i].Trim());
                        sb.AppendFormat("<a href=\"{0}\" target=\"_blank\" class=\"doc-link\"><span class='glyphicon glyphicon-file'></span> {1}</a> ",
                            HttpUtility.HtmlAttributeEncode(url), Server.HtmlEncode(fileNames[i].Trim()));
                    }
                }
                litExistingDocs.Text = sb.ToString();
            }
        }

        private void SetDropdownValue(System.Web.UI.WebControls.DropDownList ddl, object value)
        {
            if (value != null && value != DBNull.Value)
            {
                string val = value.ToString();
                if (ddl.Items.FindByValue(val) != null)
                {
                    ddl.SelectedValue = val;
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                SaveDemandFund(false);
            }
        }

        protected void btnSaveNew_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                SaveDemandFund(true);
            }
        }

        private void SaveDemandFund(bool redirectToNew)
        {
            try
            {
                string initiativeTitle = txtInitiativeTitle.Text.Trim();
                string description = txtDescription.Text.Trim();
                int? demandTypeId = GetNullableInt(ddlDemandType.SelectedValue);
                bool damoApproved = chkDAMOApproved.Checked;
                int? engineeringLeadId = GetNullableInt(ddlEngineeringLead.SelectedValue);
                int? fundingSourceId = GetNullableInt(ddlFundingSource.SelectedValue);
                int? fundsApprovedById = GetNullableInt(ddlFundsApprovedBy.SelectedValue);
                int? capexOpexId = GetNullableInt(ddlCapexOpex.SelectedValue);
                int? glCodeId = GetNullableInt(ddlGLCode.SelectedValue);
                int? phaseDescriptionId = GetNullableInt(ddlPhaseDescription.SelectedValue);
                string primaryBusinessOwner = txtPrimaryBusinessOwner.Text.Trim();
                string remarks = txtRemarks.Text.Trim();
                int? businessVerticalId = GetNullableInt(ddlBusinessVertical.SelectedValue);
                bool digitalProject = chkDigitalProject.Checked;
                string deliveryManager = txtDeliveryManager.Text.Trim();
                int? initiativeTypeId = GetNullableInt(ddlInitiativeType.SelectedValue);
                int? platformOwnerId = GetNullableInt(ddlPlatformOwner.SelectedValue);
                int? portfolioHeadId = GetNullableInt(ddlPortfolioHead.SelectedValue);
                int? technologyVerticalId = GetNullableInt(ddlTechnologyVertical.SelectedValue);
                int? initiativeSizeId = GetNullableInt(ddlInitiativeSize.SelectedValue);
                int? projectTypeId = GetNullableInt(ddlProjectType.SelectedValue);

                // Handle file uploads
                string doc1FileName = null, doc1Path = null;
                string addDocFileName = null, addDocPath = null;

                if (fuDocument1.HasFile)
                {
                    ValidateAndSaveFile(fuDocument1, out doc1FileName, out doc1Path);
                }
                if (fuAdditionalDoc.HasFile)
                {
                    var addNames = new List<string>();
                    var addPaths = new List<string>();
                    foreach (HttpPostedFile postedFile in fuAdditionalDoc.PostedFiles)
                    {
                        string fn, fp;
                        ValidateAndSavePostedFile(postedFile, out fn, out fp);
                        addNames.Add(fn);
                        addPaths.Add(fp);
                    }
                    addDocFileName = string.Join("|", addNames);
                    addDocPath = string.Join("|", addPaths);
                }

                // Get existing file info if editing and no new file uploaded
                int demandId = 0;
                int.TryParse(hdnDemandID.Value, out demandId);

                if (demandId > 0)
                {
                    DataRow existing = DatabaseHelper.GetDemandFundById(demandId);
                    if (existing != null)
                    {
                        if (doc1FileName == null)
                        {
                            doc1FileName = existing["Document1_FileName"] != DBNull.Value ? existing["Document1_FileName"].ToString() : null;
                            doc1Path = existing["Document1_Path"] != DBNull.Value ? existing["Document1_Path"].ToString() : null;
                        }
                        if (addDocFileName == null)
                        {
                            addDocFileName = existing["AdditionalDoc_FileName"] != DBNull.Value ? existing["AdditionalDoc_FileName"].ToString() : null;
                            addDocPath = existing["AdditionalDoc_Path"] != DBNull.Value ? existing["AdditionalDoc_Path"].ToString() : null;
                        }
                    }
                }

                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "Unknown";

                if (demandId > 0)
                {
                    // Update
                    DatabaseHelper.UpdateDemandFund(demandId, initiativeTitle, description, demandTypeId,
                        damoApproved, engineeringLeadId, fundingSourceId, fundsApprovedById,
                        capexOpexId, glCodeId, phaseDescriptionId, primaryBusinessOwner, remarks,
                        businessVerticalId, digitalProject, deliveryManager,
                        initiativeTypeId, platformOwnerId, portfolioHeadId, technologyVerticalId,
                        initiativeSizeId, projectTypeId, doc1FileName, doc1Path, addDocFileName,
                        addDocPath, currentUser);

                    if (redirectToNew)
                    {
                        Response.Redirect("~/Forms/DemandFundEntry.aspx");
                    }
                    else
                    {
                        Response.Redirect("~/Forms/DemandFundEntry.aspx?id=" + demandId + "&saved=1");
                    }
                }
                else
                {
                    // Insert
                    int newId = DatabaseHelper.InsertDemandFund(initiativeTitle, description, demandTypeId,
                        damoApproved, engineeringLeadId, fundingSourceId, fundsApprovedById,
                        capexOpexId, glCodeId, phaseDescriptionId, primaryBusinessOwner, remarks,
                        businessVerticalId, digitalProject, deliveryManager,
                        initiativeTypeId, platformOwnerId, portfolioHeadId, technologyVerticalId,
                        initiativeSizeId, projectTypeId, doc1FileName, doc1Path, addDocFileName,
                        addDocPath, currentUser);

                    if (redirectToNew)
                    {
                        Response.Redirect("~/Forms/DemandFundEntry.aspx");
                    }
                    else
                    {
                        // Redirect to edit page so file links display correctly
                        Response.Redirect("~/Forms/DemandFundEntry.aspx?id=" + newId + "&saved=1");
                    }
                }
            }
            catch (Exception ex)
            {
                ShowMessage("Error saving: " + ex.Message, true);
            }
        }

        private void ValidateAndSaveFile(System.Web.UI.WebControls.FileUpload fu, out string fileName, out string filePath)
        {
            fileName = null;
            filePath = null;

            string allowedExtensions = ConfigurationManager.AppSettings["AllowedFileExtensions"] ?? ".pdf,.doc,.docx,.xls,.xlsx";
            int maxSizeMB = 10;
            int.TryParse(ConfigurationManager.AppSettings["MaxUploadSizeMB"], out maxSizeMB);

            string ext = Path.GetExtension(fu.FileName).ToLower();
            if (!allowedExtensions.ToLower().Contains(ext))
            {
                throw new Exception("File type '" + ext + "' is not allowed. Allowed: " + allowedExtensions);
            }

            if (fu.FileBytes.Length > maxSizeMB * 1024 * 1024)
            {
                throw new Exception("File size exceeds " + maxSizeMB + "MB limit.");
            }

            // Sanitize file name
            string safeFileName = Path.GetFileNameWithoutExtension(fu.FileName);
            safeFileName = System.Text.RegularExpressions.Regex.Replace(safeFileName, @"[^\w\-]", "_");
            safeFileName = safeFileName + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ext;

            string uploadFolder = Server.MapPath(ConfigurationManager.AppSettings["UploadPath"] ?? "~/Uploads/");
            if (!Directory.Exists(uploadFolder))
            {
                Directory.CreateDirectory(uploadFolder);
            }

            string fullPath = Path.Combine(uploadFolder, safeFileName);
            fu.SaveAs(fullPath);

            fileName = fu.FileName;
            filePath = "~/Uploads/" + safeFileName;
        }

        private void ValidateAndSavePostedFile(HttpPostedFile postedFile, out string fileName, out string filePath)
        {
            fileName = null;
            filePath = null;

            string allowedExtensions = ConfigurationManager.AppSettings["AllowedFileExtensions"] ?? ".pdf,.doc,.docx,.xls,.xlsx";
            int maxSizeMB = 10;
            int.TryParse(ConfigurationManager.AppSettings["MaxUploadSizeMB"], out maxSizeMB);
            if (maxSizeMB == 0) maxSizeMB = 10;

            string ext = Path.GetExtension(postedFile.FileName).ToLower();
            if (!allowedExtensions.ToLower().Contains(ext))
            {
                throw new Exception("File type '" + ext + "' is not allowed. Allowed: " + allowedExtensions);
            }

            if (postedFile.ContentLength > maxSizeMB * 1024 * 1024)
            {
                throw new Exception("File size exceeds " + maxSizeMB + "MB limit.");
            }

            string safeFileName = Path.GetFileNameWithoutExtension(postedFile.FileName);
            safeFileName = System.Text.RegularExpressions.Regex.Replace(safeFileName, @"[^\w\-]", "_");
            safeFileName = safeFileName + "_" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + ext;

            string uploadFolder = Server.MapPath(ConfigurationManager.AppSettings["UploadPath"] ?? "~/Uploads/");
            if (!Directory.Exists(uploadFolder))
            {
                Directory.CreateDirectory(uploadFolder);
            }

            string fullPath = Path.Combine(uploadFolder, safeFileName);
            postedFile.SaveAs(fullPath);

            fileName = postedFile.FileName;
            filePath = "~/Uploads/" + safeFileName;
        }

        private int? GetNullableInt(string value)
        {
            int result;
            if (!string.IsNullOrEmpty(value) && int.TryParse(value, out result))
            {
                return result;
            }
            return null;
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
