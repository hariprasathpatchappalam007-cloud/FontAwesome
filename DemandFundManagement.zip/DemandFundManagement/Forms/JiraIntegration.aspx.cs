using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemandFundManagement.Forms
{
    public partial class JiraIntegration : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadSavedSettings();
            }
        }

        private void LoadSavedSettings()
        {
            string url = ConfigurationManager.AppSettings["JiraBaseUrl"];
            string email = ConfigurationManager.AppSettings["JiraEmail"];
            string projectKey = ConfigurationManager.AppSettings["JiraProjectKey"];

            if (!string.IsNullOrEmpty(url)) txtJiraUrl.Text = url;
            if (!string.IsNullOrEmpty(email)) txtJiraEmail.Text = email;
            if (!string.IsNullOrEmpty(projectKey)) txtProjectKey.Text = projectKey;
        }

        protected void btnTestConnection_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            try
            {
                string url = txtJiraUrl.Text.TrimEnd('/') + "/rest/api/2/myself";
                string json = MakeJiraRequest(url);

                var serializer = new JavaScriptSerializer();
                var result = serializer.Deserialize<Dictionary<string, object>>(json);

                string displayName = result.ContainsKey("displayName") ? result["displayName"].ToString() : "Unknown";
                ShowMessage("Connection successful! Authenticated as: " + Server.HtmlEncode(displayName), false);
            }
            catch (WebException ex)
            {
                HandleJiraError(ex);
            }
            catch (Exception ex)
            {
                ShowMessage("Connection failed: " + Server.HtmlEncode(ex.Message), true);
            }
        }

        protected void btnConnect_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            try
            {
                string projectKey = txtProjectKey.Text.Trim();
                string baseUrl = txtJiraUrl.Text.TrimEnd('/');

                // Fetch project info
                string projectUrl = baseUrl + "/rest/api/2/project/" + Uri.EscapeDataString(projectKey);
                string projectJson = MakeJiraRequest(projectUrl);
                var serializer = new JavaScriptSerializer();
                var projectInfo = serializer.Deserialize<Dictionary<string, object>>(projectJson);

                lblProjectName.Text = Server.HtmlEncode(projectInfo.ContainsKey("name") ? projectInfo["name"].ToString() : projectKey);
                pnlConnectionStatus.Visible = true;

                // Fetch issues
                FetchAndDisplayIssues(baseUrl, projectKey, serializer);

                pnlNoConnection.Visible = false;
            }
            catch (WebException ex)
            {
                HandleJiraError(ex);
                pnlConnectionStatus.Visible = false;
                pnlSummary.Visible = false;
                pnlIssues.Visible = false;
            }
            catch (Exception ex)
            {
                ShowMessage("Error: " + Server.HtmlEncode(ex.Message), true);
            }
        }

        private void FetchAndDisplayIssues(string baseUrl, string projectKey, JavaScriptSerializer serializer)
        {
            // Build JQL with filters
            string jql = "project=" + Uri.EscapeDataString(projectKey);

            string statusFilter = ddlStatusFilter.SelectedValue;
            if (!string.IsNullOrEmpty(statusFilter))
            {
                jql += " AND status=\"" + statusFilter.Replace("\"", "\\\"") + "\"";
            }

            string typeFilter = ddlTypeFilter.SelectedValue;
            if (!string.IsNullOrEmpty(typeFilter))
            {
                jql += " AND issuetype=\"" + typeFilter.Replace("\"", "\\\"") + "\"";
            }

            jql += " ORDER BY updated DESC";

            string searchUrl = baseUrl + "/rest/api/2/search?jql=" + Uri.EscapeDataString(jql)
                + "&maxResults=100&fields=summary,status,issuetype,priority,assignee,created,updated";

            string issuesJson = MakeJiraRequest(searchUrl);
            var searchResult = serializer.Deserialize<Dictionary<string, object>>(issuesJson);

            int total = searchResult.ContainsKey("total") ? Convert.ToInt32(searchResult["total"]) : 0;
            lblTotalIssues.Text = total.ToString();

            DataTable dtIssues = new DataTable();
            dtIssues.Columns.Add("Key", typeof(string));
            dtIssues.Columns.Add("IssueType", typeof(string));
            dtIssues.Columns.Add("Summary", typeof(string));
            dtIssues.Columns.Add("Status", typeof(string));
            dtIssues.Columns.Add("Priority", typeof(string));
            dtIssues.Columns.Add("Assignee", typeof(string));
            dtIssues.Columns.Add("Created", typeof(DateTime));
            dtIssues.Columns.Add("Updated", typeof(DateTime));
            dtIssues.Columns.Add("IssueUrl", typeof(string));

            int openCount = 0, inProgressCount = 0, doneCount = 0;

            if (searchResult.ContainsKey("issues"))
            {
                var issues = searchResult["issues"] as System.Collections.ArrayList;
                if (issues != null)
                {
                    foreach (Dictionary<string, object> issue in issues)
                    {
                        string key = issue.ContainsKey("key") ? issue["key"].ToString() : "";
                        var fields = issue.ContainsKey("fields") ? issue["fields"] as Dictionary<string, object> : new Dictionary<string, object>();

                        string summary = GetNestedValue(fields, "summary");
                        string status = GetNestedDictValue(fields, "status", "name");
                        string issueType = GetNestedDictValue(fields, "issuetype", "name");
                        string priority = GetNestedDictValue(fields, "priority", "name");
                        string assignee = GetNestedDictValue(fields, "assignee", "displayName");
                        string created = GetNestedValue(fields, "created");
                        string updated = GetNestedValue(fields, "updated");

                        // Count by status category
                        string statusLower = status.ToLower();
                        if (statusLower == "done" || statusLower == "closed" || statusLower == "resolved")
                            doneCount++;
                        else if (statusLower == "in progress" || statusLower == "in review")
                            inProgressCount++;
                        else
                            openCount++;

                        DataRow row = dtIssues.NewRow();
                        row["Key"] = key;
                        row["IssueType"] = issueType;
                        row["Summary"] = summary;
                        row["Status"] = status;
                        row["Priority"] = priority;
                        row["Assignee"] = string.IsNullOrEmpty(assignee) ? "Unassigned" : assignee;

                        DateTime createdDt;
                        if (DateTime.TryParse(created, out createdDt))
                            row["Created"] = createdDt;

                        DateTime updatedDt;
                        if (DateTime.TryParse(updated, out updatedDt))
                            row["Updated"] = updatedDt;

                        row["IssueUrl"] = baseUrl + "/browse/" + key;
                        dtIssues.Rows.Add(row);
                    }
                }
            }

            lblOpenIssues.Text = openCount.ToString();
            lblInProgressIssues.Text = inProgressCount.ToString();
            lblDoneIssues.Text = doneCount.ToString();
            lblIssueCount.Text = total.ToString();

            ViewState["JiraIssues"] = dtIssues;

            gvJiraIssues.DataSource = dtIssues;
            gvJiraIssues.DataBind();

            pnlSummary.Visible = true;
            pnlIssues.Visible = true;
        }

        protected void gvJiraIssues_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvJiraIssues.PageIndex = e.NewPageIndex;
            DataTable dt = ViewState["JiraIssues"] as DataTable;
            if (dt != null)
            {
                gvJiraIssues.DataSource = dt;
                gvJiraIssues.DataBind();
            }
        }

        protected void ddlStatusFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtJiraUrl.Text) && !string.IsNullOrEmpty(txtProjectKey.Text))
                btnConnect_Click(sender, e);
        }

        protected void ddlTypeFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtJiraUrl.Text) && !string.IsNullOrEmpty(txtProjectKey.Text))
                btnConnect_Click(sender, e);
        }

        protected void btnSaveSettings_Click(object sender, EventArgs e)
        {
            // Save to session for this user's session (Web.config is read-only at runtime)
            Session["JiraBaseUrl"] = txtJiraUrl.Text.Trim();
            Session["JiraEmail"] = txtJiraEmail.Text.Trim();
            Session["JiraProjectKey"] = txtProjectKey.Text.Trim();
            // Note: Token is not persisted for security - must be re-entered each session
            ShowMessage("Settings saved for this session. For permanent configuration, update Web.config appSettings.", false);
        }

        private string MakeJiraRequest(string url)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.ContentType = "application/json";
            request.Accept = "application/json";
            request.Timeout = 30000;

            // Basic auth with email:token
            string credentials = txtJiraEmail.Text.Trim() + ":" + txtJiraToken.Text.Trim();
            string encoded = Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials));
            request.Headers["Authorization"] = "Basic " + encoded;

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                return reader.ReadToEnd();
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtJiraUrl.Text))
            {
                ShowMessage("JIRA Base URL is required.", true);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtJiraEmail.Text))
            {
                ShowMessage("JIRA Email/Username is required.", true);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtJiraToken.Text))
            {
                ShowMessage("JIRA API Token is required.", true);
                return false;
            }

            // Validate URL format
            Uri uriResult;
            if (!Uri.TryCreate(txtJiraUrl.Text.Trim(), UriKind.Absolute, out uriResult) ||
                (uriResult.Scheme != Uri.UriSchemeHttp && uriResult.Scheme != Uri.UriSchemeHttps))
            {
                ShowMessage("Please enter a valid JIRA URL (e.g. https://yourcompany.atlassian.net).", true);
                return false;
            }

            return true;
        }

        private void HandleJiraError(WebException ex)
        {
            if (ex.Response != null)
            {
                var response = (HttpWebResponse)ex.Response;
                string body = "";
                using (var reader = new StreamReader(response.GetResponseStream()))
                {
                    body = reader.ReadToEnd();
                }

                switch (response.StatusCode)
                {
                    case HttpStatusCode.Unauthorized:
                        ShowMessage("Authentication failed. Please check your email and API token.", true);
                        break;
                    case HttpStatusCode.Forbidden:
                        ShowMessage("Access denied. Your account may not have permission to access this project.", true);
                        break;
                    case HttpStatusCode.NotFound:
                        ShowMessage("Project not found. Please check the project key.", true);
                        break;
                    default:
                        ShowMessage("JIRA API error (" + (int)response.StatusCode + "): " + Server.HtmlEncode(body.Length > 200 ? body.Substring(0, 200) : body), true);
                        break;
                }
            }
            else
            {
                ShowMessage("Connection error: " + Server.HtmlEncode(ex.Message), true);
            }
        }

        private string GetNestedValue(Dictionary<string, object> dict, string key)
        {
            if (dict == null || !dict.ContainsKey(key) || dict[key] == null) return "";
            return dict[key].ToString();
        }

        private string GetNestedDictValue(Dictionary<string, object> dict, string key, string subKey)
        {
            if (dict == null || !dict.ContainsKey(key) || dict[key] == null) return "";
            var nested = dict[key] as Dictionary<string, object>;
            if (nested == null || !nested.ContainsKey(subKey) || nested[subKey] == null) return "";
            return nested[subKey].ToString();
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = message;
        }
    }
}
