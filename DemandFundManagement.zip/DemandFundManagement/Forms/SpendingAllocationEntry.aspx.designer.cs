namespace DemandFundManagement.Forms
{
    public partial class SpendingAllocationEntry
    {
        protected global::System.Web.UI.WebControls.Label lblPageTitle;
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hdnRecordID;
        protected global::System.Web.UI.WebControls.TextBox txtDate;
        protected global::System.Web.UI.WebControls.TextBox txtFundingLineItem;
        protected global::System.Web.UI.WebControls.TextBox txtDescription;
        protected global::System.Web.UI.WebControls.TextBox txtAllocationType;
        protected global::System.Web.UI.WebControls.TextBox txtYear;
        protected global::System.Web.UI.WebControls.TextBox txtPlannedDate;
        protected global::System.Web.UI.WebControls.TextBox txtTeam;
        protected global::System.Web.UI.WebControls.TextBox txtPlatform;
        protected global::System.Web.UI.WebControls.TextBox txtVendor;
        protected global::System.Web.UI.WebControls.TextBox txtDRMCategory;
        protected global::System.Web.UI.WebControls.TextBox txtDRMProgram;
        protected global::System.Web.UI.WebControls.TextBox txtMemoDate;
        protected global::System.Web.UI.WebControls.TextBox txtCAMID;
        protected global::System.Web.UI.WebControls.TextBox txtActualAmount;
        protected global::System.Web.UI.WebControls.TextBox txtAllocationAmount;
        protected global::System.Web.UI.WebControls.TextBox txtLPONumber;
        protected global::System.Web.UI.WebControls.TextBox txtAMSRequestNumber;
        protected global::System.Web.UI.WebControls.TextBox txtRequester;
        protected global::System.Web.UI.WebControls.TextBox txtRemarks;
        protected global::System.Web.UI.WebControls.TextBox txtRemarks2;
        protected global::System.Web.UI.WebControls.LinkButton btnSave;
        protected global::System.Web.UI.WebControls.LinkButton btnSaveNew;
        protected global::System.Web.UI.WebControls.HyperLink lnkCancel;
        protected global::System.Web.UI.WebControls.Panel pnlWorkflowTrigger;
        protected global::System.Web.UI.WebControls.HiddenField hdnRecordIDForWF;
    }
}
