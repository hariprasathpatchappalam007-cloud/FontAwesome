using System;
using System.Web;

namespace DemandFundManagement
{
    public class Global : HttpApplication
    {
        private static string _appStartToken;

        protected void Application_Start(object sender, EventArgs e)
        {
            // Generate a unique token for this app instance to detect restarts
            _appStartToken = Guid.NewGuid().ToString();

            // Register jQuery for ScriptResourceMapping (required by UnobtrusiveValidationMode)
            System.Web.UI.ScriptManager.ScriptResourceMapping.AddDefinition("jquery",
                new System.Web.UI.ScriptResourceDefinition
                {
                    Path = "~/Scripts/jquery-1.10.2.min.js",
                    DebugPath = "~/Scripts/jquery-1.10.2.js",
                    CdnPath = "https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js",
                    CdnDebugPath = "https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.js"
                });
        }

        public static string AppStartToken { get { return _appStartToken; } }

        protected void Session_Start(object sender, EventArgs e)
        {
            // Stamp session with current app token so we can detect stale sessions after restart
            Session["AppToken"] = _appStartToken;
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();
            if (ex != null)
            {
                System.Diagnostics.Debug.WriteLine("Application Error: " + ex.Message);
            }
        }

        protected void Session_End(object sender, EventArgs e)
        {
        }

        protected void Application_End(object sender, EventArgs e)
        {
        }
    }
}
