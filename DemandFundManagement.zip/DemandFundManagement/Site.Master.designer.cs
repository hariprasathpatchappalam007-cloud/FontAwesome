namespace DemandFundManagement
{
    public partial class SiteMaster
    {
        protected global::System.Web.UI.WebControls.Panel pnlAdminMenu;
        protected global::System.Web.UI.WebControls.Repeater rptMetadataTree;
        protected global::System.Web.UI.WebControls.Label lblUserName;
        protected global::System.Web.UI.WebControls.Label lblUserRole;
        protected global::System.Web.UI.WebControls.LinkButton btnLogout;
        protected global::System.Web.UI.WebControls.Label lblGlobalNotifCount;
        protected global::System.Web.UI.WebControls.Repeater rptGlobalNotifs;
        protected global::System.Web.UI.WebControls.Panel pnlNoGlobalNotifs;
    }
}
