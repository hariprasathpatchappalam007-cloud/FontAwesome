using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement.Admin
{
    public partial class MetadataManagement : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Admin only
            if (Session["RoleID"] == null || Convert.ToInt32(Session["RoleID"]) != 1)
            {
                Response.Redirect("~/Default.aspx");
                return;
            }

            if (!IsPostBack)
            {
                // Load from query string
                string configIdParam = Request.QueryString["configId"];
                if (!string.IsNullOrEmpty(configIdParam))
                {
                    int configId;
                    if (int.TryParse(configIdParam, out configId) && configId > 0)
                    {
                        hdnConfigId.Value = configId.ToString();
                        LoadMetadataByConfigId(configId);
                    }
                }
            }
            else
            {
                // On postback, keep panels visible if a table was loaded
                if (!string.IsNullOrEmpty(hdnTableName.Value))
                {
                    pnlSelectPrompt.Visible = false;
                    pnlEditItem.Visible = true;
                    pnlGrid.Visible = true;
                }
            }
        }

        private void LoadMetadataByConfigId(int configId)
        {
            DataTable configDt = DatabaseHelper.GetMetadataConfig();
            DataRow[] rows = configDt.Select("ConfigID = " + configId);

            if (rows.Length > 0)
            {
                string tableName = rows[0]["TableName"].ToString();
                string displayName = rows[0]["DisplayName"].ToString();
                string valueColumn = rows[0]["ValueColumn"].ToString();

                hdnTableName.Value = tableName;
                hdnValueColumn.Value = valueColumn;
                lblValueColumnName.Text = displayName;
                lblGridTitle.Text = displayName + " Items";

                pnlSelectPrompt.Visible = false;
                pnlEditItem.Visible = true;
                pnlGrid.Visible = true;

                // Set next ID
                int nextId = DatabaseHelper.GetNextMetadataId(tableName);
                txtItemID.Text = nextId.ToString();

                BindMetadataGrid(tableName, valueColumn);
                ClearItemForm();
            }
        }

        private void BindMetadataGrid(string tableName, string valueColumn)
        {
            try
            {
                DataTable dt = DatabaseHelper.GetMetadataItems(tableName, valueColumn);
                gvMetadataItems.DataSource = dt;
                gvMetadataItems.DataBind();
            }
            catch (Exception ex)
            {
                ShowMessage("Error loading data: " + ex.Message, true);
            }
        }

        protected void btnSaveItem_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid)
                return;

            try
            {
                string tableName = hdnTableName.Value;
                string valueColumn = hdnValueColumn.Value;
                string value = txtItemValue.Text.Trim();
                int itemId;

                if (!int.TryParse(txtItemID.Text.Trim(), out itemId))
                {
                    ShowMessage("Please enter a valid ID.", true);
                    return;
                }

                int editingId;
                int.TryParse(hdnItemID.Value, out editingId);

                if (editingId > 0)
                {
                    // Update existing
                    DatabaseHelper.UpdateMetadataItem(tableName, valueColumn, editingId, value);
                    ShowMessage("Item updated successfully.", false);
                }
                else
                {
                    // Insert new
                    DatabaseHelper.InsertMetadataItem(tableName, valueColumn, itemId, value);
                    ShowMessage("Item added successfully.", false);
                }

                ClearItemForm();
                // Set next ID
                int nextId = DatabaseHelper.GetNextMetadataId(tableName);
                txtItemID.Text = nextId.ToString();

                BindMetadataGrid(tableName, valueColumn);
            }
            catch (Exception ex)
            {
                ShowMessage("Error: " + ex.Message, true);
            }
        }

        protected void btnClearItem_Click(object sender, EventArgs e)
        {
            ClearItemForm();
            if (!string.IsNullOrEmpty(hdnTableName.Value))
            {
                int nextId = DatabaseHelper.GetNextMetadataId(hdnTableName.Value);
                txtItemID.Text = nextId.ToString();
            }
        }

        protected void gvMetadataItems_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                string tableName = hdnTableName.Value;
                string valueColumn = hdnValueColumn.Value;

                switch (e.CommandName)
                {
                    case "EditItem":
                        string[] args = e.CommandArgument.ToString().Split('|');
                        int editId = Convert.ToInt32(args[0]);
                        string editValue = args.Length > 1 ? args[1] : "";

                        hdnItemID.Value = editId.ToString();
                        txtItemID.Text = editId.ToString();
                        txtItemID.Enabled = false;
                        txtItemValue.Text = editValue;
                        lblEditTitle.Text = "Edit Item (ID: " + editId + ")";
                        break;

                    case "ActivateItem":
                        int activateId = Convert.ToInt32(e.CommandArgument);
                        DatabaseHelper.ToggleMetadataItemStatus(tableName, activateId, true);
                        ShowMessage("Item activated.", false);
                        BindMetadataGrid(tableName, valueColumn);
                        break;

                    case "DeactivateItem":
                        int deactivateId = Convert.ToInt32(e.CommandArgument);
                        DatabaseHelper.ToggleMetadataItemStatus(tableName, deactivateId, false);
                        ShowMessage("Item deactivated.", false);
                        BindMetadataGrid(tableName, valueColumn);
                        break;

                    case "DeleteItem":
                        int deleteId = Convert.ToInt32(e.CommandArgument);
                        // Check if item is in use before deleting
                        if (DatabaseHelper.IsMetadataItemInUse(tableName, deleteId))
                        {
                            ShowMessage("Cannot delete this item - it is referenced by existing Demand Fund entries. Deactivate it instead.", true);
                        }
                        else
                        {
                            DatabaseHelper.DeleteMetadataItem(tableName, deleteId);
                            ShowMessage("Item deleted permanently.", false);
                            BindMetadataGrid(tableName, valueColumn);
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                ShowMessage("Error: " + ex.Message, true);
            }
        }

        private void ClearItemForm()
        {
            hdnItemID.Value = "0";
            txtItemID.Text = "";
            txtItemID.Enabled = true;
            txtItemValue.Text = "";
            lblEditTitle.Text = "Add New Item";
        }

        protected void gvMetadataItems_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvMetadataItems.PageIndex = e.NewPageIndex;
            string tableName = hdnTableName.Value;
            string valueColumn = hdnValueColumn.Value;
            if (!string.IsNullOrEmpty(tableName) && !string.IsNullOrEmpty(valueColumn))
            {
                BindMetadataGrid(tableName, valueColumn);
            }
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
