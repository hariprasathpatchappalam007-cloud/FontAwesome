<%@ Page Title="User Management" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="UserManagement.aspx.cs" Inherits="DemandFundManagement.Admin.UserManagement" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title"><span class="glyphicon glyphicon-user"></span> User Management</h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <!-- User Form Panel -->
    <div class="panel">
        <div class="panel-header">
            <span class="glyphicon glyphicon-plus-sign"></span> <asp:Label ID="lblFormTitle" runat="server" Text="Create New User" />
        </div>
        <div class="panel-body">
            <asp:HiddenField ID="hdnUserID" runat="server" Value="0" />

            <div class="form-row">
                <div class="form-col-3 form-group">
                    <label>Username <span style="color:red">*</span></label>
                    <asp:TextBox ID="txtUsername" runat="server" CssClass="form-control" MaxLength="100" />
                    <asp:RequiredFieldValidator ID="rfvUsername" runat="server" ControlToValidate="txtUsername"
                        ErrorMessage="Username is required" Display="Dynamic" ForeColor="Red" Font-Size="12px"
                        ValidationGroup="UserForm" />
                </div>
                <div class="form-col-3 form-group">
                    <label>Full Name <span style="color:red">*</span></label>
                    <asp:TextBox ID="txtFullName" runat="server" CssClass="form-control" MaxLength="200" />
                    <asp:RequiredFieldValidator ID="rfvFullName" runat="server" ControlToValidate="txtFullName"
                        ErrorMessage="Full Name is required" Display="Dynamic" ForeColor="Red" Font-Size="12px"
                        ValidationGroup="UserForm" />
                </div>
                <div class="form-col-3 form-group">
                    <label>Email</label>
                    <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" MaxLength="200" />
                    <asp:RegularExpressionValidator ID="revEmail" runat="server" ControlToValidate="txtEmail"
                        ErrorMessage="Invalid email format" Display="Dynamic" ForeColor="Red" Font-Size="12px"
                        ValidationExpression="^[\w\.-]+@[\w\.-]+\.\w+$" ValidationGroup="UserForm" />
                </div>
            </div>

            <div class="form-row">
                <div class="form-col-3 form-group">
                    <label>
                        <asp:Label ID="lblPasswordLabel" runat="server" Text="Password" />
                        <asp:Label ID="lblPasswordRequired" runat="server" Text=" *" ForeColor="Red" />
                    </label>
                    <asp:TextBox ID="txtPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="100" />
                    <asp:RequiredFieldValidator ID="rfvPassword" runat="server" ControlToValidate="txtPassword"
                        ErrorMessage="Password is required" Display="Dynamic" ForeColor="Red" Font-Size="12px"
                        ValidationGroup="UserForm" />
                </div>
                <div class="form-col-3 form-group">
                    <label>Role <span style="color:red">*</span></label>
                    <asp:DropDownList ID="ddlRole" runat="server" CssClass="form-control" />
                </div>
            </div>

            <div class="btn-group">
                <asp:LinkButton ID="btnSaveUser" runat="server" CssClass="btn btn-primary" OnClick="btnSaveUser_Click" ValidationGroup="UserForm">
                    <span class="glyphicon glyphicon-floppy-disk"></span> Save User
                </asp:LinkButton>
                <asp:LinkButton ID="btnClearForm" runat="server" CssClass="btn btn-secondary" OnClick="btnClearForm_Click" CausesValidation="false">
                    <span class="glyphicon glyphicon-remove"></span> Clear
                </asp:LinkButton>
            </div>
        </div>
    </div>

    <!-- User List -->
    <div class="panel">
        <div class="panel-header"><span class="glyphicon glyphicon-list"></span> All Users</div>
        <div class="panel-body" style="overflow-x:auto;">
            <asp:GridView ID="gvUsers" runat="server" AutoGenerateColumns="false"
                CssClass="grid-view" EmptyDataText="No users found."
                OnRowCommand="gvUsers_RowCommand" DataKeyNames="UserID">
                <Columns>
                    <asp:BoundField DataField="UserID" HeaderText="ID" ItemStyle-Width="50px" />
                    <asp:BoundField DataField="Username" HeaderText="Username" />
                    <asp:BoundField DataField="FullName" HeaderText="Full Name" />
                    <asp:BoundField DataField="Email" HeaderText="Email" />
                    <asp:BoundField DataField="RoleName" HeaderText="Role" />
                    <asp:TemplateField HeaderText="Status">
                        <ItemTemplate>
                            <span class='<%# Convert.ToBoolean(Eval("IsEnabled")) ? "badge badge-active" : "badge badge-inactive" %>'>
                                <%# Convert.ToBoolean(Eval("IsEnabled")) ? "Enabled" : "Disabled" %>
                            </span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="CreatedDate" HeaderText="Created" DataFormatString="{0:dd-MMM-yyyy}" />
                    <asp:BoundField DataField="LastLoginDate" HeaderText="Last Login" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                    <asp:TemplateField HeaderText="Actions" ItemStyle-Width="280px">
                        <ItemStyle Wrap="false" />
                        <ItemTemplate>
                            <div style="display:flex;gap:4px;flex-wrap:nowrap;">
                                <asp:LinkButton ID="btnEdit" runat="server" CommandName="EditUser" 
                                    CommandArgument='<%# Eval("UserID") %>' CssClass="btn btn-sm btn-primary"
                                    CausesValidation="false"><span class="glyphicon glyphicon-pencil"></span> Edit</asp:LinkButton>
                                <asp:LinkButton ID="btnToggle" runat="server" 
                                    CommandName='<%# Convert.ToBoolean(Eval("IsEnabled")) ? "DisableUser" : "EnableUser" %>'
                                    CommandArgument='<%# Eval("UserID") %>'
                                    CssClass='<%# Convert.ToBoolean(Eval("IsEnabled")) ? "btn btn-sm btn-danger" : "btn btn-sm btn-success" %>'
                                    CausesValidation="false"
                                    OnClientClick="return confirm('Are you sure you want to change this user\'s status?');">
                                    <span class='<%# Convert.ToBoolean(Eval("IsEnabled")) ? "glyphicon glyphicon-ban-circle" : "glyphicon glyphicon-ok-circle" %>'></span>
                                    <%# Convert.ToBoolean(Eval("IsEnabled")) ? "Disable" : "Enable" %>
                                </asp:LinkButton>
                                <asp:LinkButton ID="btnResetPwd" runat="server" CommandName="ResetPassword"
                                    CommandArgument='<%# Eval("UserID") %>' CssClass="btn btn-sm btn-warning"
                                    CausesValidation="false"
                                    OnClientClick="return confirm('Reset password to Admin@123?');"><span class="glyphicon glyphicon-refresh"></span> Reset</asp:LinkButton>
                            </div>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
