namespace DemandFundManagement.Admin
{
    public partial class MetadataManagement
    {
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.HiddenField hdnConfigId;
        protected global::System.Web.UI.WebControls.Panel pnlSelectPrompt;
        protected global::System.Web.UI.WebControls.Panel pnlEditItem;
        protected global::System.Web.UI.WebControls.Label lblEditTitle;
        protected global::System.Web.UI.WebControls.HiddenField hdnItemID;
        protected global::System.Web.UI.WebControls.HiddenField hdnTableName;
        protected global::System.Web.UI.WebControls.HiddenField hdnValueColumn;
        protected global::System.Web.UI.WebControls.TextBox txtItemID;
        protected global::System.Web.UI.WebControls.Label lblValueColumnName;
        protected global::System.Web.UI.WebControls.TextBox txtItemValue;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvValue;
        protected global::System.Web.UI.WebControls.LinkButton btnSaveItem;
        protected global::System.Web.UI.WebControls.LinkButton btnClearItem;
        protected global::System.Web.UI.WebControls.Panel pnlGrid;
        protected global::System.Web.UI.WebControls.Label lblGridTitle;
        protected global::System.Web.UI.WebControls.GridView gvMetadataItems;
    }
}
