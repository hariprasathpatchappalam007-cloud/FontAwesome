namespace DemandFundManagement.Admin
{
    public partial class UserManagement
    {
        protected global::System.Web.UI.WebControls.Panel pnlMessage;
        protected global::System.Web.UI.WebControls.Label lblMessage;
        protected global::System.Web.UI.WebControls.Label lblFormTitle;
        protected global::System.Web.UI.WebControls.HiddenField hdnUserID;
        protected global::System.Web.UI.WebControls.TextBox txtUsername;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvUsername;
        protected global::System.Web.UI.WebControls.TextBox txtFullName;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvFullName;
        protected global::System.Web.UI.WebControls.TextBox txtEmail;
        protected global::System.Web.UI.WebControls.RegularExpressionValidator revEmail;
        protected global::System.Web.UI.WebControls.Label lblPasswordLabel;
        protected global::System.Web.UI.WebControls.Label lblPasswordRequired;
        protected global::System.Web.UI.WebControls.TextBox txtPassword;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvPassword;
        protected global::System.Web.UI.WebControls.DropDownList ddlRole;
        protected global::System.Web.UI.WebControls.LinkButton btnSaveUser;
        protected global::System.Web.UI.WebControls.LinkButton btnClearForm;
        protected global::System.Web.UI.WebControls.GridView gvUsers;
    }
}
