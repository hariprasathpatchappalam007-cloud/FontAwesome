using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using DemandFundManagement.App_Code.DAL;
using DemandFundManagement.App_Code.Security;

namespace DemandFundManagement.Admin
{
    public partial class UserManagement : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Admin only
            if (Session["RoleID"] == null || Convert.ToInt32(Session["RoleID"]) != 1)
            {
                Response.Redirect("~/Default.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadRoles();
                BindUserGrid();
            }
        }

        private void LoadRoles()
        {
            DataTable dt = DatabaseHelper.GetUserRoles();
            ddlRole.DataSource = dt;
            ddlRole.DataTextField = "RoleName";
            ddlRole.DataValueField = "RoleID";
            ddlRole.DataBind();
        }

        private void BindUserGrid()
        {
            DataTable dt = DatabaseHelper.GetAllUsers();
            gvUsers.DataSource = dt;
            gvUsers.DataBind();
        }

        protected void btnSaveUser_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid)
                return;

            try
            {
                string username = txtUsername.Text.Trim();
                string fullName = txtFullName.Text.Trim();
                string email = txtEmail.Text.Trim();
                int roleId = Convert.ToInt32(ddlRole.SelectedValue);
                string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "admin";

                int userId = 0;
                int.TryParse(hdnUserID.Value, out userId);

                if (userId > 0)
                {
                    // Update existing user
                    if (DatabaseHelper.UsernameExists(username, userId))
                    {
                        ShowMessage("Username already exists.", true);
                        return;
                    }

                    DatabaseHelper.UpdateUser(userId, fullName, email, roleId, currentUser);

                    // Update password if provided
                    if (!string.IsNullOrEmpty(txtPassword.Text))
                    {
                        string salt = PasswordHelper.GenerateSalt();
                        string hash = PasswordHelper.HashPassword(txtPassword.Text, salt);
                        DatabaseHelper.ResetUserPassword(userId, hash, salt, currentUser);
                    }

                    ShowMessage("User updated successfully.", false);
                }
                else
                {
                    // Create new user
                    if (string.IsNullOrEmpty(txtPassword.Text))
                    {
                        ShowMessage("Password is required for new users.", true);
                        return;
                    }

                    if (DatabaseHelper.UsernameExists(username))
                    {
                        ShowMessage("Username already exists.", true);
                        return;
                    }

                    string salt = PasswordHelper.GenerateSalt();
                    string hash = PasswordHelper.HashPassword(txtPassword.Text, salt);
                    DatabaseHelper.CreateUser(username, hash, salt, fullName, email, roleId, currentUser);

                    ShowMessage("User created successfully.", false);
                }

                ClearForm();
                BindUserGrid();
            }
            catch (Exception ex)
            {
                ShowMessage("Error: " + ex.Message, true);
            }
        }

        protected void btnClearForm_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        protected void gvUsers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int userId = Convert.ToInt32(e.CommandArgument);
            string currentUser = Session["Username"] != null ? Session["Username"].ToString() : "admin";

            try
            {
                switch (e.CommandName)
                {
                    case "EditUser":
                        LoadUserForEdit(userId);
                        break;

                    case "EnableUser":
                        DatabaseHelper.ToggleUserStatus(userId, true, currentUser);
                        ShowMessage("User enabled successfully.", false);
                        BindUserGrid();
                        break;

                    case "DisableUser":
                        // Don't allow disabling own account
                        if (Session["UserID"] != null && Convert.ToInt32(Session["UserID"]) == userId)
                        {
                            ShowMessage("You cannot disable your own account.", true);
                            return;
                        }
                        DatabaseHelper.ToggleUserStatus(userId, false, currentUser);
                        ShowMessage("User disabled successfully.", false);
                        BindUserGrid();
                        break;

                    case "ResetPassword":
                        string salt = PasswordHelper.GenerateSalt();
                        string hash = PasswordHelper.HashPassword("Admin@123", salt);
                        DatabaseHelper.ResetUserPassword(userId, hash, salt, currentUser);
                        ShowMessage("Password reset to default (Admin@123).", false);
                        break;
                }
            }
            catch (Exception ex)
            {
                ShowMessage("Error: " + ex.Message, true);
            }
        }

        private void LoadUserForEdit(int userId)
        {
            DataRow user = DatabaseHelper.GetUserById(userId);
            if (user != null)
            {
                hdnUserID.Value = userId.ToString();
                txtUsername.Text = user["Username"].ToString();
                txtFullName.Text = user["FullName"].ToString();
                txtEmail.Text = user["Email"] != DBNull.Value ? user["Email"].ToString() : "";
                ddlRole.SelectedValue = user["RoleID"].ToString();

                lblFormTitle.Text = "Edit User: " + user["Username"].ToString();
                lblPasswordLabel.Text = "Password (leave blank to keep current)";
                lblPasswordRequired.Visible = false;
                rfvPassword.Enabled = false;
            }
        }

        private void ClearForm()
        {
            hdnUserID.Value = "0";
            txtUsername.Text = "";
            txtFullName.Text = "";
            txtEmail.Text = "";
            txtPassword.Attributes["value"] = "";
            if (ddlRole.Items.Count > 0)
                ddlRole.SelectedIndex = 0;

            lblFormTitle.Text = "Create New User";
            lblPasswordLabel.Text = "Password";
            lblPasswordRequired.Visible = true;
            rfvPassword.Enabled = true;
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
