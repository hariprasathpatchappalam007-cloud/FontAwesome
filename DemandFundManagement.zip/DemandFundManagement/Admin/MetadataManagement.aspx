<%@ Page Title="Metadata Management" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="MetadataManagement.aspx.cs" Inherits="DemandFundManagement.Admin.MetadataManagement" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title"><span class="glyphicon glyphicon-cog"></span> Metadata Configuration</h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <asp:HiddenField ID="hdnConfigId" runat="server" Value="0" />

    <!-- Prompt when no table is selected -->
    <asp:Panel ID="pnlSelectPrompt" runat="server" Visible="true">
        <div class="panel">
            <div class="panel-body">
                <div class="metadata-select-prompt">
                    <span class="glyphicon glyphicon-th-list"></span>
                    <h3>Select a Metadata Table</h3>
                    <p>Choose a metadata table from the <strong>Metadata Config</strong> tree in the left navigation panel.</p>
                </div>
            </div>
        </div>
    </asp:Panel>

    <!-- Add/Edit Item -->
    <asp:Panel ID="pnlEditItem" runat="server" Visible="false">
        <div class="panel">
            <div class="panel-header">
                <span class="glyphicon glyphicon-plus-sign"></span> <asp:Label ID="lblEditTitle" runat="server" Text="Add New Item" />
            </div>
            <div class="panel-body">
                <asp:HiddenField ID="hdnItemID" runat="server" Value="0" />
                <asp:HiddenField ID="hdnTableName" runat="server" />
                <asp:HiddenField ID="hdnValueColumn" runat="server" />

                <div class="form-row">
                    <div class="form-col-3 form-group">
                        <label>ID</label>
                        <asp:TextBox ID="txtItemID" runat="server" CssClass="form-control" />
                    </div>
                    <div class="form-col-3 form-group">
                        <label>
                            <asp:Label ID="lblValueColumnName" runat="server" Text="Value" />
                            <span style="color:red">*</span>
                        </label>
                        <asp:TextBox ID="txtItemValue" runat="server" CssClass="form-control" MaxLength="200" />
                        <asp:RequiredFieldValidator ID="rfvValue" runat="server" ControlToValidate="txtItemValue"
                            ErrorMessage="Value is required" Display="Dynamic" ForeColor="Red" Font-Size="12px"
                            ValidationGroup="MetaForm" />
                    </div>
                </div>

                <div class="btn-group">
                    <asp:LinkButton ID="btnSaveItem" runat="server" CssClass="btn btn-primary" OnClick="btnSaveItem_Click" ValidationGroup="MetaForm">
                        <span class="glyphicon glyphicon-floppy-disk"></span> Save
                    </asp:LinkButton>
                    <asp:LinkButton ID="btnClearItem" runat="server" CssClass="btn btn-secondary" OnClick="btnClearItem_Click" CausesValidation="false">
                        <span class="glyphicon glyphicon-remove"></span> Clear
                    </asp:LinkButton>
                </div>
            </div>
        </div>
    </asp:Panel>

    <!-- Metadata Items Grid -->
    <asp:Panel ID="pnlGrid" runat="server" Visible="false">
        <div class="panel">
            <div class="panel-header">
                <span class="glyphicon glyphicon-th-list"></span> <asp:Label ID="lblGridTitle" runat="server" Text="Items" />
            </div>
            <div class="panel-body" style="overflow-x:auto;">
                <asp:GridView ID="gvMetadataItems" runat="server" AutoGenerateColumns="false"
                    CssClass="grid-view" EmptyDataText="No items found."
                    AllowPaging="true" PageSize="10" OnPageIndexChanging="gvMetadataItems_PageIndexChanging"
                    OnRowCommand="gvMetadataItems_RowCommand" DataKeyNames="ID">
                    <PagerStyle CssClass="grid-pager" />
                    <Columns>
                        <asp:BoundField DataField="ID" HeaderText="ID" ItemStyle-Width="60px" />
                        <asp:BoundField DataField="ValueText" HeaderText="Value" />
                        <asp:TemplateField HeaderText="Status" ItemStyle-Width="100px">
                            <ItemTemplate>
                                <span class='<%# Convert.ToBoolean(Eval("IsActive")) ? "badge badge-active" : "badge badge-inactive" %>'>
                                    <%# Convert.ToBoolean(Eval("IsActive")) ? "Active" : "Inactive" %>
                                </span>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Actions" ItemStyle-Width="280px" ItemStyle-CssClass="action-buttons-cell">
                            <ItemStyle Wrap="false" />
                            <ItemTemplate>
                                <div style="display:flex;gap:4px;flex-wrap:nowrap;">
                                    <asp:LinkButton ID="btnEditItem" runat="server" CommandName="EditItem"
                                        CommandArgument='<%# Eval("ID") + "|" + Eval("ValueText") %>'
                                        CssClass="btn btn-sm btn-primary" CausesValidation="false"><span class="glyphicon glyphicon-pencil"></span> Edit</asp:LinkButton>
                                    <asp:LinkButton ID="btnToggleItem" runat="server"
                                        CommandName='<%# Convert.ToBoolean(Eval("IsActive")) ? "DeactivateItem" : "ActivateItem" %>'
                                        CommandArgument='<%# Eval("ID") %>'
                                        CssClass='<%# Convert.ToBoolean(Eval("IsActive")) ? "btn btn-sm btn-warning" : "btn btn-sm btn-success" %>'
                                        CausesValidation="false"><span class='<%# Convert.ToBoolean(Eval("IsActive")) ? "glyphicon glyphicon-ban-circle" : "glyphicon glyphicon-ok-circle" %>'></span> <%# Convert.ToBoolean(Eval("IsActive")) ? "Deactivate" : "Activate" %></asp:LinkButton>
                                    <asp:LinkButton ID="btnDeleteItem" runat="server" CommandName="DeleteItem"
                                        CommandArgument='<%# Eval("ID") %>'
                                        CssClass="btn btn-sm btn-danger" CausesValidation="false"
                                        OnClientClick="return confirm('Are you sure you want to permanently delete this item?');"><span class="glyphicon glyphicon-trash"></span> Delete</asp:LinkButton>
                                </div>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </asp:Panel>
</asp:Content>
