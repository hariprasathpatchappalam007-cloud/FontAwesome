<%@ Page Title="Change Password" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="ChangePassword.aspx.cs" Inherits="DemandFundManagement.ChangePassword" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title"><span class="glyphicon glyphicon-lock"></span> Change Password</h2>

    <asp:Panel ID="pnlMessage" runat="server" Visible="false">
        <asp:Label ID="lblMessage" runat="server" />
    </asp:Panel>

    <div class="panel" style="max-width:500px;">
        <div class="panel-header"><span class="glyphicon glyphicon-lock"></span> Update Your Password</div>
        <div class="panel-body">
            <div class="form-group">
                <label>Current Password <span style="color:red">*</span></label>
                <asp:TextBox ID="txtCurrentPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="100" />
                <asp:RequiredFieldValidator ID="rfvCurrent" runat="server" ControlToValidate="txtCurrentPassword"
                    ErrorMessage="Current password is required" Display="Dynamic" ForeColor="Red" Font-Size="12px"
                    ValidationGroup="ChangePwd" />
            </div>
            <div class="form-group">
                <label>New Password <span style="color:red">*</span></label>
                <asp:TextBox ID="txtNewPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="100" />
                <asp:RequiredFieldValidator ID="rfvNew" runat="server" ControlToValidate="txtNewPassword"
                    ErrorMessage="New password is required" Display="Dynamic" ForeColor="Red" Font-Size="12px"
                    ValidationGroup="ChangePwd" />
            </div>
            <div class="form-group">
                <label>Confirm New Password <span style="color:red">*</span></label>
                <asp:TextBox ID="txtConfirmPassword" runat="server" CssClass="form-control" TextMode="Password" MaxLength="100" />
                <asp:CompareValidator ID="cvConfirm" runat="server" ControlToValidate="txtConfirmPassword"
                    ControlToCompare="txtNewPassword" ErrorMessage="Passwords do not match"
                    Display="Dynamic" ForeColor="Red" Font-Size="12px" ValidationGroup="ChangePwd" />
            </div>
            <div class="btn-group">
                <asp:LinkButton ID="btnChangePassword" runat="server" CssClass="btn btn-primary" OnClick="btnChangePassword_Click" ValidationGroup="ChangePwd">
                    <span class="glyphicon glyphicon-floppy-disk"></span> Change Password
                </asp:LinkButton>
            </div>
        </div>
    </div>
</asp:Content>
