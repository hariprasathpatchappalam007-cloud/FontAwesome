using System;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using DemandFundManagement.App_Code.DAL;

namespace DemandFundManagement
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    // Check if app was restarted (stale auth cookie from previous instance)
                    bool sessionStale = Session["UserID"] == null ||
                        Session["AppToken"] == null ||
                        Session["AppToken"].ToString() != Global.AppStartToken;

                    if (sessionStale)
                    {
                        if (!RestoreSession(HttpContext.Current.User.Identity.Name))
                        {
                            // Could not restore session — force re-login
                            Session.Clear();
                            Session.Abandon();
                            FormsAuthentication.SignOut();
                            Response.Redirect("~/Login.aspx", false);
                            HttpContext.Current.ApplicationInstance.CompleteRequest();
                            return;
                        }
                        Session["AppToken"] = Global.AppStartToken;
                    }

                    lblUserName.Text = Session["FullName"] != null ? Session["FullName"].ToString() : HttpContext.Current.User.Identity.Name;
                    lblUserRole.Text = Session["RoleName"] != null ? Session["RoleName"].ToString() : "User";

                    // Show admin menu only for Admin role
                    if (Session["RoleID"] != null && Convert.ToInt32(Session["RoleID"]) == 1)
                    {
                        pnlAdminMenu.Visible = true;
                        LoadMetadataTree();
                    }

                    // Load global notifications
                    LoadGlobalNotifications();
                }
            }
        }

        private bool RestoreSession(string username)
        {
            try
            {
                DataRow user = DatabaseHelper.AuthenticateUser(username);
                if (user == null || !Convert.ToBoolean(user["IsEnabled"]))
                    return false;

                Session["UserID"] = Convert.ToInt32(user["UserID"]);
                Session["Username"] = user["Username"].ToString();
                Session["FullName"] = user["FullName"].ToString();
                Session["RoleID"] = Convert.ToInt32(user["RoleID"]);
                Session["RoleName"] = user["RoleName"].ToString();
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void LoadMetadataTree()
        {
            try
            {
                DataTable dt = DatabaseHelper.GetMetadataConfig();
                rptMetadataTree.DataSource = dt;
                rptMetadataTree.DataBind();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("LoadMetadataTree Error: " + ex.Message);
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            Response.Redirect("~/Login.aspx");
        }

        private void LoadGlobalNotifications()
        {
            try
            {
                if (Session["UserID"] == null) return;
                int userId = Convert.ToInt32(Session["UserID"]);

                int unread = DatabaseHelper.GetUnreadNotificationCount(userId);
                if (unread > 0)
                {
                    lblGlobalNotifCount.Text = unread.ToString();
                    lblGlobalNotifCount.Visible = true;
                }

                DataTable notifs = DatabaseHelper.GetGlobalNotifications(userId, 15);
                if (notifs.Rows.Count > 0)
                {
                    rptGlobalNotifs.DataSource = notifs;
                    rptGlobalNotifs.DataBind();
                    pnlNoGlobalNotifs.Visible = false;
                }
                else
                {
                    pnlNoGlobalNotifs.Visible = true;
                }
            }
            catch { /* tables may not exist yet */ }
        }

        protected string GetGlobalNotifIcon(string notifType)
        {
            switch (notifType)
            {
                case "Assignment": return "glyphicon-user";
                case "Approval": return "glyphicon-check";
                case "StatusChange": return "glyphicon-transfer";
                default: return "glyphicon-info-sign";
            }
        }

        protected string GetNotifLink(object stepNodeType, object taskId)
        {
            string nodeType = stepNodeType != null && stepNodeType != System.DBNull.Value ? stepNodeType.ToString() : "";
            string tid = taskId != null && taskId != System.DBNull.Value ? taskId.ToString() : "";
            if (nodeType == "approval")
                return ResolveUrl("~/Forms/MyApprovals.aspx") + (tid != "" ? "?taskId=" + tid : "");
            if (nodeType == "user-task")
                return ResolveUrl("~/Forms/MyTasks.aspx") + (tid != "" ? "?taskId=" + tid : "");
            return ResolveUrl("~/Forms/WorkflowBoard.aspx");
        }
    }
}
