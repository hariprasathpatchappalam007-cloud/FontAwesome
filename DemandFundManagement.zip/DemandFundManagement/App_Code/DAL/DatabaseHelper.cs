using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DemandFundManagement.App_Code.DAL
{
    public static class DatabaseHelper
    {
        private static string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["DFMConnection"].ConnectionString; }
        }

        #region Core Database Methods

        public static DataTable ExecuteQuery(string query, params SqlParameter[] parameters)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.CommandTimeout = 30;
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        public static int ExecuteNonQuery(string query, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.CommandTimeout = 30;
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    conn.Open();
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        public static object ExecuteScalar(string query, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.CommandTimeout = 30;
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    conn.Open();
                    return cmd.ExecuteScalar();
                }
            }
        }

        #endregion

        #region User Authentication

        public static DataRow AuthenticateUser(string username)
        {
            string query = @"SELECT u.UserID, u.Username, u.PasswordHash, u.PasswordSalt, 
                            u.FullName, u.Email, u.RoleID, r.RoleName, u.IsEnabled
                            FROM AppUsers u 
                            INNER JOIN UserRoles r ON u.RoleID = r.RoleID
                            WHERE u.Username = @Username";
            DataTable dt = ExecuteQuery(query, new SqlParameter("@Username", username));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static void UpdateLastLogin(int userId)
        {
            string query = "UPDATE AppUsers SET LastLoginDate = GETDATE() WHERE UserID = @UserID";
            ExecuteNonQuery(query, new SqlParameter("@UserID", userId));
        }

        #endregion

        #region User Management

        public static DataTable GetAllUsers()
        {
            string query = @"SELECT u.UserID, u.Username, u.FullName, u.Email, 
                            r.RoleName, u.IsEnabled, u.CreatedDate, u.LastLoginDate
                            FROM AppUsers u 
                            INNER JOIN UserRoles r ON u.RoleID = r.RoleID
                            ORDER BY u.FullName";
            return ExecuteQuery(query);
        }

        public static DataRow GetUserById(int userId)
        {
            string query = @"SELECT * FROM AppUsers WHERE UserID = @UserID";
            DataTable dt = ExecuteQuery(query, new SqlParameter("@UserID", userId));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static bool UsernameExists(string username, int excludeUserId = 0)
        {
            string query = "SELECT COUNT(*) FROM AppUsers WHERE Username = @Username AND UserID <> @ExcludeID";
            object result = ExecuteScalar(query,
                new SqlParameter("@Username", username),
                new SqlParameter("@ExcludeID", excludeUserId));
            return Convert.ToInt32(result) > 0;
        }

        public static int CreateUser(string username, string passwordHash, string passwordSalt,
            string fullName, string email, int roleId, string createdBy)
        {
            string query = @"INSERT INTO AppUsers (Username, PasswordHash, PasswordSalt, FullName, Email, RoleID, IsEnabled, CreatedBy)
                            VALUES (@Username, @PasswordHash, @PasswordSalt, @FullName, @Email, @RoleID, 1, @CreatedBy);
                            SELECT SCOPE_IDENTITY();";
            object result = ExecuteScalar(query,
                new SqlParameter("@Username", username),
                new SqlParameter("@PasswordHash", passwordHash),
                new SqlParameter("@PasswordSalt", passwordSalt),
                new SqlParameter("@FullName", fullName),
                new SqlParameter("@Email", (object)email ?? DBNull.Value),
                new SqlParameter("@RoleID", roleId),
                new SqlParameter("@CreatedBy", createdBy));
            return Convert.ToInt32(result);
        }

        public static void UpdateUser(int userId, string fullName, string email, int roleId, string modifiedBy)
        {
            string query = @"UPDATE AppUsers SET FullName = @FullName, Email = @Email, 
                            RoleID = @RoleID, ModifiedDate = GETDATE(), ModifiedBy = @ModifiedBy
                            WHERE UserID = @UserID";
            ExecuteNonQuery(query,
                new SqlParameter("@UserID", userId),
                new SqlParameter("@FullName", fullName),
                new SqlParameter("@Email", (object)email ?? DBNull.Value),
                new SqlParameter("@RoleID", roleId),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static void ResetUserPassword(int userId, string passwordHash, string passwordSalt, string modifiedBy)
        {
            string query = @"UPDATE AppUsers SET PasswordHash = @PasswordHash, PasswordSalt = @PasswordSalt,
                            ModifiedDate = GETDATE(), ModifiedBy = @ModifiedBy
                            WHERE UserID = @UserID";
            ExecuteNonQuery(query,
                new SqlParameter("@UserID", userId),
                new SqlParameter("@PasswordHash", passwordHash),
                new SqlParameter("@PasswordSalt", passwordSalt),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static void ToggleUserStatus(int userId, bool isEnabled, string modifiedBy)
        {
            string query = @"UPDATE AppUsers SET IsEnabled = @IsEnabled, ModifiedDate = GETDATE(), 
                            ModifiedBy = @ModifiedBy WHERE UserID = @UserID";
            ExecuteNonQuery(query,
                new SqlParameter("@UserID", userId),
                new SqlParameter("@IsEnabled", isEnabled),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static DataTable GetUserRoles()
        {
            return ExecuteQuery("SELECT RoleID, RoleName FROM UserRoles WHERE IsActive = 1 ORDER BY RoleID");
        }

        #endregion

        #region Demand Fund CRUD

        public static int InsertDemandFund(string initiativeTitle, string description, int? demandTypeId,
            bool damoApproved, int? engineeringLeadId, int? fundingSourceId,
            int? fundsApprovedById, int? capexOpexId, int? glCodeId, int? phaseDescriptionId,
            string primaryBusinessOwner, string remarks, int? businessVerticalId,
            bool digitalProject, string deliveryManager, int? initiativeTypeId, int? platformOwnerId,
            int? portfolioHeadId, int? technologyVerticalId, int? initiativeSizeId, int? projectTypeId,
            string doc1FileName, string doc1Path, string addDocFileName, string addDocPath, string createdBy)
        {
            string query = @"INSERT INTO DemandFund 
                (InitiativeTitle, Description, Demand_TypeID, DAMO_Approved,
                 Engineering_LeadID, Funding_SourceID, Funds_Approved_ByID, CAPEX_OPEX_ID, GL_CodeID,
                 Phase_DescriptionID, Primary_Business_Owner, Remarks, Business_VerticalID,
                 Digital_Project, Delivery_Manager, Initiative_TypeID, Platform_OwnerID, Portfolio_HeadID,
                 Technology_VerticalID, Initiative_SizeID, Project_TypeID,
                 Document1_FileName, Document1_Path, AdditionalDoc_FileName, AdditionalDoc_Path, CreatedBy)
                VALUES 
                (@InitiativeTitle, @Description, @Demand_TypeID, @DAMO_Approved,
                 @Engineering_LeadID, @Funding_SourceID, @Funds_Approved_ByID, @CAPEX_OPEX_ID, @GL_CodeID,
                 @Phase_DescriptionID, @Primary_Business_Owner, @Remarks, @Business_VerticalID,
                 @Digital_Project, @Delivery_Manager, @Initiative_TypeID, @Platform_OwnerID, @Portfolio_HeadID,
                 @Technology_VerticalID, @Initiative_SizeID, @Project_TypeID,
                 @Doc1FileName, @Doc1Path, @AddDocFileName, @AddDocPath, @CreatedBy);
                SELECT SCOPE_IDENTITY();";

            object result = ExecuteScalar(query,
                new SqlParameter("@InitiativeTitle", (object)initiativeTitle ?? DBNull.Value),
                new SqlParameter("@Description", (object)description ?? DBNull.Value),
                new SqlParameter("@Demand_TypeID", (object)demandTypeId ?? DBNull.Value),
                new SqlParameter("@DAMO_Approved", damoApproved),
                new SqlParameter("@Engineering_LeadID", (object)engineeringLeadId ?? DBNull.Value),
                new SqlParameter("@Funding_SourceID", (object)fundingSourceId ?? DBNull.Value),
                new SqlParameter("@Funds_Approved_ByID", (object)fundsApprovedById ?? DBNull.Value),
                new SqlParameter("@CAPEX_OPEX_ID", (object)capexOpexId ?? DBNull.Value),
                new SqlParameter("@GL_CodeID", (object)glCodeId ?? DBNull.Value),
                new SqlParameter("@Phase_DescriptionID", (object)phaseDescriptionId ?? DBNull.Value),
                new SqlParameter("@Primary_Business_Owner", (object)primaryBusinessOwner ?? DBNull.Value),
                new SqlParameter("@Remarks", (object)remarks ?? DBNull.Value),
                new SqlParameter("@Business_VerticalID", (object)businessVerticalId ?? DBNull.Value),
                new SqlParameter("@Digital_Project", digitalProject),
                new SqlParameter("@Delivery_Manager", (object)deliveryManager ?? DBNull.Value),
                new SqlParameter("@Initiative_TypeID", (object)initiativeTypeId ?? DBNull.Value),
                new SqlParameter("@Platform_OwnerID", (object)platformOwnerId ?? DBNull.Value),
                new SqlParameter("@Portfolio_HeadID", (object)portfolioHeadId ?? DBNull.Value),
                new SqlParameter("@Technology_VerticalID", (object)technologyVerticalId ?? DBNull.Value),
                new SqlParameter("@Initiative_SizeID", (object)initiativeSizeId ?? DBNull.Value),
                new SqlParameter("@Project_TypeID", (object)projectTypeId ?? DBNull.Value),
                new SqlParameter("@Doc1FileName", (object)doc1FileName ?? DBNull.Value),
                new SqlParameter("@Doc1Path", (object)doc1Path ?? DBNull.Value),
                new SqlParameter("@AddDocFileName", (object)addDocFileName ?? DBNull.Value),
                new SqlParameter("@AddDocPath", (object)addDocPath ?? DBNull.Value),
                new SqlParameter("@CreatedBy", (object)createdBy ?? DBNull.Value));

            return Convert.ToInt32(result);
        }

        public static void UpdateDemandFund(int id, string initiativeTitle, string description, int? demandTypeId,
            bool damoApproved, int? engineeringLeadId, int? fundingSourceId,
            int? fundsApprovedById, int? capexOpexId, int? glCodeId, int? phaseDescriptionId,
            string primaryBusinessOwner, string remarks, int? businessVerticalId,
            bool digitalProject, string deliveryManager, int? initiativeTypeId, int? platformOwnerId,
            int? portfolioHeadId, int? technologyVerticalId, int? initiativeSizeId, int? projectTypeId,
            string doc1FileName, string doc1Path, string addDocFileName, string addDocPath, string modifiedBy)
        {
            string query = @"UPDATE DemandFund SET
                InitiativeTitle = @InitiativeTitle, Description = @Description, 
                Demand_TypeID = @Demand_TypeID, DAMO_Approved = @DAMO_Approved,
                Engineering_LeadID = @Engineering_LeadID, Funding_SourceID = @Funding_SourceID,
                Funds_Approved_ByID = @Funds_Approved_ByID, CAPEX_OPEX_ID = @CAPEX_OPEX_ID, GL_CodeID = @GL_CodeID,
                Phase_DescriptionID = @Phase_DescriptionID, Primary_Business_Owner = @Primary_Business_Owner,
                Remarks = @Remarks, Business_VerticalID = @Business_VerticalID,
                Digital_Project = @Digital_Project, Delivery_Manager = @Delivery_Manager,
                Initiative_TypeID = @Initiative_TypeID, Platform_OwnerID = @Platform_OwnerID,
                Portfolio_HeadID = @Portfolio_HeadID, Technology_VerticalID = @Technology_VerticalID,
                Initiative_SizeID = @Initiative_SizeID, Project_TypeID = @Project_TypeID,
                Document1_FileName = @Doc1FileName, Document1_Path = @Doc1Path,
                AdditionalDoc_FileName = @AddDocFileName, AdditionalDoc_Path = @AddDocPath,
                ModifiedDate = GETDATE(), ModifiedBy = @ModifiedBy
                WHERE ID = @ID";

            ExecuteNonQuery(query,
                new SqlParameter("@ID", id),
                new SqlParameter("@InitiativeTitle", (object)initiativeTitle ?? DBNull.Value),
                new SqlParameter("@Description", (object)description ?? DBNull.Value),
                new SqlParameter("@Demand_TypeID", (object)demandTypeId ?? DBNull.Value),
                new SqlParameter("@DAMO_Approved", damoApproved),
                new SqlParameter("@Engineering_LeadID", (object)engineeringLeadId ?? DBNull.Value),
                new SqlParameter("@Funding_SourceID", (object)fundingSourceId ?? DBNull.Value),
                new SqlParameter("@Funds_Approved_ByID", (object)fundsApprovedById ?? DBNull.Value),
                new SqlParameter("@CAPEX_OPEX_ID", (object)capexOpexId ?? DBNull.Value),
                new SqlParameter("@GL_CodeID", (object)glCodeId ?? DBNull.Value),
                new SqlParameter("@Phase_DescriptionID", (object)phaseDescriptionId ?? DBNull.Value),
                new SqlParameter("@Primary_Business_Owner", (object)primaryBusinessOwner ?? DBNull.Value),
                new SqlParameter("@Remarks", (object)remarks ?? DBNull.Value),
                new SqlParameter("@Business_VerticalID", (object)businessVerticalId ?? DBNull.Value),
                new SqlParameter("@Digital_Project", digitalProject),
                new SqlParameter("@Delivery_Manager", (object)deliveryManager ?? DBNull.Value),
                new SqlParameter("@Initiative_TypeID", (object)initiativeTypeId ?? DBNull.Value),
                new SqlParameter("@Platform_OwnerID", (object)platformOwnerId ?? DBNull.Value),
                new SqlParameter("@Portfolio_HeadID", (object)portfolioHeadId ?? DBNull.Value),
                new SqlParameter("@Technology_VerticalID", (object)technologyVerticalId ?? DBNull.Value),
                new SqlParameter("@Initiative_SizeID", (object)initiativeSizeId ?? DBNull.Value),
                new SqlParameter("@Project_TypeID", (object)projectTypeId ?? DBNull.Value),
                new SqlParameter("@Doc1FileName", (object)doc1FileName ?? DBNull.Value),
                new SqlParameter("@Doc1Path", (object)doc1Path ?? DBNull.Value),
                new SqlParameter("@AddDocFileName", (object)addDocFileName ?? DBNull.Value),
                new SqlParameter("@AddDocPath", (object)addDocPath ?? DBNull.Value),
                new SqlParameter("@ModifiedBy", (object)modifiedBy ?? DBNull.Value));
        }

        public static DataTable GetDemandFundList()
        {
            string query = @"SELECT d.ID, d.InitiativeTitle, 
                dt.DAMO_Type AS DemandType, d.DAMO_Approved,
                el.Engineering_Lead, fs.Funding_Source_Type AS FundingSource, 
                fa.Fund_Approval_Type AS FundsApprovedBy,
                gc.GL_Code, pd.Phase_Description AS ProjectPhase,
                d.Primary_Business_Owner, pv.Primary_Vertical AS BusinessVertical,
                d.Digital_Project, it.Initiative_Type, 
                po.Platform_Owner, ph.Portfolio_Head,
                ts.TShirt_Size AS InitiativeSize, pt.Project_Type,
                tv.Technology_Vertical,
                d.CreatedDate, d.CreatedBy, d.IsActive
                FROM DemandFund d
                LEFT JOIN DAMO_Type dt ON d.Demand_TypeID = dt.ID
                LEFT JOIN EngineeringTeam el ON d.Engineering_LeadID = el.ID
                LEFT JOIN Funding_Source_Type fs ON d.Funding_SourceID = fs.ID
                LEFT JOIN FundApproval fa ON d.Funds_Approved_ByID = fa.ID
                LEFT JOIN Phase_Description pd ON d.Phase_DescriptionID = pd.ID
                LEFT JOIN Primary_Vertical pv ON d.Business_VerticalID = pv.ID
                LEFT JOIN Initiative_Type it ON d.Initiative_TypeID = it.ID
                LEFT JOIN Platform_Owner po ON d.Platform_OwnerID = po.ID
                LEFT JOIN Portfolio_Head ph ON d.Portfolio_HeadID = ph.ID
                LEFT JOIN TShirt_Size ts ON d.Initiative_SizeID = ts.ID
                LEFT JOIN GL_Code gc ON d.GL_CodeID = gc.ID
                LEFT JOIN Project_Type pt ON d.Project_TypeID = pt.ID
                LEFT JOIN Technology_Vertical tv ON d.Technology_VerticalID = tv.ID
                WHERE d.IsActive = 1
                ORDER BY d.ID DESC";
            return ExecuteQuery(query);
        }

        public static DataRow GetDemandFundById(int id)
        {
            string query = "SELECT * FROM DemandFund WHERE ID = @ID";
            DataTable dt = ExecuteQuery(query, new SqlParameter("@ID", id));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static int? LookupMetadataId(string tableName, string valueColumn, string displayText, SqlConnection conn, SqlTransaction tran)
        {
            if (string.IsNullOrWhiteSpace(displayText)) return null;
            string query = string.Format("SELECT TOP 1 ID FROM [{0}] WHERE [{1}] = @Val AND IsActive = 1", tableName, valueColumn);
            using (SqlCommand cmd = new SqlCommand(query, conn, tran))
            {
                cmd.Parameters.AddWithValue("@Val", displayText.Trim());
                object result = cmd.ExecuteScalar();
                if (result != null && result != DBNull.Value) return Convert.ToInt32(result);
            }
            return null;
        }

        public static void BulkInsertDemandFunds(DataTable dt, string createdBy, bool deleteExisting = true)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (SqlTransaction tran = conn.BeginTransaction())
                {
                    try
                    {
                        if (deleteExisting)
                        {
                            using (SqlCommand delCmd = new SqlCommand("DELETE FROM DemandFund", conn, tran))
                            {
                                delCmd.ExecuteNonQuery();
                            }
                        }

                        foreach (DataRow row in dt.Rows)
                        {
                            int? demandTypeId = LookupMetadataId("DAMO_Type", "DAMO_Type", GetDbValueStr(row, "DemandType"), conn, tran);
                            int? engLeadId = LookupMetadataId("EngineeringTeam", "Engineering_Lead", GetDbValueStr(row, "EngineeringLead"), conn, tran);
                            int? fundSourceId = LookupMetadataId("Funding_Source_Type", "Funding_Source_Type", GetDbValueStr(row, "FundingSource"), conn, tran);
                            int? fundApprovedId = LookupMetadataId("FundApproval", "Fund_Approval_Type", GetDbValueStr(row, "FundsApprovedBy"), conn, tran);
                            int? phaseId = LookupMetadataId("Phase_Description", "Phase_Description", GetDbValueStr(row, "PhaseDescription"), conn, tran);
                            int? bizVertId = LookupMetadataId("Primary_Vertical", "Primary_Vertical", GetDbValueStr(row, "BusinessVertical"), conn, tran);
                            int? initTypeId = LookupMetadataId("Initiative_Type", "Initiative_Type", GetDbValueStr(row, "InitiativeType"), conn, tran);
                            int? platformId = LookupMetadataId("Platform_Owner", "Platform_Owner", GetDbValueStr(row, "PlatformOwner"), conn, tran);
                            int? portfolioId = LookupMetadataId("Portfolio_Head", "Portfolio_Head", GetDbValueStr(row, "PortfolioHead"), conn, tran);
                            int? sizeId = LookupMetadataId("TShirt_Size", "TShirt_Size", GetDbValueStr(row, "InitiativeSize"), conn, tran);
                            int? techVertId = LookupMetadataId("Technology_Vertical", "Technology_Vertical", GetDbValueStr(row, "TechnologyVertical"), conn, tran);
                            int? projTypeId = LookupMetadataId("Project_Type", "Project_Type", GetDbValueStr(row, "ProjectType"), conn, tran);
                            int? glCodeId = LookupMetadataId("GL_Code", "GL_Code", GetDbValueStr(row, "GLCode"), conn, tran);
                            int? capexOpexId = null; // No standard lookup table reference in metadata config

                            string damoStr = GetDbValueStr(row, "DAMOApproved");
                            bool damoApproved = damoStr.Equals("yes", StringComparison.OrdinalIgnoreCase) || damoStr == "1" || damoStr.Equals("true", StringComparison.OrdinalIgnoreCase);
                            string digitalStr = GetDbValueStr(row, "DigitalProject");
                            bool digitalProject = digitalStr.Equals("yes", StringComparison.OrdinalIgnoreCase) || digitalStr == "1" || digitalStr.Equals("true", StringComparison.OrdinalIgnoreCase);

                            string query = @"INSERT INTO DemandFund 
                                (InitiativeTitle, Description, Demand_TypeID, DAMO_Approved,
                                 Engineering_LeadID, Funding_SourceID, Funds_Approved_ByID, CAPEX_OPEX_ID, GL_CodeID,
                                 Phase_DescriptionID, Primary_Business_Owner, Remarks, Business_VerticalID,
                                 Digital_Project, Delivery_Manager, Initiative_TypeID, Platform_OwnerID, Portfolio_HeadID,
                                 Technology_VerticalID, Initiative_SizeID, Project_TypeID, CreatedBy)
                                VALUES 
                                (@InitiativeTitle, @Description, @Demand_TypeID, @DAMO_Approved,
                                 @Engineering_LeadID, @Funding_SourceID, @Funds_Approved_ByID, @CAPEX_OPEX_ID, @GL_CodeID,
                                 @Phase_DescriptionID, @Primary_Business_Owner, @Remarks, @Business_VerticalID,
                                 @Digital_Project, @Delivery_Manager, @Initiative_TypeID, @Platform_OwnerID, @Portfolio_HeadID,
                                 @Technology_VerticalID, @Initiative_SizeID, @Project_TypeID, @CreatedBy)";

                            using (SqlCommand cmd = new SqlCommand(query, conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@InitiativeTitle", GetDbValue(row, "InitiativeTitle"));
                                cmd.Parameters.AddWithValue("@Description", GetDbValue(row, "Description"));
                                cmd.Parameters.AddWithValue("@Demand_TypeID", (object)demandTypeId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@DAMO_Approved", damoApproved);
                                cmd.Parameters.AddWithValue("@Engineering_LeadID", (object)engLeadId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Funding_SourceID", (object)fundSourceId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Funds_Approved_ByID", (object)fundApprovedId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CAPEX_OPEX_ID", (object)capexOpexId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@GL_CodeID", (object)glCodeId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Phase_DescriptionID", (object)phaseId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Primary_Business_Owner", GetDbValue(row, "PrimaryBusinessOwner"));
                                cmd.Parameters.AddWithValue("@Remarks", GetDbValue(row, "Remarks"));
                                cmd.Parameters.AddWithValue("@Business_VerticalID", (object)bizVertId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Digital_Project", digitalProject);
                                cmd.Parameters.AddWithValue("@Delivery_Manager", GetDbValue(row, "DeliveryManager"));
                                cmd.Parameters.AddWithValue("@Initiative_TypeID", (object)initTypeId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Platform_OwnerID", (object)platformId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Portfolio_HeadID", (object)portfolioId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Technology_VerticalID", (object)techVertId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Initiative_SizeID", (object)sizeId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@Project_TypeID", (object)projTypeId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CreatedBy", createdBy);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        tran.Commit();
                    }
                    catch
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        private static string GetDbValueStr(DataRow row, string column)
        {
            if (!row.Table.Columns.Contains(column) || row[column] == null || row[column] == DBNull.Value)
                return "";
            return row[column].ToString().Trim();
        }

        #endregion

        #region Metadata Management

        public static DataTable GetMetadataConfig()
        {
            return ExecuteQuery("SELECT * FROM MetadataConfig WHERE IsConfigurable = 1 ORDER BY DisplayName");
        }

        public static DataTable GetMetadataItems(string tableName, string valueColumn)
        {
            // Use parameterized approach with whitelisted table names for safety
            string[] allowedTables = {
                "BusinessTeam", "DAMO_Type", "EngineeringTeam", "FundApproval",
                "Funding_Source_Type", "Initiative_Type", "Phase_Description",
                "Platform_Owner", "Portfolio_Head", "Primary_Vertical",
                "Spend_Category", "Spend_Type", "TShirt_Size",
                "Technology_Vertical", "Project_Type", "GL_Code"
            };

            bool isAllowed = false;
            foreach (string t in allowedTables)
            {
                if (string.Equals(t, tableName, StringComparison.OrdinalIgnoreCase))
                {
                    tableName = t; // Use the whitelisted version
                    isAllowed = true;
                    break;
                }
            }

            if (!isAllowed)
                throw new ArgumentException("Invalid table name specified.");

            // Validate column name against allowed pattern
            if (string.IsNullOrEmpty(valueColumn) || !System.Text.RegularExpressions.Regex.IsMatch(valueColumn, @"^[A-Za-z_]+$"))
                throw new ArgumentException("Invalid column name specified.");

            string query = string.Format("SELECT ID, [{0}] AS ValueText, IsActive FROM [{1}] ORDER BY [{0}]", valueColumn, tableName);
            return ExecuteQuery(query);
        }

        public static void InsertMetadataItem(string tableName, string valueColumn, int id, string value)
        {
            ValidateMetadataTableName(tableName);
            if (!System.Text.RegularExpressions.Regex.IsMatch(valueColumn, @"^[A-Za-z_]+$"))
                throw new ArgumentException("Invalid column name.");

            string query = string.Format("INSERT INTO [{0}] (ID, [{1}], IsActive) VALUES (@ID, @Value, 1)", tableName, valueColumn);
            ExecuteNonQuery(query,
                new SqlParameter("@ID", id),
                new SqlParameter("@Value", value));
        }

        public static void UpdateMetadataItem(string tableName, string valueColumn, int id, string value)
        {
            ValidateMetadataTableName(tableName);
            if (!System.Text.RegularExpressions.Regex.IsMatch(valueColumn, @"^[A-Za-z_]+$"))
                throw new ArgumentException("Invalid column name.");

            string query = string.Format("UPDATE [{0}] SET [{1}] = @Value WHERE ID = @ID", tableName, valueColumn);
            ExecuteNonQuery(query,
                new SqlParameter("@ID", id),
                new SqlParameter("@Value", value));
        }

        public static void ToggleMetadataItemStatus(string tableName, int id, bool isActive)
        {
            ValidateMetadataTableName(tableName);
            string query = string.Format("UPDATE [{0}] SET IsActive = @IsActive WHERE ID = @ID", tableName);
            ExecuteNonQuery(query,
                new SqlParameter("@ID", id),
                new SqlParameter("@IsActive", isActive));
        }

        public static void DeleteMetadataItem(string tableName, int id)
        {
            ValidateMetadataTableName(tableName);
            string query = string.Format("DELETE FROM [{0}] WHERE ID = @ID", tableName);
            ExecuteNonQuery(query, new SqlParameter("@ID", id));
        }

        public static bool IsMetadataItemInUse(string tableName, int id)
        {
            // Check if the metadata item is referenced in the DemandFund table
            string fkColumn = GetForeignKeyColumn(tableName);
            if (string.IsNullOrEmpty(fkColumn)) return false;

            string query = string.Format("SELECT COUNT(*) FROM DemandFund WHERE [{0}] = @ID", fkColumn);
            int count = Convert.ToInt32(ExecuteScalar(query, new SqlParameter("@ID", id)));
            return count > 0;
        }

        private static string GetForeignKeyColumn(string tableName)
        {
            switch (tableName)
            {
                case "DAMO_Type": return "Demand_TypeID";
                case "EngineeringTeam": return "Engineering_LeadID";
                case "Funding_Source_Type": return "Funding_SourceID";
                case "FundApproval": return "Funds_Approved_ByID";
                case "Phase_Description": return "Phase_DescriptionID";
                case "Primary_Vertical": return "Business_VerticalID";
                case "Initiative_Type": return "Initiative_TypeID";
                case "Platform_Owner": return "Platform_OwnerID";
                case "Portfolio_Head": return "Portfolio_HeadID";
                case "TShirt_Size": return "Initiative_SizeID";
                case "Technology_Vertical": return "Technology_VerticalID";
                case "Project_Type": return "Project_TypeID";
                case "GL_Code": return "GL_CodeID";
                default: return null;
            }
        }

        public static int GetNextMetadataId(string tableName)
        {
            ValidateMetadataTableName(tableName);
            string query = string.Format("SELECT ISNULL(MAX(ID), 0) + 1 FROM [{0}]", tableName);
            return Convert.ToInt32(ExecuteScalar(query));
        }

        public static DataTable GetDashboardPhaseDistribution()
        {
            string query = @"SELECT ISNULL(pd.Phase_Description, 'Not Set') AS PhaseName, COUNT(*) AS Count
                            FROM DemandFund d
                            LEFT JOIN Phase_Description pd ON d.Phase_DescriptionID = pd.ID
                            WHERE d.IsActive = 1
                            GROUP BY pd.Phase_Description
                            ORDER BY Count DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetDashboardInitiativeTypeDistribution()
        {
            string query = @"SELECT ISNULL(it.Initiative_Type, 'Not Set') AS TypeName, COUNT(*) AS Count
                            FROM DemandFund d
                            LEFT JOIN Initiative_Type it ON d.Initiative_TypeID = it.ID
                            WHERE d.IsActive = 1
                            GROUP BY it.Initiative_Type
                            ORDER BY Count DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetDashboardFundingSourceDistribution()
        {
            string query = @"SELECT ISNULL(fs.Funding_Source_Type, 'Not Set') AS SourceName, COUNT(*) AS Count
                            FROM DemandFund d
                            LEFT JOIN Funding_Source_Type fs ON d.Funding_SourceID = fs.ID
                            WHERE d.IsActive = 1
                            GROUP BY fs.Funding_Source_Type
                            ORDER BY Count DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetDashboardBusinessVerticalDistribution()
        {
            string query = @"SELECT ISNULL(pv.Primary_Vertical, 'Not Set') AS VerticalName, COUNT(*) AS Count
                            FROM DemandFund d
                            LEFT JOIN Primary_Vertical pv ON d.Business_VerticalID = pv.ID
                            WHERE d.IsActive = 1
                            GROUP BY pv.Primary_Vertical
                            ORDER BY Count DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetDashboardMonthlyTrend()
        {
            string query = @"SELECT FORMAT(CreatedDate, 'yyyy-MM') AS MonthYear, 
                            FORMAT(CreatedDate, 'MMM yyyy') AS MonthLabel,
                            COUNT(*) AS Count
                            FROM DemandFund WHERE IsActive = 1
                            GROUP BY FORMAT(CreatedDate, 'yyyy-MM'), FORMAT(CreatedDate, 'MMM yyyy')
                            ORDER BY MonthYear DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetDashboardSpendingByTeam()
        {
            string query = @"SELECT ISNULL(Team, 'Not Set') AS TeamName, 
                            ISNULL(SUM(AllocationAmount), 0) AS TotalAmount
                            FROM SpendingAllocation 
                            WHERE Team IS NOT NULL AND Team <> ''
                            GROUP BY Team
                            ORDER BY TotalAmount DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetDashboardProgramStatusDistribution()
        {
            string query = @"SELECT ISNULL([Status], 'Not Set') AS StatusName, COUNT(*) AS Count
                            FROM ApprovedFundingPrograms
                            GROUP BY [Status]
                            ORDER BY Count DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetDashboardSpendingByPlatform()
        {
            string query = @"SELECT ISNULL(Platform, 'Not Set') AS PlatformName,
                            ISNULL(SUM(AllocationAmount), 0) AS TotalAmount
                            FROM SpendingAllocation
                            WHERE Platform IS NOT NULL AND Platform <> ''
                            GROUP BY Platform
                            ORDER BY TotalAmount DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetDashboardLineItemsByVendor()
        {
            string query = @"SELECT TOP 10 ISNULL(Vendor, 'Not Set') AS VendorName,
                            ISNULL(SUM(Amount), 0) AS TotalAmount
                            FROM FundingLineItems
                            WHERE Vendor IS NOT NULL AND Vendor <> ''
                            GROUP BY Vendor
                            ORDER BY TotalAmount DESC";
            return ExecuteQuery(query);
        }

        private static void ValidateMetadataTableName(string tableName)
        {
            string[] allowedTables = {
                "BusinessTeam", "DAMO_Type", "EngineeringTeam", "FundApproval",
                "Funding_Source_Type", "Initiative_Type", "Phase_Description",
                "Platform_Owner", "Portfolio_Head", "Primary_Vertical",
                "Spend_Category", "Spend_Type", "TShirt_Size",
                "Technology_Vertical", "Project_Type", "GL_Code"
            };

            bool isAllowed = false;
            foreach (string t in allowedTables)
            {
                if (string.Equals(t, tableName, StringComparison.OrdinalIgnoreCase))
                {
                    isAllowed = true;
                    break;
                }
            }

            if (!isAllowed)
                throw new ArgumentException("Invalid table name specified.");
        }

        #endregion

        #region Dropdown Data Helpers

        public static DataTable GetActiveMetadata(string tableName, string valueColumn)
        {
            ValidateMetadataTableName(tableName);
            if (!System.Text.RegularExpressions.Regex.IsMatch(valueColumn, @"^[A-Za-z_]+$"))
                throw new ArgumentException("Invalid column name.");

            string query = string.Format("SELECT ID, [{0}] AS DisplayText FROM [{1}] WHERE IsActive = 1 ORDER BY [{0}]", valueColumn, tableName);
            return ExecuteQuery(query);
        }

        #endregion

        #region Spending Allocation

        public static DataTable GetSpendingAllocations()
        {
            return ExecuteQuery("SELECT * FROM SpendingAllocation ORDER BY ID DESC");
        }

        public static DataRow GetSpendingAllocationById(int id)
        {
            DataTable dt = ExecuteQuery("SELECT * FROM SpendingAllocation WHERE ID = @ID",
                new SqlParameter("@ID", id));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static int InsertSpendingAllocation(DateTime? date, string fundingLineItem, string description,
            string allocationType, string year, DateTime? plannedDate, string team, string platform,
            string vendor, string drmCategory, string drmProgram, DateTime? memoDate, string camId,
            decimal? actualAmount, decimal? allocationAmount, string lpoNumber, string amsRequestNumber,
            string requester, string remarks, string remarks2, string createdBy)
        {
            string query = @"INSERT INTO SpendingAllocation 
                ([Date], FundingLineItem, [Description], AllocationType, [Year], PlannedDate,
                 Team, Platform, Vendor, DRMCategory, DRMProgram, MemoDate, CAMID,
                 ActualAmount, AllocationAmount, LPONumber, AMSRequestNumber, Requester,
                 Remarks, Remarks2, CreatedBy)
                VALUES (@Date, @FundingLineItem, @Description, @AllocationType, @Year, @PlannedDate,
                 @Team, @Platform, @Vendor, @DRMCategory, @DRMProgram, @MemoDate, @CAMID,
                 @ActualAmount, @AllocationAmount, @LPONumber, @AMSRequestNumber, @Requester,
                 @Remarks, @Remarks2, @CreatedBy);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";
            object result = ExecuteScalar(query,
                new SqlParameter("@Date", (object)date ?? DBNull.Value),
                new SqlParameter("@FundingLineItem", (object)fundingLineItem ?? DBNull.Value),
                new SqlParameter("@Description", (object)description ?? DBNull.Value),
                new SqlParameter("@AllocationType", (object)allocationType ?? DBNull.Value),
                new SqlParameter("@Year", (object)year ?? DBNull.Value),
                new SqlParameter("@PlannedDate", (object)plannedDate ?? DBNull.Value),
                new SqlParameter("@Team", (object)team ?? DBNull.Value),
                new SqlParameter("@Platform", (object)platform ?? DBNull.Value),
                new SqlParameter("@Vendor", (object)vendor ?? DBNull.Value),
                new SqlParameter("@DRMCategory", (object)drmCategory ?? DBNull.Value),
                new SqlParameter("@DRMProgram", (object)drmProgram ?? DBNull.Value),
                new SqlParameter("@MemoDate", (object)memoDate ?? DBNull.Value),
                new SqlParameter("@CAMID", (object)camId ?? DBNull.Value),
                new SqlParameter("@ActualAmount", (object)actualAmount ?? DBNull.Value),
                new SqlParameter("@AllocationAmount", (object)allocationAmount ?? DBNull.Value),
                new SqlParameter("@LPONumber", (object)lpoNumber ?? DBNull.Value),
                new SqlParameter("@AMSRequestNumber", (object)amsRequestNumber ?? DBNull.Value),
                new SqlParameter("@Requester", (object)requester ?? DBNull.Value),
                new SqlParameter("@Remarks", (object)remarks ?? DBNull.Value),
                new SqlParameter("@Remarks2", (object)remarks2 ?? DBNull.Value),
                new SqlParameter("@CreatedBy", createdBy));
            return Convert.ToInt32(result);
        }

        public static void UpdateSpendingAllocation(int id, DateTime? date, string fundingLineItem, string description,
            string allocationType, string year, DateTime? plannedDate, string team, string platform,
            string vendor, string drmCategory, string drmProgram, DateTime? memoDate, string camId,
            decimal? actualAmount, decimal? allocationAmount, string lpoNumber, string amsRequestNumber,
            string requester, string remarks, string remarks2, string modifiedBy)
        {
            string query = @"UPDATE SpendingAllocation SET
                [Date]=@Date, FundingLineItem=@FundingLineItem, [Description]=@Description,
                AllocationType=@AllocationType, [Year]=@Year, PlannedDate=@PlannedDate,
                Team=@Team, Platform=@Platform, Vendor=@Vendor, DRMCategory=@DRMCategory,
                DRMProgram=@DRMProgram, MemoDate=@MemoDate, CAMID=@CAMID,
                ActualAmount=@ActualAmount, AllocationAmount=@AllocationAmount,
                LPONumber=@LPONumber, AMSRequestNumber=@AMSRequestNumber, Requester=@Requester,
                Remarks=@Remarks, Remarks2=@Remarks2, ModifiedBy=@ModifiedBy, ModifiedDate=GETDATE()
                WHERE ID=@ID";
            ExecuteNonQuery(query,
                new SqlParameter("@ID", id),
                new SqlParameter("@Date", (object)date ?? DBNull.Value),
                new SqlParameter("@FundingLineItem", (object)fundingLineItem ?? DBNull.Value),
                new SqlParameter("@Description", (object)description ?? DBNull.Value),
                new SqlParameter("@AllocationType", (object)allocationType ?? DBNull.Value),
                new SqlParameter("@Year", (object)year ?? DBNull.Value),
                new SqlParameter("@PlannedDate", (object)plannedDate ?? DBNull.Value),
                new SqlParameter("@Team", (object)team ?? DBNull.Value),
                new SqlParameter("@Platform", (object)platform ?? DBNull.Value),
                new SqlParameter("@Vendor", (object)vendor ?? DBNull.Value),
                new SqlParameter("@DRMCategory", (object)drmCategory ?? DBNull.Value),
                new SqlParameter("@DRMProgram", (object)drmProgram ?? DBNull.Value),
                new SqlParameter("@MemoDate", (object)memoDate ?? DBNull.Value),
                new SqlParameter("@CAMID", (object)camId ?? DBNull.Value),
                new SqlParameter("@ActualAmount", (object)actualAmount ?? DBNull.Value),
                new SqlParameter("@AllocationAmount", (object)allocationAmount ?? DBNull.Value),
                new SqlParameter("@LPONumber", (object)lpoNumber ?? DBNull.Value),
                new SqlParameter("@AMSRequestNumber", (object)amsRequestNumber ?? DBNull.Value),
                new SqlParameter("@Requester", (object)requester ?? DBNull.Value),
                new SqlParameter("@Remarks", (object)remarks ?? DBNull.Value),
                new SqlParameter("@Remarks2", (object)remarks2 ?? DBNull.Value),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static void BulkInsertSpendingAllocations(DataTable dt, string createdBy, bool deleteExisting = true)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (SqlTransaction tran = conn.BeginTransaction())
                {
                    try
                    {
                        if (deleteExisting)
                        {
                            using (SqlCommand delCmd = new SqlCommand("DELETE FROM SpendingAllocation", conn, tran))
                            {
                                delCmd.ExecuteNonQuery();
                            }
                        }

                        // Insert rows
                        foreach (DataRow row in dt.Rows)
                        {
                            string query = @"INSERT INTO SpendingAllocation 
                                ([Date], FundingLineItem, [Description], AllocationType, [Year], PlannedDate,
                                 Team, Platform, Vendor, DRMCategory, DRMProgram, MemoDate, CAMID,
                                 ActualAmount, AllocationAmount, LPONumber, AMSRequestNumber, Requester,
                                 Remarks, Remarks2, CreatedBy)
                                VALUES (@Date, @FundingLineItem, @Description, @AllocationType, @Year, @PlannedDate,
                                 @Team, @Platform, @Vendor, @DRMCategory, @DRMProgram, @MemoDate, @CAMID,
                                 @ActualAmount, @AllocationAmount, @LPONumber, @AMSRequestNumber, @Requester,
                                 @Remarks, @Remarks2, @CreatedBy)";

                            using (SqlCommand cmd = new SqlCommand(query, conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@Date", GetDbValue(row, "Date", true));
                                cmd.Parameters.AddWithValue("@FundingLineItem", GetDbValue(row, "FundingLineItem"));
                                cmd.Parameters.AddWithValue("@Description", GetDbValue(row, "Description"));
                                cmd.Parameters.AddWithValue("@AllocationType", GetDbValue(row, "AllocationType"));
                                cmd.Parameters.AddWithValue("@Year", GetDbValue(row, "Year"));
                                cmd.Parameters.AddWithValue("@PlannedDate", GetDbValue(row, "PlannedDate", true));
                                cmd.Parameters.AddWithValue("@Team", GetDbValue(row, "Team"));
                                cmd.Parameters.AddWithValue("@Platform", GetDbValue(row, "Platform"));
                                cmd.Parameters.AddWithValue("@Vendor", GetDbValue(row, "Vendor"));
                                cmd.Parameters.AddWithValue("@DRMCategory", GetDbValue(row, "DRMCategory"));
                                cmd.Parameters.AddWithValue("@DRMProgram", GetDbValue(row, "DRMProgram"));
                                cmd.Parameters.AddWithValue("@MemoDate", GetDbValue(row, "MemoDate", true));
                                cmd.Parameters.AddWithValue("@CAMID", GetDbValue(row, "CAMID"));
                                cmd.Parameters.AddWithValue("@ActualAmount", GetDbValue(row, "ActualAmount", false, true));
                                cmd.Parameters.AddWithValue("@AllocationAmount", GetDbValue(row, "AllocationAmount", false, true));
                                cmd.Parameters.AddWithValue("@LPONumber", GetDbValue(row, "LPONumber"));
                                cmd.Parameters.AddWithValue("@AMSRequestNumber", GetDbValue(row, "AMSRequestNumber"));
                                cmd.Parameters.AddWithValue("@Requester", GetDbValue(row, "Requester"));
                                cmd.Parameters.AddWithValue("@Remarks", GetDbValue(row, "Remarks"));
                                cmd.Parameters.AddWithValue("@Remarks2", GetDbValue(row, "Remarks2"));
                                cmd.Parameters.AddWithValue("@CreatedBy", createdBy);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        tran.Commit();
                    }
                    catch
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        #endregion

        #region Approved Funding Programs

        public static DataTable GetApprovedFundingPrograms()
        {
            return ExecuteQuery("SELECT * FROM ApprovedFundingPrograms ORDER BY ID DESC");
        }

        public static DataRow GetApprovedFundingProgramById(int id)
        {
            DataTable dt = ExecuteQuery("SELECT * FROM ApprovedFundingPrograms WHERE ID = @ID",
                new SqlParameter("@ID", id));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static int InsertApprovedFundingProgram(string title, string type, string demandId,
            string approver, string primaryLead, string gl, decimal? capex, string capexType,
            string status, decimal? fundAmount, decimal? consumed, decimal? available,
            decimal? planned, string approvalForm, string remarks, string programOwner, string createdBy)
        {
            string query = @"INSERT INTO ApprovedFundingPrograms 
                (Title, [Type], DemandID, Approver, PrimaryLead, GL, CAPEX, CAPEXType,
                 [Status], FundAmount, Consumed, Available, Planned, ApprovalForm, Remarks, ProgramOwner, CreatedBy)
                VALUES (@Title, @Type, @DemandID, @Approver, @PrimaryLead, @GL, @CAPEX, @CAPEXType,
                 @Status, @FundAmount, @Consumed, @Available, @Planned, @ApprovalForm, @Remarks, @ProgramOwner, @CreatedBy);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";
            object result = ExecuteScalar(query,
                new SqlParameter("@Title", (object)title ?? DBNull.Value),
                new SqlParameter("@Type", (object)type ?? DBNull.Value),
                new SqlParameter("@DemandID", (object)demandId ?? DBNull.Value),
                new SqlParameter("@Approver", (object)approver ?? DBNull.Value),
                new SqlParameter("@PrimaryLead", (object)primaryLead ?? DBNull.Value),
                new SqlParameter("@GL", (object)gl ?? DBNull.Value),
                new SqlParameter("@CAPEX", (object)capex ?? DBNull.Value),
                new SqlParameter("@CAPEXType", (object)capexType ?? DBNull.Value),
                new SqlParameter("@Status", (object)status ?? DBNull.Value),
                new SqlParameter("@FundAmount", (object)fundAmount ?? DBNull.Value),
                new SqlParameter("@Consumed", (object)consumed ?? DBNull.Value),
                new SqlParameter("@Available", (object)available ?? DBNull.Value),
                new SqlParameter("@Planned", (object)planned ?? DBNull.Value),
                new SqlParameter("@ApprovalForm", (object)approvalForm ?? DBNull.Value),
                new SqlParameter("@Remarks", (object)remarks ?? DBNull.Value),
                new SqlParameter("@ProgramOwner", (object)programOwner ?? DBNull.Value),
                new SqlParameter("@CreatedBy", createdBy));
            return Convert.ToInt32(result);
        }

        public static void UpdateApprovedFundingProgram(int id, string title, string type, string demandId,
            string approver, string primaryLead, string gl, decimal? capex, string capexType,
            string status, decimal? fundAmount, decimal? consumed, decimal? available,
            decimal? planned, string approvalForm, string remarks, string programOwner, string modifiedBy)
        {
            string query = @"UPDATE ApprovedFundingPrograms SET
                Title=@Title, [Type]=@Type, DemandID=@DemandID, Approver=@Approver,
                PrimaryLead=@PrimaryLead, GL=@GL, CAPEX=@CAPEX, CAPEXType=@CAPEXType,
                [Status]=@Status, FundAmount=@FundAmount, Consumed=@Consumed, Available=@Available,
                Planned=@Planned, ApprovalForm=@ApprovalForm, Remarks=@Remarks, ProgramOwner=@ProgramOwner,
                ModifiedBy=@ModifiedBy, ModifiedDate=GETDATE()
                WHERE ID=@ID";
            ExecuteNonQuery(query,
                new SqlParameter("@ID", id),
                new SqlParameter("@Title", (object)title ?? DBNull.Value),
                new SqlParameter("@Type", (object)type ?? DBNull.Value),
                new SqlParameter("@DemandID", (object)demandId ?? DBNull.Value),
                new SqlParameter("@Approver", (object)approver ?? DBNull.Value),
                new SqlParameter("@PrimaryLead", (object)primaryLead ?? DBNull.Value),
                new SqlParameter("@GL", (object)gl ?? DBNull.Value),
                new SqlParameter("@CAPEX", (object)capex ?? DBNull.Value),
                new SqlParameter("@CAPEXType", (object)capexType ?? DBNull.Value),
                new SqlParameter("@Status", (object)status ?? DBNull.Value),
                new SqlParameter("@FundAmount", (object)fundAmount ?? DBNull.Value),
                new SqlParameter("@Consumed", (object)consumed ?? DBNull.Value),
                new SqlParameter("@Available", (object)available ?? DBNull.Value),
                new SqlParameter("@Planned", (object)planned ?? DBNull.Value),
                new SqlParameter("@ApprovalForm", (object)approvalForm ?? DBNull.Value),
                new SqlParameter("@Remarks", (object)remarks ?? DBNull.Value),
                new SqlParameter("@ProgramOwner", (object)programOwner ?? DBNull.Value),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static void BulkInsertApprovedFundingPrograms(DataTable dt, string createdBy, bool deleteExisting = true)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (SqlTransaction tran = conn.BeginTransaction())
                {
                    try
                    {
                        if (deleteExisting)
                        {
                            using (SqlCommand delCmd = new SqlCommand("DELETE FROM ApprovedFundingPrograms", conn, tran))
                            {
                                delCmd.ExecuteNonQuery();
                            }
                        }

                        foreach (DataRow row in dt.Rows)
                        {
                            string query = @"INSERT INTO ApprovedFundingPrograms 
                                (Title, [Type], DemandID, Approver, PrimaryLead, GL, CAPEX, CAPEXType,
                                 [Status], FundAmount, Consumed, Available, Planned, ApprovalForm, Remarks, ProgramOwner, CreatedBy)
                                VALUES (@Title, @Type, @DemandID, @Approver, @PrimaryLead, @GL, @CAPEX, @CAPEXType,
                                 @Status, @FundAmount, @Consumed, @Available, @Planned, @ApprovalForm, @Remarks, @ProgramOwner, @CreatedBy)";

                            using (SqlCommand cmd = new SqlCommand(query, conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@Title", GetDbValue(row, "Title"));
                                cmd.Parameters.AddWithValue("@Type", GetDbValue(row, "Type"));
                                cmd.Parameters.AddWithValue("@DemandID", GetDbValue(row, "DemandID"));
                                cmd.Parameters.AddWithValue("@Approver", GetDbValue(row, "Approver"));
                                cmd.Parameters.AddWithValue("@PrimaryLead", GetDbValue(row, "PrimaryLead"));
                                cmd.Parameters.AddWithValue("@GL", GetDbValue(row, "GL"));
                                cmd.Parameters.AddWithValue("@CAPEX", GetDbValue(row, "CAPEX", false, true));
                                cmd.Parameters.AddWithValue("@CAPEXType", GetDbValue(row, "CAPEXType"));
                                cmd.Parameters.AddWithValue("@Status", GetDbValue(row, "Status"));
                                cmd.Parameters.AddWithValue("@FundAmount", GetDbValue(row, "FundAmount", false, true));
                                cmd.Parameters.AddWithValue("@Consumed", GetDbValue(row, "Consumed", false, true));
                                cmd.Parameters.AddWithValue("@Available", GetDbValue(row, "Available", false, true));
                                cmd.Parameters.AddWithValue("@Planned", GetDbValue(row, "Planned", false, true));
                                cmd.Parameters.AddWithValue("@ApprovalForm", GetDbValue(row, "ApprovalForm"));
                                cmd.Parameters.AddWithValue("@Remarks", GetDbValue(row, "Remarks"));
                                cmd.Parameters.AddWithValue("@ProgramOwner", GetDbValue(row, "ProgramOwner"));
                                cmd.Parameters.AddWithValue("@CreatedBy", createdBy);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        tran.Commit();
                    }
                    catch
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        #endregion

        #region Funding Line Items

        public static DataTable GetFundingLineItems()
        {
            return ExecuteQuery("SELECT * FROM FundingLineItems ORDER BY ID DESC");
        }

        public static DataRow GetFundingLineItemById(int id)
        {
            DataTable dt = ExecuteQuery("SELECT * FROM FundingLineItems WHERE ID = @ID",
                new SqlParameter("@ID", id));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static int InsertFundingLineItem(string programTitle, string title, string allocationType,
            string allocationSubType, string lineItemId, string subCapexId, string vendor,
            decimal? amount, decimal? consumed, decimal? blockedAmount, decimal? remainingAmount, string createdBy)
        {
            string query = @"INSERT INTO FundingLineItems 
                (ProgramTitle, Title, AllocationType, AllocationSubType, LineItemID,
                 SubCAPEXID, Vendor, Amount, Consumed, BlockedAmount, RemainingAmount, CreatedBy)
                VALUES (@ProgramTitle, @Title, @AllocationType, @AllocationSubType, @LineItemID,
                 @SubCAPEXID, @Vendor, @Amount, @Consumed, @BlockedAmount, @RemainingAmount, @CreatedBy);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";
            object result = ExecuteScalar(query,
                new SqlParameter("@ProgramTitle", (object)programTitle ?? DBNull.Value),
                new SqlParameter("@Title", (object)title ?? DBNull.Value),
                new SqlParameter("@AllocationType", (object)allocationType ?? DBNull.Value),
                new SqlParameter("@AllocationSubType", (object)allocationSubType ?? DBNull.Value),
                new SqlParameter("@LineItemID", (object)lineItemId ?? DBNull.Value),
                new SqlParameter("@SubCAPEXID", (object)subCapexId ?? DBNull.Value),
                new SqlParameter("@Vendor", (object)vendor ?? DBNull.Value),
                new SqlParameter("@Amount", (object)amount ?? DBNull.Value),
                new SqlParameter("@Consumed", (object)consumed ?? DBNull.Value),
                new SqlParameter("@BlockedAmount", (object)blockedAmount ?? DBNull.Value),
                new SqlParameter("@RemainingAmount", (object)remainingAmount ?? DBNull.Value),
                new SqlParameter("@CreatedBy", createdBy));
            return Convert.ToInt32(result);
        }

        public static void UpdateFundingLineItem(int id, string programTitle, string title, string allocationType,
            string allocationSubType, string lineItemId, string subCapexId, string vendor,
            decimal? amount, decimal? consumed, decimal? blockedAmount, decimal? remainingAmount, string modifiedBy)
        {
            string query = @"UPDATE FundingLineItems SET
                ProgramTitle=@ProgramTitle, Title=@Title, AllocationType=@AllocationType,
                AllocationSubType=@AllocationSubType, LineItemID=@LineItemID, SubCAPEXID=@SubCAPEXID,
                Vendor=@Vendor, Amount=@Amount, Consumed=@Consumed, BlockedAmount=@BlockedAmount,
                RemainingAmount=@RemainingAmount, ModifiedBy=@ModifiedBy, ModifiedDate=GETDATE()
                WHERE ID=@ID";
            ExecuteNonQuery(query,
                new SqlParameter("@ID", id),
                new SqlParameter("@ProgramTitle", (object)programTitle ?? DBNull.Value),
                new SqlParameter("@Title", (object)title ?? DBNull.Value),
                new SqlParameter("@AllocationType", (object)allocationType ?? DBNull.Value),
                new SqlParameter("@AllocationSubType", (object)allocationSubType ?? DBNull.Value),
                new SqlParameter("@LineItemID", (object)lineItemId ?? DBNull.Value),
                new SqlParameter("@SubCAPEXID", (object)subCapexId ?? DBNull.Value),
                new SqlParameter("@Vendor", (object)vendor ?? DBNull.Value),
                new SqlParameter("@Amount", (object)amount ?? DBNull.Value),
                new SqlParameter("@Consumed", (object)consumed ?? DBNull.Value),
                new SqlParameter("@BlockedAmount", (object)blockedAmount ?? DBNull.Value),
                new SqlParameter("@RemainingAmount", (object)remainingAmount ?? DBNull.Value),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static void BulkInsertFundingLineItems(DataTable dt, string createdBy, bool deleteExisting = true)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (SqlTransaction tran = conn.BeginTransaction())
                {
                    try
                    {
                        if (deleteExisting)
                        {
                            using (SqlCommand delCmd = new SqlCommand("DELETE FROM FundingLineItems", conn, tran))
                            {
                                delCmd.ExecuteNonQuery();
                            }
                        }

                        foreach (DataRow row in dt.Rows)
                        {
                            string query = @"INSERT INTO FundingLineItems 
                                (ProgramTitle, Title, AllocationType, AllocationSubType, LineItemID,
                                 SubCAPEXID, Vendor, Amount, Consumed, BlockedAmount, RemainingAmount, CreatedBy)
                                VALUES (@ProgramTitle, @Title, @AllocationType, @AllocationSubType, @LineItemID,
                                 @SubCAPEXID, @Vendor, @Amount, @Consumed, @BlockedAmount, @RemainingAmount, @CreatedBy)";

                            using (SqlCommand cmd = new SqlCommand(query, conn, tran))
                            {
                                cmd.Parameters.AddWithValue("@ProgramTitle", GetDbValue(row, "ProgramTitle"));
                                cmd.Parameters.AddWithValue("@Title", GetDbValue(row, "Title"));
                                cmd.Parameters.AddWithValue("@AllocationType", GetDbValue(row, "AllocationType"));
                                cmd.Parameters.AddWithValue("@AllocationSubType", GetDbValue(row, "AllocationSubType"));
                                cmd.Parameters.AddWithValue("@LineItemID", GetDbValue(row, "LineItemID"));
                                cmd.Parameters.AddWithValue("@SubCAPEXID", GetDbValue(row, "SubCAPEXID"));
                                cmd.Parameters.AddWithValue("@Vendor", GetDbValue(row, "Vendor"));
                                cmd.Parameters.AddWithValue("@Amount", GetDbValue(row, "Amount", false, true));
                                cmd.Parameters.AddWithValue("@Consumed", GetDbValue(row, "Consumed", false, true));
                                cmd.Parameters.AddWithValue("@BlockedAmount", GetDbValue(row, "BlockedAmount", false, true));
                                cmd.Parameters.AddWithValue("@RemainingAmount", GetDbValue(row, "RemainingAmount", false, true));
                                cmd.Parameters.AddWithValue("@CreatedBy", createdBy);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        tran.Commit();
                    }
                    catch
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        #endregion

        #region Workflow Tasks

        public static DataTable GetWorkflowTasks()
        {
            string query = @"SELECT t.TaskID, t.Title, t.Description, t.Status, t.Priority,
                t.AssignedToUserID, t.AssignedToName, t.DemandFundID, t.DueDate, t.SortOrder,
                t.CreatedDate, t.CreatedBy, t.IsActive,
                t.InstanceID, t.StepID,
                d.InitiativeTitle AS DemandTitle,
                s.NodeType AS StepNodeType
                FROM WorkflowTasks t
                LEFT JOIN DemandFund d ON t.DemandFundID = d.ID
                LEFT JOIN WorkflowInstanceSteps s ON t.StepID = s.StepID
                WHERE t.IsActive = 1
                ORDER BY t.SortOrder, t.CreatedDate DESC";
            return ExecuteQuery(query);
        }

        public static DataRow GetWorkflowTaskById(int taskId)
        {
            string query = @"SELECT t.*, d.InitiativeTitle AS DemandTitle
                FROM WorkflowTasks t
                LEFT JOIN DemandFund d ON t.DemandFundID = d.ID
                WHERE t.TaskID = @TaskID";
            DataTable dt = ExecuteQuery(query, new SqlParameter("@TaskID", taskId));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static int InsertWorkflowTask(string title, string description, string status,
            string priority, int? assignedToUserId, string assignedToName, int? demandFundId,
            DateTime? dueDate, string createdBy)
        {
            string query = @"INSERT INTO WorkflowTasks 
                (Title, Description, Status, Priority, AssignedToUserID, AssignedToName,
                 DemandFundID, DueDate, SortOrder, CreatedBy)
                VALUES (@Title, @Description, @Status, @Priority, @AssignedToUserID, @AssignedToName,
                 @DemandFundID, @DueDate, 
                 (SELECT ISNULL(MAX(SortOrder),0)+1 FROM WorkflowTasks WHERE Status=@Status), @CreatedBy);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";
            object result = ExecuteScalar(query,
                new SqlParameter("@Title", title),
                new SqlParameter("@Description", (object)description ?? DBNull.Value),
                new SqlParameter("@Status", status),
                new SqlParameter("@Priority", priority),
                new SqlParameter("@AssignedToUserID", (object)assignedToUserId ?? DBNull.Value),
                new SqlParameter("@AssignedToName", (object)assignedToName ?? DBNull.Value),
                new SqlParameter("@DemandFundID", (object)demandFundId ?? DBNull.Value),
                new SqlParameter("@DueDate", (object)dueDate ?? DBNull.Value),
                new SqlParameter("@CreatedBy", createdBy));
            return Convert.ToInt32(result);
        }

        public static void UpdateWorkflowTask(int taskId, string title, string description,
            string priority, int? assignedToUserId, string assignedToName, int? demandFundId,
            DateTime? dueDate, string modifiedBy)
        {
            string query = @"UPDATE WorkflowTasks SET Title=@Title, Description=@Description,
                Priority=@Priority, AssignedToUserID=@AssignedToUserID, AssignedToName=@AssignedToName,
                DemandFundID=@DemandFundID, DueDate=@DueDate,
                ModifiedDate=GETDATE(), ModifiedBy=@ModifiedBy
                WHERE TaskID=@TaskID";
            ExecuteNonQuery(query,
                new SqlParameter("@TaskID", taskId),
                new SqlParameter("@Title", title),
                new SqlParameter("@Description", (object)description ?? DBNull.Value),
                new SqlParameter("@Priority", priority),
                new SqlParameter("@AssignedToUserID", (object)assignedToUserId ?? DBNull.Value),
                new SqlParameter("@AssignedToName", (object)assignedToName ?? DBNull.Value),
                new SqlParameter("@DemandFundID", (object)demandFundId ?? DBNull.Value),
                new SqlParameter("@DueDate", (object)dueDate ?? DBNull.Value),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static void UpdateWorkflowTaskStatus(int taskId, string newStatus, string changedBy)
        {
            // Get old status for history
            DataRow task = GetWorkflowTaskById(taskId);
            string oldStatus = task != null ? task["Status"].ToString() : "";

            string query = @"UPDATE WorkflowTasks SET Status=@Status, ModifiedDate=GETDATE(), ModifiedBy=@ModifiedBy WHERE TaskID=@TaskID";
            ExecuteNonQuery(query,
                new SqlParameter("@TaskID", taskId),
                new SqlParameter("@Status", newStatus),
                new SqlParameter("@ModifiedBy", changedBy));

            // Record history
            InsertStatusHistory(taskId, oldStatus, newStatus, changedBy);

            // Notify assigned user
            if (task != null && task["AssignedToUserID"] != DBNull.Value)
            {
                int assignedUserId = Convert.ToInt32(task["AssignedToUserID"]);
                string msg = string.Format("Task \"{0}\" moved from {1} to {2}", task["Title"], oldStatus, newStatus);
                InsertNotification(assignedUserId, taskId, msg, "StatusChange");
            }
        }

        public static void UpdateWorkflowTaskSortOrder(int taskId, string status, int sortOrder)
        {
            string query = @"UPDATE WorkflowTasks SET Status=@Status, SortOrder=@SortOrder WHERE TaskID=@TaskID";
            ExecuteNonQuery(query,
                new SqlParameter("@TaskID", taskId),
                new SqlParameter("@Status", status),
                new SqlParameter("@SortOrder", sortOrder));
        }

        public static void DeleteWorkflowTask(int taskId, string modifiedBy)
        {
            string query = @"UPDATE WorkflowTasks SET IsActive=0, ModifiedDate=GETDATE(), ModifiedBy=@ModifiedBy WHERE TaskID=@TaskID";
            ExecuteNonQuery(query,
                new SqlParameter("@TaskID", taskId),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        #endregion

        #region Workflow Approvals

        public static DataTable GetApprovalsByTaskId(int taskId)
        {
            string query = @"SELECT a.*, u.FullName AS ApproverFullName
                FROM WorkflowApprovals a
                LEFT JOIN AppUsers u ON a.ApproverUserID = u.UserID
                WHERE a.TaskID = @TaskID
                ORDER BY a.CreatedDate DESC";
            return ExecuteQuery(query, new SqlParameter("@TaskID", taskId));
        }

        public static int InsertApproval(int taskId, int approverUserId, string approverName, string comments, string createdBy)
        {
            string query = @"INSERT INTO WorkflowApprovals (TaskID, ApproverUserID, ApproverName, Comments, CreatedBy)
                VALUES (@TaskID, @ApproverUserID, @ApproverName, @Comments, @CreatedBy);
                SELECT CAST(SCOPE_IDENTITY() AS INT);";
            object result = ExecuteScalar(query,
                new SqlParameter("@TaskID", taskId),
                new SqlParameter("@ApproverUserID", approverUserId),
                new SqlParameter("@ApproverName", (object)approverName ?? DBNull.Value),
                new SqlParameter("@Comments", (object)comments ?? DBNull.Value),
                new SqlParameter("@CreatedBy", createdBy));

            // Notify approver
            DataRow task = GetWorkflowTaskById(taskId);
            string taskTitle = task != null ? task["Title"].ToString() : "Task #" + taskId;
            InsertNotification(approverUserId, taskId,
                string.Format("You have a pending approval for task \"{0}\"", taskTitle), "Approval");

            return Convert.ToInt32(result);
        }

        public static void UpdateApprovalStatus(int approvalId, string status, string comments)
        {
            string query = @"UPDATE WorkflowApprovals SET ApprovalStatus=@Status, Comments=@Comments, 
                ApprovalDate=GETDATE() WHERE ApprovalID=@ApprovalID";
            ExecuteNonQuery(query,
                new SqlParameter("@ApprovalID", approvalId),
                new SqlParameter("@Status", status),
                new SqlParameter("@Comments", (object)comments ?? DBNull.Value));

            // Get task info and notify creator
            DataTable dt = ExecuteQuery("SELECT TaskID FROM WorkflowApprovals WHERE ApprovalID=@ApprovalID",
                new SqlParameter("@ApprovalID", approvalId));
            if (dt.Rows.Count > 0)
            {
                int taskId = Convert.ToInt32(dt.Rows[0]["TaskID"]);
                DataRow task = GetWorkflowTaskById(taskId);
                if (task != null)
                {
                    DataRow creator = AuthenticateUser(task["CreatedBy"].ToString());
                    if (creator != null)
                    {
                        string msg = string.Format("Approval {0} for task \"{1}\"", status, task["Title"]);
                        InsertNotification(Convert.ToInt32(creator["UserID"]), taskId, msg, "Approval");
                    }
                }
            }
        }

        #endregion

        #region Workflow Status History

        public static void InsertStatusHistory(int taskId, string oldStatus, string newStatus, string changedBy)
        {
            string query = @"INSERT INTO WorkflowStatusHistory (TaskID, OldStatus, NewStatus, ChangedBy)
                VALUES (@TaskID, @OldStatus, @NewStatus, @ChangedBy)";
            ExecuteNonQuery(query,
                new SqlParameter("@TaskID", taskId),
                new SqlParameter("@OldStatus", (object)oldStatus ?? DBNull.Value),
                new SqlParameter("@NewStatus", newStatus),
                new SqlParameter("@ChangedBy", changedBy));
        }

        public static DataTable GetStatusHistory(int taskId)
        {
            string query = @"SELECT * FROM WorkflowStatusHistory WHERE TaskID=@TaskID ORDER BY ChangedDate DESC";
            return ExecuteQuery(query, new SqlParameter("@TaskID", taskId));
        }

        #endregion

        #region Workflow Notifications

        public static void InsertNotification(int userId, int? taskId, string message, string notificationType)
        {
            string query = @"INSERT INTO WorkflowNotifications (UserID, TaskID, Message, NotificationType)
                VALUES (@UserID, @TaskID, @Message, @NotificationType)";
            ExecuteNonQuery(query,
                new SqlParameter("@UserID", userId),
                new SqlParameter("@TaskID", (object)taskId ?? DBNull.Value),
                new SqlParameter("@Message", message),
                new SqlParameter("@NotificationType", notificationType));
        }

        public static void InsertWorkflowNotification(int userId, int? taskId, string message, string notificationType)
        {
            InsertNotification(userId, taskId, message, notificationType);
        }

        public static DataTable GetNotifications(int userId)
        {
            string query = @"SELECT TOP 50 n.*, s.NodeType AS StepNodeType
                FROM WorkflowNotifications n
                LEFT JOIN WorkflowTasks t ON n.TaskID = t.TaskID
                LEFT JOIN WorkflowInstanceSteps s ON t.StepID = s.StepID
                WHERE n.UserID=@UserID ORDER BY n.CreatedDate DESC";
            return ExecuteQuery(query, new SqlParameter("@UserID", userId));
        }

        public static int GetUnreadNotificationCount(int userId)
        {
            object result = ExecuteScalar("SELECT COUNT(*) FROM WorkflowNotifications WHERE UserID=@UserID AND IsRead=0",
                new SqlParameter("@UserID", userId));
            return Convert.ToInt32(result);
        }

        public static void MarkNotificationRead(int notificationId)
        {
            ExecuteNonQuery("UPDATE WorkflowNotifications SET IsRead=1 WHERE NotificationID=@ID",
                new SqlParameter("@ID", notificationId));
        }

        public static void MarkAllNotificationsRead(int userId)
        {
            ExecuteNonQuery("UPDATE WorkflowNotifications SET IsRead=1 WHERE UserID=@UserID AND IsRead=0",
                new SqlParameter("@UserID", userId));
        }

        #endregion

        #region Bulk Upload Helpers

        private static object GetDbValue(DataRow row, string column, bool isDate = false, bool isDecimal = false)
        {
            if (!row.Table.Columns.Contains(column) || row[column] == null || row[column] == DBNull.Value ||
                string.IsNullOrWhiteSpace(row[column].ToString()))
                return DBNull.Value;

            string val = row[column].ToString().Trim();

            if (isDate)
            {
                DateTime dt;
                if (DateTime.TryParse(val, out dt))
                    return dt;
                return DBNull.Value;
            }

            if (isDecimal)
            {
                decimal d;
                if (decimal.TryParse(val, System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out d))
                    return d;
                return DBNull.Value;
            }

            return val;
        }

        #endregion

        #region Workflow Definitions

        public static DataTable GetWorkflowDefinitions()
        {
            return ExecuteQuery("SELECT DefinitionID, Name, Description, Status, CreatedDate, CreatedBy, ModifiedDate FROM WorkflowDefinitions WHERE IsActive=1 ORDER BY ModifiedDate DESC, CreatedDate DESC");
        }

        public static DataRow GetWorkflowDefinitionById(int id)
        {
            DataTable dt = ExecuteQuery("SELECT * FROM WorkflowDefinitions WHERE DefinitionID=@ID AND IsActive=1",
                new SqlParameter("@ID", id));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static int InsertWorkflowDefinition(string name, string description, string workflowJson, string createdBy)
        {
            string query = @"INSERT INTO WorkflowDefinitions (Name, Description, WorkflowJSON, CreatedBy)
                VALUES (@Name, @Description, @JSON, @CreatedBy); SELECT CAST(SCOPE_IDENTITY() AS INT);";
            object result = ExecuteScalar(query,
                new SqlParameter("@Name", name),
                new SqlParameter("@Description", (object)description ?? DBNull.Value),
                new SqlParameter("@JSON", workflowJson),
                new SqlParameter("@CreatedBy", createdBy));
            return Convert.ToInt32(result);
        }

        public static void UpdateWorkflowDefinition(int id, string name, string description, string workflowJson, string modifiedBy)
        {
            string query = @"UPDATE WorkflowDefinitions SET Name=@Name, Description=@Description,
                WorkflowJSON=@JSON, ModifiedDate=GETDATE(), ModifiedBy=@ModifiedBy WHERE DefinitionID=@ID";
            ExecuteNonQuery(query,
                new SqlParameter("@ID", id),
                new SqlParameter("@Name", name),
                new SqlParameter("@Description", (object)description ?? DBNull.Value),
                new SqlParameter("@JSON", workflowJson),
                new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static void UpdateWorkflowDefinitionStatus(int id, string status, string modifiedBy)
        {
            ExecuteNonQuery("UPDATE WorkflowDefinitions SET Status=@Status, ModifiedDate=GETDATE(), ModifiedBy=@ModifiedBy WHERE DefinitionID=@ID",
                new SqlParameter("@ID", id), new SqlParameter("@Status", status), new SqlParameter("@ModifiedBy", modifiedBy));
        }

        public static void DeleteWorkflowDefinition(int id, string modifiedBy)
        {
            ExecuteNonQuery("UPDATE WorkflowDefinitions SET IsActive=0, ModifiedDate=GETDATE(), ModifiedBy=@ModifiedBy WHERE DefinitionID=@ID",
                new SqlParameter("@ID", id), new SqlParameter("@ModifiedBy", modifiedBy));
        }

        #endregion

        #region Workflow Messages

        public static DataTable GetMessages(int userId1, int userId2)
        {
            string query = @"SELECT m.MessageID, m.SenderID, m.ReceiverID, m.Message, m.IsRead, m.SentDate,
                s.FullName AS SenderName FROM WorkflowMessages m
                INNER JOIN AppUsers s ON m.SenderID = s.UserID
                WHERE (m.SenderID=@U1 AND m.ReceiverID=@U2) OR (m.SenderID=@U2 AND m.ReceiverID=@U1)
                ORDER BY m.SentDate ASC";
            return ExecuteQuery(query, new SqlParameter("@U1", userId1), new SqlParameter("@U2", userId2));
        }

        public static int SendMessage(int senderId, int receiverId, string message)
        {
            string query = @"INSERT INTO WorkflowMessages (SenderID, ReceiverID, Message)
                VALUES (@SenderID, @ReceiverID, @Message); SELECT CAST(SCOPE_IDENTITY() AS INT);";
            return Convert.ToInt32(ExecuteScalar(query,
                new SqlParameter("@SenderID", senderId),
                new SqlParameter("@ReceiverID", receiverId),
                new SqlParameter("@Message", message)));
        }

        public static void MarkMessagesRead(int receiverId, int senderId)
        {
            ExecuteNonQuery("UPDATE WorkflowMessages SET IsRead=1 WHERE ReceiverID=@RID AND SenderID=@SID AND IsRead=0",
                new SqlParameter("@RID", receiverId), new SqlParameter("@SID", senderId));
        }

        public static DataTable GetMessageContacts(int userId)
        {
            string query = @"SELECT u.UserID, u.FullName,
                (SELECT COUNT(*) FROM WorkflowMessages WHERE SenderID=u.UserID AND ReceiverID=@UID AND IsRead=0) AS UnreadCount
                FROM AppUsers u WHERE u.IsEnabled=1 AND u.UserID<>@UID ORDER BY u.FullName";
            return ExecuteQuery(query, new SqlParameter("@UID", userId));
        }

        #endregion

        #region Workflow Engine - Table Fields

        public static DataTable GetTableFields(string tableName)
        {
            // Whitelist to prevent SQL injection
            string[] allowed = { "DemandFund", "SpendingAllocation", "ApprovedFundingPrograms", "FundingLineItems" };
            bool valid = false;
            foreach (string a in allowed) { if (a.Equals(tableName, StringComparison.OrdinalIgnoreCase)) { tableName = a; valid = true; break; } }
            if (!valid) return new DataTable();

            string query = @"SELECT COLUMN_NAME, DATA_TYPE 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_NAME = @Table 
                ORDER BY ORDINAL_POSITION";
            return ExecuteQuery(query, new SqlParameter("@Table", tableName));
        }

        public static DataRow GetLinkedRecord(string tableName, int recordId)
        {
            string[] allowed = { "DemandFund", "SpendingAllocation", "ApprovedFundingPrograms", "FundingLineItems" };
            bool valid = false;
            foreach (string a in allowed) { if (a.Equals(tableName, StringComparison.OrdinalIgnoreCase)) { tableName = a; valid = true; break; } }
            if (!valid) return null;

            string pkCol = tableName == "DemandFund" ? "ID" : "ID";
            string query = "SELECT * FROM [" + tableName + "] WHERE [" + pkCol + "] = @ID";
            DataTable dt = ExecuteQuery(query, new SqlParameter("@ID", recordId));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static DataTable GetLinkedRecordsList(string tableName)
        {
            string[] allowed = { "DemandFund", "SpendingAllocation", "ApprovedFundingPrograms", "FundingLineItems" };
            bool valid = false;
            foreach (string a in allowed) { if (a.Equals(tableName, StringComparison.OrdinalIgnoreCase)) { tableName = a; valid = true; break; } }
            if (!valid) return new DataTable();

            string displayCol;
            switch (tableName)
            {
                case "DemandFund": displayCol = "ID, InitiativeTitle AS DisplayText"; break;
                case "SpendingAllocation": displayCol = "ID, ISNULL(Description,'SA-'+CAST(ID AS VARCHAR)) AS DisplayText"; break;
                case "ApprovedFundingPrograms": displayCol = "ID, ISNULL(Title,'AFP-'+CAST(ID AS VARCHAR)) AS DisplayText"; break;
                case "FundingLineItems": displayCol = "ID, ISNULL(Title,'FLI-'+CAST(ID AS VARCHAR)) AS DisplayText"; break;
                default: return new DataTable();
            }
            string query = "SELECT TOP 200 " + displayCol + " FROM [" + tableName + "] ORDER BY ID DESC";
            return ExecuteQuery(query);
        }

        #endregion

        #region Workflow Engine - Instances

        public static int CreateWorkflowInstance(int definitionId, string linkedTable, int linkedRecordId,
            int initiatedByUserId, string initiatedByName, string workflowJson)
        {
            string query = @"INSERT INTO WorkflowInstances (DefinitionID, LinkedTable, LinkedRecordID, 
                InitiatedByUserID, InitiatedByName, WorkflowJSON, Status)
                VALUES (@DefID, @Table, @RecID, @UserID, @UserName, @JSON, 'Running');
                SELECT SCOPE_IDENTITY();";
            object result = ExecuteScalar(query,
                new SqlParameter("@DefID", definitionId),
                new SqlParameter("@Table", linkedTable),
                new SqlParameter("@RecID", linkedRecordId),
                new SqlParameter("@UserID", initiatedByUserId),
                new SqlParameter("@UserName", initiatedByName ?? (object)DBNull.Value),
                new SqlParameter("@JSON", workflowJson));
            return Convert.ToInt32(result);
        }

        public static int InsertWorkflowInstanceStep(int instanceId, int nodeId, string nodeType,
            string nodeLabel, string status, int? assignedToUserId, string assignedToName)
        {
            string query = @"INSERT INTO WorkflowInstanceSteps (InstanceID, NodeId, NodeType, NodeLabel, Status, AssignedToUserID, AssignedToName)
                VALUES (@InstID, @NodeId, @NodeType, @Label, @Status, @UserID, @UserName);
                SELECT SCOPE_IDENTITY();";
            object result = ExecuteScalar(query,
                new SqlParameter("@InstID", instanceId),
                new SqlParameter("@NodeId", nodeId),
                new SqlParameter("@NodeType", nodeType),
                new SqlParameter("@Label", nodeLabel ?? (object)DBNull.Value),
                new SqlParameter("@Status", status),
                new SqlParameter("@UserID", assignedToUserId.HasValue ? (object)assignedToUserId.Value : DBNull.Value),
                new SqlParameter("@UserName", assignedToName ?? (object)DBNull.Value));
            return Convert.ToInt32(result);
        }

        public static void UpdateWorkflowInstanceStepStatus(int stepId, string status, string actionBy, string comments)
        {
            ExecuteNonQuery(@"UPDATE WorkflowInstanceSteps SET Status=@Status, ActionDate=GETDATE(), 
                ActionBy=@ActionBy, Comments=@Comments WHERE StepID=@StepID",
                new SqlParameter("@StepID", stepId),
                new SqlParameter("@Status", status),
                new SqlParameter("@ActionBy", actionBy ?? (object)DBNull.Value),
                new SqlParameter("@Comments", comments ?? (object)DBNull.Value));
        }

        public static void UpdateWorkflowInstanceStatus(int instanceId, string status)
        {
            string query = "UPDATE WorkflowInstances SET Status=@Status";
            if (status == "Completed" || status == "Cancelled" || status == "Rejected")
                query += ", CompletedDate=GETDATE()";
            query += " WHERE InstanceID=@ID";
            ExecuteNonQuery(query, new SqlParameter("@ID", instanceId), new SqlParameter("@Status", status));
        }

        public static void UpdateWorkflowInstanceCurrentNode(int instanceId, int nodeId)
        {
            ExecuteNonQuery("UPDATE WorkflowInstances SET CurrentNodeId=@NodeId WHERE InstanceID=@ID",
                new SqlParameter("@ID", instanceId), new SqlParameter("@NodeId", nodeId));
        }

        public static DataRow GetWorkflowInstanceById(int instanceId)
        {
            DataTable dt = ExecuteQuery("SELECT * FROM WorkflowInstances WHERE InstanceID=@ID",
                new SqlParameter("@ID", instanceId));
            return dt.Rows.Count > 0 ? dt.Rows[0] : null;
        }

        public static DataTable GetWorkflowInstanceSteps(int instanceId)
        {
            return ExecuteQuery(@"SELECT s.*, u.FullName AS AssignedUserFullName 
                FROM WorkflowInstanceSteps s 
                LEFT JOIN AppUsers u ON s.AssignedToUserID = u.UserID
                WHERE s.InstanceID=@ID ORDER BY s.StepID",
                new SqlParameter("@ID", instanceId));
        }

        public static DataTable GetActiveStepsForUser(int userId)
        {
            return ExecuteQuery(@"SELECT s.StepID, s.NodeType, s.NodeLabel, s.Status, s.CreatedDate,
                i.InstanceID, i.LinkedTable, i.LinkedRecordID, i.Status AS InstanceStatus,
                d.Name AS WorkflowName
                FROM WorkflowInstanceSteps s
                INNER JOIN WorkflowInstances i ON s.InstanceID = i.InstanceID
                INNER JOIN WorkflowDefinitions d ON i.DefinitionID = d.DefinitionID
                WHERE s.AssignedToUserID = @UID AND s.Status IN ('Pending','Active') AND i.Status = 'Running'
                ORDER BY s.CreatedDate DESC",
                new SqlParameter("@UID", userId));
        }

        public static DataTable GetPublishedWorkflowsForTable(string tableName)
        {
            return ExecuteQuery(@"SELECT DefinitionID, Name, Description FROM WorkflowDefinitions 
                WHERE LinkedTable=@Table AND Status='Published' AND IsActive=1 ORDER BY Name",
                new SqlParameter("@Table", tableName));
        }

        public static int InsertWorkflowTaskFromInstance(string title, string description, string status,
            string priority, int? assignedToUserId, string assignedToName, int? instanceId, int? stepId,
            string linkedTable, int? linkedRecordId, string createdBy)
        {
            string query = @"INSERT INTO WorkflowTasks (Title, Description, Status, Priority, 
                AssignedToUserID, AssignedToName, InstanceID, StepID, LinkedTable, LinkedRecordID, CreatedBy)
                VALUES (@Title, @Desc, @Status, @Priority, @UserID, @UserName, @InstID, @StepID, @Table, @RecID, @By);
                SELECT SCOPE_IDENTITY();";
            object result = ExecuteScalar(query,
                new SqlParameter("@Title", title),
                new SqlParameter("@Desc", description ?? (object)DBNull.Value),
                new SqlParameter("@Status", status),
                new SqlParameter("@Priority", priority),
                new SqlParameter("@UserID", assignedToUserId.HasValue ? (object)assignedToUserId.Value : DBNull.Value),
                new SqlParameter("@UserName", assignedToName ?? (object)DBNull.Value),
                new SqlParameter("@InstID", instanceId.HasValue ? (object)instanceId.Value : DBNull.Value),
                new SqlParameter("@StepID", stepId.HasValue ? (object)stepId.Value : DBNull.Value),
                new SqlParameter("@Table", linkedTable ?? (object)DBNull.Value),
                new SqlParameter("@RecID", linkedRecordId.HasValue ? (object)linkedRecordId.Value : DBNull.Value),
                new SqlParameter("@By", createdBy ?? (object)DBNull.Value));
            return Convert.ToInt32(result);
        }

        #endregion

        #region Workflow Engine - Dashboard & Stats

        public static DataTable GetWorkflowDashboardStats(int userId)
        {
            string query = @"SELECT 
                (SELECT COUNT(*) FROM WorkflowTasks WHERE IsActive=1 AND Status='Done') AS CompletedTasks,
                (SELECT COUNT(*) FROM WorkflowTasks WHERE IsActive=1 AND Status IN ('Backlog','ToDo','InProgress','Review')) AS PendingTasks,
                (SELECT COUNT(*) FROM WorkflowInstanceSteps WHERE AssignedToUserID=@UID AND Status IN ('Pending','Active')) AS MyPendingActions,
                (SELECT COUNT(*) FROM WorkflowInstances WHERE Status='Running') AS RunningWorkflows,
                (SELECT COUNT(*) FROM WorkflowInstances WHERE Status='Completed') AS CompletedWorkflows,
                (SELECT COUNT(*) FROM WorkflowNotifications WHERE UserID=@UID AND IsRead=0) AS UnreadNotifications";
            return ExecuteQuery(query, new SqlParameter("@UID", userId));
        }

        public static DataTable GetGlobalNotifications(int userId, int top)
        {
            string query = @"SELECT TOP (@Top) n.NotificationID, n.Message, n.NotificationType, n.IsRead, n.CreatedDate,
                n.LinkedTable, n.LinkedRecordID, n.InstanceID, n.TaskID,
                s.NodeType AS StepNodeType
                FROM WorkflowNotifications n
                LEFT JOIN WorkflowTasks t ON n.TaskID = t.TaskID
                LEFT JOIN WorkflowInstanceSteps s ON t.StepID = s.StepID
                WHERE n.UserID=@UID ORDER BY n.CreatedDate DESC";
            return ExecuteQuery(query, new SqlParameter("@UID", userId), new SqlParameter("@Top", top));
        }

        public static DataTable GetUsersByRole(int roleId)
        {
            return ExecuteQuery("SELECT UserID, FullName FROM AppUsers WHERE RoleID=@RID AND IsEnabled=1 ORDER BY FullName",
                new SqlParameter("@RID", roleId));
        }

        #endregion

        #region Workflow Engine - Ongoing Workflows & History

        public static DataTable GetOngoingWorkflows()
        {
            string query = @"SELECT wi.InstanceID, wi.DefinitionID, wd.Name AS WorkflowName, wi.LinkedTable, wi.LinkedRecordID,
                wi.Status, wi.CurrentNodeId, wi.InitiatedByName, wi.StartedDate, wi.CompletedDate
                FROM WorkflowInstances wi
                INNER JOIN WorkflowDefinitions wd ON wi.DefinitionID = wd.DefinitionID
                ORDER BY wi.StartedDate DESC";
            return ExecuteQuery(query);
        }

        public static DataTable GetWorkflowHistoryForRecord(string linkedTable, int linkedRecordId)
        {
            string query = @"SELECT wi.InstanceID, wd.Name AS WorkflowName, wi.Status, wi.InitiatedByName,
                wi.StartedDate, wi.CompletedDate
                FROM WorkflowInstances wi
                INNER JOIN WorkflowDefinitions wd ON wi.DefinitionID = wd.DefinitionID
                WHERE wi.LinkedTable = @Table AND wi.LinkedRecordID = @RecordID
                ORDER BY wi.StartedDate DESC";
            return ExecuteQuery(query, new SqlParameter("@Table", linkedTable), new SqlParameter("@RecordID", linkedRecordId));
        }

        public static void TerminateWorkflowInstance(int instanceId, string terminatedBy)
        {
            ExecuteNonQuery(@"UPDATE WorkflowInstances SET Status='Cancelled', CompletedDate=GETDATE() WHERE InstanceID=@ID",
                new SqlParameter("@ID", instanceId));
            ExecuteNonQuery(@"UPDATE WorkflowInstanceSteps SET Status='Skipped', ActionBy=@User, ActionDate=GETDATE()
                WHERE InstanceID=@ID AND Status IN ('Pending','Active')",
                new SqlParameter("@ID", instanceId), new SqlParameter("@User", terminatedBy));
        }

        public static DataTable GetWorkflowTaskByInstanceStep(int instanceId, int stepId)
        {
            return ExecuteQuery("SELECT TaskID FROM WorkflowTasks WHERE InstanceID=@IID AND StepID=@SID",
                new SqlParameter("@IID", instanceId), new SqlParameter("@SID", stepId));
        }

        #endregion

        #region Workflow Engine - My Tasks & My Approvals

        public static DataTable GetMyWorkflowTasks(int userId)
        {
            string query = @"SELECT t.TaskID, t.Title, t.Description, t.Status, t.Priority, t.DueDate,
                t.CompletionPercentage, t.LinkedTable, t.LinkedRecordID, t.InstanceID, t.StepID,
                t.CreatedBy, t.CreatedDate,
                wi.Status AS InstanceStatus, wd.Name AS WorkflowName,
                s.NodeType, s.NodeLabel, s.Status AS StepStatus
                FROM WorkflowTasks t
                INNER JOIN WorkflowInstanceSteps s ON t.StepID = s.StepID
                INNER JOIN WorkflowInstances wi ON t.InstanceID = wi.InstanceID
                INNER JOIN WorkflowDefinitions wd ON wi.DefinitionID = wd.DefinitionID
                WHERE t.AssignedToUserID = @UID AND s.NodeType = 'user-task'
                AND s.Status IN ('Pending','Active') AND wi.Status = 'Running'
                ORDER BY t.CreatedDate DESC";
            return ExecuteQuery(query, new SqlParameter("@UID", userId));
        }

        public static DataTable GetMyWorkflowApprovals(int userId)
        {
            string query = @"SELECT t.TaskID, t.Title, t.Description, t.Status, t.Priority,
                t.LinkedTable, t.LinkedRecordID, t.InstanceID, t.StepID,
                t.CreatedBy, t.CreatedDate,
                wi.Status AS InstanceStatus, wd.Name AS WorkflowName,
                s.NodeType, s.NodeLabel, s.Status AS StepStatus
                FROM WorkflowTasks t
                INNER JOIN WorkflowInstanceSteps s ON t.StepID = s.StepID
                INNER JOIN WorkflowInstances wi ON t.InstanceID = wi.InstanceID
                INNER JOIN WorkflowDefinitions wd ON wi.DefinitionID = wd.DefinitionID
                WHERE t.AssignedToUserID = @UID AND s.NodeType = 'approval'
                AND s.Status IN ('Pending','Active') AND wi.Status = 'Running'
                ORDER BY t.CreatedDate DESC";
            return ExecuteQuery(query, new SqlParameter("@UID", userId));
        }

        public static void UpdateTaskCompletionPercentage(int taskId, int percentage)
        {
            ExecuteNonQuery("UPDATE WorkflowTasks SET CompletionPercentage = @Pct WHERE TaskID = @TID",
                new SqlParameter("@TID", taskId), new SqlParameter("@Pct", percentage));
        }

        #endregion
    }
}
