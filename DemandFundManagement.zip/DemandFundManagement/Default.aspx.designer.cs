namespace DemandFundManagement
{
    public partial class Default
    {
        protected global::System.Web.UI.WebControls.Label lblTotalDemands;
        protected global::System.Web.UI.WebControls.Label lblActiveDemands;
        protected global::System.Web.UI.WebControls.Label lblInProgress;
        protected global::System.Web.UI.WebControls.Label lblCompleted;
        protected global::System.Web.UI.WebControls.Label lblDigitalProjects;
        protected global::System.Web.UI.WebControls.Label lblTotalSpending;
        protected global::System.Web.UI.WebControls.Label lblTotalFundingPrograms;
        protected global::System.Web.UI.WebControls.Label lblTotalLineItems;
        protected global::System.Web.UI.WebControls.Label lblTotalActualAmount;
        protected global::System.Web.UI.WebControls.Label lblTotalAllocationAmount;
        protected global::System.Web.UI.WebControls.Label lblTotalFundAmount;
        protected global::System.Web.UI.WebControls.Label lblTotalConsumed;
        protected global::System.Web.UI.WebControls.Label lblTotalAvailable;
        protected global::System.Web.UI.WebControls.HiddenField hdnPhaseLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnPhaseData;
        protected global::System.Web.UI.WebControls.HiddenField hdnInitTypeLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnInitTypeData;
        protected global::System.Web.UI.WebControls.HiddenField hdnVerticalLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnVerticalData;
        protected global::System.Web.UI.WebControls.HiddenField hdnFundingLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnFundingData;
        protected global::System.Web.UI.WebControls.HiddenField hdnMonthlyLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnMonthlyData;
        protected global::System.Web.UI.WebControls.HiddenField hdnSpendTeamLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnSpendTeamData;
        protected global::System.Web.UI.WebControls.HiddenField hdnProgramStatusLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnProgramStatusData;
        protected global::System.Web.UI.WebControls.HiddenField hdnSpendPlatformLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnSpendPlatformData;
        protected global::System.Web.UI.WebControls.HiddenField hdnLineItemVendorLabels;
        protected global::System.Web.UI.WebControls.HiddenField hdnLineItemVendorData;
        protected global::System.Web.UI.WebControls.GridView gvRecentDemands;
        protected global::System.Web.UI.WebControls.GridView gvRecentSpending;
        protected global::System.Web.UI.WebControls.HyperLink lnkViewAllSpending;
        protected global::System.Web.UI.WebControls.GridView gvRecentPrograms;
        protected global::System.Web.UI.WebControls.HyperLink lnkViewAllPrograms;
        protected global::System.Web.UI.WebControls.GridView gvRecentLineItems;
        protected global::System.Web.UI.WebControls.HyperLink lnkViewAllLineItems;
        protected global::System.Web.UI.WebControls.Label lblWfCompleted;
        protected global::System.Web.UI.WebControls.Label lblWfPending;
        protected global::System.Web.UI.WebControls.Label lblWfMyActions;
        protected global::System.Web.UI.WebControls.Label lblWfRunning;
        protected global::System.Web.UI.WebControls.Label lblWfCompletedWf;
    }
}
