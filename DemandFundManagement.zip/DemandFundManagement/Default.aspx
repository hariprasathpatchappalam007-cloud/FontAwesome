<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="DemandFundManagement.Default" %>

<asp:Content ID="HeadContent" ContentPlaceHolderID="HeadContent" runat="server">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        .chart-container { position: relative; height: 320px; width: 100%; }
        .chart-row { display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 20px; }
        .chart-col { flex: 1; min-width: 400px; }
    </style>
</asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <h2 class="page-title"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</h2>

    <!-- Summary Cards -->
    <div class="dashboard-cards">
        <div class="dash-card">
            <div class="dash-number"><asp:Label ID="lblTotalDemands" runat="server" Text="0" /></div>
            <div class="dash-label">Total Demands</div>
        </div>
        <div class="dash-card">
            <div class="dash-number"><asp:Label ID="lblActiveDemands" runat="server" Text="0" /></div>
            <div class="dash-label">Active Demands</div>
        </div>
        <div class="dash-card">
            <div class="dash-number"><asp:Label ID="lblInProgress" runat="server" Text="0" /></div>
            <div class="dash-label">In Progress</div>
        </div>
        <div class="dash-card">
            <div class="dash-number"><asp:Label ID="lblCompleted" runat="server" Text="0" /></div>
            <div class="dash-label">Completed</div>
        </div>
        <div class="dash-card">
            <div class="dash-number"><asp:Label ID="lblDigitalProjects" runat="server" Text="0" /></div>
            <div class="dash-label">Digital Projects</div>
        </div>
        <div class="dash-card">
            <div class="dash-number"><asp:Label ID="lblTotalSpending" runat="server" Text="0" /></div>
            <div class="dash-label">Spending Allocations</div>
        </div>
        <div class="dash-card">
            <div class="dash-number"><asp:Label ID="lblTotalFundingPrograms" runat="server" Text="0" /></div>
            <div class="dash-label">Approved Programs</div>
        </div>
        <div class="dash-card">
            <div class="dash-number"><asp:Label ID="lblTotalLineItems" runat="server" Text="0" /></div>
            <div class="dash-label">Funding Line Items</div>
        </div>
    </div>

    <!-- Financial Summary Cards -->
    <div class="dashboard-cards" style="margin-top:-10px;">
        <div class="dash-card">
            <div class="dash-number" style="font-size:24px;"><asp:Label ID="lblTotalActualAmount" runat="server" Text="0" /></div>
            <div class="dash-label">Total Actual Amount</div>
        </div>
        <div class="dash-card">
            <div class="dash-number" style="font-size:24px;"><asp:Label ID="lblTotalAllocationAmount" runat="server" Text="0" /></div>
            <div class="dash-label">Total Allocation Amount</div>
        </div>
        <div class="dash-card">
            <div class="dash-number" style="font-size:24px;"><asp:Label ID="lblTotalFundAmount" runat="server" Text="0" /></div>
            <div class="dash-label">Total Fund Amount</div>
        </div>
        <div class="dash-card">
            <div class="dash-number" style="font-size:24px;"><asp:Label ID="lblTotalConsumed" runat="server" Text="0" /></div>
            <div class="dash-label">Total Consumed</div>
        </div>
        <div class="dash-card">
            <div class="dash-number" style="font-size:24px;"><asp:Label ID="lblTotalAvailable" runat="server" Text="0" /></div>
            <div class="dash-label">Total Available</div>
        </div>
    </div>

    <!-- Workflow Status Cards -->
    <div class="dashboard-cards" style="margin-top:-10px;">
        <div class="dash-card" style="border-left:4px solid #4CAF50;">
            <div class="dash-number"><asp:Label ID="lblWfCompleted" runat="server" Text="0" /></div>
            <div class="dash-label"><span class="glyphicon glyphicon-ok" style="color:#4CAF50;"></span> Completed Tasks</div>
        </div>
        <a href="Forms/MyTasks.aspx" class="dash-card" style="border-left:4px solid #FF9800;text-decoration:none;color:inherit;cursor:pointer;">
            <div class="dash-number"><asp:Label ID="lblWfPending" runat="server" Text="0" /></div>
            <div class="dash-label"><span class="glyphicon glyphicon-time" style="color:#FF9800;"></span> Pending Tasks</div>
        </a>
        <a href="Forms/MyApprovals.aspx" class="dash-card" style="border-left:4px solid #f44336;text-decoration:none;color:inherit;cursor:pointer;">
            <div class="dash-number"><asp:Label ID="lblWfMyActions" runat="server" Text="0" /></div>
            <div class="dash-label"><span class="glyphicon glyphicon-exclamation-sign" style="color:#f44336;"></span> My Pending Actions</div>
        </a>
        <a href="Forms/WorkflowInstances.aspx" class="dash-card" style="border-left:4px solid #2196F3;text-decoration:none;color:inherit;cursor:pointer;">
            <div class="dash-number"><asp:Label ID="lblWfRunning" runat="server" Text="0" /></div>
            <div class="dash-label"><span class="glyphicon glyphicon-play" style="color:#2196F3;"></span> Running Workflows</div>
        </a>
        <div class="dash-card" style="border-left:4px solid #9C27B0;">
            <div class="dash-number"><asp:Label ID="lblWfCompletedWf" runat="server" Text="0" /></div>
            <div class="dash-label"><span class="glyphicon glyphicon-ok-circle" style="color:#9C27B0;"></span> Completed Workflows</div>
        </div>
    </div>

    <!-- Charts Row 1 -->
    <div class="chart-row">
        <div class="chart-col">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-signal"></span> Demands by Phase / Status</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartPhase"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="chart-col">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-tags"></span> Demands by Initiative Type</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartInitiativeType"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row 2 -->
    <div class="chart-row">
        <div class="chart-col">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-th-large"></span> Demands by Business Vertical</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartVertical"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="chart-col">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-usd"></span> Demands by Funding Source</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartFunding"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart Row 3: Monthly Trend -->
    <div class="chart-row">
        <div class="chart-col" style="min-width:100%;">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-stats"></span> Monthly Demand Trend</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartMonthly"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row 4: Spending & Funding -->
    <div class="chart-row">
        <div class="chart-col">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-usd"></span> Spending Allocation by Team</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartSpendByTeam"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="chart-col">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-ok-circle"></span> Approved Programs by Status</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartProgramStatus"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row 5: Spending Trend & Line Items by Vendor -->
    <div class="chart-row">
        <div class="chart-col">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-transfer"></span> Spending Allocation by Platform</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartSpendByPlatform"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="chart-col">
            <div class="panel">
                <div class="panel-header"><span class="glyphicon glyphicon-th"></span> Line Items by Vendor (Top 10)</div>
                <div class="panel-body">
                    <div class="chart-container">
                        <canvas id="chartLineItemVendor"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Hidden fields for chart data (populated from server) -->
    <asp:HiddenField ID="hdnPhaseLabels" runat="server" />
    <asp:HiddenField ID="hdnPhaseData" runat="server" />
    <asp:HiddenField ID="hdnInitTypeLabels" runat="server" />
    <asp:HiddenField ID="hdnInitTypeData" runat="server" />
    <asp:HiddenField ID="hdnVerticalLabels" runat="server" />
    <asp:HiddenField ID="hdnVerticalData" runat="server" />
    <asp:HiddenField ID="hdnFundingLabels" runat="server" />
    <asp:HiddenField ID="hdnFundingData" runat="server" />
    <asp:HiddenField ID="hdnMonthlyLabels" runat="server" />
    <asp:HiddenField ID="hdnMonthlyData" runat="server" />
    <asp:HiddenField ID="hdnSpendTeamLabels" runat="server" />
    <asp:HiddenField ID="hdnSpendTeamData" runat="server" />
    <asp:HiddenField ID="hdnProgramStatusLabels" runat="server" />
    <asp:HiddenField ID="hdnProgramStatusData" runat="server" />
    <asp:HiddenField ID="hdnSpendPlatformLabels" runat="server" />
    <asp:HiddenField ID="hdnSpendPlatformData" runat="server" />
    <asp:HiddenField ID="hdnLineItemVendorLabels" runat="server" />
    <asp:HiddenField ID="hdnLineItemVendorData" runat="server" />

    <!-- Recent Grid -->
    <div class="panel">
        <div class="panel-header"><span class="glyphicon glyphicon-time"></span> Recent Demand Fund Entries</div>
        <div class="panel-body">
            <asp:GridView ID="gvRecentDemands" runat="server" AutoGenerateColumns="false" 
                CssClass="grid-view" EmptyDataText="No demand fund entries found."
                AllowPaging="true" PageSize="10" OnPageIndexChanging="gvRecentDemands_PageIndexChanging">
                <Columns>
                    <asp:BoundField DataField="ID" HeaderText="ID" ItemStyle-Width="50px" />
                    <asp:BoundField DataField="InitiativeTitle" HeaderText="Initiative Title" />
                    <asp:BoundField DataField="DemandType" HeaderText="Demand Type" />
                    <asp:BoundField DataField="ProjectPhase" HeaderText="Phase" />
                    <asp:BoundField DataField="BusinessVertical" HeaderText="Business Vertical" />
                    <asp:BoundField DataField="Initiative_Type" HeaderText="Initiative Type" />
                    <asp:BoundField DataField="CreatedDate" HeaderText="Created" DataFormatString="{0:dd-MMM-yyyy}" />
                    <asp:HyperLinkField Text="Edit" DataNavigateUrlFields="ID" 
                        DataNavigateUrlFormatString="~/Forms/DemandFundEntry.aspx?id={0}" 
                        ItemStyle-Width="60px" ControlStyle-CssClass="btn btn-sm btn-primary" />
                </Columns>
                <PagerStyle CssClass="grid-pager" />
            </asp:GridView>
        </div>
    </div>

    <!-- Recent Spending Allocations -->
    <div class="panel">
        <div class="panel-header"><span class="glyphicon glyphicon-usd"></span> Recent Spending Allocations
            <span class="record-count"><asp:HyperLink ID="lnkViewAllSpending" runat="server" NavigateUrl="~/Forms/SpendingAllocation.aspx" Text="View All &raquo;" CssClass="view-all-link" /></span>
        </div>
        <div class="panel-body" style="overflow-x:auto;">
            <asp:GridView ID="gvRecentSpending" runat="server" AutoGenerateColumns="false"
                CssClass="grid-view" EmptyDataText="No spending allocations found."
                AllowPaging="true" PageSize="5" OnPageIndexChanging="gvRecentSpending_PageIndexChanging">
                <Columns>
                    <asp:BoundField DataField="ID" HeaderText="ID" ItemStyle-Width="50px" />
                    <asp:BoundField DataField="Date" HeaderText="Date" DataFormatString="{0:dd-MMM-yyyy}" />
                    <asp:BoundField DataField="FundingLineItem" HeaderText="Funding Line Item" />
                    <asp:BoundField DataField="Description" HeaderText="Description" />
                    <asp:BoundField DataField="Team" HeaderText="Team" />
                    <asp:BoundField DataField="Platform" HeaderText="Platform" />
                    <asp:BoundField DataField="Vendor" HeaderText="Vendor" />
                    <asp:BoundField DataField="ActualAmount" HeaderText="Actual Amount" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="AllocationAmount" HeaderText="Allocation" DataFormatString="{0:N2}" />
                    <asp:HyperLinkField Text="Edit" DataNavigateUrlFields="ID"
                        DataNavigateUrlFormatString="~/Forms/SpendingAllocationEntry.aspx?id={0}"
                        ItemStyle-Width="50px" ControlStyle-CssClass="btn btn-sm btn-primary" />
                </Columns>
                <PagerStyle CssClass="grid-pager" />
            </asp:GridView>
        </div>
    </div>

    <!-- Recent Approved Funding Programs -->
    <div class="panel">
        <div class="panel-header"><span class="glyphicon glyphicon-ok-circle"></span> Recent Approved Funding Programs
            <span class="record-count"><asp:HyperLink ID="lnkViewAllPrograms" runat="server" NavigateUrl="~/Forms/ApprovedFundingPrograms.aspx" Text="View All &raquo;" CssClass="view-all-link" /></span>
        </div>
        <div class="panel-body" style="overflow-x:auto;">
            <asp:GridView ID="gvRecentPrograms" runat="server" AutoGenerateColumns="false"
                CssClass="grid-view" EmptyDataText="No approved funding programs found."
                AllowPaging="true" PageSize="5" OnPageIndexChanging="gvRecentPrograms_PageIndexChanging">
                <Columns>
                    <asp:BoundField DataField="ID" HeaderText="ID" ItemStyle-Width="50px" />
                    <asp:BoundField DataField="Title" HeaderText="Title" />
                    <asp:BoundField DataField="Type" HeaderText="Type" />
                    <asp:BoundField DataField="Status" HeaderText="Status" />
                    <asp:BoundField DataField="FundAmount" HeaderText="Fund Amount" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="Consumed" HeaderText="Consumed" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="Available" HeaderText="Available" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="ProgramOwner" HeaderText="Owner" />
                    <asp:HyperLinkField Text="Edit" DataNavigateUrlFields="ID"
                        DataNavigateUrlFormatString="~/Forms/ApprovedFundingProgramEntry.aspx?id={0}"
                        ItemStyle-Width="50px" ControlStyle-CssClass="btn btn-sm btn-primary" />
                </Columns>
                <PagerStyle CssClass="grid-pager" />
            </asp:GridView>
        </div>
    </div>

    <!-- Recent Funding Line Items -->
    <div class="panel">
        <div class="panel-header"><span class="glyphicon glyphicon-th"></span> Recent Funding Line Items
            <span class="record-count"><asp:HyperLink ID="lnkViewAllLineItems" runat="server" NavigateUrl="~/Forms/FundingLineItems.aspx" Text="View All &raquo;" CssClass="view-all-link" /></span>
        </div>
        <div class="panel-body" style="overflow-x:auto;">
            <asp:GridView ID="gvRecentLineItems" runat="server" AutoGenerateColumns="false"
                CssClass="grid-view" EmptyDataText="No funding line items found."
                AllowPaging="true" PageSize="5" OnPageIndexChanging="gvRecentLineItems_PageIndexChanging">
                <Columns>
                    <asp:BoundField DataField="ID" HeaderText="ID" ItemStyle-Width="50px" />
                    <asp:BoundField DataField="ProgramTitle" HeaderText="Program" />
                    <asp:BoundField DataField="Title" HeaderText="Title" />
                    <asp:BoundField DataField="AllocationType" HeaderText="Type" />
                    <asp:BoundField DataField="Vendor" HeaderText="Vendor" />
                    <asp:BoundField DataField="Amount" HeaderText="Amount" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="Consumed" HeaderText="Consumed" DataFormatString="{0:N2}" />
                    <asp:BoundField DataField="RemainingAmount" HeaderText="Remaining" DataFormatString="{0:N2}" />
                    <asp:HyperLinkField Text="Edit" DataNavigateUrlFields="ID"
                        DataNavigateUrlFormatString="~/Forms/FundingLineItemEntry.aspx?id={0}"
                        ItemStyle-Width="50px" ControlStyle-CssClass="btn btn-sm btn-primary" />
                </Columns>
                <PagerStyle CssClass="grid-pager" />
            </asp:GridView>
        </div>
    </div>

    <script type="text/javascript">
        // Read theme colors from CSS custom properties
        function getThemeColor(varName) {
            return getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
        }
        function getThemeRgb() {
            return getComputedStyle(document.documentElement).getPropertyValue('--primary-rgb').trim();
        }

        function buildPalette() {
            var primary = getThemeColor('--primary');
            var primaryDark = getThemeColor('--primary-dark');
            var primaryLight = getThemeColor('--primary-light');
            var rgb = getThemeRgb();
            // Generate shades from primary by mixing with white at various opacities
            return [
                primary,
                primaryLight,
                'rgba(' + rgb + ', 0.75)',
                'rgba(' + rgb + ', 0.60)',
                'rgba(' + rgb + ', 0.48)',
                'rgba(' + rgb + ', 0.38)',
                'rgba(' + rgb + ', 0.28)',
                'rgba(' + rgb + ', 0.18)',
                primaryDark,
                'rgba(' + rgb + ', 0.85)',
                'rgba(' + rgb + ', 0.70)',
                'rgba(' + rgb + ', 0.55)',
                'rgba(' + rgb + ', 0.42)',
                'rgba(' + rgb + ', 0.32)',
                'rgba(' + rgb + ', 0.22)',
                'rgba(' + rgb + ', 0.50)',
                'rgba(' + rgb + ', 0.45)',
                'rgba(' + rgb + ', 0.40)',
                'rgba(' + rgb + ', 0.35)',
                'rgba(' + rgb + ', 0.30)'
            ];
        }

        var dibColors = buildPalette();
        var chartInstances = [];

        function safeParseJSON(val) {
            try { return JSON.parse(val || '[]'); }
            catch(e) { return []; }
        }

        function getChartColors(count) {
            var colors = [];
            for (var i = 0; i < count; i++) {
                colors.push(dibColors[i % dibColors.length]);
            }
            return colors;
        }

        function renderCharts() {
            // Destroy existing chart instances
            for (var i = 0; i < chartInstances.length; i++) {
                chartInstances[i].destroy();
            }
            chartInstances = [];

            dibColors = buildPalette();
            var primary = getThemeColor('--primary');
            var primaryDark = getThemeColor('--primary-dark');
            var primaryLight = getThemeColor('--primary-light');
            var rgb = getThemeRgb();
            // Phase Distribution - Doughnut
            var phaseLabels = safeParseJSON(document.getElementById('<%= hdnPhaseLabels.ClientID %>').value);
            var phaseData = safeParseJSON(document.getElementById('<%= hdnPhaseData.ClientID %>').value);
            if (phaseLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartPhase'), {
                    type: 'doughnut',
                    data: {
                        labels: phaseLabels,
                        datasets: [{
                            data: phaseData,
                            backgroundColor: getChartColors(phaseLabels.length),
                            borderWidth: 2,
                            borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { position: 'right', labels: { font: { size: 11 } } } }
                    }
                }));
            }

            // Initiative Type - Pie
            var initLabels = safeParseJSON(document.getElementById('<%= hdnInitTypeLabels.ClientID %>').value);
            var initData = safeParseJSON(document.getElementById('<%= hdnInitTypeData.ClientID %>').value);
            if (initLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartInitiativeType'), {
                    type: 'pie',
                    data: {
                        labels: initLabels,
                        datasets: [{
                            data: initData,
                            backgroundColor: getChartColors(initLabels.length),
                            borderWidth: 2,
                            borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { position: 'right', labels: { font: { size: 11 } } } }
                    }
                }));
            }

            // Business Vertical - Horizontal Bar
            var vertLabels = safeParseJSON(document.getElementById('<%= hdnVerticalLabels.ClientID %>').value);
            var vertData = safeParseJSON(document.getElementById('<%= hdnVerticalData.ClientID %>').value);
            if (vertLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartVertical'), {
                    type: 'bar',
                    data: {
                        labels: vertLabels,
                        datasets: [{
                            label: 'Demands',
                            data: vertData,
                            backgroundColor: primary,
                            borderColor: primaryDark,
                            borderWidth: 1,
                            borderRadius: 4
                        }]
                    },
                    options: {
                        indexAxis: 'y',
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: { x: { beginAtZero: true, ticks: { stepSize: 1 } } }
                    }
                }));
            }

            // Funding Source - Bar
            var fundLabels = safeParseJSON(document.getElementById('<%= hdnFundingLabels.ClientID %>').value);
            var fundData = safeParseJSON(document.getElementById('<%= hdnFundingData.ClientID %>').value);
            if (fundLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartFunding'), {
                    type: 'bar',
                    data: {
                        labels: fundLabels,
                        datasets: [{
                            label: 'Demands',
                            data: fundData,
                            backgroundColor: getChartColors(fundLabels.length),
                            borderWidth: 1,
                            borderRadius: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
                    }
                }));
            }

            // Monthly Trend - Line
            var monthLabels = safeParseJSON(document.getElementById('<%= hdnMonthlyLabels.ClientID %>').value);
            var monthData = safeParseJSON(document.getElementById('<%= hdnMonthlyData.ClientID %>').value);
            if (monthLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartMonthly'), {
                    type: 'line',
                    data: {
                        labels: monthLabels,
                        datasets: [{
                            label: 'Demands Created',
                            data: monthData,
                            borderColor: primary,
                            backgroundColor: 'rgba(' + rgb + ', 0.1)',
                            borderWidth: 3,
                            fill: true,
                            tension: 0.3,
                            pointBackgroundColor: primary,
                            pointRadius: 5
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: true, position: 'top' } },
                        scales: {
                            y: { beginAtZero: true, ticks: { stepSize: 1 } }
                        }
                    }
                }));
            }

            // Spending Allocation by Team - Horizontal Bar
            var spendTeamLabels = safeParseJSON(document.getElementById('<%= hdnSpendTeamLabels.ClientID %>').value);
            var spendTeamData = safeParseJSON(document.getElementById('<%= hdnSpendTeamData.ClientID %>').value);
            if (spendTeamLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartSpendByTeam'), {
                    type: 'bar',
                    data: {
                        labels: spendTeamLabels,
                        datasets: [{
                            label: 'Allocation Amount',
                            data: spendTeamData,
                            backgroundColor: primaryLight,
                            borderColor: primary,
                            borderWidth: 1,
                            borderRadius: 4
                        }]
                    },
                    options: {
                        indexAxis: 'y',
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: { x: { beginAtZero: true } }
                    }
                }));
            }

            // Approved Programs by Status - Doughnut
            var progStatusLabels = safeParseJSON(document.getElementById('<%= hdnProgramStatusLabels.ClientID %>').value);
            var progStatusData = safeParseJSON(document.getElementById('<%= hdnProgramStatusData.ClientID %>').value);
            if (progStatusLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartProgramStatus'), {
                    type: 'doughnut',
                    data: {
                        labels: progStatusLabels,
                        datasets: [{
                            data: progStatusData,
                            backgroundColor: getChartColors(progStatusLabels.length),
                            borderWidth: 2,
                            borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { position: 'right', labels: { font: { size: 11 } } } }
                    }
                }));
            }

            // Spending by Platform - Pie
            var spendPlatLabels = safeParseJSON(document.getElementById('<%= hdnSpendPlatformLabels.ClientID %>').value);
            var spendPlatData = safeParseJSON(document.getElementById('<%= hdnSpendPlatformData.ClientID %>').value);
            if (spendPlatLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartSpendByPlatform'), {
                    type: 'pie',
                    data: {
                        labels: spendPlatLabels,
                        datasets: [{
                            data: spendPlatData,
                            backgroundColor: getChartColors(spendPlatLabels.length),
                            borderWidth: 2,
                            borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { position: 'right', labels: { font: { size: 11 } } } }
                    }
                }));
            }

            // Line Items by Vendor - Bar
            var liVendorLabels = safeParseJSON(document.getElementById('<%= hdnLineItemVendorLabels.ClientID %>').value);
            var liVendorData = safeParseJSON(document.getElementById('<%= hdnLineItemVendorData.ClientID %>').value);
            if (liVendorLabels.length > 0) {
                chartInstances.push(new Chart(document.getElementById('chartLineItemVendor'), {
                    type: 'bar',
                    data: {
                        labels: liVendorLabels,
                        datasets: [{
                            label: 'Total Amount',
                            data: liVendorData,
                            backgroundColor: getChartColors(liVendorLabels.length),
                            borderWidth: 1,
                            borderRadius: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: { y: { beginAtZero: true } }
                    }
                }));
            }
        }

        window.addEventListener('load', function() { renderCharts(); });
        window.addEventListener('themeChanged', function() { renderCharts(); });
    </script>
</asp:Content>
