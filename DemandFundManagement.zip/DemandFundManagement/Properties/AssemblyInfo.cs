using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DemandFundManagement")]
[assembly: AssemblyDescription("Demand Fund Management System for Dubai Islamic Bank")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Dubai Islamic Bank")]
[assembly: AssemblyProduct("DemandFundManagement")]
[assembly: AssemblyCopyright("Copyright © Dubai Islamic Bank 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("a1b2c3d4-e5f6-7890-abcd-ef1234567890")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
