using System;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using DemandFundManagement.App_Code.DAL;
using DemandFundManagement.App_Code.Security;

namespace DemandFundManagement
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // If already authenticated, redirect to default
                if (HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    Response.Redirect("~/Default.aspx");
                }

                // Check if default admin needs to be created (first run)
                EnsureDefaultAdmin();
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ShowMessage("Please enter both username and password.", true);
                return;
            }

            try
            {
                DataRow user = DatabaseHelper.AuthenticateUser(username);

                if (user == null)
                {
                    ShowMessage("Invalid username or password.", true);
                    return;
                }

                // Check if user is enabled
                if (!Convert.ToBoolean(user["IsEnabled"]))
                {
                    ShowMessage("Your account has been disabled. Please contact the administrator.", true);
                    return;
                }

                // Verify password
                string storedHash = user["PasswordHash"].ToString();
                string storedSalt = user["PasswordSalt"].ToString();

                if (!PasswordHelper.VerifyPassword(password, storedHash, storedSalt))
                {
                    ShowMessage("Invalid username or password.", true);
                    return;
                }

                // Authentication successful - set session
                int userId = Convert.ToInt32(user["UserID"]);
                Session["UserID"] = userId;
                Session["Username"] = user["Username"].ToString();
                Session["FullName"] = user["FullName"].ToString();
                Session["RoleID"] = Convert.ToInt32(user["RoleID"]);
                Session["RoleName"] = user["RoleName"].ToString();

                // Update last login
                DatabaseHelper.UpdateLastLogin(userId);

                // Create authentication ticket
                FormsAuthentication.SetAuthCookie(username, false);

                // Redirect to default page
                string returnUrl = Request.QueryString["ReturnUrl"];
                if (!string.IsNullOrEmpty(returnUrl) && returnUrl.StartsWith("/") && !returnUrl.StartsWith("//"))
                {
                    Response.Redirect(returnUrl);
                }
                else
                {
                    Response.Redirect("~/Default.aspx");
                }
            }
            catch (Exception ex)
            {
                ShowMessage("An error occurred during login. Please try again.", true);
                System.Diagnostics.Debug.WriteLine("Login Error: " + ex.Message);
            }
        }

        private void EnsureDefaultAdmin()
        {
            try
            {
                // Check if admin user exists; if not, create one
                DataRow adminUser = DatabaseHelper.AuthenticateUser("admin");
                if (adminUser == null)
                {
                    string salt = PasswordHelper.GenerateSalt();
                    string hash = PasswordHelper.HashPassword("Admin@123", salt);
                    DatabaseHelper.CreateUser("admin", hash, salt, "System Administrator", "admin@dib.ae", 1, "SYSTEM");
                }
                else if (adminUser["PasswordHash"].ToString() == "PLACEHOLDER_HASH")
                {
                    // Update placeholder password
                    string salt = PasswordHelper.GenerateSalt();
                    string hash = PasswordHelper.HashPassword("Admin@123", salt);
                    DatabaseHelper.ResetUserPassword(Convert.ToInt32(adminUser["UserID"]), hash, salt, "SYSTEM");
                }
            }
            catch
            {
                // Database might not be set up yet - ignore
            }
        }

        private void ShowMessage(string message, bool isError)
        {
            pnlMessage.Visible = true;
            pnlMessage.CssClass = isError ? "msg-error" : "msg-success";
            lblMessage.Text = Server.HtmlEncode(message);
        }
    }
}
