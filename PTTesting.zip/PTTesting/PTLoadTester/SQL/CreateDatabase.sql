-- ============================================================
-- PT Load Tester  —  Database Setup Script
-- Compatible with SQL Server 2008 R2 and later
-- Run this script ONCE before starting the application.
-- ============================================================

USE master;
GO

-- Create database if it does not exist
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'PTLoadTesterDB')
BEGIN
    CREATE DATABASE [PTLoadTesterDB]
        COLLATE SQL_Latin1_General_CP1_CI_AS;
    PRINT 'Database PTLoadTesterDB created.';
END
ELSE
    PRINT 'Database PTLoadTesterDB already exists, skipping creation.';
GO

USE [PTLoadTesterDB];
GO

-- ============================================================
-- Table: LoadTestSessions
-- One row per test run (configuration + lifecycle status)
-- ============================================================
IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[LoadTestSessions]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[LoadTestSessions] (
        [SessionId]       INT           IDENTITY(1,1) NOT NULL,
        [TestUrl]         NVARCHAR(500) NOT NULL,
        [QueryParamName]  NVARCHAR(50)  NOT NULL CONSTRAINT [DF_Sessions_QueryParam] DEFAULT (N'ID'),
        [ConcurrentUsers] INT           NOT NULL,
        [TotalRequests]   INT           NOT NULL,
        [MinId]           INT           NOT NULL CONSTRAINT [DF_Sessions_MinId] DEFAULT (1000000),
        [MaxId]           INT           NOT NULL CONSTRAINT [DF_Sessions_MaxId] DEFAULT (9999999),
        [StartTime]       DATETIME      NOT NULL,
        [EndTime]         DATETIME      NULL,
        -- Pending | Running | Completed | Error
        [Status]          NVARCHAR(20)  NOT NULL CONSTRAINT [DF_Sessions_Status] DEFAULT (N'Pending'),
        [CreatedAt]       DATETIME      NOT NULL CONSTRAINT [DF_Sessions_CreatedAt] DEFAULT (GETDATE()),
        CONSTRAINT [PK_LoadTestSessions] PRIMARY KEY CLUSTERED ([SessionId] ASC)
    );
    PRINT 'Table LoadTestSessions created.';
END
ELSE
    PRINT 'Table LoadTestSessions already exists, skipping.';
GO

-- ============================================================
-- Table: LoadTestResults
-- One row per individual HTTP request made during a test
-- ============================================================
IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[LoadTestResults]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[LoadTestResults] (
        [ResultId]       INT           IDENTITY(1,1) NOT NULL,
        [SessionId]      INT           NOT NULL,
        [RequestNumber]  INT           NOT NULL,
        [FullUrl]        NVARCHAR(1000) NOT NULL,
        [QueryStringId]  NVARCHAR(100)  NOT NULL,
        [StatusCode]     INT           NOT NULL CONSTRAINT [DF_Results_StatusCode] DEFAULT (0),
        [ResponseTimeMs] BIGINT        NOT NULL CONSTRAINT [DF_Results_RespTime]   DEFAULT (0),
        [IsSuccess]      BIT           NOT NULL CONSTRAINT [DF_Results_IsSuccess]  DEFAULT (0),
        [ErrorMessage]   NVARCHAR(500) NULL,
        [RequestTime]    DATETIME      NOT NULL,
        CONSTRAINT [PK_LoadTestResults] PRIMARY KEY CLUSTERED ([ResultId] ASC),
        CONSTRAINT [FK_LoadTestResults_Sessions]
            FOREIGN KEY ([SessionId])
            REFERENCES [dbo].[LoadTestSessions] ([SessionId])
            ON DELETE CASCADE
    );
    PRINT 'Table LoadTestResults created.';
END
ELSE
    PRINT 'Table LoadTestResults already exists, skipping.';
GO

-- ============================================================
-- Indexes
-- ============================================================
IF NOT EXISTS (
    SELECT * FROM sys.indexes
    WHERE name = N'IX_LoadTestResults_SessionId'
      AND object_id = OBJECT_ID(N'dbo.LoadTestResults')
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_LoadTestResults_SessionId]
        ON [dbo].[LoadTestResults] ([SessionId] ASC)
        INCLUDE ([RequestNumber], [ResponseTimeMs], [IsSuccess], [StatusCode]);
    PRINT 'Index IX_LoadTestResults_SessionId created.';
END
GO

IF NOT EXISTS (
    SELECT * FROM sys.indexes
    WHERE name = N'IX_LoadTestSessions_CreatedAt'
      AND object_id = OBJECT_ID(N'dbo.LoadTestSessions')
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_LoadTestSessions_CreatedAt]
        ON [dbo].[LoadTestSessions] ([CreatedAt] DESC);
    PRINT 'Index IX_LoadTestSessions_CreatedAt created.';
END
GO

PRINT '';
PRINT '===================================================';
PRINT 'PTLoadTesterDB setup complete.';
PRINT 'Update the connection string in Web.config to point';
PRINT 'to this SQL Server instance before running the app.';
PRINT '===================================================';
GO

-- ============================================================
-- Workflow Page Load Test tables
-- ============================================================

IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[WorkflowTestSessions]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[WorkflowTestSessions] (
        [SessionId]       INT            IDENTITY(1,1) NOT NULL,
        [TestName]        NVARCHAR(200)  NOT NULL CONSTRAINT [DF_WF_Sessions_TestName]  DEFAULT (N'Workflow Test'),
        [LoginUrl]        NVARCHAR(500)  NOT NULL CONSTRAINT [DF_WF_Sessions_LoginUrl]  DEFAULT (N''),
        [UserId]          NVARCHAR(100)  NOT NULL CONSTRAINT [DF_WF_Sessions_UserId]    DEFAULT (N''),
        [ConcurrentUsers] INT            NOT NULL,
        [Iterations]      INT            NOT NULL,
        [TotalUrls]       INT            NOT NULL CONSTRAINT [DF_WF_Sessions_TotalUrls] DEFAULT (0),
        [StartTime]       DATETIME       NOT NULL,
        [EndTime]         DATETIME       NULL,
        [Status]          NVARCHAR(20)   NOT NULL CONSTRAINT [DF_WF_Sessions_Status]    DEFAULT (N'Pending'),
        [CreatedAt]       DATETIME       NOT NULL CONSTRAINT [DF_WF_Sessions_CreatedAt] DEFAULT (GETDATE()),
        CONSTRAINT [PK_WorkflowTestSessions] PRIMARY KEY CLUSTERED ([SessionId] ASC)
    );
    PRINT 'Table WorkflowTestSessions created.';
END
ELSE
    PRINT 'Table WorkflowTestSessions already exists, skipping.';
GO

IF NOT EXISTS (
    SELECT * FROM sys.objects
    WHERE object_id = OBJECT_ID(N'[dbo].[WorkflowTestResults]') AND type = N'U'
)
BEGIN
    CREATE TABLE [dbo].[WorkflowTestResults] (
        [ResultId]                INT            IDENTITY(1,1) NOT NULL,
        [SessionId]               INT            NOT NULL,
        [TargetUrl]               NVARCHAR(1000) NOT NULL,
        [VirtualUserId]           INT            NOT NULL,
        [IterationNumber]         INT            NOT NULL,
        -- Phase A: initial page GET
        [PageLoadTimeMs]          BIGINT         NOT NULL CONSTRAINT [DF_WF_Results_PLTime]  DEFAULT (0),
        [PageLoadStatusCode]      INT            NOT NULL CONSTRAINT [DF_WF_Results_PLCode]  DEFAULT (0),
        [PageLoadSuccess]         BIT            NOT NULL CONSTRAINT [DF_WF_Results_PLOk]    DEFAULT (0),
        -- Phase B: select-button postback
        [SelectActionTimeMs]      BIGINT         NOT NULL CONSTRAINT [DF_WF_Results_SATime]  DEFAULT (0),
        [SelectActionStatusCode]  INT            NOT NULL CONSTRAINT [DF_WF_Results_SACode]  DEFAULT (0),
        [SelectActionSuccess]     BIT            NOT NULL CONSTRAINT [DF_WF_Results_SAOk]    DEFAULT (0),
        [ErrorMessage]            NVARCHAR(500)  NULL,
        [RequestTime]             DATETIME       NOT NULL,
        CONSTRAINT [PK_WorkflowTestResults] PRIMARY KEY CLUSTERED ([ResultId] ASC),
        CONSTRAINT [FK_WorkflowTestResults_Sessions]
            FOREIGN KEY ([SessionId])
            REFERENCES [dbo].[WorkflowTestSessions] ([SessionId])
            ON DELETE CASCADE
    );
    PRINT 'Table WorkflowTestResults created.';
END
ELSE
    PRINT 'Table WorkflowTestResults already exists, skipping.';
GO

IF NOT EXISTS (
    SELECT * FROM sys.indexes
    WHERE name = N'IX_WorkflowTestResults_SessionId'
      AND object_id = OBJECT_ID(N'dbo.WorkflowTestResults')
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_WorkflowTestResults_SessionId]
        ON [dbo].[WorkflowTestResults] ([SessionId] ASC)
        INCLUDE ([TargetUrl], [PageLoadTimeMs], [SelectActionTimeMs],
                 [PageLoadSuccess], [SelectActionSuccess]);
    PRINT 'Index IX_WorkflowTestResults_SessionId created.';
END
GO

IF NOT EXISTS (
    SELECT * FROM sys.indexes
    WHERE name = N'IX_WorkflowTestSessions_CreatedAt'
      AND object_id = OBJECT_ID(N'dbo.WorkflowTestSessions')
)
BEGIN
    CREATE NONCLUSTERED INDEX [IX_WorkflowTestSessions_CreatedAt]
        ON [dbo].[WorkflowTestSessions] ([CreatedAt] DESC);
    PRINT 'Index IX_WorkflowTestSessions_CreatedAt created.';
END
GO

PRINT '';
PRINT '===================================================';
PRINT 'Workflow test tables added successfully.';
PRINT '===================================================';
GO
