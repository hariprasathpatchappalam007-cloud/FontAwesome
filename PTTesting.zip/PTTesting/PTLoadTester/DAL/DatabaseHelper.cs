using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using PTLoadTester.Models;

namespace PTLoadTester.DAL
{
    public static class DatabaseHelper
    {
        private static string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["LoadTestDB"].ConnectionString; }
        }

        public static int CreateSession(LoadTestSession session)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                const string sql = @"
                    INSERT INTO LoadTestSessions
                        (TestUrl, QueryParamName, ConcurrentUsers, TotalRequests, MinId, MaxId, StartTime, Status, CreatedAt)
                    OUTPUT INSERTED.SessionId
                    VALUES
                        (@TestUrl, @QueryParamName, @ConcurrentUsers, @TotalRequests, @MinId, @MaxId, @StartTime, @Status, @CreatedAt)";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@TestUrl", session.TestUrl);
                    cmd.Parameters.AddWithValue("@QueryParamName", session.QueryParamName ?? "ID");
                    cmd.Parameters.AddWithValue("@ConcurrentUsers", session.ConcurrentUsers);
                    cmd.Parameters.AddWithValue("@TotalRequests", session.TotalRequests);
                    cmd.Parameters.AddWithValue("@MinId", session.MinId);
                    cmd.Parameters.AddWithValue("@MaxId", session.MaxId);
                    cmd.Parameters.AddWithValue("@StartTime", session.StartTime);
                    cmd.Parameters.AddWithValue("@Status", session.Status);
                    cmd.Parameters.AddWithValue("@CreatedAt", DateTime.Now);
                    return (int)cmd.ExecuteScalar();
                }
            }
        }

        public static void UpdateSessionStatus(int sessionId, string status, DateTime? endTime = null)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var sql = endTime.HasValue
                    ? "UPDATE LoadTestSessions SET Status = @Status, EndTime = @EndTime WHERE SessionId = @SessionId"
                    : "UPDATE LoadTestSessions SET Status = @Status WHERE SessionId = @SessionId";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@SessionId", sessionId);
                    if (endTime.HasValue)
                        cmd.Parameters.AddWithValue("@EndTime", endTime.Value);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void BulkInsertResults(List<LoadTestResult> results)
        {
            if (results == null || results.Count == 0) return;

            var table = new DataTable();
            table.Columns.Add("SessionId", typeof(int));
            table.Columns.Add("RequestNumber", typeof(int));
            table.Columns.Add("FullUrl", typeof(string));
            table.Columns.Add("QueryStringId", typeof(string));
            table.Columns.Add("StatusCode", typeof(int));
            table.Columns.Add("ResponseTimeMs", typeof(long));
            table.Columns.Add("IsSuccess", typeof(bool));
            table.Columns.Add("ErrorMessage", typeof(string));
            table.Columns.Add("RequestTime", typeof(DateTime));

            foreach (var r in results)
            {
                table.Rows.Add(
                    r.SessionId,
                    r.RequestNumber,
                    r.FullUrl ?? string.Empty,
                    r.QueryStringId ?? string.Empty,
                    r.StatusCode,
                    r.ResponseTimeMs,
                    r.IsSuccess,
                    r.ErrorMessage ?? string.Empty,
                    r.RequestTime
                );
            }

            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var bulk = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, null))
                {
                    bulk.DestinationTableName = "dbo.LoadTestResults";
                    bulk.ColumnMappings.Add("SessionId", "SessionId");
                    bulk.ColumnMappings.Add("RequestNumber", "RequestNumber");
                    bulk.ColumnMappings.Add("FullUrl", "FullUrl");
                    bulk.ColumnMappings.Add("QueryStringId", "QueryStringId");
                    bulk.ColumnMappings.Add("StatusCode", "StatusCode");
                    bulk.ColumnMappings.Add("ResponseTimeMs", "ResponseTimeMs");
                    bulk.ColumnMappings.Add("IsSuccess", "IsSuccess");
                    bulk.ColumnMappings.Add("ErrorMessage", "ErrorMessage");
                    bulk.ColumnMappings.Add("RequestTime", "RequestTime");
                    bulk.BulkCopyTimeout = 120;
                    bulk.WriteToServer(table);
                }
            }
        }

        public static LoadTestSession GetSession(int sessionId)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT * FROM LoadTestSessions WHERE SessionId = @SessionId", conn))
                {
                    cmd.Parameters.AddWithValue("@SessionId", sessionId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) return MapSession(reader);
                    }
                }
            }
            return null;
        }

        public static List<LoadTestResult> GetResultsBySession(int sessionId)
        {
            var results = new List<LoadTestResult>();
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                const string sql = "SELECT * FROM LoadTestResults WHERE SessionId = @SessionId ORDER BY RequestNumber ASC";
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@SessionId", sessionId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read()) results.Add(MapResult(reader));
                    }
                }
            }
            return results;
        }

        public static List<LoadTestSession> GetRecentSessions(int top = 10)
        {
            var sessions = new List<LoadTestSession>();
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var sql = string.Format(
                    "SELECT TOP {0} * FROM LoadTestSessions ORDER BY CreatedAt DESC", top);
                using (var cmd = new SqlCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read()) sessions.Add(MapSession(reader));
                }
            }
            return sessions;
        }

        private static LoadTestSession MapSession(SqlDataReader r)
        {
            return new LoadTestSession
            {
                SessionId = (int)r["SessionId"],
                TestUrl = r["TestUrl"].ToString(),
                QueryParamName = r["QueryParamName"].ToString(),
                ConcurrentUsers = (int)r["ConcurrentUsers"],
                TotalRequests = (int)r["TotalRequests"],
                MinId = (int)r["MinId"],
                MaxId = (int)r["MaxId"],
                StartTime = (DateTime)r["StartTime"],
                EndTime = r["EndTime"] == DBNull.Value ? (DateTime?)null : (DateTime)r["EndTime"],
                Status = r["Status"].ToString(),
                CreatedAt = (DateTime)r["CreatedAt"]
            };
        }

        private static LoadTestResult MapResult(SqlDataReader r)
        {
            return new LoadTestResult
            {
                ResultId = (int)r["ResultId"],
                SessionId = (int)r["SessionId"],
                RequestNumber = (int)r["RequestNumber"],
                FullUrl = r["FullUrl"].ToString(),
                QueryStringId = r["QueryStringId"].ToString(),
                StatusCode = (int)r["StatusCode"],
                ResponseTimeMs = (long)r["ResponseTimeMs"],
                IsSuccess = (bool)r["IsSuccess"],
                ErrorMessage = r["ErrorMessage"] == DBNull.Value ? null : r["ErrorMessage"].ToString(),
                RequestTime = (DateTime)r["RequestTime"]
            };
        }
    }
}
