using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using PTLoadTester.Models;

namespace PTLoadTester.DAL
{
    public static class DatabaseHelper
    {
        private static string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["LoadTestDB"].ConnectionString; }
        }

        public static int CreateSession(LoadTestSession session)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                const string sql = @"
                    INSERT INTO LoadTestSessions
                        (TestUrl, QueryParamName, ConcurrentUsers, TotalRequests, MinId, MaxId, StartTime, Status, CreatedAt)
                    OUTPUT INSERTED.SessionId
                    VALUES
                        (@TestUrl, @QueryParamName, @ConcurrentUsers, @TotalRequests, @MinId, @MaxId, @StartTime, @Status, @CreatedAt)";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@TestUrl", session.TestUrl);
                    cmd.Parameters.AddWithValue("@QueryParamName", session.QueryParamName ?? "ID");
                    cmd.Parameters.AddWithValue("@ConcurrentUsers", session.ConcurrentUsers);
                    cmd.Parameters.AddWithValue("@TotalRequests", session.TotalRequests);
                    cmd.Parameters.AddWithValue("@MinId", session.MinId);
                    cmd.Parameters.AddWithValue("@MaxId", session.MaxId);
                    cmd.Parameters.AddWithValue("@StartTime", session.StartTime);
                    cmd.Parameters.AddWithValue("@Status", session.Status);
                    cmd.Parameters.AddWithValue("@CreatedAt", DateTime.Now);
                    return (int)cmd.ExecuteScalar();
                }
            }
        }

        public static void UpdateSessionStatus(int sessionId, string status, DateTime? endTime = null)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var sql = endTime.HasValue
                    ? "UPDATE LoadTestSessions SET Status = @Status, EndTime = @EndTime WHERE SessionId = @SessionId"
                    : "UPDATE LoadTestSessions SET Status = @Status WHERE SessionId = @SessionId";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@SessionId", sessionId);
                    if (endTime.HasValue)
                        cmd.Parameters.AddWithValue("@EndTime", endTime.Value);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void BulkInsertResults(List<LoadTestResult> results)
        {
            if (results == null || results.Count == 0) return;

            var table = new DataTable();
            table.Columns.Add("SessionId", typeof(int));
            table.Columns.Add("RequestNumber", typeof(int));
            table.Columns.Add("FullUrl", typeof(string));
            table.Columns.Add("QueryStringId", typeof(string));
            table.Columns.Add("StatusCode", typeof(int));
            table.Columns.Add("ResponseTimeMs", typeof(long));
            table.Columns.Add("IsSuccess", typeof(bool));
            table.Columns.Add("ErrorMessage", typeof(string));
            table.Columns.Add("RequestTime", typeof(DateTime));

            foreach (var r in results)
            {
                table.Rows.Add(
                    r.SessionId,
                    r.RequestNumber,
                    r.FullUrl ?? string.Empty,
                    r.QueryStringId ?? string.Empty,
                    r.StatusCode,
                    r.ResponseTimeMs,
                    r.IsSuccess,
                    r.ErrorMessage ?? string.Empty,
                    r.RequestTime
                );
            }

            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var bulk = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, null))
                {
                    bulk.DestinationTableName = "dbo.LoadTestResults";
                    bulk.ColumnMappings.Add("SessionId", "SessionId");
                    bulk.ColumnMappings.Add("RequestNumber", "RequestNumber");
                    bulk.ColumnMappings.Add("FullUrl", "FullUrl");
                    bulk.ColumnMappings.Add("QueryStringId", "QueryStringId");
                    bulk.ColumnMappings.Add("StatusCode", "StatusCode");
                    bulk.ColumnMappings.Add("ResponseTimeMs", "ResponseTimeMs");
                    bulk.ColumnMappings.Add("IsSuccess", "IsSuccess");
                    bulk.ColumnMappings.Add("ErrorMessage", "ErrorMessage");
                    bulk.ColumnMappings.Add("RequestTime", "RequestTime");
                    bulk.BulkCopyTimeout = 120;
                    bulk.WriteToServer(table);
                }
            }
        }

        public static LoadTestSession GetSession(int sessionId)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT * FROM LoadTestSessions WHERE SessionId = @SessionId", conn))
                {
                    cmd.Parameters.AddWithValue("@SessionId", sessionId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) return MapSession(reader);
                    }
                }
            }
            return null;
        }

        public static List<LoadTestResult> GetResultsBySession(int sessionId)
        {
            var results = new List<LoadTestResult>();
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                const string sql = "SELECT * FROM LoadTestResults WHERE SessionId = @SessionId ORDER BY RequestNumber ASC";
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@SessionId", sessionId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read()) results.Add(MapResult(reader));
                    }
                }
            }
            return results;
        }

        public static List<LoadTestSession> GetRecentSessions(int top = 10)
        {
            var sessions = new List<LoadTestSession>();
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var sql = string.Format(
                    "SELECT TOP {0} * FROM LoadTestSessions ORDER BY CreatedAt DESC", top);
                using (var cmd = new SqlCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read()) sessions.Add(MapSession(reader));
                }
            }
            return sessions;
        }

        private static LoadTestSession MapSession(SqlDataReader r)
        {
            return new LoadTestSession
            {
                SessionId = (int)r["SessionId"],
                TestUrl = r["TestUrl"].ToString(),
                QueryParamName = r["QueryParamName"].ToString(),
                ConcurrentUsers = (int)r["ConcurrentUsers"],
                TotalRequests = (int)r["TotalRequests"],
                MinId = (int)r["MinId"],
                MaxId = (int)r["MaxId"],
                StartTime = (DateTime)r["StartTime"],
                EndTime = r["EndTime"] == DBNull.Value ? (DateTime?)null : (DateTime)r["EndTime"],
                Status = r["Status"].ToString(),
                CreatedAt = (DateTime)r["CreatedAt"]
            };
        }

        private static LoadTestResult MapResult(SqlDataReader r)
        {
            return new LoadTestResult
            {
                ResultId = (int)r["ResultId"],
                SessionId = (int)r["SessionId"],
                RequestNumber = (int)r["RequestNumber"],
                FullUrl = r["FullUrl"].ToString(),
                QueryStringId = r["QueryStringId"].ToString(),
                StatusCode = (int)r["StatusCode"],
                ResponseTimeMs = (long)r["ResponseTimeMs"],
                IsSuccess = (bool)r["IsSuccess"],
                ErrorMessage = r["ErrorMessage"] == DBNull.Value ? null : r["ErrorMessage"].ToString(),
                RequestTime = (DateTime)r["RequestTime"]
            };
        }

        // ====================================================================
        // Workflow test methods
        // ====================================================================

        public static int CreateWorkflowSession(Models.WorkflowTestSession session)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                const string sql = @"
                    INSERT INTO WorkflowTestSessions
                        (TestName, LoginUrl, UserId, ConcurrentUsers, Iterations, TotalUrls,
                         StartTime, Status, CreatedAt)
                    OUTPUT INSERTED.SessionId
                    VALUES
                        (@TestName, @LoginUrl, @UserId, @ConcurrentUsers, @Iterations, @TotalUrls,
                         @StartTime, @Status, @CreatedAt)";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@TestName",        session.TestName ?? "Workflow Test");
                    cmd.Parameters.AddWithValue("@LoginUrl",         session.LoginUrl ?? string.Empty);
                    cmd.Parameters.AddWithValue("@UserId",           session.UserId ?? string.Empty);
                    cmd.Parameters.AddWithValue("@ConcurrentUsers",  session.ConcurrentUsers);
                    cmd.Parameters.AddWithValue("@Iterations",       session.Iterations);
                    cmd.Parameters.AddWithValue("@TotalUrls",        session.TotalUrls);
                    cmd.Parameters.AddWithValue("@StartTime",        session.StartTime);
                    cmd.Parameters.AddWithValue("@Status",           session.Status ?? "Pending");
                    cmd.Parameters.AddWithValue("@CreatedAt",        DateTime.Now);
                    return (int)cmd.ExecuteScalar();
                }
            }
        }

        public static void UpdateWorkflowSessionStatus(int sessionId, string status,
            DateTime? endTime = null)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var sql = endTime.HasValue
                    ? "UPDATE WorkflowTestSessions SET Status=@Status, EndTime=@EndTime WHERE SessionId=@Id"
                    : "UPDATE WorkflowTestSessions SET Status=@Status WHERE SessionId=@Id";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@Id",     sessionId);
                    if (endTime.HasValue)
                        cmd.Parameters.AddWithValue("@EndTime", endTime.Value);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void BulkInsertWorkflowResults(List<Models.WorkflowPageResult> results)
        {
            if (results == null || results.Count == 0) return;

            var table = new DataTable();
            table.Columns.Add("SessionId",              typeof(int));
            table.Columns.Add("TargetUrl",              typeof(string));
            table.Columns.Add("VirtualUserId",          typeof(int));
            table.Columns.Add("IterationNumber",        typeof(int));
            table.Columns.Add("PageLoadTimeMs",         typeof(long));
            table.Columns.Add("PageLoadStatusCode",     typeof(int));
            table.Columns.Add("PageLoadSuccess",        typeof(bool));
            table.Columns.Add("SelectActionTimeMs",     typeof(long));
            table.Columns.Add("SelectActionStatusCode", typeof(int));
            table.Columns.Add("SelectActionSuccess",    typeof(bool));
            table.Columns.Add("ErrorMessage",           typeof(string));
            table.Columns.Add("RequestTime",            typeof(DateTime));

            foreach (var r in results)
            {
                table.Rows.Add(
                    r.SessionId,
                    r.TargetUrl ?? string.Empty,
                    r.VirtualUserId,
                    r.IterationNumber,
                    r.PageLoadTimeMs,
                    r.PageLoadStatusCode,
                    r.PageLoadSuccess,
                    r.SelectActionTimeMs,
                    r.SelectActionStatusCode,
                    r.SelectActionSuccess,
                    r.ErrorMessage ?? string.Empty,
                    r.RequestTime
                );
            }

            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var bulk = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, null))
                {
                    bulk.DestinationTableName = "dbo.WorkflowTestResults";
                    foreach (DataColumn col in table.Columns)
                        bulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                    bulk.BulkCopyTimeout = 120;
                    bulk.WriteToServer(table);
                }
            }
        }

        public static Models.WorkflowTestSession GetWorkflowSession(int sessionId)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(
                    "SELECT * FROM WorkflowTestSessions WHERE SessionId=@Id", conn))
                {
                    cmd.Parameters.AddWithValue("@Id", sessionId);
                    using (var r = cmd.ExecuteReader())
                        if (r.Read()) return MapWorkflowSession(r);
                }
            }
            return null;
        }

        public static List<Models.WorkflowPageResult> GetWorkflowResultsBySession(int sessionId)
        {
            var list = new List<Models.WorkflowPageResult>();
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                const string sql = @"SELECT * FROM WorkflowTestResults
                                     WHERE SessionId=@Id
                                     ORDER BY VirtualUserId, IterationNumber, TargetUrl";
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", sessionId);
                    using (var r = cmd.ExecuteReader())
                        while (r.Read()) list.Add(MapWorkflowResult(r));
                }
            }
            return list;
        }

        public static List<Models.WorkflowTestSession> GetRecentWorkflowSessions(int top = 10)
        {
            var list = new List<Models.WorkflowTestSession>();
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var sql = string.Format(
                    "SELECT TOP {0} * FROM WorkflowTestSessions ORDER BY CreatedAt DESC", top);
                using (var cmd = new SqlCommand(sql, conn))
                using (var r = cmd.ExecuteReader())
                    while (r.Read()) list.Add(MapWorkflowSession(r));
            }
            return list;
        }

        private static Models.WorkflowTestSession MapWorkflowSession(SqlDataReader r)
        {
            return new Models.WorkflowTestSession
            {
                SessionId       = (int)r["SessionId"],
                TestName        = r["TestName"].ToString(),
                LoginUrl        = r["LoginUrl"].ToString(),
                UserId          = r["UserId"].ToString(),
                ConcurrentUsers = (int)r["ConcurrentUsers"],
                Iterations      = (int)r["Iterations"],
                TotalUrls       = (int)r["TotalUrls"],
                StartTime       = (DateTime)r["StartTime"],
                EndTime         = r["EndTime"] == DBNull.Value ? (DateTime?)null : (DateTime)r["EndTime"],
                Status          = r["Status"].ToString(),
                CreatedAt       = (DateTime)r["CreatedAt"]
            };
        }

        private static Models.WorkflowPageResult MapWorkflowResult(SqlDataReader r)
        {
            return new Models.WorkflowPageResult
            {
                ResultId                = (int)r["ResultId"],
                SessionId               = (int)r["SessionId"],
                TargetUrl               = r["TargetUrl"].ToString(),
                VirtualUserId           = (int)r["VirtualUserId"],
                IterationNumber         = (int)r["IterationNumber"],
                PageLoadTimeMs          = (long)r["PageLoadTimeMs"],
                PageLoadStatusCode      = (int)r["PageLoadStatusCode"],
                PageLoadSuccess         = (bool)r["PageLoadSuccess"],
                SelectActionTimeMs      = (long)r["SelectActionTimeMs"],
                SelectActionStatusCode  = (int)r["SelectActionStatusCode"],
                SelectActionSuccess     = (bool)r["SelectActionSuccess"],
                ErrorMessage            = r["ErrorMessage"] == DBNull.Value ? null : r["ErrorMessage"].ToString(),
                RequestTime             = (DateTime)r["RequestTime"]
            };
        }
    }
}
