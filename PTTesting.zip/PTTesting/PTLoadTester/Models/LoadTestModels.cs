using System;
using System.Collections.Generic;

namespace PTLoadTester.Models
{
    public class LoadTestSession
    {
        public int SessionId { get; set; }
        public string TestUrl { get; set; }
        public string QueryParamName { get; set; }
        public int ConcurrentUsers { get; set; }
        public int TotalRequests { get; set; }
        public int MinId { get; set; }
        public int MaxId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class LoadTestResult
    {
        public int ResultId { get; set; }
        public int SessionId { get; set; }
        public int RequestNumber { get; set; }
        public string FullUrl { get; set; }
        public string QueryStringId { get; set; }
        public int StatusCode { get; set; }
        public long ResponseTimeMs { get; set; }
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime RequestTime { get; set; }
    }

    public class TestProgressInfo
    {
        public string Status { get; set; }
        public int CompletedRequests { get; set; }
        public int TotalRequests { get; set; }
        public string ErrorMessage { get; set; }
        public int SessionId { get; set; }
    }

    public class TestSummary
    {
        public int TotalRequests { get; set; }
        public int SuccessCount { get; set; }
        public int FailCount { get; set; }
        public double SuccessRate { get; set; }
        public double AverageResponseTime { get; set; }
        public long MinResponseTime { get; set; }
        public long MaxResponseTime { get; set; }
        public double RequestsPerSecond { get; set; }
        public double TotalDurationSeconds { get; set; }
        public double P50ResponseTime { get; set; }
        public double P95ResponseTime { get; set; }
        public double P99ResponseTime { get; set; }
    }

    public class ChartData
    {
        public List<int> RequestNumbers { get; set; }
        public List<long> ResponseTimes { get; set; }
        public List<bool> IsSuccess { get; set; }
        public List<string> DistributionLabels { get; set; }
        public List<int> DistributionCounts { get; set; }
    }
}
