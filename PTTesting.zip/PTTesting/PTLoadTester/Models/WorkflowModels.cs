using System;
using System.Collections.Generic;

namespace PTLoadTester.Models
{
    // -----------------------------------------------------------------------
    // Configuration passed to WorkflowTestEngine.RunTestAsync
    // -----------------------------------------------------------------------
    public class WorkflowTestConfig
    {
        public string       LoginUrl         { get; set; }
        /// <summary>
        /// Raw URL-encoded POST body the caller wants sent to the login page
        /// (excluding __VIEWSTATE / __EVENTVALIDATION, which are auto-extracted).
        /// Example: "txtUserId=SPUser05&txtPassword=secret&btnLogin=Login"
        /// </summary>
        public string       LoginPostData    { get; set; }
        public List<string> TargetUrls       { get; set; }
        public int          ConcurrentUsers  { get; set; }
        public int          Iterations       { get; set; }
        public int          RequestTimeoutMs { get; set; }
    }

    // -----------------------------------------------------------------------
    // One result row per: virtual-user × iteration × target URL
    // -----------------------------------------------------------------------
    public class WorkflowPageResult
    {
        public int      ResultId                { get; set; }
        public int      SessionId               { get; set; }
        public string   TargetUrl               { get; set; }
        public int      VirtualUserId           { get; set; }
        public int      IterationNumber         { get; set; }

        // Phase 1 — initial page GET
        public long     PageLoadTimeMs          { get; set; }
        public int      PageLoadStatusCode      { get; set; }
        public bool     PageLoadSuccess         { get; set; }

        // Phase 2 — select-button postback
        public long     SelectActionTimeMs      { get; set; }
        public int      SelectActionStatusCode  { get; set; }
        public bool     SelectActionSuccess     { get; set; }

        public string   ErrorMessage            { get; set; }
        public DateTime RequestTime             { get; set; }
    }

    // -----------------------------------------------------------------------
    // Persisted session record (one per test run)
    // -----------------------------------------------------------------------
    public class WorkflowTestSession
    {
        public int       SessionId       { get; set; }
        public string    TestName        { get; set; }
        public string    LoginUrl        { get; set; }
        public string    UserId          { get; set; }
        public int       ConcurrentUsers { get; set; }
        public int       Iterations      { get; set; }
        public int       TotalUrls       { get; set; }
        public DateTime  StartTime       { get; set; }
        public DateTime? EndTime         { get; set; }
        public string    Status          { get; set; }
        public DateTime  CreatedAt       { get; set; }
    }

    // -----------------------------------------------------------------------
    // In-memory progress (not persisted, held in ConcurrentDictionary)
    // -----------------------------------------------------------------------
    public class WorkflowProgress
    {
        public int    SessionId      { get; set; }
        public string Status         { get; set; }
        public int    TotalTasks     { get; set; }
        public int    CompletedTasks { get; set; }
        public string ErrorMessage   { get; set; }
    }

    // -----------------------------------------------------------------------
    // Aggregated stats per URL (computed in Results code-behind)
    // -----------------------------------------------------------------------
    public class WorkflowUrlSummary
    {
        public string Url                { get; set; }
        public string UrlShort           { get; set; }
        public int    TotalRequests      { get; set; }
        public int    PageSuccessCount   { get; set; }
        public int    SelectSuccessCount { get; set; }
        public double AvgPageLoadMs      { get; set; }
        public long   MinPageLoadMs      { get; set; }
        public long   MaxPageLoadMs      { get; set; }
        public double P95PageLoadMs      { get; set; }
        public double AvgSelectMs        { get; set; }
        public long   MinSelectMs        { get; set; }
        public long   MaxSelectMs        { get; set; }
        public double P95SelectMs        { get; set; }
    }

    // -----------------------------------------------------------------------
    // Overall (cross-URL) summary for the results KPI cards
    // -----------------------------------------------------------------------
    public class WorkflowOverallSummary
    {
        public int    TotalTests          { get; set; }
        public int    PageSuccessCount    { get; set; }
        public int    SelectSuccessCount  { get; set; }
        public double PageSuccessRate     { get; set; }
        public double SelectSuccessRate   { get; set; }
        public double OverallAvgPageMs    { get; set; }
        public double OverallAvgSelectMs  { get; set; }
        public long   MinPageLoadMs       { get; set; }
        public long   MaxPageLoadMs       { get; set; }
        public double TotalDurationSec    { get; set; }
        public int    ConcurrentUsers     { get; set; }
        public int    Iterations          { get; set; }
        public int    TotalUrls           { get; set; }
    }
}
