<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="PTLoadTester.Default" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>PT Load Tester &mdash; Performance Testing Tool</title>
    <!-- Bootstrap 3 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Font Awesome 4 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <style>
        /* ===== Global ===== */
        body { background: #f0f2f7; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        /* ===== Navbar ===== */
        .navbar-custom {
            background: linear-gradient(135deg, #1a237e 0%, #283593 50%, #1565c0 100%);
            border: none; border-radius: 0; margin-bottom: 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.35);
        }
        .navbar-custom .navbar-brand { color: #fff !important; font-size: 22px; font-weight: 700; letter-spacing: 0.5px; }
        .navbar-custom .navbar-brand span { color: #82b1ff; }
        .navbar-custom .navbar-text { color: #b0bec5; font-size: 13px; margin-top: 17px; }
        /* ===== Hero strip ===== */
        .hero-strip {
            background: linear-gradient(135deg, #0d47a1 0%, #1565c0 100%);
            color: #fff; padding: 28px 0 22px; margin-bottom: 30px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }
        .hero-strip h2 { margin: 0 0 6px; font-weight: 300; font-size: 28px; }
        .hero-strip p  { margin: 0; opacity: 0.8; font-size: 14px; }
        /* ===== Cards / Panels ===== */
        .card {
            background: #fff; border-radius: 8px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.09);
            margin-bottom: 24px; overflow: hidden;
        }
        .card-header {
            background: linear-gradient(90deg, #1565c0, #0d47a1);
            color: #fff; padding: 14px 20px;
            font-size: 15px; font-weight: 600; letter-spacing: 0.3px;
        }
        .card-header .fa { margin-right: 8px; }
        .card-body { padding: 24px; }
        /* ===== Form elements ===== */
        .form-control {
            border-radius: 5px; border: 1px solid #dde3ee;
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.06);
            transition: border-color 0.2s;
        }
        .form-control:focus { border-color: #1565c0; box-shadow: 0 0 0 2px rgba(21,101,192,0.15); }
        label { font-weight: 600; color: #37474f; font-size: 13px; margin-bottom: 5px; }
        .form-group { margin-bottom: 20px; }
        /* ===== Range sliders ===== */
        .slider-wrap { display: flex; align-items: center; gap: 14px; }
        .slider-wrap input[type=range] { flex: 1; accent-color: #1565c0; height: 6px; }
        .slider-num {
            min-width: 80px; padding: 5px 10px; border: 2px solid #1565c0;
            border-radius: 6px; font-weight: 700; font-size: 15px;
            color: #1565c0; text-align: center; background: #e8f0fe;
        }
        /* ===== Badge row ===== */
        .badge-row { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
        .badge-info-box {
            background: #e8f0fe; border-left: 4px solid #1565c0;
            padding: 6px 14px; border-radius: 4px; font-size: 12px; color: #1a237e;
        }
        /* ===== Buttons ===== */
        .btn-start {
            background: linear-gradient(135deg, #2e7d32, #388e3c);
            color: #fff; border: none; border-radius: 6px;
            padding: 12px 36px; font-size: 16px; font-weight: 600;
            letter-spacing: 0.4px; transition: all 0.2s;
            box-shadow: 0 3px 8px rgba(46,125,50,0.35);
        }
        .btn-start:hover:not(:disabled) { background: linear-gradient(135deg, #1b5e20, #2e7d32); box-shadow: 0 4px 12px rgba(46,125,50,0.45); color:#fff; }
        .btn-start:disabled { opacity: 0.65; cursor: not-allowed; }
        /* ===== Progress panel ===== */
        #progressPanel {
            display: none; background: #fff; border-radius: 8px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.09); padding: 24px;
            margin-bottom: 24px; border-left: 5px solid #1565c0;
        }
        #progressPanel h4 { margin-top: 0; color: #1565c0; }
        .progress { height: 22px; border-radius: 11px; background: #e8f0fe; margin-bottom: 10px; }
        .progress-bar {
            border-radius: 11px; background: linear-gradient(90deg, #1565c0, #42a5f5);
            font-size: 13px; font-weight: 600; line-height: 22px;
            transition: width 0.4s ease;
        }
        .progress-bar.progress-error { background: #e53935; }
        .stat-pill {
            display: inline-block; padding: 4px 12px; border-radius: 20px;
            font-size: 12px; font-weight: 600; margin: 2px;
        }
        .pill-blue   { background: #e3f2fd; color: #1565c0; }
        .pill-green  { background: #e8f5e9; color: #2e7d32; }
        .pill-orange { background: #fff3e0; color: #e65100; }
        /* ===== Recent tests table ===== */
        .table-recent th { background: #f5f7fb; color: #455a64; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
        .table-recent td { vertical-align: middle; font-size: 13px; }
        .status-badge { padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .status-completed { background: #c8e6c9; color: #1b5e20; }
        .status-running   { background: #bbdefb; color: #0d47a1; }
        .status-error     { background: #ffcdd2; color: #b71c1c; }
        .status-pending   { background: #f3e5f5; color: #6a1b9a; }
        /* ===== Alert ===== */
        #dbAlert { display:none; }
        /* ===== Footer ===== */
        .footer { text-align:center; padding: 20px; color: #90a4ae; font-size: 12px; margin-top: 10px; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-custom navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <span class="navbar-brand">
                <i class="fa fa-tachometer"></i> PT<span>LoadTester</span>
            </span>
        </div>
        <p class="navbar-text navbar-right hidden-xs">
            <i class="fa fa-info-circle"></i>&nbsp;ASP.NET Page Load Performance Tool
        </p>
    </div>
</nav>

<!-- Hero -->
<div class="hero-strip">
    <div class="container-fluid">
        <h2><i class="fa fa-bolt"></i> Load Test Dashboard</h2>
        <p>Stress-test any URL with configurable concurrent users and random query strings</p>
    </div>
</div>

<div class="container-fluid" style="max-width:1280px;">

    <!-- DB Error Alert -->
    <div id="dbAlert" class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" onclick="$('#dbAlert').hide()"><span>&times;</span></button>
        <strong><i class="fa fa-database"></i> Database Error:</strong>
        <span id="dbErrorMsg"></span>
        <br/><small>Please verify the connection string in <code>Web.config</code> and run <code>SQL/CreateDatabase.sql</code>.</small>
    </div>

    <div class="row">
        <!-- LEFT: Configuration -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-cogs"></i> Test Configuration
                </div>
                <div class="card-body">

                    <!-- Target URL -->
                    <div class="form-group">
                        <label for="txtUrl"><i class="fa fa-link"></i> Target URL</label>
                        <input type="text" id="txtUrl" class="form-control"
                               value="http://10.224.3.14:9050/qrcode/QrImg.aspx?ID=1234567"
                               placeholder="http://server/page.aspx?ID=1234567" />
                        <p class="help-block" style="font-size:12px;">
                            The existing query-string parameter name is auto-detected from the URL.
                        </p>
                    </div>

                    <!-- Param Name + ID Range -->
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="txtParam"><i class="fa fa-key"></i> Query Parameter</label>
                                <input type="text" id="txtParam" class="form-control" value="ID" maxlength="50"
                                       placeholder="e.g. ID" />
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="txtMinId"><i class="fa fa-arrow-down"></i> Min ID Value</label>
                                <input type="number" id="txtMinId" class="form-control" value="1000000" min="0" />
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="txtMaxId"><i class="fa fa-arrow-up"></i> Max ID Value</label>
                                <input type="number" id="txtMaxId" class="form-control" value="9999999" min="0" />
                            </div>
                        </div>
                    </div>

                    <hr style="margin:10px 0 20px;border-color:#e8f0fe;" />

                    <!-- Concurrent Users Slider -->
                    <div class="form-group">
                        <label><i class="fa fa-users"></i> Concurrent Users</label>
                        <div class="slider-wrap">
                            <input type="range" id="sldConcurrent" min="1" max="500" step="1" value="100" />
                            <div class="slider-num" id="lblConcurrent">100</div>
                            <input type="number" id="numConcurrent" class="form-control"
                                   style="width:90px;" min="1" max="500" value="100" />
                        </div>
                    </div>

                    <!-- Total Requests Slider -->
                    <div class="form-group">
                        <label><i class="fa fa-list-ol"></i> Total Requests</label>
                        <div class="slider-wrap">
                            <input type="range" id="sldRequests" min="10" max="5000" step="10" value="500" />
                            <div class="slider-num" id="lblRequests">500</div>
                            <input type="number" id="numRequests" class="form-control"
                                   style="width:90px;" min="10" max="5000" value="500" />
                        </div>
                    </div>

                    <!-- Badges -->
                    <div class="badge-row">
                        <span class="badge-info-box" id="badgeRatio">
                            <i class="fa fa-calculator"></i>
                            Each user handles ~<strong id="reqPerUser">5</strong> requests
                        </span>
                        <span class="badge-info-box">
                            <i class="fa fa-random"></i>
                            Random IDs: <strong id="idRangeDisplay">1000000 – 9999999</strong>
                        </span>
                    </div>

                    <div style="margin-top:24px;">
                        <button id="btnStart" class="btn-start" type="button">
                            <i class="fa fa-play-circle"></i>&nbsp; Start Load Test
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- RIGHT: Info -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-question-circle"></i> How It Works
                </div>
                <div class="card-body" style="font-size:13px; color:#546e7a; line-height:1.7;">
                    <p><i class="fa fa-check-circle" style="color:#1565c0;"></i>
                       Enter the target URL with an ID query parameter.</p>
                    <p><i class="fa fa-check-circle" style="color:#1565c0;"></i>
                       Set the number of <strong>concurrent virtual users</strong> and
                       <strong>total requests</strong> to fire.</p>
                    <p><i class="fa fa-check-circle" style="color:#1565c0;"></i>
                       Each request uses a <strong>random ID</strong> within the specified range
                       to simulate real traffic.</p>
                    <p><i class="fa fa-check-circle" style="color:#1565c0;"></i>
                       Results are stored in SQL Server and displayed as
                       <strong>ApexCharts + DataTable</strong>.</p>
                    <hr/>
                    <p style="margin:0; font-size:11px;">
                        <i class="fa fa-database"></i>
                        Connection: <code style="font-size:11px;">PTLoadTesterDB</code><br/>
                        Run <code style="font-size:11px;">SQL/CreateDatabase.sql</code> before first use.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Progress Panel -->
    <div id="progressPanel">
        <div class="row">
            <div class="col-sm-8">
                <h4><i class="fa fa-spinner fa-spin"></i> Test Running&hellip;</h4>
                <div class="progress">
                    <div id="progressBar" class="progress-bar progress-bar-striped active" style="width:0%">0%</div>
                </div>
                <p id="progressText" style="color:#546e7a; font-size:13px;">
                    Initialising&hellip;
                </p>
            </div>
            <div class="col-sm-4" style="padding-top:14px;">
                <div class="badge-row">
                    <span class="stat-pill pill-blue">
                        <i class="fa fa-check"></i> <span id="liveCompleted">0</span> done
                    </span>
                    <span class="stat-pill pill-orange">
                        <i class="fa fa-clock-o"></i> Session #<span id="liveSession">—</span>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Tests -->
    <div class="card">
        <div class="card-header">
            <i class="fa fa-history"></i> Recent Test Sessions
        </div>
        <div class="card-body" style="padding:0;">
            <div class="table-responsive">
                <table class="table table-hover table-recent" id="tblRecent" style="margin:0;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>URL</th>
                            <th>Param</th>
                            <th>Users</th>
                            <th>Requests</th>
                            <th>ID Range</th>
                            <th>Status</th>
                            <th>Started</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="recentBody">
                        <tr><td colspan="9" class="text-center text-muted" style="padding:30px;">
                            <i class="fa fa-circle-o-notch fa-spin"></i> Loading&hellip;
                        </td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div><!-- /container -->

<div class="footer">
    <i class="fa fa-bolt"></i> PT Load Tester &mdash; ASP.NET 4.5 &bull; SQL Server &bull; ApexCharts
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
    // ======== Injected from server ========
    var recentSessions   = <%=RecentSessionsJson%>;
    var dbError          = <%=DbErrorJson%>;

    $(function () {

        // Show DB error
        if (dbError) {
            $('#dbErrorMsg').text(dbError);
            $('#dbAlert').show();
        }

        // Render recent sessions table
        renderRecent(recentSessions);

        // ---- Slider sync ----
        function syncSlider(sld, num, lbl) {
            $(sld).on('input change', function () {
                var v = this.value;
                $(lbl).text(v);
                $(num).val(v);
                updateBadges();
            });
            $(num).on('input change', function () {
                var v = Math.min(Math.max(parseInt(this.value) || 1, parseInt($(sld).attr('min'))), parseInt($(sld).attr('max')));
                $(sld).val(v);
                $(lbl).text(v);
                this.value = v;
                updateBadges();
            });
        }
        syncSlider('#sldConcurrent', '#numConcurrent', '#lblConcurrent');
        syncSlider('#sldRequests',   '#numRequests',   '#lblRequests');

        $('#txtMinId, #txtMaxId').on('input change', updateBadges);

        updateBadges();

        // ---- Start Test ----
        $('#btnStart').on('click', function () {
            var url     = $.trim($('#txtUrl').val());
            var param   = $.trim($('#txtParam').val()) || 'ID';
            var cu      = parseInt($('#numConcurrent').val());
            var tr      = parseInt($('#numRequests').val());
            var minId   = parseInt($('#txtMinId').val());
            var maxId   = parseInt($('#txtMaxId').val());

            if (!url)           { alert('Please enter a target URL.'); return; }
            if (isNaN(minId) || isNaN(maxId) || minId < 0 || maxId < minId)
                { alert('Max ID must be >= Min ID and both must be non-negative.'); return; }

            setRunning(true);

            $.ajax({
                url: 'Handlers/StartTestHandler.ashx',
                type: 'POST',
                data: { testUrl: url, queryParamName: param, concurrentUsers: cu,
                        totalRequests: tr, minId: minId, maxId: maxId },
                dataType: 'json',
                success: function (d) {
                    if (d.success) {
                        $('#liveSession').text(d.sessionId);
                        pollProgress(d.sessionId, tr);
                    } else {
                        alert('Error starting test:\n' + d.error);
                        setRunning(false);
                    }
                },
                error: function (x) {
                    alert('Request failed (' + x.status + '). Is the app running?');
                    setRunning(false);
                }
            });
        });

        // ---- Poll progress ----
        var _pollTimer = null;
        function pollProgress(sessionId, totalReqs) {
            _pollTimer = setInterval(function () {
                $.getJSON('Handlers/ProgressHandler.ashx?sessionId=' + sessionId, function (d) {
                    var pct = d.progressPercent || 0;
                    $('#progressBar').css('width', pct + '%').text(pct + '%');
                    $('#progressText').text(d.completedRequests + ' / ' + d.totalRequests + ' requests completed');
                    $('#liveCompleted').text(d.completedRequests);

                    if (d.status === 'Completed') {
                        clearInterval(_pollTimer);
                        $('#progressBar').css('width', '100%').text('100%').removeClass('progress-bar-striped active');
                        $('#progressText').html('<i class="fa fa-check-circle" style="color:#2e7d32"></i> Test completed! Redirecting to results&hellip;');
                        setTimeout(function () {
                            window.location.href = 'Results.aspx?sessionId=' + sessionId;
                        }, 1200);
                    } else if (d.status === 'Error') {
                        clearInterval(_pollTimer);
                        $('#progressBar').addClass('progress-error').removeClass('progress-bar-striped active').text('Error');
                        $('#progressText').html('<i class="fa fa-exclamation-triangle" style="color:#c62828"></i> Test failed: ' + (d.errorMessage || 'Unknown error'));
                        setRunning(false);
                    }
                });
            }, 600);
        }

        function setRunning(running) {
            $('#btnStart').prop('disabled', running)
                .html(running
                    ? '<i class="fa fa-spinner fa-spin"></i>&nbsp; Running&hellip;'
                    : '<i class="fa fa-play-circle"></i>&nbsp; Start Load Test');
            if (running) { $('#progressPanel').slideDown(250); }
            else         { $('#progressPanel').slideUp(250); }
        }

        function updateBadges() {
            var cu  = parseInt($('#numConcurrent').val()) || 1;
            var tr  = parseInt($('#numRequests').val())   || 1;
            var min = $('#txtMinId').val();
            var max = $('#txtMaxId').val();
            $('#reqPerUser').text(Math.ceil(tr / cu));
            $('#idRangeDisplay').text(min + ' \u2013 ' + max);
        }

        // ---- Render recent sessions ----
        function renderRecent(sessions) {
            var tbody = $('#recentBody');
            tbody.empty();
            if (!sessions || sessions.length === 0) {
                tbody.append('<tr><td colspan="9" class="text-center text-muted" style="padding:30px;">' +
                    '<i class="fa fa-inbox"></i> No test sessions yet. Run your first test above!</td></tr>');
                return;
            }
            $.each(sessions, function (i, s) {
                var statusClass = { Completed:'completed', Running:'running', Error:'error', Pending:'pending' }[s.Status] || 'pending';
                var started = s.StartTime ? new Date(parseInt(s.StartTime.replace('/Date(', '').replace(')/', ''))).toLocaleString() : '';
                tbody.append(
                    '<tr>' +
                    '<td><strong>#' + s.SessionId + '</strong></td>' +
                    '<td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + escHtml(s.TestUrl) + '">' + escHtml(s.TestUrl) + '</td>' +
                    '<td><code>' + escHtml(s.QueryParamName) + '</code></td>' +
                    '<td><i class="fa fa-users"></i> ' + s.ConcurrentUsers + '</td>' +
                    '<td>' + s.TotalRequests + '</td>' +
                    '<td style="font-size:11px;">' + s.MinId + '&ndash;' + s.MaxId + '</td>' +
                    '<td><span class="status-badge status-' + statusClass + '">' + s.Status + '</span></td>' +
                    '<td style="font-size:11px;">' + started + '</td>' +
                    '<td>' + (s.Status === 'Completed'
                        ? '<a href="Results.aspx?sessionId=' + s.SessionId + '" class="btn btn-xs btn-primary"><i class="fa fa-bar-chart"></i> View</a>'
                        : '') + '</td>' +
                    '</tr>');
            });
        }

        function escHtml(str) {
            if (!str) return '';
            return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        }

    }); // ready
</script>
</body>
</html>
