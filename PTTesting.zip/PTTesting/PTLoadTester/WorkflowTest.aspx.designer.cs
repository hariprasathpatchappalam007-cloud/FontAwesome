namespace PTLoadTester
{
    public partial class WorkflowTest
    {
        // No server-side controls; all interaction is handled via JavaScript.
    }
}
