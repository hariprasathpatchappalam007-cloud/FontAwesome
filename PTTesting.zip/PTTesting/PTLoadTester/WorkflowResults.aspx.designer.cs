namespace PTLoadTester
{
    public partial class WorkflowResults
    {
        // No server-side controls; data is injected via <%=...%> properties.
    }
}
