using System;
using System.Configuration;
using System.Web;
using System.Web.Script.Serialization;
using PTLoadTester.DAL;
using PTLoadTester.Engine;
using PTLoadTester.Models;

namespace PTLoadTester.Handlers
{
    /// <summary>
    /// Receives load-test configuration, creates a DB session and fires
    /// the test off on a background thread. Returns JSON { success, sessionId }.
    /// </summary>
    public class StartTestHandler : IHttpHandler
    {
        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);

            var js = new JavaScriptSerializer();

            try
            {
                if (!string.Equals(context.Request.HttpMethod, "POST", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("POST required.");

                // ---- Read & validate inputs ----
                string rawUrl       = (context.Request.Form["testUrl"] ?? "").Trim();
                string paramName    = (context.Request.Form["queryParamName"] ?? "ID").Trim();
                int concurrentUsers = ParseInt(context.Request.Form["concurrentUsers"], 100);
                int totalRequests   = ParseInt(context.Request.Form["totalRequests"], 500);
                int minId           = ParseInt(context.Request.Form["minId"], 1000000);
                int maxId           = ParseInt(context.Request.Form["maxId"], 9999999);

                if (string.IsNullOrEmpty(rawUrl))
                    throw new ArgumentException("Target URL is required.");

                Uri uri;
                if (!Uri.TryCreate(rawUrl, UriKind.Absolute, out uri))
                    throw new ArgumentException("Invalid URL format. Must start with http:// or https://.");

                if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)
                    throw new ArgumentException("Only http and https URLs are supported.");

                string baseUrl = uri.GetLeftPart(UriPartial.Path);

                // Auto-detect param name from supplied URL if not explicitly overridden
                if (string.Equals(paramName, "ID", StringComparison.OrdinalIgnoreCase) &&
                    !string.IsNullOrEmpty(uri.Query))
                {
                    var qs = HttpUtility.ParseQueryString(uri.Query);
                    if (qs.Count > 0 && !string.IsNullOrEmpty(qs.AllKeys[0]))
                        paramName = qs.AllKeys[0];
                }

                int maxUsers  = GetAppSettingInt("MaxConcurrentUsers",  500);
                int maxReqs   = GetAppSettingInt("MaxTotalRequests",    10000);

                if (concurrentUsers < 1 || concurrentUsers > maxUsers)
                    throw new ArgumentException(string.Format("Concurrent users must be 1–{0}.", maxUsers));

                if (totalRequests < 1 || totalRequests > maxReqs)
                    throw new ArgumentException(string.Format("Total requests must be 1–{0}.", maxReqs));

                if (minId < 0 || maxId < minId)
                    throw new ArgumentException("Max ID must be >= Min ID and both must be non-negative.");

                if (string.IsNullOrEmpty(paramName))
                    paramName = "ID";

                // ---- Persist session ----
                var session = new LoadTestSession
                {
                    TestUrl        = baseUrl,
                    QueryParamName = paramName,
                    ConcurrentUsers = concurrentUsers,
                    TotalRequests  = totalRequests,
                    MinId          = minId,
                    MaxId          = maxId,
                    StartTime      = DateTime.Now,
                    Status         = "Pending"
                };

                int sessionId = DatabaseHelper.CreateSession(session);

                // ---- Launch background test ----
                LoadTestEngine.RunTestAsync(sessionId, baseUrl, paramName,
                    concurrentUsers, totalRequests, minId, maxId);

                context.Response.Write(js.Serialize(new { success = true, sessionId = sessionId }));
            }
            catch (Exception ex)
            {
                context.Response.Write(js.Serialize(new { success = false, error = ex.Message }));
            }
        }

        private static int ParseInt(string value, int defaultValue)
        {
            int result;
            return int.TryParse(value, out result) ? result : defaultValue;
        }

        private static int GetAppSettingInt(string key, int fallback)
        {
            int v;
            return int.TryParse(ConfigurationManager.AppSettings[key], out v) ? v : fallback;
        }
    }
}
