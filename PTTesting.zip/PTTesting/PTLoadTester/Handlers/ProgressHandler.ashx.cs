using System;
using System.Web;
using System.Web.Script.Serialization;
using PTLoadTester.Engine;

namespace PTLoadTester.Handlers
{
    /// <summary>
    /// Lightweight polling endpoint.
    /// GET /Handlers/ProgressHandler.ashx?sessionId=42
    /// Returns JSON { status, completedRequests, totalRequests, progressPercent, errorMessage, sessionId }
    /// </summary>
    public class ProgressHandler : IHttpHandler
    {
        public bool IsReusable { get { return true; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            context.Response.Cache.SetNoStore();

            var js = new JavaScriptSerializer();

            try
            {
                int sessionId;
                if (!int.TryParse(context.Request.QueryString["sessionId"], out sessionId) || sessionId <= 0)
                    throw new ArgumentException("Valid sessionId is required.");

                var progress = LoadTestEngine.GetProgress(sessionId);

                if (progress == null)
                {
                    // Test may have been submitted before this app-pool instance started;
                    // fall back to the database for a final status.
                    context.Response.Write(js.Serialize(new
                    {
                        status = "Unknown",
                        completedRequests = 0,
                        totalRequests = 0,
                        progressPercent = 0,
                        errorMessage = (string)null,
                        sessionId = sessionId
                    }));
                    return;
                }

                int pct = progress.TotalRequests > 0
                    ? Math.Min(100, (int)((progress.CompletedRequests * 100L) / progress.TotalRequests))
                    : 0;

                context.Response.Write(js.Serialize(new
                {
                    status            = progress.Status,
                    completedRequests = progress.CompletedRequests,
                    totalRequests     = progress.TotalRequests,
                    progressPercent   = pct,
                    errorMessage      = progress.ErrorMessage,
                    sessionId         = progress.SessionId
                }));
            }
            catch (Exception ex)
            {
                var js2 = new JavaScriptSerializer();
                context.Response.Write(js2.Serialize(new { status = "Error", error = ex.Message }));
            }
        }
    }
}
