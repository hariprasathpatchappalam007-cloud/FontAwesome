using System;
using System.Web;
using System.Web.Script.Serialization;
using PTLoadTester.Engine;

namespace PTLoadTester.Handlers
{
    /// <summary>
    /// Lightweight polling endpoint for workflow test progress.
    /// GET /Handlers/WorkflowProgressHandler.ashx?sessionId=42
    /// Returns JSON { status, completedTasks, totalTasks, progressPercent, errorMessage, sessionId }
    /// </summary>
    public class WorkflowProgressHandler : IHttpHandler
    {
        public bool IsReusable { get { return true; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            context.Response.Cache.SetNoStore();

            var js = new JavaScriptSerializer();

            try
            {
                int sessionId;
                if (!int.TryParse(context.Request.QueryString["sessionId"], out sessionId) || sessionId <= 0)
                    throw new ArgumentException("Valid sessionId is required.");

                var prog = WorkflowTestEngine.GetProgress(sessionId);

                if (prog == null)
                {
                    context.Response.Write(js.Serialize(new
                    {
                        status          = "Unknown",
                        completedTasks  = 0,
                        totalTasks      = 0,
                        progressPercent = 0,
                        errorMessage    = (string)null,
                        sessionId       = sessionId
                    }));
                    return;
                }

                int pct = prog.TotalTasks > 0
                    ? Math.Min(100, (int)((prog.CompletedTasks * 100L) / prog.TotalTasks))
                    : 0;

                context.Response.Write(js.Serialize(new
                {
                    status          = prog.Status,
                    completedTasks  = prog.CompletedTasks,
                    totalTasks      = prog.TotalTasks,
                    progressPercent = pct,
                    errorMessage    = prog.ErrorMessage,
                    sessionId       = prog.SessionId
                }));
            }
            catch (Exception ex)
            {
                context.Response.Write(new JavaScriptSerializer().Serialize(
                    new { status = "Error", error = ex.Message }));
            }
        }
    }
}
