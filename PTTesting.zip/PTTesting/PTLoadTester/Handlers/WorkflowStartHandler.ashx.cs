using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Script.Serialization;
using PTLoadTester.DAL;
using PTLoadTester.Engine;
using PTLoadTester.Models;

namespace PTLoadTester.Handlers
{
    /// <summary>
    /// POST handler that creates a workflow test session and fires it on a background thread.
    /// Returns JSON { success, sessionId } or { success:false, error }.
    /// </summary>
    public class WorkflowStartHandler : IHttpHandler
    {
        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            var js = new JavaScriptSerializer();
            js.MaxJsonLength = 1024 * 1024;

            try
            {
                if (!string.Equals(context.Request.HttpMethod, "POST",
                        StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("POST required.");

                // ---- Read inputs ----
                string loginUrl      = (context.Request.Form["loginUrl"]      ?? "").Trim();
                string loginPostData = (context.Request.Form["loginPostData"] ?? "").Trim();
                string urlsJson      = (context.Request.Form["targetUrls"]    ?? "[]").Trim();
                string testName      = (context.Request.Form["testName"]      ?? "Workflow Test").Trim();
                string userId        = (context.Request.Form["userId"]        ?? "SPUser05").Trim();
                int concurrentUsers  = ParseInt(context.Request.Form["concurrentUsers"], 5);
                int iterations       = ParseInt(context.Request.Form["iterations"],      3);
                int timeoutMs        = ParseInt(context.Request.Form["timeoutMs"],       30000);

                // ---- Validate ----
                List<string> urls;
                try   { urls = js.Deserialize<List<string>>(urlsJson); }
                catch { urls = new List<string>(); }

                if (urls == null || urls.Count == 0)
                    throw new ArgumentException("Select at least one target URL.");

                if (!string.IsNullOrEmpty(loginUrl))
                {
                    Uri dummy;
                    if (!Uri.TryCreate(loginUrl, UriKind.Absolute, out dummy) ||
                        (dummy.Scheme != Uri.UriSchemeHttp && dummy.Scheme != Uri.UriSchemeHttps))
                        throw new ArgumentException("Login URL must start with http:// or https://");
                }

                if (concurrentUsers < 1 || concurrentUsers > 200)
                    throw new ArgumentException("Concurrent users must be between 1 and 200.");
                if (iterations < 1 || iterations > 500)
                    throw new ArgumentException("Iterations must be between 1 and 500.");
                if (timeoutMs < 1000 || timeoutMs > 120000)
                    timeoutMs = 30000;

                // ---- Create DB session record ----
                var session = new WorkflowTestSession
                {
                    TestName        = string.IsNullOrEmpty(testName) ? "Workflow Test" : testName,
                    LoginUrl        = loginUrl,
                    UserId          = userId,
                    ConcurrentUsers = concurrentUsers,
                    Iterations      = iterations,
                    TotalUrls       = urls.Count,
                    StartTime       = DateTime.Now,
                    Status          = "Pending"
                };
                int sessionId = DatabaseHelper.CreateWorkflowSession(session);

                // ---- Launch background test ----
                var config = new WorkflowTestConfig
                {
                    LoginUrl         = loginUrl,
                    LoginPostData    = loginPostData,
                    TargetUrls       = urls,
                    ConcurrentUsers  = concurrentUsers,
                    Iterations       = iterations,
                    RequestTimeoutMs = timeoutMs
                };
                WorkflowTestEngine.RunTestAsync(sessionId, config);

                context.Response.Write(js.Serialize(new { success = true, sessionId = sessionId }));
            }
            catch (Exception ex)
            {
                context.Response.Write(js.Serialize(new { success = false, error = ex.Message }));
            }
        }

        private static int ParseInt(string s, int defaultValue)
        {
            int v;
            return int.TryParse(s, out v) && v > 0 ? v : defaultValue;
        }
    }
}
