<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WorkflowResults.aspx.cs" Inherits="PTLoadTester.WorkflowResults" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Workflow Results &mdash; PT Load Tester</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap.min.css" />
    <style>
        body { background:#f0f2f7; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; }
        .navbar-custom { background:linear-gradient(135deg,#1a237e,#1565c0); border:none; border-radius:0; box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .navbar-custom .navbar-brand { color:#fff!important; font-weight:700; font-size:20px; }
        .navbar-custom .navbar-brand span { color:#82b1ff; }
        .navbar-custom .navbar-nav > li > a { color:#cfd8dc!important; font-size:13px; }
        .navbar-custom .navbar-nav > li > a:hover { color:#fff!important; background:rgba(255,255,255,.1)!important; }
        .hero-strip { background:linear-gradient(135deg,#0d47a1,#1565c0); color:#fff; padding:22px 0 18px; margin-bottom:26px; box-shadow:0 3px 10px rgba(0,0,0,.2); }
        .hero-strip h3 { margin:0 0 4px; font-weight:300; font-size:24px; }
        .hero-strip p  { margin:0; opacity:.8; font-size:13px; }
        /* KPI */
        .kpi-grid { display:flex; flex-wrap:wrap; gap:16px; margin-bottom:26px; }
        .kpi-card { flex:1; min-width:140px; background:#fff; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,.08); padding:18px 20px; border-top:4px solid transparent; position:relative; overflow:hidden; }
        .kpi-card::before { content:''; position:absolute; top:0; right:0; width:60px; height:60px; border-radius:0 10px 0 60px; opacity:.08; }
        .kpi-blue   { border-top-color:#1565c0; } .kpi-blue::before   { background:#1565c0; }
        .kpi-green  { border-top-color:#2e7d32; } .kpi-green::before  { background:#2e7d32; }
        .kpi-orange { border-top-color:#e65100; } .kpi-orange::before { background:#e65100; }
        .kpi-teal   { border-top-color:#00695c; } .kpi-teal::before   { background:#00695c; }
        .kpi-purple { border-top-color:#6a1b9a; } .kpi-purple::before { background:#6a1b9a; }
        .kpi-card .kpi-label { font-size:11px; text-transform:uppercase; letter-spacing:.6px; color:#90a4ae; font-weight:600; margin-bottom:6px; }
        .kpi-card .kpi-value { font-size:28px; font-weight:700; color:#263238; line-height:1.1; }
        .kpi-card .kpi-sub   { font-size:12px; color:#78909c; margin-top:3px; }
        .kpi-card .kpi-icon  { position:absolute; top:16px; right:18px; font-size:24px; opacity:.18; }
        /* Chart / table cards */
        .chart-card { background:#fff; border-radius:10px; box-shadow:0 2px 12px rgba(0,0,0,.09); margin-bottom:24px; overflow:hidden; }
        .chart-card-header { background:linear-gradient(90deg,#1565c0,#0d47a1); color:#fff; padding:12px 20px; font-size:14px; font-weight:600; }
        .chart-card-header .fa { margin-right:8px; }
        .chart-card-body { padding:16px; }
        /* Per-URL summary table */
        .tbl-url-summary th { background:#f5f7fb; color:#455a64; font-size:11px; text-transform:uppercase; letter-spacing:.5px; white-space:nowrap; }
        .tbl-url-summary td { font-size:12px; vertical-align:middle; }
        .tbl-url-summary .time-cell { font-weight:600; }
        .badge-ok  { background:#c8e6c9; color:#1b5e20; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:700; }
        .badge-err { background:#ffcdd2; color:#b71c1c; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:700; }
        /* Detail table */
        #tblDetail thead th { background:#f5f7fb; color:#455a64; font-size:11px; text-transform:uppercase; letter-spacing:.5px; }
        #tblDetail td { font-size:12px; vertical-align:middle; }
        .pill-ok  { background:#c8e6c9; color:#1b5e20; padding:2px 7px; border-radius:10px; font-size:11px; font-weight:700; }
        .pill-fail{ background:#ffcdd2; color:#b71c1c; padding:2px 7px; border-radius:10px; font-size:11px; font-weight:700; }
        .status-badge { padding:3px 10px; border-radius:12px; font-size:11px; font-weight:700; text-transform:uppercase; }
        .status-completed { background:#c8e6c9; color:#1b5e20; }
        .status-running   { background:#bbdefb; color:#0d47a1; }
        .status-error     { background:#ffcdd2; color:#b71c1c; }
        .btn-back { background:#fff; color:#1565c0; border:2px solid #1565c0; border-radius:6px; padding:7px 18px; font-size:13px; font-weight:600; transition:all .2s; }
        .btn-back:hover { background:#1565c0; color:#fff; }
        .footer { text-align:center; padding:20px; color:#90a4ae; font-size:12px; }
    </style>
</head>
<body>

<nav class="navbar navbar-custom navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navMenu">
                <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="Default.aspx">
                <i class="fa fa-tachometer"></i> PT<span>LoadTester</span>
            </a>
        </div>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="nav navbar-nav">
                <li><a href="Default.aspx"><i class="fa fa-home"></i> Query Load Test</a></li>
                <li><a href="WorkflowTest.aspx"><i class="fa fa-sitemap"></i> Workflow Page Test</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="hero-strip">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-8">
                <h3><i class="fa fa-bar-chart"></i> Workflow Test Results &mdash; #<%=SessionId%></h3>
                <p>
                    <strong><%=Server.HtmlEncode(TestName)%></strong>
                    &nbsp;|&nbsp; User: <strong><%=Server.HtmlEncode(UserId)%></strong>
                    &nbsp;|&nbsp; <i class="fa fa-users"></i> <%=ConcurrentUsers%> users &times;
                    <%=Iterations%> iterations
                    &nbsp;|&nbsp; <i class="fa fa-clock-o"></i> <%=SessionStarted%>
                    &nbsp;|&nbsp;
                    <span class="status-badge status-<%=SessionStatus.ToLower()%>"><%=SessionStatus%></span>
                </p>
            </div>
            <div class="col-sm-4 text-right" style="padding-top:10px;">
                <a href="WorkflowTest.aspx" class="btn-back">
                    <i class="fa fa-arrow-left"></i> Back to Workflow Test
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid" style="max-width:1440px;">

    <!-- KPI Cards -->
    <div class="kpi-grid">
        <div class="kpi-card kpi-blue">
            <div class="kpi-icon"><i class="fa fa-list-ol"></i></div>
            <div class="kpi-label">Total Tests</div>
            <div class="kpi-value" id="kpiTotal">—</div>
            <div class="kpi-sub" id="kpiConfig">—</div>
        </div>
        <div class="kpi-card kpi-green">
            <div class="kpi-icon"><i class="fa fa-check-circle"></i></div>
            <div class="kpi-label">Page Load Success</div>
            <div class="kpi-value" id="kpiPageOk">—</div>
            <div class="kpi-sub" id="kpiPageRate">—</div>
        </div>
        <div class="kpi-card kpi-teal">
            <div class="kpi-icon"><i class="fa fa-mouse-pointer"></i></div>
            <div class="kpi-label">Select Action Success</div>
            <div class="kpi-value" id="kpiSelectOk">—</div>
            <div class="kpi-sub" id="kpiSelectRate">—</div>
        </div>
        <div class="kpi-card kpi-orange">
            <div class="kpi-icon"><i class="fa fa-hourglass-half"></i></div>
            <div class="kpi-label">Avg Page Load</div>
            <div class="kpi-value" id="kpiAvgPage">—</div>
            <div class="kpi-sub">milliseconds</div>
        </div>
        <div class="kpi-card kpi-purple">
            <div class="kpi-icon"><i class="fa fa-bolt"></i></div>
            <div class="kpi-label">Avg Select Action</div>
            <div class="kpi-value" id="kpiAvgSelect">—</div>
            <div class="kpi-sub">milliseconds</div>
        </div>
    </div>

    <!-- Grouped bar chart: avg times per URL -->
    <div class="chart-card">
        <div class="chart-card-header">
            <i class="fa fa-bar-chart"></i> Average Response Time per URL
            <small style="opacity:.75; float:right; font-weight:400;">Blue = Page Load &nbsp;|&nbsp; Orange = Select Action</small>
        </div>
        <div class="chart-card-body">
            <div id="chartGroupedBar"></div>
        </div>
    </div>

    <!-- Per-URL summary table -->
    <div class="chart-card">
        <div class="chart-card-header"><i class="fa fa-table"></i> Per-URL Performance Summary</div>
        <div class="chart-card-body" style="overflow-x:auto;">
            <table class="table table-bordered table-condensed tbl-url-summary" id="tblUrlSummary" style="width:100%;">
                <thead>
                    <tr>
                        <th>Page</th>
                        <th>Tests</th>
                        <th colspan="4" style="text-align:center;background:#e3f2fd;color:#0d47a1;">
                            &#x1F4BE; Page Load (ms)
                        </th>
                        <th colspan="4" style="text-align:center;background:#fff3e0;color:#e65100;">
                            &#x1F5B1; Select Action (ms)
                        </th>
                        <th>Page OK</th>
                        <th>Select OK</th>
                    </tr>
                    <tr>
                        <th></th><th></th>
                        <th style="background:#e3f2fd;">Avg</th>
                        <th style="background:#e3f2fd;">Min</th>
                        <th style="background:#e3f2fd;">Max</th>
                        <th style="background:#e3f2fd;">P95</th>
                        <th style="background:#fff3e0;">Avg</th>
                        <th style="background:#fff3e0;">Min</th>
                        <th style="background:#fff3e0;">Max</th>
                        <th style="background:#fff3e0;">P95</th>
                        <th></th><th></th>
                    </tr>
                </thead>
                <tbody id="urlSummaryBody"></tbody>
            </table>
        </div>
    </div>

    <!-- Detailed DataTable -->
    <div class="chart-card">
        <div class="chart-card-header">
            <i class="fa fa-list"></i> Detailed Request Log
            <small style="float:right; font-weight:400; opacity:.75; font-size:12px;">
                <i class="fa fa-download"></i> Use CSV/Excel export buttons
            </small>
        </div>
        <div class="chart-card-body" style="overflow-x:auto;">
            <table id="tblDetail" class="table table-bordered table-condensed" style="width:100%;">
                <thead>
                    <tr>
                        <th>Page</th>
                        <th>User</th>
                        <th>Iter</th>
                        <th>Page Load (ms)</th>
                        <th>Page HTTP</th>
                        <th>Page OK</th>
                        <th>Select (ms)</th>
                        <th>Select HTTP</th>
                        <th>Select OK</th>
                        <th>Time</th>
                        <th>Error</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

</div>

<div class="footer"><i class="fa fa-sitemap"></i> PT Load Tester &mdash; Workflow Results #<%=SessionId%></div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts@3.41.0/dist/apexcharts.min.js"></script>

<script>
    var urlSummaries  = <%=UrlSummariesJson%>;
    var overallSummary = <%=OverallSummaryJson%>;
    var detailData    = <%=ResultsJson%>;

    $(function () {
        var s = overallSummary;

        // ---- KPI cards ----
        $('#kpiTotal').text(s.TotalTests);
        $('#kpiConfig').text(s.ConcurrentUsers + ' users \u00d7 ' + s.Iterations + ' iter \u00d7 ' + s.TotalUrls + ' URLs');
        $('#kpiPageOk').text(s.PageSuccessCount);
        $('#kpiPageRate').text(s.PageSuccessRate.toFixed(1) + '% success rate');
        $('#kpiSelectOk').text(s.SelectSuccessCount);
        $('#kpiSelectRate').text(s.SelectSuccessRate.toFixed(1) + '% success rate');
        $('#kpiAvgPage').text(Math.round(s.OverallAvgPageMs));
        $('#kpiAvgSelect').text(Math.round(s.OverallAvgSelectMs));

        // ---- Per-URL summary table ----
        var tbody = '';
        urlSummaries.forEach(function (u) {
            var pageRate   = u.TotalRequests > 0 ? (u.PageSuccessCount   / u.TotalRequests * 100).toFixed(0) : 0;
            var selectRate = u.TotalRequests > 0 ? (u.SelectSuccessCount / u.TotalRequests * 100).toFixed(0) : 0;
            tbody += '<tr>' +
                '<td title="' + escHtml(u.Url) + '"><strong>' + escHtml(u.UrlShort) + '</strong></td>' +
                '<td>' + u.TotalRequests + '</td>' +
                '<td class="time-cell" style="background:#e3f2fd;">' + Math.round(u.AvgPageLoadMs) + '</td>' +
                '<td style="background:#e3f2fd;">' + u.MinPageLoadMs + '</td>' +
                '<td style="background:#e3f2fd;">' + u.MaxPageLoadMs + '</td>' +
                '<td style="background:#e3f2fd;">' + Math.round(u.P95PageLoadMs) + '</td>' +
                '<td class="time-cell" style="background:#fff3e0;">' + Math.round(u.AvgSelectMs) + '</td>' +
                '<td style="background:#fff3e0;">' + u.MinSelectMs + '</td>' +
                '<td style="background:#fff3e0;">' + u.MaxSelectMs + '</td>' +
                '<td style="background:#fff3e0;">' + Math.round(u.P95SelectMs) + '</td>' +
                '<td><span class="' + (pageRate >= 80 ? 'badge-ok' : 'badge-err') + '">' + pageRate + '%</span></td>' +
                '<td><span class="' + (selectRate >= 80 ? 'badge-ok' : 'badge-err') + '">' + selectRate + '%</span></td>' +
                '</tr>';
        });
        document.getElementById('urlSummaryBody').innerHTML = tbody;

        // ---- Grouped bar chart ----
        var labels     = urlSummaries.map(function(u) { return u.UrlShort; });
        var pageAvgs   = urlSummaries.map(function(u) { return Math.round(u.AvgPageLoadMs); });
        var selectAvgs = urlSummaries.map(function(u) { return Math.round(u.AvgSelectMs); });

        var chartOpts = {
            series: [
                { name: 'Avg Page Load (ms)',   data: pageAvgs   },
                { name: 'Avg Select Action (ms)', data: selectAvgs }
            ],
            chart: {
                type: 'bar', height: 380,
                toolbar: { show: true },
                animations: { enabled: false }
            },
            colors: ['#1565c0', '#e65100'],
            plotOptions: { bar: { horizontal: false, columnWidth: '55%', borderRadius: 4 } },
            dataLabels: { enabled: false },
            xaxis: {
                categories: labels,
                labels: { rotate: -35, style: { fontSize: '11px' } }
            },
            yaxis: {
                title: { text: 'Response Time (ms)', style: { color: '#546e7a' } },
                min: 0
            },
            legend: { position: 'top' },
            tooltip: {
                y: { formatter: function(v) { return v + ' ms'; } }
            }
        };
        new ApexCharts(document.getElementById('chartGroupedBar'), chartOpts).render();

        // ---- Detailed DataTable ----
        var rows = detailData.map(function(r) {
            return [
                '<span title="' + escHtml(r.TargetUrl) + '">' + escHtml(r.UrlShort) + '</span>',
                'VU' + r.VirtualUserId,
                r.IterationNumber,
                r.PageLoadTimeMs,
                r.PageLoadStatusCode || '—',
                r.PageLoadSuccess  ? '<span class="pill-ok">OK</span>'   : '<span class="pill-fail">FAIL</span>',
                r.SelectActionTimeMs,
                r.SelectActionStatusCode || '—',
                r.SelectActionSuccess ? '<span class="pill-ok">OK</span>' : '<span class="pill-fail">FAIL</span>',
                r.RequestTime,
                r.ErrorMessage ? '<span class="text-danger" title="' + escHtml(r.ErrorMessage) + '">' +
                    escHtml(r.ErrorMessage.substring(0, 60)) + (r.ErrorMessage.length > 60 ? '…' : '') + '</span>' : ''
            ];
        });

        $('#tblDetail').DataTable({
            data: rows,
            columns: [
                { title: 'Page' }, { title: 'User' }, { title: 'Iter' },
                { title: 'Page Load (ms)' }, { title: 'Page HTTP' }, { title: 'Page OK' },
                { title: 'Select (ms)' }, { title: 'Select HTTP' }, { title: 'Select OK' },
                { title: 'Time' }, { title: 'Error' }
            ],
            pageLength: 25,
            order: [[0, 'asc'], [1, 'asc'], [2, 'asc']],
            dom: 'Bfrtip',
            buttons: [
                { extend: 'csvHtml5',   text: '<i class="fa fa-download"></i> CSV',   className: 'btn btn-xs btn-default' },
                { extend: 'excelHtml5', text: '<i class="fa fa-file-excel-o"></i> Excel', className: 'btn btn-xs btn-default' }
            ],
            language: { search: 'Filter:' }
        });
    });

    function escHtml(s) {
        if (!s) return '';
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
</script>
</body>
</html>
