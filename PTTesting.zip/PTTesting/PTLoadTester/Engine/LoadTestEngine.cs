using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using PTLoadTester.DAL;
using PTLoadTester.Models;

namespace PTLoadTester.Engine
{
    public static class LoadTestEngine
    {
        // Stores live progress keyed by sessionId — survives for the app-pool lifetime
        private static readonly ConcurrentDictionary<int, TestProgressInfo> _progress
            = new ConcurrentDictionary<int, TestProgressInfo>();

        // Per-thread random to avoid lock contention
        private static readonly ThreadLocal<Random> _rng =
            new ThreadLocal<Random>(() => new Random(Guid.NewGuid().GetHashCode()));

        public static void RunTestAsync(int sessionId, string baseUrl, string paramName,
            int concurrentUsers, int totalRequests, int minId, int maxId)
        {
            var info = new TestProgressInfo
            {
                SessionId = sessionId,
                Status = "Running",
                CompletedRequests = 0,
                TotalRequests = totalRequests
            };
            _progress[sessionId] = info;

            // Fire and forget on a background thread
            Task.Factory.StartNew(
                () => ExecuteTest(sessionId, baseUrl, paramName, concurrentUsers, totalRequests, minId, maxId, info),
                TaskCreationOptions.LongRunning);
        }

        public static TestProgressInfo GetProgress(int sessionId)
        {
            TestProgressInfo info;
            return _progress.TryGetValue(sessionId, out info) ? info : null;
        }

        // ----------------------------------------------------------------
        private static void ExecuteTest(int sessionId, string baseUrl, string paramName,
            int concurrentUsers, int totalRequests, int minId, int maxId, TestProgressInfo progress)
        {
            DatabaseHelper.UpdateSessionStatus(sessionId, "Running");

            var results = new ConcurrentBag<LoadTestResult>();
            int completed = 0;
            int requestTimeoutMs = 30000;
            int cfgTimeout;
            if (int.TryParse(ConfigurationManager.AppSettings["RequestTimeoutMs"], out cfgTimeout) && cfgTimeout > 0)
                requestTimeoutMs = cfgTimeout;

            try
            {
                var options = new ParallelOptions { MaxDegreeOfParallelism = concurrentUsers };

                Parallel.For(0, totalRequests, options, i =>
                {
                    int randomId = _rng.Value.Next(minId, maxId + 1);
                    string idStr = randomId.ToString();
                    string fullUrl = string.Concat(baseUrl, "?", paramName, "=", idStr);

                    var result = new LoadTestResult
                    {
                        SessionId = sessionId,
                        RequestNumber = i + 1,
                        QueryStringId = idStr,
                        FullUrl = fullUrl,
                        RequestTime = DateTime.Now
                    };

                    MakeRequest(fullUrl, requestTimeoutMs, result);

                    results.Add(result);
                    int done = Interlocked.Increment(ref completed);
                    progress.CompletedRequests = done;
                });

                // Persist all results in bulk
                DatabaseHelper.BulkInsertResults(new List<LoadTestResult>(results));
                DatabaseHelper.UpdateSessionStatus(sessionId, "Completed", DateTime.Now);

                progress.Status = "Completed";
                progress.CompletedRequests = totalRequests;
            }
            catch (Exception ex)
            {
                DatabaseHelper.UpdateSessionStatus(sessionId, "Error");
                progress.Status = "Error";
                progress.ErrorMessage = ex.Message;
            }

            _progress[sessionId] = progress;
        }

        private static void MakeRequest(string url, int timeoutMs, LoadTestResult result)
        {
            var sw = Stopwatch.StartNew();
            try
            {
                var req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "GET";
                req.Timeout = timeoutMs;
                req.ReadWriteTimeout = timeoutMs;
                req.AllowAutoRedirect = true;
                req.KeepAlive = false;           // avoid socket exhaustion
                req.UserAgent = "PTLoadTester/1.0 (+PerfTest)";
                req.Accept = "text/html,image/*,*/*;q=0.8";

                using (var resp = (HttpWebResponse)req.GetResponse())
                {
                    sw.Stop();
                    var code = (int)resp.StatusCode;
                    result.StatusCode = code;
                    result.ResponseTimeMs = sw.ElapsedMilliseconds;
                    result.IsSuccess = (code >= 200 && code < 400);
                    // Drain response body to allow connection reuse
                    using (resp.GetResponseStream()) { }
                }
            }
            catch (WebException ex)
            {
                sw.Stop();
                result.ResponseTimeMs = sw.ElapsedMilliseconds;
                result.IsSuccess = false;
                if (ex.Response != null)
                {
                    result.StatusCode = (int)((HttpWebResponse)ex.Response).StatusCode;
                    result.ErrorMessage = TruncateError(ex.Message);
                }
                else
                {
                    result.StatusCode = 0;
                    result.ErrorMessage = TruncateError(ex.Status + ": " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                sw.Stop();
                result.ResponseTimeMs = sw.ElapsedMilliseconds;
                result.StatusCode = 0;
                result.IsSuccess = false;
                result.ErrorMessage = TruncateError(ex.Message);
            }
        }

        private static string TruncateError(string msg)
        {
            if (msg == null) return null;
            return msg.Length > 490 ? msg.Substring(0, 490) : msg;
        }
    }
}
