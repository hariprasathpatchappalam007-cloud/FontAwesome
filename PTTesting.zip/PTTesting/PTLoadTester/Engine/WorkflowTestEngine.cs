using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using PTLoadTester.DAL;
using PTLoadTester.Models;

namespace PTLoadTester.Engine
{
    /// <summary>
    /// Workflow page load tester.
    /// Each virtual user:
    ///   1. Authenticates via a configurable login POST (once per virtual user).
    ///   2. For every iteration × every target URL:
    ///        Phase A – GET the page and record the page-load time.
    ///        Phase B – Simulate a click on the "select" button inside
    ///                  grdApplicationDetails and record the postback time.
    /// </summary>
    public static class WorkflowTestEngine
    {
        private static readonly ConcurrentDictionary<int, WorkflowProgress> _progress
            = new ConcurrentDictionary<int, WorkflowProgress>();

        // ----------------------------------------------------------------
        // Public API
        // ----------------------------------------------------------------

        public static void RunTestAsync(int sessionId, WorkflowTestConfig config)
        {
            int totalTasks = config.ConcurrentUsers * config.Iterations * config.TargetUrls.Count;
            var prog = new WorkflowProgress
            {
                SessionId      = sessionId,
                Status         = "Running",
                TotalTasks     = Math.Max(1, totalTasks),
                CompletedTasks = 0
            };
            _progress[sessionId] = prog;

            Task.Factory.StartNew(
                () => ExecuteTest(sessionId, config, prog),
                TaskCreationOptions.LongRunning);
        }

        public static WorkflowProgress GetProgress(int sessionId)
        {
            WorkflowProgress prog;
            return _progress.TryGetValue(sessionId, out prog) ? prog : null;
        }

        // ----------------------------------------------------------------
        // Core execution
        // ----------------------------------------------------------------

        private static void ExecuteTest(int sessionId, WorkflowTestConfig config, WorkflowProgress progress)
        {
            DatabaseHelper.UpdateWorkflowSessionStatus(sessionId, "Running");
            var allResults = new ConcurrentBag<WorkflowPageResult>();
            int completed  = 0;

            try
            {
                var opts = new ParallelOptions { MaxDegreeOfParallelism = config.ConcurrentUsers };

                Parallel.For(0, config.ConcurrentUsers, opts, vuId =>
                {
                    var jar    = new CookieContainer();
                    bool authed = Authenticate(config, jar);

                    for (int iter = 1; iter <= config.Iterations; iter++)
                    {
                        foreach (string url in config.TargetUrls)
                        {
                            var r = new WorkflowPageResult
                            {
                                SessionId       = sessionId,
                                TargetUrl       = url,
                                VirtualUserId   = vuId + 1,
                                IterationNumber = iter,
                                RequestTime     = DateTime.Now
                            };

                            if (!authed)
                            {
                                r.ErrorMessage = "Login failed – check Login URL / POST data.";
                            }
                            else
                            {
                                TestPage(url, jar, config.RequestTimeoutMs, r);
                            }

                            allResults.Add(r);
                            progress.CompletedTasks = Interlocked.Increment(ref completed);
                        }
                    }
                });

                DatabaseHelper.BulkInsertWorkflowResults(new List<WorkflowPageResult>(allResults));
                DatabaseHelper.UpdateWorkflowSessionStatus(sessionId, "Completed", DateTime.Now);
                progress.Status         = "Completed";
                progress.CompletedTasks = progress.TotalTasks;
            }
            catch (Exception ex)
            {
                DatabaseHelper.UpdateWorkflowSessionStatus(sessionId, "Error");
                progress.Status       = "Error";
                progress.ErrorMessage = Truncate(ex.Message);
            }

            _progress[sessionId] = progress;
        }

        // ----------------------------------------------------------------
        // Step 1 – Authenticate this virtual user
        // ----------------------------------------------------------------

        private static bool Authenticate(WorkflowTestConfig config, CookieContainer jar)
        {
            if (string.IsNullOrEmpty(config.LoginUrl))
                return true;   // no auth configured – proceed unauthenticated

            try
            {
                // GET the login page to capture ViewState fields
                var getResult = FetchPage(config.LoginUrl, "GET", null, null, jar, config.RequestTimeoutMs);

                // Build the POST body: user-supplied fields + auto-extracted ASP.NET hidden fields
                var sb = new StringBuilder();
                if (!string.IsNullOrEmpty(config.LoginPostData))
                    sb.Append(config.LoginPostData.TrimEnd('&'));

                AppendHiddenField(sb, getResult.Body, "__VIEWSTATE");
                AppendHiddenField(sb, getResult.Body, "__VIEWSTATEGENERATOR");
                AppendHiddenField(sb, getResult.Body, "__EVENTVALIDATION");

                var postResult = FetchPage(
                    config.LoginUrl, "POST", sb.ToString(), config.LoginUrl, jar, config.RequestTimeoutMs);

                // Login is considered successful if the server returned a non-error status
                return postResult.StatusCode >= 200 && postResult.StatusCode < 400;
            }
            catch
            {
                return false;
            }
        }

        // ----------------------------------------------------------------
        // Step 2/3 – GET page then POST select-button click
        // ----------------------------------------------------------------

        private static void TestPage(string url, CookieContainer jar, int timeoutMs, WorkflowPageResult r)
        {
            // ---- Phase A: GET the page ----
            var sw1 = Stopwatch.StartNew();
            PageFetchResult getResult;
            try
            {
                getResult = FetchPage(url, "GET", null, null, jar, timeoutMs);
                sw1.Stop();
                r.PageLoadStatusCode = getResult.StatusCode;
                r.PageLoadTimeMs     = sw1.ElapsedMilliseconds;
                r.PageLoadSuccess    = getResult.StatusCode >= 200
                                       && getResult.StatusCode < 400
                                       && !IsLoginRedirect(getResult.FinalUrl, getResult.Body);
            }
            catch (WebException wex)
            {
                sw1.Stop();
                r.PageLoadTimeMs     = sw1.ElapsedMilliseconds;
                r.PageLoadStatusCode = wex.Response != null
                    ? (int)((HttpWebResponse)wex.Response).StatusCode : 0;
                r.ErrorMessage       = Truncate(wex.Message);
                return;
            }
            catch (Exception ex)
            {
                sw1.Stop();
                r.PageLoadTimeMs = sw1.ElapsedMilliseconds;
                r.ErrorMessage   = Truncate(ex.Message);
                return;
            }

            if (!r.PageLoadSuccess)
            {
                if (string.IsNullOrEmpty(r.ErrorMessage))
                    r.ErrorMessage = IsLoginRedirect(getResult.FinalUrl, getResult.Body)
                        ? "Redirected to login page – session expired or invalid credentials."
                        : "Page load failed (HTTP " + r.PageLoadStatusCode + ")";
                return;
            }

            // ---- Phase B: Simulate select-button postback ----
            string html = getResult.Body ?? string.Empty;

            string vs  = ExtractField(html, "__VIEWSTATE");
            string vsg = ExtractField(html, "__VIEWSTATEGENERATOR");
            string ev  = ExtractField(html, "__EVENTVALIDATION");

            string eventTarget, eventArg, submitName;
            FindSelectButton(html, out eventTarget, out eventArg, out submitName);

            var sb2 = new StringBuilder();
            if (!string.IsNullOrEmpty(submitName))
            {
                // The select is a regular <input type="submit"> button
                sb2.Append(Uri.EscapeDataString(submitName)).Append("=select");
                sb2.Append("&__EVENTTARGET=&__EVENTARGUMENT=");
            }
            else
            {
                sb2.Append("__EVENTTARGET=").Append(Uri.EscapeDataString(eventTarget ?? "grdApplicationDetails"));
                sb2.Append("&__EVENTARGUMENT=").Append(Uri.EscapeDataString(eventArg ?? "Select$0"));
            }
            if (!string.IsNullOrEmpty(vs))  sb2.Append("&__VIEWSTATE=").Append(Uri.EscapeDataString(vs));
            if (!string.IsNullOrEmpty(vsg)) sb2.Append("&__VIEWSTATEGENERATOR=").Append(Uri.EscapeDataString(vsg));
            if (!string.IsNullOrEmpty(ev))  sb2.Append("&__EVENTVALIDATION=").Append(Uri.EscapeDataString(ev));

            string postUrl = ExtractFormAction(html, url);

            var sw2 = Stopwatch.StartNew();
            try
            {
                var postResult = FetchPage(postUrl, "POST", sb2.ToString(), url, jar, timeoutMs);
                sw2.Stop();
                r.SelectActionStatusCode = postResult.StatusCode;
                r.SelectActionTimeMs     = sw2.ElapsedMilliseconds;
                r.SelectActionSuccess    = postResult.StatusCode >= 200 && postResult.StatusCode < 400;
            }
            catch (WebException wex2)
            {
                sw2.Stop();
                r.SelectActionTimeMs     = sw2.ElapsedMilliseconds;
                r.SelectActionStatusCode = wex2.Response != null
                    ? (int)((HttpWebResponse)wex2.Response).StatusCode : 0;
                if (string.IsNullOrEmpty(r.ErrorMessage))
                    r.ErrorMessage = Truncate("Select click: " + wex2.Message);
            }
            catch (Exception ex2)
            {
                sw2.Stop();
                r.SelectActionTimeMs = sw2.ElapsedMilliseconds;
                if (string.IsNullOrEmpty(r.ErrorMessage))
                    r.ErrorMessage = Truncate("Select click: " + ex2.Message);
            }
        }

        // ----------------------------------------------------------------
        // Low-level HTTP
        // ----------------------------------------------------------------

        private struct PageFetchResult
        {
            public int    StatusCode;
            public string Body;
            public string FinalUrl;
        }

        private static PageFetchResult FetchPage(string url, string method, string postBody,
            string referer, CookieContainer jar, int timeoutMs)
        {
            var req = (HttpWebRequest)WebRequest.Create(url);
            req.Method            = method;
            req.CookieContainer   = jar;
            req.Timeout           = timeoutMs;
            req.ReadWriteTimeout  = timeoutMs;
            req.AllowAutoRedirect = true;
            req.KeepAlive         = true;
            req.UserAgent         = "Mozilla/5.0 (compatible; PTLoadTester/2.0; WorkflowTest)";
            req.Accept            = "text/html,application/xhtml+xml,*/*;q=0.8";
            req.Headers.Add("Accept-Language", "en-US,en;q=0.9");
            if (!string.IsNullOrEmpty(referer))
                req.Referer = referer;

            if (method == "POST" && postBody != null)
            {
                req.ContentType = "application/x-www-form-urlencoded";
                byte[] bytes    = Encoding.UTF8.GetBytes(postBody);
                req.ContentLength = bytes.Length;
                using (var s = req.GetRequestStream())
                    s.Write(bytes, 0, bytes.Length);
            }

            using (var resp = (HttpWebResponse)req.GetResponse())
            {
                var res = new PageFetchResult
                {
                    StatusCode = (int)resp.StatusCode,
                    FinalUrl   = resp.ResponseUri != null ? resp.ResponseUri.ToString() : url
                };
                using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    res.Body = sr.ReadToEnd();
                return res;
            }
        }

        // ----------------------------------------------------------------
        // HTML helpers
        // ----------------------------------------------------------------

        /// <summary>Extracts an ASP.NET hidden field value from page HTML.</summary>
        private static string ExtractField(string html, string name)
        {
            if (string.IsNullOrEmpty(html)) return null;

            // Match the whole <input> tag that has name="fieldName"
            var tagMatch = Regex.Match(html,
                string.Format(@"<input\b[^>]*\bname=""{0}""[^>]*>", Regex.Escape(name)),
                RegexOptions.IgnoreCase | RegexOptions.Singleline);
            if (!tagMatch.Success) return null;

            // Now extract the value attribute from within that tag
            var valMatch = Regex.Match(tagMatch.Value, @"\bvalue=""([^""]*)""", RegexOptions.IgnoreCase);
            return valMatch.Success ? valMatch.Groups[1].Value : null;
        }

        /// <summary>Appends "&amp;fieldName=encodedValue" to the StringBuilder if the field is found.</summary>
        private static void AppendHiddenField(StringBuilder sb, string html, string fieldName)
        {
            string val = ExtractField(html, fieldName);
            if (!string.IsNullOrEmpty(val))
            {
                if (sb.Length > 0) sb.Append('&');
                sb.Append(fieldName).Append('=').Append(Uri.EscapeDataString(val));
            }
        }

        /// <summary>
        /// Locates the select button for grdApplicationDetails.
        /// Sets exactly one of: (eventTarget+eventArg) OR submitName.
        /// Falls back to the standard GridView Select$0 command.
        /// </summary>
        private static void FindSelectButton(string html,
            out string eventTarget, out string eventArg, out string submitName)
        {
            eventTarget = null; eventArg = null; submitName = null;

            // Pattern A – standard CommandField: __doPostBack('grdApplicationDetails','Select$0')
            var mA = Regex.Match(html,
                @"__doPostBack\('([^']*grdApplicationDetails[^']*)',\s*'(Select\$\d+)'\)",
                RegexOptions.IgnoreCase);
            if (mA.Success)
            { eventTarget = mA.Groups[1].Value; eventArg = mA.Groups[2].Value; return; }

            // Pattern B – any __doPostBack whose first argument contains grdApplicationDetails
            var mB = Regex.Match(html,
                @"__doPostBack\('(grdApplicationDetails[^']*)',\s*'([^']*)'\)",
                RegexOptions.IgnoreCase);
            if (mB.Success)
            { eventTarget = mB.Groups[1].Value; eventArg = mB.Groups[2].Value; return; }

            // Pattern C – plain submit button with value="select"
            var mC = Regex.Match(html,
                @"<input\b[^>]*\bname=""([^""]*grdApplicationDetails[^""]*)""\b[^>]*\bvalue=""select""",
                RegexOptions.IgnoreCase);
            if (!mC.Success)
                mC = Regex.Match(html,
                    @"<input\b[^>]*\bvalue=""select""\b[^>]*\bname=""([^""]*grdApplicationDetails[^""]*)""\b",
                    RegexOptions.IgnoreCase);
            if (mC.Success) { submitName = mC.Groups[1].Value; return; }

            // Default – standard GridView row-0 select
            eventTarget = "grdApplicationDetails";
            eventArg    = "Select$0";
        }

        /// <summary>Returns the absolute URL of the page's &lt;form action&gt;.</summary>
        private static string ExtractFormAction(string html, string pageUrl)
        {
            if (string.IsNullOrEmpty(html)) return pageUrl;
            var m = Regex.Match(html, @"<form\b[^>]*\baction=""([^""]*)""", RegexOptions.IgnoreCase);
            if (!m.Success) return pageUrl;
            string action = HttpUtility.HtmlDecode(m.Groups[1].Value);
            if (string.IsNullOrEmpty(action)) return pageUrl;
            if (action.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                action.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                return action;
            return new Uri(new Uri(pageUrl), action).ToString();
        }

        /// <summary>Detects if the response URL / body indicates a redirect to the login page.</summary>
        private static bool IsLoginRedirect(string finalUrl, string body)
        {
            if (!string.IsNullOrEmpty(finalUrl))
            {
                string u = finalUrl.ToLowerInvariant();
                if (u.Contains("login") || u.Contains("signin") || u.Contains("logon"))
                    return true;
            }
            // Heuristic: page contains a user-id input but no data grid
            if (!string.IsNullOrEmpty(body) &&
                body.IndexOf("grdApplicationDetails", StringComparison.OrdinalIgnoreCase) < 0 &&
                (body.IndexOf("name=\"txtUserId\"", StringComparison.OrdinalIgnoreCase) >= 0 ||
                 body.IndexOf("name=\"txtUserID\"", StringComparison.OrdinalIgnoreCase) >= 0))
                return true;
            return false;
        }

        private static string Truncate(string msg)
        {
            if (msg == null) return null;
            return msg.Length > 490 ? msg.Substring(0, 490) : msg;
        }
    }
}
