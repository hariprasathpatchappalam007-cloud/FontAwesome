<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WorkflowTest.aspx.cs" Inherits="PTLoadTester.WorkflowTest" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Workflow Page Test &mdash; PT Load Tester</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <style>
        body { background:#f0f2f7; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; }
        .navbar-custom { background:linear-gradient(135deg,#1a237e 0%,#283593 50%,#1565c0 100%); border:none; border-radius:0; box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .navbar-custom .navbar-brand { color:#fff!important; font-size:22px; font-weight:700; }
        .navbar-custom .navbar-brand span { color:#82b1ff; }
        .navbar-custom .navbar-nav > li > a { color:#cfd8dc!important; font-size:13px; }
        .navbar-custom .navbar-nav > li > a:hover { color:#fff!important; background:rgba(255,255,255,.1)!important; }
        .navbar-custom .navbar-nav > li.active > a { color:#fff!important; background:rgba(255,255,255,.15)!important; }
        .hero-strip { background:linear-gradient(135deg,#0d47a1,#1565c0); color:#fff; padding:28px 0 22px; margin-bottom:30px; box-shadow:0 3px 10px rgba(0,0,0,.2); }
        .hero-strip h2 { margin:0 0 6px; font-weight:300; font-size:28px; }
        .hero-strip p  { margin:0; opacity:.8; font-size:14px; }
        .card { background:#fff; border-radius:8px; box-shadow:0 2px 12px rgba(0,0,0,.09); margin-bottom:24px; overflow:hidden; }
        .card-header { background:linear-gradient(90deg,#1565c0,#0d47a1); color:#fff; padding:14px 20px; font-size:15px; font-weight:600; }
        .card-header .fa { margin-right:8px; }
        .card-body { padding:24px; }
        .form-control { border-radius:5px; border:1px solid #dde3ee; box-shadow:inset 0 1px 3px rgba(0,0,0,.06); transition:border-color .2s; }
        .form-control:focus { border-color:#1565c0; box-shadow:0 0 0 2px rgba(21,101,192,.15); }
        label { font-weight:600; color:#37474f; font-size:13px; margin-bottom:5px; }
        .form-group { margin-bottom:20px; }
        /* Sliders */
        .slider-wrap { display:flex; align-items:center; gap:14px; }
        .slider-wrap input[type=range] { flex:1; accent-color:#1565c0; height:6px; }
        .slider-num { min-width:80px; padding:5px 10px; border:2px solid #1565c0; border-radius:6px; font-weight:700; font-size:15px; color:#1565c0; text-align:center; background:#e8f0fe; }
        /* URL checkboxes */
        .url-list { max-height:340px; overflow-y:auto; border:1px solid #e3e8f0; border-radius:6px; padding:12px 16px; background:#fafbff; }
        .url-item { display:flex; align-items:flex-start; padding:7px 0; border-bottom:1px solid #f0f0f0; gap:10px; }
        .url-item:last-child { border-bottom:none; }
        .url-item input[type=checkbox] { margin-top:3px; width:16px; height:16px; flex-shrink:0; accent-color:#1565c0; }
        .url-item-label { font-size:13px; color:#263238; }
        .url-item-full  { font-size:11px; color:#90a4ae; word-break:break-all; margin-top:2px; }
        .btn-select-all { font-size:12px; padding:3px 10px; margin-right:6px; }
        /* Start button */
        .btn-start { background:linear-gradient(135deg,#2e7d32,#388e3c); color:#fff; border:none; border-radius:6px; padding:12px 36px; font-size:16px; font-weight:600; box-shadow:0 3px 8px rgba(46,125,50,.35); transition:all .2s; }
        .btn-start:hover:not(:disabled) { background:linear-gradient(135deg,#1b5e20,#2e7d32); color:#fff; }
        .btn-start:disabled { opacity:.65; cursor:not-allowed; }
        /* Progress panel */
        #progressPanel { display:none; background:#fff; border-radius:8px; box-shadow:0 2px 12px rgba(0,0,0,.09); padding:24px; margin-bottom:24px; border-left:5px solid #1565c0; }
        #progressPanel h4 { margin-top:0; color:#1565c0; }
        .progress { height:22px; border-radius:11px; background:#e8f0fe; margin-bottom:10px; }
        .progress-bar { border-radius:11px; background:linear-gradient(90deg,#1565c0,#42a5f5); font-size:13px; font-weight:600; line-height:22px; transition:width .4s ease; }
        .progress-bar.progress-error { background:#e53935; }
        /* Recent table */
        .table-recent th { background:#f5f7fb; color:#455a64; font-size:12px; text-transform:uppercase; letter-spacing:.5px; }
        .table-recent td { vertical-align:middle; font-size:13px; }
        .status-badge { padding:3px 10px; border-radius:12px; font-size:11px; font-weight:700; text-transform:uppercase; }
        .status-completed { background:#c8e6c9; color:#1b5e20; }
        .status-running   { background:#bbdefb; color:#0d47a1; }
        .status-error     { background:#ffcdd2; color:#b71c1c; }
        .status-pending   { background:#f3e5f5; color:#6a1b9a; }
        #dbAlert { display:none; }
        .footer { text-align:center; padding:20px; color:#90a4ae; font-size:12px; }
        .help-block { font-size:12px; color:#78909c; margin-top:4px; }
        .info-badge { display:inline-block; background:#e8f0fe; color:#1565c0; border-radius:4px; padding:3px 10px; font-size:12px; font-weight:600; border-left:3px solid #1565c0; }
    </style>
</head>
<body>

<nav class="navbar navbar-custom navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navMenu">
                <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="Default.aspx">
                <i class="fa fa-tachometer"></i> PT<span>LoadTester</span>
            </a>
        </div>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="nav navbar-nav">
                <li><a href="Default.aspx"><i class="fa fa-home"></i> Query Load Test</a></li>
                <li class="active"><a href="WorkflowTest.aspx"><i class="fa fa-sitemap"></i> Workflow Page Test</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="hero-strip">
    <div class="container-fluid">
        <h2><i class="fa fa-sitemap"></i> Workflow Page Load Tester</h2>
        <p>
            Measures <strong>page load time</strong> and <strong>grdApplicationDetails Select action time</strong>
            across LMS workflow pages with configurable concurrent users and iterations.
        </p>
    </div>
</div>

<div class="container-fluid" style="max-width:1280px;">

    <div id="dbAlert" class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" onclick="$('#dbAlert').hide()"><span>&times;</span></button>
        <strong><i class="fa fa-database"></i> Database Error:</strong> <span id="dbErrorMsg"></span>
        <br/><small>Please verify the connection string in <code>Web.config</code> and run <code>SQL/CreateDatabase.sql</code>.</small>
    </div>

    <div class="row">
        <!-- LEFT COL: Config -->
        <div class="col-md-8">

            <!-- Auth Card -->
            <div class="card">
                <div class="card-header"><i class="fa fa-lock"></i> Authentication Setup</div>
                <div class="card-body">
                    <div class="alert alert-info" style="font-size:13px;padding:10px 14px;margin-bottom:16px;">
                        <i class="fa fa-info-circle"></i>
                        Each virtual user independently authenticates by GETting the login page (to capture
                        <code>__VIEWSTATE</code>), then POSTing the form data you supply below.
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><i class="fa fa-sign-in"></i> Login Page URL</label>
                                <input type="text" id="txtLoginUrl" class="form-control"
                                       placeholder="http://10.224.3.14/lms/Login.aspx" />
                                <p class="help-block">Leave blank to skip authentication.</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><i class="fa fa-user"></i> User ID (for display only)</label>
                                <input type="text" id="txtUserId" class="form-control" value="SPUser05" />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><i class="fa fa-code"></i> Login POST Data</label>
                        <textarea id="txtLoginPostData" class="form-control" rows="3"
                            placeholder="txtUserId=SPUser05&txtPassword=yourpassword&btnLogin=Login"></textarea>
                        <p class="help-block">
                            Enter the form fields as <code>name=value</code> pairs separated by <code>&amp;</code>.
                            The <code>__VIEWSTATE</code>, <code>__VIEWSTATEGENERATOR</code> and
                            <code>__EVENTVALIDATION</code> fields are extracted automatically from the login page.
                        </p>
                    </div>
                </div>
            </div>

            <!-- URL Selection Card -->
            <div class="card">
                <div class="card-header">
                    <i class="fa fa-list-ul"></i> Target Workflow Pages
                    <span style="float:right; font-size:12px; font-weight:400; opacity:.85;">
                        <button class="btn btn-xs btn-default btn-select-all" onclick="selectAllUrls(true)">Select All</button>
                        <button class="btn btn-xs btn-default btn-select-all" onclick="selectAllUrls(false)">Deselect All</button>
                    </span>
                </div>
                <div class="card-body">
                    <p class="help-block" style="margin-bottom:12px;">
                        <i class="fa fa-info-circle"></i>
                        Each selected page is tested for: <strong>page load time</strong> (GET) and
                        <strong>select-button response time</strong> (clicking the first row's Select button
                        in <code>grdApplicationDetails</code>).
                    </p>
                    <div class="url-list" id="urlList"></div>
                </div>
            </div>

            <!-- Load Settings Card -->
            <div class="card">
                <div class="card-header"><i class="fa fa-sliders"></i> Load Settings</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><i class="fa fa-users"></i> Concurrent Users</label>
                                <div class="slider-wrap">
                                    <input type="range" id="sldConcurrent" min="1" max="100" step="1" value="5" />
                                    <div class="slider-num" id="lblConcurrent">5</div>
                                    <input type="number" id="numConcurrent" class="form-control"
                                           style="width:80px;" min="1" max="100" value="5" />
                                </div>
                                <p class="help-block">Each virtual user authenticates independently.</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><i class="fa fa-repeat"></i> Iterations per User</label>
                                <div class="slider-wrap">
                                    <input type="range" id="sldIterations" min="1" max="50" step="1" value="3" />
                                    <div class="slider-num" id="lblIterations">3</div>
                                    <input type="number" id="numIterations" class="form-control"
                                           style="width:80px;" min="1" max="500" value="3" />
                                </div>
                                <p class="help-block">How many times each user cycles through all selected URLs.</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><i class="fa fa-clock-o"></i> Request Timeout (ms)</label>
                                <input type="number" id="numTimeout" class="form-control"
                                       style="max-width:200px;" value="30000" min="1000" max="120000" />
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label><i class="fa fa-tag"></i> Test Name (optional)</label>
                                <input type="text" id="txtTestName" class="form-control"
                                       placeholder="e.g. Regression Run – Sprint 42" maxlength="200" />
                            </div>
                        </div>
                    </div>

                    <div id="summaryBadge" class="info-badge" style="margin-bottom:20px;">
                        Total tasks: <span id="totalTasksLabel">—</span>
                        &nbsp;(users &times; iterations &times; URLs)
                    </div>

                    <button id="btnStart" class="btn-start" onclick="startTest()">
                        <i class="fa fa-play-circle"></i>&nbsp; Start Workflow Test
                    </button>
                    <span id="startError" class="text-danger" style="margin-left:14px; font-size:13px;"></span>
                </div>
            </div>

        </div><!-- /col-md-8 -->

        <!-- RIGHT COL: Recent tests -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header"><i class="fa fa-history"></i> Recent Workflow Tests</div>
                <div class="card-body" style="padding:0;">
                    <div id="recentSessionsPanel">
                        <p style="padding:18px;color:#90a4ae;font-size:13px;">Loading…</p>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /row -->

    <!-- Progress Panel -->
    <div id="progressPanel">
        <h4><i class="fa fa-spinner fa-spin"></i> Test Running…</h4>
        <div class="progress">
            <div class="progress-bar" id="progressBar" role="progressbar" style="width:0%;">0%</div>
        </div>
        <div id="progressDetail" style="font-size:13px; color:#546e7a;"></div>
    </div>

</div><!-- /container -->

<div class="footer"><i class="fa fa-sitemap"></i> PT Load Tester &mdash; Workflow Page Test</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script>
    // ===== Pre-defined LMS workflow URLs =====
    var WORKFLOW_URLS = [
        { url: "http://10.224.3.14/lms/workflow/WF_ApplicationDataEntry.aspx",                             label: "WF_ApplicationDataEntry" },
        { url: "http://10.224.3.14/lms/workflow/WF_ApplicationDataEntryAppr.aspx",                         label: "WF_ApplicationDataEntryAppr" },
        { url: "http://10.224.3.14/lms/workflow/Offer_Letter_Printing.aspx",                               label: "Offer_Letter_Printing" },
        { url: "http://10.224.3.14/lms/workflow/WF_CA.aspx",                                               label: "WF_CA" },
        { url: "http://10.224.3.14/lms/workflow/WF_CA.aspx?Role=HR&type=checker",                          label: "WF_CA (HR Checker)" },
        { url: "http://10.224.3.14/lms/workflow/WF_CA.aspx?Role=HR&type=maker",                            label: "WF_CA (HR Maker)" },
        { url: "http://10.224.3.14/lms/workflow/WF_LEVEL_APPROVAL.aspx?APPROVAL_LEVEL=LEVEL-1-CEO",        label: "LEVEL APPROVAL – LEVEL-1-CEO" },
        { url: "http://10.224.3.14/lms/workflow/WF_LEVEL_APPROVAL.aspx?APPROVAL_LEVEL=LEVEL-1-MCRC",       label: "LEVEL APPROVAL – LEVEL-1-MCRC" },
        { url: "http://10.224.3.14/lms/workflow/WF_LEVEL_APPROVAL.aspx?APPROVAL_LEVEL=LEVEL-2",            label: "LEVEL APPROVAL – LEVEL-2" },
        { url: "http://10.224.3.14/lms/workflow/WF_LEVEL_APPROVAL.aspx?APPROVAL_LEVEL=LEVEL-3",            label: "LEVEL APPROVAL – LEVEL-3" },
        { url: "http://10.224.3.14/lms/workflow/WF_LEVEL_APPROVAL.aspx?APPROVAL_LEVEL=LEVEL-4",            label: "LEVEL APPROVAL – LEVEL-4" },
        { url: "http://10.224.3.14/lms/workflow/WF_LEVEL_APPROVAL.aspx?APPROVAL_LEVEL=PA-LEVEL1-CCO",      label: "LEVEL APPROVAL – PA-LEVEL1-CCO" },
        { url: "http://10.224.3.14/lms/workflow/WF_LEVEL_APPROVAL.aspx?APPROVAL_LEVEL=PA-LEVEL1-MCC",      label: "LEVEL APPROVAL – PA-LEVEL1-MCC" },
        { url: "http://10.224.3.14/lms/workflow/Lead_Credit_login_helpdesk.aspx",                          label: "Lead_Credit_login_helpdesk" },
        { url: "http://10.224.3.14/lms/workflow/WF_OPS_Scrutinizer.aspx?SEC=SEC1",                         label: "OPS Scrutinizer – SEC1" },
        { url: "http://10.224.3.14/lms/workflow/WF_OPS_Scrutinizer.aspx?SEC=SEC2",                         label: "OPS Scrutinizer – SEC2" },
        { url: "http://10.224.3.14/lms/workflow/WF_OPS_Scrutinizer.aspx?SEC=OPS_SCRUTINIZER_MANAGER",      label: "OPS Scrutinizer – Manager" },
        { url: "http://10.224.3.14/lms/workflow/WF_OPS_Authorizer.aspx?AUTH=AUTH1",                        label: "OPS Authorizer – AUTH1" },
        { url: "http://10.224.3.14/lms/workflow/WF_Affordability.aspx?ROLE=Sales",                         label: "WF Affordability – Sales" }
    ];

    var _pollTimer  = null;
    var _sessionId  = 0;

    // Build URL checkboxes
    (function buildUrlList() {
        var html = '';
        WORKFLOW_URLS.forEach(function(item, i) {
            html += '<div class="url-item">' +
                '<input type="checkbox" id="url_' + i + '" checked />' +
                '<label for="url_' + i + '" style="cursor:pointer;font-weight:normal;">' +
                    '<span class="url-item-label"><strong>' + escHtml(item.label) + '</strong></span>' +
                    '<div class="url-item-full">' + escHtml(item.url) + '</div>' +
                '</label>' +
                '</div>';
        });
        document.getElementById('urlList').innerHTML = html;
        updateTotalTasks();
    })();

    // Render recent sessions
    var recentData = <%=RecentSessionsJson%>;
    var dbErr = <%=DbErrorJson%>;
    if (dbErr) {
        document.getElementById('dbAlert').style.display = 'block';
        document.getElementById('dbErrorMsg').textContent = dbErr;
    }
    (function renderRecent() {
        var panel = document.getElementById('recentSessionsPanel');
        if (!recentData || recentData.length === 0) {
            panel.innerHTML = '<p style="padding:18px;color:#90a4ae;font-size:13px;">No workflow tests yet.</p>';
            return;
        }
        var rows = recentData.map(function(s) {
            var cls = 'status-' + (s.Status || 'pending').toLowerCase();
            var link = s.Status === 'Completed' || s.Status === 'Error'
                ? '<a href="WorkflowResults.aspx?sessionId=' + s.SessionId + '">#' + s.SessionId + '</a>'
                : '#' + s.SessionId;
            return '<tr>' +
                '<td>' + link + '</td>' +
                '<td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + escHtml(s.TestName) + '">' + escHtml(s.TestName) + '</td>' +
                '<td>' + s.ConcurrentUsers + 'u &times; ' + s.Iterations + 'iter</td>' +
                '<td><span class="status-badge ' + cls + '">' + escHtml(s.Status) + '</span></td>' +
                '</tr>';
        }).join('');
        panel.innerHTML = '<table class="table table-hover table-condensed table-recent" style="margin:0;">' +
            '<thead><tr><th>ID</th><th>Name</th><th>Config</th><th>Status</th></tr></thead>' +
            '<tbody>' + rows + '</tbody></table>';
    })();

    // Slider / number sync
    function syncSlider(sldId, numId, lblId) {
        var sld = document.getElementById(sldId);
        var num = document.getElementById(numId);
        var lbl = document.getElementById(lblId);
        function update(v) { sld.value = v; num.value = v; lbl.textContent = v; updateTotalTasks(); }
        sld.addEventListener('input',  function() { update(sld.value); });
        num.addEventListener('input',  function() { update(num.value); });
        num.addEventListener('change', function() { update(num.value); });
    }
    syncSlider('sldConcurrent',  'numConcurrent',  'lblConcurrent');
    syncSlider('sldIterations',  'numIterations',  'lblIterations');

    // Re-compute total tasks when URL checkboxes change
    document.getElementById('urlList').addEventListener('change', updateTotalTasks);

    function updateTotalTasks() {
        var users = parseInt(document.getElementById('numConcurrent').value, 10)  || 0;
        var iters = parseInt(document.getElementById('numIterations').value, 10)  || 0;
        var urls  = document.querySelectorAll('#urlList input[type=checkbox]:checked').length;
        document.getElementById('totalTasksLabel').textContent =
            (users * iters * urls).toLocaleString() +
            ' (' + users + ' \u00d7 ' + iters + ' \u00d7 ' + urls + ')';
    }

    function selectAllUrls(on) {
        document.querySelectorAll('#urlList input[type=checkbox]').forEach(function(cb) { cb.checked = on; });
        updateTotalTasks();
    }

    function getSelectedUrls() {
        var urls = [];
        WORKFLOW_URLS.forEach(function(item, i) {
            var cb = document.getElementById('url_' + i);
            if (cb && cb.checked) urls.push(item.url);
        });
        return urls;
    }

    function startTest() {
        document.getElementById('startError').textContent = '';
        var urls = getSelectedUrls();
        if (urls.length === 0) {
            document.getElementById('startError').textContent = 'Select at least one URL.';
            return;
        }
        var btn = document.getElementById('btnStart');
        btn.disabled = true;
        btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Starting…';

        var data = {
            loginUrl:       document.getElementById('txtLoginUrl').value.trim(),
            loginPostData:  document.getElementById('txtLoginPostData').value.trim(),
            userId:         document.getElementById('txtUserId').value.trim(),
            testName:       document.getElementById('txtTestName').value.trim(),
            concurrentUsers: document.getElementById('numConcurrent').value,
            iterations:     document.getElementById('numIterations').value,
            timeoutMs:      document.getElementById('numTimeout').value,
            targetUrls:     JSON.stringify(urls)
        };

        $.ajax({
            url:  'Handlers/WorkflowStartHandler.ashx',
            type: 'POST',
            data: data,
            success: function(resp) {
                if (resp.success) {
                    _sessionId = resp.sessionId;
                    showProgress();
                    _pollTimer = setInterval(pollProgress, 1000);
                } else {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fa fa-play-circle"></i>&nbsp; Start Workflow Test';
                    document.getElementById('startError').textContent = resp.error || 'Unknown error.';
                }
            },
            error: function() {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa fa-play-circle"></i>&nbsp; Start Workflow Test';
                document.getElementById('startError').textContent = 'Network error – check server.';
            }
        });
    }

    function showProgress() {
        document.getElementById('progressPanel').style.display = 'block';
        document.getElementById('progressPanel').scrollIntoView({ behavior: 'smooth' });
    }

    function pollProgress() {
        $.getJSON('Handlers/WorkflowProgressHandler.ashx?sessionId=' + _sessionId, function(p) {
            var pct   = p.progressPercent || 0;
            var bar   = document.getElementById('progressBar');
            bar.style.width   = pct + '%';
            bar.textContent   = pct + '%';
            bar.className     = 'progress-bar' + (p.status === 'Error' ? ' progress-error' : '');
            document.getElementById('progressDetail').innerHTML =
                '<i class="fa fa-check-circle text-success"></i> Completed: <strong>' +
                (p.completedTasks || 0) + '</strong> / ' + (p.totalTasks || 0) +
                ' tasks &nbsp;|&nbsp; Status: <strong>' + (p.status || '…') + '</strong>' +
                (p.errorMessage ? ' &nbsp;<span class="text-danger">' + escHtml(p.errorMessage) + '</span>' : '');

            if (p.status === 'Completed') {
                clearInterval(_pollTimer);
                setTimeout(function() {
                    window.location.href = 'WorkflowResults.aspx?sessionId=' + _sessionId;
                }, 800);
            } else if (p.status === 'Error') {
                clearInterval(_pollTimer);
                document.getElementById('btnStart').disabled = false;
                document.getElementById('btnStart').innerHTML = '<i class="fa fa-play-circle"></i>&nbsp; Start Workflow Test';
            }
        });
    }

    function escHtml(s) {
        if (!s) return '';
        return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
</script>
</body>
</html>
