using System;
using System.Web.Script.Serialization;
using PTLoadTester.DAL;

namespace PTLoadTester
{
    public partial class WorkflowTest : System.Web.UI.Page
    {
        private string _recentSessionsJson;
        private string _dbErrorJson;

        public string RecentSessionsJson { get { return _recentSessionsJson; } }
        public string DbErrorJson        { get { return _dbErrorJson;        } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var js = new JavaScriptSerializer();
                try
                {
                    var sessions = DatabaseHelper.GetRecentWorkflowSessions(10);
                    _recentSessionsJson = js.Serialize(sessions);
                    _dbErrorJson        = "null";
                }
                catch (Exception ex)
                {
                    _recentSessionsJson = "[]";
                    _dbErrorJson        = js.Serialize(ex.Message);
                }
            }
        }
    }
}
