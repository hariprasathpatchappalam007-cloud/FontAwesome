<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Results.aspx.cs" Inherits="PTLoadTester.Results" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Results &mdash; PT Load Tester</title>
    <!-- Bootstrap 3 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Font Awesome 4 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <!-- DataTables Bootstrap theme -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap.min.css" />
    <style>
        body { background:#f0f2f7; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; }
        /* Navbar */
        .navbar-custom { background:linear-gradient(135deg,#1a237e,#1565c0); border:none; border-radius:0; box-shadow:0 2px 8px rgba(0,0,0,.35); }
        .navbar-custom .navbar-brand { color:#fff!important; font-weight:700; font-size:20px; }
        .navbar-custom .navbar-brand span { color:#82b1ff; }
        /* Hero */
        .hero-strip { background:linear-gradient(135deg,#0d47a1,#1565c0); color:#fff; padding:22px 0 18px; margin-bottom:26px; box-shadow:0 3px 10px rgba(0,0,0,.2); }
        .hero-strip h3 { margin:0 0 4px; font-weight:300; font-size:24px; }
        .hero-strip p  { margin:0; opacity:.8; font-size:13px; }
        /* KPI Cards */
        .kpi-grid { display:flex; flex-wrap:wrap; gap:16px; margin-bottom:26px; }
        .kpi-card {
            flex:1; min-width:150px; background:#fff; border-radius:10px;
            box-shadow:0 2px 10px rgba(0,0,0,.08); padding:18px 20px;
            border-top:4px solid transparent; position:relative; overflow:hidden;
        }
        .kpi-card::before { content:''; position:absolute; top:0; right:0; width:60px; height:60px; border-radius:0 10px 0 60px; opacity:.08; }
        .kpi-blue   { border-top-color:#1565c0; } .kpi-blue::before   { background:#1565c0; }
        .kpi-green  { border-top-color:#2e7d32; } .kpi-green::before  { background:#2e7d32; }
        .kpi-red    { border-top-color:#c62828; } .kpi-red::before    { background:#c62828; }
        .kpi-orange { border-top-color:#e65100; } .kpi-orange::before { background:#e65100; }
        .kpi-teal   { border-top-color:#00695c; } .kpi-teal::before   { background:#00695c; }
        .kpi-purple { border-top-color:#6a1b9a; } .kpi-purple::before { background:#6a1b9a; }
        .kpi-card .kpi-label { font-size:11px; text-transform:uppercase; letter-spacing:.6px; color:#90a4ae; font-weight:600; margin-bottom:6px; }
        .kpi-card .kpi-value { font-size:28px; font-weight:700; color:#263238; line-height:1.1; }
        .kpi-card .kpi-sub   { font-size:12px; color:#78909c; margin-top:3px; }
        .kpi-card .kpi-icon  { position:absolute; top:16px; right:18px; font-size:24px; opacity:.18; }
        /* Chart cards */
        .chart-card { background:#fff; border-radius:10px; box-shadow:0 2px 12px rgba(0,0,0,.09); margin-bottom:24px; overflow:hidden; }
        .chart-card-header { background:linear-gradient(90deg,#1565c0,#0d47a1); color:#fff; padding:12px 20px; font-size:14px; font-weight:600; }
        .chart-card-header .fa { margin-right:8px; }
        .chart-card-body { padding:16px; }
        /* Percentile badges */
        .pct-badges { display:flex; gap:10px; flex-wrap:wrap; margin:10px 0 0; }
        .pct-badge { padding:5px 14px; border-radius:20px; font-size:12px; font-weight:700; }
        .pct-p50 { background:#e3f2fd; color:#0d47a1; }
        .pct-p95 { background:#fff3e0; color:#e65100; }
        .pct-p99 { background:#fce4ec; color:#b71c1c; }
        /* DataTable tweaks */
        #tblResults thead th { background:#f5f7fb; color:#455a64; font-size:11px; text-transform:uppercase; letter-spacing:.5px; }
        .dt-success td:first-child { border-left:3px solid #4caf50; }
        .dt-fail    td:first-child { border-left:3px solid #f44336; }
        tr.dt-success { background:#f9fff9!important; }
        tr.dt-fail    { background:#fff5f5!important; }
        .pill-sc { padding:2px 9px; border-radius:12px; font-size:11px; font-weight:700; }
        .pill-2xx { background:#c8e6c9; color:#1b5e20; }
        .pill-3xx { background:#e3f2fd; color:#0d47a1; }
        .pill-4xx { background:#fff3e0; color:#e65100; }
        .pill-5xx { background:#ffcdd2; color:#b71c1c; }
        .pill-0   { background:#eeeeee; color:#616161; }
        /* Back button */
        .btn-back { background:#fff; color:#1565c0; border:2px solid #1565c0; border-radius:6px; padding:7px 18px; font-size:13px; font-weight:600; transition:all .2s; }
        .btn-back:hover { background:#1565c0; color:#fff; }
        /* Footer */
        .footer { text-align:center; padding:20px; color:#90a4ae; font-size:12px; }
    </style>
</head>
<body>

<nav class="navbar navbar-custom navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <span class="navbar-brand"><i class="fa fa-tachometer"></i> PT<span>LoadTester</span></span>
        </div>
    </div>
</nav>

<div class="hero-strip">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-8">
                <h3><i class="fa fa-bar-chart"></i> Test Results &mdash; Session #<%=SessionId%></h3>
                <p>
                    <i class="fa fa-link"></i> <strong><%=Server.HtmlEncode(SessionUrl)%></strong>
                    &nbsp;|&nbsp;
                    <i class="fa fa-key"></i> Param: <strong><%=Server.HtmlEncode(SessionParam)%></strong>
                    &nbsp;|&nbsp;
                    <i class="fa fa-clock-o"></i> <%=SessionStarted%>
                </p>
            </div>
            <div class="col-sm-4 text-right" style="padding-top:10px;">
                <a href="Default.aspx" class="btn-back">
                    <i class="fa fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid" style="max-width:1440px;">

    <!-- KPI Row -->
    <div class="kpi-grid">
        <div class="kpi-card kpi-blue">
            <div class="kpi-icon"><i class="fa fa-list-ol"></i></div>
            <div class="kpi-label">Total Requests</div>
            <div class="kpi-value" id="kpiTotal">—</div>
            <div class="kpi-sub"><i class="fa fa-users"></i> <%=ConcurrentUsers%> concurrent users</div>
        </div>
        <div class="kpi-card kpi-green">
            <div class="kpi-icon"><i class="fa fa-check-circle"></i></div>
            <div class="kpi-label">Successful</div>
            <div class="kpi-value" id="kpiSuccess">—</div>
            <div class="kpi-sub" id="kpiSuccessRate">—</div>
        </div>
        <div class="kpi-card kpi-red">
            <div class="kpi-icon"><i class="fa fa-times-circle"></i></div>
            <div class="kpi-label">Failed</div>
            <div class="kpi-value" id="kpiFail">—</div>
            <div class="kpi-sub" id="kpiFailRate">—</div>
        </div>
        <div class="kpi-card kpi-orange">
            <div class="kpi-icon"><i class="fa fa-hourglass-half"></i></div>
            <div class="kpi-label">Avg Response</div>
            <div class="kpi-value" id="kpiAvg">—</div>
            <div class="kpi-sub">milliseconds</div>
        </div>
        <div class="kpi-card kpi-teal">
            <div class="kpi-icon"><i class="fa fa-bolt"></i></div>
            <div class="kpi-label">Min / Max</div>
            <div class="kpi-value" id="kpiMinMax">—</div>
            <div class="kpi-sub">response time (ms)</div>
        </div>
        <div class="kpi-card kpi-purple">
            <div class="kpi-icon"><i class="fa fa-tachometer"></i></div>
            <div class="kpi-label">Requests/sec</div>
            <div class="kpi-value" id="kpiRps">—</div>
            <div class="kpi-sub" id="kpiDuration">—</div>
        </div>
    </div>

    <!-- Percentile badges -->
    <div class="pct-badges" style="margin-bottom:26px;" id="pctBadges"></div>

    <!-- Row 1: Response Time Line Chart (full width) -->
    <div class="chart-card">
        <div class="chart-card-header">
            <i class="fa fa-line-chart"></i> Response Time per Request
            <small style="opacity:.75; float:right; font-weight:400;">
                Green = Success &nbsp;|&nbsp; Red = Failed &nbsp;|&nbsp; Orange line = Average
            </small>
        </div>
        <div class="chart-card-body">
            <div id="chartLine"></div>
        </div>
    </div>

    <!-- Row 2: Distribution + Donut -->
    <div class="row">
        <div class="col-md-8">
            <div class="chart-card">
                <div class="chart-card-header"><i class="fa fa-bar-chart"></i> Response Time Distribution</div>
                <div class="chart-card-body">
                    <div id="chartDist"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="chart-card">
                <div class="chart-card-header"><i class="fa fa-pie-chart"></i> Success vs Failed</div>
                <div class="chart-card-body">
                    <div id="chartDonut"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Row 3: Status Code Breakdown -->
    <div class="chart-card">
        <div class="chart-card-header"><i class="fa fa-th"></i> HTTP Status Code Breakdown</div>
        <div class="chart-card-body">
            <div id="chartStatusCodes"></div>
        </div>
    </div>

    <!-- Row 4: Detailed Results DataTable -->
    <div class="chart-card">
        <div class="chart-card-header">
            <i class="fa fa-table"></i> Detailed Request Log
            <span style="float:right; font-weight:400; font-size:12px; opacity:.75;">
                <i class="fa fa-download"></i> Use the table's CSV/Excel export buttons
            </span>
        </div>
        <div class="chart-card-body" style="overflow-x:auto;">
            <table id="tblResults" class="table table-bordered table-condensed" style="width:100%;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ID Value</th>
                        <th>Status Code</th>
                        <th>Time (ms)</th>
                        <th>Success</th>
                        <th>Request Time</th>
                        <th>Error</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

</div>

<div class="footer">
    <i class="fa fa-bolt"></i> PT Load Tester &mdash; Session #<%=SessionId%>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts@3.41.0/dist/apexcharts.min.js"></script>

<script>
    // ===== Data injected from server =====
    var summaryData  = <%=SummaryJson%>;
    var chartData    = <%=ChartDataJson%>;
    var resultsData  = <%=ResultsJson%>;

    $(function () {

        // ---- KPI cards ----
        var s = summaryData;
        $('#kpiTotal').text(s.TotalRequests);
        $('#kpiSuccess').text(s.SuccessCount);
        $('#kpiSuccessRate').text((s.SuccessRate).toFixed(1) + '% success rate');
        $('#kpiFail').text(s.FailCount);
        $('#kpiFailRate').text((100 - s.SuccessRate).toFixed(1) + '% failure rate');
        $('#kpiAvg').text(Math.round(s.AverageResponseTime));
        $('#kpiMinMax').html(s.MinResponseTime + ' <span style="font-size:16px;color:#90a4ae">/</span> ' + s.MaxResponseTime);
        $('#kpiRps').text(s.RequestsPerSecond.toFixed(2));
        $('#kpiDuration').text('Total: ' + s.TotalDurationSeconds.toFixed(1) + 's');

        // ---- Percentile badges ----
        $('#pctBadges').html(
            '<span class="pct-badge pct-p50"><i class="fa fa-circle"></i> P50: ' + Math.round(s.P50ResponseTime) + ' ms</span>' +
            '<span class="pct-badge pct-p95"><i class="fa fa-circle"></i> P95: ' + Math.round(s.P95ResponseTime) + ' ms</span>' +
            '<span class="pct-badge pct-p99"><i class="fa fa-circle"></i> P99: ' + Math.round(s.P99ResponseTime) + ' ms</span>'
        );

        // ======================================================
        // CHART 1 — Response Time Scatter (Success + Failed)
        // ======================================================
        var successPts = [], failPts = [];
        for (var i = 0; i < chartData.RequestNumbers.length; i++) {
            var pt = { x: chartData.RequestNumbers[i], y: chartData.ResponseTimes[i] };
            if (chartData.IsSuccess[i]) successPts.push(pt);
            else                        failPts.push(pt);
        }

        var lineOpts = {
            series: [
                { name: 'Success', data: successPts },
                { name: 'Failed',  data: failPts   }
            ],
            chart: {
                type: 'scatter', height: 340,
                zoom: { enabled: true, type: 'xy' },
                toolbar: { show: true, tools: { download: true, zoom: true, reset: true } }
            },
            colors: ['#00C853', '#FF1744'],
            markers: { size: successPts.length + failPts.length > 300 ? 2 : 4 },
            xaxis: {
                title: { text: 'Request Number', style: { color:'#546e7a', fontSize:'12px' } },
                tickAmount: 10, type: 'numeric'
            },
            yaxis: {
                title: { text: 'Response Time (ms)', style: { color:'#546e7a', fontSize:'12px' } },
                min: 0
            },
            annotations: {
                yaxis: [{
                    y: s.AverageResponseTime,
                    borderColor: '#FF6F00',
                    strokeDashArray: 4,
                    label: {
                        text: 'Avg ' + Math.round(s.AverageResponseTime) + ' ms',
                        style: { background:'#FF6F00', color:'#fff', fontSize:'11px' }
                    }
                }]
            },
            tooltip: {
                custom: function(opts) {
                    var pt = opts.w.config.series[opts.seriesIndex].data[opts.dataPointIndex];
                    return '<div style="padding:8px 12px;font-size:12px;">' +
                           '<b>Request #' + pt.x + '</b><br/>' +
                           'Time: <b>' + pt.y + ' ms</b><br/>' +
                           (opts.seriesIndex === 0 ? '<span style="color:#00C853">&#10003; Success</span>' : '<span style="color:#FF1744">&#10007; Failed</span>') +
                           '</div>';
                }
            },
            legend: { position: 'top', horizontalAlign: 'right' }
        };
        new ApexCharts(document.querySelector('#chartLine'), lineOpts).render();

        // ======================================================
        // CHART 2 — Distribution Horizontal Bar
        // ======================================================
        var distOpts = {
            series: [{ name: 'Requests', data: chartData.DistributionCounts }],
            chart: { type: 'bar', height: 280, toolbar: { show: false } },
            plotOptions: {
                bar: {
                    horizontal: true, borderRadius: 4,
                    dataLabels: { position: 'end' },
                    distributed: true
                }
            },
            colors: ['#1565c0','#1976d2','#1e88e5','#ff6f00','#f4511e','#b71c1c'],
            dataLabels: {
                enabled: true,
                formatter: function(val) { return val + ' req'; },
                style: { fontSize:'11px', colors:['#263238'] },
                offsetX: 4
            },
            xaxis: { title: { text: 'Number of Requests', style:{color:'#546e7a',fontSize:'12px'} } },
            yaxis: { categories: chartData.DistributionLabels },
            legend: { show: false },
            tooltip: { y: { formatter: function(v) { return v + ' requests'; } } }
        };
        new ApexCharts(document.querySelector('#chartDist'), distOpts).render();

        // ======================================================
        // CHART 3 — Donut: Success vs Failed
        // ======================================================
        var donutOpts = {
            series: [s.SuccessCount, s.FailCount],
            chart: { type: 'donut', height: 280 },
            labels: ['Success', 'Failed'],
            colors: ['#00C853', '#FF1744'],
            dataLabels: { enabled: true, formatter: function(val) { return val.toFixed(1) + '%'; } },
            plotOptions: { pie: { donut: { size: '62%', labels: {
                show: true,
                total: {
                    show: true, label: 'Success Rate',
                    formatter: function(w) {
                        return s.SuccessRate.toFixed(1) + '%';
                    }
                }
            } } } },
            legend: { position: 'bottom' },
            tooltip: { y: { formatter: function(v) { return v + ' requests'; } } }
        };
        new ApexCharts(document.querySelector('#chartDonut'), donutOpts).render();

        // ======================================================
        // CHART 4 — Status Code Bar Chart
        // ======================================================
        var scCounts = {};
        $.each(resultsData, function(i, r) {
            var code = r.StatusCode === 0 ? 'Timeout/Error' : r.StatusCode.toString();
            scCounts[code] = (scCounts[code] || 0) + 1;
        });
        var scLabels = Object.keys(scCounts).sort();
        var scValues = scLabels.map(function(k) { return scCounts[k]; });
        var scColors = scLabels.map(function(k) {
            var n = parseInt(k);
            if (isNaN(n))   return '#9e9e9e';
            if (n < 300)    return '#00C853';
            if (n < 400)    return '#1565c0';
            if (n < 500)    return '#FF6F00';
            return '#FF1744';
        });
        var scOpts = {
            series: [{ name: 'Requests', data: scValues }],
            chart: { type: 'bar', height: 220, toolbar: { show: false } },
            plotOptions: { bar: { distributed: true, columnWidth: '45%', borderRadius: 4 } },
            colors: scColors,
            xaxis: { categories: scLabels, title: { text: 'HTTP Status Code', style:{color:'#546e7a',fontSize:'12px'} } },
            yaxis: { title: { text: 'Count', style:{color:'#546e7a',fontSize:'12px'} } },
            legend: { show: false },
            dataLabels: { enabled: true, style: { fontSize:'11px' } },
            tooltip: { y: { formatter: function(v) { return v + ' requests'; } } }
        };
        new ApexCharts(document.querySelector('#chartStatusCodes'), scOpts).render();

        // ======================================================
        // DataTable
        // ======================================================
        var table = $('#tblResults').DataTable({
            data: resultsData,
            pageLength: 25,
            lengthMenu: [10, 25, 50, 100, 250],
            order: [[0, 'asc']],
            columns: [
                { data: 'RequestNumber', title: '#', width: '55px' },
                { data: 'QueryStringId', title: 'ID Value', width: '100px' },
                {
                    data: 'StatusCode', title: 'Status',
                    render: function(d) {
                        var cls = d === 0 ? 'pill-0' : d < 300 ? 'pill-2xx' : d < 400 ? 'pill-3xx' : d < 500 ? 'pill-4xx' : 'pill-5xx';
                        var lbl = d === 0 ? 'ERR' : d;
                        return '<span class="pill-sc ' + cls + '">' + lbl + '</span>';
                    }
                },
                {
                    data: 'ResponseTimeMs', title: 'Time (ms)',
                    render: function(d) {
                        var color = d < 200 ? '#2e7d32' : d < 500 ? '#e65100' : '#b71c1c';
                        return '<span style="font-weight:700;color:' + color + ';">' + d + '</span>';
                    }
                },
                {
                    data: 'IsSuccess', title: 'Result',
                    render: function(d) {
                        return d ? '<span class="label label-success"><i class="fa fa-check"></i> OK</span>'
                                 : '<span class="label label-danger"><i class="fa fa-times"></i> FAIL</span>';
                    }
                },
                {
                    data: 'RequestTime', title: 'Timestamp',
                    render: function(d) {
                        if (!d) return '';
                        var ms = parseInt(d.replace('/Date(', '').replace(')/', ''));
                        return isNaN(ms) ? d : new Date(ms).toLocaleTimeString();
                    }
                },
                {
                    data: 'ErrorMessage', title: 'Error',
                    render: function(d) {
                        if (!d) return '<span style="color:#bdbdbd">—</span>';
                        return '<span title="' + escHtml(d) + '" style="color:#c62828;font-size:11px;">' +
                               escHtml(d.length > 60 ? d.substr(0,60) + '…' : d) + '</span>';
                    }
                }
            ],
            createdRow: function(row, data) {
                $(row).addClass(data.IsSuccess ? 'dt-success' : 'dt-fail');
            },
            language: {
                emptyTable: 'No results found.',
                info: 'Showing _START_ to _END_ of _TOTAL_ requests',
                search: '<i class="fa fa-search"></i> Filter:'
            }
        });

        function escHtml(str) {
            if (!str) return '';
            return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        }

    }); // ready
</script>
</body>
</html>
