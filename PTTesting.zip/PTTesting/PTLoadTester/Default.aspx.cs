using System;
using System.Web.Script.Serialization;
using PTLoadTester.DAL;

namespace PTLoadTester
{
    public partial class Default : System.Web.UI.Page
    {
        // Backing fields — see Results.aspx.cs comment for VS 2012 ASPX compiler compatibility.
        private string _recentSessionsJson;
        private string _dbErrorJson;

        public string RecentSessionsJson { get { return _recentSessionsJson; } }
        public string DbErrorJson        { get { return _dbErrorJson;        } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var js = new JavaScriptSerializer();
                try
                {
                    var sessions = DatabaseHelper.GetRecentSessions(15);
                    _recentSessionsJson = js.Serialize(sessions);
                    _dbErrorJson        = "null";
                }
                catch (Exception ex)
                {
                    _recentSessionsJson = "[]";
                    _dbErrorJson        = js.Serialize(ex.Message);
                }
            }
        }
    }
}
