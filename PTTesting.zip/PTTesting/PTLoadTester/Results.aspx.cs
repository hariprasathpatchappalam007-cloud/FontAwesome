using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
using PTLoadTester.DAL;
using PTLoadTester.Models;

namespace PTLoadTester
{
    public partial class Results : System.Web.UI.Page
    {
        // ---- Backing fields for properties used in <%=...%> ASPX expressions.
        //      VS 2012's ASPX compiler requires explicit backing fields + getter-only
        //      properties to reliably resolve inline expressions in the derived page class.
        private int    _sessionId;
        private string _sessionUrl;
        private string _sessionParam;
        private string _sessionStarted;
        private int    _concurrentUsers;
        private string _summaryJson;
        private string _chartDataJson;
        private string _resultsJson;

        public int    SessionId       { get { return _sessionId;       } }
        public string SessionUrl      { get { return _sessionUrl;      } }
        public string SessionParam    { get { return _sessionParam;    } }
        public string SessionStarted  { get { return _sessionStarted;  } }
        public int    ConcurrentUsers { get { return _concurrentUsers; } }
        public string SummaryJson     { get { return _summaryJson;     } }
        public string ChartDataJson   { get { return _chartDataJson;   } }
        public string ResultsJson     { get { return _resultsJson;     } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                LoadData();
        }

        private void LoadData()
        {
            int id;
            if (!int.TryParse(Request.QueryString["sessionId"], out id) || id <= 0)
            {
                Response.Redirect("Default.aspx");
                return;
            }

            var js = new JavaScriptSerializer();
            js.MaxJsonLength = 10 * 1024 * 1024; // 10 MB

            LoadTestSession session;
            List<LoadTestResult> results;
            try
            {
                session = DatabaseHelper.GetSession(id);
                if (session == null) { Response.Redirect("Default.aspx"); return; }
                results = DatabaseHelper.GetResultsBySession(id);
            }
            catch (Exception ex)
            {
                // Render a minimal error page
                Response.Write("<h3 style='color:red;padding:30px;'>Database error: " +
                    Server.HtmlEncode(ex.Message) + "</h3><a href='Default.aspx'>Back</a>");
                Response.End();
                return;
            }

            // ---- Header properties ----
            _sessionId       = session.SessionId;
            _sessionUrl      = session.TestUrl;
            _sessionParam    = session.QueryParamName;
            _sessionStarted  = session.StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            _concurrentUsers = session.ConcurrentUsers;

            // ---- Summary stats ----
            var summary = BuildSummary(session, results);
            _summaryJson = js.Serialize(summary);

            // ---- Chart data ----
            var ordered = results.OrderBy(r => r.RequestNumber).ToList();
            var chartData = new ChartData
            {
                RequestNumbers     = ordered.Select(r => r.RequestNumber).ToList(),
                ResponseTimes      = ordered.Select(r => r.ResponseTimeMs).ToList(),
                IsSuccess          = ordered.Select(r => r.IsSuccess).ToList(),
                DistributionLabels = new List<string> { "< 50ms", "50-100ms", "100-200ms", "200-500ms", "500-1000ms", "> 1000ms" },
                DistributionCounts = BuildDistribution(ordered)
            };
            _chartDataJson = js.Serialize(chartData);

            // ---- Grid data (slim DTO to keep JSON small) ----
            var gridRows = ordered.Select(r => new
            {
                r.RequestNumber,
                r.QueryStringId,
                r.StatusCode,
                r.ResponseTimeMs,
                r.IsSuccess,
                r.RequestTime,
                r.ErrorMessage
            }).ToList();
            _resultsJson = js.Serialize(gridRows);
        }

        // ----------------------------------------------------------------
        private static TestSummary BuildSummary(LoadTestSession session, List<LoadTestResult> results)
        {
            if (results.Count == 0)
            {
                return new TestSummary { TotalRequests = session.TotalRequests };
            }

            var times = results.Select(r => r.ResponseTimeMs).OrderBy(t => t).ToList();
            int successCount = results.Count(r => r.IsSuccess);

            double totalSec = 0;
            if (session.EndTime.HasValue)
                totalSec = (session.EndTime.Value - session.StartTime).TotalSeconds;
            if (totalSec <= 0) totalSec = times.Sum() / 1000.0;

            return new TestSummary
            {
                TotalRequests       = results.Count,
                SuccessCount        = successCount,
                FailCount           = results.Count - successCount,
                SuccessRate         = (successCount * 100.0) / results.Count,
                AverageResponseTime = times.Average(),
                MinResponseTime     = times.First(),
                MaxResponseTime     = times.Last(),
                TotalDurationSeconds= totalSec,
                RequestsPerSecond   = totalSec > 0 ? results.Count / totalSec : 0,
                P50ResponseTime     = Percentile(times, 50),
                P95ResponseTime     = Percentile(times, 95),
                P99ResponseTime     = Percentile(times, 99)
            };
        }

        private static double Percentile(List<long> sorted, double pct)
        {
            if (sorted.Count == 0) return 0;
            double idx   = (pct / 100.0) * (sorted.Count - 1);
            int    lower = (int)Math.Floor(idx);
            int    upper = (int)Math.Ceiling(idx);
            if (lower == upper) return sorted[lower];
            double w = idx - lower;
            return sorted[lower] * (1 - w) + sorted[upper] * w;
        }

        private static List<int> BuildDistribution(List<LoadTestResult> ordered)
        {
            var buckets = new[] { 50L, 100L, 200L, 500L, 1000L, long.MaxValue };
            var counts  = new int[buckets.Length];
            foreach (var r in ordered)
            {
                for (int i = 0; i < buckets.Length; i++)
                {
                    if (r.ResponseTimeMs < buckets[i]) { counts[i]++; break; }
                }
            }
            return counts.ToList();
        }
    }
}
