using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
using PTLoadTester.DAL;
using PTLoadTester.Models;

namespace PTLoadTester
{
    public partial class WorkflowResults : System.Web.UI.Page
    {
        private int    _sessionId;
        private string _testName;
        private string _loginUrl;
        private string _userId;
        private int    _concurrentUsers;
        private int    _iterations;
        private string _sessionStarted;
        private string _sessionStatus;
        private string _urlSummariesJson;
        private string _overallSummaryJson;
        private string _resultsJson;

        public int    SessionId          { get { return _sessionId;          } }
        public string TestName           { get { return _testName;           } }
        public string LoginUrl           { get { return _loginUrl;           } }
        public string UserId             { get { return _userId;             } }
        public int    ConcurrentUsers    { get { return _concurrentUsers;    } }
        public int    Iterations         { get { return _iterations;         } }
        public string SessionStarted     { get { return _sessionStarted;     } }
        public string SessionStatus      { get { return _sessionStatus;      } }
        public string UrlSummariesJson   { get { return _urlSummariesJson;   } }
        public string OverallSummaryJson { get { return _overallSummaryJson; } }
        public string ResultsJson        { get { return _resultsJson;        } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                LoadData();
        }

        private void LoadData()
        {
            int id;
            if (!int.TryParse(Request.QueryString["sessionId"], out id) || id <= 0)
            {
                Response.Redirect("WorkflowTest.aspx");
                return;
            }

            var js = new JavaScriptSerializer { MaxJsonLength = 10 * 1024 * 1024 };

            WorkflowTestSession session;
            List<WorkflowPageResult> results;
            try
            {
                session = DatabaseHelper.GetWorkflowSession(id);
                if (session == null) { Response.Redirect("WorkflowTest.aspx"); return; }
                results = DatabaseHelper.GetWorkflowResultsBySession(id);
            }
            catch (Exception ex)
            {
                Response.Write("<h3 style='color:red;padding:30px;'>Database error: " +
                    Server.HtmlEncode(ex.Message) + "</h3><a href='WorkflowTest.aspx'>Back</a>");
                Response.End();
                return;
            }

            _sessionId       = session.SessionId;
            _testName        = session.TestName;
            _loginUrl        = session.LoginUrl;
            _userId          = session.UserId;
            _concurrentUsers = session.ConcurrentUsers;
            _iterations      = session.Iterations;
            _sessionStarted  = session.StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            _sessionStatus   = session.Status;

            // Per-URL summaries
            _urlSummariesJson   = js.Serialize(BuildUrlSummaries(results));
            // Overall summary
            _overallSummaryJson = js.Serialize(BuildOverallSummary(session, results));
            // Detail rows (slimmed for DataTables)
            _resultsJson = js.Serialize(results.Select(r => new
            {
                UrlShort              = ShortUrl(r.TargetUrl),
                r.TargetUrl,
                r.VirtualUserId,
                r.IterationNumber,
                r.PageLoadTimeMs,
                r.PageLoadStatusCode,
                r.PageLoadSuccess,
                r.SelectActionTimeMs,
                r.SelectActionStatusCode,
                r.SelectActionSuccess,
                r.ErrorMessage,
                RequestTime = r.RequestTime.ToString("HH:mm:ss")
            }).ToList());
        }

        // ------------------------------------------------------------------
        // Summary builders
        // ------------------------------------------------------------------

        private static List<WorkflowUrlSummary> BuildUrlSummaries(List<WorkflowPageResult> results)
        {
            var list = new List<WorkflowUrlSummary>();
            foreach (var grp in results.GroupBy(r => r.TargetUrl))
            {
                var items = grp.ToList();

                var pageTimes   = items.Where(r => r.PageLoadSuccess)
                                       .Select(r => r.PageLoadTimeMs).OrderBy(t => t).ToList();
                var selectTimes = items.Where(r => r.SelectActionSuccess)
                                       .Select(r => r.SelectActionTimeMs).OrderBy(t => t).ToList();

                list.Add(new WorkflowUrlSummary
                {
                    Url                = grp.Key,
                    UrlShort           = ShortUrl(grp.Key),
                    TotalRequests      = items.Count,
                    PageSuccessCount   = items.Count(r => r.PageLoadSuccess),
                    SelectSuccessCount = items.Count(r => r.SelectActionSuccess),
                    AvgPageLoadMs      = pageTimes.Any()   ? pageTimes.Average()            : 0,
                    MinPageLoadMs      = pageTimes.Any()   ? pageTimes.First()               : 0,
                    MaxPageLoadMs      = pageTimes.Any()   ? pageTimes.Last()                : 0,
                    P95PageLoadMs      = pageTimes.Any()   ? Percentile(pageTimes,   0.95)   : 0,
                    AvgSelectMs        = selectTimes.Any() ? selectTimes.Average()           : 0,
                    MinSelectMs        = selectTimes.Any() ? selectTimes.First()              : 0,
                    MaxSelectMs        = selectTimes.Any() ? selectTimes.Last()               : 0,
                    P95SelectMs        = selectTimes.Any() ? Percentile(selectTimes, 0.95)   : 0
                });
            }
            return list;
        }

        private static WorkflowOverallSummary BuildOverallSummary(
            WorkflowTestSession session, List<WorkflowPageResult> results)
        {
            int total          = results.Count;
            int pageOk         = results.Count(r => r.PageLoadSuccess);
            int selectOk       = results.Count(r => r.SelectActionSuccess);
            var pageTimes      = results.Where(r => r.PageLoadSuccess).Select(r => r.PageLoadTimeMs).ToList();
            var selectTimes    = results.Where(r => r.SelectActionSuccess).Select(r => r.SelectActionTimeMs).ToList();

            double durationSec = session.EndTime.HasValue
                ? (session.EndTime.Value - session.StartTime).TotalSeconds
                : (DateTime.Now - session.StartTime).TotalSeconds;

            return new WorkflowOverallSummary
            {
                TotalTests         = total,
                PageSuccessCount   = pageOk,
                SelectSuccessCount = selectOk,
                PageSuccessRate    = total > 0 ? pageOk   * 100.0 / total : 0,
                SelectSuccessRate  = total > 0 ? selectOk * 100.0 / total : 0,
                OverallAvgPageMs   = pageTimes.Any()   ? pageTimes.Average()   : 0,
                OverallAvgSelectMs = selectTimes.Any() ? selectTimes.Average() : 0,
                MinPageLoadMs      = pageTimes.Any()   ? pageTimes.Min()        : 0,
                MaxPageLoadMs      = pageTimes.Any()   ? pageTimes.Max()        : 0,
                TotalDurationSec   = durationSec,
                ConcurrentUsers    = session.ConcurrentUsers,
                Iterations         = session.Iterations,
                TotalUrls          = session.TotalUrls
            };
        }

        private static double Percentile(List<long> sorted, double p)
        {
            if (sorted.Count == 0) return 0;
            double idx   = p * (sorted.Count - 1);
            int    lower = (int)Math.Floor(idx);
            int    upper = Math.Min(lower + 1, sorted.Count - 1);
            double frac  = idx - lower;
            return sorted[lower] + frac * (sorted[upper] - sorted[lower]);
        }

        private static string ShortUrl(string url)
        {
            if (string.IsNullOrEmpty(url)) return url;
            try
            {
                var uri     = new Uri(url);
                string page = System.IO.Path.GetFileName(uri.AbsolutePath);
                return string.IsNullOrEmpty(uri.Query) ? page : page + uri.Query;
            }
            catch { return url; }
        }
    }
}
