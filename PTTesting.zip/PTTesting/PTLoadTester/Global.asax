<%@ Application Codebehind="Global.asax.cs" Inherits="PTLoadTester.Global" Language="C#" %>
