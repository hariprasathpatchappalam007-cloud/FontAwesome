using System;
using System.Web.UI;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM.Admin
{
    public partial class OracleSync : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!AuthHelper.IsAdmin) { Response.Redirect("~/Default.aspx"); return; }
            if (!IsPostBack) BindLog();
        }

        protected void btnSync_Click(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.Button btn = sender as System.Web.UI.WebControls.Button;
            string cmd = btn != null ? btn.CommandName : "Unknown";
            string triggeredBy = AuthHelper.CurrentUser;
            int syncId = SyncDAL.StartSyncLog(cmd, triggeredBy);
            SyncResult r = null;

            try
            {
                switch (cmd)
                {
                    case "CapexOnly":  r = SyncDAL.SyncCapex(syncId);  break;
                    case "OpexOnly":   r = SyncDAL.SyncOpex(syncId);   break;
                    case "GLOnly":     r = SyncDAL.SyncGL(syncId);     break;
                    case "VendorOnly": r = SyncDAL.SyncVendor(syncId); break;
                    case "BPMData":    r = SyncDAL.SyncBPMData(syncId); break;
                    case "CapexOpexHistory": r = SyncDAL.SyncCapexOpexHistory(syncId); break;
                    case "CapexOpexDetails": r = SyncDAL.SyncCapexOpexDetails(syncId); break;
                    case "GLHistory":        r = SyncDAL.SyncGLHistory(syncId);        break;
                    case "AllHistory":
                        var rch = SyncDAL.SyncCapexOpexHistory(syncId);
                        var rcd = SyncDAL.SyncCapexOpexDetails(syncId);
                        var rgh = SyncDAL.SyncGLHistory(syncId);
                        r = new SyncResult
                        {
                            SyncType  = "AllHistory",
                            Success   = rch.Success && rcd.Success && rgh.Success,
                            RecordsIn = rch.RecordsIn + rcd.RecordsIn + rgh.RecordsIn,
                            RecordsUp = rch.RecordsUp + rcd.RecordsUp + rgh.RecordsUp,
                            ErrorMsg  = string.Join("; ", new[] { rch.ErrorMsg, rcd.ErrorMsg, rgh.ErrorMsg })
                        };
                        break;
                    case "AllMasters":
                        var rc = SyncDAL.SyncCapex(syncId);
                        var ro = SyncDAL.SyncOpex(syncId);
                        var rg = SyncDAL.SyncGL(syncId);
                        var rv = SyncDAL.SyncVendor(syncId);
                        r = new SyncResult
                        {
                            SyncType  = "AllMasters",
                            Success   = rc.Success && ro.Success && rg.Success && rv.Success,
                            RecordsIn = rc.RecordsIn + ro.RecordsIn + rg.RecordsIn + rv.RecordsIn,
                            RecordsUp = rc.RecordsUp + ro.RecordsUp + rg.RecordsUp + rv.RecordsUp,
                            ErrorMsg  = string.Join("; ", new[] { rc.ErrorMsg, ro.ErrorMsg, rg.ErrorMsg, rv.ErrorMsg })
                        };
                        break;
                    case "FullSync":
                        var ram = new SyncResult { SyncType="FullSync", Success=true };
                        foreach (var sub in new[] {
                            SyncDAL.SyncCapex(syncId), SyncDAL.SyncOpex(syncId),
                            SyncDAL.SyncGL(syncId),    SyncDAL.SyncVendor(syncId),
                            SyncDAL.SyncBPMData(syncId),
                            SyncDAL.SyncCapexOpexHistory(syncId),
                            SyncDAL.SyncCapexOpexDetails(syncId),
                            SyncDAL.SyncGLHistory(syncId) })
                        {
                            ram.RecordsIn += sub.RecordsIn;
                            ram.RecordsUp += sub.RecordsUp;
                            if (!sub.Success) { ram.Success = false; ram.ErrorMsg += sub.ErrorMsg + "; "; }
                        }
                        r = ram;
                        break;
                }
            }
            catch (Exception ex)
            {
                r = new SyncResult { SyncType = cmd, Success = false, ErrorMsg = ex.Message };
            }

            if (r != null) SyncDAL.EndSyncLog(syncId, r);

            if (r != null && r.Success)
                ShowMsg(string.Format("✔ {0} completed. Records in: {1}, Upserted: {2}",
                    r.SyncType, r.RecordsIn, r.RecordsUp), true);
            else
                ShowMsg(string.Format("✘ {0} failed: {1}", cmd, r != null ? r.ErrorMsg : "Unknown error"), false);

            BindLog();
        }

        private void BindLog()
        {
            gvLog.DataSource = SyncDAL.GetSyncLogs(30);
            gvLog.DataBind();
        }

        private void ShowMsg(string msg, bool success)
        {
            lblMsg.Text     = msg;
            lblMsg.CssClass = success ? "sync-result sync-ok" : "sync-result sync-err";
            lblMsg.Visible  = true;
        }
    }
}
