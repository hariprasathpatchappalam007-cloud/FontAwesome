// Auto-generated designer file for Admin/CapexMaster.aspx
namespace DFM_BPM.Admin
{
    public partial class CapexMaster
    {
        protected global::System.Web.UI.WebControls.Label      lblMsg;
        protected global::System.Web.UI.WebControls.TextBox    txtSearch;
        protected global::System.Web.UI.WebControls.LinkButton btnSearch;
        protected global::System.Web.UI.WebControls.LinkButton btnExport;
        protected global::System.Web.UI.WebControls.Literal    litSyncInfo;
        protected global::System.Web.UI.WebControls.Literal    litTotalBudget;
        protected global::System.Web.UI.WebControls.Literal    litTotalUtil;
        protected global::System.Web.UI.WebControls.Literal    litTotalLocked;
        protected global::System.Web.UI.WebControls.Literal    litTotalAvail;
        protected global::System.Web.UI.WebControls.Literal    litCount;
        protected global::System.Web.UI.WebControls.GridView   gv;
    }
}
