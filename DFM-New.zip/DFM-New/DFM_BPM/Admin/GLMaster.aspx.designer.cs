// Auto-generated designer file for Admin/GLMaster.aspx
namespace DFM_BPM.Admin
{
    public partial class GLMaster
    {
        protected global::System.Web.UI.WebControls.Label      lblMsg;
        protected global::System.Web.UI.WebControls.TextBox    txtSearch;
        protected global::System.Web.UI.WebControls.LinkButton btnSearch;
        protected global::System.Web.UI.WebControls.LinkButton btnExport;
        protected global::System.Web.UI.WebControls.Literal    litCount;
        protected global::System.Web.UI.WebControls.GridView   gv;
    }
}
