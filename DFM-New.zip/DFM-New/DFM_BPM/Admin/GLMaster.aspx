<%@ Page Title="GL Master" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="GLMaster.aspx.cs" Inherits="DFM_BPM.Admin.GLMaster" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><i class="bi bi-journal-bookmark"></i> GL Master
        <small style="font-size:.55em;color:#64748b;font-weight:400;">Read-only – synced from Oracle BPM (Q2)</small>
    </h1>
    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="filter-row">
        <div class="form-group" style="flex:2;">
            <label>Search by GL Number or Description</label>
            <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" />
        </div>
        <div class="form-group"><label>&nbsp;</label>
            <asp:LinkButton ID="btnSearch" runat="server" CssClass="btn btn-primary" OnClick="btnSearch_Click"><i class="bi bi-search"></i> Search</asp:LinkButton></div>
        <div class="form-group"><label>&nbsp;</label>
            <asp:LinkButton ID="btnExport" runat="server" CssClass="btn btn-success" OnClick="btnExport_Click"><i class="bi bi-file-excel"></i> Export</asp:LinkButton></div>
    </div>

    <div class="card-panel">
        <div class="card-panel-hdr"><i class="bi bi-table"></i> GL Records (<asp:Literal ID="litCount" runat="server" Text="0" />)</div>
        <div class="card-panel-body" style="padding:0;overflow-x:auto;">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false"
                CssClass="dfm-table" GridLines="None"
                EmptyDataText="No GL data found. Please run Oracle Sync first.">
                <Columns>
                    <asp:BoundField DataField="GLNumber"            HeaderText="GL Number" />
                    <asp:BoundField DataField="GLDescription"       HeaderText="Description" />
                    <asp:BoundField DataField="GLOpenedDate"        HeaderText="Opened" DataFormatString="{0:dd-MMM-yyyy}" />
                    <asp:BoundField DataField="BudgetedAmount"      HeaderText="Budget (AED)"        DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="BPMLockedAmount"     HeaderText="BPM Locked (AED)"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="AMSLockedAmount"     HeaderText="AMS Locked (AED)"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="UtilizedAmount"      HeaderText="Utilized (AED)"     DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="BalanceAmount"       HeaderText="Balance (AED)"      DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="CapitalizedAmount"   HeaderText="Capitalized (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="InvoiceProcessedAmt" HeaderText="Invoice Proc.(AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="LastSyncDate"        HeaderText="Last Sync"          DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
