<%@ Page Title="OPEX Master" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="OpexMaster.aspx.cs" Inherits="DFM_BPM.Admin.OpexMaster" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><i class="bi bi-receipt"></i> OPEX Master
        <small style="font-size:.55em;color:#64748b;font-weight:400;">Read-only – synced from Oracle BPM</small>
    </h1>
    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="filter-row">
        <div class="form-group" style="flex:2;">
            <label>Search by OPEX ID or Contract</label>
            <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" />
        </div>
        <div class="form-group">
            <label>&nbsp;</label>
            <asp:LinkButton ID="btnSearch" runat="server" CssClass="btn btn-primary" OnClick="btnSearch_Click">
                <i class="bi bi-search"></i> Search
            </asp:LinkButton>
        </div>
        <div class="form-group">
            <label>&nbsp;</label>
            <asp:LinkButton ID="btnExport" runat="server" CssClass="btn btn-success" OnClick="btnExport_Click">
                <i class="bi bi-file-excel"></i> Export
            </asp:LinkButton>
        </div>
    </div>

    <div class="kpi-row">
        <div class="kpi-card kpi-green"><span class="kpi-icon"><i class="bi bi-currency-dollar"></i></span>
            <div><div class="kpi-label">Total Budget</div><div class="kpi-val"><asp:Literal ID="litTotalBudget" runat="server" Text="0" /></div></div></div>
        <div class="kpi-card kpi-blue"><span class="kpi-icon"><i class="bi bi-graph-up"></i></span>
            <div><div class="kpi-label">Total Utilized</div><div class="kpi-val"><asp:Literal ID="litTotalUtil" runat="server" Text="0" /></div></div></div>
        <div class="kpi-card kpi-orange"><span class="kpi-icon"><i class="bi bi-lock"></i></span>
            <div><div class="kpi-label">Total Locked</div><div class="kpi-val"><asp:Literal ID="litTotalLocked" runat="server" Text="0" /></div></div></div>
        <div class="kpi-card kpi-red"><span class="kpi-icon"><i class="bi bi-wallet2"></i></span>
            <div><div class="kpi-label">Total Available</div><div class="kpi-val"><asp:Literal ID="litTotalAvail" runat="server" Text="0" /></div></div></div>
    </div>

    <div class="card-panel">
        <div class="card-panel-hdr"><i class="bi bi-table"></i> OPEX Records (<asp:Literal ID="litCount" runat="server" Text="0" />)</div>
        <div class="card-panel-body" style="padding:0;overflow-x:auto;">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false"
                CssClass="dfm-table" GridLines="None"
                EmptyDataText="No OPEX data found. Please run Oracle Sync first.">
                <Columns>
                    <asp:BoundField DataField="OpexID"          HeaderText="OPEX ID" />
                    <asp:BoundField DataField="BudgetedAmount"  HeaderText="Budgeted (AED)"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="UtilizedAmount"  HeaderText="Utilized (AED)"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="LockedAmount"    HeaderText="BPM Locked (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="AvailableAmount" HeaderText="Available (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="Contracts"       HeaderText="Contracts" />
                    <asp:BoundField DataField="LastSyncDate"    HeaderText="Last Sync"        DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
