<%@ Page Title="Vendor Master" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="VendorMaster.aspx.cs" Inherits="DFM_BPM.Admin.VendorMaster" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><i class="bi bi-building"></i> Vendor Master
        <small style="font-size:.55em;color:#64748b;font-weight:400;">Read-only – synced from Oracle BPM (Q16)</small>
    </h1>
    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <div class="filter-row">
        <div class="form-group" style="flex:2;">
            <label>Search by Name or Code</label>
            <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" />
        </div>
        <div class="form-group"><label>&nbsp;</label>
            <asp:LinkButton ID="btnSearch" runat="server" CssClass="btn btn-primary" OnClick="btnSearch_Click"><i class="bi bi-search"></i> Search</asp:LinkButton></div>
        <div class="form-group"><label>&nbsp;</label>
            <asp:LinkButton ID="btnExport" runat="server" CssClass="btn btn-success" OnClick="btnExport_Click"><i class="bi bi-file-excel"></i> Export</asp:LinkButton></div>
    </div>

    <div class="card-panel">
        <div class="card-panel-hdr"><i class="bi bi-table"></i> Vendors (<asp:Literal ID="litCount" runat="server" Text="0" />)</div>
        <div class="card-panel-body" style="padding:0;overflow-x:auto;">
            <asp:GridView ID="gv" runat="server" AutoGenerateColumns="false"
                CssClass="dfm-table" GridLines="None"
                EmptyDataText="No vendor data. Please run Oracle Sync first.">
                <Columns>
                    <asp:BoundField DataField="VendorCode" HeaderText="Code" />
                    <asp:BoundField DataField="VendorName" HeaderText="Vendor Name" />
                    <asp:BoundField DataField="LastSyncDate" HeaderText="Last Sync" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
