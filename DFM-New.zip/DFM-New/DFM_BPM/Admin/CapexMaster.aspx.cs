using System;
using System.Data;
using System.Web.UI;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM.Admin
{
    public partial class CapexMaster : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) Bind(null);
        }

        private void Bind(string search)
        {
            DataTable dt = MastersDAL.GetCapex(search);
            gv.DataSource = dt;
            gv.DataBind();
            litCount.Text = dt.Rows.Count.ToString();

            decimal budget = 0, util = 0, locked = 0, avail = 0;
            foreach (DataRow r in dt.Rows)
            {
                budget += DecVal(r, "BudgetedAmount");
                util   += DecVal(r, "UtilizedAmount");
                locked += DecVal(r, "LockedAmount");
                avail  += DecVal(r, "AvailableAmount");
            }
            litTotalBudget.Text = budget.ToString("N2");
            litTotalUtil.Text   = util.ToString("N2");
            litTotalLocked.Text = locked.ToString("N2");
            litTotalAvail.Text  = avail.ToString("N2");

            // Sync info
            DataRow syncRow = Db.QueryRow("SELECT TOP 1 CONVERT(VARCHAR,EndTime,120) AS T FROM dbo.SyncLog WHERE Status='Success' AND SyncType LIKE '%Capex%' ORDER BY SyncID DESC");
            if (syncRow != null)
                litSyncInfo.Text = "<span style='color:#64748b;font-size:.8em;'>Last sync: " + syncRow["T"] + "</span>";
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Bind(txtSearch.Text.Trim());
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = MastersDAL.GetCapex(txtSearch.Text.Trim());
            ExcelHelper.ExportToExcel(Response, dt, "CAPEX_Master_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        private static decimal DecVal(DataRow r, string col)
        {
            if (r[col] == DBNull.Value) return 0m;
            decimal v; return decimal.TryParse(r[col].ToString(), out v) ? v : 0m;
        }
    }
}
