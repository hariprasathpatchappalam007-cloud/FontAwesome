<%@ Page Title="User Management" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="UserManagement.aspx.cs" Inherits="DFM_BPM.Admin.UserManagement" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
<style>
.tab-pane { padding-top: 14px; }
</style>
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><i class="bi bi-people"></i> User Management</h1>
    <asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

    <!-- Bootstrap Tabs: Users | Roles | Role Assignments | Page Access -->
    <ul class="nav nav-tabs" role="tablist">
        <li class="active"><a href="#tabUsers"  data-toggle="tab"><i class="bi bi-person"></i> Users</a></li>
        <li><a href="#tabRoles" data-toggle="tab"><i class="bi bi-shield"></i> Roles &amp; Assignments</a></li>
        <li><a href="#tabPage"  data-toggle="tab"><i class="bi bi-layout-sidebar"></i> Page Access</a></li>
    </ul>

    <div class="tab-content">
        <!-- ============ TAB 1: USERS ============ -->
        <div class="tab-pane active" id="tabUsers">
            <!-- Add User Form -->
            <div class="card-panel">
                <div class="dfm-panel-hdr" onclick="DFM.togglePanel('userFormBody','userChev')">
                    <span id="userChev" class="glyphicon glyphicon-chevron-right dfm-panel-chev"></span>
                    <i class="bi bi-person-plus"></i> Add / Reset User
                </div>
                <div id="userFormBody" class="dfm-panel-body">
                    <asp:HiddenField ID="hfEditUserId" runat="server" Value="0" />
                    <div class="form-grid-4">
                        <div class="form-group">
                            <label>Username *</label>
                            <asp:TextBox ID="txtUsername" runat="server" CssClass="form-control" placeholder="e.g. john.doe" />
                        </div>
                        <div class="form-group">
                            <label>Full Name *</label>
                            <asp:TextBox ID="txtFullName" runat="server" CssClass="form-control" />
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" />
                        </div>
                        <div class="form-group">
                            <label>Department</label>
                            <asp:TextBox ID="txtDept" runat="server" CssClass="form-control" />
                        </div>
                        <div class="form-group">
                            <label>Primary Role *</label>
                            <asp:DropDownList ID="ddlRole" runat="server" CssClass="form-control" />
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <asp:TextBox ID="txtPwd" runat="server" CssClass="form-control" TextMode="Password" placeholder="Leave blank = Admin@123" />
                        </div>
                        <div class="form-group" style="align-self:end;">
                            <asp:Button ID="btnSaveUser" runat="server" CssClass="btn btn-primary" Text="Save User" OnClick="btnSaveUser_Click" />
                        </div>
                    </div>
                </div>
            </div>

            <!-- Users Grid -->
            <div class="card-panel">
                <div class="card-panel-hdr"><i class="bi bi-table"></i> All Users</div>
                <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                    <asp:GridView ID="gvUsers" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None"
                        OnRowCommand="gvUsers_RowCommand"
                        EmptyDataText="No users found.">
                        <Columns>
                            <asp:BoundField DataField="Username"      HeaderText="Username" />
                            <asp:BoundField DataField="FullName"      HeaderText="Full Name" />
                            <asp:BoundField DataField="Email"         HeaderText="Email" />
                            <asp:BoundField DataField="Department"    HeaderText="Dept" />
                            <asp:BoundField DataField="RoleName"      HeaderText="Role" />
                            <asp:TemplateField HeaderText="Enabled">
                                <ItemTemplate>
                                    <span class='<%# ((bool)Eval("IsEnabled")) ? "badge-success" : "badge-danger" %>'>
                                        <%# ((bool)Eval("IsEnabled")) ? "Yes" : "No" %></span>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:BoundField DataField="LastLoginDate" HeaderText="Last Login" DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                            <asp:TemplateField HeaderText="Actions">
                                <ItemTemplate>
                                    <div class="gv-acts">
                                        <asp:LinkButton runat="server" CssClass="btn btn-xs btn-warning"
                                            CommandName="ToggleEnable" CommandArgument='<%# Eval("UserID") %>'
                                            OnClientClick="return confirm('Toggle enabled status?')">
                                            <i class="bi bi-toggle-on"></i>
                                        </asp:LinkButton>
                                        <asp:LinkButton runat="server" CssClass="btn btn-xs btn-info"
                                            CommandName="ResetPwd" CommandArgument='<%# Eval("UserID") %>'
                                            OnClientClick="return confirm('Reset password to Admin@123?')">
                                            <i class="bi bi-key"></i>
                                        </asp:LinkButton>
                                        <asp:LinkButton runat="server" CssClass="btn btn-xs btn-default"
                                            CommandName="Assign" CommandArgument='<%# Eval("Username") %>'
                                            title="Manage role assignments">
                                            <i class="bi bi-person-badge"></i>
                                        </asp:LinkButton>
                                        <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger"
                                            CommandName="DeleteUser" CommandArgument='<%# Eval("UserID") %>'
                                            OnClientClick="return confirm('Delete this user?')">
                                            <i class="bi bi-trash"></i>
                                        </asp:LinkButton>
                                    </div>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>
            </div>

            <!-- Role Assignment panel (shown after clicking Assign) -->
            <asp:Panel ID="pnlAssign" runat="server" Visible="false" CssClass="card-panel">
                <div class="card-panel-hdr"><i class="bi bi-person-badge"></i>
                    Role Assignments for: <strong><asp:Literal ID="litAssignUser" runat="server" /></strong>
                </div>
                <div class="card-panel-body">
                    <p style="font-size:.88em;color:#64748b;">Check the workflow roles this user should have (in addition to their primary role).</p>
                    <div class="form-grid-4">
                        <div class="form-group">
                            <asp:CheckBox ID="chkRequestor" runat="server" Text=" Requestor" />
                        </div>
                        <div class="form-group">
                            <asp:CheckBox ID="chkReviewer" runat="server" Text=" Reviewer (can review PET before approval)" />
                        </div>
                        <div class="form-group">
                            <asp:CheckBox ID="chkApprover" runat="server" Text=" Approver (can approve / reject PET)" />
                        </div>
                    </div>
                    <asp:HiddenField ID="hfAssignUsername" runat="server" />
                    <asp:Button ID="btnSaveAssign" runat="server" CssClass="btn btn-primary" Text="Save Assignments" OnClick="btnSaveAssign_Click" />
                    <asp:Button ID="btnCancelAssign" runat="server" CssClass="btn btn-default" Text="Cancel" OnClick="btnCancelAssign_Click" CausesValidation="false" />
                </div>
            </asp:Panel>
        </div><!-- /tabUsers -->

        <!-- ============ TAB 2: ROLES ============ -->
        <div class="tab-pane" id="tabRoles">
            <div class="card-panel">
                <div class="card-panel-hdr"><i class="bi bi-shield"></i> System Roles</div>
                <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                    <asp:GridView ID="gvRoles" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None" EmptyDataText="No roles.">
                        <Columns>
                            <asp:BoundField DataField="RoleID"      HeaderText="ID" />
                            <asp:BoundField DataField="RoleName"    HeaderText="Role Name" />
                            <asp:BoundField DataField="Description" HeaderText="Description" />
                            <asp:TemplateField HeaderText="Active">
                                <ItemTemplate>
                                    <span class='<%# ((bool)Eval("IsActive")) ? "badge-success" : "badge-danger" %>'>
                                        <%# ((bool)Eval("IsActive")) ? "Yes" : "No" %></span>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>
            </div>

            <!-- Reviewer/Approver assignment overview -->
            <div class="card-panel">
                <div class="card-panel-hdr"><i class="bi bi-people"></i> Reviewer &amp; Approver Assignments</div>
                <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                    <asp:GridView ID="gvAssignments" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None" EmptyDataText="No assignments.">
                        <Columns>
                            <asp:BoundField DataField="Username" HeaderText="Username" />
                            <asp:BoundField DataField="RoleType" HeaderText="Workflow Role" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
        </div><!-- /tabRoles -->

        <!-- ============ TAB 3: PAGE ACCESS ============ -->
        <div class="tab-pane" id="tabPage">
            <div class="card-panel">
                <div class="card-panel-hdr"><i class="bi bi-layout-sidebar"></i> Page Access by Role</div>
                <div class="card-panel-body">
                    <div class="form-grid-4">
                        <div class="form-group">
                            <label>Select Role</label>
                            <asp:DropDownList ID="ddlPageRole" runat="server" CssClass="form-control"
                                AutoPostBack="true" OnSelectedIndexChanged="ddlPageRole_Changed" />
                        </div>
                    </div>
                    <asp:GridView ID="gvPageAccess" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None"
                        OnRowCommand="gvPageAccess_RowCommand"
                        EmptyDataText="Select a role.">
                        <Columns>
                            <asp:BoundField DataField="PageName" HeaderText="Page" />
                            <asp:BoundField DataField="Category" HeaderText="Category" />
                            <asp:TemplateField HeaderText="Can View">
                                <ItemTemplate>
                                    <span class='<%# (int)Eval("CanView")==1 ? "badge-success" : "badge-secondary" %>'>
                                        <%# (int)Eval("CanView")==1 ? "Yes" : "No" %></span>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField HeaderText="Toggle">
                                <ItemTemplate>
                                    <asp:LinkButton runat="server" CssClass="btn btn-xs btn-warning"
                                        CommandName="ToggleAccess" CommandArgument='<%# Eval("PageID") %>'>
                                        Toggle
                                    </asp:LinkButton>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
        </div><!-- /tabPage -->
    </div><!-- /tab-content -->
</asp:Content>
