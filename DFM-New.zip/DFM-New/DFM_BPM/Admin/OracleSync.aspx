<%@ Page Title="Oracle Sync" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="OracleSync.aspx.cs" Inherits="DFM_BPM.Admin.OracleSync" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
<style>
.sync-card { background:#fff; border:1px solid #e2e8f0; border-radius:10px; padding:18px; margin-bottom:12px; }
.sync-card h4 { margin:0 0 8px; color:#1a3c5e; font-size:.95em; font-weight:700; }
.sync-btn { margin-right:8px; }
.sync-result { padding:10px 14px; border-radius:6px; margin-top:10px; font-size:.88em; white-space:pre-wrap; font-family:monospace; }
.sync-ok    { background:#d1fae5; color:#065f46; }
.sync-err   { background:#fee2e2; color:#991b1b; }
.sync-info  { background:#dbeafe; color:#1e40af; }
</style>
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><i class="bi bi-arrow-repeat"></i> Oracle BPM Sync</h1>
    <p style="color:#64748b;font-size:.9em;">
        Synchronises master data and BPM fact tables from Oracle (DMSUAT) into SQL Server (DFM_BPM).
        Masters (CAPEX, OPEX, GL, Vendor) are read-only once synced.
        BPM data (Projects, PET, Contracts, LPO, Invoices) is also synced here.
    </p>

    <asp:Label ID="lblMsg" runat="server" CssClass="sync-result sync-info" Visible="false" />

    <div class="row">
        <!-- Master Sync -->
        <div class="col-md-6">
            <div class="sync-card">
                <h4><i class="bi bi-database-fill-up"></i> Master Data Sync</h4>
                <p style="font-size:.84em;color:#64748b;">CAPEX, OPEX, GL, Vendor – one-time then delta.</p>
                <asp:Button ID="btnSyncCapex"  runat="server" Text="Sync CAPEX"  CssClass="btn btn-primary sync-btn"  OnClick="btnSync_Click" CommandName="CapexOnly"  />
                <asp:Button ID="btnSyncOpex"   runat="server" Text="Sync OPEX"   CssClass="btn btn-primary sync-btn"  OnClick="btnSync_Click" CommandName="OpexOnly"   />
                <asp:Button ID="btnSyncGL"     runat="server" Text="Sync GL"     CssClass="btn btn-info    sync-btn"  OnClick="btnSync_Click" CommandName="GLOnly"     />
                <asp:Button ID="btnSyncVendor" runat="server" Text="Sync Vendor" CssClass="btn btn-default sync-btn"  OnClick="btnSync_Click" CommandName="VendorOnly" />
                <br /><br />
                <asp:Button ID="btnSyncAllMasters" runat="server" Text="Sync ALL Masters" CssClass="btn btn-warning sync-btn"
                    OnClick="btnSync_Click" CommandName="AllMasters"
                    OnClientClick="return confirm('Sync all master tables from Oracle?');" />
            </div>
        </div>

        <!-- BPM Data Sync -->
        <div class="col-md-6">
            <div class="sync-card">
                <h4><i class="bi bi-diagram-3"></i> BPM Fact Data Sync</h4>
                <p style="font-size:.84em;color:#64748b;">Projects, PET, Contracts (Q1), GL (Q2), LPO (Q3), Invoices (Q4), CAPEX/OPEX Details (Q13/Q14).</p>
                <asp:Button ID="btnSyncBPM" runat="server" Text="Sync BPM Data" CssClass="btn btn-success sync-btn"
                    OnClick="btnSync_Click" CommandName="BPMData"
                    OnClientClick="return confirm('Sync BPM fact data from Oracle? This may take a few minutes.');" />
                <br /><br />
                <asp:Button ID="btnSyncAll" runat="server" Text="Full Sync (All)" CssClass="btn btn-danger sync-btn"
                    OnClick="btnSync_Click" CommandName="FullSync"
                    OnClientClick="return confirm('Run FULL sync of all data? This may take several minutes.');" />
            </div>
        </div>
    </div>

    <!-- Sync log -->
    <div class="card-panel">
        <div class="card-panel-hdr"><i class="bi bi-clock-history"></i> Sync History (Last 30)</div>
        <div class="card-panel-body" style="padding:0;overflow-x:auto;">
            <asp:GridView ID="gvLog" runat="server" AutoGenerateColumns="false"
                CssClass="dfm-table" GridLines="None" EmptyDataText="No sync history.">
                <Columns>
                    <asp:BoundField DataField="SyncID"      HeaderText="#" />
                    <asp:BoundField DataField="SyncType"    HeaderText="Type" />
                    <asp:BoundField DataField="StartTime"   HeaderText="Started"   DataFormatString="{0:dd-MMM-yyyy HH:mm:ss}" />
                    <asp:BoundField DataField="EndTime"     HeaderText="Ended"     DataFormatString="{0:dd-MMM-yyyy HH:mm:ss}" />
                    <asp:TemplateField HeaderText="Status">
                        <ItemTemplate>
                            <span class='<%# Eval("Status").ToString()=="Success" ? "badge-success" : Eval("Status").ToString()=="Running" ? "badge-warning" : "badge-danger" %>'>
                                <%# Eval("Status") %></span>
                        </ItemTemplate>
                    </asp:TemplateField>
                    <asp:BoundField DataField="RecordsIn"   HeaderText="Records In" ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="RecordsUp"   HeaderText="Upserted"   ItemStyle-CssClass="text-right" />
                    <asp:BoundField DataField="TriggeredBy" HeaderText="By" />
                    <asp:BoundField DataField="ErrorMsg"    HeaderText="Error" />
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>
