// Auto-generated designer file for Admin/OracleSync.aspx
namespace DFM_BPM.Admin
{
    public partial class OracleSync
    {
        protected global::System.Web.UI.WebControls.Label   lblMsg;
        protected global::System.Web.UI.WebControls.Button  btnSyncCapex;
        protected global::System.Web.UI.WebControls.Button  btnSyncOpex;
        protected global::System.Web.UI.WebControls.Button  btnSyncGL;
        protected global::System.Web.UI.WebControls.Button  btnSyncVendor;
        protected global::System.Web.UI.WebControls.Button  btnSyncAllMasters;
        protected global::System.Web.UI.WebControls.Button  btnSyncBPM;
        protected global::System.Web.UI.WebControls.Button  btnSyncAll;
        protected global::System.Web.UI.WebControls.GridView gvLog;
    }
}
