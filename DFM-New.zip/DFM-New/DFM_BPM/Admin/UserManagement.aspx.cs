using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM.Admin
{
    public partial class UserManagement : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!AuthHelper.IsAdmin)
            {
                Response.Redirect("~/Default.aspx");
                return;
            }
            if (!IsPostBack)
            {
                BindAll();
            }
        }

        private void BindAll()
        {
            // Users
            gvUsers.DataSource = UserDAL.GetUsers();
            gvUsers.DataBind();

            // Roles dropdown for add form
            DataTable roles = UserDAL.GetRoles();
            ddlRole.DataSource     = roles;
            ddlRole.DataTextField  = "RoleName";
            ddlRole.DataValueField = "RoleID";
            ddlRole.DataBind();

            // Roles tab
            gvRoles.DataSource = roles;
            gvRoles.DataBind();

            // Assignments tab
            gvAssignments.DataSource = Db.Query("SELECT Username, RoleType FROM dbo.UserRoleAssignments ORDER BY Username, RoleType");
            gvAssignments.DataBind();

            // Page access role dropdown
            ddlPageRole.DataSource     = roles;
            ddlPageRole.DataTextField  = "RoleName";
            ddlPageRole.DataValueField = "RoleID";
            ddlPageRole.DataBind();
            ddlPageRole.Items.Insert(0, new ListItem("-- Select Role --", "0"));
        }

        // ===== Add User =====
        protected void btnSaveUser_Click(object sender, EventArgs e)
        {
            string user = (txtUsername.Text ?? "").Trim();
            string name = (txtFullName.Text ?? "").Trim();
            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(name))
            {
                ShowMsg("Username and Full Name are required.");
                return;
            }
            if (Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM dbo.AppUsers WHERE Username=@u", Db.P("@u", user))) > 0)
            {
                ShowMsg("Username already exists.");
                return;
            }
            int roleId = Convert.ToInt32(ddlRole.SelectedValue);
            string pwd = string.IsNullOrEmpty(txtPwd.Text) ? "Admin@123" : txtPwd.Text;
            UserDAL.CreateUser(user, name, txtEmail.Text.Trim(), txtDept.Text.Trim(), roleId, pwd, AuthHelper.CurrentUser);
            ShowMsg("User created. Default password: Admin@123");
            txtUsername.Text = txtFullName.Text = txtEmail.Text = txtDept.Text = "";
            BindAll();
        }

        // ===== User Grid Commands =====
        protected void gvUsers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ToggleEnable")
            {
                UserDAL.ToggleEnabled(Convert.ToInt32(e.CommandArgument));
                BindAll();
            }
            else if (e.CommandName == "ResetPwd")
            {
                UserDAL.ResetPassword(Convert.ToInt32(e.CommandArgument), "Admin@123");
                ShowMsg("Password reset to Admin@123.");
                BindAll();
            }
            else if (e.CommandName == "DeleteUser")
            {
                UserDAL.DeleteUser(Convert.ToInt32(e.CommandArgument));
                ShowMsg("User deleted.");
                BindAll();
            }
            else if (e.CommandName == "Assign")
            {
                // Show role assignment panel
                string username = e.CommandArgument.ToString();
                hfAssignUsername.Value = username;
                litAssignUser.Text     = Server.HtmlEncode(username);
                pnlAssign.Visible      = true;

                DataTable dt = UserDAL.GetUserRoleAssignments(username);
                var roles = new System.Collections.Generic.HashSet<string>();
                foreach (DataRow r in dt.Rows) roles.Add(r["RoleType"].ToString());

                chkRequestor.Checked = roles.Contains("Requestor");
                chkReviewer.Checked  = roles.Contains("Reviewer");
                chkApprover.Checked  = roles.Contains("Approver");
            }
        }

        // ===== Save role assignments =====
        protected void btnSaveAssign_Click(object sender, EventArgs e)
        {
            string u = hfAssignUsername.Value;
            UserDAL.SetRoleAssignment(u, "Requestor", chkRequestor.Checked, AuthHelper.CurrentUser);
            UserDAL.SetRoleAssignment(u, "Reviewer",  chkReviewer.Checked,  AuthHelper.CurrentUser);
            UserDAL.SetRoleAssignment(u, "Approver",  chkApprover.Checked,  AuthHelper.CurrentUser);
            ShowMsg("Role assignments saved for " + u + ".");
            pnlAssign.Visible = false;
            BindAll();
        }

        protected void btnCancelAssign_Click(object sender, EventArgs e)
        {
            pnlAssign.Visible = false;
        }

        // ===== Page Access =====
        protected void ddlPageRole_Changed(object sender, EventArgs e)
        {
            BindPageAccess();
        }

        private void BindPageAccess()
        {
            int roleId;
            if (!int.TryParse(ddlPageRole.SelectedValue, out roleId) || roleId == 0) return;
            gvPageAccess.DataSource = UserDAL.GetPageAccessForRole(roleId);
            gvPageAccess.DataBind();
        }

        protected void gvPageAccess_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "ToggleAccess") return;
            int pageId = Convert.ToInt32(e.CommandArgument);
            int roleId;
            if (!int.TryParse(ddlPageRole.SelectedValue, out roleId) || roleId == 0) return;

            int current = Convert.ToInt32(Db.Scalar(
                "SELECT COUNT(*) FROM dbo.PageAccess WHERE RoleID=@r AND PageID=@p AND CanView=1",
                Db.P("@r", roleId), Db.P("@p", pageId)));
            UserDAL.SavePageAccess(roleId, pageId, current == 0);
            BindPageAccess();
        }

        private void ShowMsg(string msg)
        {
            lblMsg.Text    = msg;
            lblMsg.Visible = true;
        }
    }
}
