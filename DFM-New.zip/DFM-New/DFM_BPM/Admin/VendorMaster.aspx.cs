using System;
using System.Data;
using System.Web.UI;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM.Admin
{
    public partial class VendorMaster : Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(null); }
        private void Bind(string s)
        {
            DataTable dt = MastersDAL.GetVendors(s);
            gv.DataSource = dt; gv.DataBind();
            litCount.Text = dt.Rows.Count.ToString();
        }
        protected void btnSearch_Click(object sender, EventArgs e) { Bind(txtSearch.Text.Trim()); }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            ExcelHelper.ExportToExcel(Response, MastersDAL.GetVendors(txtSearch.Text.Trim()),
                "Vendor_Master_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }
    }
}
