using System;
using System.Data;
using System.Web.UI;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM.Admin
{
    public partial class OpexMaster : Page
    {
        protected void Page_Load(object sender, EventArgs e) { if (!IsPostBack) Bind(null); }

        private void Bind(string search)
        {
            DataTable dt = MastersDAL.GetOpex(search);
            gv.DataSource = dt; gv.DataBind();
            litCount.Text = dt.Rows.Count.ToString();
            decimal b = 0, u = 0, l = 0, a = 0;
            foreach (DataRow r in dt.Rows)
            {
                b += Dec(r,"BudgetedAmount"); u += Dec(r,"UtilizedAmount");
                l += Dec(r,"LockedAmount");   a += Dec(r,"AvailableAmount");
            }
            litTotalBudget.Text = b.ToString("N2"); litTotalUtil.Text = u.ToString("N2");
            litTotalLocked.Text = l.ToString("N2"); litTotalAvail.Text = a.ToString("N2");
        }

        protected void btnSearch_Click(object sender, EventArgs e) { Bind(txtSearch.Text.Trim()); }
        protected void btnExport_Click(object sender, EventArgs e)
        {
            ExcelHelper.ExportToExcel(Response, MastersDAL.GetOpex(txtSearch.Text.Trim()),
                "OPEX_Master_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }
        private static decimal Dec(DataRow r, string c) { decimal v; return decimal.TryParse(r[c] == DBNull.Value ? null : r[c].ToString(), out v) ? v : 0m; }
    }
}
