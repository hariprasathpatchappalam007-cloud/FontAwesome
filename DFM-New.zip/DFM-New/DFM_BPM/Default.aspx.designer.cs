// Auto-generated designer file for Default.aspx
namespace DFM_BPM
{
    public partial class DefaultPage
    {
        protected global::System.Web.UI.WebControls.Literal  litProjects;
        protected global::System.Web.UI.WebControls.Literal  litPET;
        protected global::System.Web.UI.WebControls.Literal  litLPO;
        protected global::System.Web.UI.WebControls.Literal  litInvoice;
        protected global::System.Web.UI.WebControls.Literal  litCapexBudget;
        protected global::System.Web.UI.WebControls.Literal  litOpexBudget;
        protected global::System.Web.UI.WebControls.GridView  gvMyPet;
    }
}
