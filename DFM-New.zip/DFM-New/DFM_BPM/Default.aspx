<%@ Page Title="Home" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="Default.aspx.cs" Inherits="DFM_BPM.DefaultPage" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title"><i class="bi bi-house"></i> Welcome</h1>

    <div class="kpi-row">
        <div class="kpi-card kpi-blue">
            <span class="kpi-icon"><i class="bi bi-folder2-open"></i></span>
            <div><div class="kpi-label">Total Projects</div><div class="kpi-val"><asp:Literal ID="litProjects" runat="server" Text="0" /></div></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="kpi-icon"><i class="bi bi-file-earmark-text"></i></span>
            <div><div class="kpi-label">Total PET</div><div class="kpi-val"><asp:Literal ID="litPET" runat="server" Text="0" /></div></div>
        </div>
        <div class="kpi-card kpi-orange">
            <span class="kpi-icon"><i class="bi bi-cart3"></i></span>
            <div><div class="kpi-label">Total LPO</div><div class="kpi-val"><asp:Literal ID="litLPO" runat="server" Text="0" /></div></div>
        </div>
        <div class="kpi-card kpi-red">
            <span class="kpi-icon"><i class="bi bi-receipt-cutoff"></i></span>
            <div><div class="kpi-label">Total Invoices</div><div class="kpi-val"><asp:Literal ID="litInvoice" runat="server" Text="0" /></div></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="kpi-icon"><i class="bi bi-currency-dollar"></i></span>
            <div><div class="kpi-label">CAPEX Budget (AED)</div><div class="kpi-val"><asp:Literal ID="litCapexBudget" runat="server" Text="0" /></div></div>
        </div>
        <div class="kpi-card kpi-blue">
            <span class="kpi-icon"><i class="bi bi-receipt"></i></span>
            <div><div class="kpi-label">OPEX Budget (AED)</div><div class="kpi-val"><asp:Literal ID="litOpexBudget" runat="server" Text="0" /></div></div>
        </div>
    </div>

    <!-- Quick links -->
    <div class="row">
        <div class="col-md-4">
            <div class="card-panel">
                <div class="card-panel-hdr"><i class="bi bi-file-earmark-text"></i> Quick Actions</div>
                <div class="card-panel-body">
                    <a href="<%= ResolveUrl("~/Forms/PetWorkflow.aspx") %>" class="btn btn-primary btn-block" style="margin-bottom:8px;">
                        <i class="bi bi-plus-circle"></i> New PET Form
                    </a>
                    <a href="<%= ResolveUrl("~/Forms/Dashboard.aspx") %>" class="btn btn-default btn-block" style="margin-bottom:8px;">
                        <i class="bi bi-bar-chart-line"></i> Financial Dashboard
                    </a>
                    <% if (IsAdmin) { %>
                    <a href="<%= ResolveUrl("~/Admin/OracleSync.aspx") %>" class="btn btn-warning btn-block">
                        <i class="bi bi-arrow-repeat"></i> Sync from Oracle
                    </a>
                    <% } %>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card-panel">
                <div class="card-panel-hdr"><i class="bi bi-clock-history"></i> My Recent PET Forms</div>
                <div class="card-panel-body" style="padding:0;">
                    <asp:GridView ID="gvMyPet" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None" EmptyDataText="No PET forms found.">
                        <Columns>
                            <asp:BoundField DataField="PetRefNo"    HeaderText="Ref No" />
                            <asp:BoundField DataField="ProjectID"   HeaderText="Project ID" />
                            <asp:BoundField DataField="Title"       HeaderText="Title" />
                            <asp:BoundField DataField="CapexOpexType" HeaderText="Type" />
                            <asp:BoundField DataField="Status"      HeaderText="Status" />
                            <asp:BoundField DataField="CreatedDate" HeaderText="Created" DataFormatString="{0:dd-MMM-yyyy}" />
                            <asp:TemplateField HeaderText="Action">
                                <ItemTemplate>
                                    <a href='<%= ResolveUrl("~/Forms/PetWorkflow.aspx") %>?id=<%# Eval("PetFormID") %>' class="btn btn-xs btn-primary">Open</a>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
