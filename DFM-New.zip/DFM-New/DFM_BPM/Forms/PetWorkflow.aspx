<%@ Page Title="PET Workflow" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="PetWorkflow.aspx.cs" Inherits="DFM_BPM.Forms.PetWorkflow"
    MaintainScrollPositionOnPostback="true" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet" />
<style>
/* ---- PET Workflow ---- */
.pet-nav-tabs > li.active > a { background:#1a3c5e !important; color:#fff !important; border-color:#1a3c5e !important; }
.pet-nav-tabs > li > a { font-weight:700; font-size:.88em; }

/* Stage stepper */
.stepper { display:flex; gap:0; margin-bottom:18px; }
.step { flex:1; text-align:center; padding:8px 4px; font-size:.78em; font-weight:700;
        background:#f1f5f9; border:1px solid #cbd5e1; color:#64748b; position:relative; }
.step.active { background:#1a3c5e; color:#fff; border-color:#1a3c5e; }
.step.done   { background:#059669; color:#fff; border-color:#059669; }
.step::after { content:'›'; position:absolute; right:-12px; top:50%; transform:translateY(-50%);
                font-size:1.4em; z-index:2; color:#94a3b8; }
.step:last-child::after { display:none; }

/* PET line item grid */
.pet-line-tbl th { background:#1a3c5e; color:#fff; padding:6px 8px; font-size:.78em; white-space:nowrap; }
.pet-line-tbl td { padding:4px 6px; border:1px solid #e2e8f0; vertical-align:middle; font-size:.82em; }
.pet-line-tbl .xcl { border:1px solid transparent; background:transparent; width:100%; padding:2px 4px;
                      font-family:inherit; font-size:inherit; }
.pet-line-tbl .xcl:focus { border-color:#2563eb; background:#eff6ff; outline:2px solid #93c5fd; border-radius:3px; }
.pet-line-tbl .num { text-align:right; }
.total-bar { background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px; padding:8px 14px;
              display:flex; gap:20px; font-size:.82em; font-weight:700; margin-top:8px; }
.total-bar span { color:#64748b; } .total-bar strong { color:#1a3c5e; }

/* Approval decision panel */
.decision-panel { background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:18px; }
.decision-btns  { display:flex; gap:8px; flex-wrap:wrap; margin-top:12px; }

/* BPM hierarchy */
.hier-table th { background:#1a3c5e; color:#fff; padding:6px 8px; font-size:.78em; }
.hier-table td { padding:5px 8px; font-size:.82em; border:1px solid #e2e8f0; }
.hier-l1 { font-weight:800; color:#1a3c5e; }
.hier-l2 { padding-left:18px; color:#2563eb; }
.hier-l3 { padding-left:36px; color:#059669; }
.hier-l4 { padding-left:54px; color:#9333ea; }
.hier-collapse { cursor:pointer; color:#94a3b8; font-size:.85em; margin-right:4px; }

/* Amount summary panels */
.amt-panel { background:linear-gradient(135deg,#dbeafe,#eff6ff); border:1px solid #93c5fd;
              border-radius:8px; padding:12px; margin-bottom:10px; }
.amt-panel.opex-panel { background:linear-gradient(135deg,#d1fae5,#ecfdf5); border-color:#6ee7b7; }
.amt-panel-title { font-size:.75em; font-weight:700; text-transform:uppercase; letter-spacing:.3px; color:#64748b; margin-bottom:6px; }
.amt-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:6px; }
.amt-cell-label { font-size:.7em; color:#64748b; }
.amt-cell-val   { font-size:.88em; font-weight:700; color:#1e293b; }

/* Budget source card */
.budget-src-card { background:#f0f9ff; border:1px solid #bae6fd; border-radius:8px; padding:12px; margin-top:8px; }
</style>
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
<h1 class="page-title"><i class="bi bi-file-earmark-text"></i> PET Workflow
    <% if (!string.IsNullOrEmpty(PetRefNo)) { %>
        &nbsp;<span style="font-size:.6em;color:#2563eb;"><%: PetRefNo %></span>
    <% } %>
</h1>

<!-- Stage stepper -->
<div class="stepper">
    <div class="step <%= StepClass(1) %>"><i class="bi bi-file-earmark-plus"></i> 1. PET</div>
    <div class="step <%= StepClass(2) %>"><i class="bi bi-folder2-open"></i> 2. Project Details</div>
    <div class="step <%= StepClass(3) %>"><i class="bi bi-check2-circle"></i> 3. PET Approval</div>
    <div class="step <%= StepClass(4) %>"><i class="bi bi-diagram-3"></i> 4. BPM CAM</div>
</div>

<asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

<asp:HiddenField ID="hfPetFormId" runat="server" Value="0" />

<!-- TABS -->
<ul class="nav nav-tabs pet-nav-tabs" role="tablist">
    <li class="<%= TabActive("pet") %>">      <a href="#tabPet"      data-toggle="tab"><i class="bi bi-file-earmark-text"></i> PET</a></li>
    <li class="<%= TabActive("project") %>">  <a href="#tabProject"  data-toggle="tab"><i class="bi bi-folder2-open"></i> Project Details</a></li>
    <li class="<%= TabActive("approval") %>"> <a href="#tabApproval" data-toggle="tab"><i class="bi bi-check2-circle"></i> PET Approval</a></li>
    <li class="<%= TabActive("bpm") %>">      <a href="#tabBpm"      data-toggle="tab"><i class="bi bi-diagram-3"></i> BPM CAM</a></li>
</ul>

<div class="tab-content" style="padding-top:14px;">

    <!-- ================================================================
         TAB 1: PET FORM
         ================================================================ -->
    <div class="tab-pane <%= TabPane("pet") %>" id="tabPet">

        <!-- Header fields -->
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-pencil-square"></i> PET Header</div>
            <div class="card-panel-body">
                <div class="form-grid-4">
                    <div class="form-group">
                        <label>Project *</label>
                        <asp:DropDownList ID="ddlProject" runat="server" CssClass="form-control"
                            AutoPostBack="true" OnSelectedIndexChanged="ddlProject_Changed"
                            Enabled="<%# IsEditable %>" />
                    </div>
                    <div class="form-group">
                        <label>Type *</label>
                        <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control"
                            AutoPostBack="true" OnSelectedIndexChanged="ddlType_Changed"
                            Enabled="<%# IsEditable %>">
                            <asp:ListItem Value="">-- Select --</asp:ListItem>
                            <asp:ListItem Value="CAPEX">CAPEX</asp:ListItem>
                            <asp:ListItem Value="OPEX">OPEX</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                    <div class="form-group">
                        <label>Budget Source</label>
                        <asp:DropDownList ID="ddlBudgetSource" runat="server" CssClass="form-control"
                            Enabled="<%# IsEditable %>" />
                    </div>
                    <div class="form-group">
                        <label>Reviewer (optional)</label>
                        <asp:DropDownList ID="ddlReviewer" runat="server" CssClass="form-control"
                            Enabled="<%# IsEditable %>">
                            <asp:ListItem Value="">-- Skip reviewer --</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                    <div class="form-group">
                        <label>Approver *</label>
                        <asp:DropDownList ID="ddlApprover" runat="server" CssClass="form-control"
                            Enabled="<%# IsEditable %>" />
                    </div>
                    <div class="form-group col-span-3">
                        <label>Title / Subject *</label>
                        <asp:TextBox ID="txtTitle" runat="server" CssClass="form-control"
                            Enabled="<%# IsEditable %>" />
                    </div>
                </div>

                <!-- Budget source info panel (loaded by postback) -->
                <asp:Panel ID="pnlBudgetInfo" runat="server" Visible="false">
                    <div id="budgetInfoPanel"></div>
                    <asp:PlaceHolder ID="phBudgetInfo" runat="server" />
                </asp:Panel>

                <!-- Save header -->
                <% if (IsEditable) { %>
                <div style="margin-top:10px;">
                    <asp:Button ID="btnSaveHeader" runat="server" CssClass="btn btn-primary"
                        Text="Save Header" OnClick="btnSaveHeader_Click" />
                </div>
                <% } %>
            </div>
        </div>

        <!-- Budget amounts (shown when CAPEX/OPEX selected) -->
        <asp:Panel ID="pnlCapexAmt" runat="server" Visible="false">
            <div class="amt-panel">
                <div class="amt-panel-title"><i class="bi bi-currency-dollar"></i> CAPEX Budget Summary</div>
                <div class="amt-grid">
                    <div><div class="amt-cell-label">Budgeted</div><div class="amt-cell-val"><asp:Literal ID="litCapexBudget" runat="server" Text="0" /></div></div>
                    <div><div class="amt-cell-label">Utilized</div><div class="amt-cell-val"><asp:Literal ID="litCapexUtil" runat="server" Text="0" /></div></div>
                    <div><div class="amt-cell-label">BPM Locked</div><div class="amt-cell-val"><asp:Literal ID="litCapexLocked" runat="server" Text="0" /></div></div>
                    <div><div class="amt-cell-label">Available</div><div class="amt-cell-val"><asp:Literal ID="litCapexAvail" runat="server" Text="0" /></div></div>
                    <div><div class="amt-cell-label">GL Numbers</div><div class="amt-cell-val"><asp:Literal ID="litCapexGL" runat="server" /></div></div>
                </div>
            </div>
        </asp:Panel>

        <asp:Panel ID="pnlOpexAmt" runat="server" Visible="false">
            <div class="amt-panel opex-panel">
                <div class="amt-panel-title"><i class="bi bi-receipt"></i> OPEX Budget Summary</div>
                <div class="amt-grid">
                    <div><div class="amt-cell-label">Budgeted</div><div class="amt-cell-val"><asp:Literal ID="litOpexBudget" runat="server" Text="0" /></div></div>
                    <div><div class="amt-cell-label">Utilized</div><div class="amt-cell-val"><asp:Literal ID="litOpexUtil" runat="server" Text="0" /></div></div>
                    <div><div class="amt-cell-label">BPM Locked</div><div class="amt-cell-val"><asp:Literal ID="litOpexLocked" runat="server" Text="0" /></div></div>
                    <div><div class="amt-cell-label">Available</div><div class="amt-cell-val"><asp:Literal ID="litOpexAvail" runat="server" Text="0" /></div></div>
                    <div><div class="amt-cell-label">Contracts</div><div class="amt-cell-val"><asp:Literal ID="litOpexContracts" runat="server" /></div></div>
                </div>
            </div>
        </asp:Panel>

        <!-- PET Line Items -->
        <asp:Panel ID="pnlLines" runat="server" Visible="false">
        <div class="card-panel">
            <div class="card-panel-hdr">
                <i class="bi bi-list-ul"></i> PET Line Items
                <% if (IsEditable) { %>
                <asp:LinkButton ID="btnAddLine" runat="server" CssClass="btn btn-xs btn-success" style="margin-left:auto;"
                    OnClick="btnAddLine_Click"><i class="bi bi-plus-circle"></i> Add Line</asp:LinkButton>
                <% } %>
            </div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvLines" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table pet-line-tbl" GridLines="None"
                    OnRowCommand="gvLines_RowCommand"
                    EmptyDataText="No line items. Click 'Add Line' to start.">
                    <Columns>
                        <asp:BoundField DataField="SerialNo"    HeaderText="#"         ItemStyle-Width="30px" />
                        <asp:BoundField DataField="ExpHead"     HeaderText="Head"      ItemStyle-Width="60px" />
                        <asp:BoundField DataField="Topic"       HeaderText="Topic" />
                        <asp:BoundField DataField="VendorName"  HeaderText="Vendor" />
                        <asp:BoundField DataField="CostType"    HeaderText="Cost Type" />
                        <asp:BoundField DataField="Units"       HeaderText="Units"     DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UnitPrice"   HeaderText="Unit Price" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BaseCurrency" HeaderText="CCY" />
                        <asp:BoundField DataField="AmtFCY"      HeaderText="FCY Amt"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AmtLCY"      HeaderText="AED Amt"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="ContingencyPct" HeaderText="Cont.%" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="FinalAmtLCY" HeaderText="Final AED" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="GLNumber"    HeaderText="GL#" />
                        <asp:TemplateField HeaderText="Del" ItemStyle-Width="34px">
                            <ItemTemplate>
                                <asp:LinkButton runat="server" CssClass="btn btn-xs btn-danger"
                                    Visible='<%# IsEditable %>'
                                    CommandName="DelLine" CommandArgument='<%# Eval("LineID") %>'
                                    OnClientClick="return confirm('Delete this line?')">
                                    <i class="bi bi-trash"></i>
                                </asp:LinkButton>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                </asp:GridView>
                <div class="total-bar">
                    <span>Lines: <strong><asp:Literal ID="litLineCount" runat="server" Text="0" /></strong></span>
                    <span>Total AED (before contingency): <strong><asp:Literal ID="litTotalLCY" runat="server" Text="0.00" /></strong></span>
                    <span>Total Final AED: <strong><asp:Literal ID="litTotalFinal" runat="server" Text="0.00" /></strong></span>
                </div>
            </div>
        </div>

        <!-- Add line item form -->
        <asp:Panel ID="pnlAddLine" runat="server" Visible="false">
        <div class="card-panel" style="border-color:#2563eb;">
            <div class="card-panel-hdr" style="background:#dbeafe;color:#1e40af;">
                <i class="bi bi-plus-circle"></i> New Line Item
            </div>
            <div class="card-panel-body">
                <div class="form-grid-4">
                    <div class="form-group">
                        <label>Expenditure Head</label>
                        <asp:DropDownList ID="ddlExpHead" runat="server" CssClass="form-control">
                            <asp:ListItem Value="CAPEX">CAPEX</asp:ListItem>
                            <asp:ListItem Value="OPEX">OPEX</asp:ListItem>
                        </asp:DropDownList>
                    </div>
                    <div class="form-group col-span-2">
                        <label>Topic / Item</label>
                        <asp:TextBox ID="txtLineTopic" runat="server" CssClass="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Vendor</label>
                        <asp:DropDownList ID="ddlLineVendor" runat="server" CssClass="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Cost Type</label>
                        <asp:DropDownList ID="ddlLineCostType" runat="server" CssClass="form-control" />
                    </div>
                    <div class="form-group">
                        <label>GL Number</label>
                        <asp:DropDownList ID="ddlLineGL" runat="server" CssClass="form-control" />
                    </div>
                    <div class="form-group">
                        <label>Currency</label>
                        <asp:DropDownList ID="ddlLineCcy" runat="server" CssClass="form-control"
                            AutoPostBack="true" OnSelectedIndexChanged="ddlLineCcy_Changed" />
                    </div>
                    <div class="form-group">
                        <label>Units</label>
                        <asp:TextBox ID="txtLineUnits" runat="server" CssClass="form-control" Text="1" />
                    </div>
                    <div class="form-group">
                        <label>Unit Price (FCY)</label>
                        <asp:TextBox ID="txtLineUnitPrice" runat="server" CssClass="form-control" Text="0" />
                    </div>
                    <div class="form-group">
                        <label>FCY Amount</label>
                        <asp:TextBox ID="txtLineAmtFCY" runat="server" CssClass="form-control" Text="0" ReadOnly="true" />
                    </div>
                    <div class="form-group">
                        <label>AED Amount</label>
                        <asp:TextBox ID="txtLineAmtLCY" runat="server" CssClass="form-control" Text="0" ReadOnly="true" />
                    </div>
                    <div class="form-group">
                        <label>Contingency %</label>
                        <asp:TextBox ID="txtLineConting" runat="server" CssClass="form-control" Text="0" />
                    </div>
                    <div class="form-group col-span-4">
                        <label>Description</label>
                        <asp:TextBox ID="txtLineDesc" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" />
                    </div>
                </div>
                <asp:Button ID="btnSaveLine" runat="server" CssClass="btn btn-primary" Text="Save Line" OnClick="btnSaveLine_Click" />
                <asp:Button ID="btnCancelLine" runat="server" CssClass="btn btn-default" Text="Cancel" OnClick="btnCancelLine_Click" CausesValidation="false" />
            </div>
        </div>
        </asp:Panel>

        <!-- Submit PET -->
        <% if (IsEditable && CurrentPetFormId > 0) { %>
        <div style="margin-top:14px;padding:14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
            <strong>Ready to Submit?</strong>
            <p style="font-size:.85em;color:#64748b;margin:4px 0 10px;">
                Submitting will send the PET
                <% if (!string.IsNullOrEmpty(ReviewerName)) { %>
                    to reviewer <strong><%: ReviewerName %></strong>
                <% } else { %>
                    directly to approver <strong><%: ApproverName %></strong>
                <% } %>
                for action.
            </p>
            <asp:TextBox ID="txtSubmitComments" runat="server" CssClass="form-control" placeholder="Optional comments..." TextMode="MultiLine" Rows="2" style="margin-bottom:8px;" />
            <asp:Button ID="btnSubmitPet" runat="server" CssClass="btn btn-warning" Text="Submit PET for Approval"
                OnClick="btnSubmitPet_Click"
                OnClientClick="return confirm('Submit this PET for approval?');" />
        </div>
        <% } %>
        </asp:Panel><!-- /pnlLines -->
    </div><!-- /tabPet -->

    <!-- ================================================================
         TAB 2: PROJECT DETAILS
         ================================================================ -->
    <div class="tab-pane <%= TabPane("project") %>" id="tabProject">
        <asp:Panel ID="pnlProjectDetails" runat="server" Visible="false">
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-folder2-open"></i> Project Information</div>
            <div class="card-panel-body">
                <table class="table table-bordered" style="font-size:.88em;">
                    <tr><td class="active" width="20%"><strong>Project ID</strong></td><td><asp:Literal ID="litProjId" runat="server" /></td>
                        <td class="active" width="20%"><strong>Project Name</strong></td><td><asp:Literal ID="litProjName" runat="server" /></td></tr>
                    <tr><td class="active"><strong>Manager</strong></td><td><asp:Literal ID="litProjMgr" runat="server" /></td>
                        <td class="active"><strong>Email</strong></td><td><asp:Literal ID="litProjMgrEmail" runat="server" /></td></tr>
                    <tr><td class="active"><strong>Business Area</strong></td><td><asp:Literal ID="litProjBA" runat="server" /></td>
                        <td class="active"><strong>Status</strong></td><td><asp:Literal ID="litProjStatus" runat="server" /></td></tr>
                    <tr><td class="active"><strong>Start Date</strong></td><td><asp:Literal ID="litProjStart" runat="server" /></td>
                        <td class="active"><strong>End Date</strong></td><td><asp:Literal ID="litProjEnd" runat="server" /></td></tr>
                    <tr><td class="active"><strong>Project Amount</strong></td><td><asp:Literal ID="litProjAmt" runat="server" /></td>
                        <td class="active"><strong>CAPEX ID</strong></td><td><asp:Literal ID="litProjCapex" runat="server" /></td></tr>
                    <tr><td class="active" colspan="1"><strong>Description</strong></td><td colspan="3"><asp:Literal ID="litProjDesc" runat="server" /></td></tr>
                </table>
            </div>
        </div>

        <!-- CAPEX amounts for this project -->
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-currency-dollar"></i> CAPEX Amounts for this Project</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvCapexAmt" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No CAPEX data.">
                    <Columns>
                        <asp:BoundField DataField="ItemID"          HeaderText="CAPEX ID" />
                        <asp:BoundField DataField="ItemDescription"  HeaderText="Description" />
                        <asp:BoundField DataField="BudgetedAmount"   HeaderText="Budget (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"   HeaderText="Utilized (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="LockedAmount"     HeaderText="Locked (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AvailableAmount"  HeaderText="Available (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>

        <!-- OPEX amounts for this project -->
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-receipt"></i> OPEX Amounts for this Project</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvOpexAmt" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No OPEX data.">
                    <Columns>
                        <asp:BoundField DataField="ItemID"          HeaderText="OPEX ID" />
                        <asp:BoundField DataField="ItemDescription"  HeaderText="Description" />
                        <asp:BoundField DataField="BudgetedAmount"   HeaderText="Budget (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"   HeaderText="Utilized (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="LockedAmount"     HeaderText="Locked (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AvailableAmount"  HeaderText="Available (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>

        <!-- GL amounts -->
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-journal-bookmark"></i> GL Amounts for this Project</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvGLAmt" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No GL data.">
                    <Columns>
                        <asp:BoundField DataField="GLNumber"        HeaderText="GL Number" />
                        <asp:BoundField DataField="GLDescription"   HeaderText="Description" />
                        <asp:BoundField DataField="BudgetedAmount"  HeaderText="Budget"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BPMLockedAmount" HeaderText="BPM Lock"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AMSLockedAmount" HeaderText="AMS Lock"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"  HeaderText="Utilized"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BalanceAmount"   HeaderText="Balance"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
        </asp:Panel>

        <asp:Panel ID="pnlNoProject" runat="server">
            <div class="alert-info">Select a Project in the PET tab first.</div>
        </asp:Panel>
    </div><!-- /tabProject -->

    <!-- ================================================================
         TAB 3: PET APPROVAL
         ================================================================ -->
    <div class="tab-pane <%= TabPane("approval") %>" id="tabApproval">
        <asp:Panel ID="pnlApprovalDetails" runat="server">
        <!-- Status summary -->
        <div class="kpi-row">
            <div class="kpi-card kpi-blue"><span class="kpi-icon"><i class="bi bi-person"></i></span>
                <div><div class="kpi-label">Requestor</div><div class="kpi-val"><asp:Literal ID="litApprRequestor" runat="server" Text="-" /></div></div></div>
            <div class="kpi-card kpi-orange"><span class="kpi-icon"><i class="bi bi-person-check"></i></span>
                <div><div class="kpi-label">Reviewer</div><div class="kpi-val"><asp:Literal ID="litApprReviewer" runat="server" Text="-" /></div></div></div>
            <div class="kpi-card kpi-green"><span class="kpi-icon"><i class="bi bi-check2-circle"></i></span>
                <div><div class="kpi-label">Approver</div><div class="kpi-val"><asp:Literal ID="litApprApprover" runat="server" Text="-" /></div></div></div>
            <div class="kpi-card kpi-red"><span class="kpi-icon"><i class="bi bi-flag"></i></span>
                <div><div class="kpi-label">Current Status</div><div class="kpi-val"><asp:Literal ID="litApprStatus" runat="server" Text="-" /></div></div></div>
        </div>

        <!-- Approval action panel (shown to reviewer/approver) -->
        <asp:Panel ID="pnlDecision" runat="server" Visible="false">
        <div class="decision-panel">
            <h4 style="margin:0 0 10px;color:#1a3c5e;"><i class="bi bi-check2-square"></i>
                <asp:Literal ID="litDecisionTitle" runat="server" Text="Your Decision" />
            </h4>
            <div class="form-group">
                <label>Comments</label>
                <asp:TextBox ID="txtDecisionComments" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="3" placeholder="Enter your comments..." />
            </div>
            <div class="decision-btns">
                <asp:Button ID="btnApprove"  runat="server" CssClass="btn btn-success btn-lg" Text="Approve"   OnClick="btnApprove_Click"  OnClientClick="return confirm('Approve this PET?');" />
                <asp:Button ID="btnReject"   runat="server" CssClass="btn btn-danger btn-lg"  Text="Reject"    OnClick="btnReject_Click"   OnClientClick="return confirm('Reject this PET?');" />
                <asp:Button ID="btnSendBack" runat="server" CssClass="btn btn-warning btn-lg" Text="Send Back" OnClick="btnSendBack_Click" OnClientClick="return confirm('Send back to requestor?');" />
            </div>
        </div>
        </asp:Panel>

        <!-- Workflow History -->
        <div class="card-panel" style="margin-top:14px;">
            <div class="card-panel-hdr"><i class="bi bi-clock-history"></i> Workflow History</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvHistory" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No history.">
                    <Columns>
                        <asp:BoundField DataField="ActionDate"  HeaderText="Date"       DataFormatString="{0:dd-MMM-yyyy HH:mm}" />
                        <asp:BoundField DataField="Action"      HeaderText="Action" />
                        <asp:BoundField DataField="ActionBy"    HeaderText="By" />
                        <asp:BoundField DataField="FromStatus"  HeaderText="From" />
                        <asp:BoundField DataField="ToStatus"    HeaderText="To" />
                        <asp:BoundField DataField="Comments"    HeaderText="Comments" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
        </asp:Panel>
    </div><!-- /tabApproval -->

    <!-- ================================================================
         TAB 4: BPM CAM HIERARCHY
         ================================================================ -->
    <div class="tab-pane <%= TabPane("bpm") %>" id="tabBpm">
        <div class="filter-row">
            <div class="form-group" style="flex:2;">
                <label>Project</label>
                <asp:DropDownList ID="ddlBpmProject" runat="server" CssClass="form-control" />
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <asp:Button ID="btnLoadHierarchy" runat="server" CssClass="btn btn-primary"
                    Text="Load Hierarchy" OnClick="btnLoadHierarchy_Click" />
            </div>
        </div>

        <!-- Expandable Traceability Section (like capex_opex_contract_tracker_v5) -->
        <asp:Panel ID="pnlHierarchy" runat="server" Visible="false">

        <!-- Project Level 1 -->
        <div class="tracker-section">
            <div class="tracker-hdr">
                <span><i class="bi bi-folder2-open"></i> Project: <asp:Literal ID="litHierProjId" runat="server" /></span>
                <i class="bi bi-chevron-down"></i>
            </div>
            <div class="tracker-body show">
                <table class="table table-bordered" style="font-size:.84em;margin-bottom:10px;">
                    <tr><td width="18%"><strong>Name</strong></td><td><asp:Literal ID="litHierProjName" runat="server" /></td>
                        <td width="18%"><strong>Manager</strong></td><td><asp:Literal ID="litHierMgr" runat="server" /></td></tr>
                    <tr><td><strong>Amount (AED)</strong></td><td><asp:Literal ID="litHierProjAmt" runat="server" /></td>
                        <td><strong>Status</strong></td><td><asp:Literal ID="litHierProjStatus" runat="server" /></td></tr>
                </table>

                <!-- Level 2: PET -->
                <div class="tracker-sub-hdr">
                    <span><i class="bi bi-file-earmark-text"></i> PET (Level 2)</span>
                    <i class="bi bi-chevron-down"></i>
                </div>
                <div class="tracker-sub-body show">
                    <asp:GridView ID="gvHierPet" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None" EmptyDataText="No PET data.">
                        <Columns>
                            <asp:BoundField DataField="PETReferenceNo"  HeaderText="PET Ref" />
                            <asp:BoundField DataField="Description"      HeaderText="Description" />
                            <asp:BoundField DataField="PETApprovedAmt"  HeaderText="Approved (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="BPMLockedAmount" HeaderText="BPM Locked"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="Utilized"         HeaderText="Utilized"       DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="Balance"          HeaderText="Balance"        DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        </Columns>
                    </asp:GridView>
                </div>

                <!-- Level 2: Contracts (Memo) -->
                <div class="tracker-sub-hdr" style="margin-top:8px;">
                    <span><i class="bi bi-file-earmark-richtext"></i> Contracts/Memo (Level 2)</span>
                    <i class="bi bi-chevron-down"></i>
                </div>
                <div class="tracker-sub-body show">
                    <asp:GridView ID="gvHierContract" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None" EmptyDataText="No contract data.">
                        <Columns>
                            <asp:BoundField DataField="ContractNo"      HeaderText="Contract No" />
                            <asp:BoundField DataField="Reference"       HeaderText="Reference" />
                            <asp:BoundField DataField="VendorName"      HeaderText="Vendor" />
                            <asp:BoundField DataField="LCAmount"        HeaderText="LC Amount"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="ContractBalance" HeaderText="Balance"     DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="ContractStatus"  HeaderText="Status" />
                        </Columns>
                    </asp:GridView>
                </div>

                <!-- Level 3: LPO -->
                <div class="tracker-sub-hdr" style="margin-top:8px;">
                    <span><i class="bi bi-cart3"></i> LPO (Level 3)</span>
                    <i class="bi bi-chevron-down"></i>
                </div>
                <div class="tracker-sub-body show">
                    <asp:GridView ID="gvHierLPO" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None" EmptyDataText="No LPO data.">
                        <Columns>
                            <asp:BoundField DataField="LPONo"           HeaderText="LPO No" />
                            <asp:BoundField DataField="LPODesc"         HeaderText="Description" />
                            <asp:BoundField DataField="VendorName"      HeaderText="Vendor" />
                            <asp:BoundField DataField="LCAmount"        HeaderText="LC Amount"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="BudgetAmount"    HeaderText="Budget"     DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="AvailableBalance" HeaderText="Available" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="LPOStatus"       HeaderText="Status" />
                            <asp:BoundField DataField="GLNumber"        HeaderText="GL#" />
                        </Columns>
                    </asp:GridView>
                </div>

                <!-- Level 4: Invoice -->
                <div class="tracker-sub-hdr" style="margin-top:8px;">
                    <span><i class="bi bi-receipt-cutoff"></i> Invoices (Level 4)</span>
                    <i class="bi bi-chevron-down"></i>
                </div>
                <div class="tracker-sub-body show">
                    <asp:GridView ID="gvHierInvoice" runat="server" AutoGenerateColumns="false"
                        CssClass="dfm-table" GridLines="None" EmptyDataText="No invoice data.">
                        <Columns>
                            <asp:BoundField DataField="InvoiceNumber"   HeaderText="Invoice No" />
                            <asp:BoundField DataField="InvoiceType"     HeaderText="Type" />
                            <asp:BoundField DataField="VendorName"      HeaderText="Vendor" />
                            <asp:BoundField DataField="LCAmount"        HeaderText="LC Amount" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                            <asp:BoundField DataField="AMSInvoiceStatus" HeaderText="Status" />
                            <asp:BoundField DataField="InvoiceDate"     HeaderText="Invoice Date" DataFormatString="{0:dd-MMM-yyyy}" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div><!-- /tracker-body -->
        </div><!-- /tracker-section -->
        </asp:Panel><!-- /pnlHierarchy -->

        <asp:Panel ID="pnlNoBpm" runat="server">
            <div class="alert-info">Select a project and click "Load Hierarchy" to view the BPM CAM hierarchy.</div>
        </asp:Panel>
    </div><!-- /tabBpm -->

</div><!-- /tab-content -->

<script>
$(function() {
    // Currency auto-calc
    var rates = <%= CurrencyRatesJson %>;
    function calcAmts() {
        var units = parseFloat($('#<%: txtLineUnits.ClientID %>').val()) || 0;
        var price = parseFloat($('#<%: txtLineUnitPrice.ClientID %>').val()) || 0;
        var ccy   = $('#<%: ddlLineCcy.ClientID %>').val();
        var rate  = rates[ccy] || 1;
        var fcy   = units * price;
        var lcy   = fcy * rate;
        $('#<%: txtLineAmtFCY.ClientID %>').val(fcy.toFixed(2));
        $('#<%: txtLineAmtLCY.ClientID %>').val(lcy.toFixed(2));
    }
    $('#<%: txtLineUnits.ClientID %>, #<%: txtLineUnitPrice.ClientID %>').on('input', calcAmts);
    // Tracker toggles already in Site.Master
});
</script>
</asp:Content>
