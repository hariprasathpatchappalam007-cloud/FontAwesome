using System;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM.Forms
{
    public partial class PetWorkflow : Page
    {
        // ===== State =====
        protected int CurrentPetFormId
        {
            get { int v; return int.TryParse(hfPetFormId.Value, out v) ? v : 0; }
            set { hfPetFormId.Value = value.ToString(); }
        }

        protected string PetRefNo    { get; private set; }
        protected string ReviewerName { get; private set; }
        protected string ApproverName { get; private set; }
        protected bool   IsEditable   { get; private set; }
        protected string CurrencyRatesJson { get; private set; }

        private string CurrentStatus { get { return ViewState["petStatus"] as string ?? "Draft"; } set { ViewState["petStatus"] = value; } }
        private string ActiveTab     { get { return ViewState["activeTab"] as string ?? "pet"; }  set { ViewState["activeTab"] = value; } }

        protected string TabActive(string tab) { return ActiveTab == tab ? "active" : ""; }
        protected string TabPane(string tab)   { return ActiveTab == tab ? "active" : ""; }

        protected string StepClass(int step)
        {
            int cur = GetCurrentStep();
            if (step < cur)  return "done";
            if (step == cur) return "active";
            return "";
        }

        private int GetCurrentStep()
        {
            switch (CurrentStatus)
            {
                case "Draft":           return 1;
                case "PendingReview":   return 3;
                case "SentBack":        return 1;
                case "PendingApproval": return 3;
                case "Approved":        return 4;
                case "Rejected":        return 3;
                default:                return 2;
            }
        }

        // ===== Lifecycle =====
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDropdowns();
                LoadCurrencies();

                int qid;
                if (int.TryParse(Request.QueryString["id"], out qid) && qid > 0)
                {
                    CurrentPetFormId = qid;
                    LoadForm(qid);
                }
                else
                {
                    IsEditable = true;
                    pnlLines.Visible         = false;
                    pnlProjectDetails.Visible = false;
                    pnlNoProject.Visible      = true;
                    pnlNoBpm.Visible          = true;
                    pnlHierarchy.Visible      = false;
                    pnlDecision.Visible       = false;
                }
            }
            else
            {
                // Re-apply editable state on postback
                if (CurrentPetFormId > 0)
                {
                    DataRow f = WorkflowDAL.GetPetForm(CurrentPetFormId);
                    if (f != null)
                    {
                        CurrentStatus = f["Status"].ToString();
                        IsEditable = CurrentStatus == "Draft" || CurrentStatus == "SentBack";
                        IsEditable = IsEditable && string.Equals(f["CreatedBy"].ToString(), AuthHelper.CurrentUser, StringComparison.OrdinalIgnoreCase);
                    }
                }
                LoadCurrencies();
            }
        }

        // ===== Dropdowns =====
        private void LoadDropdowns()
        {
            // Projects
            DataTable dtP = MastersDAL.GetProjectDropdown();
            ddlProject.DataSource     = dtP;
            ddlProject.DataTextField  = "Name";
            ddlProject.DataValueField = "ID";
            ddlProject.DataBind();
            ddlProject.Items.Insert(0, new ListItem("-- Select Project --", ""));

            // Reviewers
            DataTable dtRev = MastersDAL.GetReviewers();
            ddlReviewer.DataSource     = dtRev;
            ddlReviewer.DataTextField  = "FullName";
            ddlReviewer.DataValueField = "Username";
            ddlReviewer.DataBind();
            ddlReviewer.Items.Insert(0, new ListItem("-- Skip reviewer --", ""));

            // Approvers
            DataTable dtApp = MastersDAL.GetApprovers();
            ddlApprover.DataSource     = dtApp;
            ddlApprover.DataTextField  = "FullName";
            ddlApprover.DataValueField = "Username";
            ddlApprover.DataBind();
            ddlApprover.Items.Insert(0, new ListItem("-- Select Approver --", ""));

            // BPM project for hierarchy tab
            DataTable dtBP = MastersDAL.GetProjectDropdown();
            ddlBpmProject.DataSource     = dtBP;
            ddlBpmProject.DataTextField  = "Name";
            ddlBpmProject.DataValueField = "ID";
            ddlBpmProject.DataBind();
            ddlBpmProject.Items.Insert(0, new ListItem("-- Select Project --", ""));
        }

        private void LoadCurrencies()
        {
            DataTable dt = MastersDAL.GetCurrencies();
            var sb = new StringBuilder("{");
            foreach (DataRow r in dt.Rows)
            {
                if (sb.Length > 1) sb.Append(",");
                sb.AppendFormat("\"{0}\":{1}", r["Code"], r["RateToLocal"].ToString().Replace(",", "."));
            }
            sb.Append("}");
            CurrencyRatesJson = sb.ToString();

            // Line item currency dropdown
            ddlLineCcy.DataSource     = dt;
            ddlLineCcy.DataTextField  = "Code";
            ddlLineCcy.DataValueField = "Code";
            ddlLineCcy.DataBind();

            // Cost types
            DataTable ct = MastersDAL.GetCostTypes();
            ddlLineCostType.DataSource     = ct;
            ddlLineCostType.DataTextField  = "Category";
            ddlLineCostType.DataValueField = "Category";
            ddlLineCostType.DataBind();
            ddlLineCostType.Items.Insert(0, new ListItem("-- Select --", ""));

            // Vendors
            DataTable vd = MastersDAL.GetVendorDropdown();
            ddlLineVendor.DataSource     = vd;
            ddlLineVendor.DataTextField  = "Name";
            ddlLineVendor.DataValueField = "ID";
            ddlLineVendor.DataBind();
            ddlLineVendor.Items.Insert(0, new ListItem("-- Select --", ""));

            // GL numbers
            DataTable gl = MastersDAL.GetGLDropdown();
            ddlLineGL.DataSource     = gl;
            ddlLineGL.DataTextField  = "Name";
            ddlLineGL.DataValueField = "ID";
            ddlLineGL.DataBind();
            ddlLineGL.Items.Insert(0, new ListItem("-- None --", ""));
        }

        // ===== Load existing form =====
        private void LoadForm(int id)
        {
            DataRow f = WorkflowDAL.GetPetForm(id);
            if (f == null) { Response.Redirect("~/Forms/PetWorkflow.aspx"); return; }

            CurrentStatus = f["Status"].ToString();
            PetRefNo      = f["PetRefNo"] == DBNull.Value ? null : f["PetRefNo"].ToString();
            ReviewerName  = f["ReviewerUsername"] == DBNull.Value ? null : f["ReviewerUsername"].ToString();
            ApproverName  = f["ApproverUsername"] == DBNull.Value ? null : f["ApproverUsername"].ToString();
            IsEditable    = (CurrentStatus == "Draft" || CurrentStatus == "SentBack")
                          && string.Equals(f["CreatedBy"].ToString(), AuthHelper.CurrentUser, StringComparison.OrdinalIgnoreCase);

            // Bind form controls
            SetDdl(ddlProject,      f, "ProjectID");
            SetDdl(ddlType,         f, "CapexOpexType");
            SetDdl(ddlReviewer,     f, "ReviewerUsername");
            SetDdl(ddlApprover,     f, "ApproverUsername");
            txtTitle.Text = f["Title"] == DBNull.Value ? "" : f["Title"].ToString();

            // Load budget source dropdown for the type
            LoadBudgetSourceDropdown(f["CapexOpexType"] == DBNull.Value ? null : f["CapexOpexType"].ToString());
            SetDdl(ddlBudgetSource, f, "BudgetSourceID");

            // Show budget amounts
            ShowBudgetAmounts(
                f["CapexOpexType"]  == DBNull.Value ? null : f["CapexOpexType"].ToString(),
                f["BudgetSourceID"] == DBNull.Value ? null : f["BudgetSourceID"].ToString());

            // Lines
            pnlLines.Visible = true;
            BindLines(id);

            // Project details tab
            LoadProjectDetails(f["ProjectID"] == DBNull.Value ? null : f["ProjectID"].ToString());

            // Approval tab
            LoadApprovalTab(f);

            // BPM project preselect
            SetDdl(ddlBpmProject, f, "ProjectID");
        }

        private void LoadProjectDetails(string projectId)
        {
            if (string.IsNullOrEmpty(projectId)) { pnlProjectDetails.Visible = false; pnlNoProject.Visible = true; return; }

            pnlNoProject.Visible      = false;
            pnlProjectDetails.Visible = true;

            DataRow p = MastersDAL.GetProjectById(projectId);
            if (p != null)
            {
                litProjId.Text     = Server.HtmlEncode(Convert.ToString(p["ProjectID"]));
                litProjName.Text   = Server.HtmlEncode(Convert.ToString(p["ProjectName"]));
                litProjMgr.Text    = Server.HtmlEncode(Convert.ToString(p["ProjectManager"]));
                litProjMgrEmail.Text = Server.HtmlEncode(Convert.ToString(p["ProjectManagerEmail"]));
                litProjBA.Text     = Server.HtmlEncode(Convert.ToString(p["BusinessArea"]));
                litProjStatus.Text = Server.HtmlEncode(Convert.ToString(p["ProjectStatus"]));
                litProjStart.Text  = p["ProjectStartDate"] == DBNull.Value ? "" : Convert.ToDateTime(p["ProjectStartDate"]).ToString("dd-MMM-yyyy");
                litProjEnd.Text    = p["ProjectEndDate"]   == DBNull.Value ? "" : Convert.ToDateTime(p["ProjectEndDate"]).ToString("dd-MMM-yyyy");
                litProjAmt.Text    = p["ProjectAmount"] == DBNull.Value ? "0" : Convert.ToDecimal(p["ProjectAmount"]).ToString("N2");
                litProjCapex.Text  = Server.HtmlEncode(Convert.ToString(p["CapexID"]));
                litProjDesc.Text   = Server.HtmlEncode(Convert.ToString(p["ProjectDescription"]));
            }

            gvCapexAmt.DataSource = WorkflowDAL.GetCapexAmountsForProject(projectId);
            gvCapexAmt.DataBind();
            gvOpexAmt.DataSource  = WorkflowDAL.GetOpexAmountsForProject(projectId);
            gvOpexAmt.DataBind();
            gvGLAmt.DataSource    = WorkflowDAL.GetGLAmountsForProject(projectId);
            gvGLAmt.DataBind();
        }

        private void LoadApprovalTab(DataRow f)
        {
            string status       = f["Status"] == DBNull.Value ? "" : f["Status"].ToString();
            string reviewer     = f["ReviewerUsername"] == DBNull.Value ? "N/A" : f["ReviewerUsername"].ToString();
            string approver     = f["ApproverUsername"] == DBNull.Value ? null : f["ApproverUsername"].ToString();
            string requestor    = f["CreatedBy"] == DBNull.Value ? "" : f["CreatedBy"].ToString();

            litApprRequestor.Text = Server.HtmlEncode(requestor);
            litApprReviewer.Text  = Server.HtmlEncode(reviewer);
            litApprApprover.Text  = Server.HtmlEncode(approver);
            litApprStatus.Text    = Server.HtmlEncode(status);

            // Show decision panel if this user must act
            bool isReviewer  = string.Equals(reviewer, AuthHelper.CurrentUser, StringComparison.OrdinalIgnoreCase);
            bool isApprover  = string.Equals(approver, AuthHelper.CurrentUser, StringComparison.OrdinalIgnoreCase);

            bool showDecision = (status == "PendingReview" && isReviewer)
                             || (status == "PendingApproval" && isApprover);

            pnlDecision.Visible = showDecision;
            if (showDecision)
            {
                litDecisionTitle.Text = isReviewer ? "Review Decision" : "Approval Decision";
                // For reviewer, hide Approve button (they use Recommend or SendBack)
                btnApprove.Text  = isReviewer ? "Recommend (Send to Approver)" : "Approve";
                btnReject.Visible = isApprover;
            }

            // History
            gvHistory.DataSource = WorkflowDAL.GetHistory(CurrentPetFormId);
            gvHistory.DataBind();
        }

        // ===== Budget source dropdown =====
        private void LoadBudgetSourceDropdown(string type)
        {
            ddlBudgetSource.Items.Clear();
            ddlBudgetSource.Items.Add(new ListItem("-- Select --", ""));
            if (type == "CAPEX")
            {
                foreach (DataRow r in MastersDAL.GetCapexDropdown().Rows)
                    ddlBudgetSource.Items.Add(new ListItem(r["Name"].ToString(), r["ID"].ToString()));
            }
            else if (type == "OPEX")
            {
                foreach (DataRow r in MastersDAL.GetOpexDropdown().Rows)
                    ddlBudgetSource.Items.Add(new ListItem(r["Name"].ToString(), r["ID"].ToString()));
            }
        }

        private void ShowBudgetAmounts(string type, string sourceId)
        {
            pnlCapexAmt.Visible = false;
            pnlOpexAmt.Visible  = false;

            if (type == "CAPEX" && !string.IsNullOrEmpty(sourceId))
            {
                DataRow r = MastersDAL.GetCapexById(sourceId);
                if (r != null)
                {
                    litCapexBudget.Text    = Dec(r, "BudgetedAmount").ToString("N2");
                    litCapexUtil.Text      = Dec(r, "UtilizedAmount").ToString("N2");
                    litCapexLocked.Text    = Dec(r, "LockedAmount").ToString("N2");
                    litCapexAvail.Text     = Dec(r, "AvailableAmount").ToString("N2");
                    litCapexGL.Text        = Server.HtmlEncode(Convert.ToString(r["GLNumbers"]));
                    pnlCapexAmt.Visible    = true;
                }
            }
            else if (type == "OPEX" && !string.IsNullOrEmpty(sourceId))
            {
                DataRow r = MastersDAL.GetOpexById(sourceId);
                if (r != null)
                {
                    litOpexBudget.Text    = Dec(r, "BudgetedAmount").ToString("N2");
                    litOpexUtil.Text      = Dec(r, "UtilizedAmount").ToString("N2");
                    litOpexLocked.Text    = Dec(r, "LockedAmount").ToString("N2");
                    litOpexAvail.Text     = Dec(r, "AvailableAmount").ToString("N2");
                    litOpexContracts.Text = Server.HtmlEncode(Convert.ToString(r["Contracts"]));
                    pnlOpexAmt.Visible    = true;
                }
            }
        }

        // ===== PET Lines =====
        private void BindLines(int id)
        {
            DataTable dt = WorkflowDAL.GetPetLines(id);
            gvLines.DataSource = dt;
            gvLines.DataBind();
            litLineCount.Text = dt.Rows.Count.ToString();
            decimal totLCY = 0, totFinal = 0;
            foreach (DataRow r in dt.Rows) { totLCY += Dec(r,"AmtLCY"); totFinal += Dec(r,"FinalAmtLCY"); }
            litTotalLCY.Text   = totLCY.ToString("N2");
            litTotalFinal.Text = totFinal.ToString("N2");
        }

        // ===== Event handlers =====
        protected void ddlProject_Changed(object sender, EventArgs e)
        {
            LoadProjectDetails(ddlProject.SelectedValue);
            SetDdl(ddlBpmProject, ddlProject.SelectedValue);
        }

        protected void ddlType_Changed(object sender, EventArgs e)
        {
            LoadBudgetSourceDropdown(ddlType.SelectedValue);
        }

        protected void ddlLineCcy_Changed(object sender, EventArgs e) { /* recalc done in JS */ }

        protected void btnSaveHeader_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ddlProject.SelectedValue) || string.IsNullOrEmpty(ddlApprover.SelectedValue))
            {
                ShowMsg("Project and Approver are required."); return;
            }

            if (CurrentPetFormId == 0)
            {
                int newId = WorkflowDAL.CreatePetForm(
                    ddlProject.SelectedValue, ddlType.SelectedValue,
                    ddlBudgetSource.SelectedValue == "" ? null : ddlBudgetSource.SelectedValue,
                    txtTitle.Text.Trim(), "", ddlReviewer.SelectedValue == "" ? null : ddlReviewer.SelectedValue,
                    ddlApprover.SelectedValue, AuthHelper.CurrentUser);
                CurrentPetFormId = newId;
                Response.Redirect("~/Forms/PetWorkflow.aspx?id=" + newId);
                return;
            }
            else
            {
                WorkflowDAL.UpdatePetForm(CurrentPetFormId,
                    ddlProject.SelectedValue, ddlType.SelectedValue,
                    ddlBudgetSource.SelectedValue == "" ? null : ddlBudgetSource.SelectedValue,
                    txtTitle.Text.Trim(), "",
                    ddlReviewer.SelectedValue == "" ? null : ddlReviewer.SelectedValue,
                    ddlApprover.SelectedValue, AuthHelper.CurrentUser);
            }

            ShowMsg("Header saved.");
            pnlLines.Visible = true;
            ShowBudgetAmounts(ddlType.SelectedValue, ddlBudgetSource.SelectedValue);
            BindLines(CurrentPetFormId);
            LoadProjectDetails(ddlProject.SelectedValue);
        }

        protected void btnAddLine_Click(object sender, EventArgs e)
        {
            pnlAddLine.Visible = true;
        }

        protected void btnCancelLine_Click(object sender, EventArgs e)
        {
            pnlAddLine.Visible = false;
        }

        protected void btnSaveLine_Click(object sender, EventArgs e)
        {
            if (CurrentPetFormId == 0) { ShowMsg("Save the header first."); return; }
            decimal units = Dec(txtLineUnits.Text);
            decimal price = Dec(txtLineUnitPrice.Text);
            decimal fcy   = units * price;
            decimal rate  = GetRate(ddlLineCcy.SelectedValue);
            decimal lcy   = fcy * rate;
            decimal cont  = Dec(txtLineConting.Text);
            decimal final = lcy * (1 + cont / 100);

            int nextSerial = Convert.ToInt32(Db.Scalar(
                "SELECT ISNULL(MAX(SerialNo),0)+1 FROM dbo.PetLineItem WHERE PetFormID=@f",
                Db.P("@f", CurrentPetFormId)));

            WorkflowDAL.SavePetLine(
                CurrentPetFormId, nextSerial,
                "", ddlExpHead.SelectedValue,
                txtLineTopic.Text.Trim(), ddlLineVendor.SelectedValue,
                txtLineDesc.Text.Trim(), ddlLineCostType.SelectedValue,
                units, price, ddlLineCcy.SelectedValue,
                fcy, lcy, cont, final,
                ddlLineGL.SelectedValue == "" ? null : ddlLineGL.SelectedValue,
                "", AuthHelper.CurrentUser);

            pnlAddLine.Visible = false;
            BindLines(CurrentPetFormId);
        }

        protected void gvLines_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DelLine" && IsEditable)
            {
                WorkflowDAL.DeletePetLine(Convert.ToInt32(e.CommandArgument));
                BindLines(CurrentPetFormId);
            }
        }

        protected void btnSubmitPet_Click(object sender, EventArgs e)
        {
            if (CurrentPetFormId == 0) { ShowMsg("Save the form first."); return; }
            int lineCount = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM dbo.PetLineItem WHERE PetFormID=@f", Db.P("@f", CurrentPetFormId)));
            if (lineCount == 0) { ShowMsg("Please add at least one line item before submitting."); return; }

            WorkflowDAL.SubmitPet(CurrentPetFormId, AuthHelper.CurrentUser, txtSubmitComments.Text.Trim());
            Response.Redirect("~/Forms/PetWorkflow.aspx?id=" + CurrentPetFormId);
        }

        // ===== Approval buttons =====
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            DataRow f = WorkflowDAL.GetPetForm(CurrentPetFormId);
            if (f == null) return;
            string status = f["Status"].ToString();
            if (status == "PendingReview")
                WorkflowDAL.ReviewPet(CurrentPetFormId, AuthHelper.CurrentUser, "Approve", txtDecisionComments.Text.Trim());
            else if (status == "PendingApproval")
                WorkflowDAL.ApprovePet(CurrentPetFormId, AuthHelper.CurrentUser, "Approved", txtDecisionComments.Text.Trim());
            Response.Redirect("~/Forms/PetWorkflow.aspx?id=" + CurrentPetFormId);
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            WorkflowDAL.ApprovePet(CurrentPetFormId, AuthHelper.CurrentUser, "Rejected", txtDecisionComments.Text.Trim());
            Response.Redirect("~/Forms/PetWorkflow.aspx?id=" + CurrentPetFormId);
        }

        protected void btnSendBack_Click(object sender, EventArgs e)
        {
            DataRow f = WorkflowDAL.GetPetForm(CurrentPetFormId);
            if (f == null) return;
            string status = f["Status"].ToString();
            if (status == "PendingReview")
                WorkflowDAL.ReviewPet(CurrentPetFormId, AuthHelper.CurrentUser, "SentBack", txtDecisionComments.Text.Trim());
            else if (status == "PendingApproval")
                WorkflowDAL.ApprovePet(CurrentPetFormId, AuthHelper.CurrentUser, "SentBack", txtDecisionComments.Text.Trim());
            Response.Redirect("~/Forms/PetWorkflow.aspx?id=" + CurrentPetFormId);
        }

        // ===== BPM Hierarchy =====
        protected void btnLoadHierarchy_Click(object sender, EventArgs e)
        {
            string pid = ddlBpmProject.SelectedValue;
            if (string.IsNullOrEmpty(pid)) { pnlHierarchy.Visible = false; pnlNoBpm.Visible = true; return; }

            ActiveTab = "bpm";

            // Project header
            DataRow p = MastersDAL.GetProjectById(pid);
            if (p != null)
            {
                litHierProjId.Text     = Server.HtmlEncode(Convert.ToString(p["ProjectID"]));
                litHierProjName.Text   = Server.HtmlEncode(Convert.ToString(p["ProjectName"]));
                litHierMgr.Text        = Server.HtmlEncode(Convert.ToString(p["ProjectManager"]));
                litHierProjAmt.Text    = Dec(p,"ProjectAmount").ToString("N2") + " AED";
                litHierProjStatus.Text = Server.HtmlEncode(Convert.ToString(p["ProjectStatus"]));
            }

            // PET
            gvHierPet.DataSource = WorkflowDAL.GetBPMPetForProject(pid);
            gvHierPet.DataBind();

            // Contracts
            gvHierContract.DataSource = DashboardDAL.GetContractFact(pid);
            gvHierContract.DataBind();

            // LPO
            gvHierLPO.DataSource = WorkflowDAL.GetLPOForProject(pid);
            gvHierLPO.DataBind();

            // Invoice (summarised from all LPOs for this project)
            gvHierInvoice.DataSource = Db.Query(@"SELECT i.InvoiceNumber, i.InvoiceType, i.VendorName,
                                                         i.LCAmount, i.AMSInvoiceStatus, i.InvoiceDate
                                                  FROM dbo.BPM_Invoice i
                                                  WHERE i.WiName IN (
                                                      SELECT WiName FROM dbo.BPM_LPO WHERE GLNumber IN (
                                                          SELECT GLNumber FROM dbo.GLMaster WHERE IsActive=1))",
                                                  Db.P("@p", pid));
            gvHierInvoice.DataBind();

            pnlNoBpm.Visible      = false;
            pnlHierarchy.Visible  = true;
        }

        // ===== Helpers =====
        private void ShowMsg(string msg) { lblMsg.Text = msg; lblMsg.Visible = true; }

        private static void SetDdl(DropDownList ddl, DataRow row, string col)
        {
            if (row == null || row[col] == DBNull.Value) return;
            string v = row[col].ToString();
            var item = ddl.Items.FindByValue(v);
            if (item != null) ddl.SelectedValue = v;
        }

        private static void SetDdl(DropDownList ddl, string value)
        {
            var item = ddl.Items.FindByValue(value ?? "");
            if (item != null) ddl.SelectedValue = value;
        }

        private static decimal Dec(DataRow r, string col)
        {
            if (r[col] == DBNull.Value) return 0m;
            decimal v; return decimal.TryParse(r[col].ToString(), out v) ? v : 0m;
        }
        private static decimal Dec(string s) { decimal v; return decimal.TryParse(s ?? "0", out v) ? v : 0m; }

        private decimal GetRate(string code)
        {
            DataRow r = Db.QueryRow("SELECT RateToLocal FROM dbo.PetCurrency WHERE Code=@c", Db.P("@c", code));
            if (r == null) return 1m;
            decimal v; return decimal.TryParse(r["RateToLocal"].ToString(), out v) ? v : 1m;
        }
    }
}
