using System;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM.Forms
{
    public partial class Dashboard : Page
    {
        // Chart data properties (used by inline JS)
        public string KpiUtilized  { get; private set; }
        public string KpiLocked    { get; private set; }
        public string KpiAvailable { get; private set; }
        public string TopProjectsLabelsJson { get; private set; }
        public string TopProjectsDataJson   { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadSlicers();
                BindAll();
            }
        }

        private void LoadSlicers()
        {
            // Project slicer
            DataTable dtP = DashboardDAL.GetDistinctProjects();
            ddlProject.DataSource     = dtP;
            ddlProject.DataTextField  = "ProjectID";
            ddlProject.DataValueField = "ProjectID";
            ddlProject.DataBind();
            ddlProject.Items.Insert(0, new ListItem("All Projects", ""));

            // PET Ref slicer
            DataTable dtPet = DashboardDAL.GetDistinctPetRefs();
            ddlPetRef.DataSource     = dtPet;
            ddlPetRef.DataTextField  = "PETReferenceNo";
            ddlPetRef.DataValueField = "PETReferenceNo";
            ddlPetRef.DataBind();
            ddlPetRef.Items.Insert(0, new ListItem("All PET", ""));

            // CAPEX slicer
            DataTable dtC = DashboardDAL.GetDistinctCapexIds();
            ddlCapex.DataSource     = dtC;
            ddlCapex.DataTextField  = "CapexID";
            ddlCapex.DataValueField = "CapexID";
            ddlCapex.DataBind();
            ddlCapex.Items.Insert(0, new ListItem("All CAPEX", ""));

            // Vendor slicer
            DataTable dtV = DashboardDAL.GetDistinctVendors();
            ddlVendor.DataSource     = dtV;
            ddlVendor.DataTextField  = "VendorName";
            ddlVendor.DataValueField = "VendorName";
            ddlVendor.DataBind();
            ddlVendor.Items.Insert(0, new ListItem("All Vendors", ""));
        }

        private void BindAll()
        {
            // As-of label
            litAsOf.Text = DateTime.Now.ToString("dd-MMM-yyyy HH:mm");

            string pid      = ddlProject.SelectedValue;
            string petRef   = ddlPetRef.SelectedValue;
            string capexId  = ddlCapex.SelectedValue;
            string itemType = ddlItemType.SelectedValue;
            string vendor   = ddlVendor.SelectedValue;

            // KPIs
            DataRow kpi = DashboardDAL.GetDashboardKPIs();
            decimal budget = 0, util = 0, locked = 0, avail = 0;
            int projCount = 0;
            if (kpi != null)
            {
                projCount = Convert.ToInt32(kpi["TotalProjects"]);
                budget = Dec(kpi, "TotalCapexBudget") + Dec(kpi, "TotalOpexBudget");
                util   = Dec(kpi, "TotalUtilized");
            }

            // Overview grid (Q7 / Q13 / Q14)
            DataTable dtOverview = DashboardDAL.GetProjectFinancialOverview(
                string.IsNullOrEmpty(pid) ? null : pid,
                string.IsNullOrEmpty(petRef) ? null : petRef,
                string.IsNullOrEmpty(capexId) ? null : capexId,
                string.IsNullOrEmpty(itemType) ? null : itemType);

            // Compute KPIs from overview data
            decimal obudget = 0, outil = 0, olocked = 0, oavail = 0;
            foreach (DataRow r in dtOverview.Rows)
            {
                obudget += Dec(r, "BudgetedAmount");
                outil   += Dec(r, "UtilizedAmount");
                olocked += Dec(r, "LockedAmount");
                oavail  += Dec(r, "AvailableAmount");
            }

            // If filtered, use the overview numbers; else use master KPIs
            bool isFiltered = !string.IsNullOrEmpty(pid) || !string.IsNullOrEmpty(petRef)
                           || !string.IsNullOrEmpty(capexId) || !string.IsNullOrEmpty(itemType);
            if (isFiltered) { budget = obudget; util = outil; locked = olocked; avail = oavail; }
            else             { locked = obudget - util; avail = obudget - util - locked; }

            litKpiProjects.Text = projCount.ToString("N0");
            litKpiBudget.Text   = FormatAmt(budget);
            litKpiUtil.Text     = FormatAmt(util);
            litKpiLocked.Text   = FormatAmt(locked);
            litKpiAvail.Text    = FormatAmt(avail);
            decimal pct = budget > 0 ? Math.Round(util / budget * 100, 1) : 0;
            litKpiUtilPct.Text  = pct + "%";

            // Chart data
            KpiUtilized  = util.ToString("F2");
            KpiLocked    = locked.ToString("F2");
            KpiAvailable = avail > 0 ? avail.ToString("F2") : "0";

            // Top 5 projects for bar chart
            DataTable dtProj = DashboardDAL.GetDistinctProjects();
            var sbL = new StringBuilder(); var sbD = new StringBuilder();
            int topN = 0;
            foreach (DataRow r in dtOverview.Rows)
            {
                if (topN >= 10) break;
                string pn = r["ProjectName"] != DBNull.Value ? r["ProjectName"].ToString() : (r["ProjectID"] != DBNull.Value ? r["ProjectID"].ToString() : "");
                if (!string.IsNullOrEmpty(pn))
                {
                    if (sbL.Length > 0) { sbL.Append(","); sbD.Append(","); }
                    sbL.Append("'").Append(pn.Replace("'", "").Substring(0, Math.Min(pn.Length, 15))).Append("'");
                    sbD.Append(Dec(r, "BudgetedAmount").ToString("F2"));
                    topN++;
                }
            }
            TopProjectsLabelsJson = sbL.ToString();
            TopProjectsDataJson   = sbD.ToString();

            // Bind overview grid
            gvOverview.DataSource = dtOverview;
            gvOverview.DataBind();
            litOverviewCount.Text = dtOverview.Rows.Count.ToString();

            // CAPEX tab
            gvCapex.DataSource = DashboardDAL.GetCapexMaster();
            gvCapex.DataBind();

            // OPEX tab
            gvOpex.DataSource = DashboardDAL.GetOpexMaster();
            gvOpex.DataBind();

            // GL tab (Q2)
            gvGL.DataSource = DashboardDAL.GetGLSummary();
            gvGL.DataBind();

            // Contract tab (Q1)
            gvContract.DataSource = DashboardDAL.GetContractFact(
                string.IsNullOrEmpty(pid) ? null : pid);
            gvContract.DataBind();

            // LPO tab (Q3)
            gvLPO.DataSource = DashboardDAL.GetLPOFact();
            gvLPO.DataBind();

            // Invoice tab (Q4)
            gvInvoice.DataSource = DashboardDAL.GetInvoiceFact(
                null,
                string.IsNullOrEmpty(vendor) ? null : vendor);
            gvInvoice.DataBind();
        }

        protected void ddlFilter_Changed(object sender, EventArgs e) { BindAll(); }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            ddlProject.SelectedIndex  = 0;
            ddlPetRef.SelectedIndex   = 0;
            ddlCapex.SelectedIndex    = 0;
            ddlItemType.SelectedIndex = 0;
            ddlVendor.SelectedIndex   = 0;
            BindAll();
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = DashboardDAL.GetProjectFinancialOverview(
                ddlProject.SelectedValue  == "" ? null : ddlProject.SelectedValue,
                ddlPetRef.SelectedValue   == "" ? null : ddlPetRef.SelectedValue,
                ddlCapex.SelectedValue    == "" ? null : ddlCapex.SelectedValue,
                ddlItemType.SelectedValue == "" ? null : ddlItemType.SelectedValue);
            ExcelHelper.ExportToExcel(Response, dt, "ProjectFinancialOverview_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        private static decimal Dec(DataRow r, string col)
        {
            if (r == null || !r.Table.Columns.Contains(col) || r[col] == DBNull.Value) return 0m;
            decimal v; return decimal.TryParse(r[col].ToString(), out v) ? v : 0m;
        }

        private static string FormatAmt(decimal v)
        {
            if (v >= 1_000_000_000) return (v / 1_000_000_000).ToString("N2") + "B";
            if (v >= 1_000_000)     return (v / 1_000_000).ToString("N2") + "M";
            if (v >= 1_000)         return (v / 1_000).ToString("N1") + "K";
            return v.ToString("N0");
        }
    }
}
