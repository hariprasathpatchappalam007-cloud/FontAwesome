<%@ Page Title="Project Financial Overview" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="Dashboard.aspx.cs" Inherits="DFM_BPM.Forms.Dashboard" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
<style>
.pfo-banner { background:linear-gradient(135deg,#1a3c5e,#2563eb); color:#fff; padding:14px 24px;
              display:flex; align-items:center; gap:16px; border-radius:8px 8px 0 0; }
.pfo-banner h2 { margin:0; font-size:1.35em; font-weight:800; }
.pfo-slicers { display:flex; flex-wrap:wrap; gap:6px; background:#f1f5f9; padding:10px 16px;
               border:1px solid #cbd5e1; border-top:none; border-radius:0 0 8px 8px; margin-bottom:14px; align-items:flex-end; }
.pfo-slicers .form-group { flex:1 1 150px; max-width:210px; margin-bottom:0; }
.pfo-slicers label { font-size:.72em; font-weight:700; color:#1a3c5e; }

/* Data sections */
.section-tabs .nav-tabs > li.active > a { background:#1a3c5e !important; color:#fff !important; border-color:#1a3c5e !important; }
.section-tabs .nav-tabs > li > a { font-weight:700; font-size:.85em; }

/* Chart container */
.chart-wrap { position:relative; height:300px; margin-bottom:14px; }
</style>
</head>
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">

<!-- Banner -->
<div class="pfo-banner">
    <i class="bi bi-bank2" style="font-size:2em;"></i>
    <h2>Project Financial Overview – BPM Financial Tracker</h2>
    <div style="margin-left:auto;font-size:.8em;opacity:.8;">Data synced from Oracle BPM | As of: <asp:Literal ID="litAsOf" runat="server" /></div>
</div>

<!-- Slicers -->
<div class="pfo-slicers">
    <div class="form-group">
        <label>Project ID</label>
        <asp:DropDownList ID="ddlProject" runat="server" CssClass="form-control"
            AutoPostBack="true" OnSelectedIndexChanged="ddlFilter_Changed" />
    </div>
    <div class="form-group">
        <label>PET Reference</label>
        <asp:DropDownList ID="ddlPetRef" runat="server" CssClass="form-control"
            AutoPostBack="true" OnSelectedIndexChanged="ddlFilter_Changed" />
    </div>
    <div class="form-group">
        <label>CAPEX ID</label>
        <asp:DropDownList ID="ddlCapex" runat="server" CssClass="form-control"
            AutoPostBack="true" OnSelectedIndexChanged="ddlFilter_Changed" />
    </div>
    <div class="form-group">
        <label>Item Type</label>
        <asp:DropDownList ID="ddlItemType" runat="server" CssClass="form-control"
            AutoPostBack="true" OnSelectedIndexChanged="ddlFilter_Changed">
            <asp:ListItem Value="">All</asp:ListItem>
            <asp:ListItem Value="Capex">CAPEX</asp:ListItem>
            <asp:ListItem Value="Opex">OPEX</asp:ListItem>
        </asp:DropDownList>
    </div>
    <div class="form-group">
        <label>Vendor</label>
        <asp:DropDownList ID="ddlVendor" runat="server" CssClass="form-control"
            AutoPostBack="true" OnSelectedIndexChanged="ddlFilter_Changed" />
    </div>
    <div class="form-group" style="flex:0 0 auto;">
        <label>&nbsp;</label>
        <div style="display:flex;gap:6px;">
            <asp:LinkButton ID="btnClear" runat="server" CssClass="btn btn-default btn-sm"
                OnClick="btnClear_Click" CausesValidation="false">
                <i class="bi bi-x-circle"></i> Clear
            </asp:LinkButton>
            <asp:LinkButton ID="btnExport" runat="server" CssClass="btn btn-success btn-sm"
                OnClick="btnExport_Click" CausesValidation="false">
                <i class="bi bi-file-excel"></i> Export
            </asp:LinkButton>
        </div>
    </div>
</div>

<asp:Label ID="lblMsg" runat="server" CssClass="alert-info" Visible="false" />

<!-- KPI Tiles -->
<div class="kpi-row">
    <div class="kpi-card kpi-blue"><span class="kpi-icon"><i class="bi bi-folder2-open"></i></span>
        <div><div class="kpi-label">Projects</div><div class="kpi-val"><asp:Literal ID="litKpiProjects" runat="server" Text="0" /></div></div></div>
    <div class="kpi-card kpi-green"><span class="kpi-icon"><i class="bi bi-currency-dollar"></i></span>
        <div><div class="kpi-label">Total Budget (AED)</div><div class="kpi-val"><asp:Literal ID="litKpiBudget" runat="server" Text="0" /></div></div></div>
    <div class="kpi-card kpi-orange"><span class="kpi-icon"><i class="bi bi-graph-up"></i></span>
        <div><div class="kpi-label">Utilized (AED)</div><div class="kpi-val"><asp:Literal ID="litKpiUtil" runat="server" Text="0" /></div>
             <div style="font-size:.75em;color:#d97706;"><asp:Literal ID="litKpiUtilPct" runat="server" Text="0%" /> of budget</div></div></div>
    <div class="kpi-card kpi-red"><span class="kpi-icon"><i class="bi bi-lock"></i></span>
        <div><div class="kpi-label">Locked (AED)</div><div class="kpi-val"><asp:Literal ID="litKpiLocked" runat="server" Text="0" /></div></div></div>
    <div class="kpi-card kpi-green"><span class="kpi-icon"><i class="bi bi-wallet2"></i></span>
        <div><div class="kpi-label">Available (AED)</div><div class="kpi-val"><asp:Literal ID="litKpiAvail" runat="server" Text="0" /></div></div></div>
</div>

<!-- Section tabs -->
<div class="section-tabs">
<ul class="nav nav-tabs" role="tablist">
    <li class="active"><a href="#tabOverview"  data-toggle="tab"><i class="bi bi-bar-chart-line"></i> Overview</a></li>
    <li><a href="#tabCapex"    data-toggle="tab"><i class="bi bi-currency-dollar"></i> CAPEX</a></li>
    <li><a href="#tabOpex"     data-toggle="tab"><i class="bi bi-receipt"></i> OPEX</a></li>
    <li><a href="#tabGL"       data-toggle="tab"><i class="bi bi-journal-bookmark"></i> GL</a></li>
    <li><a href="#tabContract" data-toggle="tab"><i class="bi bi-file-earmark-richtext"></i> Contracts</a></li>
    <li><a href="#tabLPO"      data-toggle="tab"><i class="bi bi-cart3"></i> LPO</a></li>
    <li><a href="#tabInvoice"  data-toggle="tab"><i class="bi bi-receipt-cutoff"></i> Invoices</a></li>
</ul>

<div class="tab-content" style="padding-top:12px;">

    <!-- Overview Tab -->
    <div class="tab-pane active" id="tabOverview">
        <div class="row">
            <div class="col-md-6">
                <div class="card-panel">
                    <div class="card-panel-hdr"><i class="bi bi-pie-chart"></i> Budget Distribution</div>
                    <div class="card-panel-body"><div class="chart-wrap"><canvas id="chartBudget"></canvas></div></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card-panel">
                    <div class="card-panel-hdr"><i class="bi bi-bar-chart"></i> Top Projects by Budget</div>
                    <div class="card-panel-body"><div class="chart-wrap"><canvas id="chartProjects"></canvas></div></div>
                </div>
            </div>
        </div>
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-table"></i> Project Financial Overview
                (<asp:Literal ID="litOverviewCount" runat="server" Text="0" /> records)
            </div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvOverview" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None"
                    EmptyDataText="No data. Run Oracle Sync to populate.">
                    <Columns>
                        <asp:BoundField DataField="ItemType"        HeaderText="Type" />
                        <asp:BoundField DataField="ItemID"           HeaderText="Item ID" />
                        <asp:BoundField DataField="ProjectID"        HeaderText="Project ID" />
                        <asp:BoundField DataField="ProjectName"      HeaderText="Project Name" />
                        <asp:BoundField DataField="PetReference"     HeaderText="PET Ref" />
                        <asp:BoundField DataField="BudgetedAmount"   HeaderText="Budget (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"   HeaderText="Utilized (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="LockedAmount"     HeaderText="Locked (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AvailableAmount"  HeaderText="Available (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="ClaimAmount"      HeaderText="Claim (AED)"     DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="VendorName"       HeaderText="Vendor" />
                        <asp:BoundField DataField="InitiatorDept"    HeaderText="Dept" />
                        <asp:BoundField DataField="EFormDate"        HeaderText="E-Form Date" DataFormatString="{0:dd-MMM-yyyy}" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

    <!-- CAPEX Tab -->
    <div class="tab-pane" id="tabCapex">
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-currency-dollar"></i> CAPEX Master</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvCapex" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No CAPEX data.">
                    <Columns>
                        <asp:BoundField DataField="CapexID"          HeaderText="CAPEX ID" />
                        <asp:BoundField DataField="BudgetedAmount"   HeaderText="Budget (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"   HeaderText="Utilized (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="LockedAmount"     HeaderText="Locked (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AvailableAmount"  HeaderText="Available (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="GLNumbers"        HeaderText="GL Numbers" />
                        <asp:BoundField DataField="LastSyncDate"     HeaderText="Last Sync"       DataFormatString="{0:dd-MMM-yyyy}" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

    <!-- OPEX Tab -->
    <div class="tab-pane" id="tabOpex">
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-receipt"></i> OPEX Master</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvOpex" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No OPEX data.">
                    <Columns>
                        <asp:BoundField DataField="OpexID"           HeaderText="OPEX ID" />
                        <asp:BoundField DataField="BudgetedAmount"   HeaderText="Budget (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"   HeaderText="Utilized (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="LockedAmount"     HeaderText="Locked (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AvailableAmount"  HeaderText="Available (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="Contracts"        HeaderText="Contracts" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

    <!-- GL Tab -->
    <div class="tab-pane" id="tabGL">
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-journal-bookmark"></i> GL Summary (Q2)</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvGL" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No GL data.">
                    <Columns>
                        <asp:BoundField DataField="GLNumber"            HeaderText="GL Number" />
                        <asp:BoundField DataField="GLDescription"       HeaderText="Description" />
                        <asp:BoundField DataField="BudgetedAmount"      HeaderText="Budget (AED)"       DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BPMLockedAmount"     HeaderText="BPM Locked (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AMSLockedAmount"     HeaderText="AMS Locked (AED)"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"      HeaderText="Utilized (AED)"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BalanceAmount"       HeaderText="Balance (AED)"     DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="CapitalizedAmount"   HeaderText="Capitalized (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="InvoiceProcessedAmt" HeaderText="Invoice Proc (AED)" DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

    <!-- Contract Tab (Q1) -->
    <div class="tab-pane" id="tabContract">
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-file-earmark-richtext"></i> Contracts / Memo (Q1)</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvContract" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No contract data.">
                    <Columns>
                        <asp:BoundField DataField="Reference"       HeaderText="Reference" />
                        <asp:BoundField DataField="Department"      HeaderText="Department" />
                        <asp:BoundField DataField="ContractNo"      HeaderText="Contract No" />
                        <asp:BoundField DataField="VendorName"      HeaderText="Vendor" />
                        <asp:BoundField DataField="Currency"        HeaderText="CCY" />
                        <asp:BoundField DataField="LCAmount"        HeaderText="LC Amount"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BPMLockedAmount" HeaderText="BPM Locked"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"  HeaderText="Utilized"     DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="ContractBalance" HeaderText="Balance"      DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="ContractStatus"  HeaderText="Status" />
                        <asp:BoundField DataField="OpexID"          HeaderText="OPEX ID" />
                        <asp:BoundField DataField="InitiationDate"  HeaderText="Initiated"    DataFormatString="{0:dd-MMM-yyyy}" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

    <!-- LPO Tab (Q3) -->
    <div class="tab-pane" id="tabLPO">
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-cart3"></i> LPO (Q3)</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvLPO" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No LPO data.">
                    <Columns>
                        <asp:BoundField DataField="LPONo"           HeaderText="LPO No" />
                        <asp:BoundField DataField="LPODesc"         HeaderText="Description" />
                        <asp:BoundField DataField="VendorName"      HeaderText="Vendor" />
                        <asp:BoundField DataField="Currency"        HeaderText="CCY" />
                        <asp:BoundField DataField="LCAmount"        HeaderText="LC Amount"   DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BudgetAmount"    HeaderText="Budget"      DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="BPMLockedAmount" HeaderText="BPM Locked"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="UtilizedAmount"  HeaderText="Utilized"    DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AvailableBalance" HeaderText="Available"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="LPOStatus"       HeaderText="Status" />
                        <asp:BoundField DataField="GLNumber"        HeaderText="GL#" />
                        <asp:BoundField DataField="InitiationDate"  HeaderText="Initiated"   DataFormatString="{0:dd-MMM-yyyy}" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>

    <!-- Invoice Tab (Q4) -->
    <div class="tab-pane" id="tabInvoice">
        <div class="card-panel">
            <div class="card-panel-hdr"><i class="bi bi-receipt-cutoff"></i> Invoices (Q4)</div>
            <div class="card-panel-body" style="padding:0;overflow-x:auto;">
                <asp:GridView ID="gvInvoice" runat="server" AutoGenerateColumns="false"
                    CssClass="dfm-table" GridLines="None" EmptyDataText="No invoice data.">
                    <Columns>
                        <asp:BoundField DataField="InvoiceNumber"    HeaderText="Invoice No" />
                        <asp:BoundField DataField="InvoiceType"      HeaderText="Type" />
                        <asp:BoundField DataField="Department"       HeaderText="Department" />
                        <asp:BoundField DataField="VendorName"       HeaderText="Vendor" />
                        <asp:BoundField DataField="Currency"         HeaderText="CCY" />
                        <asp:BoundField DataField="LCAmount"         HeaderText="LC Amount"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="FCAmount"         HeaderText="FC Amount"  DataFormatString="{0:N2}" ItemStyle-CssClass="text-right" />
                        <asp:BoundField DataField="AMSInvoiceStatus" HeaderText="AMS Status" />
                        <asp:BoundField DataField="BPMLastStatus"    HeaderText="BPM Status" />
                        <asp:BoundField DataField="PendingAt"        HeaderText="Pending At" />
                        <asp:BoundField DataField="InvoiceDate"      HeaderText="Invoice Date" DataFormatString="{0:dd-MMM-yyyy}" />
                    </Columns>
                </asp:GridView>
            </div>
        </div>
    </div>
</div><!-- /tab-content -->
</div><!-- /section-tabs -->

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function() {
    // Budget distribution pie chart
    var budgetCtx = document.getElementById('chartBudget');
    if (budgetCtx) {
        new Chart(budgetCtx.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['Utilized', 'Locked', 'Available'],
                datasets: [{
                    data: [
                        parseFloat('<%: KpiUtilized %>') || 0,
                        parseFloat('<%: KpiLocked %>') || 0,
                        parseFloat('<%: KpiAvailable %>') || 0
                    ],
                    backgroundColor: ['#f59e0b','#3b82f6','#10b981']
                }]
            },
            options: { responsive:true, maintainAspectRatio:false, plugins:{legend:{position:'bottom'}} }
        });
    }

    // Top projects bar chart
    var projCtx = document.getElementById('chartProjects');
    var projLabels = [<%: TopProjectsLabelsJson %>];
    var projData   = [<%: TopProjectsDataJson %>];
    if (projCtx && projLabels.length) {
        new Chart(projCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: projLabels,
                datasets: [{
                    label: 'Budget (AED)',
                    data: projData,
                    backgroundColor: '#2563eb'
                }]
            },
            options: { responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
        });
    }
})();
</script>
</asp:Content>
