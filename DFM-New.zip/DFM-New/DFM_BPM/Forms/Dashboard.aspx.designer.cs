// Auto-generated designer file for Forms/Dashboard.aspx
namespace DFM_BPM.Forms
{
    public partial class Dashboard
    {
        protected global::System.Web.UI.WebControls.Literal      litAsOf;

        // Slicer dropdowns
        protected global::System.Web.UI.WebControls.DropDownList  ddlProject;
        protected global::System.Web.UI.WebControls.DropDownList  ddlPetRef;
        protected global::System.Web.UI.WebControls.DropDownList  ddlCapex;
        protected global::System.Web.UI.WebControls.DropDownList  ddlItemType;
        protected global::System.Web.UI.WebControls.DropDownList  ddlVendor;
        protected global::System.Web.UI.WebControls.LinkButton     btnClear;
        protected global::System.Web.UI.WebControls.LinkButton     btnExport;
        protected global::System.Web.UI.WebControls.Label          lblMsg;

        // KPI literals
        protected global::System.Web.UI.WebControls.Literal  litKpiProjects;
        protected global::System.Web.UI.WebControls.Literal  litKpiBudget;
        protected global::System.Web.UI.WebControls.Literal  litKpiUtil;
        protected global::System.Web.UI.WebControls.Literal  litKpiLocked;
        protected global::System.Web.UI.WebControls.Literal  litKpiAvail;
        protected global::System.Web.UI.WebControls.Literal  litKpiUtilPct;

        // Grids
        protected global::System.Web.UI.WebControls.Literal   litOverviewCount;
        protected global::System.Web.UI.WebControls.GridView  gvOverview;
        protected global::System.Web.UI.WebControls.GridView  gvCapex;
        protected global::System.Web.UI.WebControls.GridView  gvOpex;
        protected global::System.Web.UI.WebControls.GridView  gvGL;
        protected global::System.Web.UI.WebControls.GridView  gvContract;
        protected global::System.Web.UI.WebControls.GridView  gvLPO;
        protected global::System.Web.UI.WebControls.GridView  gvInvoice;
    }
}
