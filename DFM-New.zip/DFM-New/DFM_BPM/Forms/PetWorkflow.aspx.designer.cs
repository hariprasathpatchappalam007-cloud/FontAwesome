// Auto-generated designer file for Forms/PetWorkflow.aspx
namespace DFM_BPM.Forms
{
    public partial class PetWorkflow
    {
        // Shared
        protected global::System.Web.UI.WebControls.Label        lblMsg;
        protected global::System.Web.UI.WebControls.HiddenField   hfPetFormId;

        // Tab 1 – PET Header
        protected global::System.Web.UI.WebControls.DropDownList  ddlProject;
        protected global::System.Web.UI.WebControls.DropDownList  ddlType;
        protected global::System.Web.UI.WebControls.DropDownList  ddlBudgetSource;
        protected global::System.Web.UI.WebControls.DropDownList  ddlReviewer;
        protected global::System.Web.UI.WebControls.DropDownList  ddlApprover;
        protected global::System.Web.UI.WebControls.TextBox       txtTitle;
        protected global::System.Web.UI.WebControls.Panel         pnlBudgetInfo;
        protected global::System.Web.UI.WebControls.PlaceHolder   phBudgetInfo;
        protected global::System.Web.UI.WebControls.Button        btnSaveHeader;

        // Budget amount panels
        protected global::System.Web.UI.WebControls.Panel    pnlCapexAmt;
        protected global::System.Web.UI.WebControls.Literal  litCapexBudget;
        protected global::System.Web.UI.WebControls.Literal  litCapexUtil;
        protected global::System.Web.UI.WebControls.Literal  litCapexLocked;
        protected global::System.Web.UI.WebControls.Literal  litCapexAvail;
        protected global::System.Web.UI.WebControls.Literal  litCapexGL;

        protected global::System.Web.UI.WebControls.Panel    pnlOpexAmt;
        protected global::System.Web.UI.WebControls.Literal  litOpexBudget;
        protected global::System.Web.UI.WebControls.Literal  litOpexUtil;
        protected global::System.Web.UI.WebControls.Literal  litOpexLocked;
        protected global::System.Web.UI.WebControls.Literal  litOpexAvail;
        protected global::System.Web.UI.WebControls.Literal  litOpexContracts;

        // Line items panel
        protected global::System.Web.UI.WebControls.Panel        pnlLines;
        protected global::System.Web.UI.WebControls.LinkButton   btnAddLine;
        protected global::System.Web.UI.WebControls.GridView     gvLines;
        protected global::System.Web.UI.WebControls.Literal      litLineCount;
        protected global::System.Web.UI.WebControls.Literal      litTotalLCY;
        protected global::System.Web.UI.WebControls.Literal      litTotalFinal;

        // Add line form
        protected global::System.Web.UI.WebControls.Panel        pnlAddLine;
        protected global::System.Web.UI.WebControls.DropDownList  ddlExpHead;
        protected global::System.Web.UI.WebControls.TextBox       txtLineTopic;
        protected global::System.Web.UI.WebControls.DropDownList  ddlLineVendor;
        protected global::System.Web.UI.WebControls.DropDownList  ddlLineCostType;
        protected global::System.Web.UI.WebControls.DropDownList  ddlLineGL;
        protected global::System.Web.UI.WebControls.DropDownList  ddlLineCcy;
        protected global::System.Web.UI.WebControls.TextBox       txtLineUnits;
        protected global::System.Web.UI.WebControls.TextBox       txtLineUnitPrice;
        protected global::System.Web.UI.WebControls.TextBox       txtLineAmtFCY;
        protected global::System.Web.UI.WebControls.TextBox       txtLineAmtLCY;
        protected global::System.Web.UI.WebControls.TextBox       txtLineConting;
        protected global::System.Web.UI.WebControls.TextBox       txtLineDesc;
        protected global::System.Web.UI.WebControls.Button        btnSaveLine;
        protected global::System.Web.UI.WebControls.Button        btnCancelLine;

        // Submit section
        protected global::System.Web.UI.WebControls.TextBox  txtSubmitComments;
        protected global::System.Web.UI.WebControls.Button   btnSubmitPet;

        // Tab 2 – Project Details
        protected global::System.Web.UI.WebControls.Panel    pnlProjectDetails;
        protected global::System.Web.UI.WebControls.Literal  litProjId;
        protected global::System.Web.UI.WebControls.Literal  litProjName;
        protected global::System.Web.UI.WebControls.Literal  litProjMgr;
        protected global::System.Web.UI.WebControls.Literal  litProjMgrEmail;
        protected global::System.Web.UI.WebControls.Literal  litProjBA;
        protected global::System.Web.UI.WebControls.Literal  litProjStatus;
        protected global::System.Web.UI.WebControls.Literal  litProjStart;
        protected global::System.Web.UI.WebControls.Literal  litProjEnd;
        protected global::System.Web.UI.WebControls.Literal  litProjAmt;
        protected global::System.Web.UI.WebControls.Literal  litProjCapex;
        protected global::System.Web.UI.WebControls.Literal  litProjDesc;
        protected global::System.Web.UI.WebControls.GridView  gvCapexAmt;
        protected global::System.Web.UI.WebControls.GridView  gvOpexAmt;
        protected global::System.Web.UI.WebControls.GridView  gvGLAmt;
        protected global::System.Web.UI.WebControls.Panel     pnlNoProject;

        // Tab 3 – PET Approval
        protected global::System.Web.UI.WebControls.Panel    pnlApprovalDetails;
        protected global::System.Web.UI.WebControls.Literal  litApprRequestor;
        protected global::System.Web.UI.WebControls.Literal  litApprReviewer;
        protected global::System.Web.UI.WebControls.Literal  litApprApprover;
        protected global::System.Web.UI.WebControls.Literal  litApprStatus;
        protected global::System.Web.UI.WebControls.Panel    pnlDecision;
        protected global::System.Web.UI.WebControls.Literal  litDecisionTitle;
        protected global::System.Web.UI.WebControls.TextBox  txtDecisionComments;
        protected global::System.Web.UI.WebControls.Button   btnApprove;
        protected global::System.Web.UI.WebControls.Button   btnReject;
        protected global::System.Web.UI.WebControls.Button   btnSendBack;
        protected global::System.Web.UI.WebControls.GridView  gvHistory;

        // Tab 4 – BPM CAM
        protected global::System.Web.UI.WebControls.DropDownList  ddlBpmProject;
        protected global::System.Web.UI.WebControls.Button        btnLoadHierarchy;
        protected global::System.Web.UI.WebControls.Panel         pnlHierarchy;
        protected global::System.Web.UI.WebControls.Literal       litHierProjId;
        protected global::System.Web.UI.WebControls.Literal       litHierProjName;
        protected global::System.Web.UI.WebControls.Literal       litHierMgr;
        protected global::System.Web.UI.WebControls.Literal       litHierProjAmt;
        protected global::System.Web.UI.WebControls.Literal       litHierProjStatus;
        protected global::System.Web.UI.WebControls.GridView      gvHierPet;
        protected global::System.Web.UI.WebControls.GridView      gvHierContract;
        protected global::System.Web.UI.WebControls.GridView      gvHierLPO;
        protected global::System.Web.UI.WebControls.GridView      gvHierInvoice;
        protected global::System.Web.UI.WebControls.Panel         pnlNoBpm;
    }
}
