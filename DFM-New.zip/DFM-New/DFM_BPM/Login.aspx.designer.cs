// Auto-generated designer file for Login.aspx
namespace DFM_BPM
{
    public partial class Login
    {
        protected global::System.Web.UI.WebControls.Label    lblMsg;
        protected global::System.Web.UI.WebControls.TextBox  txtUser;
        protected global::System.Web.UI.WebControls.TextBox  txtPwd;
        protected global::System.Web.UI.WebControls.CheckBox chkRemember;
        protected global::System.Web.UI.WebControls.Button   btnLogin;
    }
}
