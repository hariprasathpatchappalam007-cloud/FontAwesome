using System;
using System.Web.UI;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM
{
    public partial class SiteMaster : MasterPage
    {
        public string CurrentUser     { get { return AuthHelper.CurrentUser; } }
        public string CurrentFullName { get { return AuthHelper.CurrentFullName; } }
        public bool   IsAdminUser     { get { return AuthHelper.IsAdmin; } }
        public int    UnreadNotifCount { get; private set; }
        public string LastSyncLabel   { get; private set; }

        public string UserInitials
        {
            get
            {
                string n = CurrentFullName ?? CurrentUser;
                if (string.IsNullOrEmpty(n)) return "?";
                var parts = n.Split(' ');
                return parts.Length >= 2
                    ? (parts[0][0].ToString() + parts[1][0]).ToUpper()
                    : n.Substring(0, Math.Min(2, n.Length)).ToUpper();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            // Sign-out handling
            if (Request.QueryString["signout"] == "1")
            {
                AuthHelper.SignOut();
                Response.Redirect("~/Login.aspx");
            }

            try
            {
                UnreadNotifCount = UserDAL.GetUnreadCount(CurrentUser);
            }
            catch { UnreadNotifCount = 0; }

            try
            {
                var row = Db.QueryRow("SELECT TOP 1 CONVERT(VARCHAR,EndTime,120) AS T FROM dbo.SyncLog WHERE Status='Success' ORDER BY SyncID DESC");
                LastSyncLabel = row != null ? row["T"].ToString() : "Never";
            }
            catch { LastSyncLabel = "N/A"; }
        }

        protected string IsActive(string page)
        {
            string path = Request.AppRelativeCurrentExecutionFilePath ?? "";
            return path.IndexOf(page, StringComparison.OrdinalIgnoreCase) >= 0 ? "active" : "";
        }
    }
}
