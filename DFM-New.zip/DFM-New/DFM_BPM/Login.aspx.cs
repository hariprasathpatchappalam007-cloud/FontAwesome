using System;
using System.Data;
using System.Web.UI;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["signout"] == "1")
            {
                AuthHelper.SignOut();
                Response.Redirect("~/Login.aspx");
                return;
            }
            if (!IsPostBack && Request.IsAuthenticated)
                Response.Redirect("~/Default.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string user = (txtUser.Text ?? "").Trim();
            string pwd  = txtPwd.Text ?? "";

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pwd))
            {
                ShowError("Username and password are required.");
                return;
            }

            // First run: if admin has the placeholder hash, set it from this login
            EnsureAdminPassword(user, pwd);

            DataRow row = UserDAL.ValidateUser(user, pwd);
            if (row == null)
            {
                ShowError("Invalid username or password, or account is disabled.");
                return;
            }

            UserDAL.UpdateLastLogin(user);
            AuthHelper.SignIn(
                row["Username"].ToString(),
                row["FullName"].ToString(),
                row["RoleName"].ToString(),
                chkRemember.Checked);

            string returnUrl = Request.QueryString["ReturnUrl"];
            Response.Redirect(string.IsNullOrEmpty(returnUrl) ? "~/Default.aspx" : returnUrl);
        }

        private void ShowError(string msg)
        {
            lblMsg.Text    = msg;
            lblMsg.Visible = true;
        }

        /// <summary>
        /// On first run the admin hash is a placeholder.  When the admin logs in
        /// for the first time we persist the real hash so subsequent logins work.
        /// </summary>
        private static void EnsureAdminPassword(string username, string password)
        {
            try
            {
                DataRow row = Db.QueryRow(
                    "SELECT PasswordHash, PasswordSalt FROM dbo.AppUsers WHERE Username=@u",
                    Db.P("@u", username));
                if (row == null) return;
                string hash = row["PasswordHash"].ToString();
                if (hash.StartsWith("rAndom-"))
                {
                    string salt    = PasswordHelper.GenerateSalt();
                    string newHash = PasswordHelper.Hash(password, salt);
                    Db.Exec("UPDATE dbo.AppUsers SET PasswordHash=@h, PasswordSalt=@s WHERE Username=@u",
                        Db.P("@h", newHash), Db.P("@s", salt), Db.P("@u", username));
                }
            }
            catch { /* non-critical */ }
        }
    }
}
