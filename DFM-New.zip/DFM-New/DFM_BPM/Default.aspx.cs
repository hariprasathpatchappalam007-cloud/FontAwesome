using System;
using System.Data;
using System.Web.UI;
using DFM_BPM.App_Code.DAL;
using DFM_BPM.App_Code.Helpers;

namespace DFM_BPM
{
    public partial class DefaultPage : Page
    {
        protected bool IsAdmin => AuthHelper.IsAdmin;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) LoadKPIs();
        }

        private void LoadKPIs()
        {
            try
            {
                DataRow kpi = DashboardDAL.GetDashboardKPIs();
                if (kpi != null)
                {
                    litProjects.Text    = Fmt(kpi, "TotalProjects");
                    litPET.Text         = Fmt(kpi, "TotalPET");
                    litLPO.Text         = Fmt(kpi, "TotalLPO");
                    litInvoice.Text     = Fmt(kpi, "TotalInvoice");
                    litCapexBudget.Text = FmtAmt(kpi, "TotalCapexBudget");
                    litOpexBudget.Text  = FmtAmt(kpi, "TotalOpexBudget");
                }
            }
            catch { /* data not yet synced */ }

            try
            {
                DataTable dt = WorkflowDAL.GetPetForms(AuthHelper.CurrentUser);
                dt.DefaultView.RowFilter = "";
                gvMyPet.DataSource = dt;
                gvMyPet.DataBind();
            }
            catch { }
        }

        private static string Fmt(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return "0";
            return Convert.ToInt32(r[col]).ToString("N0");
        }

        private static string FmtAmt(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return "AED 0";
            decimal v = Convert.ToDecimal(r[col]);
            if (v >= 1_000_000) return "AED " + (v / 1_000_000).ToString("N2") + "M";
            if (v >= 1_000)     return "AED " + (v / 1_000).ToString("N1") + "K";
            return "AED " + v.ToString("N0");
        }
    }
}
