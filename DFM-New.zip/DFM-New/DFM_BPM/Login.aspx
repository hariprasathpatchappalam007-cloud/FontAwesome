<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="DFM_BPM.Login" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign In – BPM Financial Tracker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<%= ResolveUrl("~/Content/Site.css") %>" rel="stylesheet" />
</head>
<body>
<form id="form1" runat="server">
<div class="login-wrap">
    <div class="login-card">
        <div class="login-logo">
            <i class="bi bi-bank2" style="font-size:3em;color:#1a3c5e;"></i>
        </div>
        <div class="login-title">BPM Financial Tracker</div>
        <div class="login-sub">Dubai Islamic Bank – IT Division</div>

        <asp:Label ID="lblMsg" runat="server" CssClass="alert-error" Visible="false" />

        <div class="form-group">
            <label style="font-weight:700;color:#374151;">Username</label>
            <asp:TextBox ID="txtUser" runat="server" CssClass="form-control" placeholder="Enter username" />
        </div>
        <div class="form-group">
            <label style="font-weight:700;color:#374151;">Password</label>
            <asp:TextBox ID="txtPwd" runat="server" CssClass="form-control" TextMode="Password" placeholder="Enter password" />
        </div>
        <div class="form-group">
            <asp:CheckBox ID="chkRemember" runat="server" Text=" Remember me" />
        </div>
        <div class="form-group">
            <asp:Button ID="btnLogin" runat="server" Text="Sign In" CssClass="btn btn-primary"
                OnClick="btnLogin_Click" />
        </div>

        <div style="text-align:center;font-size:.8em;color:#94a3b8;margin-top:16px;">
            Default credentials: admin / Admin@123
        </div>
    </div>
</div>
</form>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet" />
</body>
</html>
