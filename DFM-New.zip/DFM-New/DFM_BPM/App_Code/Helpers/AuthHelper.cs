using System;
using System.Web;
using System.Web.Security;

namespace DFM_BPM.App_Code.Helpers
{
    public static class AuthHelper
    {
        public static string CurrentUser
        {
            get
            {
                if (HttpContext.Current == null) return "system";
                string u = HttpContext.Current.Session != null
                    ? HttpContext.Current.Session["Username"] as string
                    : null;
                if (u != null) return u;
                if (HttpContext.Current.User != null && HttpContext.Current.User.Identity != null)
                    return HttpContext.Current.User.Identity.Name ?? "anonymous";
                return "anonymous";
            }
        }

        public static string CurrentFullName
        {
            get
            {
                if (HttpContext.Current == null || HttpContext.Current.Session == null) return CurrentUser;
                return (HttpContext.Current.Session["FullName"] as string) ?? CurrentUser;
            }
        }

        public static string CurrentRole
        {
            get
            {
                if (HttpContext.Current == null || HttpContext.Current.Session == null) return "";
                return (HttpContext.Current.Session["Role"] as string) ?? "";
            }
        }

        public static bool IsAdmin
        {
            get { return string.Equals(CurrentRole, "Admin", StringComparison.OrdinalIgnoreCase); }
        }

        public static bool IsReviewer
        {
            get { return HasRoleAssignment("Reviewer"); }
        }

        public static bool IsApprover
        {
            get { return HasRoleAssignment("Approver"); }
        }

        private static bool HasRoleAssignment(string roleType)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null) return false;
            string key = "RoleAssign_" + roleType;
            object cached = HttpContext.Current.Session[key];
            if (cached != null) return (bool)cached;
            int cnt = Convert.ToInt32(DAL.Db.Scalar(
                "SELECT COUNT(*) FROM dbo.UserRoleAssignments WHERE Username=@u AND RoleType=@r",
                DAL.Db.P("@u", CurrentUser), DAL.Db.P("@r", roleType)));
            bool result = cnt > 0;
            HttpContext.Current.Session[key] = result;
            return result;
        }

        public static void SignIn(string username, string fullName, string role, bool persist)
        {
            HttpContext.Current.Session["Username"] = username;
            HttpContext.Current.Session["FullName"] = fullName;
            HttpContext.Current.Session["Role"]     = role;
            // Clear cached role assignments
            HttpContext.Current.Session.Remove("RoleAssign_Reviewer");
            HttpContext.Current.Session.Remove("RoleAssign_Approver");
            FormsAuthentication.SetAuthCookie(username, persist);
        }

        public static void SignOut()
        {
            HttpContext.Current.Session.Abandon();
            FormsAuthentication.SignOut();
        }

        public static bool CanAccessPage(string pageName)
        {
            if (IsAdmin) return true;
            int roleId = Convert.ToInt32(DAL.Db.Scalar(
                "SELECT RoleID FROM dbo.AppUsers WHERE Username=@u", DAL.Db.P("@u", CurrentUser)));
            int cnt = Convert.ToInt32(DAL.Db.Scalar(@"
                SELECT COUNT(*) FROM dbo.PageAccess a
                INNER JOIN dbo.PageRegistry p ON p.PageID = a.PageID
                WHERE a.RoleID=@r AND p.PageName=@n AND a.CanView=1",
                DAL.Db.P("@r", roleId), DAL.Db.P("@n", pageName)));
            return cnt > 0;
        }
    }
}
