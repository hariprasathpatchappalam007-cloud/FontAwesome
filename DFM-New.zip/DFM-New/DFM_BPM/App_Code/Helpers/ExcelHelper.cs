using System;
using System.Data;
using System.Text;
using System.Web;

namespace DFM_BPM.App_Code.Helpers
{
    public static class ExcelHelper
    {
        public static void ExportToExcel(HttpResponse response, DataTable dt, string filename)
        {
            response.Clear();
            response.ContentType = "application/vnd.ms-excel";
            response.AddHeader("Content-Disposition",
                "attachment; filename=" + filename + ".xls");
            response.ContentEncoding = Encoding.UTF8;
            response.BinaryWrite(Encoding.UTF8.GetPreamble());

            var sb = new StringBuilder();
            // Header row
            foreach (DataColumn col in dt.Columns)
            {
                sb.Append(col.ColumnName.Replace("\t", " ").Replace("\r\n", " "));
                sb.Append('\t');
            }
            sb.AppendLine();
            // Data rows
            foreach (DataRow row in dt.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    string val = item == null || item == DBNull.Value ? "" : item.ToString();
                    val = val.Replace("\t", " ").Replace("\r\n", " ").Replace("\n", " ");
                    sb.Append(val);
                    sb.Append('\t');
                }
                sb.AppendLine();
            }
            response.Write(sb.ToString());
            response.End();
        }
    }
}
