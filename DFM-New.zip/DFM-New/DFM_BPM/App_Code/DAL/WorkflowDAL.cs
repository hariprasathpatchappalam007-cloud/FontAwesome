using System;
using System.Data;

namespace DFM_BPM.App_Code.DAL
{
    /// <summary>
    /// Data access for the PET workflow (local forms, not Oracle).
    /// Hierarchy: Project (BPM) → PET Form → PET Line Items → Approval → BPM CAM data
    /// </summary>
    public static class WorkflowDAL
    {
        // ===================================================================
        // PET FORM CRUD
        // ===================================================================

        public static DataTable GetPetForms(string createdBy = null, string status = null)
        {
            string sql = @"SELECT p.PetFormID, p.PetRefNo, p.ProjectID, p.CapexOpexType,
                                  p.BudgetSourceID, p.Title, p.Status, p.ReviewerUsername,
                                  p.ApproverUsername, p.Version, p.SubmittedDate,
                                  p.ReviewedDate, p.ApprovedDate, p.CreatedBy, p.CreatedDate,
                                  pr.ProjectName
                           FROM dbo.PetForm p
                           LEFT JOIN dbo.BPM_Projects pr ON pr.ProjectID = p.ProjectID
                           WHERE 1=1";
            var ps = new System.Collections.Generic.List<System.Data.SqlClient.SqlParameter>();
            if (!string.IsNullOrEmpty(createdBy)) { sql += " AND p.CreatedBy=@cb"; ps.Add(Db.P("@cb", createdBy)); }
            if (!string.IsNullOrEmpty(status))    { sql += " AND p.Status=@st";   ps.Add(Db.P("@st", status));    }
            sql += " ORDER BY p.PetFormID DESC";
            return Db.Query(sql, ps.ToArray());
        }

        public static DataTable GetPetFormsForApprover(string username)
        {
            return Db.Query(@"SELECT p.PetFormID, p.PetRefNo, p.ProjectID, p.Title, p.Status,
                                     p.CapexOpexType, p.CreatedBy, p.CreatedDate, p.SubmittedDate,
                                     pr.ProjectName
                              FROM dbo.PetForm p
                              LEFT JOIN dbo.BPM_Projects pr ON pr.ProjectID = p.ProjectID
                              WHERE (p.ReviewerUsername=@u OR p.ApproverUsername=@u)
                                AND p.Status IN ('PendingReview','PendingApproval')
                              ORDER BY p.PetFormID DESC",
                Db.P("@u", username));
        }

        public static DataRow GetPetForm(int petFormId)
        {
            return Db.QueryRow(@"SELECT p.*, pr.ProjectName, pr.ProjectManager, pr.ProjectAmount,
                                        pr.CapexID, pr.BusinessArea, pr.ProjectStatus
                                 FROM dbo.PetForm p
                                 LEFT JOIN dbo.BPM_Projects pr ON pr.ProjectID = p.ProjectID
                                 WHERE p.PetFormID=@id",
                Db.P("@id", petFormId));
        }

        public static int CreatePetForm(string projectId, string capexOpexType, string budgetSourceId,
                                        string title, string description, string reviewerUsername,
                                        string approverUsername, string createdBy)
        {
            return Convert.ToInt32(Db.Scalar(@"
                INSERT INTO dbo.PetForm
                    (ProjectID, CapexOpexType, BudgetSourceID, Title, Description,
                     ReviewerUsername, ApproverUsername, Status, CreatedBy)
                OUTPUT INSERTED.PetFormID
                VALUES
                    (@pid, @cot, @bsid, @ti, @de, @rev, @app, 'Draft', @cb)",
                Db.P("@pid", projectId), Db.P("@cot", capexOpexType),
                Db.P("@bsid", budgetSourceId ?? (object)DBNull.Value),
                Db.P("@ti", title ?? ""), Db.P("@de", description ?? ""),
                Db.P("@rev", reviewerUsername ?? (object)DBNull.Value),
                Db.P("@app", approverUsername), Db.P("@cb", createdBy)));
        }

        public static void UpdatePetForm(int petFormId, string projectId, string capexOpexType,
                                         string budgetSourceId, string title, string description,
                                         string reviewerUsername, string approverUsername, string modifiedBy)
        {
            Db.Exec(@"UPDATE dbo.PetForm SET ProjectID=@pid, CapexOpexType=@cot, BudgetSourceID=@bsid,
                      Title=@ti, Description=@de, ReviewerUsername=@rev, ApproverUsername=@app,
                      ModifiedBy=@mb, ModifiedDate=GETDATE()
                      WHERE PetFormID=@id AND Status='Draft'",
                Db.P("@pid", projectId), Db.P("@cot", capexOpexType),
                Db.P("@bsid", budgetSourceId ?? (object)DBNull.Value),
                Db.P("@ti", title ?? ""), Db.P("@de", description ?? ""),
                Db.P("@rev", reviewerUsername ?? (object)DBNull.Value),
                Db.P("@app", approverUsername), Db.P("@mb", modifiedBy), Db.P("@id", petFormId));
        }

        // ===================================================================
        // PET LINE ITEMS
        // ===================================================================

        public static DataTable GetPetLines(int petFormId)
        {
            return Db.Query(@"SELECT LineID, SerialNo, Department, ExpHead, Topic, VendorName,
                                     Description, CostType, Units, UnitPrice, BaseCurrency,
                                     AmtFCY, AmtLCY, ContingencyPct, FinalAmtLCY, GLNumber, Comments
                              FROM dbo.PetLineItem WHERE PetFormID=@id ORDER BY SerialNo",
                Db.P("@id", petFormId));
        }

        public static int SavePetLine(int petFormId, int serialNo, string dept, string expHead,
                                       string topic, string vendor, string description, string costType,
                                       decimal units, decimal unitPrice, string currency,
                                       decimal amtFcy, decimal amtLcy, decimal contingencyPct,
                                       decimal finalAmtLcy, string glNumber, string comments, string createdBy)
        {
            return Convert.ToInt32(Db.Scalar(@"
                INSERT INTO dbo.PetLineItem
                    (PetFormID, SerialNo, Department, ExpHead, Topic, VendorName, Description,
                     CostType, Units, UnitPrice, BaseCurrency, AmtFCY, AmtLCY, ContingencyPct,
                     FinalAmtLCY, GLNumber, Comments, CreatedBy)
                OUTPUT INSERTED.LineID
                VALUES (@fid, @sn, @dep, @eh, @to, @vn, @de, @ct,
                        @un, @up, @cu, @af, @al, @cp, @fl, @gl, @co, @cb)",
                Db.P("@fid", petFormId), Db.P("@sn", serialNo), Db.P("@dep", dept ?? ""),
                Db.P("@eh", expHead ?? ""), Db.P("@to", topic ?? ""), Db.P("@vn", vendor ?? ""),
                Db.P("@de", description ?? ""), Db.P("@ct", costType ?? ""),
                Db.P("@un", units), Db.P("@up", unitPrice), Db.P("@cu", currency ?? "AED"),
                Db.P("@af", amtFcy), Db.P("@al", amtLcy), Db.P("@cp", contingencyPct),
                Db.P("@fl", finalAmtLcy), Db.P("@gl", glNumber ?? (object)DBNull.Value),
                Db.P("@co", comments ?? ""), Db.P("@cb", createdBy)));
        }

        public static void DeletePetLine(int lineId)
        {
            Db.Exec("DELETE FROM dbo.PetLineItem WHERE LineID=@id", Db.P("@id", lineId));
        }

        // ===================================================================
        // WORKFLOW ACTIONS
        // ===================================================================

        public static void SubmitPet(int petFormId, string actionBy, string comments)
        {
            DataRow f = GetPetForm(petFormId);
            if (f == null) return;

            string reviewer = f["ReviewerUsername"] == DBNull.Value ? null : f["ReviewerUsername"].ToString();
            string newStatus = string.IsNullOrEmpty(reviewer) ? "PendingApproval" : "PendingReview";

            Db.Exec(@"UPDATE dbo.PetForm SET Status=@s, SubmittedDate=GETDATE(), Version=Version+1,
                      ModifiedBy=@by, ModifiedDate=GETDATE() WHERE PetFormID=@id",
                Db.P("@s", newStatus), Db.P("@by", actionBy), Db.P("@id", petFormId));

            LogHistory(petFormId, "Submit", actionBy, "Draft", newStatus, comments);

            // Notification
            string target = string.IsNullOrEmpty(reviewer) ? f["ApproverUsername"].ToString() : reviewer;
            string url = "~/Forms/PetWorkflow.aspx?id=" + petFormId;
            UserDAL.SendNotification(target, "PET Pending: " + f["PetRefNo"],
                "A new PET has been submitted for your action.", url, petFormId, "ApprovalRequest");
        }

        public static void ReviewPet(int petFormId, string actionBy, string decision, string comments)
        {
            // decision: Approve (send to approver) | SentBack (return to requestor)
            DataRow f = GetPetForm(petFormId);
            if (f == null) return;
            string newStatus = decision == "Approve" ? "PendingApproval" : "SentBack";

            Db.Exec(@"UPDATE dbo.PetForm SET Status=@s, ReviewedDate=GETDATE(), ReviewComments=@rc,
                      ModifiedBy=@by, ModifiedDate=GETDATE() WHERE PetFormID=@id",
                Db.P("@s", newStatus), Db.P("@rc", comments ?? ""),
                Db.P("@by", actionBy), Db.P("@id", petFormId));

            LogHistory(petFormId, "Review_" + decision, actionBy, "PendingReview", newStatus, comments);

            string target = decision == "Approve"
                ? f["ApproverUsername"].ToString()
                : f["CreatedBy"].ToString();
            UserDAL.SendNotification(target, "PET " + (decision == "Approve" ? "Ready for Approval" : "Sent Back") + ": " + f["PetRefNo"],
                comments, "~/Forms/PetWorkflow.aspx?id=" + petFormId, petFormId,
                decision == "Approve" ? "ApprovalRequest" : "RouteBack");
        }

        public static void ApprovePet(int petFormId, string actionBy, string decision, string comments)
        {
            // decision: Approved | Rejected | SentBack
            DataRow f = GetPetForm(petFormId);
            if (f == null) return;
            string newStatus = decision == "Approved" ? "Approved"
                             : decision == "Rejected" ? "Rejected" : "SentBack";

            Db.Exec(@"UPDATE dbo.PetForm SET Status=@s, ApprovedDate=GETDATE(), ApprovalComments=@ac,
                      ModifiedBy=@by, ModifiedDate=GETDATE() WHERE PetFormID=@id",
                Db.P("@s", newStatus), Db.P("@ac", comments ?? ""),
                Db.P("@by", actionBy), Db.P("@id", petFormId));

            LogHistory(petFormId, "Approve_" + decision, actionBy, "PendingApproval", newStatus, comments);

            UserDAL.SendNotification(f["CreatedBy"].ToString(),
                "PET " + decision + ": " + f["PetRefNo"], comments,
                "~/Forms/PetWorkflow.aspx?id=" + petFormId, petFormId, decision);
        }

        public static void LogHistory(int petFormId, string action, string actionBy, string from, string to, string comments)
        {
            Db.Exec(@"INSERT INTO dbo.PetWorkflowHistory(PetFormID, Action, ActionBy, FromStatus, ToStatus, Comments)
                      VALUES(@f, @a, @by, @fs, @ts, @c)",
                Db.P("@f", petFormId), Db.P("@a", action), Db.P("@by", actionBy),
                Db.P("@fs", from), Db.P("@ts", to), Db.P("@c", comments ?? ""));
        }

        public static DataTable GetHistory(int petFormId)
        {
            return Db.Query(@"SELECT Action, ActionBy, ActionDate, FromStatus, ToStatus, Comments
                              FROM dbo.PetWorkflowHistory WHERE PetFormID=@id ORDER BY HistID",
                Db.P("@id", petFormId));
        }

        // ===================================================================
        // BPM CAM HIERARCHY (from Oracle-synced data)
        // ===================================================================

        public static DataSet GetHierarchy(string projectId)
        {
            return Db.QuerySPMulti("dbo.sp_GetHierarchy",
                Db.P("@ProjectID", projectId ?? (object)DBNull.Value));
        }

        public static DataTable GetBPMPetForProject(string projectId)
        {
            return Db.Query(@"SELECT PETReferenceNo, Description, PETApprovedAmt, BPMLockedAmount,
                                     Utilized, Balance, ProjectID
                              FROM dbo.BPM_PET WHERE ProjectID=@p ORDER BY PETReferenceNo",
                Db.P("@p", projectId));
        }

        public static DataTable GetLPOForProject(string projectId)
        {
            return Db.Query(@"SELECT l.WiName, l.LPONo, l.LPODesc, l.VendorName, l.LCAmount,
                                     l.LPOStatus, l.BudgetAmount, l.AvailableBalance, l.GLNumber
                              FROM dbo.BPM_LPO l
                              INNER JOIN dbo.GLMaster g ON l.GLNumber = g.GLNumber
                              INNER JOIN dbo.BPM_Projects p ON p.CapexID LIKE '%' + g.GLNumber + '%'
                              WHERE p.ProjectID = @pid",
                Db.P("@pid", projectId));
        }

        public static DataTable GetInvoiceForLPO(string lpoNo)
        {
            return Db.Query(@"SELECT WiName, InvoiceNumber, InvoiceType, VendorName,
                                     LCAmount, AMSInvoiceStatus, InvoiceDate
                              FROM dbo.BPM_Invoice WHERE InvoiceRefNo=@n ORDER BY InvoiceDate",
                Db.P("@n", lpoNo));
        }

        // ===================================================================
        // CAPEX/OPEX amounts for a project
        // ===================================================================

        public static DataTable GetCapexAmountsForProject(string projectId)
        {
            return Db.Query(@"SELECT cod.ItemID, cod.ItemDescription, SUM(cod.BudgetedAmount) AS BudgetedAmount,
                                     SUM(cod.UtilizedAmount) AS UtilizedAmount, SUM(cod.LockedAmount) AS LockedAmount,
                                     SUM(cod.AvailableAmount) AS AvailableAmount, SUM(cod.ClaimAmount) AS ClaimAmount
                              FROM dbo.BPM_CapexOpexDetails cod
                              WHERE cod.ProjectID = @pid AND cod.ItemType = 'Capex'
                              GROUP BY cod.ItemID, cod.ItemDescription ORDER BY cod.ItemID",
                Db.P("@pid", projectId));
        }

        public static DataTable GetOpexAmountsForProject(string projectId)
        {
            return Db.Query(@"SELECT cod.ItemID, cod.ItemDescription, SUM(cod.BudgetedAmount) AS BudgetedAmount,
                                     SUM(cod.UtilizedAmount) AS UtilizedAmount, SUM(cod.LockedAmount) AS LockedAmount,
                                     SUM(cod.AvailableAmount) AS AvailableAmount, SUM(cod.ClaimAmount) AS ClaimAmount
                              FROM dbo.BPM_CapexOpexDetails cod
                              WHERE cod.ProjectID = @pid AND cod.ItemType = 'Opex'
                              GROUP BY cod.ItemID, cod.ItemDescription ORDER BY cod.ItemID",
                Db.P("@pid", projectId));
        }

        public static DataTable GetGLAmountsForProject(string projectId)
        {
            return Db.Query(@"SELECT g.GLNumber, g.GLDescription, g.BudgetedAmount,
                                     g.BPMLockedAmount, g.AMSLockedAmount, g.UtilizedAmount, g.BalanceAmount
                              FROM dbo.GLMaster g
                              INNER JOIN dbo.BPM_Projects p ON p.CapexID LIKE '%' + g.GLNumber + '%'
                              WHERE p.ProjectID = @pid",
                Db.P("@pid", projectId));
        }
    }
}
