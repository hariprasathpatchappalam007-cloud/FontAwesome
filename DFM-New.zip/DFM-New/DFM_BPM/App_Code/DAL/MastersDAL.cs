using System;
using System.Data;
using System.Data.SqlClient;

namespace DFM_BPM.App_Code.DAL
{
    /// <summary>
    /// Data access for Oracle-synced master tables:
    /// CapexMaster, OpexMaster, GLMaster, VendorMaster (all read-only in the UI).
    /// </summary>
    public static class MastersDAL
    {
        // ===== CAPEX =====
        public static DataTable GetCapex(string search = null)
        {
            string sql = @"SELECT CapexID, BudgetedAmount, UtilizedAmount, AvailableAmount,
                                  LockedAmount, GLNumbers, LastSyncDate, IsActive
                           FROM dbo.CapexMaster";
            if (!string.IsNullOrWhiteSpace(search))
                sql += " WHERE CapexID LIKE @s OR GLNumbers LIKE @s";
            sql += " ORDER BY CapexID";
            return string.IsNullOrWhiteSpace(search)
                ? Db.Query(sql)
                : Db.Query(sql, Db.P("@s", "%" + search.Trim() + "%"));
        }

        public static DataRow GetCapexById(string capexId)
        {
            return Db.QueryRow(
                "SELECT * FROM dbo.CapexMaster WHERE CapexID = @id",
                Db.P("@id", capexId));
        }

        // ===== OPEX =====
        public static DataTable GetOpex(string search = null)
        {
            string sql = @"SELECT OpexID, BudgetedAmount, UtilizedAmount, AvailableAmount,
                                  LockedAmount, Contracts, LastSyncDate, IsActive
                           FROM dbo.OpexMaster";
            if (!string.IsNullOrWhiteSpace(search))
                sql += " WHERE OpexID LIKE @s OR Contracts LIKE @s";
            sql += " ORDER BY OpexID";
            return string.IsNullOrWhiteSpace(search)
                ? Db.Query(sql)
                : Db.Query(sql, Db.P("@s", "%" + search.Trim() + "%"));
        }

        public static DataRow GetOpexById(string opexId)
        {
            return Db.QueryRow(
                "SELECT * FROM dbo.OpexMaster WHERE OpexID = @id",
                Db.P("@id", opexId));
        }

        // ===== GL =====
        public static DataTable GetGL(string search = null)
        {
            string sql = @"SELECT GLNumber, GLDescription, GLOpenedDate, BudgetedAmount,
                                  BPMLockedAmount, AMSLockedAmount, UtilizedAmount,
                                  BalanceAmount, CapitalizedAmount, InvoiceProcessedAmt, LastSyncDate
                           FROM dbo.GLMaster WHERE IsActive=1";
            if (!string.IsNullOrWhiteSpace(search))
                sql += " AND (GLNumber LIKE @s OR GLDescription LIKE @s)";
            sql += " ORDER BY GLNumber";
            return string.IsNullOrWhiteSpace(search)
                ? Db.Query(sql)
                : Db.Query(sql, Db.P("@s", "%" + search.Trim() + "%"));
        }

        public static DataRow GetGLByNumber(string glNumber)
        {
            return Db.QueryRow(
                "SELECT * FROM dbo.GLMaster WHERE GLNumber = @n",
                Db.P("@n", glNumber));
        }

        // ===== Vendor =====
        public static DataTable GetVendors(string search = null)
        {
            string sql = @"SELECT VendorCode, VendorName, LastSyncDate, IsActive
                           FROM dbo.VendorMaster";
            if (!string.IsNullOrWhiteSpace(search))
                sql += " WHERE VendorName LIKE @s OR VendorCode LIKE @s";
            sql += " ORDER BY VendorName";
            return string.IsNullOrWhiteSpace(search)
                ? Db.Query(sql)
                : Db.Query(sql, Db.P("@s", "%" + search.Trim() + "%"));
        }

        // ===== Dropdown helpers =====
        public static DataTable GetCapexDropdown()
        {
            return Db.Query("SELECT CapexID AS ID, CapexID AS Name FROM dbo.CapexMaster WHERE IsActive=1 ORDER BY CapexID");
        }

        public static DataTable GetOpexDropdown()
        {
            return Db.Query("SELECT OpexID AS ID, OpexID AS Name FROM dbo.OpexMaster WHERE IsActive=1 ORDER BY OpexID");
        }

        public static DataTable GetGLDropdown()
        {
            return Db.Query("SELECT GLNumber AS ID, GLNumber + ' - ' + ISNULL(GLDescription,'') AS Name FROM dbo.GLMaster WHERE IsActive=1 ORDER BY GLNumber");
        }

        public static DataTable GetVendorDropdown()
        {
            return Db.Query("SELECT VendorCode AS ID, VendorName AS Name FROM dbo.VendorMaster WHERE IsActive=1 ORDER BY VendorName");
        }

        // ===== BPM Projects dropdown =====
        public static DataTable GetProjectDropdown()
        {
            return Db.Query(@"SELECT ProjectID AS ID, ProjectID + ' – ' + ISNULL(ProjectName,'') AS Name
                              FROM dbo.BPM_Projects ORDER BY ProjectID");
        }

        public static DataRow GetProjectById(string projectId)
        {
            return Db.QueryRow(
                "SELECT * FROM dbo.BPM_Projects WHERE ProjectID = @id",
                Db.P("@id", projectId));
        }

        // ===== PET Cost types & currencies =====
        public static DataTable GetCostTypes()
        {
            return Db.Query("SELECT Category FROM dbo.PetCostType WHERE IsActive=1 ORDER BY Category");
        }

        public static DataTable GetCurrencies()
        {
            return Db.Query("SELECT Code, Name, RateToLocal FROM dbo.PetCurrency WHERE IsActive=1 ORDER BY Code");
        }

        // ===== Reviewer / Approver users for workflow =====
        public static DataTable GetReviewers()
        {
            return Db.Query(@"SELECT DISTINCT u.Username, u.FullName, u.Email
                              FROM dbo.AppUsers u
                              INNER JOIN dbo.UserRoleAssignments a ON a.Username = u.Username
                              WHERE a.RoleType = 'Reviewer' AND u.IsEnabled = 1
                              ORDER BY u.FullName");
        }

        public static DataTable GetApprovers()
        {
            return Db.Query(@"SELECT DISTINCT u.Username, u.FullName, u.Email
                              FROM dbo.AppUsers u
                              INNER JOIN dbo.UserRoleAssignments a ON a.Username = u.Username
                              WHERE a.RoleType = 'Approver' AND u.IsEnabled = 1
                              ORDER BY u.FullName");
        }
    }
}
