using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;

namespace DFM_BPM.JiraSync
{
    /// <summary>
    /// DFM_BPM JIRA Sync console application.
    /// Fetches issues from JIRA and upserts them into dbo.JiraIssues in DFM_BPM database.
    /// Also updates dbo.JiraConfig with last-run timestamp.
    /// Run via Windows Task Scheduler or manually.
    /// </summary>
    internal class Program
    {
        private static readonly string ConnStr =
            ConfigurationManager.ConnectionStrings["DFM_BPM"].ConnectionString;
        private static readonly string BaseUrl =
            ConfigurationManager.AppSettings["JiraBaseUrl"];
        private static readonly string JiraUser =
            ConfigurationManager.AppSettings["JiraUser"];
        private static readonly string JiraPass =
            ConfigurationManager.AppSettings["JiraPassword"];
        private static readonly int BatchSize =
            int.Parse(ConfigurationManager.AppSettings["BatchSize"] ?? "500");
        private static readonly int MinBatchSize =
            int.Parse(ConfigurationManager.AppSettings["MinBatchSize"] ?? "50");
        private static readonly int HttpTimeoutMs =
            int.Parse(ConfigurationManager.AppSettings["HttpTimeoutSeconds"] ?? "300") * 1000;
        private static readonly int MaxFetchAttempts =
            int.Parse(ConfigurationManager.AppSettings["MaxFetchAttempts"] ?? "3");
        private static readonly string FieldsOverride =
            ConfigurationManager.AppSettings["JiraFields"];
        private static readonly string[] Projects =
            (ConfigurationManager.AppSettings["Projects"] ?? "DMGT,DIBITP").Split(',');

        private static int _inserted, _updated, _failed, _pulled;
        private static string _logFile;

        public static int Main(string[] args)
        {
            DateTime start = DateTime.Now;
            EnsureLogDir();
            _logFile = Path.Combine(
                ConfigurationManager.AppSettings["LogFolder"] ?? "logs",
                "jira_sync_" + start.ToString("yyyyMMdd_HHmmss") + ".log");

            Log("===== DFM_BPM JIRA Sync started at " + start.ToString("yyyy-MM-dd HH:mm:ss") + " =====");
            Log("Projects: " + string.Join(", ", Projects));

            int syncId = StartSyncLog("JiraSync", start);
            try
            {
                ServicePointManager.SecurityProtocol =
                    SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

                foreach (string p in Projects)
                {
                    string proj = p.Trim();
                    if (proj.Length == 0) continue;
                    Log("--- Syncing project: " + proj + " ---");
                    SyncProject(proj);
                }

                DateTime end = DateTime.Now;
                EndSyncLog(syncId, end, "Success", null);
                UpdateJiraConfig(end);
                Log(string.Format("===== Completed. Pulled={0}, Inserted={1}, Updated={2}, Failed={3}. Duration={4} =====",
                    _pulled, _inserted, _updated, _failed, (end - start)));
                return 0;
            }
            catch (Exception ex)
            {
                Log("FATAL: " + ex);
                EndSyncLog(syncId, DateTime.Now, "Failed", ex.Message);
                return 1;
            }
        }

        // ====================================================================
        // Streaming sync
        // ====================================================================
        private static void SyncProject(string projectKey)
        {
            int startAt = 0;
            int total = int.MaxValue;
            int currentBatch = BatchSize;

            string defaultFields = "summary,status,issuetype,priority,project,created,updated,duedate,assignee,reporter,issuelinks";
            string fields = FieldsOverride == null ? defaultFields : FieldsOverride;

            while (startAt < total)
            {
                string jql = "project=" + projectKey + " ORDER BY updated DESC";

                string body = null;
                for (int attempt = 1; attempt <= MaxFetchAttempts && body == null; attempt++)
                {
                    try
                    {
                        body = JiraSearch(jql, startAt, currentBatch, fields);
                    }
                    catch (WebException wex)
                    {
                        Log(string.Format("  Fetch attempt {0}/{1} failed for {2} startAt={3}: {4} [{5}]",
                            attempt, MaxFetchAttempts, projectKey, startAt, wex.Message, wex.Status));
                        bool isTimeout = wex.Status == WebExceptionStatus.Timeout
                                      || wex.Status == WebExceptionStatus.ReceiveFailure;
                        if (attempt >= MaxFetchAttempts) break;
                        if (isTimeout && currentBatch > MinBatchSize)
                            currentBatch = Math.Max(MinBatchSize, currentBatch / 2);
                        try { System.Threading.Thread.Sleep(2000 * attempt); } catch { }
                    }
                    catch (Exception ex)
                    {
                        Log("  Fetch failed (non-retryable): " + ex.Message); break;
                    }
                }

                if (body == null) { startAt += currentBatch; continue; }

                var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                Dictionary<string, object> obj;
                try { obj = ser.Deserialize<Dictionary<string, object>>(body); }
                catch (Exception ex) { Log("  Parse failed: " + ex.Message); break; }
                if (obj == null || !obj.ContainsKey("issues")) break;

                var issues = obj["issues"] as ArrayList;
                if (issues == null || issues.Count == 0) break;

                total = obj.ContainsKey("total") ? Convert.ToInt32(obj["total"]) : issues.Count;
                Log(string.Format("  startAt={0} fetched={1} total={2}", startAt, issues.Count, total));

                using (var con = new SqlConnection(ConnStr))
                {
                    con.Open();
                    using (var cmd = BuildUpsertCommand(con))
                    {
                        foreach (Dictionary<string, object> issue in issues)
                        {
                            try
                            {
                                int r = UpsertIssue(cmd, issue, projectKey);
                                if (r == 1) _inserted++; else _updated++;
                                _pulled++;
                            }
                            catch (Exception ex)
                            {
                                _failed++;
                                string k = issue.ContainsKey("key") ? issue["key"]?.ToString() : "?";
                                Log("  Upsert failed for " + k + ": " + ex.Message);
                            }
                        }
                    }
                }

                int fetched = issues.Count;
                startAt += fetched;
                issues.Clear(); obj = null; body = null;
                if (startAt >= total || fetched < currentBatch) break;
                if (currentBatch < BatchSize) currentBatch = Math.Min(BatchSize, currentBatch * 2);
            }
        }

        // ====================================================================
        // Build reusable upsert command
        // ====================================================================
        private static SqlCommand BuildUpsertCommand(SqlConnection con)
        {
            var cmd = con.CreateCommand();
            cmd.CommandTimeout = 150;
            cmd.CommandText = @"
SET NOCOUNT ON;
IF EXISTS (SELECT 1 FROM dbo.JiraIssues WHERE JiraKey=@key)
BEGIN
    UPDATE dbo.JiraIssues
       SET Summary=@summary, Status=@status, IssueType=@itype, Priority=@priority,
           ProjectKey=@proj, ProjectName=@projName,
           Assignee=@assignee, Reporter=@reporter,
           DueDate=@due, JiraUpdated=@upd, SyncDate=GETDATE()
     WHERE JiraKey=@key;
    SELECT 0;
END
ELSE
BEGIN
    INSERT INTO dbo.JiraIssues
        (JiraKey, Summary, Status, IssueType, Priority, ProjectKey, ProjectName,
         Assignee, Reporter, DueDate, JiraCreated, JiraUpdated, SyncDate)
    VALUES
        (@key, @summary, @status, @itype, @priority, @proj, @projName,
         @assignee, @reporter, @due, @cre, @upd, GETDATE());
    SELECT 1;
END";
            cmd.Parameters.Add("@key",      SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@summary",  SqlDbType.NVarChar, 1000);
            cmd.Parameters.Add("@status",   SqlDbType.NVarChar, 100);
            cmd.Parameters.Add("@itype",    SqlDbType.NVarChar, 100);
            cmd.Parameters.Add("@priority", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@proj",     SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@projName", SqlDbType.NVarChar, 300);
            cmd.Parameters.Add("@assignee", SqlDbType.NVarChar, 200);
            cmd.Parameters.Add("@reporter", SqlDbType.NVarChar, 200);
            cmd.Parameters.Add("@due",      SqlDbType.DateTime);
            cmd.Parameters.Add("@cre",      SqlDbType.DateTime);
            cmd.Parameters.Add("@upd",      SqlDbType.DateTime);
            return cmd;
        }

        private static int UpsertIssue(SqlCommand cmd, Dictionary<string, object> issue, string projectKey)
        {
            string key = issue.ContainsKey("key") && issue["key"] != null ? issue["key"].ToString() : null;
            if (string.IsNullOrEmpty(key)) throw new InvalidOperationException("Issue missing 'key'");

            var fields = issue["fields"] as Dictionary<string, object>;
            if (fields == null) throw new InvalidOperationException("Issue " + key + " has no 'fields'");

            cmd.Parameters["@key"].Value      = key;
            cmd.Parameters["@summary"].Value  = S(Get(fields, "summary"));
            cmd.Parameters["@status"].Value   = S(GetNested(fields, "status", "name"));
            cmd.Parameters["@itype"].Value    = S(GetNested(fields, "issuetype", "name"));
            cmd.Parameters["@priority"].Value = S(GetNested(fields, "priority", "name"));
            cmd.Parameters["@proj"].Value     = S(GetNested(fields, "project", "key") ?? projectKey);
            cmd.Parameters["@projName"].Value = S(GetNested(fields, "project", "name"));
            cmd.Parameters["@assignee"].Value = S(GetNested(fields, "assignee", "displayName"));
            cmd.Parameters["@reporter"].Value = S(GetNested(fields, "reporter", "displayName"));
            cmd.Parameters["@due"].Value      = (object)ParseDate(Get(fields, "duedate")) ?? DBNull.Value;
            cmd.Parameters["@cre"].Value      = (object)ParseDate(Get(fields, "created"))  ?? DBNull.Value;
            cmd.Parameters["@upd"].Value      = (object)ParseDate(Get(fields, "updated"))  ?? DBNull.Value;

            return Convert.ToInt32(cmd.ExecuteScalar());
        }

        // ====================================================================
        // JIRA HTTP helper
        // ====================================================================
        private static string JiraSearch(string jql, int startAt, int maxResults, string fields)
        {
            string url = BaseUrl.TrimEnd('/') + "/rest/api/2/search?jql="
                + Uri.EscapeDataString(jql)
                + "&startAt=" + startAt
                + "&maxResults=" + maxResults;
            if (!string.IsNullOrEmpty(fields))
                url += "&fields=" + Uri.EscapeDataString(fields);

            var req = (HttpWebRequest)WebRequest.Create(url);
            req.Method      = "GET";
            req.Timeout     = HttpTimeoutMs;
            req.ReadWriteTimeout = HttpTimeoutMs;
            req.Accept      = "application/json";
            req.Headers["Authorization"] = "Basic " +
                Convert.ToBase64String(Encoding.ASCII.GetBytes(JiraUser + ":" + JiraPass));

            using (var resp = (HttpWebResponse)req.GetResponse())
            using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                return sr.ReadToEnd();
        }

        // ====================================================================
        // SyncLog helpers
        // ====================================================================
        private static int StartSyncLog(string syncType, DateTime start)
        {
            try
            {
                using (var con = new SqlConnection(ConnStr))
                {
                    con.Open();
                    var cmd = con.CreateCommand();
                    cmd.CommandText = @"INSERT INTO dbo.SyncLog (SyncType, StartTime, Status)
                                        VALUES (@t, @s, 'Running');
                                        SELECT SCOPE_IDENTITY();";
                    cmd.Parameters.AddWithValue("@t", syncType);
                    cmd.Parameters.AddWithValue("@s", start);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            catch { return 0; }
        }

        private static void EndSyncLog(int id, DateTime end, string status, string error)
        {
            if (id == 0) return;
            try
            {
                using (var con = new SqlConnection(ConnStr))
                {
                    con.Open();
                    var cmd = con.CreateCommand();
                    cmd.CommandText = @"UPDATE dbo.SyncLog
                                        SET EndTime=@e, Status=@st, RecordsInserted=@ins,
                                            RecordsUpdated=@upd, ErrorMessage=@err
                                        WHERE SyncLogID=@id";
                    cmd.Parameters.AddWithValue("@e",   end);
                    cmd.Parameters.AddWithValue("@st",  status);
                    cmd.Parameters.AddWithValue("@ins", _inserted);
                    cmd.Parameters.AddWithValue("@upd", _updated);
                    cmd.Parameters.AddWithValue("@err", (object)error ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@id",  id);
                    cmd.ExecuteNonQuery();
                }
            }
            catch { }
        }

        private static void UpdateJiraConfig(DateTime syncDate)
        {
            try
            {
                using (var con = new SqlConnection(ConnStr))
                {
                    con.Open();
                    var cmd = con.CreateCommand();
                    cmd.CommandText = @"IF EXISTS (SELECT 1 FROM dbo.JiraConfig WHERE ConfigKey='LastJiraSyncDate')
                                            UPDATE dbo.JiraConfig SET ConfigValue=@v, UpdatedDate=GETDATE() WHERE ConfigKey='LastJiraSyncDate'
                                        ELSE
                                            INSERT INTO dbo.JiraConfig (ConfigKey, ConfigValue, UpdatedDate)
                                            VALUES ('LastJiraSyncDate', @v, GETDATE())";
                    cmd.Parameters.AddWithValue("@v", syncDate.ToString("yyyy-MM-dd HH:mm:ss"));
                    cmd.ExecuteNonQuery();
                }
            }
            catch { }
        }

        // ====================================================================
        // Logging
        // ====================================================================
        private static void EnsureLogDir()
        {
            string dir = ConfigurationManager.AppSettings["LogFolder"] ?? "logs";
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
        }

        private static void Log(string msg)
        {
            string line = "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + msg;
            Console.WriteLine(line);
            try { File.AppendAllText(_logFile ?? "jira_sync.log", line + Environment.NewLine); }
            catch { }
        }

        // ====================================================================
        // JSON field extractors
        // ====================================================================
        private static string Get(Dictionary<string, object> d, string key)
        {
            object v; if (d.TryGetValue(key, out v) && v != null) return v.ToString(); return null;
        }

        private static string GetNested(Dictionary<string, object> d, string key, string subKey)
        {
            object v;
            if (!d.TryGetValue(key, out v) || v == null) return null;
            var inner = v as Dictionary<string, object>;
            if (inner == null) return null;
            object sv; return inner.TryGetValue(subKey, out sv) && sv != null ? sv.ToString() : null;
        }

        private static DateTime? ParseDate(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            DateTime dt; return DateTime.TryParse(s, out dt) ? (DateTime?)dt : null;
        }

        private static object S(string s) => string.IsNullOrEmpty(s) ? (object)DBNull.Value : s;
    }
}
