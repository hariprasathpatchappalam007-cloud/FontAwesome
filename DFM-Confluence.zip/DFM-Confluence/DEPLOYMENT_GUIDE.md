# CET Portfolio Financial Tracker - Deployment Guide

## Architecture Overview

```
┌─────────────────┐       ┌──────────────────┐       ┌──────────────┐
│   Confluence    │──────▶│   .NET Web API   │──────▶│  SQL Server  │
│  (HTML Macro)   │  HTTP │   (IIS Hosted)   │  ADO  │   Database   │
│                 │◀──────│                  │◀──────│              │
└─────────────────┘       └──────────────────┘       └──────────────┘
        │                         │
        │                         │
        ▼                         ▼
┌─────────────────┐       ┌──────────────────┐
│  JIRA (Login &  │       │  File Storage    │
│  Project Data)  │       │  (Attachments)   │
└─────────────────┘       └──────────────────┘
```

## File Structure

```
DFM-Confluence/
├── Database/
│   ├── 01_CreateDatabase.sql          -- Database schema
│   └── 02_StoredProcedures.sql        -- All stored procedures
│
├── API/
│   └── CETFinTracker.API/
│       ├── App_Start/WebApiConfig.cs  -- Web API routing & CORS
│       ├── Controllers/               -- API Controllers
│       │   ├── CapexController.cs
│       │   ├── OpexController.cs
│       │   ├── ProjectController.cs
│       │   ├── SpendRequestController.cs
│       │   ├── BudgetLineItemController.cs
│       │   ├── InvoiceController.cs
│       │   ├── DashboardController.cs
│       │   ├── UserController.cs
│       │   └── LookupController.cs
│       ├── DataAccess/DbHelper.cs     -- Database helper
│       ├── Models/                    -- Data models
│       ├── Web.config                 -- Configuration
│       ├── Global.asax
│       └── CETFinTracker.API.csproj
│
├── Confluence/
│   ├── cet-fintracker.html            -- Main HTML (paste in HTML macro)
│   ├── css/
│   │   └── styles.css                 -- Application styles
│   └── js/
│       ├── config.js                  -- Configuration (UPDATE THIS)
│       ├── api-service.js             -- API communication layer
│       └── app.js                     -- Main application logic
│
└── Requirement/                       -- Source requirement files
```

---

## Step-by-Step Deployment

### STEP 1: SQL Server Setup

1. Open SQL Server Management Studio (SSMS)
2. Execute `Database/01_CreateDatabase.sql` - Creates the database and tables
3. Execute `Database/02_StoredProcedures.sql` - Creates all stored procedures
4. Verify the database `CETFinTracker` is created with all tables

### STEP 2: .NET API Setup (Visual Studio 2017)

1. Open the solution in Visual Studio 2017
2. Install NuGet packages:
   ```
   Install-Package Microsoft.AspNet.WebApi -Version 5.2.7
   Install-Package Microsoft.AspNet.WebApi.Cors -Version 5.2.7
   Install-Package Newtonsoft.Json -Version 12.0.3
   ```
3. Update `Web.config`:
   - Change the connection string `Server=YOUR_SERVER` to your SQL Server instance
   - Update JIRA/Confluence URLs in `<appSettings>`
4. Build the solution (Ctrl+Shift+B)
5. Publish to a folder

### STEP 3: IIS Deployment

1. Open IIS Manager
2. Create a new Application Pool:
   - Name: `CETFinTrackerPool`
   - .NET CLR Version: `v4.0`
   - Managed Pipeline Mode: `Integrated`
3. Create a new Website or Application:
   - Physical Path: Point to published API folder
   - Application Pool: `CETFinTrackerPool`
   - Binding: `https://your-server/CETFinTrackerAPI`
4. Ensure the App Pool identity has:
   - Read access to the application folder
   - SQL Server login permissions (if using Windows Auth)

### STEP 4: Host Static Files (JS/CSS)

Option A - Same IIS Server:
1. Create a virtual directory in IIS: `https://your-server/CETFinTracker/`
2. Point to the `Confluence/` folder
3. Ensure static file serving is enabled

Option B - Separate Web Server:
1. Copy `Confluence/js/` and `Confluence/css/` to any web-accessible location
2. Ensure CORS headers allow access from your Confluence domain

### STEP 5: Update Configuration

Edit `Confluence/js/config.js`:
```javascript
var CETConfig = {
    apiBaseUrl: 'https://your-actual-server/CETFinTrackerAPI/api',  // <-- UPDATE
    jiraBaseUrl: 'https://your-jira.atlassian.net',                 // <-- UPDATE
    confluenceBaseUrl: 'https://your-confluence.atlassian.net',     // <-- UPDATE
    ...
};
```

### STEP 6: Confluence Page Setup

1. Log in to Confluence as Admin
2. Verify HTML Macro is enabled:
   - Go to: Admin > Manage Apps > HTML Macro (under System)
   - Ensure it's enabled
3. Create a new page (or edit existing)
4. Click **Insert** > **Other Macros** > **HTML**
5. Open `Confluence/cet-fintracker.html`
6. **Update the `<link>` and `<script>` paths** to your hosted file URLs:
   ```html
   <link rel="stylesheet" href="https://your-server/CETFinTracker/css/styles.css" />
   ...
   <script src="https://your-server/CETFinTracker/js/config.js"></script>
   <script src="https://your-server/CETFinTracker/js/api-service.js"></script>
   <script src="https://your-server/CETFinTracker/js/app.js"></script>
   ```
7. Paste the full HTML content into the HTML macro
8. Save the page

---

## API Endpoints Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/capex/getall` | Get all CAPEX records |
| GET | `/api/capex/get/{id}` | Get CAPEX by ID |
| POST | `/api/capex/save` | Create/Update CAPEX |
| POST | `/api/capex/import` | Bulk import CAPEX from CSV |
| GET | `/api/opex/getall` | Get all OPEX records |
| POST | `/api/opex/save` | Create/Update OPEX |
| POST | `/api/opex/import` | Bulk import OPEX from CSV |
| GET | `/api/project/getall` | Get all projects |
| POST | `/api/project/save` | Register project |
| GET | `/api/spendrequest/getall` | Get spend requests (with filters) |
| POST | `/api/spendrequest/save` | Create/Update spend request |
| POST | `/api/spendrequest/submit` | Submit for review |
| POST | `/api/spendrequest/review` | Reviewer action |
| POST | `/api/spendrequest/approve` | Approver action |
| GET | `/api/budgetlineitem/getbyrequest/{id}` | Get line items |
| POST | `/api/budgetlineitem/save` | Save line item |
| GET | `/api/invoice/getbyrequest/{id}` | Get invoices |
| POST | `/api/invoice/save` | Save invoice |
| GET | `/api/dashboard/summary` | Dashboard data |
| GET | `/api/user/getbyjira/{id}` | Get user by JIRA ID |
| GET | `/api/user/reviewers` | List reviewers |
| GET | `/api/user/approvers` | List approvers |
| GET | `/api/lookup/departments` | Get departments |
| GET | `/api/lookup/costtypes` | Get cost types |
| GET | `/api/lookup/unittypes` | Get unit types |

---

## Workflow

```
Requestor                    Reviewer                   Approver
    │                            │                          │
    ├── 1. Register Project      │                          │
    │                            │                          │
    ├── 2. Create Spend Request  │                          │
    │       (Draft)              │                          │
    │                            │                          │
    ├── 3. Submit to Reviewer ──▶│                          │
    │       (Submitted)          │                          │
    │                            ├── 4. Review ────────────▶│
    │                            │     (Reviewed)           │
    │                            │                          ├── 5. Approve
    │                            │                          │     (Approved)
    │                            │                          │
    ├── 6. Upload Budget Line Items                         │
    │                            │                          │
    ├── 7. Upload Invoices       │                          │
    │                            │                          │
    └────────────────────────────┴──────────────────────────┘
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| CORS errors in browser console | Ensure IIS CORS headers are configured in Web.config |
| API returns 500 error | Check SQL connection string in Web.config |
| HTML macro not rendering | Verify HTML macro is enabled in Confluence admin |
| User not detected | Ensure `AJS.params.remoteUser` is available in Confluence |
| CSV import fails | Ensure CSV format matches expected columns |

---

## Security Notes

- The API uses Windows Authentication for SQL Server by default
- CORS is configured to allow all origins (`*`) - restrict this in production to your Confluence domain only
- File uploads should be validated for type and size on the server side
- Consider adding API key authentication for the endpoints
