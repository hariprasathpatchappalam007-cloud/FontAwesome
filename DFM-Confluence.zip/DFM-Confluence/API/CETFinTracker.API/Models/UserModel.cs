using System;

namespace CETFinTracker.API.Models
{
    public class UserModel
    {
        public int UserId { get; set; }
        public string JiraUserId { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public string Department { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public bool IsActive { get; set; }
    }

    public class ReviewerApproverModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string RoleType { get; set; }
        public int DepartmentId { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public string DepartmentName { get; set; }
    }
}
