using System;

namespace CETFinTracker.API.Models
{
    public class CapexModel
    {
        public int CapexId { get; set; }
        public string Type { get; set; }
        public string BudgetId { get; set; }
        public string Description { get; set; }
        public decimal Budget { get; set; }
        public decimal Utilization { get; set; }
        public decimal AvailableBudget { get; set; }
        public decimal LockedAmt { get; set; }
        public decimal BudgetAfterLocked { get; set; }
        public decimal ClaimAmt { get; set; }
        public decimal NetBalance { get; set; }
        public bool IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
