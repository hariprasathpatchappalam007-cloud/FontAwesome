using System;

namespace CETFinTracker.API.Models
{
    public class InvoiceModel
    {
        public int InvoiceId { get; set; }
        public int SpendRequestId { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime InvoiceDate { get; set; }
        public string VendorName { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public string Currency { get; set; }
        public decimal AmountLCY { get; set; }
        public string Status { get; set; }
        public string AttachmentPath { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
