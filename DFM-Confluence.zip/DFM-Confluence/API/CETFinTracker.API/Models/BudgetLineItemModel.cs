using System;

namespace CETFinTracker.API.Models
{
    public class BudgetLineItemModel
    {
        public int LineItemId { get; set; }
        public int SpendRequestId { get; set; }
        public int LineNo { get; set; }
        public string Description { get; set; }
        public string CostType { get; set; }
        public string UnitType { get; set; }
        public decimal Units { get; set; }
        public decimal UnitPrice { get; set; }
        public string BaseCurrency { get; set; }
        public decimal AmountFCY { get; set; }
        public decimal AmountLCY { get; set; }
        public decimal ContingencyPercent { get; set; }
        public decimal FinalAmountLCY { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
