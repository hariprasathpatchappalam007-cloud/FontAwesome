using System;

namespace CETFinTracker.API.Models
{
    public class SpendRequestModel
    {
        public int SpendRequestId { get; set; }
        public int ProjectId { get; set; }
        public int SerialNo { get; set; }
        public DateTime RequestDate { get; set; }
        public int DepartmentId { get; set; }
        public string AutoId { get; set; }
        public string ExpenseHead { get; set; }
        public string Topic { get; set; }
        public string Vendor { get; set; }
        public string Description { get; set; }
        public string CostType { get; set; }
        public string UnitType { get; set; }
        public decimal Units { get; set; }
        public decimal UnitPrice { get; set; }
        public string BaseCurrency { get; set; }
        public decimal AmountFCY { get; set; }
        public decimal AmountLCY { get; set; }
        public decimal ContingencyPercent { get; set; }
        public decimal FinalAmountLCY { get; set; }
        public int YearlyRecurrence { get; set; }
        public string Status { get; set; }
        public string ProjectName { get; set; }
        public string BudgetSource { get; set; }
        public string DepartmentName { get; set; }
        public string CreatedByName { get; set; }
        public DateTime? SubmittedDate { get; set; }
        public DateTime? ReviewedDate { get; set; }
        public DateTime? ApprovedDate { get; set; }
    }

    public class SpendRequestSubmitModel
    {
        public int SpendRequestId { get; set; }
        public int UserId { get; set; }
    }

    public class ReviewApproveModel
    {
        public int SpendRequestId { get; set; }
        public int UserId { get; set; }
        public string Action { get; set; }
        public string Comments { get; set; }
    }
}
