using System;

namespace CETFinTracker.API.Models
{
    public class DashboardModel
    {
        public decimal TotalCapexBudget { get; set; }
        public decimal TotalCapexUtilization { get; set; }
        public decimal TotalCapexAvailable { get; set; }
        public decimal TotalOpexBudget { get; set; }
        public decimal TotalOpexUtilization { get; set; }
        public decimal TotalOpexAvailable { get; set; }
    }

    public class StatusCount
    {
        public string Status { get; set; }
        public int Count { get; set; }
    }

    public class PendingAction
    {
        public int SpendRequestId { get; set; }
        public string Topic { get; set; }
        public decimal FinalAmountLCY { get; set; }
        public string Status { get; set; }
        public string ProjectName { get; set; }
    }
}
