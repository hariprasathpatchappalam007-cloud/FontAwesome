using System;

namespace CETFinTracker.API.Models
{
    public class ProjectModel
    {
        public int ProjectId { get; set; }
        public string ProjectType { get; set; }
        public string JiraProjectKey { get; set; }
        public string ProjectName { get; set; }
        public string BudgetSource { get; set; }
        public int? BudgetReferenceId { get; set; }
        public int RequestorId { get; set; }
        public int? ReviewerId { get; set; }
        public int? ApproverId { get; set; }
        public string Status { get; set; }
        public string RequestorName { get; set; }
        public string ReviewerName { get; set; }
        public string ApproverName { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
