using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/spendrequest")]
    public class SpendRequestController : ApiController
    {
        [HttpGet]
        [Route("getall")]
        public IHttpActionResult GetAll(int? projectId = null, string status = null, int? userId = null, string roleType = null)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@ProjectId", projectId },
                    { "@Status", status },
                    { "@UserId", userId },
                    { "@RoleType", roleType }
                };
                DataTable dt = DbHelper.ExecuteQuery("usp_SpendRequest_GetAll", parameters);
                var list = new List<SpendRequestModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(MapSpendRequest(row));
                }
                return Ok(ApiResponse<List<SpendRequestModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<SpendRequestModel>>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("save")]
        public IHttpActionResult Save([FromBody] SpendRequestModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@SpendRequestId", model.SpendRequestId > 0 ? (object)model.SpendRequestId : null },
                    { "@ProjectId", model.ProjectId },
                    { "@DepartmentId", model.DepartmentId },
                    { "@ExpenseHead", model.ExpenseHead },
                    { "@Topic", model.Topic },
                    { "@Vendor", model.Vendor },
                    { "@Description", model.Description },
                    { "@CostType", model.CostType },
                    { "@UnitType", model.UnitType },
                    { "@Units", model.Units },
                    { "@UnitPrice", model.UnitPrice },
                    { "@BaseCurrency", model.BaseCurrency },
                    { "@ContingencyPercent", model.ContingencyPercent },
                    { "@YearlyRecurrence", model.YearlyRecurrence },
                    { "@UserId", 1 } // Will be replaced by logged-in user
                };

                DataTable dt = DbHelper.ExecuteQuery("usp_SpendRequest_Upsert", parameters);
                int newId = Convert.ToInt32(dt.Rows[0]["Id"]);
                return Ok(ApiResponse<int>.Ok(newId, "Spend request saved successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<int>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("submit")]
        public IHttpActionResult Submit([FromBody] SpendRequestSubmitModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@SpendRequestId", model.SpendRequestId },
                    { "@UserId", model.UserId }
                };
                DbHelper.ExecuteNonQuery("usp_SpendRequest_Submit", parameters);
                return Ok(ApiResponse.Ok("Submitted for review"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("review")]
        public IHttpActionResult Review([FromBody] ReviewApproveModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@SpendRequestId", model.SpendRequestId },
                    { "@UserId", model.UserId },
                    { "@Action", model.Action },
                    { "@Comments", model.Comments }
                };
                DbHelper.ExecuteNonQuery("usp_SpendRequest_Review", parameters);
                return Ok(ApiResponse.Ok("Review action completed"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("approve")]
        public IHttpActionResult Approve([FromBody] ReviewApproveModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@SpendRequestId", model.SpendRequestId },
                    { "@UserId", model.UserId },
                    { "@Action", model.Action },
                    { "@Comments", model.Comments }
                };
                DbHelper.ExecuteNonQuery("usp_SpendRequest_Approve", parameters);
                return Ok(ApiResponse.Ok("Approval action completed"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse.Fail(ex.Message));
            }
        }

        private SpendRequestModel MapSpendRequest(DataRow row)
        {
            return new SpendRequestModel
            {
                SpendRequestId = Convert.ToInt32(row["SpendRequestId"]),
                ProjectId = Convert.ToInt32(row["ProjectId"]),
                SerialNo = Convert.ToInt32(row["SerialNo"]),
                RequestDate = Convert.ToDateTime(row["RequestDate"]),
                DepartmentId = Convert.ToInt32(row["DepartmentId"]),
                AutoId = row["AutoId"].ToString(),
                ExpenseHead = row["ExpenseHead"].ToString(),
                Topic = row["Topic"].ToString(),
                Vendor = row["Vendor"].ToString(),
                Description = row["Description"].ToString(),
                CostType = row["CostType"].ToString(),
                UnitType = row["UnitType"].ToString(),
                Units = Convert.ToDecimal(row["Units"]),
                UnitPrice = Convert.ToDecimal(row["UnitPrice"]),
                BaseCurrency = row["BaseCurrency"].ToString(),
                AmountFCY = Convert.ToDecimal(row["AmountFCY"]),
                AmountLCY = Convert.ToDecimal(row["AmountLCY"]),
                ContingencyPercent = Convert.ToDecimal(row["ContingencyPercent"]),
                FinalAmountLCY = Convert.ToDecimal(row["FinalAmountLCY"]),
                YearlyRecurrence = Convert.ToInt32(row["YearlyRecurrence"]),
                Status = row["Status"].ToString(),
                ProjectName = row["ProjectName"].ToString(),
                BudgetSource = row["BudgetSource"].ToString(),
                DepartmentName = row["DepartmentName"].ToString(),
                CreatedByName = row["CreatedByName"].ToString()
            };
        }
    }
}
