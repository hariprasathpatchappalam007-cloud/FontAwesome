using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/lookup")]
    public class LookupController : ApiController
    {
        [HttpGet]
        [Route("departments")]
        public IHttpActionResult GetDepartments()
        {
            try
            {
                DataTable dt = DbHelper.ExecuteQuery("usp_Department_GetAll");
                var list = new List<object>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(new
                    {
                        DepartmentId = row["DepartmentId"],
                        DepartmentCode = row["DepartmentCode"].ToString(),
                        DepartmentName = row["DepartmentName"].ToString()
                    });
                }
                return Ok(ApiResponse<List<object>>.Ok(list));
            }
            catch
            {
                // Fallback hardcoded departments
                var departments = new List<object>
                {
                    new { DepartmentId = 1, DepartmentCode = "GOV", DepartmentName = "Governance" },
                    new { DepartmentId = 2, DepartmentCode = "COR", DepartmentName = "Core" },
                    new { DepartmentId = 3, DepartmentCode = "EIS", DepartmentName = "EIS" },
                    new { DepartmentId = 4, DepartmentCode = "CRM", DepartmentName = "CRM" },
                    new { DepartmentId = 5, DepartmentCode = "AE", DepartmentName = "EA&I" },
                    new { DepartmentId = 6, DepartmentCode = "RSK", DepartmentName = "Risk" },
                    new { DepartmentId = 7, DepartmentCode = "CET", DepartmentName = "CET" },
                    new { DepartmentId = 8, DepartmentCode = "BUS", DepartmentName = "Business" },
                    new { DepartmentId = 9, DepartmentCode = "CIO", DepartmentName = "CIO Office" },
                    new { DepartmentId = 10, DepartmentCode = "CTO", DepartmentName = "CTO" },
                    new { DepartmentId = 11, DepartmentCode = "RTB", DepartmentName = "RTB" },
                    new { DepartmentId = 12, DepartmentCode = "TEST", DepartmentName = "Test Gov." }
                };
                return Ok(ApiResponse<List<object>>.Ok(departments));
            }
        }

        [HttpGet]
        [Route("roles")]
        public IHttpActionResult GetRoles()
        {
            var roles = new List<object>
            {
                new { RoleId = 1, RoleName = "Administrator" },
                new { RoleId = 2, RoleName = "Reviewer" },
                new { RoleId = 3, RoleName = "Approver" },
                new { RoleId = 4, RoleName = "Requestor" }
            };
            return Ok(ApiResponse<List<object>>.Ok(roles));
        }

        [HttpGet]
        [Route("costtypes")]
        public IHttpActionResult GetCostTypes()
        {
            var types = new List<string>
            {
                "UAT Functional Testing", "Development", "Design & ReEngineering",
                "Infrastructure", "Licensing", "Consultancy", "Support & Maintenance",
                "Training", "Hardware", "Software", "Cloud Services", "Other"
            };
            return Ok(ApiResponse<List<string>>.Ok(types));
        }

        [HttpGet]
        [Route("unittypes")]
        public IHttpActionResult GetUnitTypes()
        {
            var types = new List<string>
            {
                "Man Days", "Man Months", "Hours", "Units", "Licenses", "Instances", "Per Month", "Lump Sum"
            };
            return Ok(ApiResponse<List<string>>.Ok(types));
        }

        [HttpGet]
        [Route("currencies")]
        public IHttpActionResult GetCurrencies()
        {
            var currencies = new List<object>
            {
                new { Code = "AED", Name = "UAE Dirham" },
                new { Code = "USD", Name = "US Dollar" },
                new { Code = "EUR", Name = "Euro" },
                new { Code = "GBP", Name = "British Pound" },
                new { Code = "INR", Name = "Indian Rupee" }
            };
            return Ok(ApiResponse<List<object>>.Ok(currencies));
        }
    }
}
