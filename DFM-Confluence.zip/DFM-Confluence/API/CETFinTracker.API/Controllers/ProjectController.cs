using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/project")]
    public class ProjectController : ApiController
    {
        [HttpGet]
        [Route("getall")]
        public IHttpActionResult GetAll(int? userId = null)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@UserId", userId } };
                DataTable dt = DbHelper.ExecuteQuery("usp_Project_GetAll", parameters);
                var list = new List<ProjectModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(new ProjectModel
                    {
                        ProjectId = Convert.ToInt32(row["ProjectId"]),
                        ProjectType = row["ProjectType"].ToString(),
                        JiraProjectKey = row["JiraProjectKey"].ToString(),
                        ProjectName = row["ProjectName"].ToString(),
                        BudgetSource = row["BudgetSource"].ToString(),
                        BudgetReferenceId = row["BudgetReferenceId"] != DBNull.Value ? Convert.ToInt32(row["BudgetReferenceId"]) : (int?)null,
                        RequestorId = Convert.ToInt32(row["RequestorId"]),
                        Status = row["Status"].ToString(),
                        RequestorName = row["RequestorName"].ToString(),
                        ReviewerName = row["ReviewerName"].ToString(),
                        ApproverName = row["ApproverName"].ToString(),
                        CreatedDate = Convert.ToDateTime(row["CreatedDate"])
                    });
                }
                return Ok(ApiResponse<List<ProjectModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<ProjectModel>>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("save")]
        public IHttpActionResult Save([FromBody] ProjectModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@ProjectId", model.ProjectId > 0 ? (object)model.ProjectId : null },
                    { "@ProjectType", model.ProjectType },
                    { "@JiraProjectKey", model.JiraProjectKey },
                    { "@ProjectName", model.ProjectName },
                    { "@BudgetSource", model.BudgetSource },
                    { "@BudgetReferenceId", model.BudgetReferenceId },
                    { "@RequestorId", model.RequestorId },
                    { "@ReviewerId", model.ReviewerId },
                    { "@ApproverId", model.ApproverId }
                };

                DataTable dt = DbHelper.ExecuteQuery("usp_Project_Upsert", parameters);
                int newId = Convert.ToInt32(dt.Rows[0]["Id"]);
                return Ok(ApiResponse<int>.Ok(newId, "Project saved successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<int>.Fail(ex.Message));
            }
        }
    }
}
