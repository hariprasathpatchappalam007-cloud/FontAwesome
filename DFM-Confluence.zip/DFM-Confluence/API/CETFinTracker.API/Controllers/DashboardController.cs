using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/dashboard")]
    public class DashboardController : ApiController
    {
        [HttpGet]
        [Route("summary")]
        public IHttpActionResult GetSummary(int? userId = null)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@UserId", userId } };
                DataSet ds = DbHelper.ExecuteQueryMultiple("usp_Dashboard_Summary", parameters);

                var result = new Dictionary<string, object>();

                // Budget Summary
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    var row = ds.Tables[0].Rows[0];
                    result["budgetSummary"] = new DashboardModel
                    {
                        TotalCapexBudget = Convert.ToDecimal(row["TotalCapexBudget"]),
                        TotalCapexUtilization = Convert.ToDecimal(row["TotalCapexUtilization"]),
                        TotalCapexAvailable = Convert.ToDecimal(row["TotalCapexAvailable"]),
                        TotalOpexBudget = Convert.ToDecimal(row["TotalOpexBudget"]),
                        TotalOpexUtilization = Convert.ToDecimal(row["TotalOpexUtilization"]),
                        TotalOpexAvailable = Convert.ToDecimal(row["TotalOpexAvailable"])
                    };
                }

                // Status Counts
                if (ds.Tables.Count > 1)
                {
                    var statusCounts = new List<StatusCount>();
                    foreach (DataRow row in ds.Tables[1].Rows)
                    {
                        statusCounts.Add(new StatusCount
                        {
                            Status = row["Status"].ToString(),
                            Count = Convert.ToInt32(row["Count"])
                        });
                    }
                    result["statusCounts"] = statusCounts;
                }

                // Recent Requests
                if (ds.Tables.Count > 2)
                {
                    var recentRequests = new List<object>();
                    foreach (DataRow row in ds.Tables[2].Rows)
                    {
                        recentRequests.Add(new
                        {
                            SpendRequestId = Convert.ToInt32(row["SpendRequestId"]),
                            Topic = row["Topic"].ToString(),
                            FinalAmountLCY = Convert.ToDecimal(row["FinalAmountLCY"]),
                            Status = row["Status"].ToString(),
                            CreatedDate = Convert.ToDateTime(row["CreatedDate"]),
                            ProjectName = row["ProjectName"].ToString(),
                            RequestorName = row["RequestorName"].ToString()
                        });
                    }
                    result["recentRequests"] = recentRequests;
                }

                // Pending Actions
                if (ds.Tables.Count > 3)
                {
                    var pendingActions = new List<PendingAction>();
                    foreach (DataRow row in ds.Tables[3].Rows)
                    {
                        pendingActions.Add(new PendingAction
                        {
                            SpendRequestId = Convert.ToInt32(row["SpendRequestId"]),
                            Topic = row["Topic"].ToString(),
                            FinalAmountLCY = Convert.ToDecimal(row["FinalAmountLCY"]),
                            Status = row["Status"].ToString(),
                            ProjectName = row["ProjectName"].ToString()
                        });
                    }
                    result["pendingActions"] = pendingActions;
                }

                return Ok(ApiResponse<Dictionary<string, object>>.Ok(result));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<Dictionary<string, object>>.Fail(ex.Message));
            }
        }
    }
}
