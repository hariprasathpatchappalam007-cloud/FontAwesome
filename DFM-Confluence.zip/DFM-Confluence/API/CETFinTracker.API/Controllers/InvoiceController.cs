using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/invoice")]
    public class InvoiceController : ApiController
    {
        [HttpGet]
        [Route("getbyrequest/{spendRequestId}")]
        public IHttpActionResult GetByRequest(int spendRequestId)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@SpendRequestId", spendRequestId } };
                DataTable dt = DbHelper.ExecuteQuery("usp_Invoice_GetByRequest", parameters);
                var list = new List<InvoiceModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(new InvoiceModel
                    {
                        InvoiceId = Convert.ToInt32(row["InvoiceId"]),
                        SpendRequestId = Convert.ToInt32(row["SpendRequestId"]),
                        InvoiceNumber = row["InvoiceNumber"].ToString(),
                        InvoiceDate = Convert.ToDateTime(row["InvoiceDate"]),
                        VendorName = row["VendorName"].ToString(),
                        Description = row["Description"].ToString(),
                        Amount = Convert.ToDecimal(row["Amount"]),
                        Currency = row["Currency"].ToString(),
                        AmountLCY = Convert.ToDecimal(row["AmountLCY"]),
                        Status = row["Status"].ToString(),
                        CreatedDate = Convert.ToDateTime(row["CreatedDate"])
                    });
                }
                return Ok(ApiResponse<List<InvoiceModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<InvoiceModel>>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("save")]
        public IHttpActionResult Save([FromBody] InvoiceModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@InvoiceId", model.InvoiceId > 0 ? (object)model.InvoiceId : null },
                    { "@SpendRequestId", model.SpendRequestId },
                    { "@InvoiceNumber", model.InvoiceNumber },
                    { "@InvoiceDate", model.InvoiceDate },
                    { "@VendorName", model.VendorName },
                    { "@Description", model.Description },
                    { "@Amount", model.Amount },
                    { "@Currency", model.Currency },
                    { "@AmountLCY", model.AmountLCY },
                    { "@UserId", 1 }
                };

                DataTable dt = DbHelper.ExecuteQuery("usp_Invoice_Upsert", parameters);
                int newId = Convert.ToInt32(dt.Rows[0]["Id"]);
                return Ok(ApiResponse<int>.Ok(newId, "Invoice saved"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<int>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("delete")]
        public IHttpActionResult Delete(int id, int userId)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@InvoiceId", id },
                    { "@UserId", userId }
                };
                DbHelper.ExecuteNonQuery("usp_Invoice_Delete", parameters);
                return Ok(ApiResponse.Ok("Invoice deleted"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse.Fail(ex.Message));
            }
        }
    }
}
