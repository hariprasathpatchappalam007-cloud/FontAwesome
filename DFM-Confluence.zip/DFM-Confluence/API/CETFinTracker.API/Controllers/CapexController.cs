using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/capex")]
    public class CapexController : ApiController
    {
        [HttpGet]
        [Route("getall")]
        public IHttpActionResult GetAll()
        {
            try
            {
                DataTable dt = DbHelper.ExecuteQuery("usp_CAPEX_GetAll");
                var list = new List<CapexModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(MapCapex(row));
                }
                return Ok(ApiResponse<List<CapexModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<CapexModel>>.Fail(ex.Message));
            }
        }

        [HttpGet]
        [Route("get/{id}")]
        public IHttpActionResult GetById(int id)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@CapexId", id } };
                DataTable dt = DbHelper.ExecuteQuery("usp_CAPEX_GetById", parameters);
                if (dt.Rows.Count == 0)
                    return Ok(ApiResponse<CapexModel>.Fail("Record not found"));

                return Ok(ApiResponse<CapexModel>.Ok(MapCapex(dt.Rows[0])));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<CapexModel>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("save")]
        public IHttpActionResult Save([FromBody] CapexModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@CapexId", model.CapexId > 0 ? (object)model.CapexId : null },
                    { "@BudgetId", model.BudgetId },
                    { "@Description", model.Description },
                    { "@Budget", model.Budget },
                    { "@Utilization", model.Utilization },
                    { "@AvailableBudget", model.AvailableBudget },
                    { "@LockedAmt", model.LockedAmt },
                    { "@BudgetAfterLocked", model.BudgetAfterLocked },
                    { "@ClaimAmt", model.ClaimAmt },
                    { "@NetBalance", model.NetBalance },
                    { "@UserId", model.CreatedBy }
                };

                DataTable dt = DbHelper.ExecuteQuery("usp_CAPEX_Upsert", parameters);
                int newId = Convert.ToInt32(dt.Rows[0]["Id"]);
                return Ok(ApiResponse<int>.Ok(newId, "Saved successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<int>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("delete")]
        public IHttpActionResult Delete(int id, int userId)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@CapexId", id },
                    { "@UserId", userId }
                };
                DbHelper.ExecuteNonQuery("usp_CAPEX_Delete", parameters);
                return Ok(ApiResponse.Ok("Deleted successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("import")]
        public IHttpActionResult ImportCsv([FromBody] List<CapexModel> items)
        {
            try
            {
                int count = 0;
                foreach (var model in items)
                {
                    var parameters = new Dictionary<string, object>
                    {
                        { "@CapexId", null },
                        { "@BudgetId", model.BudgetId },
                        { "@Description", model.Description },
                        { "@Budget", model.Budget },
                        { "@Utilization", model.Utilization },
                        { "@AvailableBudget", model.AvailableBudget },
                        { "@LockedAmt", model.LockedAmt },
                        { "@BudgetAfterLocked", model.BudgetAfterLocked },
                        { "@ClaimAmt", model.ClaimAmt },
                        { "@NetBalance", model.NetBalance },
                        { "@UserId", model.CreatedBy }
                    };
                    DbHelper.ExecuteQuery("usp_CAPEX_Upsert", parameters);
                    count++;
                }
                return Ok(ApiResponse<int>.Ok(count, count + " records imported successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<int>.Fail(ex.Message));
            }
        }

        private CapexModel MapCapex(DataRow row)
        {
            return new CapexModel
            {
                CapexId = Convert.ToInt32(row["CapexId"]),
                Type = row["Type"].ToString(),
                BudgetId = row["BudgetId"].ToString(),
                Description = row["Description"].ToString(),
                Budget = Convert.ToDecimal(row["Budget"]),
                Utilization = Convert.ToDecimal(row["Utilization"]),
                AvailableBudget = Convert.ToDecimal(row["AvailableBudget"]),
                LockedAmt = Convert.ToDecimal(row["LockedAmt"]),
                BudgetAfterLocked = Convert.ToDecimal(row["BudgetAfterLocked"]),
                ClaimAmt = Convert.ToDecimal(row["ClaimAmt"]),
                NetBalance = Convert.ToDecimal(row["NetBalance"]),
                IsActive = Convert.ToBoolean(row["IsActive"]),
                CreatedDate = Convert.ToDateTime(row["CreatedDate"])
            };
        }
    }
}
