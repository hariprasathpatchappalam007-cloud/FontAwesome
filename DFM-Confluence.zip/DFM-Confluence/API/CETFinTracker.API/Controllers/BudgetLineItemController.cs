using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/budgetlineitem")]
    public class BudgetLineItemController : ApiController
    {
        [HttpGet]
        [Route("getbyrequest/{spendRequestId}")]
        public IHttpActionResult GetByRequest(int spendRequestId)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@SpendRequestId", spendRequestId } };
                DataTable dt = DbHelper.ExecuteQuery("usp_BudgetLineItem_GetByRequest", parameters);
                var list = new List<BudgetLineItemModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(new BudgetLineItemModel
                    {
                        LineItemId = Convert.ToInt32(row["LineItemId"]),
                        SpendRequestId = Convert.ToInt32(row["SpendRequestId"]),
                        LineNo = Convert.ToInt32(row["LineNo"]),
                        Description = row["Description"].ToString(),
                        CostType = row["CostType"].ToString(),
                        UnitType = row["UnitType"].ToString(),
                        Units = Convert.ToDecimal(row["Units"]),
                        UnitPrice = Convert.ToDecimal(row["UnitPrice"]),
                        BaseCurrency = row["BaseCurrency"].ToString(),
                        AmountFCY = Convert.ToDecimal(row["AmountFCY"]),
                        AmountLCY = Convert.ToDecimal(row["AmountLCY"]),
                        ContingencyPercent = Convert.ToDecimal(row["ContingencyPercent"]),
                        FinalAmountLCY = Convert.ToDecimal(row["FinalAmountLCY"]),
                        CreatedDate = Convert.ToDateTime(row["CreatedDate"])
                    });
                }
                return Ok(ApiResponse<List<BudgetLineItemModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<BudgetLineItemModel>>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("save")]
        public IHttpActionResult Save([FromBody] BudgetLineItemModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@LineItemId", model.LineItemId > 0 ? (object)model.LineItemId : null },
                    { "@SpendRequestId", model.SpendRequestId },
                    { "@Description", model.Description },
                    { "@CostType", model.CostType },
                    { "@UnitType", model.UnitType },
                    { "@Units", model.Units },
                    { "@UnitPrice", model.UnitPrice },
                    { "@BaseCurrency", model.BaseCurrency },
                    { "@ContingencyPercent", model.ContingencyPercent },
                    { "@UserId", 1 }
                };

                DataTable dt = DbHelper.ExecuteQuery("usp_BudgetLineItem_Upsert", parameters);
                int newId = Convert.ToInt32(dt.Rows[0]["Id"]);
                return Ok(ApiResponse<int>.Ok(newId, "Line item saved"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<int>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("delete")]
        public IHttpActionResult Delete(int id, int userId)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@LineItemId", id },
                    { "@UserId", userId }
                };
                DbHelper.ExecuteNonQuery("usp_BudgetLineItem_Delete", parameters);
                return Ok(ApiResponse.Ok("Line item deleted"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse.Fail(ex.Message));
            }
        }
    }
}
