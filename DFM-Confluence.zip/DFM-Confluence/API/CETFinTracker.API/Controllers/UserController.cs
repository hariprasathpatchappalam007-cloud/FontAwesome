using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/user")]
    public class UserController : ApiController
    {
        [HttpGet]
        [Route("getbyjira/{jiraUserId}")]
        public IHttpActionResult GetByJiraId(string jiraUserId)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@JiraUserId", jiraUserId } };
                DataTable dt = DbHelper.ExecuteQuery("usp_User_GetByJiraId", parameters);
                if (dt.Rows.Count == 0)
                    return Ok(ApiResponse<UserModel>.Fail("User not found"));

                var row = dt.Rows[0];
                var user = new UserModel
                {
                    UserId = Convert.ToInt32(row["UserId"]),
                    JiraUserId = row["JiraUserId"].ToString(),
                    DisplayName = row["DisplayName"].ToString(),
                    Email = row["Email"].ToString(),
                    Department = row["Department"].ToString(),
                    RoleId = Convert.ToInt32(row["RoleId"]),
                    RoleName = row["RoleName"].ToString(),
                    IsActive = Convert.ToBoolean(row["IsActive"])
                };
                return Ok(ApiResponse<UserModel>.Ok(user));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<UserModel>.Fail(ex.Message));
            }
        }

        [HttpGet]
        [Route("reviewers")]
        public IHttpActionResult GetReviewers()
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@RoleType", "Reviewer" } };
                DataTable dt = DbHelper.ExecuteQuery("usp_ReviewerApprover_GetAll", parameters);
                var list = new List<ReviewerApproverModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(MapReviewerApprover(row));
                }
                return Ok(ApiResponse<List<ReviewerApproverModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<ReviewerApproverModel>>.Fail(ex.Message));
            }
        }

        [HttpGet]
        [Route("approvers")]
        public IHttpActionResult GetApprovers()
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@RoleType", "Approver" } };
                DataTable dt = DbHelper.ExecuteQuery("usp_ReviewerApprover_GetAll", parameters);
                var list = new List<ReviewerApproverModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(MapReviewerApprover(row));
                }
                return Ok(ApiResponse<List<ReviewerApproverModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<ReviewerApproverModel>>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("savereviewerapprover")]
        public IHttpActionResult SaveReviewerApprover([FromBody] ReviewerApproverModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@UserId", model.UserId },
                    { "@RoleType", model.RoleType },
                    { "@DepartmentId", model.DepartmentId }
                };
                DbHelper.ExecuteNonQuery("usp_ReviewerApprover_Save", parameters);
                return Ok(ApiResponse.Ok("Saved successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("removereviewerapprover")]
        public IHttpActionResult RemoveReviewerApprover(int id)
        {
            try
            {
                var parameters = new Dictionary<string, object> { { "@Id", id } };
                DbHelper.ExecuteNonQuery("usp_ReviewerApprover_Remove", parameters);
                return Ok(ApiResponse.Ok("Removed successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse.Fail(ex.Message));
            }
        }

        [HttpGet]
        [Route("getall")]
        public IHttpActionResult GetAll()
        {
            try
            {
                DataTable dt = DbHelper.ExecuteQuery("usp_User_GetAll");
                var list = new List<UserModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(new UserModel
                    {
                        UserId = Convert.ToInt32(row["UserId"]),
                        JiraUserId = row["JiraUserId"].ToString(),
                        DisplayName = row["DisplayName"].ToString(),
                        Email = row["Email"].ToString(),
                        Department = row["Department"].ToString(),
                        RoleName = row["RoleName"].ToString()
                    });
                }
                return Ok(ApiResponse<List<UserModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<UserModel>>.Fail(ex.Message));
            }
        }

        private ReviewerApproverModel MapReviewerApprover(DataRow row)
        {
            return new ReviewerApproverModel
            {
                Id = Convert.ToInt32(row["Id"]),
                UserId = Convert.ToInt32(row["UserId"]),
                RoleType = row["RoleType"].ToString(),
                DepartmentId = Convert.ToInt32(row["DepartmentId"]),
                DisplayName = row["DisplayName"].ToString(),
                Email = row["Email"].ToString(),
                DepartmentName = row["DepartmentName"].ToString()
            };
        }
    }
}
