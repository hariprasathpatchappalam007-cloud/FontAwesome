using System;
using System.Collections.Generic;
using System.Data;
using System.Web.Http;
using CETFinTracker.API.DataAccess;
using CETFinTracker.API.Models;

namespace CETFinTracker.API.Controllers
{
    [RoutePrefix("api/opex")]
    public class OpexController : ApiController
    {
        [HttpGet]
        [Route("getall")]
        public IHttpActionResult GetAll()
        {
            try
            {
                DataTable dt = DbHelper.ExecuteQuery("usp_OPEX_GetAll");
                var list = new List<OpexModel>();
                foreach (DataRow row in dt.Rows)
                {
                    list.Add(new OpexModel
                    {
                        OpexId = Convert.ToInt32(row["OpexId"]),
                        Type = row["Type"].ToString(),
                        BudgetId = row["BudgetId"].ToString(),
                        Description = row["Description"].ToString(),
                        Budget = Convert.ToDecimal(row["Budget"]),
                        Utilization = Convert.ToDecimal(row["Utilization"]),
                        AvailableBudget = Convert.ToDecimal(row["AvailableBudget"]),
                        LockedAmt = Convert.ToDecimal(row["LockedAmt"]),
                        BudgetAfterLocked = Convert.ToDecimal(row["BudgetAfterLocked"]),
                        ClaimAmt = Convert.ToDecimal(row["ClaimAmt"]),
                        NetBalance = Convert.ToDecimal(row["NetBalance"]),
                        IsActive = Convert.ToBoolean(row["IsActive"]),
                        CreatedDate = Convert.ToDateTime(row["CreatedDate"])
                    });
                }
                return Ok(ApiResponse<List<OpexModel>>.Ok(list));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<List<OpexModel>>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("save")]
        public IHttpActionResult Save([FromBody] OpexModel model)
        {
            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@OpexId", model.OpexId > 0 ? (object)model.OpexId : null },
                    { "@BudgetId", model.BudgetId },
                    { "@Description", model.Description },
                    { "@Budget", model.Budget },
                    { "@Utilization", model.Utilization },
                    { "@AvailableBudget", model.AvailableBudget },
                    { "@LockedAmt", model.LockedAmt },
                    { "@BudgetAfterLocked", model.BudgetAfterLocked },
                    { "@ClaimAmt", model.ClaimAmt },
                    { "@NetBalance", model.NetBalance },
                    { "@UserId", model.CreatedBy }
                };

                DataTable dt = DbHelper.ExecuteQuery("usp_OPEX_Upsert", parameters);
                int newId = Convert.ToInt32(dt.Rows[0]["Id"]);
                return Ok(ApiResponse<int>.Ok(newId, "Saved successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<int>.Fail(ex.Message));
            }
        }

        [HttpPost]
        [Route("import")]
        public IHttpActionResult ImportCsv([FromBody] List<OpexModel> items)
        {
            try
            {
                int count = 0;
                foreach (var model in items)
                {
                    var parameters = new Dictionary<string, object>
                    {
                        { "@OpexId", null },
                        { "@BudgetId", model.BudgetId },
                        { "@Description", model.Description },
                        { "@Budget", model.Budget },
                        { "@Utilization", model.Utilization },
                        { "@AvailableBudget", model.AvailableBudget },
                        { "@LockedAmt", model.LockedAmt },
                        { "@BudgetAfterLocked", model.BudgetAfterLocked },
                        { "@ClaimAmt", model.ClaimAmt },
                        { "@NetBalance", model.NetBalance },
                        { "@UserId", model.CreatedBy }
                    };
                    DbHelper.ExecuteQuery("usp_OPEX_Upsert", parameters);
                    count++;
                }
                return Ok(ApiResponse<int>.Ok(count, count + " records imported successfully"));
            }
            catch (Exception ex)
            {
                return Ok(ApiResponse<int>.Fail(ex.Message));
            }
        }
    }
}
