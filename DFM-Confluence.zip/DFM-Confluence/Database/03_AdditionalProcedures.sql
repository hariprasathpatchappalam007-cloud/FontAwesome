-- ============================================
-- CET Portfolio Financial Tracker - Additional Stored Procedures
-- Run AFTER 02_StoredProcedures.sql
-- ============================================

USE [CETFinTracker]
GO

-- Department GetAll
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Department_GetAll]'))
    DROP PROCEDURE [dbo].[usp_Department_GetAll]
GO
CREATE PROCEDURE [dbo].[usp_Department_GetAll]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DepartmentId, DepartmentCode, DepartmentName 
    FROM [dbo].[Departments] 
    WHERE IsActive = 1 
    ORDER BY DepartmentName
END
GO

-- Budget Line Item Delete (soft delete)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_BudgetLineItem_Delete]'))
    DROP PROCEDURE [dbo].[usp_BudgetLineItem_Delete]
GO
CREATE PROCEDURE [dbo].[usp_BudgetLineItem_Delete]
    @LineItemId INT,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE [dbo].[BudgetLineItems] 
    SET IsActive = 0, ModifiedBy = @UserId, ModifiedDate = GETDATE() 
    WHERE LineItemId = @LineItemId
END
GO

-- Invoice Delete (soft delete)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Invoice_Delete]'))
    DROP PROCEDURE [dbo].[usp_Invoice_Delete]
GO
CREATE PROCEDURE [dbo].[usp_Invoice_Delete]
    @InvoiceId INT,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE [dbo].[Invoices] 
    SET IsActive = 0, ModifiedBy = @UserId, ModifiedDate = GETDATE() 
    WHERE InvoiceId = @InvoiceId
END
GO

-- OPEX Delete (soft delete)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_OPEX_Delete]'))
    DROP PROCEDURE [dbo].[usp_OPEX_Delete]
GO
CREATE PROCEDURE [dbo].[usp_OPEX_Delete]
    @OpexId INT,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE [dbo].[OPEX] 
    SET IsActive = 0, ModifiedBy = @UserId, ModifiedDate = GETDATE() 
    WHERE OpexId = @OpexId
END
GO

-- Reviewer/Approver Save
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ReviewerApprover_Save]'))
    DROP PROCEDURE [dbo].[usp_ReviewerApprover_Save]
GO
CREATE PROCEDURE [dbo].[usp_ReviewerApprover_Save]
    @UserId INT,
    @RoleType NVARCHAR(20),
    @DepartmentId INT
AS
BEGIN
    SET NOCOUNT ON;
    -- Check if already exists
    IF NOT EXISTS (SELECT 1 FROM [dbo].[ReviewerApprover] WHERE UserId = @UserId AND RoleType = @RoleType AND DepartmentId = @DepartmentId AND IsActive = 1)
    BEGIN
        INSERT INTO [dbo].[ReviewerApprover] ([UserId], [RoleType], [DepartmentId])
        VALUES (@UserId, @RoleType, @DepartmentId)
    END
    SELECT @@ROWCOUNT AS AffectedRows
END
GO

-- Reviewer/Approver Remove
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ReviewerApprover_Remove]'))
    DROP PROCEDURE [dbo].[usp_ReviewerApprover_Remove]
GO
CREATE PROCEDURE [dbo].[usp_ReviewerApprover_Remove]
    @Id INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE [dbo].[ReviewerApprover] SET IsActive = 0 WHERE Id = @Id
END
GO

-- User Upsert (create/update user from JIRA login)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_User_Upsert]'))
    DROP PROCEDURE [dbo].[usp_User_Upsert]
GO
CREATE PROCEDURE [dbo].[usp_User_Upsert]
    @JiraUserId NVARCHAR(100),
    @DisplayName NVARCHAR(200),
    @Email NVARCHAR(200),
    @Department NVARCHAR(100) = NULL,
    @RoleId INT = 4 -- Default to Requestor
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM [dbo].[Users] WHERE JiraUserId = @JiraUserId)
    BEGIN
        UPDATE [dbo].[Users] SET 
            DisplayName = @DisplayName,
            Email = @Email,
            Department = ISNULL(@Department, Department),
            ModifiedDate = GETDATE()
        WHERE JiraUserId = @JiraUserId

        SELECT UserId FROM [dbo].[Users] WHERE JiraUserId = @JiraUserId
    END
    ELSE
    BEGIN
        INSERT INTO [dbo].[Users] ([JiraUserId], [DisplayName], [Email], [Department], [RoleId])
        VALUES (@JiraUserId, @DisplayName, @Email, @Department, @RoleId)

        SELECT SCOPE_IDENTITY() AS UserId
    END
END
GO

-- Get All Users (for Reviewer/Approver dropdown)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_User_GetAll]'))
    DROP PROCEDURE [dbo].[usp_User_GetAll]
GO
CREATE PROCEDURE [dbo].[usp_User_GetAll]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT u.UserId, u.JiraUserId, u.DisplayName, u.Email, u.Department, r.RoleName
    FROM [dbo].[Users] u
    LEFT JOIN [dbo].[Roles] r ON u.RoleId = r.RoleId
    WHERE u.IsActive = 1
    ORDER BY u.DisplayName
END
GO

-- Approval History for a Spend Request
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ApprovalHistory_GetByRequest]'))
    DROP PROCEDURE [dbo].[usp_ApprovalHistory_GetByRequest]
GO
CREATE PROCEDURE [dbo].[usp_ApprovalHistory_GetByRequest]
    @SpendRequestId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ah.*, u.DisplayName AS ActionByName
    FROM [dbo].[ApprovalHistory] ah
    LEFT JOIN [dbo].[Users] u ON ah.ActionBy = u.UserId
    WHERE ah.SpendRequestId = @SpendRequestId
    ORDER BY ah.ActionDate
END
GO

-- Spend Request GetById
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SpendRequest_GetById]'))
    DROP PROCEDURE [dbo].[usp_SpendRequest_GetById]
GO
CREATE PROCEDURE [dbo].[usp_SpendRequest_GetById]
    @SpendRequestId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT sr.*, p.ProjectName, p.BudgetSource, d.DepartmentName,
           u1.DisplayName AS CreatedByName,
           u2.DisplayName AS ReviewedByName,
           u3.DisplayName AS ApprovedByName
    FROM [dbo].[SpendRequests] sr
    INNER JOIN [dbo].[Projects] p ON sr.ProjectId = p.ProjectId
    LEFT JOIN [dbo].[Departments] d ON sr.DepartmentId = d.DepartmentId
    LEFT JOIN [dbo].[Users] u1 ON sr.CreatedBy = u1.UserId
    LEFT JOIN [dbo].[Users] u2 ON sr.ReviewedBy = u2.UserId
    LEFT JOIN [dbo].[Users] u3 ON sr.ApprovedBy = u3.UserId
    WHERE sr.SpendRequestId = @SpendRequestId
END
GO

PRINT 'Additional stored procedures created successfully.'
GO
