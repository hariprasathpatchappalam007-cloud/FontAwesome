-- ============================================
-- CET Portfolio Financial Tracker - Database Setup
-- SQL Server Database Creation Script
-- ============================================

USE [master]
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'CETFinTracker')
BEGIN
    CREATE DATABASE [CETFinTracker]
END
GO

USE [CETFinTracker]
GO

-- ============================================
-- MASTER TABLES
-- ============================================

-- Roles Master
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Roles]'))
BEGIN
    CREATE TABLE [dbo].[Roles] (
        [RoleId] INT IDENTITY(1,1) PRIMARY KEY,
        [RoleName] NVARCHAR(50) NOT NULL,
        [Description] NVARCHAR(200),
        [IsActive] BIT DEFAULT 1,
        [CreatedDate] DATETIME DEFAULT GETDATE(),
        [ModifiedDate] DATETIME DEFAULT GETDATE()
    )

    INSERT INTO [dbo].[Roles] ([RoleName], [Description]) VALUES
        ('Administrator', 'Full system access'),
        ('Reviewer', 'Can review spend requests'),
        ('Approver', 'Can approve spend requests'),
        ('Requestor', 'Can submit spend requests')
END
GO

-- Users Master
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Users]'))
BEGIN
    CREATE TABLE [dbo].[Users] (
        [UserId] INT IDENTITY(1,1) PRIMARY KEY,
        [JiraUserId] NVARCHAR(100),
        [DisplayName] NVARCHAR(200) NOT NULL,
        [Email] NVARCHAR(200),
        [Department] NVARCHAR(100),
        [RoleId] INT FOREIGN KEY REFERENCES [dbo].[Roles]([RoleId]),
        [IsActive] BIT DEFAULT 1,
        [CreatedDate] DATETIME DEFAULT GETDATE(),
        [ModifiedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

-- Departments Master
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Departments]'))
BEGIN
    CREATE TABLE [dbo].[Departments] (
        [DepartmentId] INT IDENTITY(1,1) PRIMARY KEY,
        [DepartmentCode] NVARCHAR(10) NOT NULL,
        [DepartmentName] NVARCHAR(100) NOT NULL,
        [IsActive] BIT DEFAULT 1,
        [CreatedDate] DATETIME DEFAULT GETDATE()
    )

    INSERT INTO [dbo].[Departments] ([DepartmentCode], [DepartmentName]) VALUES
        ('GOV', 'Governance'),
        ('COR', 'Core'),
        ('EIS', 'EIS'),
        ('CRM', 'CRM'),
        ('AE', 'EA&I'),
        ('RSK', 'Risk'),
        ('CET', 'CET'),
        ('BUS', 'Business'),
        ('CIO', 'CIO Office'),
        ('CTO', 'CTO'),
        ('RTB', 'RTB'),
        ('TEST', 'Test Gov.')
END
GO

-- CAPEX Master
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CAPEX]'))
BEGIN
    CREATE TABLE [dbo].[CAPEX] (
        [CapexId] INT IDENTITY(1,1) PRIMARY KEY,
        [Type] NVARCHAR(20) DEFAULT 'Capex',
        [BudgetId] NVARCHAR(50) NOT NULL,
        [Description] NVARCHAR(500),
        [Budget] DECIMAL(18,2) DEFAULT 0,
        [Utilization] DECIMAL(18,2) DEFAULT 0,
        [AvailableBudget] DECIMAL(18,2) DEFAULT 0,
        [LockedAmt] DECIMAL(18,2) DEFAULT 0,
        [BudgetAfterLocked] DECIMAL(18,2) DEFAULT 0,
        [ClaimAmt] DECIMAL(18,2) DEFAULT 0,
        [NetBalance] DECIMAL(18,2) DEFAULT 0,
        [IsActive] BIT DEFAULT 1,
        [CreatedBy] INT,
        [CreatedDate] DATETIME DEFAULT GETDATE(),
        [ModifiedBy] INT,
        [ModifiedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

-- OPEX Master
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OPEX]'))
BEGIN
    CREATE TABLE [dbo].[OPEX] (
        [OpexId] INT IDENTITY(1,1) PRIMARY KEY,
        [Type] NVARCHAR(20) DEFAULT 'Opex',
        [BudgetId] NVARCHAR(50) NOT NULL,
        [Description] NVARCHAR(500),
        [Budget] DECIMAL(18,2) DEFAULT 0,
        [Utilization] DECIMAL(18,2) DEFAULT 0,
        [AvailableBudget] DECIMAL(18,2) DEFAULT 0,
        [LockedAmt] DECIMAL(18,2) DEFAULT 0,
        [BudgetAfterLocked] DECIMAL(18,2) DEFAULT 0,
        [ClaimAmt] DECIMAL(18,2) DEFAULT 0,
        [NetBalance] DECIMAL(18,2) DEFAULT 0,
        [IsActive] BIT DEFAULT 1,
        [CreatedBy] INT,
        [CreatedDate] DATETIME DEFAULT GETDATE(),
        [ModifiedBy] INT,
        [ModifiedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

-- Reviewer/Approver Assignment
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReviewerApprover]'))
BEGIN
    CREATE TABLE [dbo].[ReviewerApprover] (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [UserId] INT FOREIGN KEY REFERENCES [dbo].[Users]([UserId]),
        [RoleType] NVARCHAR(20) NOT NULL, -- 'Reviewer' or 'Approver'
        [DepartmentId] INT FOREIGN KEY REFERENCES [dbo].[Departments]([DepartmentId]),
        [IsActive] BIT DEFAULT 1,
        [CreatedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

-- ============================================
-- TRANSACTION TABLES
-- ============================================

-- Projects
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Projects]'))
BEGIN
    CREATE TABLE [dbo].[Projects] (
        [ProjectId] INT IDENTITY(1,1) PRIMARY KEY,
        [ProjectType] NVARCHAR(20) NOT NULL, -- 'JIRA' or 'Non-JIRA'
        [JiraProjectKey] NVARCHAR(50),
        [ProjectName] NVARCHAR(200) NOT NULL,
        [BudgetSource] NVARCHAR(10) NOT NULL, -- 'CAPEX' or 'OPEX'
        [BudgetReferenceId] INT, -- FK to CAPEX or OPEX based on BudgetSource
        [RequestorId] INT FOREIGN KEY REFERENCES [dbo].[Users]([UserId]),
        [ReviewerId] INT FOREIGN KEY REFERENCES [dbo].[Users]([UserId]),
        [ApproverId] INT FOREIGN KEY REFERENCES [dbo].[Users]([UserId]),
        [Status] NVARCHAR(30) DEFAULT 'Draft', -- Draft, Submitted, UnderReview, Approved, Rejected
        [IsActive] BIT DEFAULT 1,
        [CreatedDate] DATETIME DEFAULT GETDATE(),
        [ModifiedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

-- Spend Requests (PET Form)
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SpendRequests]'))
BEGIN
    CREATE TABLE [dbo].[SpendRequests] (
        [SpendRequestId] INT IDENTITY(1,1) PRIMARY KEY,
        [ProjectId] INT FOREIGN KEY REFERENCES [dbo].[Projects]([ProjectId]),
        [SerialNo] INT,
        [RequestDate] DATETIME DEFAULT GETDATE(),
        [DepartmentId] INT FOREIGN KEY REFERENCES [dbo].[Departments]([DepartmentId]),
        [AutoId] NVARCHAR(50),
        [ExpenseHead] NVARCHAR(20), -- 'Capex' or 'Opex'
        [Topic] NVARCHAR(200),
        [Vendor] NVARCHAR(200),
        [Description] NVARCHAR(1000),
        [CostType] NVARCHAR(100),
        [UnitType] NVARCHAR(50),
        [Units] DECIMAL(10,2),
        [UnitPrice] DECIMAL(18,2),
        [BaseCurrency] NVARCHAR(10) DEFAULT 'AED',
        [AmountFCY] DECIMAL(18,2),
        [AmountLCY] DECIMAL(18,2),
        [ContingencyPercent] DECIMAL(5,2),
        [FinalAmountLCY] DECIMAL(18,2),
        [YearlyRecurrence] INT DEFAULT 1,
        [Status] NVARCHAR(30) DEFAULT 'Draft',
        [SubmittedDate] DATETIME,
        [ReviewedDate] DATETIME,
        [ReviewedBy] INT,
        [ReviewComments] NVARCHAR(1000),
        [ApprovedDate] DATETIME,
        [ApprovedBy] INT,
        [ApprovalComments] NVARCHAR(1000),
        [CreatedBy] INT,
        [CreatedDate] DATETIME DEFAULT GETDATE(),
        [ModifiedBy] INT,
        [ModifiedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

-- Budget Line Items
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BudgetLineItems]'))
BEGIN
    CREATE TABLE [dbo].[BudgetLineItems] (
        [LineItemId] INT IDENTITY(1,1) PRIMARY KEY,
        [SpendRequestId] INT FOREIGN KEY REFERENCES [dbo].[SpendRequests]([SpendRequestId]),
        [LineNo] INT,
        [Description] NVARCHAR(500),
        [CostType] NVARCHAR(100),
        [UnitType] NVARCHAR(50),
        [Units] DECIMAL(10,2),
        [UnitPrice] DECIMAL(18,2),
        [BaseCurrency] NVARCHAR(10) DEFAULT 'AED',
        [AmountFCY] DECIMAL(18,2),
        [AmountLCY] DECIMAL(18,2),
        [ContingencyPercent] DECIMAL(5,2),
        [FinalAmountLCY] DECIMAL(18,2),
        [IsActive] BIT DEFAULT 1,
        [CreatedBy] INT,
        [CreatedDate] DATETIME DEFAULT GETDATE(),
        [ModifiedBy] INT,
        [ModifiedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

-- Invoices
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Invoices]'))
BEGIN
    CREATE TABLE [dbo].[Invoices] (
        [InvoiceId] INT IDENTITY(1,1) PRIMARY KEY,
        [SpendRequestId] INT FOREIGN KEY REFERENCES [dbo].[SpendRequests]([SpendRequestId]),
        [InvoiceNumber] NVARCHAR(50),
        [InvoiceDate] DATETIME,
        [VendorName] NVARCHAR(200),
        [Description] NVARCHAR(500),
        [Amount] DECIMAL(18,2),
        [Currency] NVARCHAR(10) DEFAULT 'AED',
        [AmountLCY] DECIMAL(18,2),
        [Status] NVARCHAR(30) DEFAULT 'Pending', -- Pending, Verified, Paid
        [AttachmentPath] NVARCHAR(500),
        [IsActive] BIT DEFAULT 1,
        [CreatedBy] INT,
        [CreatedDate] DATETIME DEFAULT GETDATE(),
        [ModifiedBy] INT,
        [ModifiedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

-- Approval History / Audit Trail
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ApprovalHistory]'))
BEGIN
    CREATE TABLE [dbo].[ApprovalHistory] (
        [HistoryId] INT IDENTITY(1,1) PRIMARY KEY,
        [SpendRequestId] INT FOREIGN KEY REFERENCES [dbo].[SpendRequests]([SpendRequestId]),
        [Action] NVARCHAR(50), -- Submitted, Reviewed, Approved, Rejected, Returned
        [ActionBy] INT FOREIGN KEY REFERENCES [dbo].[Users]([UserId]),
        [ActionDate] DATETIME DEFAULT GETDATE(),
        [Comments] NVARCHAR(1000),
        [FromStatus] NVARCHAR(30),
        [ToStatus] NVARCHAR(30)
    )
END
GO

-- Attachments
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Attachments]'))
BEGIN
    CREATE TABLE [dbo].[Attachments] (
        [AttachmentId] INT IDENTITY(1,1) PRIMARY KEY,
        [ReferenceType] NVARCHAR(30), -- 'SpendRequest', 'Invoice', 'BudgetLineItem'
        [ReferenceId] INT,
        [FileName] NVARCHAR(200),
        [FilePath] NVARCHAR(500),
        [FileSize] BIGINT,
        [ContentType] NVARCHAR(100),
        [UploadedBy] INT FOREIGN KEY REFERENCES [dbo].[Users]([UserId]),
        [UploadedDate] DATETIME DEFAULT GETDATE()
    )
END
GO

PRINT 'Database setup completed successfully.'
GO
