-- ============================================
-- CET Portfolio Financial Tracker - Stored Procedures
-- ============================================

USE [CETFinTracker]
GO

-- ============================================
-- CAPEX CRUD
-- ============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CAPEX_GetAll]'))
    DROP PROCEDURE [dbo].[usp_CAPEX_GetAll]
GO
CREATE PROCEDURE [dbo].[usp_CAPEX_GetAll]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM [dbo].[CAPEX] WHERE IsActive = 1 ORDER BY BudgetId
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CAPEX_GetById]'))
    DROP PROCEDURE [dbo].[usp_CAPEX_GetById]
GO
CREATE PROCEDURE [dbo].[usp_CAPEX_GetById]
    @CapexId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM [dbo].[CAPEX] WHERE CapexId = @CapexId AND IsActive = 1
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CAPEX_Upsert]'))
    DROP PROCEDURE [dbo].[usp_CAPEX_Upsert]
GO
CREATE PROCEDURE [dbo].[usp_CAPEX_Upsert]
    @CapexId INT = NULL,
    @BudgetId NVARCHAR(50),
    @Description NVARCHAR(500),
    @Budget DECIMAL(18,2),
    @Utilization DECIMAL(18,2) = 0,
    @AvailableBudget DECIMAL(18,2) = 0,
    @LockedAmt DECIMAL(18,2) = 0,
    @BudgetAfterLocked DECIMAL(18,2) = 0,
    @ClaimAmt DECIMAL(18,2) = 0,
    @NetBalance DECIMAL(18,2) = 0,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @CapexId IS NULL OR @CapexId = 0
    BEGIN
        INSERT INTO [dbo].[CAPEX] ([BudgetId],[Description],[Budget],[Utilization],[AvailableBudget],[LockedAmt],[BudgetAfterLocked],[ClaimAmt],[NetBalance],[CreatedBy])
        VALUES (@BudgetId, @Description, @Budget, @Utilization, @AvailableBudget, @LockedAmt, @BudgetAfterLocked, @ClaimAmt, @NetBalance, @UserId)
        
        SELECT SCOPE_IDENTITY() AS Id
    END
    ELSE
    BEGIN
        UPDATE [dbo].[CAPEX] SET
            BudgetId = @BudgetId,
            [Description] = @Description,
            Budget = @Budget,
            Utilization = @Utilization,
            AvailableBudget = @AvailableBudget,
            LockedAmt = @LockedAmt,
            BudgetAfterLocked = @BudgetAfterLocked,
            ClaimAmt = @ClaimAmt,
            NetBalance = @NetBalance,
            ModifiedBy = @UserId,
            ModifiedDate = GETDATE()
        WHERE CapexId = @CapexId

        SELECT @CapexId AS Id
    END
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_CAPEX_Delete]'))
    DROP PROCEDURE [dbo].[usp_CAPEX_Delete]
GO
CREATE PROCEDURE [dbo].[usp_CAPEX_Delete]
    @CapexId INT,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE [dbo].[CAPEX] SET IsActive = 0, ModifiedBy = @UserId, ModifiedDate = GETDATE() WHERE CapexId = @CapexId
END
GO

-- ============================================
-- OPEX CRUD
-- ============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_OPEX_GetAll]'))
    DROP PROCEDURE [dbo].[usp_OPEX_GetAll]
GO
CREATE PROCEDURE [dbo].[usp_OPEX_GetAll]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM [dbo].[OPEX] WHERE IsActive = 1 ORDER BY BudgetId
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_OPEX_Upsert]'))
    DROP PROCEDURE [dbo].[usp_OPEX_Upsert]
GO
CREATE PROCEDURE [dbo].[usp_OPEX_Upsert]
    @OpexId INT = NULL,
    @BudgetId NVARCHAR(50),
    @Description NVARCHAR(500),
    @Budget DECIMAL(18,2),
    @Utilization DECIMAL(18,2) = 0,
    @AvailableBudget DECIMAL(18,2) = 0,
    @LockedAmt DECIMAL(18,2) = 0,
    @BudgetAfterLocked DECIMAL(18,2) = 0,
    @ClaimAmt DECIMAL(18,2) = 0,
    @NetBalance DECIMAL(18,2) = 0,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @OpexId IS NULL OR @OpexId = 0
    BEGIN
        INSERT INTO [dbo].[OPEX] ([BudgetId],[Description],[Budget],[Utilization],[AvailableBudget],[LockedAmt],[BudgetAfterLocked],[ClaimAmt],[NetBalance],[CreatedBy])
        VALUES (@BudgetId, @Description, @Budget, @Utilization, @AvailableBudget, @LockedAmt, @BudgetAfterLocked, @ClaimAmt, @NetBalance, @UserId)
        
        SELECT SCOPE_IDENTITY() AS Id
    END
    ELSE
    BEGIN
        UPDATE [dbo].[OPEX] SET
            BudgetId = @BudgetId,
            [Description] = @Description,
            Budget = @Budget,
            Utilization = @Utilization,
            AvailableBudget = @AvailableBudget,
            LockedAmt = @LockedAmt,
            BudgetAfterLocked = @BudgetAfterLocked,
            ClaimAmt = @ClaimAmt,
            NetBalance = @NetBalance,
            ModifiedBy = @UserId,
            ModifiedDate = GETDATE()
        WHERE OpexId = @OpexId

        SELECT @OpexId AS Id
    END
END
GO

-- ============================================
-- PROJECTS
-- ============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Project_GetAll]'))
    DROP PROCEDURE [dbo].[usp_Project_GetAll]
GO
CREATE PROCEDURE [dbo].[usp_Project_GetAll]
    @UserId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT p.*, u1.DisplayName AS RequestorName, u2.DisplayName AS ReviewerName, u3.DisplayName AS ApproverName
    FROM [dbo].[Projects] p
    LEFT JOIN [dbo].[Users] u1 ON p.RequestorId = u1.UserId
    LEFT JOIN [dbo].[Users] u2 ON p.ReviewerId = u2.UserId
    LEFT JOIN [dbo].[Users] u3 ON p.ApproverId = u3.UserId
    WHERE p.IsActive = 1
    AND (@UserId IS NULL OR p.RequestorId = @UserId)
    ORDER BY p.CreatedDate DESC
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Project_Upsert]'))
    DROP PROCEDURE [dbo].[usp_Project_Upsert]
GO
CREATE PROCEDURE [dbo].[usp_Project_Upsert]
    @ProjectId INT = NULL,
    @ProjectType NVARCHAR(20),
    @JiraProjectKey NVARCHAR(50) = NULL,
    @ProjectName NVARCHAR(200),
    @BudgetSource NVARCHAR(10),
    @BudgetReferenceId INT = NULL,
    @RequestorId INT,
    @ReviewerId INT = NULL,
    @ApproverId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @ProjectId IS NULL OR @ProjectId = 0
    BEGIN
        INSERT INTO [dbo].[Projects] ([ProjectType],[JiraProjectKey],[ProjectName],[BudgetSource],[BudgetReferenceId],[RequestorId],[ReviewerId],[ApproverId])
        VALUES (@ProjectType, @JiraProjectKey, @ProjectName, @BudgetSource, @BudgetReferenceId, @RequestorId, @ReviewerId, @ApproverId)
        
        SELECT SCOPE_IDENTITY() AS Id
    END
    ELSE
    BEGIN
        UPDATE [dbo].[Projects] SET
            ProjectType = @ProjectType,
            JiraProjectKey = @JiraProjectKey,
            ProjectName = @ProjectName,
            BudgetSource = @BudgetSource,
            BudgetReferenceId = @BudgetReferenceId,
            ReviewerId = @ReviewerId,
            ApproverId = @ApproverId,
            ModifiedDate = GETDATE()
        WHERE ProjectId = @ProjectId

        SELECT @ProjectId AS Id
    END
END
GO

-- ============================================
-- SPEND REQUESTS
-- ============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SpendRequest_GetAll]'))
    DROP PROCEDURE [dbo].[usp_SpendRequest_GetAll]
GO
CREATE PROCEDURE [dbo].[usp_SpendRequest_GetAll]
    @ProjectId INT = NULL,
    @Status NVARCHAR(30) = NULL,
    @UserId INT = NULL,
    @RoleType NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT sr.*, p.ProjectName, p.BudgetSource, d.DepartmentName,
           u1.DisplayName AS CreatedByName
    FROM [dbo].[SpendRequests] sr
    INNER JOIN [dbo].[Projects] p ON sr.ProjectId = p.ProjectId
    LEFT JOIN [dbo].[Departments] d ON sr.DepartmentId = d.DepartmentId
    LEFT JOIN [dbo].[Users] u1 ON sr.CreatedBy = u1.UserId
    WHERE (@ProjectId IS NULL OR sr.ProjectId = @ProjectId)
    AND (@Status IS NULL OR sr.Status = @Status)
    AND (
        @RoleType IS NULL 
        OR (@RoleType = 'Requestor' AND sr.CreatedBy = @UserId)
        OR (@RoleType = 'Reviewer' AND p.ReviewerId = @UserId)
        OR (@RoleType = 'Approver' AND p.ApproverId = @UserId)
    )
    ORDER BY sr.CreatedDate DESC
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SpendRequest_Upsert]'))
    DROP PROCEDURE [dbo].[usp_SpendRequest_Upsert]
GO
CREATE PROCEDURE [dbo].[usp_SpendRequest_Upsert]
    @SpendRequestId INT = NULL,
    @ProjectId INT,
    @DepartmentId INT,
    @ExpenseHead NVARCHAR(20),
    @Topic NVARCHAR(200),
    @Vendor NVARCHAR(200),
    @Description NVARCHAR(1000),
    @CostType NVARCHAR(100),
    @UnitType NVARCHAR(50),
    @Units DECIMAL(10,2),
    @UnitPrice DECIMAL(18,2),
    @BaseCurrency NVARCHAR(10) = 'AED',
    @ContingencyPercent DECIMAL(5,2) = 0,
    @YearlyRecurrence INT = 1,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @AmtFCY DECIMAL(18,2) = @Units * @UnitPrice
    DECLARE @AmtLCY DECIMAL(18,2) = @AmtFCY -- Assuming AED for now
    DECLARE @FinalAmt DECIMAL(18,2) = @AmtLCY + (@AmtLCY * ISNULL(@ContingencyPercent, 0) / 100)

    IF @SpendRequestId IS NULL OR @SpendRequestId = 0
    BEGIN
        DECLARE @SerialNo INT
        SELECT @SerialNo = ISNULL(MAX(SerialNo), 0) + 1 FROM [dbo].[SpendRequests] WHERE ProjectId = @ProjectId

        DECLARE @AutoId NVARCHAR(50)
        SELECT @AutoId = d.DepartmentCode + ' - ' + CAST(@SerialNo AS NVARCHAR(10))
        FROM [dbo].[Departments] d WHERE d.DepartmentId = @DepartmentId

        INSERT INTO [dbo].[SpendRequests] 
            ([ProjectId],[SerialNo],[DepartmentId],[AutoId],[ExpenseHead],[Topic],[Vendor],[Description],
             [CostType],[UnitType],[Units],[UnitPrice],[BaseCurrency],[AmountFCY],[AmountLCY],[ContingencyPercent],[FinalAmountLCY],[YearlyRecurrence],[CreatedBy])
        VALUES 
            (@ProjectId, @SerialNo, @DepartmentId, @AutoId, @ExpenseHead, @Topic, @Vendor, @Description,
             @CostType, @UnitType, @Units, @UnitPrice, @BaseCurrency, @AmtFCY, @AmtLCY, @ContingencyPercent, @FinalAmt, @YearlyRecurrence, @UserId)
        
        SELECT SCOPE_IDENTITY() AS Id
    END
    ELSE
    BEGIN
        UPDATE [dbo].[SpendRequests] SET
            DepartmentId = @DepartmentId,
            ExpenseHead = @ExpenseHead,
            Topic = @Topic,
            Vendor = @Vendor,
            [Description] = @Description,
            CostType = @CostType,
            UnitType = @UnitType,
            Units = @Units,
            UnitPrice = @UnitPrice,
            BaseCurrency = @BaseCurrency,
            AmountFCY = @AmtFCY,
            AmountLCY = @AmtLCY,
            ContingencyPercent = @ContingencyPercent,
            FinalAmountLCY = @FinalAmt,
            YearlyRecurrence = @YearlyRecurrence,
            ModifiedBy = @UserId,
            ModifiedDate = GETDATE()
        WHERE SpendRequestId = @SpendRequestId

        SELECT @SpendRequestId AS Id
    END
END
GO

-- Submit Spend Request
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SpendRequest_Submit]'))
    DROP PROCEDURE [dbo].[usp_SpendRequest_Submit]
GO
CREATE PROCEDURE [dbo].[usp_SpendRequest_Submit]
    @SpendRequestId INT,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE [dbo].[SpendRequests] SET Status = 'Submitted', SubmittedDate = GETDATE(), ModifiedBy = @UserId, ModifiedDate = GETDATE()
    WHERE SpendRequestId = @SpendRequestId

    INSERT INTO [dbo].[ApprovalHistory] ([SpendRequestId],[Action],[ActionBy],[Comments],[FromStatus],[ToStatus])
    VALUES (@SpendRequestId, 'Submitted', @UserId, 'Submitted for review', 'Draft', 'Submitted')
END
GO

-- Review Spend Request
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SpendRequest_Review]'))
    DROP PROCEDURE [dbo].[usp_SpendRequest_Review]
GO
CREATE PROCEDURE [dbo].[usp_SpendRequest_Review]
    @SpendRequestId INT,
    @UserId INT,
    @Action NVARCHAR(20), -- 'Reviewed' or 'Returned'
    @Comments NVARCHAR(1000)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @NewStatus NVARCHAR(30) = CASE WHEN @Action = 'Reviewed' THEN 'Reviewed' ELSE 'Returned' END

    UPDATE [dbo].[SpendRequests] SET 
        Status = @NewStatus, 
        ReviewedDate = GETDATE(), 
        ReviewedBy = @UserId, 
        ReviewComments = @Comments,
        ModifiedBy = @UserId, 
        ModifiedDate = GETDATE()
    WHERE SpendRequestId = @SpendRequestId

    INSERT INTO [dbo].[ApprovalHistory] ([SpendRequestId],[Action],[ActionBy],[Comments],[FromStatus],[ToStatus])
    VALUES (@SpendRequestId, @Action, @UserId, @Comments, 'Submitted', @NewStatus)
END
GO

-- Approve Spend Request
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_SpendRequest_Approve]'))
    DROP PROCEDURE [dbo].[usp_SpendRequest_Approve]
GO
CREATE PROCEDURE [dbo].[usp_SpendRequest_Approve]
    @SpendRequestId INT,
    @UserId INT,
    @Action NVARCHAR(20), -- 'Approved' or 'Rejected'
    @Comments NVARCHAR(1000)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @NewStatus NVARCHAR(30) = CASE WHEN @Action = 'Approved' THEN 'Approved' ELSE 'Rejected' END

    UPDATE [dbo].[SpendRequests] SET 
        Status = @NewStatus, 
        ApprovedDate = GETDATE(), 
        ApprovedBy = @UserId, 
        ApprovalComments = @Comments,
        ModifiedBy = @UserId, 
        ModifiedDate = GETDATE()
    WHERE SpendRequestId = @SpendRequestId

    INSERT INTO [dbo].[ApprovalHistory] ([SpendRequestId],[Action],[ActionBy],[Comments],[FromStatus],[ToStatus])
    VALUES (@SpendRequestId, @Action, @UserId, @Comments, 'Reviewed', @NewStatus)
END
GO

-- ============================================
-- BUDGET LINE ITEMS
-- ============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_BudgetLineItem_GetByRequest]'))
    DROP PROCEDURE [dbo].[usp_BudgetLineItem_GetByRequest]
GO
CREATE PROCEDURE [dbo].[usp_BudgetLineItem_GetByRequest]
    @SpendRequestId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM [dbo].[BudgetLineItems] WHERE SpendRequestId = @SpendRequestId AND IsActive = 1 ORDER BY LineNo
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_BudgetLineItem_Upsert]'))
    DROP PROCEDURE [dbo].[usp_BudgetLineItem_Upsert]
GO
CREATE PROCEDURE [dbo].[usp_BudgetLineItem_Upsert]
    @LineItemId INT = NULL,
    @SpendRequestId INT,
    @Description NVARCHAR(500),
    @CostType NVARCHAR(100),
    @UnitType NVARCHAR(50),
    @Units DECIMAL(10,2),
    @UnitPrice DECIMAL(18,2),
    @BaseCurrency NVARCHAR(10) = 'AED',
    @ContingencyPercent DECIMAL(5,2) = 0,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @AmtFCY DECIMAL(18,2) = @Units * @UnitPrice
    DECLARE @AmtLCY DECIMAL(18,2) = @AmtFCY
    DECLARE @FinalAmt DECIMAL(18,2) = @AmtLCY + (@AmtLCY * ISNULL(@ContingencyPercent, 0) / 100)

    IF @LineItemId IS NULL OR @LineItemId = 0
    BEGIN
        DECLARE @LineNo INT
        SELECT @LineNo = ISNULL(MAX(LineNo), 0) + 1 FROM [dbo].[BudgetLineItems] WHERE SpendRequestId = @SpendRequestId

        INSERT INTO [dbo].[BudgetLineItems]
            ([SpendRequestId],[LineNo],[Description],[CostType],[UnitType],[Units],[UnitPrice],[BaseCurrency],[AmountFCY],[AmountLCY],[ContingencyPercent],[FinalAmountLCY],[CreatedBy])
        VALUES
            (@SpendRequestId, @LineNo, @Description, @CostType, @UnitType, @Units, @UnitPrice, @BaseCurrency, @AmtFCY, @AmtLCY, @ContingencyPercent, @FinalAmt, @UserId)
        
        SELECT SCOPE_IDENTITY() AS Id
    END
    ELSE
    BEGIN
        UPDATE [dbo].[BudgetLineItems] SET
            [Description] = @Description,
            CostType = @CostType,
            UnitType = @UnitType,
            Units = @Units,
            UnitPrice = @UnitPrice,
            BaseCurrency = @BaseCurrency,
            AmountFCY = @AmtFCY,
            AmountLCY = @AmtLCY,
            ContingencyPercent = @ContingencyPercent,
            FinalAmountLCY = @FinalAmt,
            ModifiedBy = @UserId,
            ModifiedDate = GETDATE()
        WHERE LineItemId = @LineItemId

        SELECT @LineItemId AS Id
    END
END
GO

-- ============================================
-- INVOICES
-- ============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Invoice_GetByRequest]'))
    DROP PROCEDURE [dbo].[usp_Invoice_GetByRequest]
GO
CREATE PROCEDURE [dbo].[usp_Invoice_GetByRequest]
    @SpendRequestId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM [dbo].[Invoices] WHERE SpendRequestId = @SpendRequestId AND IsActive = 1 ORDER BY InvoiceDate DESC
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Invoice_Upsert]'))
    DROP PROCEDURE [dbo].[usp_Invoice_Upsert]
GO
CREATE PROCEDURE [dbo].[usp_Invoice_Upsert]
    @InvoiceId INT = NULL,
    @SpendRequestId INT,
    @InvoiceNumber NVARCHAR(50),
    @InvoiceDate DATETIME,
    @VendorName NVARCHAR(200),
    @Description NVARCHAR(500),
    @Amount DECIMAL(18,2),
    @Currency NVARCHAR(10) = 'AED',
    @AmountLCY DECIMAL(18,2),
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @InvoiceId IS NULL OR @InvoiceId = 0
    BEGIN
        INSERT INTO [dbo].[Invoices]
            ([SpendRequestId],[InvoiceNumber],[InvoiceDate],[VendorName],[Description],[Amount],[Currency],[AmountLCY],[CreatedBy])
        VALUES
            (@SpendRequestId, @InvoiceNumber, @InvoiceDate, @VendorName, @Description, @Amount, @Currency, @AmountLCY, @UserId)
        
        SELECT SCOPE_IDENTITY() AS Id
    END
    ELSE
    BEGIN
        UPDATE [dbo].[Invoices] SET
            InvoiceNumber = @InvoiceNumber,
            InvoiceDate = @InvoiceDate,
            VendorName = @VendorName,
            [Description] = @Description,
            Amount = @Amount,
            Currency = @Currency,
            AmountLCY = @AmountLCY,
            ModifiedBy = @UserId,
            ModifiedDate = GETDATE()
        WHERE InvoiceId = @InvoiceId

        SELECT @InvoiceId AS Id
    END
END
GO

-- ============================================
-- DASHBOARD
-- ============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_Dashboard_Summary]'))
    DROP PROCEDURE [dbo].[usp_Dashboard_Summary]
GO
CREATE PROCEDURE [dbo].[usp_Dashboard_Summary]
    @UserId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Total Budget Summary
    SELECT 
        (SELECT ISNULL(SUM(Budget), 0) FROM CAPEX WHERE IsActive = 1) AS TotalCapexBudget,
        (SELECT ISNULL(SUM(Utilization), 0) FROM CAPEX WHERE IsActive = 1) AS TotalCapexUtilization,
        (SELECT ISNULL(SUM(AvailableBudget), 0) FROM CAPEX WHERE IsActive = 1) AS TotalCapexAvailable,
        (SELECT ISNULL(SUM(Budget), 0) FROM OPEX WHERE IsActive = 1) AS TotalOpexBudget,
        (SELECT ISNULL(SUM(Utilization), 0) FROM OPEX WHERE IsActive = 1) AS TotalOpexUtilization,
        (SELECT ISNULL(SUM(AvailableBudget), 0) FROM OPEX WHERE IsActive = 1) AS TotalOpexAvailable

    -- Spend Request Status Counts
    SELECT Status, COUNT(*) AS Count 
    FROM SpendRequests 
    GROUP BY Status

    -- Recent Spend Requests
    SELECT TOP 10 sr.SpendRequestId, sr.Topic, sr.FinalAmountLCY, sr.Status, sr.CreatedDate, 
           p.ProjectName, u.DisplayName AS RequestorName
    FROM SpendRequests sr
    INNER JOIN Projects p ON sr.ProjectId = p.ProjectId
    LEFT JOIN Users u ON sr.CreatedBy = u.UserId
    ORDER BY sr.CreatedDate DESC

    -- Pending Actions for User
    IF @UserId IS NOT NULL
    BEGIN
        SELECT sr.SpendRequestId, sr.Topic, sr.FinalAmountLCY, sr.Status, p.ProjectName
        FROM SpendRequests sr
        INNER JOIN Projects p ON sr.ProjectId = p.ProjectId
        WHERE (sr.Status = 'Submitted' AND p.ReviewerId = @UserId)
           OR (sr.Status = 'Reviewed' AND p.ApproverId = @UserId)
        ORDER BY sr.CreatedDate
    END
END
GO

-- ============================================
-- USER/ROLE MANAGEMENT
-- ============================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_User_GetByJiraId]'))
    DROP PROCEDURE [dbo].[usp_User_GetByJiraId]
GO
CREATE PROCEDURE [dbo].[usp_User_GetByJiraId]
    @JiraUserId NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT u.*, r.RoleName FROM [dbo].[Users] u
    LEFT JOIN [dbo].[Roles] r ON u.RoleId = r.RoleId
    WHERE u.JiraUserId = @JiraUserId AND u.IsActive = 1
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usp_ReviewerApprover_GetAll]'))
    DROP PROCEDURE [dbo].[usp_ReviewerApprover_GetAll]
GO
CREATE PROCEDURE [dbo].[usp_ReviewerApprover_GetAll]
    @RoleType NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ra.*, u.DisplayName, u.Email, d.DepartmentName
    FROM [dbo].[ReviewerApprover] ra
    INNER JOIN [dbo].[Users] u ON ra.UserId = u.UserId
    LEFT JOIN [dbo].[Departments] d ON ra.DepartmentId = d.DepartmentId
    WHERE ra.IsActive = 1 AND (@RoleType IS NULL OR ra.RoleType = @RoleType)
END
GO

PRINT 'Stored procedures created successfully.'
GO
