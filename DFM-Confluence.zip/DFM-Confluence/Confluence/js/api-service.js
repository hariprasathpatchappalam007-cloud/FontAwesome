/**
 * CET Portfolio Financial Tracker - API Service Layer
 */
var CETApi = (function () {
    'use strict';

    function request(method, endpoint, data) {
        return new Promise(function (resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open(method, CETConfig.apiBaseUrl + endpoint, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status >= 200 && xhr.status < 300) {
                        try {
                            var response = JSON.parse(xhr.responseText);
                            resolve(response);
                        } catch (e) {
                            reject({ message: 'Invalid response format' });
                        }
                    } else {
                        reject({ message: 'Request failed: ' + xhr.status });
                    }
                }
            };
            xhr.onerror = function () { reject({ message: 'Network error' }); };
            xhr.send(data ? JSON.stringify(data) : null);
        });
    }

    return {
        // CAPEX
        getCapexAll: function () { return request('GET', '/capex/getall'); },
        getCapexById: function (id) { return request('GET', '/capex/get/' + id); },
        saveCapex: function (data) { return request('POST', '/capex/save', data); },
        deleteCapex: function (id, userId) { return request('POST', '/capex/delete?id=' + id + '&userId=' + userId); },
        importCapex: function (data) { return request('POST', '/capex/import', data); },

        // OPEX
        getOpexAll: function () { return request('GET', '/opex/getall'); },
        saveOpex: function (data) { return request('POST', '/opex/save', data); },
        importOpex: function (data) { return request('POST', '/opex/import', data); },

        // Projects
        getProjects: function (userId) { return request('GET', '/project/getall' + (userId ? '?userId=' + userId : '')); },
        saveProject: function (data) { return request('POST', '/project/save', data); },

        // Spend Requests
        getSpendRequests: function (params) {
            var query = [];
            if (params.projectId) query.push('projectId=' + params.projectId);
            if (params.status) query.push('status=' + params.status);
            if (params.userId) query.push('userId=' + params.userId);
            if (params.roleType) query.push('roleType=' + params.roleType);
            return request('GET', '/spendrequest/getall' + (query.length ? '?' + query.join('&') : ''));
        },
        saveSpendRequest: function (data) { return request('POST', '/spendrequest/save', data); },
        submitSpendRequest: function (data) { return request('POST', '/spendrequest/submit', data); },
        reviewSpendRequest: function (data) { return request('POST', '/spendrequest/review', data); },
        approveSpendRequest: function (data) { return request('POST', '/spendrequest/approve', data); },

        // Budget Line Items
        getBudgetLineItems: function (spendRequestId) { return request('GET', '/budgetlineitem/getbyrequest/' + spendRequestId); },
        saveBudgetLineItem: function (data) { return request('POST', '/budgetlineitem/save', data); },
        deleteLineItem: function (id, userId) { return request('POST', '/budgetlineitem/delete?id=' + id + '&userId=' + userId); },

        // Invoices
        getInvoices: function (spendRequestId) { return request('GET', '/invoice/getbyrequest/' + spendRequestId); },
        saveInvoice: function (data) { return request('POST', '/invoice/save', data); },
        deleteInvoice: function (id, userId) { return request('POST', '/invoice/delete?id=' + id + '&userId=' + userId); },

        // Dashboard
        getDashboard: function (userId) { return request('GET', '/dashboard/summary' + (userId ? '?userId=' + userId : '')); },

        // Users
        getUserByJira: function (jiraId) { return request('GET', '/user/getbyjira/' + encodeURIComponent(jiraId)); },
        getReviewers: function () { return request('GET', '/user/reviewers'); },
        getApprovers: function () { return request('GET', '/user/approvers'); },
        saveReviewerApprover: function (data) { return request('POST', '/user/savereviewerapprover', data); },
        removeReviewerApprover: function (id) { return request('POST', '/user/removereviewerapprover?id=' + id); },

        // Lookups
        getDepartments: function () { return request('GET', '/lookup/departments'); },
        getCostTypes: function () { return request('GET', '/lookup/costtypes'); },
        getUnitTypes: function () { return request('GET', '/lookup/unittypes'); },
        getCurrencies: function () { return request('GET', '/lookup/currencies'); }
    };
})();
