/**
 * CET Portfolio Financial Tracker - Configuration
 * Update these values based on your environment
 */
var CETConfig = {
    // API Base URL - Update this to your IIS hosted API URL
    apiBaseUrl: 'https://your-server/CETFinTrackerAPI/api',

    // JIRA Configuration
    jiraBaseUrl: 'https://your-jira-instance.atlassian.net',
    jiraApiPath: '/rest/api/2',

    // Confluence Configuration  
    confluenceBaseUrl: 'https://your-confluence-instance.atlassian.net',

    // Application Settings
    appName: 'CET Portfolio Financial Tracker',
    appVersion: '1.0.0',
    currency: 'AED',
    dateFormat: 'DD/MM/YYYY',

    // Color Scheme (from colorCode.csv)
    colors: {
        spendRequest: { header: '#2F5597', background: '#F5F9FF', border: '#B4C7E7' },
        budgetLineItems: { header: '#548235', background: '#F6FBF4', border: '#C6E0B4' },
        invoice: { header: '#C55A11', background: '#FFF8F2', border: '#F4B183' },
        approvalHistory: { header: '#7F6000', background: '#FFFBEA', border: '#FFE699' },
        comments: { header: '#5B5B5B', background: '#FAFAFA', border: '#D9D9D9' },
        attachments: { header: '#1F4E78', background: '#F3F9FD', border: '#9DC3E6' },
        auditTrail: { header: '#7030A0', background: '#FAF5FF', border: '#D9C2E9' }
    },

    // Status Colors
    statusColors: {
        'Draft': '#6c757d',
        'Submitted': '#0d6efd',
        'UnderReview': '#fd7e14',
        'Reviewed': '#198754',
        'Approved': '#198754',
        'Rejected': '#dc3545',
        'Returned': '#ffc107'
    },

    // Departments
    departments: [
        { id: 1, code: 'GOV', name: 'Governance' },
        { id: 2, code: 'COR', name: 'Core' },
        { id: 3, code: 'EIS', name: 'EIS' },
        { id: 4, code: 'CRM', name: 'CRM' },
        { id: 5, code: 'AE', name: 'EA&I' },
        { id: 6, code: 'RSK', name: 'Risk' },
        { id: 7, code: 'CET', name: 'CET' },
        { id: 8, code: 'BUS', name: 'Business' },
        { id: 9, code: 'CIO', name: 'CIO Office' },
        { id: 10, code: 'CTO', name: 'CTO' },
        { id: 11, code: 'RTB', name: 'RTB' },
        { id: 12, code: 'TEST', name: 'Test Gov.' }
    ],

    // Cost Types
    costTypes: [
        'UAT Functional Testing', 'Development', 'Design & ReEngineering',
        'Infrastructure', 'Licensing', 'Consultancy', 'Support & Maintenance',
        'Training', 'Hardware', 'Software', 'Cloud Services', 'Other'
    ],

    // Unit Types
    unitTypes: [
        'Man Days', 'Man Months', 'Hours', 'Units', 'Licenses', 'Instances', 'Per Month', 'Lump Sum'
    ],

    // Currencies
    currencies: [
        { code: 'AED', name: 'UAE Dirham', rate: 1 },
        { code: 'USD', name: 'US Dollar', rate: 3.67 },
        { code: 'EUR', name: 'Euro', rate: 4.02 },
        { code: 'GBP', name: 'British Pound', rate: 4.65 },
        { code: 'INR', name: 'Indian Rupee', rate: 0.044 }
    ]
};
