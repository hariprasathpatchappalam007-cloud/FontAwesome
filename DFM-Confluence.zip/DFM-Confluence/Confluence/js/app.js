/**
 * CET Portfolio Financial Tracker - Main Application Logic
 */
var CETApp = (function () {
    'use strict';

    var currentUser = null;
    var currentView = 'dashboard';

    // ===== INITIALIZATION =====
    function init() {
        loadCurrentUser();
        setupNavigation();
        showView('dashboard');
    }

    function loadCurrentUser() {
        // Attempt to get JIRA logged-in user from Confluence context
        try {
            if (typeof AJS !== 'undefined' && AJS.params && AJS.params.remoteUser) {
                var jiraId = AJS.params.remoteUser;
                CETApi.getUserByJira(jiraId).then(function (res) {
                    if (res.success) {
                        currentUser = res.data;
                        updateUserDisplay();
                    }
                });
            } else {
                // Fallback for testing
                currentUser = { userId: 1, displayName: 'Test User', roleName: 'Administrator' };
                updateUserDisplay();
            }
        } catch (e) {
            currentUser = { userId: 1, displayName: 'Test User', roleName: 'Administrator' };
            updateUserDisplay();
        }
    }

    function updateUserDisplay() {
        var el = document.getElementById('currentUserName');
        if (el && currentUser) {
            el.textContent = currentUser.displayName;
        }
        var roleEl = document.getElementById('currentUserRole');
        if (roleEl && currentUser) {
            roleEl.textContent = currentUser.roleName;
        }
    }

    // ===== NAVIGATION =====
    function setupNavigation() {
        var navLinks = document.querySelectorAll('[data-view]');
        for (var i = 0; i < navLinks.length; i++) {
            navLinks[i].addEventListener('click', function (e) {
                e.preventDefault();
                var view = this.getAttribute('data-view');
                showView(view);
            });
        }
    }

    function showView(viewName) {
        currentView = viewName;
        var views = document.querySelectorAll('.cet-view');
        for (var i = 0; i < views.length; i++) {
            views[i].style.display = 'none';
        }
        var target = document.getElementById('view-' + viewName);
        if (target) {
            target.style.display = 'block';
        }

        // Update active nav
        var navLinks = document.querySelectorAll('[data-view]');
        for (var j = 0; j < navLinks.length; j++) {
            navLinks[j].classList.remove('active');
            if (navLinks[j].getAttribute('data-view') === viewName) {
                navLinks[j].classList.add('active');
            }
        }

        // Load view data
        switch (viewName) {
            case 'dashboard': loadDashboard(); break;
            case 'capex': loadCapexList(); break;
            case 'opex': loadOpexList(); break;
            case 'projects': loadProjectList(); break;
            case 'spend-requests': loadSpendRequestList(); break;
            case 'reviewer': loadReviewerQueue(); break;
            case 'approver': loadApproverQueue(); break;
            case 'masters': loadMasters(); break;
        }
    }

    // ===== DASHBOARD =====
    function loadDashboard() {
        CETApi.getDashboard(currentUser ? currentUser.userId : null).then(function (res) {
            if (res.success) {
                renderDashboard(res.data);
            }
        }).catch(function () {
            // Show empty dashboard
            renderDashboardEmpty();
        });
    }

    function renderDashboard(data) {
        var summary = data.budgetSummary || {};
        document.getElementById('dash-capex-budget').textContent = formatCurrency(summary.totalCapexBudget || 0);
        document.getElementById('dash-capex-utilized').textContent = formatCurrency(summary.totalCapexUtilization || 0);
        document.getElementById('dash-capex-available').textContent = formatCurrency(summary.totalCapexAvailable || 0);
        document.getElementById('dash-opex-budget').textContent = formatCurrency(summary.totalOpexBudget || 0);
        document.getElementById('dash-opex-utilized').textContent = formatCurrency(summary.totalOpexUtilization || 0);
        document.getElementById('dash-opex-available').textContent = formatCurrency(summary.totalOpexAvailable || 0);

        // Status counts
        var statusCounts = data.statusCounts || [];
        var statusHtml = '';
        for (var i = 0; i < statusCounts.length; i++) {
            var sc = statusCounts[i];
            var color = CETConfig.statusColors[sc.status] || '#6c757d';
            statusHtml += '<div class="status-card" style="border-left: 4px solid ' + color + '">' +
                '<div class="status-count">' + sc.count + '</div>' +
                '<div class="status-label">' + sc.status + '</div></div>';
        }
        document.getElementById('dash-status-counts').innerHTML = statusHtml;

        // Pending actions
        var pending = data.pendingActions || [];
        var pendingHtml = '';
        if (pending.length === 0) {
            pendingHtml = '<p class="text-muted">No pending actions</p>';
        } else {
            pendingHtml = '<table class="cet-table"><thead><tr><th>Project</th><th>Topic</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>';
            for (var j = 0; j < pending.length; j++) {
                var p = pending[j];
                pendingHtml += '<tr><td>' + escapeHtml(p.projectName) + '</td><td>' + escapeHtml(p.topic) + '</td>' +
                    '<td>' + formatCurrency(p.finalAmountLCY) + '</td><td><span class="badge" style="background:' + (CETConfig.statusColors[p.status] || '#6c757d') + '">' + p.status + '</span></td>' +
                    '<td><button class="btn btn-sm btn-primary" onclick="CETApp.openSpendRequest(' + p.spendRequestId + ')">View</button></td></tr>';
            }
            pendingHtml += '</tbody></table>';
        }
        document.getElementById('dash-pending-actions').innerHTML = pendingHtml;
    }

    function renderDashboardEmpty() {
        document.getElementById('dash-capex-budget').textContent = formatCurrency(0);
        document.getElementById('dash-capex-utilized').textContent = formatCurrency(0);
        document.getElementById('dash-capex-available').textContent = formatCurrency(0);
        document.getElementById('dash-opex-budget').textContent = formatCurrency(0);
        document.getElementById('dash-opex-utilized').textContent = formatCurrency(0);
        document.getElementById('dash-opex-available').textContent = formatCurrency(0);
    }

    // ===== CAPEX MANAGEMENT =====
    function loadCapexList() {
        CETApi.getCapexAll().then(function (res) {
            if (res.success) {
                renderCapexTable(res.data);
            }
        });
    }

    function renderCapexTable(items) {
        var html = '<table class="cet-table"><thead><tr>' +
            '<th>Budget ID</th><th>Description</th><th>Budget</th><th>Utilization</th>' +
            '<th>Available</th><th>Locked</th><th>Net Balance</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + escapeHtml(item.budgetId) + '</td><td class="desc-cell">' + escapeHtml(item.description) + '</td>' +
                '<td class="amt">' + formatCurrency(item.budget) + '</td><td class="amt">' + formatCurrency(item.utilization) + '</td>' +
                '<td class="amt">' + formatCurrency(item.availableBudget) + '</td><td class="amt">' + formatCurrency(item.lockedAmt) + '</td>' +
                '<td class="amt">' + formatCurrency(item.netBalance) + '</td>' +
                '<td><button class="btn btn-sm btn-edit" onclick="CETApp.editCapex(' + item.capexId + ')">Edit</button></td></tr>';
        }
        html += '</tbody></table>';
        document.getElementById('capex-table-container').innerHTML = html;
    }

    function showCapexForm(data) {
        var modal = document.getElementById('capexModal');
        if (data) {
            document.getElementById('capex-id').value = data.capexId || 0;
            document.getElementById('capex-budgetId').value = data.budgetId || '';
            document.getElementById('capex-description').value = data.description || '';
            document.getElementById('capex-budget').value = data.budget || 0;
            document.getElementById('capex-utilization').value = data.utilization || 0;
            document.getElementById('capex-locked').value = data.lockedAmt || 0;
        } else {
            document.getElementById('capexForm').reset();
            document.getElementById('capex-id').value = 0;
        }
        modal.style.display = 'flex';
    }

    function saveCapex() {
        var budget = parseFloat(document.getElementById('capex-budget').value) || 0;
        var utilization = parseFloat(document.getElementById('capex-utilization').value) || 0;
        var locked = parseFloat(document.getElementById('capex-locked').value) || 0;
        var available = budget - utilization;
        var afterLocked = available - locked;

        var model = {
            capexId: parseInt(document.getElementById('capex-id').value) || 0,
            budgetId: document.getElementById('capex-budgetId').value,
            description: document.getElementById('capex-description').value,
            budget: budget,
            utilization: utilization,
            availableBudget: available,
            lockedAmt: locked,
            budgetAfterLocked: afterLocked,
            claimAmt: 0,
            netBalance: afterLocked,
            createdBy: currentUser ? currentUser.userId : 1
        };

        CETApi.saveCapex(model).then(function (res) {
            if (res.success) {
                closeModal('capexModal');
                loadCapexList();
                showToast('CAPEX saved successfully', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    function editCapex(id) {
        CETApi.getCapexById(id).then(function (res) {
            if (res.success) {
                showCapexForm(res.data);
            }
        });
    }

    // ===== OPEX MANAGEMENT =====
    function loadOpexList() {
        CETApi.getOpexAll().then(function (res) {
            if (res.success) {
                renderOpexTable(res.data);
            }
        });
    }

    function renderOpexTable(items) {
        var html = '<table class="cet-table"><thead><tr>' +
            '<th>Budget ID</th><th>Description</th><th>Budget</th><th>Utilization</th>' +
            '<th>Available</th><th>Locked</th><th>Net Balance</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + escapeHtml(item.budgetId) + '</td><td class="desc-cell">' + escapeHtml(item.description) + '</td>' +
                '<td class="amt">' + formatCurrency(item.budget) + '</td><td class="amt">' + formatCurrency(item.utilization) + '</td>' +
                '<td class="amt">' + formatCurrency(item.availableBudget) + '</td><td class="amt">' + formatCurrency(item.lockedAmt) + '</td>' +
                '<td class="amt">' + formatCurrency(item.netBalance) + '</td>' +
                '<td><button class="btn btn-sm btn-edit" onclick="CETApp.editOpex(' + item.opexId + ')">Edit</button></td></tr>';
        }
        html += '</tbody></table>';
        document.getElementById('opex-table-container').innerHTML = html;
    }

    // ===== PROJECT REGISTRATION =====
    function loadProjectList() {
        CETApi.getProjects(currentUser ? currentUser.userId : null).then(function (res) {
            if (res.success) {
                renderProjectTable(res.data);
            }
        });
    }

    function renderProjectTable(items) {
        var html = '<table class="cet-table"><thead><tr>' +
            '<th>Project Name</th><th>Type</th><th>JIRA Key</th><th>Budget Source</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + escapeHtml(item.projectName) + '</td><td><span class="badge badge-info">' + item.projectType + '</span></td>' +
                '<td>' + (item.jiraProjectKey || '-') + '</td><td><span class="badge badge-' + item.budgetSource.toLowerCase() + '">' + item.budgetSource + '</span></td>' +
                '<td><span class="badge" style="background:' + (CETConfig.statusColors[item.status] || '#6c757d') + '">' + item.status + '</span></td>' +
                '<td><button class="btn btn-sm btn-primary" onclick="CETApp.viewProject(' + item.projectId + ')">View</button></td></tr>';
        }
        html += '</tbody></table>';
        document.getElementById('project-table-container').innerHTML = html;
    }

    function showProjectForm() {
        document.getElementById('projectForm').reset();
        document.getElementById('project-id').value = 0;
        document.getElementById('project-jira-key-group').style.display = 'none';
        document.getElementById('project-name-group').style.display = 'none';
        loadBudgetDropdowns();

        // Load Reviewers
        CETApi.getReviewers().then(function (res) {
            if (res.success) {
                var select = document.getElementById('project-reviewer');
                select.innerHTML = '<option value="">-- Select Reviewer --</option>';
                for (var i = 0; i < res.data.length; i++) {
                    var opt = document.createElement('option');
                    opt.value = res.data[i].userId;
                    opt.textContent = res.data[i].displayName + ' (' + res.data[i].departmentName + ')';
                    select.appendChild(opt);
                }
            }
        });

        // Load Approvers
        CETApi.getApprovers().then(function (res) {
            if (res.success) {
                var select = document.getElementById('project-approver');
                select.innerHTML = '<option value="">-- Select Approver --</option>';
                for (var i = 0; i < res.data.length; i++) {
                    var opt = document.createElement('option');
                    opt.value = res.data[i].userId;
                    opt.textContent = res.data[i].displayName + ' (' + res.data[i].departmentName + ')';
                    select.appendChild(opt);
                }
            }
        });

        document.getElementById('projectModal').style.display = 'flex';
    }

    function onProjectTypeChange() {
        var type = document.getElementById('project-type').value;
        document.getElementById('project-jira-key-group').style.display = type === 'JIRA' ? 'block' : 'none';
        document.getElementById('project-name-group').style.display = type === 'Non-JIRA' ? 'block' : 'none';
        if (type === 'JIRA') {
            loadJiraProjects();
        }
    }

    function loadJiraProjects() {
        // In production, this would call JIRA REST API via our backend
        // For now, display text input for JIRA project key
    }

    function loadBudgetDropdowns() {
        var source = document.getElementById('project-budget-source').value;
        var select = document.getElementById('project-budget-ref');
        select.innerHTML = '<option value="">-- Select Budget --</option>';

        if (source === 'CAPEX') {
            CETApi.getCapexAll().then(function (res) {
                if (res.success) {
                    for (var i = 0; i < res.data.length; i++) {
                        var opt = document.createElement('option');
                        opt.value = res.data[i].capexId;
                        opt.textContent = res.data[i].budgetId + ' - ' + res.data[i].description.substring(0, 50);
                        select.appendChild(opt);
                    }
                }
            });
        } else if (source === 'OPEX') {
            CETApi.getOpexAll().then(function (res) {
                if (res.success) {
                    for (var i = 0; i < res.data.length; i++) {
                        var opt = document.createElement('option');
                        opt.value = res.data[i].opexId;
                        opt.textContent = res.data[i].budgetId + ' - ' + res.data[i].description.substring(0, 50);
                        select.appendChild(opt);
                    }
                }
            });
        }
    }

    function saveProject() {
        var type = document.getElementById('project-type').value;
        var model = {
            projectId: parseInt(document.getElementById('project-id').value) || 0,
            projectType: type,
            jiraProjectKey: type === 'JIRA' ? document.getElementById('project-jira-key').value : null,
            projectName: type === 'JIRA' ? document.getElementById('project-jira-key').value : document.getElementById('project-name').value,
            budgetSource: document.getElementById('project-budget-source').value,
            budgetReferenceId: parseInt(document.getElementById('project-budget-ref').value) || null,
            requestorId: currentUser ? currentUser.userId : 1,
            reviewerId: parseInt(document.getElementById('project-reviewer').value) || null,
            approverId: parseInt(document.getElementById('project-approver').value) || null
        };

        CETApi.saveProject(model).then(function (res) {
            if (res.success) {
                closeModal('projectModal');
                loadProjectList();
                showToast('Project saved successfully', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    // ===== SPEND REQUESTS =====
    function loadSpendRequestList() {
        CETApi.getSpendRequests({ userId: currentUser ? currentUser.userId : null, roleType: 'Requestor' }).then(function (res) {
            if (res.success) {
                renderSpendRequestTable(res.data, 'spend-request-table-container');
            }
        });
    }

    function renderSpendRequestTable(items, containerId) {
        var html = '<table class="cet-table"><thead><tr>' +
            '<th>ID</th><th>Project</th><th>Department</th><th>Topic</th><th>Vendor</th><th>Amount (AED)</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + escapeHtml(item.autoId) + '</td><td>' + escapeHtml(item.projectName) + '</td>' +
                '<td>' + escapeHtml(item.departmentName || '') + '</td><td>' + escapeHtml(item.topic) + '</td>' +
                '<td>' + escapeHtml(item.vendor) + '</td><td class="amt">' + formatCurrency(item.finalAmountLCY) + '</td>' +
                '<td><span class="badge" style="background:' + (CETConfig.statusColors[item.status] || '#6c757d') + '">' + item.status + '</span></td>' +
                '<td>' + getSpendRequestActions(item) + '</td></tr>';
        }
        html += '</tbody></table>';
        document.getElementById(containerId).innerHTML = html;
    }

    function getSpendRequestActions(item) {
        var actions = '<button class="btn btn-sm btn-primary" onclick="CETApp.openSpendRequest(' + item.spendRequestId + ')">View</button> ';
        if (item.status === 'Draft') {
            actions += '<button class="btn btn-sm btn-edit" onclick="CETApp.editSpendRequest(' + item.spendRequestId + ')">Edit</button> ';
            actions += '<button class="btn btn-sm btn-success" onclick="CETApp.submitSpendRequest(' + item.spendRequestId + ')">Submit</button>';
        }
        return actions;
    }

    function showSpendRequestForm(projectId) {
        document.getElementById('spendRequestForm').reset();
        document.getElementById('sr-id').value = 0;
        document.getElementById('sr-project-id').value = projectId || '';
        populateDropdown('sr-department', CETConfig.departments, 'id', 'name');
        populateDropdown('sr-cost-type', CETConfig.costTypes);
        populateDropdown('sr-unit-type', CETConfig.unitTypes);
        populateDropdown('sr-currency', CETConfig.currencies, 'code', 'code');
        document.getElementById('spendRequestModal').style.display = 'flex';
    }

    function saveSpendRequest() {
        var model = {
            spendRequestId: parseInt(document.getElementById('sr-id').value) || 0,
            projectId: parseInt(document.getElementById('sr-project-id').value),
            departmentId: parseInt(document.getElementById('sr-department').value),
            expenseHead: document.getElementById('sr-expense-head').value,
            topic: document.getElementById('sr-topic').value,
            vendor: document.getElementById('sr-vendor').value,
            description: document.getElementById('sr-description').value,
            costType: document.getElementById('sr-cost-type').value,
            unitType: document.getElementById('sr-unit-type').value,
            units: parseFloat(document.getElementById('sr-units').value) || 0,
            unitPrice: parseFloat(document.getElementById('sr-unit-price').value) || 0,
            baseCurrency: document.getElementById('sr-currency').value,
            contingencyPercent: parseFloat(document.getElementById('sr-contingency').value) || 0,
            yearlyRecurrence: parseInt(document.getElementById('sr-recurrence').value) || 1
        };

        CETApi.saveSpendRequest(model).then(function (res) {
            if (res.success) {
                closeModal('spendRequestModal');
                loadSpendRequestList();
                showToast('Spend request saved', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    function submitSpendRequest(id) {
        if (!confirm('Submit this spend request for review?')) return;
        CETApi.submitSpendRequest({ spendRequestId: id, userId: currentUser ? currentUser.userId : 1 }).then(function (res) {
            if (res.success) {
                loadSpendRequestList();
                showToast('Submitted for review', 'success');
            }
        });
    }

    // ===== REVIEWER QUEUE =====
    function loadReviewerQueue() {
        CETApi.getSpendRequests({ userId: currentUser ? currentUser.userId : null, roleType: 'Reviewer', status: 'Submitted' }).then(function (res) {
            if (res.success) {
                renderReviewerQueueTable(res.data);
            }
        });
    }

    function reviewAction(id, action) {
        var comments = prompt('Enter your review comments:');
        if (comments === null) return;
        CETApi.reviewSpendRequest({ spendRequestId: id, userId: currentUser ? currentUser.userId : 1, action: action, comments: comments }).then(function (res) {
            if (res.success) {
                loadReviewerQueue();
                showToast('Review action completed', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    // ===== APPROVER QUEUE =====
    function loadApproverQueue() {
        CETApi.getSpendRequests({ userId: currentUser ? currentUser.userId : null, roleType: 'Approver', status: 'Reviewed' }).then(function (res) {
            if (res.success) {
                renderApproverQueueTable(res.data);
            }
        });
    }

    function approveAction(id, action) {
        var comments = prompt('Enter your approval comments:');
        if (comments === null) return;
        CETApi.approveSpendRequest({ spendRequestId: id, userId: currentUser ? currentUser.userId : 1, action: action, comments: comments }).then(function (res) {
            if (res.success) {
                loadApproverQueue();
                showToast('Approval action completed', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    // ===== BUDGET LINE ITEMS =====
    function loadBudgetLineItems(spendRequestId) {
        CETApi.getBudgetLineItems(spendRequestId).then(function (res) {
            if (res.success) {
                renderBudgetLineItems(res.data, spendRequestId);
            }
        });
    }

    function renderBudgetLineItems(items, spendRequestId) {
        var html = '<table class="cet-table"><thead><tr>' +
            '<th>#</th><th>Description</th><th>Cost Type</th><th>Unit Type</th><th>Units</th><th>Unit Price</th><th>Amount (AED)</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + item.lineNo + '</td><td>' + escapeHtml(item.description) + '</td>' +
                '<td>' + escapeHtml(item.costType) + '</td><td>' + item.unitType + '</td>' +
                '<td>' + item.units + '</td><td>' + formatCurrency(item.unitPrice) + '</td>' +
                '<td class="amt">' + formatCurrency(item.finalAmountLCY) + '</td>' +
                '<td><button class="btn btn-sm btn-edit" onclick="CETApp.editLineItem(' + item.lineItemId + ')">Edit</button></td></tr>';
        }
        html += '</tbody></table>';
        html += '<button class="btn btn-success" onclick="CETApp.addLineItem(' + spendRequestId + ')">+ Add Line Item</button>';
        document.getElementById('budget-lineitems-container').innerHTML = html;
    }

    // ===== INVOICES =====
    function loadInvoices(spendRequestId) {
        CETApi.getInvoices(spendRequestId).then(function (res) {
            if (res.success) {
                renderInvoices(res.data, spendRequestId);
            }
        });
    }

    function renderInvoices(items, spendRequestId) {
        var html = '<table class="cet-table"><thead><tr>' +
            '<th>Invoice #</th><th>Date</th><th>Vendor</th><th>Description</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + escapeHtml(item.invoiceNumber) + '</td><td>' + formatDate(item.invoiceDate) + '</td>' +
                '<td>' + escapeHtml(item.vendorName) + '</td><td>' + escapeHtml(item.description) + '</td>' +
                '<td class="amt">' + formatCurrency(item.amountLCY) + '</td>' +
                '<td><span class="badge">' + item.status + '</span></td>' +
                '<td><button class="btn btn-sm btn-edit" onclick="CETApp.editInvoice(' + item.invoiceId + ')">Edit</button></td></tr>';
        }
        html += '</tbody></table>';
        html += '<button class="btn btn-success" onclick="CETApp.addInvoice(' + spendRequestId + ')">+ Add Invoice</button>';
        document.getElementById('invoices-container').innerHTML = html;
    }

    // ===== CSV IMPORT =====
    function importCsv(type) {
        var input = document.createElement('input');
        input.type = 'file';
        input.accept = '.csv';
        input.onchange = function (e) {
            var file = e.target.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function (event) {
                var csv = event.target.result;
                var items = parseCsv(csv, type);
                if (type === 'CAPEX') {
                    CETApi.importCapex(items).then(function (res) {
                        if (res.success) {
                            loadCapexList();
                            showToast(res.message, 'success');
                        }
                    });
                } else {
                    CETApi.importOpex(items).then(function (res) {
                        if (res.success) {
                            loadOpexList();
                            showToast(res.message, 'success');
                        }
                    });
                }
            };
            reader.readAsText(file);
        };
        input.click();
    }

    function parseCsv(csvText, type) {
        var lines = csvText.split('\n');
        var items = [];
        for (var i = 1; i < lines.length; i++) { // Skip header
            var cols = parseCSVLine(lines[i]);
            if (cols.length < 10 || !cols[1]) continue;
            items.push({
                budgetId: cols[1].trim(),
                description: cols[2].trim(),
                budget: parseAmount(cols[3]),
                utilization: parseAmount(cols[4]),
                availableBudget: parseAmount(cols[5]),
                lockedAmt: parseAmount(cols[6]),
                budgetAfterLocked: parseAmount(cols[7]),
                claimAmt: parseAmount(cols[8]),
                netBalance: parseAmount(cols[9]),
                createdBy: currentUser ? currentUser.userId : 1
            });
        }
        return items;
    }

    function parseCSVLine(line) {
        var result = [];
        var current = '';
        var inQuotes = false;
        for (var i = 0; i < line.length; i++) {
            var ch = line[i];
            if (ch === '"') {
                inQuotes = !inQuotes;
            } else if (ch === ',' && !inQuotes) {
                result.push(current);
                current = '';
            } else {
                current += ch;
            }
        }
        result.push(current);
        return result;
    }

    function parseAmount(str) {
        if (!str) return 0;
        return parseFloat(str.replace(/"/g, '').replace(/,/g, '').trim()) || 0;
    }

    // ===== MASTERS =====
    function loadMasters() {
        // Load reviewer/approver management
        CETApi.getReviewers().then(function (res) {
            if (res.success) {
                renderReviewerApproverTable(res.data, 'Reviewer', 'reviewers-table-container');
            }
        });
        CETApi.getApprovers().then(function (res) {
            if (res.success) {
                renderReviewerApproverTable(res.data, 'Approver', 'approvers-table-container');
            }
        });
    }

    function renderReviewerApproverTable(items, type, containerId) {
        var html = '<table class="cet-table"><thead><tr><th>Name</th><th>Email</th><th>Department</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + escapeHtml(item.displayName) + '</td><td>' + escapeHtml(item.email) + '</td>' +
                '<td>' + escapeHtml(item.departmentName) + '</td>' +
                '<td><button class="btn btn-sm btn-danger" onclick="CETApp.removeReviewerApprover(' + item.id + ')">Remove</button></td></tr>';
        }
        html += '</tbody></table>';
        document.getElementById(containerId).innerHTML = html;
    }

    // ===== OPEX MANAGEMENT =====
    function showOpexForm(data) {
        var modal = document.getElementById('opexModal');
        if (data) {
            document.getElementById('opex-id').value = data.opexId || 0;
            document.getElementById('opex-budgetId').value = data.budgetId || '';
            document.getElementById('opex-description').value = data.description || '';
            document.getElementById('opex-budget').value = data.budget || 0;
            document.getElementById('opex-utilization').value = data.utilization || 0;
            document.getElementById('opex-locked').value = data.lockedAmt || 0;
        } else {
            document.getElementById('opexForm').reset();
            document.getElementById('opex-id').value = 0;
        }
        modal.style.display = 'flex';
    }

    function saveOpex() {
        var budget = parseFloat(document.getElementById('opex-budget').value) || 0;
        var utilization = parseFloat(document.getElementById('opex-utilization').value) || 0;
        var locked = parseFloat(document.getElementById('opex-locked').value) || 0;
        var available = budget - utilization;
        var afterLocked = available - locked;

        var model = {
            opexId: parseInt(document.getElementById('opex-id').value) || 0,
            budgetId: document.getElementById('opex-budgetId').value,
            description: document.getElementById('opex-description').value,
            budget: budget,
            utilization: utilization,
            availableBudget: available,
            lockedAmt: locked,
            budgetAfterLocked: afterLocked,
            claimAmt: 0,
            netBalance: afterLocked,
            createdBy: currentUser ? currentUser.userId : 1
        };

        CETApi.saveOpex(model).then(function (res) {
            if (res.success) {
                closeModal('opexModal');
                loadOpexList();
                showToast('OPEX saved successfully', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    function editOpex(id) {
        CETApi.getOpexAll().then(function (res) {
            if (res.success) {
                var item = null;
                for (var i = 0; i < res.data.length; i++) {
                    if (res.data[i].opexId === id) { item = res.data[i]; break; }
                }
                if (item) showOpexForm(item);
            }
        });
    }

    // ===== SPEND REQUEST DETAIL VIEW =====
    function openSpendRequest(id) {
        CETApi.getSpendRequests({ projectId: null, status: null, userId: null, roleType: null }).then(function (res) {
            if (res.success) {
                var item = null;
                for (var i = 0; i < res.data.length; i++) {
                    if (res.data[i].spendRequestId === id) { item = res.data[i]; break; }
                }
                if (item) {
                    renderSpendRequestDetail(item);
                }
            }
        });
    }

    function renderSpendRequestDetail(item) {
        var container = document.getElementById('view-spend-detail');
        if (!container) return;

        // Workflow stepper status
        var steps = ['Draft', 'Submitted', 'Reviewed', 'Approved'];
        var currentStep = steps.indexOf(item.status);
        if (item.status === 'Returned' || item.status === 'Rejected') currentStep = -1;

        var stepperHtml = '<ul class="workflow-stepper">';
        for (var s = 0; s < steps.length; s++) {
            var cls = s < currentStep ? 'completed' : (s === currentStep ? 'active' : '');
            stepperHtml += '<li class="step ' + cls + '"><div class="step-icon">' + (s + 1) + '</div><div class="step-label">' + steps[s] + '</div></li>';
        }
        stepperHtml += '</ul>';

        var html = '<h2 class="page-title">Spend Request: ' + escapeHtml(item.autoId || 'N/A') + '</h2>';
        html += stepperHtml;

        // Spend Request Details Panel
        html += '<div class="section-panel panel-spend"><div class="panel-header"><span>Spend Request Details</span>';
        if (item.status === 'Draft') {
            html += '<button class="btn btn-sm btn-success" onclick="CETApp.submitSpendRequest(' + item.spendRequestId + ')">Submit for Review</button>';
        }
        html += '</div><div class="panel-body">';
        html += '<div class="form-row">';
        html += '<div class="form-group"><label>Project</label><div class="detail-value">' + escapeHtml(item.projectName) + '</div></div>';
        html += '<div class="form-group"><label>Department</label><div class="detail-value">' + escapeHtml(item.departmentName || '-') + '</div></div>';
        html += '<div class="form-group"><label>Expense Head</label><div class="detail-value"><span class="badge badge-' + (item.expenseHead || '').toLowerCase() + '">' + (item.expenseHead || '-') + '</span></div></div>';
        html += '</div><div class="form-row">';
        html += '<div class="form-group"><label>Topic</label><div class="detail-value">' + escapeHtml(item.topic) + '</div></div>';
        html += '<div class="form-group"><label>Vendor</label><div class="detail-value">' + escapeHtml(item.vendor) + '</div></div>';
        html += '<div class="form-group"><label>Status</label><div class="detail-value"><span class="badge" style="background:' + (CETConfig.statusColors[item.status] || '#6c757d') + '">' + item.status + '</span></div></div>';
        html += '</div><div class="form-row">';
        html += '<div class="form-group"><label>Cost Type</label><div class="detail-value">' + escapeHtml(item.costType) + '</div></div>';
        html += '<div class="form-group"><label>Unit Type</label><div class="detail-value">' + (item.unitType || '-') + '</div></div>';
        html += '<div class="form-group"><label>Units</label><div class="detail-value">' + item.units + '</div></div>';
        html += '</div><div class="form-row">';
        html += '<div class="form-group"><label>Unit Price</label><div class="detail-value">' + formatCurrency(item.unitPrice) + '</div></div>';
        html += '<div class="form-group"><label>Amount (FCY)</label><div class="detail-value">' + formatCurrency(item.amountFCY) + '</div></div>';
        html += '<div class="form-group"><label>Final Amount (LCY)</label><div class="detail-value" style="font-weight:700;font-size:16px;">' + formatCurrency(item.finalAmountLCY) + '</div></div>';
        html += '</div>';
        html += '<div class="form-row"><div class="form-group"><label>Description</label><div class="detail-value">' + escapeHtml(item.description) + '</div></div></div>';
        html += '</div></div>';

        // Budget Line Items Panel
        html += '<div class="section-panel panel-budget"><div class="panel-header"><span>Budget Line Items</span>';
        html += '<button class="btn btn-sm btn-success" onclick="CETApp.showLineItemForm(' + item.spendRequestId + ')">+ Add Line Item</button>';
        html += '</div><div class="panel-body" id="detail-lineitems-container"><p class="text-muted">Loading...</p></div></div>';

        // Invoice Panel
        html += '<div class="section-panel panel-invoice"><div class="panel-header"><span>Invoices</span>';
        html += '<button class="btn btn-sm btn-success" onclick="CETApp.showInvoiceForm(' + item.spendRequestId + ')">+ Add Invoice</button>';
        html += '</div><div class="panel-body" id="detail-invoices-container"><p class="text-muted">Loading...</p></div></div>';

        // Approval History Panel
        html += '<div class="section-panel panel-approval"><div class="panel-header">Approval History</div><div class="panel-body" id="detail-approval-history">';
        var historyHtml = '<table class="cet-table"><thead><tr><th>Date</th><th>Action</th><th>By</th><th>Status</th></tr></thead><tbody>';
        if (item.submittedDate) {
            historyHtml += '<tr><td>' + formatDate(item.submittedDate) + '</td><td>Submitted</td><td>' + escapeHtml(item.createdByName) + '</td><td>Submitted</td></tr>';
        }
        if (item.reviewedDate) {
            historyHtml += '<tr><td>' + formatDate(item.reviewedDate) + '</td><td>Reviewed</td><td>Reviewer</td><td>Reviewed</td></tr>';
        }
        if (item.approvedDate) {
            historyHtml += '<tr><td>' + formatDate(item.approvedDate) + '</td><td>Approved</td><td>Approver</td><td>Approved</td></tr>';
        }
        historyHtml += '</tbody></table>';
        html += historyHtml + '</div></div>';

        // Back button
        html += '<button class="btn btn-outline mt-16" onclick="CETApp.showView(\'spend-requests\')">&#8592; Back to Spend Requests</button>';

        container.innerHTML = html;

        // Show detail view
        var views = document.querySelectorAll('.cet-view');
        for (var i = 0; i < views.length; i++) { views[i].style.display = 'none'; }
        container.style.display = 'block';

        // Load sub-data
        loadDetailLineItems(item.spendRequestId);
        loadDetailInvoices(item.spendRequestId);
    }

    function loadDetailLineItems(spendRequestId) {
        CETApi.getBudgetLineItems(spendRequestId).then(function (res) {
            if (res.success && res.data.length > 0) {
                var html = '<table class="cet-table"><thead><tr><th>#</th><th>Description</th><th>Cost Type</th><th>Unit Type</th><th>Units</th><th>Unit Price</th><th>Amount</th><th>Actions</th></tr></thead><tbody>';
                for (var i = 0; i < res.data.length; i++) {
                    var item = res.data[i];
                    html += '<tr><td>' + item.lineNo + '</td><td>' + escapeHtml(item.description) + '</td><td>' + escapeHtml(item.costType) + '</td><td>' + item.unitType + '</td><td>' + item.units + '</td><td>' + formatCurrency(item.unitPrice) + '</td><td class="amt">' + formatCurrency(item.finalAmountLCY) + '</td>';
                    html += '<td><button class="btn btn-sm btn-edit" onclick="CETApp.editLineItem(' + item.lineItemId + ',' + spendRequestId + ')">Edit</button> <button class="btn btn-sm btn-danger" onclick="CETApp.deleteLineItem(' + item.lineItemId + ',' + spendRequestId + ')">Delete</button></td></tr>';
                }
                html += '</tbody></table>';
                document.getElementById('detail-lineitems-container').innerHTML = html;
            } else {
                document.getElementById('detail-lineitems-container').innerHTML = '<div class="empty-state"><div class="empty-icon">&#128196;</div><p>No budget line items yet. Click "+ Add Line Item" to create one.</p></div>';
            }
        });
    }

    function loadDetailInvoices(spendRequestId) {
        CETApi.getInvoices(spendRequestId).then(function (res) {
            if (res.success && res.data.length > 0) {
                var html = '<table class="cet-table"><thead><tr><th>Invoice #</th><th>Date</th><th>Vendor</th><th>Description</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
                for (var i = 0; i < res.data.length; i++) {
                    var item = res.data[i];
                    html += '<tr><td>' + escapeHtml(item.invoiceNumber) + '</td><td>' + formatDate(item.invoiceDate) + '</td><td>' + escapeHtml(item.vendorName) + '</td><td>' + escapeHtml(item.description) + '</td><td class="amt">' + formatCurrency(item.amountLCY) + '</td><td><span class="badge">' + item.status + '</span></td>';
                    html += '<td><button class="btn btn-sm btn-edit" onclick="CETApp.editInvoice(' + item.invoiceId + ',' + spendRequestId + ')">Edit</button> <button class="btn btn-sm btn-danger" onclick="CETApp.deleteInvoice(' + item.invoiceId + ',' + spendRequestId + ')">Delete</button></td></tr>';
                }
                html += '</tbody></table>';
                document.getElementById('detail-invoices-container').innerHTML = html;
            } else {
                document.getElementById('detail-invoices-container').innerHTML = '<div class="empty-state"><div class="empty-icon">&#128203;</div><p>No invoices uploaded yet. Click "+ Add Invoice" to upload one.</p></div>';
            }
        });
    }

    // ===== EDIT SPEND REQUEST =====
    function editSpendRequest(id) {
        CETApi.getSpendRequests({ projectId: null, status: null, userId: null, roleType: null }).then(function (res) {
            if (res.success) {
                var item = null;
                for (var i = 0; i < res.data.length; i++) {
                    if (res.data[i].spendRequestId === id) { item = res.data[i]; break; }
                }
                if (item) {
                    showSpendRequestForm(item.projectId);
                    // Populate the form with existing data
                    setTimeout(function () {
                        document.getElementById('sr-id').value = item.spendRequestId;
                        document.getElementById('sr-project-id').value = item.projectId;
                        document.getElementById('sr-department').value = item.departmentId;
                        document.getElementById('sr-expense-head').value = item.expenseHead;
                        document.getElementById('sr-topic').value = item.topic;
                        document.getElementById('sr-vendor').value = item.vendor;
                        document.getElementById('sr-description').value = item.description;
                        document.getElementById('sr-cost-type').value = item.costType;
                        document.getElementById('sr-unit-type').value = item.unitType;
                        document.getElementById('sr-units').value = item.units;
                        document.getElementById('sr-unit-price').value = item.unitPrice;
                        document.getElementById('sr-currency').value = item.baseCurrency;
                        document.getElementById('sr-contingency').value = item.contingencyPercent;
                        document.getElementById('sr-recurrence').value = item.yearlyRecurrence;
                    }, 100);
                }
            }
        });
    }

    // ===== BUDGET LINE ITEM FORM =====
    function showLineItemForm(spendRequestId, data) {
        var modal = document.getElementById('lineItemModal');
        document.getElementById('lineItemForm').reset();
        document.getElementById('li-id').value = 0;
        document.getElementById('li-spend-request-id').value = spendRequestId;
        populateDropdown('li-cost-type', CETConfig.costTypes);
        populateDropdown('li-unit-type', CETConfig.unitTypes);
        populateDropdown('li-currency', CETConfig.currencies, 'code', 'code');

        if (data) {
            document.getElementById('li-id').value = data.lineItemId;
            document.getElementById('li-description').value = data.description;
            document.getElementById('li-cost-type').value = data.costType;
            document.getElementById('li-unit-type').value = data.unitType;
            document.getElementById('li-units').value = data.units;
            document.getElementById('li-unit-price').value = data.unitPrice;
            document.getElementById('li-currency').value = data.baseCurrency;
            document.getElementById('li-contingency').value = data.contingencyPercent;
        }
        modal.style.display = 'flex';
    }

    function saveLineItem() {
        var model = {
            lineItemId: parseInt(document.getElementById('li-id').value) || 0,
            spendRequestId: parseInt(document.getElementById('li-spend-request-id').value),
            description: document.getElementById('li-description').value,
            costType: document.getElementById('li-cost-type').value,
            unitType: document.getElementById('li-unit-type').value,
            units: parseFloat(document.getElementById('li-units').value) || 0,
            unitPrice: parseFloat(document.getElementById('li-unit-price').value) || 0,
            baseCurrency: document.getElementById('li-currency').value || 'AED',
            contingencyPercent: parseFloat(document.getElementById('li-contingency').value) || 0
        };

        CETApi.saveBudgetLineItem(model).then(function (res) {
            if (res.success) {
                closeModal('lineItemModal');
                loadDetailLineItems(model.spendRequestId);
                showToast('Line item saved', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    function editLineItem(id, spendRequestId) {
        CETApi.getBudgetLineItems(spendRequestId).then(function (res) {
            if (res.success) {
                var item = null;
                for (var i = 0; i < res.data.length; i++) {
                    if (res.data[i].lineItemId === id) { item = res.data[i]; break; }
                }
                if (item) {
                    showLineItemForm(spendRequestId, item);
                }
            }
        });
    }

    function deleteLineItem(id, spendRequestId) {
        if (!confirm('Are you sure you want to delete this line item?')) return;
        CETApi.deleteLineItem(id, currentUser ? currentUser.userId : 1).then(function (res) {
            loadDetailLineItems(spendRequestId);
            showToast('Line item deleted', 'success');
        }).catch(function () {
            showToast('Delete failed', 'error');
        });
    }

    // ===== INVOICE FORM =====
    function showInvoiceForm(spendRequestId, data) {
        var modal = document.getElementById('invoiceModal');
        document.getElementById('invoiceForm').reset();
        document.getElementById('inv-id').value = 0;
        document.getElementById('inv-spend-request-id').value = spendRequestId;
        populateDropdown('inv-currency', CETConfig.currencies, 'code', 'code');

        if (data) {
            document.getElementById('inv-id').value = data.invoiceId;
            document.getElementById('inv-number').value = data.invoiceNumber;
            document.getElementById('inv-date').value = data.invoiceDate ? data.invoiceDate.substring(0, 10) : '';
            document.getElementById('inv-vendor').value = data.vendorName;
            document.getElementById('inv-description').value = data.description;
            document.getElementById('inv-amount').value = data.amount;
            document.getElementById('inv-currency').value = data.currency;
            document.getElementById('inv-amount-lcy').value = data.amountLCY;
        }
        modal.style.display = 'flex';
    }

    function saveInvoice() {
        var model = {
            invoiceId: parseInt(document.getElementById('inv-id').value) || 0,
            spendRequestId: parseInt(document.getElementById('inv-spend-request-id').value),
            invoiceNumber: document.getElementById('inv-number').value,
            invoiceDate: document.getElementById('inv-date').value,
            vendorName: document.getElementById('inv-vendor').value,
            description: document.getElementById('inv-description').value,
            amount: parseFloat(document.getElementById('inv-amount').value) || 0,
            currency: document.getElementById('inv-currency').value || 'AED',
            amountLCY: parseFloat(document.getElementById('inv-amount-lcy').value) || parseFloat(document.getElementById('inv-amount').value) || 0
        };

        CETApi.saveInvoice(model).then(function (res) {
            if (res.success) {
                closeModal('invoiceModal');
                loadDetailInvoices(model.spendRequestId);
                showToast('Invoice saved', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    function editInvoice(id, spendRequestId) {
        CETApi.getInvoices(spendRequestId).then(function (res) {
            if (res.success) {
                var item = null;
                for (var i = 0; i < res.data.length; i++) {
                    if (res.data[i].invoiceId === id) { item = res.data[i]; break; }
                }
                if (item) {
                    showInvoiceForm(spendRequestId, item);
                }
            }
        });
    }

    function deleteInvoice(id, spendRequestId) {
        if (!confirm('Are you sure you want to delete this invoice?')) return;
        CETApi.deleteInvoice(id, currentUser ? currentUser.userId : 1).then(function (res) {
            loadDetailInvoices(spendRequestId);
            showToast('Invoice deleted', 'success');
        }).catch(function () {
            showToast('Delete failed', 'error');
        });
    }

    // ===== VIEW PROJECT DETAIL =====
    function viewProject(id) {
        CETApi.getProjects(null).then(function (res) {
            if (res.success) {
                var project = null;
                for (var i = 0; i < res.data.length; i++) {
                    if (res.data[i].projectId === id) { project = res.data[i]; break; }
                }
                if (project) {
                    renderProjectDetail(project);
                }
            }
        });
    }

    function renderProjectDetail(project) {
        var container = document.getElementById('view-project-detail');
        if (!container) return;

        var html = '<h2 class="page-title">Project: ' + escapeHtml(project.projectName) + '</h2>';

        // Project Info
        html += '<div class="section-panel panel-spend"><div class="panel-header"><span>Project Information</span>';
        html += '<button class="btn btn-sm btn-success" onclick="CETApp.showSpendRequestForm(' + project.projectId + ')">+ New Spend Request</button>';
        html += '</div><div class="panel-body">';
        html += '<div class="form-row">';
        html += '<div class="form-group"><label>Project Type</label><div class="detail-value"><span class="badge badge-info">' + project.projectType + '</span></div></div>';
        html += '<div class="form-group"><label>JIRA Key</label><div class="detail-value">' + (project.jiraProjectKey || 'N/A') + '</div></div>';
        html += '<div class="form-group"><label>Budget Source</label><div class="detail-value"><span class="badge badge-' + project.budgetSource.toLowerCase() + '">' + project.budgetSource + '</span></div></div>';
        html += '</div><div class="form-row">';
        html += '<div class="form-group"><label>Requestor</label><div class="detail-value">' + escapeHtml(project.requestorName || '-') + '</div></div>';
        html += '<div class="form-group"><label>Reviewer</label><div class="detail-value">' + escapeHtml(project.reviewerName || 'Not Assigned') + '</div></div>';
        html += '<div class="form-group"><label>Approver</label><div class="detail-value">' + escapeHtml(project.approverName || 'Not Assigned') + '</div></div>';
        html += '</div></div></div>';

        // Spend Requests for this project
        html += '<div class="section-panel panel-budget"><div class="panel-header">Spend Requests for this Project</div><div class="panel-body" id="project-spend-requests-container"><p class="text-muted">Loading...</p></div></div>';

        html += '<button class="btn btn-outline mt-16" onclick="CETApp.showView(\'projects\')">&#8592; Back to Projects</button>';

        container.innerHTML = html;

        // Show detail view
        var views = document.querySelectorAll('.cet-view');
        for (var i = 0; i < views.length; i++) { views[i].style.display = 'none'; }
        container.style.display = 'block';

        // Load spend requests for this project
        CETApi.getSpendRequests({ projectId: project.projectId }).then(function (res) {
            if (res.success && res.data.length > 0) {
                var srHtml = '<table class="cet-table"><thead><tr><th>ID</th><th>Topic</th><th>Vendor</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
                for (var j = 0; j < res.data.length; j++) {
                    var sr = res.data[j];
                    srHtml += '<tr><td>' + escapeHtml(sr.autoId) + '</td><td>' + escapeHtml(sr.topic) + '</td><td>' + escapeHtml(sr.vendor) + '</td><td class="amt">' + formatCurrency(sr.finalAmountLCY) + '</td>';
                    srHtml += '<td><span class="badge" style="background:' + (CETConfig.statusColors[sr.status] || '#6c757d') + '">' + sr.status + '</span></td>';
                    srHtml += '<td><button class="btn btn-sm btn-primary" onclick="CETApp.openSpendRequest(' + sr.spendRequestId + ')">View</button></td></tr>';
                }
                srHtml += '</tbody></table>';
                document.getElementById('project-spend-requests-container').innerHTML = srHtml;
            } else {
                document.getElementById('project-spend-requests-container').innerHTML = '<div class="empty-state"><p>No spend requests yet for this project.</p></div>';
            }
        });
    }

    // ===== REVIEWER/APPROVER MANAGEMENT =====
    function showReviewerApproverForm(roleType) {
        var modal = document.getElementById('reviewerApproverModal');
        document.getElementById('raForm').reset();
        document.getElementById('ra-role-type').value = roleType;
        document.getElementById('ra-modal-title').textContent = 'Add ' + roleType;
        populateDropdown('ra-department', CETConfig.departments, 'id', 'name');
        modal.style.display = 'flex';
    }

    function saveReviewerApprover() {
        var model = {
            userId: parseInt(document.getElementById('ra-user').value),
            roleType: document.getElementById('ra-role-type').value,
            departmentId: parseInt(document.getElementById('ra-department').value)
        };

        CETApi.saveReviewerApprover(model).then(function (res) {
            if (res.success) {
                closeModal('reviewerApproverModal');
                loadMasters();
                showToast(model.roleType + ' added successfully', 'success');
            } else {
                showToast(res.message, 'error');
            }
        });
    }

    function removeReviewerApprover(id) {
        if (!confirm('Remove this assignment?')) return;
        CETApi.removeReviewerApprover(id).then(function (res) {
            loadMasters();
            showToast('Removed successfully', 'success');
        }).catch(function () {
            showToast('Remove failed', 'error');
        });
    }

    // ===== REVIEWER QUEUE ACTIONS =====
    function renderReviewerQueueTable(items) {
        if (!items || items.length === 0) {
            document.getElementById('reviewer-table-container').innerHTML = '<div class="empty-state"><div class="empty-icon">&#9989;</div><p>No items pending review</p></div>';
            return;
        }
        var html = '<table class="cet-table"><thead><tr>' +
            '<th>ID</th><th>Project</th><th>Topic</th><th>Vendor</th><th>Amount (AED)</th><th>Submitted</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + escapeHtml(item.autoId) + '</td><td>' + escapeHtml(item.projectName) + '</td>' +
                '<td>' + escapeHtml(item.topic) + '</td><td>' + escapeHtml(item.vendor) + '</td>' +
                '<td class="amt">' + formatCurrency(item.finalAmountLCY) + '</td>' +
                '<td>' + formatDate(item.submittedDate) + '</td>' +
                '<td><button class="btn btn-sm btn-primary" onclick="CETApp.openSpendRequest(' + item.spendRequestId + ')">View</button> ' +
                '<button class="btn btn-sm btn-success" onclick="CETApp.reviewAction(' + item.spendRequestId + ',\'Reviewed\')">Approve</button> ' +
                '<button class="btn btn-sm btn-warning" onclick="CETApp.reviewAction(' + item.spendRequestId + ',\'Returned\')">Return</button></td></tr>';
        }
        html += '</tbody></table>';
        document.getElementById('reviewer-table-container').innerHTML = html;
    }

    // ===== APPROVER QUEUE ACTIONS =====
    function renderApproverQueueTable(items) {
        if (!items || items.length === 0) {
            document.getElementById('approver-table-container').innerHTML = '<div class="empty-state"><div class="empty-icon">&#9989;</div><p>No items pending approval</p></div>';
            return;
        }
        var html = '<table class="cet-table"><thead><tr>' +
            '<th>ID</th><th>Project</th><th>Topic</th><th>Vendor</th><th>Amount (AED)</th><th>Reviewed</th><th>Actions</th></tr></thead><tbody>';
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            html += '<tr><td>' + escapeHtml(item.autoId) + '</td><td>' + escapeHtml(item.projectName) + '</td>' +
                '<td>' + escapeHtml(item.topic) + '</td><td>' + escapeHtml(item.vendor) + '</td>' +
                '<td class="amt">' + formatCurrency(item.finalAmountLCY) + '</td>' +
                '<td>' + formatDate(item.reviewedDate) + '</td>' +
                '<td><button class="btn btn-sm btn-primary" onclick="CETApp.openSpendRequest(' + item.spendRequestId + ')">View</button> ' +
                '<button class="btn btn-sm btn-success" onclick="CETApp.approveAction(' + item.spendRequestId + ',\'Approved\')">Approve</button> ' +
                '<button class="btn btn-sm btn-danger" onclick="CETApp.approveAction(' + item.spendRequestId + ',\'Rejected\')">Reject</button></td></tr>';
        }
        html += '</tbody></table>';
        document.getElementById('approver-table-container').innerHTML = html;
    }

    // ===== CALCULATE AMOUNTS LIVE =====
    function calculateSpendRequestAmount() {
        var units = parseFloat(document.getElementById('sr-units').value) || 0;
        var price = parseFloat(document.getElementById('sr-unit-price').value) || 0;
        var contingency = parseFloat(document.getElementById('sr-contingency').value) || 0;
        var amount = units * price;
        var finalAmt = amount + (amount * contingency / 100);
        var display = document.getElementById('sr-calculated-amount');
        if (display) {
            display.textContent = 'Calculated: ' + formatCurrency(amount) + ' | Final (with contingency): ' + formatCurrency(finalAmt);
        }
    }

    function calculateLineItemAmount() {
        var units = parseFloat(document.getElementById('li-units').value) || 0;
        var price = parseFloat(document.getElementById('li-unit-price').value) || 0;
        var contingency = parseFloat(document.getElementById('li-contingency').value) || 0;
        var amount = units * price;
        var finalAmt = amount + (amount * contingency / 100);
        var display = document.getElementById('li-calculated-amount');
        if (display) {
            display.textContent = 'Calculated: ' + formatCurrency(amount) + ' | Final: ' + formatCurrency(finalAmt);
        }
    }

    // ===== UTILITY FUNCTIONS =====
    function formatCurrency(amount) {
        if (amount === null || amount === undefined) return 'AED 0.00';
        return 'AED ' + Number(amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function formatDate(dateStr) {
        if (!dateStr) return '-';
        var d = new Date(dateStr);
        return d.getDate().toString().padStart(2, '0') + '/' + (d.getMonth() + 1).toString().padStart(2, '0') + '/' + d.getFullYear();
    }

    function escapeHtml(text) {
        if (!text) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(text));
        return div.innerHTML;
    }

    function populateDropdown(elementId, items, valueField, textField) {
        var select = document.getElementById(elementId);
        if (!select) return;
        select.innerHTML = '<option value="">-- Select --</option>';
        for (var i = 0; i < items.length; i++) {
            var opt = document.createElement('option');
            if (typeof items[i] === 'string') {
                opt.value = items[i];
                opt.textContent = items[i];
            } else {
                opt.value = items[i][valueField];
                opt.textContent = items[i][textField];
            }
            select.appendChild(opt);
        }
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    function showToast(message, type) {
        var toast = document.getElementById('toast');
        toast.textContent = message;
        toast.className = 'toast toast-' + (type || 'info') + ' show';
        setTimeout(function () { toast.className = 'toast'; }, 3000);
    }

    // ===== PUBLIC API =====
    return {
        init: init,
        showView: showView,
        // CAPEX
        showCapexForm: showCapexForm,
        saveCapex: saveCapex,
        editCapex: editCapex,
        // OPEX
        showOpexForm: showOpexForm,
        saveOpex: saveOpex,
        editOpex: editOpex,
        // Projects
        showProjectForm: showProjectForm,
        onProjectTypeChange: onProjectTypeChange,
        loadBudgetDropdowns: loadBudgetDropdowns,
        saveProject: saveProject,
        viewProject: viewProject,
        // Spend Requests
        showSpendRequestForm: showSpendRequestForm,
        saveSpendRequest: saveSpendRequest,
        submitSpendRequest: submitSpendRequest,
        editSpendRequest: editSpendRequest,
        openSpendRequest: openSpendRequest,
        calculateSpendRequestAmount: calculateSpendRequestAmount,
        // Review & Approve
        reviewAction: reviewAction,
        approveAction: approveAction,
        // Budget Line Items
        showLineItemForm: showLineItemForm,
        saveLineItem: saveLineItem,
        editLineItem: editLineItem,
        deleteLineItem: deleteLineItem,
        calculateLineItemAmount: calculateLineItemAmount,
        loadBudgetLineItems: loadBudgetLineItems,
        // Invoices
        showInvoiceForm: showInvoiceForm,
        saveInvoice: saveInvoice,
        editInvoice: editInvoice,
        deleteInvoice: deleteInvoice,
        loadInvoices: loadInvoices,
        // Masters
        showReviewerApproverForm: showReviewerApproverForm,
        saveReviewerApprover: saveReviewerApprover,
        removeReviewerApprover: removeReviewerApprover,
        // Utility
        importCsv: importCsv,
        closeModal: closeModal
    };
})();

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', function () {
    CETApp.init();
});
