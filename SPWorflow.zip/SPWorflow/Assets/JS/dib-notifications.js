/* ============================================================
   DIB Notifications Module
   Handles toast notifications, bell dropdown, and polling
   ============================================================ */
var DIB = window.DIB || {};

DIB.Notifications = (function () {
    'use strict';

    var _notifications = [];
    var _pollInterval = null;
    var _siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : '';
    var NOTIF_LIST_NAME = 'DIBNotifications';

    // --- Initialize ---
    function init() {
        _loadNotifications();
        _startPolling();
        _highlightActiveNav();
        // Close dropdown on outside click
        document.addEventListener('click', function (e) {
            var bell = document.getElementById('dibNotificationBell');
            var dropdown = document.getElementById('dibNotifDropdown');
            if (bell && dropdown && !bell.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.remove('show');
            }
        });
    }

    // --- Highlight active nav link ---
    function _highlightActiveNav() {
        var path = window.location.pathname.toLowerCase();
        var links = document.querySelectorAll('#dib-nav a');
        for (var i = 0; i < links.length; i++) {
            var href = links[i].getAttribute('href');
            if (href && path.indexOf(href.toLowerCase()) !== -1) {
                links[i].classList.add('active');
            }
        }
    }

    // --- Toggle notification dropdown ---
    function toggle() {
        var dropdown = document.getElementById('dibNotifDropdown');
        if (dropdown) {
            dropdown.classList.toggle('show');
        }
    }

    // --- Load notifications from SP list ---
    function _loadNotifications() {
        if (!_siteUrl) {
            _renderDemoNotifications();
            return;
        }

        var currentUser = _spPageContextInfo.userId;
        var url = _siteUrl + "/_api/web/lists/getbytitle('" + NOTIF_LIST_NAME + "')/items" +
            "?$filter=AssignedToId eq " + currentUser + " or AssignedToId eq null" +
            "&$orderby=Created desc&$top=20" +
            "&$select=Id,Title,Body,NotificationType,IsRead,Created";

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    _notifications = data.d.results || [];
                    _renderNotifications();
                } else {
                    _renderDemoNotifications();
                }
            }
        };
        xhr.send();
    }

    // --- Render demo notifications (when list doesn't exist) ---
    function _renderDemoNotifications() {
        _notifications = [
            { Id: 1, Title: 'New task assigned', Body: 'Budget Approval workflow needs your review', NotificationType: 'assignment', IsRead: false, Created: new Date().toISOString() },
            { Id: 2, Title: 'Task overdue', Body: 'Invoice Processing #1042 is past due', NotificationType: 'overdue', IsRead: false, Created: new Date(Date.now() - 3600000).toISOString() },
            { Id: 3, Title: 'Workflow completed', Body: 'Leave Request #892 has been approved', NotificationType: 'completion', IsRead: true, Created: new Date(Date.now() - 7200000).toISOString() }
        ];
        _renderNotifications();
    }

    // --- Render notifications to dropdown ---
    function _renderNotifications() {
        var list = document.getElementById('dibNotifList');
        var badge = document.getElementById('dibNotifCount');
        if (!list) return;

        var unreadCount = 0;
        var html = '';

        for (var i = 0; i < _notifications.length; i++) {
            var n = _notifications[i];
            var isRead = n.IsRead === true || n.IsRead === 'true';
            if (!isRead) unreadCount++;

            var icon = '&#128276;';
            if (n.NotificationType === 'assignment') icon = '&#128100;';
            else if (n.NotificationType === 'overdue') icon = '&#9888;';
            else if (n.NotificationType === 'completion') icon = '&#9989;';

            var timeAgo = _getTimeAgo(n.Created);

            html += '<div class="notif-item ' + (isRead ? '' : 'unread') + '" onclick="DIB.Notifications.markRead(' + n.Id + ');">' +
                '<div class="notif-title">' + icon + ' ' + _escapeHtml(n.Title) + '</div>' +
                '<div class="notif-desc">' + _escapeHtml(n.Body || '') + '</div>' +
                '<div class="notif-time">' + timeAgo + '</div>' +
                '</div>';
        }

        if (_notifications.length === 0) {
            html = '<div style="padding:20px;text-align:center;color:#999;">No notifications</div>';
        }

        list.innerHTML = html;
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? 'flex' : 'none';
        }
    }

    // --- Mark single notification as read ---
    function markRead(id) {
        for (var i = 0; i < _notifications.length; i++) {
            if (_notifications[i].Id === id) {
                _notifications[i].IsRead = true;
                break;
            }
        }
        _renderNotifications();

        // Update in SP list
        if (_siteUrl) {
            _updateNotifInSP(id, true);
        }
    }

    // --- Mark all as read ---
    function markAllRead() {
        for (var i = 0; i < _notifications.length; i++) {
            _notifications[i].IsRead = true;
        }
        _renderNotifications();
    }

    // --- Show toast notification ---
    function showToast(title, message, type) {
        type = type || 'info';
        var container = document.getElementById('dibToastContainer');
        if (!container) return;

        var icons = { info: '\u2139\uFE0F', success: '\u2705', warning: '\u26A0\uFE0F', error: '\u274C' };
        var toast = document.createElement('div');
        toast.className = 'dib-toast toast-' + type;
        toast.innerHTML =
            '<span class="dib-toast-icon">' + (icons[type] || '') + '</span>' +
            '<div class="dib-toast-content">' +
            '<div class="dib-toast-title">' + _escapeHtml(title) + '</div>' +
            '<div class="dib-toast-message">' + _escapeHtml(message) + '</div>' +
            '</div>' +
            '<button class="dib-toast-close" onclick="this.parentElement.remove();">&times;</button>';

        container.appendChild(toast);

        // Auto-remove after 5 seconds
        setTimeout(function () {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 5000);
    }

    // --- Poll for new notifications ---
    function _startPolling() {
        _pollInterval = setInterval(function () {
            _loadNotifications();
        }, 30000); // Poll every 30 seconds
    }

    // --- Update notification in SP ---
    function _updateNotifInSP(id, isRead) {
        var url = _siteUrl + "/_api/web/lists/getbytitle('" + NOTIF_LIST_NAME + "')/items(" + id + ")";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('Content-Type', 'application/json;odata=verbose');
        xhr.setRequestHeader('IF-MATCH', '*');
        xhr.setRequestHeader('X-HTTP-Method', 'MERGE');
        xhr.setRequestHeader('X-RequestDigest', document.getElementById('__REQUESTDIGEST') ? document.getElementById('__REQUESTDIGEST').value : '');
        xhr.send(JSON.stringify({
            '__metadata': { 'type': 'SP.Data.' + NOTIF_LIST_NAME + 'ListItem' },
            'IsRead': isRead
        }));
    }

    // --- Create notification in SP ---
    function createNotification(title, body, type, assignedToId) {
        if (!_siteUrl) {
            showToast(title, body, type === 'overdue' ? 'warning' : 'info');
            return;
        }

        var url = _siteUrl + "/_api/web/lists/getbytitle('" + NOTIF_LIST_NAME + "')/items";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('Content-Type', 'application/json;odata=verbose');
        xhr.setRequestHeader('X-RequestDigest', document.getElementById('__REQUESTDIGEST') ? document.getElementById('__REQUESTDIGEST').value : '');
        
        var payload = {
            '__metadata': { 'type': 'SP.Data.' + NOTIF_LIST_NAME + 'ListItem' },
            'Title': title,
            'Body': body,
            'NotificationType': type,
            'IsRead': false
        };
        if (assignedToId) {
            payload.AssignedToId = assignedToId;
        }
        xhr.send(JSON.stringify(payload));

        showToast(title, body, type === 'overdue' ? 'warning' : 'info');
    }

    // --- Helpers ---
    function _getTimeAgo(dateStr) {
        var now = new Date();
        var then = new Date(dateStr);
        var diff = Math.floor((now - then) / 1000);
        if (diff < 60) return 'Just now';
        if (diff < 3600) return Math.floor(diff / 60) + ' min ago';
        if (diff < 86400) return Math.floor(diff / 3600) + ' hours ago';
        return Math.floor(diff / 86400) + ' days ago';
    }

    function _escapeHtml(text) {
        if (!text) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(text));
        return div.innerHTML;
    }

    // Auto-initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    return {
        toggle: toggle,
        markRead: markRead,
        markAllRead: markAllRead,
        showToast: showToast,
        createNotification: createNotification,
        refresh: _loadNotifications
    };
})();
