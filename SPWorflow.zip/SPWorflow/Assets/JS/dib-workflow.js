/* ============================================================
   DIB Workflow Designer Module
   Drag-and-drop workflow configuration with task assignment
   ============================================================ */
var DIB = window.DIB || {};

DIB.Workflow = (function () {
    'use strict';

    var _steps = [];
    var _connections = [];
    var _selectedStep = null;
    var _stepIdCounter = 0;
    var _dragOffset = { x: 0, y: 0 };
    var _isDraggingStep = false;
    var _siteUrl = (typeof _spPageContextInfo !== 'undefined') ? _spPageContextInfo.webAbsoluteUrl : '';
    var WF_CONFIG_LIST = 'DIBWorkflowConfigs';
    var WF_TASKS_LIST = 'DIBWorkflowTasks';

    // --- Step type definitions ---
    var STEP_TYPES = {
        task: { label: 'Task', icon: '\u2611', color: '#e3f2fd', borderColor: '#1565c0' },
        approval: { label: 'Approval', icon: '\u2714', color: '#fff3e0', borderColor: '#e65100' },
        condition: { label: 'Condition', icon: '\u2753', color: '#f3e5f5', borderColor: '#7b1fa2' },
        notification: { label: 'Notification', icon: '\u2709', color: '#e8f5e9', borderColor: '#2e7d32' },
        delay: { label: 'Delay/Timer', icon: '\u23F0', color: '#fce4ec', borderColor: '#c62828' },
        parallel: { label: 'Parallel', icon: '\u2261', color: '#e0f7fa', borderColor: '#00838f' }
    };

    // --- Initialize Designer ---
    function initDesigner() {
        var canvas = document.getElementById('wfCanvas');
        if (!canvas) return;

        // Setup drag-and-drop from toolbox
        _setupToolboxDrag();

        // Setup canvas drop
        canvas.addEventListener('dragover', function (e) {
            e.preventDefault();
            canvas.classList.add('drag-over');
        });

        canvas.addEventListener('dragleave', function () {
            canvas.classList.remove('drag-over');
        });

        canvas.addEventListener('drop', function (e) {
            e.preventDefault();
            canvas.classList.remove('drag-over');

            var type = e.dataTransfer.getData('text/plain');
            if (type && STEP_TYPES[type]) {
                var rect = canvas.getBoundingClientRect();
                var x = e.clientX - rect.left - 90;
                var y = e.clientY - rect.top - 30;
                _addStep(type, x, y);
            }
        });

        // Click canvas to deselect
        canvas.addEventListener('click', function (e) {
            if (e.target === canvas) {
                _selectStep(null);
            }
        });

        // Load saved workflow if editing
        var wfId = _getUrlParam('wfId');
        if (wfId) {
            _loadWorkflow(wfId);
        }
    }

    // --- Setup Toolbox Drag ---
    function _setupToolboxDrag() {
        var items = document.querySelectorAll('.wf-tool-item');
        for (var i = 0; i < items.length; i++) {
            items[i].addEventListener('dragstart', function (e) {
                e.dataTransfer.setData('text/plain', this.getAttribute('data-type'));
                e.dataTransfer.effectAllowed = 'copy';
            });
        }
    }

    // --- Add Step to Canvas ---
    function _addStep(type, x, y) {
        _stepIdCounter++;
        var step = {
            id: _stepIdCounter,
            type: type,
            title: STEP_TYPES[type].label + ' ' + _stepIdCounter,
            x: Math.max(0, x),
            y: Math.max(0, y),
            assignedTo: '',
            dueInDays: 3,
            description: '',
            config: {}
        };

        _steps.push(step);
        _renderStep(step);
        _selectStep(step);
        _hideCanvasEmpty();

        if (DIB.Notifications) {
            DIB.Notifications.showToast('Step Added', step.title + ' added to workflow', 'success');
        }
    }

    // --- Render a Step on Canvas ---
    function _renderStep(step) {
        var canvas = document.getElementById('wfCanvas');
        if (!canvas) return;

        var typeDef = STEP_TYPES[step.type];
        var el = document.createElement('div');
        el.className = 'wf-step';
        el.id = 'wf-step-' + step.id;
        el.style.left = step.x + 'px';
        el.style.top = step.y + 'px';
        el.style.borderColor = typeDef.borderColor;

        el.innerHTML =
            '<div class="wf-step-header">' +
            '<span style="font-size:18px;">' + typeDef.icon + '</span>' +
            '<div>' +
            '<div class="wf-step-title" id="wfStepTitle' + step.id + '">' + _escapeHtml(step.title) + '</div>' +
            '<div class="wf-step-type">' + typeDef.label + '</div>' +
            '</div>' +
            '</div>' +
            '<div class="wf-step-actions">' +
            '<button class="wf-step-action-btn" onclick="DIB.Workflow.configureStep(' + step.id + ');" title="Configure">\u2699</button>' +
            '<button class="wf-step-action-btn" onclick="DIB.Workflow.removeStep(' + step.id + ');" title="Delete">\u2716</button>' +
            '</div>' +
            '<div class="wf-connector top"></div>' +
            '<div class="wf-connector bottom"></div>' +
            '<div class="wf-connector left"></div>' +
            '<div class="wf-connector right"></div>';

        // Make step draggable within canvas
        el.addEventListener('mousedown', function (e) {
            if (e.target.classList.contains('wf-connector') || e.target.classList.contains('wf-step-action-btn')) return;
            e.preventDefault();
            _selectStep(step);
            _isDraggingStep = true;
            var rect = el.getBoundingClientRect();
            _dragOffset.x = e.clientX - rect.left;
            _dragOffset.y = e.clientY - rect.top;

            function onMouseMove(me) {
                if (!_isDraggingStep) return;
                var canvasRect = canvas.getBoundingClientRect();
                var newX = me.clientX - canvasRect.left - _dragOffset.x;
                var newY = me.clientY - canvasRect.top - _dragOffset.y;
                newX = Math.max(0, Math.min(newX, canvas.clientWidth - el.offsetWidth));
                newY = Math.max(0, Math.min(newY, canvas.clientHeight - el.offsetHeight));
                el.style.left = newX + 'px';
                el.style.top = newY + 'px';
                step.x = newX;
                step.y = newY;
                _renderConnections();
            }

            function onMouseUp() {
                _isDraggingStep = false;
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onMouseUp);
            }

            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });

        canvas.appendChild(el);
    }

    // --- Select Step ---
    function _selectStep(step) {
        // Remove previous selection
        var prevSelected = document.querySelector('.wf-step.selected');
        if (prevSelected) prevSelected.classList.remove('selected');

        _selectedStep = step;

        if (step) {
            var el = document.getElementById('wf-step-' + step.id);
            if (el) el.classList.add('selected');
            _showProperties(step);
        } else {
            _clearProperties();
        }
    }

    // --- Show Properties Panel ---
    function _showProperties(step) {
        var panel = document.getElementById('wfPropertiesBody');
        if (!panel) return;

        var typeDef = STEP_TYPES[step.type];
        panel.innerHTML =
            '<div class="wf-prop-group">' +
            '<div class="wf-prop-label">Step Name</div>' +
            '<input type="text" class="wf-prop-input" id="propTitle" value="' + _escapeAttr(step.title) + '" onchange="DIB.Workflow.updateProp(' + step.id + ', \'title\', this.value);" />' +
            '</div>' +
            '<div class="wf-prop-group">' +
            '<div class="wf-prop-label">Type</div>' +
            '<input type="text" class="wf-prop-input" value="' + typeDef.label + '" disabled />' +
            '</div>' +
            '<div class="wf-prop-group">' +
            '<div class="wf-prop-label">Assign To</div>' +
            '<input type="text" class="wf-prop-input" id="propAssign" placeholder="User or group name" value="' + _escapeAttr(step.assignedTo) + '" onchange="DIB.Workflow.updateProp(' + step.id + ', \'assignedTo\', this.value);" />' +
            '</div>' +
            '<div class="wf-prop-group">' +
            '<div class="wf-prop-label">Due In (Days)</div>' +
            '<input type="number" class="wf-prop-input" id="propDue" value="' + step.dueInDays + '" min="1" onchange="DIB.Workflow.updateProp(' + step.id + ', \'dueInDays\', parseInt(this.value));" />' +
            '</div>' +
            '<div class="wf-prop-group">' +
            '<div class="wf-prop-label">Description</div>' +
            '<textarea class="wf-prop-input" rows="3" id="propDesc" onchange="DIB.Workflow.updateProp(' + step.id + ', \'description\', this.value);">' + _escapeHtml(step.description) + '</textarea>' +
            '</div>' +
            '<div style="margin-top:10px;">' +
            '<button class="dib-btn dib-btn-danger dib-btn-sm" onclick="DIB.Workflow.removeStep(' + step.id + ');">Remove Step</button>' +
            '</div>';
    }

    // --- Clear Properties Panel ---
    function _clearProperties() {
        var panel = document.getElementById('wfPropertiesBody');
        if (panel) {
            panel.innerHTML = '<div style="padding:20px;text-align:center;color:#999;">Select a step to view properties</div>';
        }
    }

    // --- Update Step Property ---
    function updateProp(stepId, prop, value) {
        var step = _findStep(stepId);
        if (step) {
            step[prop] = value;
            if (prop === 'title') {
                var titleEl = document.getElementById('wfStepTitle' + stepId);
                if (titleEl) titleEl.textContent = value;
            }
        }
    }

    // --- Remove Step ---
    function removeStep(stepId) {
        var el = document.getElementById('wf-step-' + stepId);
        if (el) el.remove();
        _steps = _steps.filter(function (s) { return s.id !== stepId; });
        _connections = _connections.filter(function (c) { return c.from !== stepId && c.to !== stepId; });
        if (_selectedStep && _selectedStep.id === stepId) {
            _selectStep(null);
        }
        _renderConnections();
        if (_steps.length === 0) _showCanvasEmpty();
    }

    // --- Configure Step (Modal) ---
    function configureStep(stepId) {
        var step = _findStep(stepId);
        if (!step) return;
        _selectStep(step);
        // Focus properties panel
        var propTitle = document.getElementById('propTitle');
        if (propTitle) propTitle.focus();
    }

    // --- Save Workflow ---
    function saveWorkflow() {
        var nameInput = document.getElementById('wfName');
        var name = nameInput ? nameInput.value.trim() : '';
        if (!name) {
            if (DIB.Notifications) DIB.Notifications.showToast('Validation', 'Please enter a workflow name', 'warning');
            return;
        }

        if (_steps.length === 0) {
            if (DIB.Notifications) DIB.Notifications.showToast('Validation', 'Add at least one step to the workflow', 'warning');
            return;
        }

        var config = {
            name: name,
            steps: _steps,
            connections: _connections,
            createdDate: new Date().toISOString()
        };

        if (_siteUrl) {
            _saveToSP(config);
        } else {
            // Demo mode - save to localStorage
            var saved = JSON.parse(localStorage.getItem('dib_workflows') || '[]');
            config.id = saved.length + 1;
            saved.push(config);
            localStorage.setItem('dib_workflows', JSON.stringify(saved));
            if (DIB.Notifications) DIB.Notifications.showToast('Saved', 'Workflow "' + name + '" saved successfully', 'success');
        }
    }

    // --- Save to SharePoint ---
    function _saveToSP(config) {
        var url = _siteUrl + "/_api/web/lists/getbytitle('" + WF_CONFIG_LIST + "')/items";
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.setRequestHeader('Content-Type', 'application/json;odata=verbose');
        xhr.setRequestHeader('X-RequestDigest', document.getElementById('__REQUESTDIGEST') ? document.getElementById('__REQUESTDIGEST').value : '');

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 201) {
                    if (DIB.Notifications) DIB.Notifications.showToast('Saved', 'Workflow saved to SharePoint', 'success');
                } else {
                    if (DIB.Notifications) DIB.Notifications.showToast('Error', 'Failed to save workflow', 'error');
                }
            }
        };

        xhr.send(JSON.stringify({
            '__metadata': { 'type': 'SP.Data.' + WF_CONFIG_LIST + 'ListItem' },
            'Title': config.name,
            'WorkflowConfig': JSON.stringify(config)
        }));
    }

    // --- Load Workflow ---
    function _loadWorkflow(wfId) {
        if (_siteUrl) {
            var url = _siteUrl + "/_api/web/lists/getbytitle('" + WF_CONFIG_LIST + "')/items(" + parseInt(wfId, 10) + ")";
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    var config = JSON.parse(data.d.WorkflowConfig);
                    _restoreWorkflow(config);
                }
            };
            xhr.send();
        }
    }

    // --- Restore Workflow from Config ---
    function _restoreWorkflow(config) {
        var nameInput = document.getElementById('wfName');
        if (nameInput) nameInput.value = config.name || '';

        _steps = [];
        _connections = config.connections || [];

        var canvas = document.getElementById('wfCanvas');
        if (canvas) {
            var existingSteps = canvas.querySelectorAll('.wf-step');
            for (var i = 0; i < existingSteps.length; i++) {
                existingSteps[i].remove();
            }
        }

        if (config.steps) {
            for (var j = 0; j < config.steps.length; j++) {
                var s = config.steps[j];
                _stepIdCounter = Math.max(_stepIdCounter, s.id);
                _steps.push(s);
                _renderStep(s);
            }
        }

        _hideCanvasEmpty();
        _renderConnections();
    }

    // --- Render Connections (SVG lines) ---
    function _renderConnections() {
        var svg = document.getElementById('wfConnectionsSvg');
        if (!svg) return;
        svg.innerHTML = '';

        for (var i = 0; i < _connections.length; i++) {
            var conn = _connections[i];
            var fromEl = document.getElementById('wf-step-' + conn.from);
            var toEl = document.getElementById('wf-step-' + conn.to);
            if (!fromEl || !toEl) continue;

            var fromRect = fromEl.getBoundingClientRect();
            var toRect = toEl.getBoundingClientRect();
            var canvasRect = svg.parentElement.getBoundingClientRect();

            var x1 = fromRect.left + fromRect.width / 2 - canvasRect.left;
            var y1 = fromRect.bottom - canvasRect.top;
            var x2 = toRect.left + toRect.width / 2 - canvasRect.left;
            var y2 = toRect.top - canvasRect.top;

            var line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', x1);
            line.setAttribute('y1', y1);
            line.setAttribute('x2', x2);
            line.setAttribute('y2', y2);
            line.setAttribute('stroke', '#0066CC');
            line.setAttribute('stroke-width', '2');
            line.setAttribute('marker-end', 'url(#arrowhead)');
            svg.appendChild(line);
        }
    }

    // --- Canvas Empty State ---
    function _hideCanvasEmpty() {
        var empty = document.querySelector('.wf-canvas-empty');
        if (empty) empty.style.display = 'none';
    }

    function _showCanvasEmpty() {
        var empty = document.querySelector('.wf-canvas-empty');
        if (empty) empty.style.display = '';
    }

    // --- Helpers ---
    function _findStep(id) {
        for (var i = 0; i < _steps.length; i++) {
            if (_steps[i].id === id) return _steps[i];
        }
        return null;
    }

    function _getUrlParam(name) {
        var results = new RegExp('[?&]' + name + '=([^&#]*)').exec(window.location.href);
        return results ? decodeURIComponent(results[1]) : null;
    }

    function _escapeHtml(text) {
        if (!text) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(text));
        return div.innerHTML;
    }

    function _escapeAttr(text) {
        if (!text) return '';
        return text.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    return {
        initDesigner: initDesigner,
        updateProp: updateProp,
        removeStep: removeStep,
        configureStep: configureStep,
        saveWorkflow: saveWorkflow,
        STEP_TYPES: STEP_TYPES
    };
})();

/* ============================================================
   DIB Task Helpers - Used across pages
   ============================================================ */
DIB.Tasks = (function () {
    'use strict';

    var _siteUrl = (typeof _spPageContextInfo !== 'undefined') ? _spPageContextInfo.webAbsoluteUrl : '';
    var TASKS_LIST = 'DIBWorkflowTasks';

    // --- Demo data for when SP lists aren't available ---
    var DEMO_TASKS = [
        { Id: 1, Title: 'Review Budget Proposal', WorkflowName: 'Budget Approval', AssignedTo: { Title: 'John Smith' }, Status: 'In Progress', Priority: 'High', DueDate: _futureDate(-2), Created: _futureDate(-10), ApplicationName: 'Budget FY2026' },
        { Id: 2, Title: 'Approve Leave Request', WorkflowName: 'Leave Approval', AssignedTo: { Title: 'Jane Doe' }, Status: 'Pending', Priority: 'Medium', DueDate: _futureDate(3), Created: _futureDate(-5), ApplicationName: 'Leave Mgmt' },
        { Id: 3, Title: 'Sign Contract Amendment', WorkflowName: 'Contract Review', AssignedTo: { Title: 'Mike Johnson' }, Status: 'Pending', Priority: 'High', DueDate: _futureDate(-5), Created: _futureDate(-15), ApplicationName: 'Contracts' },
        { Id: 4, Title: 'Verify Invoice Details', WorkflowName: 'Invoice Processing', AssignedTo: { Title: 'Sarah Wilson' }, Status: 'In Progress', Priority: 'Low', DueDate: _futureDate(7), Created: _futureDate(-3), ApplicationName: 'Accounts Payable' },
        { Id: 5, Title: 'Complete Compliance Check', WorkflowName: 'Compliance Review', AssignedTo: { Title: 'John Smith' }, Status: 'Pending', Priority: 'High', DueDate: _futureDate(-1), Created: _futureDate(-8), ApplicationName: 'Compliance' },
        { Id: 6, Title: 'Review Marketing Plan', WorkflowName: 'Marketing Approval', AssignedTo: { Title: 'Jane Doe' }, Status: 'Completed', Priority: 'Medium', DueDate: _futureDate(0), Created: _futureDate(-12), ApplicationName: 'Marketing' },
        { Id: 7, Title: 'Approve Travel Expense', WorkflowName: 'Expense Approval', AssignedTo: { Title: 'Admin User' }, Status: 'Pending', Priority: 'Low', DueDate: _futureDate(5), Created: _futureDate(-2), ApplicationName: 'Expenses' },
        { Id: 8, Title: 'Deploy Staging Build', WorkflowName: 'Release Management', AssignedTo: { Title: 'Mike Johnson' }, Status: 'In Progress', Priority: 'High', DueDate: _futureDate(-3), Created: _futureDate(-7), ApplicationName: 'IT Releases' },
        { Id: 9, Title: 'Onboard New Hire', WorkflowName: 'HR Onboarding', AssignedTo: { Title: 'Sarah Wilson' }, Status: 'Pending', Priority: 'Medium', DueDate: _futureDate(2), Created: _futureDate(-4), ApplicationName: 'HR' },
        { Id: 10, Title: 'Audit Data Access', WorkflowName: 'Security Audit', AssignedTo: { Title: 'Admin User' }, Status: 'Pending', Priority: 'High', DueDate: _futureDate(-7), Created: _futureDate(-20), ApplicationName: 'Security' }
    ];

    var DEMO_APPS = [
        { Id: 1, Title: 'Budget FY2026', Status: 'In Progress', Stage: 'Finance Review', Owner: 'John Smith', StartDate: _futureDate(-30), Progress: 65 },
        { Id: 2, Title: 'Leave Mgmt System', Status: 'Pending', Stage: 'HR Approval', Owner: 'Jane Doe', StartDate: _futureDate(-15), Progress: 40 },
        { Id: 3, Title: 'Contract Renewal #445', Status: 'Overdue', Stage: 'Legal Review', Owner: 'Mike Johnson', StartDate: _futureDate(-45), Progress: 25 },
        { Id: 4, Title: 'Invoice Batch Q1', Status: 'In Progress', Stage: 'Validation', Owner: 'Sarah Wilson', StartDate: _futureDate(-10), Progress: 80 },
        { Id: 5, Title: 'Compliance Audit 2026', Status: 'Pending', Stage: 'Data Collection', Owner: 'Admin User', StartDate: _futureDate(-20), Progress: 15 },
        { Id: 6, Title: 'Marketing Campaign Q2', Status: 'Completed', Stage: 'Complete', Owner: 'Jane Doe', StartDate: _futureDate(-60), Progress: 100 },
        { Id: 7, Title: 'IT Infrastructure Upgrade', Status: 'In Progress', Stage: 'Implementation', Owner: 'Mike Johnson', StartDate: _futureDate(-25), Progress: 55 }
    ];

    function _futureDate(days) {
        var d = new Date();
        d.setDate(d.getDate() + days);
        return d.toISOString();
    }

    // --- Get tasks from SP or demo ---
    function getTasks(filter, callback) {
        if (_siteUrl) {
            _getTasksFromSP(filter, callback);
        } else {
            var filtered = DEMO_TASKS;
            if (filter) {
                if (filter.status) {
                    filtered = filtered.filter(function (t) { return t.Status === filter.status; });
                }
                if (filter.assignedTo) {
                    filtered = filtered.filter(function (t) { return t.AssignedTo && t.AssignedTo.Title === filter.assignedTo; });
                }
                if (filter.overdue) {
                    filtered = filtered.filter(function (t) { return new Date(t.DueDate) < new Date() && t.Status !== 'Completed'; });
                }
            }
            callback(filtered);
        }
    }

    function _getTasksFromSP(filter, callback) {
        var filterParts = [];
        if (filter && filter.status) {
            filterParts.push("Status eq '" + filter.status + "'");
        }
        if (filter && filter.assignedTo) {
            filterParts.push("AssignedTo/Title eq '" + filter.assignedTo + "'");
        }

        var url = _siteUrl + "/_api/web/lists/getbytitle('" + TASKS_LIST + "')/items" +
            "?$select=Id,Title,WorkflowName,Status,Priority,DueDate,Created,ApplicationName,AssignedTo/Title" +
            "&$expand=AssignedTo" +
            "&$orderby=DueDate asc" +
            (filterParts.length > 0 ? "&$filter=" + filterParts.join(' and ') : '');

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    callback(data.d.results || []);
                } else {
                    callback(DEMO_TASKS);
                }
            }
        };
        xhr.send();
    }

    // --- Get pipeline applications ---
    function getApplications(callback) {
        if (_siteUrl) {
            _getAppsFromSP(callback);
        } else {
            callback(DEMO_APPS);
        }
    }

    function _getAppsFromSP(callback) {
        var url = _siteUrl + "/_api/web/lists/getbytitle('DIBApplications')/items" +
            "?$select=Id,Title,Status,Stage,Owner,StartDate,Progress" +
            "&$orderby=Created desc";

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('Accept', 'application/json;odata=verbose');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    var data = JSON.parse(xhr.responseText);
                    callback(data.d.results || []);
                } else {
                    callback(DEMO_APPS);
                }
            }
        };
        xhr.send();
    }

    // --- Format date ---
    function formatDate(dateStr) {
        if (!dateStr) return '-';
        var d = new Date(dateStr);
        return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    }

    // --- Check if overdue ---
    function isOverdue(dateStr, status) {
        if (!dateStr || status === 'Completed') return false;
        return new Date(dateStr) < new Date();
    }

    // --- Get days overdue ---
    function getDaysOverdue(dateStr) {
        if (!dateStr) return 0;
        var diff = Math.floor((new Date() - new Date(dateStr)) / (1000 * 60 * 60 * 24));
        return Math.max(0, diff);
    }

    // --- Escape HTML ---
    function escapeHtml(text) {
        if (!text) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(text));
        return div.innerHTML;
    }

    return {
        getTasks: getTasks,
        getApplications: getApplications,
        formatDate: formatDate,
        isOverdue: isOverdue,
        getDaysOverdue: getDaysOverdue,
        escapeHtml: escapeHtml,
        DEMO_TASKS: DEMO_TASKS,
        DEMO_APPS: DEMO_APPS
    };
})();
