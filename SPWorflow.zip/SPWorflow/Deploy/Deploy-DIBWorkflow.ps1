<#
.SYNOPSIS
    Deploys DIB Workflow Portal to SharePoint 2013/2016/2019.

.DESCRIPTION
    This script:
    1. Uploads the DIB-branded Seattle.master to the Master Page Gallery
    2. Uploads CSS, JS, and images to the Style Library
    3. Creates the required SharePoint lists (Notifications, Workflow Configs, Tasks, Applications)
    4. Uploads application pages to the Pages library
    5. Sets the custom master page as the site master page

.PARAMETER SiteUrl
    The URL of the SharePoint site to deploy to.

.PARAMETER MasterPagePath
    Local path to the Seattle.master file. Defaults to the solution directory.

.EXAMPLE
    .\Deploy-DIBWorkflow.ps1 -SiteUrl "https://sharepoint.contoso.com/sites/workflow"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SiteUrl,

    [Parameter(Mandatory = $false)]
    [string]$SolutionRoot = (Split-Path -Parent $PSScriptRoot)
)

# --- Load SharePoint PowerShell Snap-in ---
if ((Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null) {
    Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction Stop
}

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  DIB Workflow Portal - SharePoint Deployment" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Site URL: $SiteUrl" -ForegroundColor White
Write-Host "Solution: $SolutionRoot" -ForegroundColor White
Write-Host ""

# --- Helper: Upload file to SharePoint library ---
function Upload-FileToLibrary {
    param(
        [Microsoft.SharePoint.SPWeb]$Web,
        [string]$LibraryName,
        [string]$FolderPath,
        [string]$LocalFilePath,
        [hashtable]$Properties = @{}
    )

    $fileName = Split-Path $LocalFilePath -Leaf
    $fileContent = [System.IO.File]::ReadAllBytes($LocalFilePath)

    $folder = $Web.GetFolder($FolderPath)
    if (-not $folder.Exists) {
        # Create folder structure
        $parts = $FolderPath.Split('/')
        $currentFolder = $Web.RootFolder
        foreach ($part in $parts) {
            if ($part -and $part -ne $Web.ServerRelativeUrl.TrimStart('/')) {
                $subFolder = $currentFolder.SubFolders[$part]
                if ($subFolder -eq $null) {
                    $subFolder = $currentFolder.SubFolders.Add($part)
                }
                $currentFolder = $subFolder
            }
        }
        $folder = $currentFolder
    }

    $fileUrl = "$FolderPath/$fileName"
    $spFile = $Web.GetFile($fileUrl)

    if ($spFile.Exists) {
        $spFile.CheckOut()
    }

    $uploadedFile = $folder.Files.Add($fileName, $fileContent, $true)

    # Set properties
    if ($Properties.Count -gt 0) {
        $item = $uploadedFile.Item
        foreach ($key in $Properties.Keys) {
            $item[$key] = $Properties[$key]
        }
        $item.Update()
    }

    if ($uploadedFile.CheckOutType -ne [Microsoft.SharePoint.SPFile+SPCheckOutType]::None) {
        $uploadedFile.CheckIn("DIB Deployment", [Microsoft.SharePoint.SPCheckinType]::MajorCheckIn)
    }

    if ($uploadedFile.Item.ParentList.EnableModeration) {
        $uploadedFile.Approve("DIB Deployment - Auto-approved")
    }

    Write-Host "  Uploaded: $fileName -> $FolderPath" -ForegroundColor Green
    return $uploadedFile
}

# --- Helper: Create List if not exists ---
function Ensure-List {
    param(
        [Microsoft.SharePoint.SPWeb]$Web,
        [string]$ListName,
        [string]$Description,
        [Microsoft.SharePoint.SPListTemplateType]$TemplateType = [Microsoft.SharePoint.SPListTemplateType]::GenericList,
        [scriptblock]$ColumnSetup
    )

    $list = $Web.Lists.TryGetList($ListName)
    if ($list -eq $null) {
        $listId = $Web.Lists.Add($ListName, $Description, $TemplateType)
        $list = $Web.Lists[$listId]
        Write-Host "  Created list: $ListName" -ForegroundColor Green

        if ($ColumnSetup) {
            & $ColumnSetup $list
            $list.Update()
        }
    }
    else {
        Write-Host "  List exists: $ListName" -ForegroundColor Yellow
    }

    return $list
}

# --- Helper: Add field to list ---
function Add-ListField {
    param(
        [Microsoft.SharePoint.SPList]$List,
        [string]$InternalName,
        [string]$DisplayName,
        [Microsoft.SharePoint.SPFieldType]$FieldType,
        [bool]$Required = $false,
        [string[]]$Choices = @()
    )

    if ($List.Fields.ContainsField($InternalName)) { return }

    if ($FieldType -eq [Microsoft.SharePoint.SPFieldType]::Choice -and $Choices.Count -gt 0) {
        $choiceCollection = New-Object System.Collections.Specialized.StringCollection
        $Choices | ForEach-Object { $choiceCollection.Add($_) | Out-Null }
        $List.Fields.Add($InternalName, $FieldType, $Required, $false, $choiceCollection) | Out-Null
    }
    else {
        $List.Fields.Add($InternalName, $FieldType, $Required) | Out-Null
    }

    $field = $List.Fields[$InternalName]
    $field.Title = $DisplayName
    $field.Update()

    Write-Host "    Added field: $DisplayName ($FieldType)" -ForegroundColor Gray
}

try {
    # ==========================================
    # 1. Connect to SharePoint site
    # ==========================================
    Write-Host "[Step 1] Connecting to SharePoint..." -ForegroundColor Cyan
    $web = Get-SPWeb $SiteUrl -ErrorAction Stop
    Write-Host "  Connected: $($web.Title)" -ForegroundColor Green

    # ==========================================
    # 2. Upload Master Page
    # ==========================================
    Write-Host ""
    Write-Host "[Step 2] Uploading Master Page..." -ForegroundColor Cyan

    $masterPagePath = Join-Path $SolutionRoot "Seatle.master"
    if (-not (Test-Path $masterPagePath)) {
        throw "Master page not found: $masterPagePath"
    }

    $masterPageGalleryUrl = "$($web.ServerRelativeUrl)/_catalogs/masterpage"
    $masterPageFile = Upload-FileToLibrary -Web $web `
        -LibraryName "Master Page Gallery" `
        -FolderPath $masterPageGalleryUrl `
        -LocalFilePath $masterPagePath `
        -Properties @{
            "ContentTypeId" = "0x010105"
            "UIVersion" = "15"
        }

    # ==========================================
    # 3. Upload CSS, JS, Images to Style Library
    # ==========================================
    Write-Host ""
    Write-Host "[Step 3] Uploading Assets to Style Library..." -ForegroundColor Cyan

    $styleLibBase = "$($web.ServerRelativeUrl)/Style Library/DIB"

    # CSS
    $cssDir = Join-Path $SolutionRoot "Assets\CSS"
    if (Test-Path $cssDir) {
        Get-ChildItem $cssDir -File | ForEach-Object {
            Upload-FileToLibrary -Web $web -LibraryName "Style Library" -FolderPath "$styleLibBase/CSS" -LocalFilePath $_.FullName
        }
    }

    # JS
    $jsDir = Join-Path $SolutionRoot "Assets\JS"
    if (Test-Path $jsDir) {
        Get-ChildItem $jsDir -File | ForEach-Object {
            Upload-FileToLibrary -Web $web -LibraryName "Style Library" -FolderPath "$styleLibBase/JS" -LocalFilePath $_.FullName
        }
    }

    # Images (logo)
    $imagesDir = Join-Path $SolutionRoot "Assets\Images"
    if (Test-Path $imagesDir) {
        Get-ChildItem $imagesDir -File | ForEach-Object {
            Upload-FileToLibrary -Web $web -LibraryName "Style Library" -FolderPath "$styleLibBase/Images" -LocalFilePath $_.FullName
        }
    }

    # Also upload the logo from the root if present
    $logoFile = Join-Path $SolutionRoot "dib-logo (2).png"
    if (Test-Path $logoFile) {
        # Copy with clean name
        $cleanLogo = Join-Path $SolutionRoot "Assets\Images\dib-logo.png"
        Copy-Item $logoFile $cleanLogo -Force
        Upload-FileToLibrary -Web $web -LibraryName "Style Library" -FolderPath "$styleLibBase/Images" -LocalFilePath $cleanLogo
    }

    # ==========================================
    # 4. Create SharePoint Lists
    # ==========================================
    Write-Host ""
    Write-Host "[Step 4] Creating SharePoint Lists..." -ForegroundColor Cyan

    # --- DIBNotifications list ---
    Ensure-List -Web $web -ListName "DIBNotifications" -Description "Stores user notifications for the DIB Workflow Portal" -ColumnSetup {
        param($list)
        Add-ListField -List $list -InternalName "Body" -DisplayName "Body" -FieldType ([Microsoft.SharePoint.SPFieldType]::Note)
        Add-ListField -List $list -InternalName "NotificationType" -DisplayName "Notification Type" -FieldType ([Microsoft.SharePoint.SPFieldType]::Choice) -Choices @("assignment", "overdue", "completion", "reminder", "update")
        Add-ListField -List $list -InternalName "IsRead" -DisplayName "Is Read" -FieldType ([Microsoft.SharePoint.SPFieldType]::Boolean)
        Add-ListField -List $list -InternalName "AssignedTo" -DisplayName "Assigned To" -FieldType ([Microsoft.SharePoint.SPFieldType]::User)
    }

    # --- DIBWorkflowConfigs list ---
    Ensure-List -Web $web -ListName "DIBWorkflowConfigs" -Description "Stores workflow configuration JSON" -ColumnSetup {
        param($list)
        Add-ListField -List $list -InternalName "WorkflowConfig" -DisplayName "Workflow Config" -FieldType ([Microsoft.SharePoint.SPFieldType]::Note)
        Add-ListField -List $list -InternalName "IsActive" -DisplayName "Is Active" -FieldType ([Microsoft.SharePoint.SPFieldType]::Boolean)
    }

    # --- DIBWorkflowTasks list ---
    Ensure-List -Web $web -ListName "DIBWorkflowTasks" -Description "Workflow task items" -ColumnSetup {
        param($list)
        Add-ListField -List $list -InternalName "WorkflowName" -DisplayName "Workflow Name" -FieldType ([Microsoft.SharePoint.SPFieldType]::Text)
        Add-ListField -List $list -InternalName "Status" -DisplayName "Status" -FieldType ([Microsoft.SharePoint.SPFieldType]::Choice) -Choices @("Pending", "In Progress", "Completed", "Cancelled")
        Add-ListField -List $list -InternalName "Priority" -DisplayName "Priority" -FieldType ([Microsoft.SharePoint.SPFieldType]::Choice) -Choices @("High", "Medium", "Low")
        Add-ListField -List $list -InternalName "DueDate" -DisplayName "Due Date" -FieldType ([Microsoft.SharePoint.SPFieldType]::DateTime)
        Add-ListField -List $list -InternalName "AssignedTo" -DisplayName "Assigned To" -FieldType ([Microsoft.SharePoint.SPFieldType]::User)
        Add-ListField -List $list -InternalName "ApplicationName" -DisplayName "Application Name" -FieldType ([Microsoft.SharePoint.SPFieldType]::Text)
        Add-ListField -List $list -InternalName "TaskDescription" -DisplayName "Task Description" -FieldType ([Microsoft.SharePoint.SPFieldType]::Note)
    }

    # --- DIBApplications list ---
    Ensure-List -Web $web -ListName "DIBApplications" -Description "Applications in the workflow pipeline" -ColumnSetup {
        param($list)
        Add-ListField -List $list -InternalName "Status" -DisplayName "Status" -FieldType ([Microsoft.SharePoint.SPFieldType]::Choice) -Choices @("Pending", "In Progress", "Overdue", "Completed")
        Add-ListField -List $list -InternalName "Stage" -DisplayName "Current Stage" -FieldType ([Microsoft.SharePoint.SPFieldType]::Text)
        Add-ListField -List $list -InternalName "Owner" -DisplayName "Owner" -FieldType ([Microsoft.SharePoint.SPFieldType]::Text)
        Add-ListField -List $list -InternalName "StartDate" -DisplayName "Start Date" -FieldType ([Microsoft.SharePoint.SPFieldType]::DateTime)
        Add-ListField -List $list -InternalName "Progress" -DisplayName "Progress (%)" -FieldType ([Microsoft.SharePoint.SPFieldType]::Number)
    }

    # ==========================================
    # 5. Upload Application Pages
    # ==========================================
    Write-Host ""
    Write-Host "[Step 5] Uploading Application Pages..." -ForegroundColor Cyan

    $pagesDir = Join-Path $SolutionRoot "Pages"
    $pagesLibUrl = "$($web.ServerRelativeUrl)/Pages"

    # Check if Pages library exists; if not, use SitePages
    $pagesList = $web.Lists.TryGetList("Pages")
    if ($pagesList -eq $null) {
        $pagesList = $web.Lists.TryGetList("Site Pages")
        if ($pagesList) {
            $pagesLibUrl = "$($web.ServerRelativeUrl)/SitePages"
        }
        else {
            # Create Pages library
            $web.Lists.Add("Pages", "Application pages", [Microsoft.SharePoint.SPListTemplateType]::WebPageLibrary) | Out-Null
            Write-Host "  Created Pages library" -ForegroundColor Green
        }
    }

    if (Test-Path $pagesDir) {
        Get-ChildItem $pagesDir -Filter "*.aspx" | ForEach-Object {
            Upload-FileToLibrary -Web $web -LibraryName "Pages" -FolderPath $pagesLibUrl -LocalFilePath $_.FullName
        }
    }

    # ==========================================
    # 6. Set Master Page
    # ==========================================
    Write-Host ""
    Write-Host "[Step 6] Setting Master Page..." -ForegroundColor Cyan

    $masterPageUrl = "$masterPageGalleryUrl/Seatle.master"
    $web.MasterUrl = $masterPageUrl
    $web.CustomMasterUrl = $masterPageUrl
    $web.Update()
    Write-Host "  Master page set to: $masterPageUrl" -ForegroundColor Green

    # ==========================================
    # Done!
    # ==========================================
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Green
    Write-Host "  Deployment Complete!" -ForegroundColor Green
    Write-Host "================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Dashboard:  $SiteUrl/Pages/Dashboard.aspx" -ForegroundColor White
    Write-Host "  Designer:   $SiteUrl/Pages/WorkflowDesigner.aspx" -ForegroundColor White
    Write-Host "  Tasks:      $SiteUrl/Pages/PendingTasks.aspx" -ForegroundColor White
    Write-Host "  My Tasks:   $SiteUrl/Pages/MyTasks.aspx" -ForegroundColor White
    Write-Host "  Pipeline:   $SiteUrl/Pages/Pipeline.aspx" -ForegroundColor White
    Write-Host ""
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor DarkRed
}
finally {
    if ($web) { $web.Dispose() }
}
