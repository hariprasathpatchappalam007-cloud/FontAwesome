<%@ Page Language="C#" MasterPageFile="~masterurl/default.master" Inherits="Microsoft.SharePoint.WebPartPages.WebPartPage,Microsoft.SharePoint,Version=15.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %>
<%@ Register TagPrefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitle" runat="server">
    DIB - My Tasks
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitleInTitleArea" runat="server">
    My Tasks
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderMain" runat="server">

<!-- Summary Stats -->
<div class="dib-stats-grid" id="myTaskStats"></div>

<!-- Tabs -->
<div class="dib-tabs">
    <button class="dib-tab active" onclick="switchTab('all', this);">All My Tasks</button>
    <button class="dib-tab" onclick="switchTab('pending', this);">Pending</button>
    <button class="dib-tab" onclick="switchTab('inprogress', this);">In Progress</button>
    <button class="dib-tab" onclick="switchTab('overdue', this);">Overdue</button>
    <button class="dib-tab" onclick="switchTab('completed', this);">Completed</button>
</div>

<!-- Filter -->
<div class="dib-filter-bar" style="margin-bottom:16px;">
    <div class="dib-search-box">
        <input type="text" id="myTaskSearch" placeholder="Search my tasks..." onkeyup="filterMyTasks();" />
    </div>
    <select id="myTaskPriority" onchange="filterMyTasks();">
        <option value="">All Priorities</option>
        <option value="High">High</option>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
    </select>
</div>

<!-- Tasks List -->
<div class="dib-card">
    <div class="dib-card-header">
        <span id="myTaskLabel">&#128100; My Tasks (0)</span>
    </div>
    <div class="dib-card-body" style="padding:0;">
        <table class="dib-table" id="myTasksTable">
            <thead>
                <tr>
                    <th style="width:30px;">#</th>
                    <th>Task</th>
                    <th>Workflow</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Due Date</th>
                    <th>Days Remaining</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="myTasksBody">
                <tr><td colspan="8" style="text-align:center;padding:40px;color:#999;">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript">
var myTasks = [];
var currentTab = 'all';
var currentUser = (typeof _spPageContextInfo !== 'undefined') ? _spPageContextInfo.userDisplayName : 'Admin User';

function loadMyTasks() {
    DIB.Tasks.getTasks(null, function(tasks) {
        // Filter to current user
        myTasks = tasks.filter(function(t) {
            return t.AssignedTo && t.AssignedTo.Title === currentUser;
        });
        // If no match for current user in demo, show all
        if (myTasks.length === 0) {
            myTasks = tasks;
        }
        renderStats();
        filterMyTasks();
    });
}

function renderStats() {
    var stats = document.getElementById('myTaskStats');
    var total = myTasks.length;
    var pending = myTasks.filter(function(t) { return t.Status === 'Pending'; }).length;
    var inProgress = myTasks.filter(function(t) { return t.Status === 'In Progress'; }).length;
    var overdue = myTasks.filter(function(t) { return DIB.Tasks.isOverdue(t.DueDate, t.Status); }).length;
    var completed = myTasks.filter(function(t) { return t.Status === 'Completed'; }).length;

    stats.innerHTML =
        '<div class="dib-stat-card stat-total" onclick="switchTab(\'all\', null);"><div class="dib-stat-number">' + total + '</div><div class="dib-stat-label">Total Tasks</div></div>' +
        '<div class="dib-stat-card stat-pending" onclick="switchTab(\'pending\', null);"><div class="dib-stat-number">' + pending + '</div><div class="dib-stat-label">Pending</div></div>' +
        '<div class="dib-stat-card stat-progress" onclick="switchTab(\'inprogress\', null);"><div class="dib-stat-number">' + inProgress + '</div><div class="dib-stat-label">In Progress</div></div>' +
        '<div class="dib-stat-card stat-overdue" onclick="switchTab(\'overdue\', null);"><div class="dib-stat-number">' + overdue + '</div><div class="dib-stat-label">Overdue</div></div>' +
        '<div class="dib-stat-card stat-completed" onclick="switchTab(\'completed\', null);"><div class="dib-stat-number">' + completed + '</div><div class="dib-stat-label">Completed</div></div>';
}

function switchTab(tab, btn) {
    currentTab = tab;
    var tabs = document.querySelectorAll('.dib-tab');
    for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove('active');
    if (btn) btn.classList.add('active');
    else {
        var tabMap = { all: 0, pending: 1, inprogress: 2, overdue: 3, completed: 4 };
        if (tabs[tabMap[tab]]) tabs[tabMap[tab]].classList.add('active');
    }
    filterMyTasks();
}

function filterMyTasks() {
    var search = (document.getElementById('myTaskSearch').value || '').toLowerCase();
    var priority = document.getElementById('myTaskPriority').value;

    var filtered = myTasks.filter(function(t) {
        if (search && t.Title.toLowerCase().indexOf(search) === -1) return false;
        if (priority && t.Priority !== priority) return false;
        if (currentTab === 'pending' && t.Status !== 'Pending') return false;
        if (currentTab === 'inprogress' && t.Status !== 'In Progress') return false;
        if (currentTab === 'completed' && t.Status !== 'Completed') return false;
        if (currentTab === 'overdue' && !DIB.Tasks.isOverdue(t.DueDate, t.Status)) return false;
        return true;
    });

    renderMyTasks(filtered);
}

function renderMyTasks(tasks) {
    var tbody = document.getElementById('myTasksBody');
    var label = document.getElementById('myTaskLabel');
    label.innerHTML = '&#128100; My Tasks (' + tasks.length + ')';

    if (tasks.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#999;">No tasks found</td></tr>';
        return;
    }

    var html = '';
    for (var i = 0; i < tasks.length; i++) {
        var t = tasks[i];
        var overdue = DIB.Tasks.isOverdue(t.DueDate, t.Status);
        var daysLeft = Math.ceil((new Date(t.DueDate) - new Date()) / (1000 * 60 * 60 * 24));

        var statusClass = 'dib-badge-pending';
        if (t.Status === 'In Progress') statusClass = 'dib-badge-inprogress';
        else if (t.Status === 'Completed') statusClass = 'dib-badge-completed';

        var priorityClass = 'dib-badge-low';
        if (t.Priority === 'High') priorityClass = 'dib-badge-high';
        else if (t.Priority === 'Medium') priorityClass = 'dib-badge-medium';

        var daysLabel = '';
        if (t.Status === 'Completed') {
            daysLabel = '<span style="color:#28a745;">Done</span>';
        } else if (overdue) {
            daysLabel = '<span class="dib-overdue-indicator">&#9888; ' + Math.abs(daysLeft) + ' days overdue</span>';
        } else {
            daysLabel = '<span style="color:#0066CC;">' + daysLeft + ' days left</span>';
        }

        html += '<tr class="' + (overdue ? 'dib-overdue-row' : '') + '">' +
            '<td>' + (i + 1) + '</td>' +
            '<td><strong>' + DIB.Tasks.escapeHtml(t.Title) + '</strong></td>' +
            '<td>' + DIB.Tasks.escapeHtml(t.WorkflowName || '-') + '</td>' +
            '<td><span class="dib-badge ' + priorityClass + '">' + DIB.Tasks.escapeHtml(t.Priority) + '</span></td>' +
            '<td><span class="dib-badge ' + statusClass + '">' + DIB.Tasks.escapeHtml(t.Status) + '</span></td>' +
            '<td>' + DIB.Tasks.formatDate(t.DueDate) + '</td>' +
            '<td>' + daysLabel + '</td>' +
            '<td>' +
            (t.Status !== 'Completed' ?
                '<button class="dib-btn dib-btn-sm dib-btn-success" onclick="completeTask(' + t.Id + ');">Complete</button> ' : '') +
            '<button class="dib-btn dib-btn-sm dib-btn-secondary" onclick="viewTask(' + t.Id + ');">View</button>' +
            '</td></tr>';
    }
    tbody.innerHTML = html;
}

function completeTask(id) {
    for (var i = 0; i < myTasks.length; i++) {
        if (myTasks[i].Id === id) {
            myTasks[i].Status = 'Completed';
            break;
        }
    }
    renderStats();
    filterMyTasks();
    if (DIB.Notifications) DIB.Notifications.showToast('Task Completed', 'Task marked as completed', 'success');
}

function viewTask(id) {
    if (DIB.Notifications) DIB.Notifications.showToast('Task Details', 'Opening task #' + id, 'info');
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadMyTasks);
} else {
    loadMyTasks();
}
</script>

</asp:Content>
