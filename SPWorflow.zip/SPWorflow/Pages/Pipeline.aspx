<%@ Page Language="C#" MasterPageFile="~masterurl/default.master" Inherits="Microsoft.SharePoint.WebPartPages.WebPartPage,Microsoft.SharePoint,Version=15.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %>
<%@ Register TagPrefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitle" runat="server">
    DIB - Application Pipeline
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitleInTitleArea" runat="server">
    Application Pipeline
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderMain" runat="server">

<!-- Pipeline Stats -->
<div class="dib-stats-grid" id="pipelineStats"></div>

<!-- Filter Bar -->
<div class="dib-filter-bar" style="margin-bottom:16px;">
    <div class="dib-search-box">
        <input type="text" id="pipeSearch" placeholder="Search applications..." onkeyup="filterPipeline();" />
    </div>
    <select id="pipeStatus" onchange="filterPipeline();">
        <option value="">All Statuses</option>
        <option value="Pending">Pending</option>
        <option value="In Progress">In Progress</option>
        <option value="Overdue">Overdue</option>
        <option value="Completed">Completed</option>
    </select>
</div>

<!-- Pipeline Table -->
<div class="dib-card">
    <div class="dib-card-header">
        <span id="pipeLabel">&#128200; Applications in Pipeline (0)</span>
    </div>
    <div class="dib-card-body" style="padding:0;">
        <table class="dib-table" id="pipelineTable">
            <thead>
                <tr>
                    <th style="width:30px;">#</th>
                    <th>Application</th>
                    <th>Current Stage</th>
                    <th>Owner</th>
                    <th>Status</th>
                    <th>Start Date</th>
                    <th>Progress</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="pipelineBody">
                <tr><td colspan="8" style="text-align:center;padding:40px;color:#999;">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript">
var allApps = [];

function loadPipeline() {
    DIB.Tasks.getApplications(function(apps) {
        allApps = apps;
        renderPipelineStats(apps);
        filterPipeline();
    });
}

function renderPipelineStats(apps) {
    var stats = document.getElementById('pipelineStats');
    var total = apps.length;
    var pending = apps.filter(function(a) { return a.Status === 'Pending'; }).length;
    var inProgress = apps.filter(function(a) { return a.Status === 'In Progress'; }).length;
    var overdue = apps.filter(function(a) { return a.Status === 'Overdue'; }).length;
    var completed = apps.filter(function(a) { return a.Status === 'Completed'; }).length;

    stats.innerHTML =
        '<div class="dib-stat-card stat-total"><div class="dib-stat-number">' + total + '</div><div class="dib-stat-label">Total Applications</div></div>' +
        '<div class="dib-stat-card stat-pending"><div class="dib-stat-number">' + pending + '</div><div class="dib-stat-label">Pending</div></div>' +
        '<div class="dib-stat-card stat-progress"><div class="dib-stat-number">' + inProgress + '</div><div class="dib-stat-label">In Progress</div></div>' +
        '<div class="dib-stat-card stat-overdue"><div class="dib-stat-number">' + overdue + '</div><div class="dib-stat-label">Overdue</div></div>' +
        '<div class="dib-stat-card stat-completed"><div class="dib-stat-number">' + completed + '</div><div class="dib-stat-label">Completed</div></div>';
}

function filterPipeline() {
    var search = (document.getElementById('pipeSearch').value || '').toLowerCase();
    var status = document.getElementById('pipeStatus').value;

    var filtered = allApps.filter(function(a) {
        if (search && a.Title.toLowerCase().indexOf(search) === -1) return false;
        if (status && a.Status !== status) return false;
        return true;
    });

    renderPipeline(filtered);
}

function renderPipeline(apps) {
    var tbody = document.getElementById('pipelineBody');
    var label = document.getElementById('pipeLabel');
    label.innerHTML = '&#128200; Applications in Pipeline (' + apps.length + ')';

    if (apps.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:#999;">No applications found</td></tr>';
        return;
    }

    var html = '';
    for (var i = 0; i < apps.length; i++) {
        var a = apps[i];
        var ownerInitials = a.Owner ? a.Owner.split(' ').map(function(n){return n[0];}).join('') : '?';

        var statusClass = 'dib-badge-pending';
        if (a.Status === 'In Progress') statusClass = 'dib-badge-inprogress';
        else if (a.Status === 'Completed') statusClass = 'dib-badge-completed';
        else if (a.Status === 'Overdue') statusClass = 'dib-badge-overdue';

        var progressColor = 'bg-info';
        if (a.Progress >= 100) progressColor = 'bg-success';
        else if (a.Status === 'Overdue') progressColor = 'bg-danger';
        else if (a.Progress < 30) progressColor = 'bg-warning';

        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td><strong>' + DIB.Tasks.escapeHtml(a.Title) + '</strong></td>' +
            '<td>' + DIB.Tasks.escapeHtml(a.Stage || '-') + '</td>' +
            '<td><span class="dib-avatar" title="' + DIB.Tasks.escapeHtml(a.Owner || '') + '">' + ownerInitials + '</span> ' + DIB.Tasks.escapeHtml(a.Owner || '-') + '</td>' +
            '<td><span class="dib-badge ' + statusClass + '">' + DIB.Tasks.escapeHtml(a.Status) + '</span></td>' +
            '<td>' + DIB.Tasks.formatDate(a.StartDate) + '</td>' +
            '<td style="min-width:120px;">' +
            '<div style="display:flex;align-items:center;gap:8px;">' +
            '<div class="dib-progress" style="flex:1;"><div class="dib-progress-bar ' + progressColor + '" style="width:' + a.Progress + '%;"></div></div>' +
            '<span style="font-size:12px;font-weight:600;color:#333;">' + a.Progress + '%</span>' +
            '</div></td>' +
            '<td><button class="dib-btn dib-btn-sm dib-btn-secondary" onclick="viewApp(' + a.Id + ');">Details</button></td>' +
            '</tr>';
    }
    tbody.innerHTML = html;
}

function viewApp(id) {
    if (DIB.Notifications) DIB.Notifications.showToast('Application', 'Opening application #' + id, 'info');
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadPipeline);
} else {
    loadPipeline();
}
</script>

</asp:Content>
