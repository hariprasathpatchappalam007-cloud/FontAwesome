<%@ Page Language="C#" MasterPageFile="~masterurl/default.master" Inherits="Microsoft.SharePoint.WebPartPages.WebPartPage,Microsoft.SharePoint,Version=15.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %>
<%@ Register TagPrefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitle" runat="server">
    DIB - Workflow Designer
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitleInTitleArea" runat="server">
    Workflow Designer
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderMain" runat="server">

<style>
    #contentBox { max-width: 100%; padding: 16px; }
</style>

<!-- Toolbar -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
    <div style="display:flex;align-items:center;gap:12px;">
        <label style="font-weight:600;color:#003366;">Workflow Name:</label>
        <input type="text" id="wfName" class="dib-form-control" style="width:280px;" placeholder="Enter workflow name..." />
    </div>
    <div style="display:flex;gap:8px;">
        <button class="dib-btn dib-btn-primary" onclick="DIB.Workflow.saveWorkflow();">&#128190; Save Workflow</button>
        <button class="dib-btn dib-btn-outline" onclick="window.location.reload();">&#128260; Clear</button>
    </div>
</div>

<!-- Designer Layout -->
<div class="wf-designer">

    <!-- Toolbox -->
    <div class="wf-toolbox">
        <div class="wf-toolbox-header">&#128295; Toolbox</div>
        <div class="wf-toolbox-section">
            <div class="wf-toolbox-section-title">Actions</div>
            <div class="wf-tool-item" draggable="true" data-type="task">
                <div class="wf-tool-icon task">&#9745;</div>
                <div><strong>Task</strong><br/><span style="font-size:11px;color:#999;">Assign work to a user</span></div>
            </div>
            <div class="wf-tool-item" draggable="true" data-type="approval">
                <div class="wf-tool-icon approval">&#10004;</div>
                <div><strong>Approval</strong><br/><span style="font-size:11px;color:#999;">Require approval</span></div>
            </div>
            <div class="wf-tool-item" draggable="true" data-type="notification">
                <div class="wf-tool-icon notification">&#9993;</div>
                <div><strong>Notification</strong><br/><span style="font-size:11px;color:#999;">Send alert/email</span></div>
            </div>
        </div>
        <div class="wf-toolbox-section">
            <div class="wf-toolbox-section-title">Flow Control</div>
            <div class="wf-tool-item" draggable="true" data-type="condition">
                <div class="wf-tool-icon condition">&#10067;</div>
                <div><strong>Condition</strong><br/><span style="font-size:11px;color:#999;">If/then branching</span></div>
            </div>
            <div class="wf-tool-item" draggable="true" data-type="delay">
                <div class="wf-tool-icon delay">&#9200;</div>
                <div><strong>Delay/Timer</strong><br/><span style="font-size:11px;color:#999;">Wait for duration</span></div>
            </div>
            <div class="wf-tool-item" draggable="true" data-type="parallel">
                <div class="wf-tool-icon parallel">&#8801;</div>
                <div><strong>Parallel</strong><br/><span style="font-size:11px;color:#999;">Run steps in parallel</span></div>
            </div>
        </div>
    </div>

    <!-- Canvas -->
    <div class="wf-canvas" id="wfCanvas">
        <svg id="wfConnectionsSvg" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:5;">
            <defs>
                <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#0066CC" />
                </marker>
            </defs>
        </svg>
        <div class="wf-canvas-empty">
            <div class="icon">&#128640;</div>
            <div style="font-size:16px;font-weight:600;margin-bottom:8px;">Drag & Drop Steps Here</div>
            <div style="font-size:13px;">Drag items from the toolbox to build your workflow</div>
        </div>
    </div>

    <!-- Properties Panel -->
    <div class="wf-properties">
        <div class="wf-properties-header">&#9881; Properties</div>
        <div class="wf-properties-body" id="wfPropertiesBody">
            <div style="padding:20px;text-align:center;color:#999;">Select a step to view properties</div>
        </div>
    </div>
</div>

<script type="text/javascript">
    // Initialize designer when page loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() { DIB.Workflow.initDesigner(); });
    } else {
        DIB.Workflow.initDesigner();
    }
</script>

</asp:Content>
