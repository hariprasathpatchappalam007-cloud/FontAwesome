<%@ Page Language="C#" MasterPageFile="~masterurl/default.master" Inherits="Microsoft.SharePoint.WebPartPages.WebPartPage,Microsoft.SharePoint,Version=15.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %>
<%@ Register TagPrefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitle" runat="server">
    DIB - Pending Tasks
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitleInTitleArea" runat="server">
    Pending Tasks
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderMain" runat="server">

<!-- Filter Bar -->
<div class="dib-card">
    <div class="dib-card-header">
        <span>&#128270; Filter Tasks</span>
        <button class="dib-btn dib-btn-sm dib-btn-outline" onclick="resetFilters();">Reset</button>
    </div>
    <div class="dib-card-body">
        <div class="dib-filter-bar">
            <div class="dib-search-box">
                <input type="text" id="filterSearch" placeholder="Search tasks..." onkeyup="applyFilters();" />
            </div>
            <select id="filterStatus" onchange="applyFilters();">
                <option value="">All Statuses</option>
                <option value="Pending" selected>Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
            </select>
            <select id="filterPriority" onchange="applyFilters();">
                <option value="">All Priorities</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
            </select>
            <select id="filterWorkflow" onchange="applyFilters();">
                <option value="">All Workflows</option>
            </select>
            <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                <input type="checkbox" id="filterOverdue" onchange="applyFilters();" /> Overdue Only
            </label>
        </div>
    </div>
</div>

<!-- Tasks Table -->
<div class="dib-card">
    <div class="dib-card-header">
        <span id="taskCountLabel">&#128203; Pending Tasks (0)</span>
        <button class="dib-btn dib-btn-sm dib-btn-primary" onclick="exportTasks();">&#128229; Export</button>
    </div>
    <div class="dib-card-body" style="padding:0;">
        <table class="dib-table" id="tasksTable">
            <thead>
                <tr>
                    <th style="width:30px;">#</th>
                    <th>Task</th>
                    <th>Workflow</th>
                    <th>Assigned To</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Due Date</th>
                    <th>Overdue</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="tasksBody">
                <tr><td colspan="9" style="text-align:center;padding:40px;color:#999;">Loading tasks...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript">
var allTasks = [];

function loadTasks() {
    DIB.Tasks.getTasks(null, function(tasks) {
        allTasks = tasks;
        populateWorkflowFilter(tasks);
        applyFilters();
    });
}

function populateWorkflowFilter(tasks) {
    var select = document.getElementById('filterWorkflow');
    var workflows = {};
    for (var i = 0; i < tasks.length; i++) {
        if (tasks[i].WorkflowName) workflows[tasks[i].WorkflowName] = true;
    }
    for (var wf in workflows) {
        var opt = document.createElement('option');
        opt.value = wf;
        opt.textContent = wf;
        select.appendChild(opt);
    }
}

function applyFilters() {
    var search = (document.getElementById('filterSearch').value || '').toLowerCase();
    var status = document.getElementById('filterStatus').value;
    var priority = document.getElementById('filterPriority').value;
    var workflow = document.getElementById('filterWorkflow').value;
    var overdueOnly = document.getElementById('filterOverdue').checked;

    var filtered = allTasks.filter(function(t) {
        if (search && t.Title.toLowerCase().indexOf(search) === -1) return false;
        if (status && t.Status !== status) return false;
        if (priority && t.Priority !== priority) return false;
        if (workflow && t.WorkflowName !== workflow) return false;
        if (overdueOnly && !DIB.Tasks.isOverdue(t.DueDate, t.Status)) return false;
        return true;
    });

    renderTasks(filtered);
}

function renderTasks(tasks) {
    var tbody = document.getElementById('tasksBody');
    var label = document.getElementById('taskCountLabel');
    label.innerHTML = '&#128203; Pending Tasks (' + tasks.length + ')';

    if (tasks.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:40px;color:#999;">No tasks match the current filters</td></tr>';
        return;
    }

    var html = '';
    for (var i = 0; i < tasks.length; i++) {
        var t = tasks[i];
        var overdue = DIB.Tasks.isOverdue(t.DueDate, t.Status);
        var daysOver = DIB.Tasks.getDaysOverdue(t.DueDate);
        var assignee = t.AssignedTo ? t.AssignedTo.Title : '-';
        var initials = assignee !== '-' ? assignee.split(' ').map(function(n){return n[0];}).join('') : '?';

        var statusClass = 'dib-badge-pending';
        if (t.Status === 'In Progress') statusClass = 'dib-badge-inprogress';
        else if (t.Status === 'Completed') statusClass = 'dib-badge-completed';

        var priorityClass = 'dib-badge-low';
        if (t.Priority === 'High') priorityClass = 'dib-badge-high';
        else if (t.Priority === 'Medium') priorityClass = 'dib-badge-medium';

        html += '<tr class="' + (overdue ? 'dib-overdue-row' : '') + '">' +
            '<td>' + (i + 1) + '</td>' +
            '<td><strong>' + DIB.Tasks.escapeHtml(t.Title) + '</strong></td>' +
            '<td>' + DIB.Tasks.escapeHtml(t.WorkflowName || '-') + '</td>' +
            '<td><span class="dib-avatar" title="' + DIB.Tasks.escapeHtml(assignee) + '">' + initials + '</span> ' + DIB.Tasks.escapeHtml(assignee) + '</td>' +
            '<td><span class="dib-badge ' + priorityClass + '">' + DIB.Tasks.escapeHtml(t.Priority) + '</span></td>' +
            '<td><span class="dib-badge ' + statusClass + '">' + DIB.Tasks.escapeHtml(t.Status) + '</span></td>' +
            '<td>' + DIB.Tasks.formatDate(t.DueDate) + '</td>' +
            '<td>' + (overdue ? '<span class="dib-overdue-indicator">&#9888; ' + daysOver + ' days</span>' : '-') + '</td>' +
            '<td><button class="dib-btn dib-btn-sm dib-btn-secondary" onclick="viewTask(' + t.Id + ');">View</button></td>' +
            '</tr>';
    }
    tbody.innerHTML = html;
}

function resetFilters() {
    document.getElementById('filterSearch').value = '';
    document.getElementById('filterStatus').value = 'Pending';
    document.getElementById('filterPriority').value = '';
    document.getElementById('filterWorkflow').value = '';
    document.getElementById('filterOverdue').checked = false;
    applyFilters();
}

function viewTask(id) {
    if (DIB.Notifications) DIB.Notifications.showToast('Task Details', 'Opening task #' + id, 'info');
}

function exportTasks() {
    if (DIB.Notifications) DIB.Notifications.showToast('Export', 'Task list export initiated', 'info');
}

// Load on page ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadTasks);
} else {
    loadTasks();
}
</script>

</asp:Content>
