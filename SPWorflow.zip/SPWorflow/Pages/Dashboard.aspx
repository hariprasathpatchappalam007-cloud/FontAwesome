<%@ Page Language="C#" MasterPageFile="~masterurl/default.master" Inherits="Microsoft.SharePoint.WebPartPages.WebPartPage,Microsoft.SharePoint,Version=15.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %>
<%@ Register TagPrefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=15.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitle" runat="server">
    DIB - Workflow Dashboard
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderPageTitleInTitleArea" runat="server">
    Workflow Dashboard
</asp:Content>

<asp:Content ContentPlaceHolderId="PlaceHolderMain" runat="server">

<!-- Dashboard Stats -->
<div class="dib-stats-grid" id="dashStats"></div>

<!-- Two Column Layout -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">

    <!-- Overdue / Long Pending Items -->
    <div class="dib-card">
        <div class="dib-card-header" style="background:#fff5f5;color:#dc3545;">
            <span>&#9888; Overdue &amp; Long Pending Items</span>
            <a href="/Pages/PendingTasks.aspx" class="dib-btn dib-btn-sm dib-btn-outline" style="border-color:#dc3545;color:#dc3545;">View All</a>
        </div>
        <div class="dib-card-body" style="padding:0;">
            <table class="dib-table" id="overdueTable">
                <thead>
                    <tr>
                        <th>Task</th>
                        <th>Assigned To</th>
                        <th>Due Date</th>
                        <th>Days Overdue</th>
                    </tr>
                </thead>
                <tbody id="overdueBody">
                    <tr><td colspan="4" style="text-align:center;padding:30px;color:#999;">Loading...</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Recent Activity / My Tasks Quick View -->
    <div class="dib-card">
        <div class="dib-card-header">
            <span>&#128100; My Upcoming Tasks</span>
            <a href="/Pages/MyTasks.aspx" class="dib-btn dib-btn-sm dib-btn-outline">View All</a>
        </div>
        <div class="dib-card-body" style="padding:0;">
            <table class="dib-table" id="myUpcomingTable">
                <thead>
                    <tr>
                        <th>Task</th>
                        <th>Priority</th>
                        <th>Due Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody id="myUpcomingBody">
                    <tr><td colspan="4" style="text-align:center;padding:30px;color:#999;">Loading...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pipeline Summary -->
<div class="dib-card" style="margin-top:20px;">
    <div class="dib-card-header">
        <span>&#128200; Pipeline Overview</span>
        <a href="/Pages/Pipeline.aspx" class="dib-btn dib-btn-sm dib-btn-outline">Full Pipeline</a>
    </div>
    <div class="dib-card-body" style="padding:0;">
        <table class="dib-table" id="pipelineSummaryTable">
            <thead>
                <tr>
                    <th>Application</th>
                    <th>Stage</th>
                    <th>Owner</th>
                    <th>Status</th>
                    <th>Progress</th>
                </tr>
            </thead>
            <tbody id="pipelineSummaryBody">
                <tr><td colspan="5" style="text-align:center;padding:30px;color:#999;">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Notifications Log -->
<div class="dib-card" style="margin-top:20px;">
    <div class="dib-card-header">
        <span>&#128276; Recent Notifications</span>
    </div>
    <div class="dib-card-body" id="dashNotifLog">
        <div style="text-align:center;color:#999;">Loading notifications...</div>
    </div>
</div>

<script type="text/javascript">
var dashTasks = [];
var dashApps = [];

function loadDashboard() {
    DIB.Tasks.getTasks(null, function(tasks) {
        dashTasks = tasks;
        renderDashStats(tasks);
        renderOverdueSection(tasks);
        renderMyUpcoming(tasks);
    });
    DIB.Tasks.getApplications(function(apps) {
        dashApps = apps;
        renderPipelineSummary(apps);
    });
    renderNotifLog();
}

function renderDashStats(tasks) {
    var stats = document.getElementById('dashStats');
    var total = tasks.length;
    var pending = tasks.filter(function(t) { return t.Status === 'Pending'; }).length;
    var inProgress = tasks.filter(function(t) { return t.Status === 'In Progress'; }).length;
    var overdue = tasks.filter(function(t) { return DIB.Tasks.isOverdue(t.DueDate, t.Status); }).length;
    var completed = tasks.filter(function(t) { return t.Status === 'Completed'; }).length;

    stats.innerHTML =
        '<div class="dib-stat-card stat-total"><div class="dib-stat-number">' + total + '</div><div class="dib-stat-label">Total Tasks</div></div>' +
        '<div class="dib-stat-card stat-pending"><div class="dib-stat-number">' + pending + '</div><div class="dib-stat-label">Pending</div></div>' +
        '<div class="dib-stat-card stat-progress"><div class="dib-stat-number">' + inProgress + '</div><div class="dib-stat-label">In Progress</div></div>' +
        '<div class="dib-stat-card stat-overdue"><div class="dib-stat-number">' + overdue + '</div><div class="dib-stat-label">Overdue</div></div>' +
        '<div class="dib-stat-card stat-completed"><div class="dib-stat-number">' + completed + '</div><div class="dib-stat-label">Completed</div></div>';
}

function renderOverdueSection(tasks) {
    var tbody = document.getElementById('overdueBody');
    var overdue = tasks.filter(function(t) {
        return DIB.Tasks.isOverdue(t.DueDate, t.Status);
    }).sort(function(a, b) {
        return new Date(a.DueDate) - new Date(b.DueDate); // Most overdue first
    });

    if (overdue.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:30px;color:#28a745;">&#9989; No overdue items</td></tr>';
        return;
    }

    var html = '';
    for (var i = 0; i < overdue.length; i++) {
        var t = overdue[i];
        var days = DIB.Tasks.getDaysOverdue(t.DueDate);
        var assignee = t.AssignedTo ? t.AssignedTo.Title : '-';

        var urgency = 'dib-badge-medium';
        if (days > 7) urgency = 'dib-badge-high';
        else if (days > 14) urgency = 'dib-badge-overdue';

        html += '<tr class="dib-overdue-row">' +
            '<td><strong>' + DIB.Tasks.escapeHtml(t.Title) + '</strong><br/><span style="font-size:11px;color:#999;">' + DIB.Tasks.escapeHtml(t.WorkflowName || '') + '</span></td>' +
            '<td>' + DIB.Tasks.escapeHtml(assignee) + '</td>' +
            '<td>' + DIB.Tasks.formatDate(t.DueDate) + '</td>' +
            '<td><span class="dib-overdue-indicator">&#9888; ' + days + ' days overdue</span></td>' +
            '</tr>';
    }
    tbody.innerHTML = html;
}

function renderMyUpcoming(tasks) {
    var tbody = document.getElementById('myUpcomingBody');
    var currentUser = (typeof _spPageContextInfo !== 'undefined') ? _spPageContextInfo.userDisplayName : '';

    var myTasks = tasks.filter(function(t) {
        return t.Status !== 'Completed';
    }).sort(function(a, b) {
        return new Date(a.DueDate) - new Date(b.DueDate);
    }).slice(0, 5); // Top 5

    if (myTasks.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:30px;color:#999;">No upcoming tasks</td></tr>';
        return;
    }

    var html = '';
    for (var i = 0; i < myTasks.length; i++) {
        var t = myTasks[i];
        var overdue = DIB.Tasks.isOverdue(t.DueDate, t.Status);

        var statusClass = t.Status === 'In Progress' ? 'dib-badge-inprogress' : 'dib-badge-pending';
        var priorityClass = t.Priority === 'High' ? 'dib-badge-high' : (t.Priority === 'Medium' ? 'dib-badge-medium' : 'dib-badge-low');

        html += '<tr class="' + (overdue ? 'dib-overdue-row' : '') + '">' +
            '<td><strong>' + DIB.Tasks.escapeHtml(t.Title) + '</strong></td>' +
            '<td><span class="dib-badge ' + priorityClass + '">' + DIB.Tasks.escapeHtml(t.Priority) + '</span></td>' +
            '<td>' + DIB.Tasks.formatDate(t.DueDate) + '</td>' +
            '<td><span class="dib-badge ' + statusClass + '">' + DIB.Tasks.escapeHtml(t.Status) + '</span></td>' +
            '</tr>';
    }
    tbody.innerHTML = html;
}

function renderPipelineSummary(apps) {
    var tbody = document.getElementById('pipelineSummaryBody');
    var active = apps.filter(function(a) { return a.Status !== 'Completed'; }).slice(0, 5);

    if (active.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:30px;color:#999;">No active applications</td></tr>';
        return;
    }

    var html = '';
    for (var i = 0; i < active.length; i++) {
        var a = active[i];
        var statusClass = 'dib-badge-pending';
        if (a.Status === 'In Progress') statusClass = 'dib-badge-inprogress';
        else if (a.Status === 'Overdue') statusClass = 'dib-badge-overdue';

        var progressColor = 'bg-info';
        if (a.Status === 'Overdue') progressColor = 'bg-danger';
        else if (a.Progress < 30) progressColor = 'bg-warning';

        html += '<tr>' +
            '<td><strong>' + DIB.Tasks.escapeHtml(a.Title) + '</strong></td>' +
            '<td>' + DIB.Tasks.escapeHtml(a.Stage || '-') + '</td>' +
            '<td>' + DIB.Tasks.escapeHtml(a.Owner || '-') + '</td>' +
            '<td><span class="dib-badge ' + statusClass + '">' + DIB.Tasks.escapeHtml(a.Status) + '</span></td>' +
            '<td style="min-width:120px;">' +
            '<div style="display:flex;align-items:center;gap:8px;">' +
            '<div class="dib-progress" style="flex:1;"><div class="dib-progress-bar ' + progressColor + '" style="width:' + a.Progress + '%;"></div></div>' +
            '<span style="font-size:12px;font-weight:600;">' + a.Progress + '%</span>' +
            '</div></td></tr>';
    }
    tbody.innerHTML = html;
}

function renderNotifLog() {
    var container = document.getElementById('dashNotifLog');
    container.innerHTML =
        '<div style="display:flex;flex-direction:column;gap:8px;">' +
        '<div style="padding:10px;background:#f0f7ff;border-left:3px solid #0066CC;border-radius:4px;font-size:13px;">' +
        '<strong>&#128100; New Assignment</strong> - Budget Approval task assigned to John Smith <span style="color:#999;float:right;">2 min ago</span></div>' +
        '<div style="padding:10px;background:#fff5f5;border-left:3px solid #dc3545;border-radius:4px;font-size:13px;">' +
        '<strong>&#9888; Overdue Alert</strong> - Contract Review #445 is 5 days past due <span style="color:#999;float:right;">1 hour ago</span></div>' +
        '<div style="padding:10px;background:#f0fff0;border-left:3px solid #28a745;border-radius:4px;font-size:13px;">' +
        '<strong>&#9989; Task Completed</strong> - Marketing Plan review approved by Jane Doe <span style="color:#999;float:right;">3 hours ago</span></div>' +
        '<div style="padding:10px;background:#fffff0;border-left:3px solid #ffc107;border-radius:4px;font-size:13px;">' +
        '<strong>&#9200; Reminder</strong> - Invoice Batch Q1 validation due in 2 days <span style="color:#999;float:right;">5 hours ago</span></div>' +
        '</div>';
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadDashboard);
} else {
    loadDashboard();
}
</script>

</asp:Content>
