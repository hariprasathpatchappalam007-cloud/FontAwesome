using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using CETPortal.Models;

namespace CETPortal.Services
{
    public class AppRepository
    {
        private readonly string _connectionString;

        public AppRepository()
        {
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["CETPortalDb"];
            _connectionString = settings == null ? string.Empty : settings.ConnectionString;
        }

        public IList<PortalApp> GetApps(string searchText, string keyword, bool includeInactive)
        {
            List<PortalApp> apps = new List<PortalApp>();

            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = @"
SELECT
    a.AppId,
    a.AppName,
    a.AppDescription,
    a.TargetUrl,
    a.IconClass,
    a.IsActive,
    a.SortOrder,
    STUFF((
        SELECT ',' + k.Keyword
        FROM AppKeywords k
        WHERE k.AppId = a.AppId
        FOR XML PATH(''), TYPE
    ).value('.', 'nvarchar(max)'), 1, 1, '') AS Keywords
FROM PortalApps a
WHERE (@includeInactive = 1 OR a.IsActive = 1)
  AND (
      @searchText = ''
      OR a.AppName LIKE '%' + @searchText + '%'
      OR a.AppDescription LIKE '%' + @searchText + '%'
      OR EXISTS (
          SELECT 1 FROM AppKeywords x
          WHERE x.AppId = a.AppId AND x.Keyword LIKE '%' + @searchText + '%'
      )
  )
  AND (
      @keyword = ''
      OR EXISTS (
          SELECT 1 FROM AppKeywords y
          WHERE y.AppId = a.AppId AND y.Keyword LIKE '%' + @keyword + '%'
      )
  )
ORDER BY a.SortOrder, a.AppName;";

                command.Parameters.AddWithValue("@includeInactive", includeInactive ? 1 : 0);
                command.Parameters.AddWithValue("@searchText", searchText ?? string.Empty);
                command.Parameters.AddWithValue("@keyword", keyword ?? string.Empty);

                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        apps.Add(MapApp(reader));
                    }
                }
            }

            return apps;
        }

        public PortalApp FindFirstMatchingApp(string searchText, bool includeInactive)
        {
            IList<PortalApp> apps = GetApps(searchText, string.Empty, includeInactive);
            return apps.Count > 0 ? apps[0] : null;
        }

        public void AddApp(PortalApp app)
        {
            if (app == null)
            {
                throw new ArgumentNullException("app");
            }

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        int appId;
                        using (SqlCommand command = connection.CreateCommand())
                        {
                            command.Transaction = transaction;
                            command.CommandText = @"
INSERT INTO PortalApps (AppName, AppDescription, TargetUrl, IconClass, IsActive, SortOrder)
VALUES (@name, @description, @url, @iconClass, @isActive, @sortOrder);
SELECT CAST(SCOPE_IDENTITY() AS INT);";

                            command.Parameters.AddWithValue("@name", app.Name);
                            command.Parameters.AddWithValue("@description", app.Description);
                            command.Parameters.AddWithValue("@url", app.Url);
                            command.Parameters.AddWithValue("@iconClass", app.IconClass);
                            command.Parameters.AddWithValue("@isActive", app.IsActive);
                            command.Parameters.AddWithValue("@sortOrder", app.SortOrder);
                            appId = Convert.ToInt32(command.ExecuteScalar());
                        }

                        foreach (string keyword in SplitKeywords(app.Keywords))
                        {
                            using (SqlCommand command = connection.CreateCommand())
                            {
                                command.Transaction = transaction;
                                command.CommandText = "INSERT INTO AppKeywords (AppId, Keyword) VALUES (@appId, @keyword);";
                                command.Parameters.AddWithValue("@appId", appId);
                                command.Parameters.AddWithValue("@keyword", keyword);
                                command.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public void DeleteApp(int appId)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = "DELETE FROM PortalApps WHERE AppId = @appId;";
                command.Parameters.AddWithValue("@appId", appId);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private static PortalApp MapApp(SqlDataReader reader)
        {
            PortalApp app = new PortalApp();
            app.Id = Convert.ToInt32(reader["AppId"]);
            app.Name = Convert.ToString(reader["AppName"]);
            app.Description = Convert.ToString(reader["AppDescription"]);
            app.Url = Convert.ToString(reader["TargetUrl"]);
            app.IconClass = Convert.ToString(reader["IconClass"]);
            app.IsActive = Convert.ToBoolean(reader["IsActive"]);
            app.SortOrder = Convert.ToInt32(reader["SortOrder"]);
            app.Keywords = reader["Keywords"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Keywords"]);
            return app;
        }

        private static IEnumerable<string> SplitKeywords(string csv)
        {
            if (string.IsNullOrWhiteSpace(csv))
            {
                yield break;
            }

            string[] chunks = csv.Split(new[] { ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string chunk in chunks)
            {
                string value = chunk.Trim();
                if (value.Length > 0)
                {
                    yield return value;
                }
            }
        }
    }
}