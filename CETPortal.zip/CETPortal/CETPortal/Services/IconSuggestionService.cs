using System;
using System.Collections.Generic;
using System.Linq;
using CETPortal.Models;

namespace CETPortal.Services
{
    public class IconSuggestionService
    {
        private static readonly List<IconOption> Catalog = new List<IconOption>
        {
            new IconOption { IconClass = "fa-line-chart", Label = "Analytics" },
            new IconOption { IconClass = "fa-money", Label = "Finance" },
            new IconOption { IconClass = "fa-sitemap", Label = "Portfolio" },
            new IconOption { IconClass = "fa-cogs", Label = "Simulator" },
            new IconOption { IconClass = "fa-shield", Label = "Risk" },
            new IconOption { IconClass = "fa-users", Label = "HR" },
            new IconOption { IconClass = "fa-file-text", Label = "Documents" },
            new IconOption { IconClass = "fa-briefcase", Label = "Operations" },
            new IconOption { IconClass = "fa-dashboard", Label = "Dashboard" },
            new IconOption { IconClass = "fa-bank", Label = "Banking" },
            new IconOption { IconClass = "fa-laptop", Label = "Technology" },
            new IconOption { IconClass = "fa-exchange", Label = "Integration" }
        };

        private static readonly Dictionary<string, string[]> MatchTokens = new Dictionary<string, string[]>
        {
            { "fa-money", new[] { "finance", "treasury", "expense", "cost", "payment", "invoice" } },
            { "fa-line-chart", new[] { "tracker", "analytics", "report", "insight", "trend", "kpi" } },
            { "fa-sitemap", new[] { "portfolio", "allocation", "investment", "assets", "products" } },
            { "fa-cogs", new[] { "simulator", "engine", "workflow", "rules", "configuration" } },
            { "fa-shield", new[] { "risk", "compliance", "audit", "security", "control" } },
            { "fa-bank", new[] { "bank", "dib", "islamic", "branch", "core" } },
            { "fa-dashboard", new[] { "dashboard", "portal", "home", "overview" } },
            { "fa-users", new[] { "user", "employee", "people", "resource" } },
            { "fa-file-text", new[] { "document", "policy", "template", "letter" } },
            { "fa-briefcase", new[] { "operations", "ops", "service", "process" } },
            { "fa-laptop", new[] { "application", "system", "tech", "digital", "platform" } },
            { "fa-exchange", new[] { "integration", "api", "sync", "gateway", "interface" } }
        };

        public IList<IconOption> GetCatalog()
        {
            return Catalog;
        }

        public IList<IconOption> SuggestIcons(string name, string description, string url, int max)
        {
            string text = ((name ?? string.Empty) + " " + (description ?? string.Empty) + " " + (url ?? string.Empty)).ToLowerInvariant();
            List<Tuple<IconOption, int>> scored = new List<Tuple<IconOption, int>>();

            foreach (IconOption icon in Catalog)
            {
                int score = 0;
                string[] tokens;
                if (MatchTokens.TryGetValue(icon.IconClass, out tokens))
                {
                    foreach (string token in tokens)
                    {
                        if (text.Contains(token))
                        {
                            score++;
                        }
                    }
                }

                scored.Add(new Tuple<IconOption, int>(icon, score));
            }

            List<IconOption> strongMatches = scored
                .Where(x => x.Item2 > 0)
                .OrderByDescending(x => x.Item2)
                .ThenBy(x => x.Item1.Label)
                .Take(max)
                .Select(x => x.Item1)
                .ToList();

            if (strongMatches.Count > 0)
            {
                return strongMatches;
            }

            return Catalog.Take(max).ToList();
        }
    }
}