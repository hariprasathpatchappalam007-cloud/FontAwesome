using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CETPortal")]
[assembly: AssemblyDescription("CET Portal application directory")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DIB")]
[assembly: AssemblyProduct("CETPortal")]
[assembly: AssemblyCopyright("Copyright © DIB 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("9e16901c-5672-4959-baf8-132433cef9c7")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]