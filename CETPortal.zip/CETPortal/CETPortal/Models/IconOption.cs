namespace CETPortal.Models
{
    public class IconOption
    {
        public string IconClass { get; set; }
        public string Label { get; set; }
    }
}