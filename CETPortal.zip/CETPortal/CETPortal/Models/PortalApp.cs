namespace CETPortal.Models
{
    public class PortalApp
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Url { get; set; }
        public string IconClass { get; set; }
        public string Keywords { get; set; }
        public bool IsActive { get; set; }
        public int SortOrder { get; set; }
    }
}