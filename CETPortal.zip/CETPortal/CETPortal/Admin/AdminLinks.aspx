<%@ Page Title="Admin Console" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="AdminLinks.aspx.cs" Inherits="CETPortal.Admin.AdminLinks" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <section class="panel-soft">
        <h2>Admin Console</h2>
        <p>Manage app links, keywords, and icon relevancy. Search by description and open matched application directly.</p>

        <asp:Label ID="lblMessage" runat="server" Visible="false" CssClass="alert" EnableViewState="false"></asp:Label>

        <h3>Search And Launch</h3>
        <div class="search-row">
            <asp:TextBox ID="txtAdminSearch" runat="server" CssClass="form-control" placeholder="Search by description, app name or keyword"></asp:TextBox>
            <asp:Button ID="btnAdminSearch" runat="server" CssClass="btn btn-primary" Text="Search" OnClick="btnAdminSearch_Click" />
            <asp:Button ID="btnAdminReset" runat="server" CssClass="btn btn-default" Text="Reset" OnClick="btnAdminReset_Click" />
            <asp:Button ID="btnOpenFirst" runat="server" CssClass="btn btn-info" Text="Find And Open First Match" OnClick="btnOpenFirst_Click" />
        </div>

        <asp:GridView ID="gvApps" runat="server" CssClass="table table-striped table-bordered" AutoGenerateColumns="false" OnRowCommand="gvApps_RowCommand" DataKeyNames="Id">
            <Columns>
                <asp:TemplateField HeaderText="Icon">
                    <ItemTemplate>
                        <i class='fa <%# Eval("IconClass") %>'></i>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="Name" HeaderText="Application" />
                <asp:BoundField DataField="Description" HeaderText="Description" />
                <asp:BoundField DataField="Keywords" HeaderText="Keywords" />
                <asp:TemplateField HeaderText="Actions">
                    <ItemTemplate>
                        <asp:LinkButton ID="btnOpen" runat="server" CommandName="OpenApp" CommandArgument='<%# Eval("Url") %>' CssClass="btn btn-xs btn-info">Open</asp:LinkButton>
                        <asp:LinkButton ID="btnDelete" runat="server" CommandName="DeleteApp" CommandArgument='<%# Eval("Id") %>' CssClass="btn btn-xs btn-danger" OnClientClick="return confirm('Delete this app link?');">Delete</asp:LinkButton>
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </section>

    <section class="panel-soft" style="margin-top: 16px;">
        <h3>Create New Link</h3>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Application Name</label>
                    <asp:TextBox ID="txtName" runat="server" CssClass="form-control"></asp:TextBox>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <asp:TextBox ID="txtDescription" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="3"></asp:TextBox>
                </div>
                <div class="form-group">
                    <label>Application URL</label>
                    <asp:TextBox ID="txtUrl" runat="server" CssClass="form-control" placeholder="https://..."></asp:TextBox>
                </div>
                <div class="form-group">
                    <label>Keywords (comma separated)</label>
                    <asp:TextBox ID="txtKeywords" runat="server" CssClass="form-control" placeholder="finance, tracker, simulator"></asp:TextBox>
                </div>
                <div class="form-group">
                    <label>Sort Order</label>
                    <asp:TextBox ID="txtSortOrder" runat="server" CssClass="form-control" Text="100"></asp:TextBox>
                </div>
                <div class="checkbox">
                    <label>
                        <asp:CheckBox ID="chkIsActive" runat="server" Checked="true" /> Active
                    </label>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Selected Icon Class</label>
                    <asp:TextBox ID="txtIconClass" runat="server" CssClass="form-control" Text="fa-th-large"></asp:TextBox>
                    <p style="margin-top: 8px;">Preview: <span class="icon-preview"><i id="selectedIconPreview" class="fa fa-th-large"></i></span></p>
                </div>
                <div class="form-group">
                    <asp:Button ID="btnSuggest" runat="server" CssClass="btn btn-default" Text="Suggest Icons" OnClick="btnSuggest_Click" />
                </div>
                <label>Suggested Icons</label>
                <asp:Repeater ID="rptSuggestedIcons" runat="server" OnItemCommand="rptSuggestedIcons_ItemCommand">
                    <HeaderTemplate><div class="icon-list"></HeaderTemplate>
                    <ItemTemplate>
                        <asp:LinkButton ID="btnIcon" runat="server" CommandName="SelectIcon" CommandArgument='<%# Eval("IconClass") %>' CssClass="icon-btn">
                            <i class='fa <%# Eval("IconClass") %>'></i>
                            <%# Eval("Label") %>
                        </asp:LinkButton>
                    </ItemTemplate>
                    <FooterTemplate></div></FooterTemplate>
                </asp:Repeater>

                <label style="margin-top: 12px; display: block;">Full Icon Catalog</label>
                <asp:Repeater ID="rptCatalog" runat="server" OnItemCommand="rptSuggestedIcons_ItemCommand">
                    <HeaderTemplate><div class="icon-list"></HeaderTemplate>
                    <ItemTemplate>
                        <asp:LinkButton ID="btnIconCatalog" runat="server" CommandName="SelectIcon" CommandArgument='<%# Eval("IconClass") %>' CssClass="icon-btn">
                            <i class='fa <%# Eval("IconClass") %>'></i>
                            <%# Eval("Label") %>
                        </asp:LinkButton>
                    </ItemTemplate>
                    <FooterTemplate></div></FooterTemplate>
                </asp:Repeater>
            </div>
        </div>

        <asp:Button ID="btnAddApp" runat="server" CssClass="btn btn-success" Text="Create Link" OnClick="btnAddApp_Click" />
    </section>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ScriptContent" runat="server">
    <script type="text/javascript">
        (function () {
            var iconInput = document.getElementById('<%= txtIconClass.ClientID %>');
            var iconPreview = document.getElementById('selectedIconPreview');

            if (!iconInput || !iconPreview) {
                return;
            }

            var syncPreview = function () {
                iconPreview.className = 'fa ' + iconInput.value;
            };

            iconInput.onkeyup = syncPreview;
            iconInput.onchange = syncPreview;
            syncPreview();
        })();
    </script>
</asp:Content>