using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CETPortal.Models;
using CETPortal.Services;

namespace CETPortal.Admin
{
    public partial class AdminLinks : Page
    {
        private readonly AppRepository _repository = new AppRepository();
        private readonly IconSuggestionService _icons = new IconSuggestionService();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindApps();
                BindIconCatalog();
                BindSuggestedIcons();
            }
        }

        protected void btnAdminSearch_Click(object sender, EventArgs e)
        {
            BindApps();
        }

        protected void btnAdminReset_Click(object sender, EventArgs e)
        {
            txtAdminSearch.Text = string.Empty;
            BindApps();
            ShowMessage("Filter reset. Showing all applications.", "alert-info");
        }

        protected void btnOpenFirst_Click(object sender, EventArgs e)
        {
            PortalApp app = _repository.FindFirstMatchingApp(txtAdminSearch.Text.Trim(), true);
            if (app == null)
            {
                ShowMessage("No matching application found.", "alert-warning");
                return;
            }

            Response.Redirect(app.Url, false);
            Context.ApplicationInstance.CompleteRequest();
        }

        protected void btnSuggest_Click(object sender, EventArgs e)
        {
            BindSuggestedIcons();
            ShowMessage("Icon suggestions refreshed from app title, description, and URL.", "alert-info");
        }

        protected void rptSuggestedIcons_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName != "SelectIcon")
            {
                return;
            }

            txtIconClass.Text = Convert.ToString(e.CommandArgument);
            ShowMessage("Icon selected: " + txtIconClass.Text, "alert-success");
        }

        protected void btnAddApp_Click(object sender, EventArgs e)
        {
            if (!ValidateForm())
            {
                return;
            }

            int sortOrder;
            if (!int.TryParse(txtSortOrder.Text.Trim(), out sortOrder))
            {
                sortOrder = 100;
            }

            PortalApp app = new PortalApp
            {
                Name = txtName.Text.Trim(),
                Description = txtDescription.Text.Trim(),
                Url = txtUrl.Text.Trim(),
                Keywords = txtKeywords.Text.Trim(),
                IconClass = txtIconClass.Text.Trim(),
                IsActive = chkIsActive.Checked,
                SortOrder = sortOrder
            };

            _repository.AddApp(app);
            ClearForm();
            BindApps();
            ShowMessage("Application link created successfully.", "alert-success");
        }

        protected void gvApps_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteApp")
            {
                int appId;
                if (int.TryParse(Convert.ToString(e.CommandArgument), out appId))
                {
                    _repository.DeleteApp(appId);
                    BindApps();
                    ShowMessage("Application deleted.", "alert-success");
                }

                return;
            }

            if (e.CommandName == "OpenApp")
            {
                string url = Convert.ToString(e.CommandArgument);
                if (!string.IsNullOrWhiteSpace(url))
                {
                    Response.Redirect(url, false);
                    Context.ApplicationInstance.CompleteRequest();
                }
            }
        }

        private void BindApps()
        {
            IList<PortalApp> apps = _repository.GetApps(txtAdminSearch.Text.Trim(), string.Empty, true);
            gvApps.DataSource = apps;
            gvApps.DataBind();
        }

        private void BindIconCatalog()
        {
            rptCatalog.DataSource = _icons.GetCatalog();
            rptCatalog.DataBind();
        }

        private void BindSuggestedIcons()
        {
            rptSuggestedIcons.DataSource = _icons.SuggestIcons(txtName.Text, txtDescription.Text, txtUrl.Text, 6);
            rptSuggestedIcons.DataBind();
        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtDescription.Text) || string.IsNullOrWhiteSpace(txtUrl.Text))
            {
                ShowMessage("Name, description and URL are required.", "alert-danger");
                return false;
            }

            Uri uri;
            if (!Uri.TryCreate(txtUrl.Text.Trim(), UriKind.Absolute, out uri))
            {
                ShowMessage("Please enter a valid absolute URL.", "alert-danger");
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtIconClass.Text))
            {
                txtIconClass.Text = "fa-th-large";
            }

            return true;
        }

        private void ClearForm()
        {
            txtName.Text = string.Empty;
            txtDescription.Text = string.Empty;
            txtUrl.Text = string.Empty;
            txtKeywords.Text = string.Empty;
            txtSortOrder.Text = "100";
            txtIconClass.Text = "fa-th-large";
            chkIsActive.Checked = true;
            BindSuggestedIcons();
        }

        private void ShowMessage(string text, string cssClass)
        {
            lblMessage.Visible = true;
            lblMessage.Text = HttpUtility.HtmlEncode(text);
            lblMessage.CssClass = "alert " + cssClass;
        }
    }
}