/*
    CET Portal database script for SQL Server 2012+
*/

IF DB_ID('CETPortalDb') IS NULL
BEGIN
    CREATE DATABASE CETPortalDb;
END
GO

USE CETPortalDb;
GO

IF OBJECT_ID('dbo.AppKeywords', 'U') IS NOT NULL
    DROP TABLE dbo.AppKeywords;
GO

IF OBJECT_ID('dbo.PortalApps', 'U') IS NOT NULL
    DROP TABLE dbo.PortalApps;
GO

CREATE TABLE dbo.PortalApps
(
    AppId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    AppName NVARCHAR(120) NOT NULL,
    AppDescription NVARCHAR(500) NOT NULL,
    TargetUrl NVARCHAR(500) NOT NULL,
    IconClass NVARCHAR(80) NOT NULL CONSTRAINT DF_PortalApps_IconClass DEFAULT ('fa-th-large'),
    IsActive BIT NOT NULL CONSTRAINT DF_PortalApps_IsActive DEFAULT (1),
    SortOrder INT NOT NULL CONSTRAINT DF_PortalApps_SortOrder DEFAULT (100),
    CreatedOn DATETIME NOT NULL CONSTRAINT DF_PortalApps_CreatedOn DEFAULT (GETDATE())
);
GO

CREATE TABLE dbo.AppKeywords
(
    KeywordId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    AppId INT NOT NULL,
    Keyword NVARCHAR(100) NOT NULL,
    CONSTRAINT FK_AppKeywords_PortalApps FOREIGN KEY (AppId)
        REFERENCES dbo.PortalApps(AppId)
        ON DELETE CASCADE
);
GO

INSERT INTO dbo.PortalApps (AppName, AppDescription, TargetUrl, IconClass, IsActive, SortOrder)
VALUES
('Finance Tracker', 'Track finance utilization, budgets, and treasury activities.', 'https://finance.example.local/', 'fa-money', 1, 10),
('AECB Simulator', 'Simulate AECB scenarios for internal analysis and readiness checks.', 'https://aecb.example.local/', 'fa-cogs', 1, 20),
('Portfolio Management', 'Manage portfolio allocations, performance and product mix.', 'https://portfolio.example.local/', 'fa-sitemap', 1, 30);
GO

INSERT INTO dbo.AppKeywords (AppId, Keyword)
SELECT AppId, Keyword
FROM
(
    SELECT AppId, 'finance' AS Keyword FROM dbo.PortalApps WHERE AppName = 'Finance Tracker'
    UNION ALL SELECT AppId, 'tracker' FROM dbo.PortalApps WHERE AppName = 'Finance Tracker'
    UNION ALL SELECT AppId, 'treasury' FROM dbo.PortalApps WHERE AppName = 'Finance Tracker'
    UNION ALL SELECT AppId, 'aecb' FROM dbo.PortalApps WHERE AppName = 'AECB Simulator'
    UNION ALL SELECT AppId, 'simulator' FROM dbo.PortalApps WHERE AppName = 'AECB Simulator'
    UNION ALL SELECT AppId, 'compliance' FROM dbo.PortalApps WHERE AppName = 'AECB Simulator'
    UNION ALL SELECT AppId, 'portfolio' FROM dbo.PortalApps WHERE AppName = 'Portfolio Management'
    UNION ALL SELECT AppId, 'allocation' FROM dbo.PortalApps WHERE AppName = 'Portfolio Management'
    UNION ALL SELECT AppId, 'investment' FROM dbo.PortalApps WHERE AppName = 'Portfolio Management'
) AS seed;
GO

CREATE INDEX IX_AppKeywords_AppId ON dbo.AppKeywords (AppId);
CREATE INDEX IX_AppKeywords_Keyword ON dbo.AppKeywords (Keyword);
GO