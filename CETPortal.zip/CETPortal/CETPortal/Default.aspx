<%@ Page Title="CET Portal" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="CETPortal._Default" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <section class="panel-soft">
        <h2>Application Directory</h2>
        <p>All applications are visible by default. Use keyword or description search to narrow down.</p>

        <div class="search-row">
            <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" placeholder="Search by app name, description or keyword"></asp:TextBox>
            <asp:Button ID="btnSearch" runat="server" CssClass="btn btn-primary" Text="Search" OnClick="btnSearch_Click" />
            <asp:Button ID="btnReset" runat="server" CssClass="btn btn-default" Text="Reset" OnClick="btnReset_Click" />
        </div>

        <asp:Panel ID="pnlEmpty" runat="server" Visible="false" CssClass="alert alert-warning">
            No applications matched your filter.
        </asp:Panel>

        <asp:Repeater ID="rptApps" runat="server">
            <HeaderTemplate>
                <div class="apps-grid">
            </HeaderTemplate>
            <ItemTemplate>
                <div class="app-card">
                    <div class="app-top">
                        <span class="app-icon"><i class='fa <%# ResolveIconClass(Eval("IconClass")) %>'></i></span>
                        <h3 class="app-title"><%# Eval("Name") %></h3>
                    </div>
                    <p class="app-desc"><%# Eval("Description") %></p>
                    <div>
                        <%# RenderKeywordChips(Eval("Keywords")) %>
                    </div>
                    <div style="margin-top: 10px;">
                        <a href='<%# Eval("Url") %>' class="btn btn-info btn-sm" target="_blank">Open Application</a>
                    </div>
                </div>
            </ItemTemplate>
            <FooterTemplate>
                </div>
            </FooterTemplate>
        </asp:Repeater>
    </section>
</asp:Content>
