using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using CETPortal.Models;
using CETPortal.Services;

namespace CETPortal
{
    public partial class _Default : Page
    {
        private readonly AppRepository _repository = new AppRepository();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtSearch.Text = Request.QueryString["q"] ?? string.Empty;
                BindApps();
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindApps();
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtSearch.Text = string.Empty;
            BindApps();
        }

        private void BindApps()
        {
            IList<PortalApp> apps = _repository.GetApps(txtSearch.Text.Trim(), string.Empty, false);
            pnlEmpty.Visible = apps.Count == 0;
            rptApps.DataSource = apps;
            rptApps.DataBind();
        }

        protected string ResolveIconClass(object iconClass)
        {
            string value = Convert.ToString(iconClass);
            return string.IsNullOrWhiteSpace(value) ? "fa-th-large" : HttpUtility.HtmlEncode(value);
        }

        protected string RenderKeywordChips(object keywordCsv)
        {
            string csv = Convert.ToString(keywordCsv);
            if (string.IsNullOrWhiteSpace(csv))
            {
                return "";
            }

            StringBuilder builder = new StringBuilder();
            string[] items = csv.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string item in items.Take(4))
            {
                string safe = HttpUtility.HtmlEncode(item.Trim());
                builder.Append("<span class='keyword-chip'>");
                builder.Append(safe);
                builder.Append("</span>");
            }

            return builder.ToString();
        }
    }
}