# CET Portal (ASP.NET 4.5, VS2012 Compatible)

CET Portal is an **ASP.NET Web Forms** portal (C#, .NET Framework 4.5) with SQL Server-backed link management.

## What Is Included

- Anonymous landing page that shows **all apps by default**
- Search by app name, description, or keyword
- App-style tile UI with Bootstrap + Font Awesome icons
- Admin console for:
  - Searching links by description and opening matched app
  - Creating and deleting app links
  - Assigning keywords for filtering
  - Icon suggestion engine based on app name/description/url
- Windows-authenticated admin path (`/Admin`)

## Project Structure

- `CETPortal.sln` - Visual Studio 2012 solution
- `CETPortal/CETPortal.csproj` - .NET Framework 4.5 Web Application
- `CETPortal/Default.aspx` - Anonymous app catalog
- `CETPortal/Admin/AdminLinks.aspx` - Windows-authenticated admin module
- `CETPortal/Services/AppRepository.cs` - SQL data access
- `CETPortal/Services/IconSuggestionService.cs` - icon recommendation logic
- `CETPortal/Database/CETPortal.sql` - DB schema + seed data

## Prerequisites

1. Windows machine
2. Visual Studio 2012 (or later that can load .NET 4.5 projects)
3. SQL Server 2012+ (or LocalDB v11.0)
4. .NET Framework 4.5 targeting pack

## Setup Steps

1. Open solution:
   - Open `CETPortal.sln` in Visual Studio.
2. Create database:
   - Open `CETPortal/Database/CETPortal.sql`.
   - Execute script in SQL Server Management Studio.
3. Verify connection string in `CETPortal/Web.config`:
   - Default: `Data Source=(localdb)\v11.0;Initial Catalog=CETPortalDb;Integrated Security=True`
   - If you use SQL Server instance, update `Data Source` accordingly (example: `SERVERNAME\SQL2012`).
4. Build and run:
   - Set `CETPortal` as startup project.
   - Press `F5`.

## Authentication Configuration (Important)

The site is designed for:
- Public/anonymous access to `/Default.aspx`
- Windows-authenticated access to `/Admin/AdminLinks.aspx`

### In IIS (recommended for real use)

1. Publish or host the site in IIS.
2. Open site authentication settings.
3. Enable:
   - Anonymous Authentication
   - Windows Authentication
4. Keep `Web.config` as delivered:
   - `/Admin` path denies anonymous users, which triggers Windows login challenge.

### IIS Express note

If your local profile does not challenge correctly, run under Local IIS instead of IIS Express for strict Windows auth behavior.

## How To Use

1. Browse to home page:
   - All apps are displayed (Finance Tracker, AECB Simulator, Portfolio Management seed data).
2. Search apps:
   - Use search box to filter by description, app name, or keywords.
3. Open admin console:
   - Click **Admin Console**.
   - Browser prompts Windows credentials if not already authenticated.
4. Add a new app link:
   - Enter name, description, URL, keywords.
   - Click **Suggest Icons** to get relevant icon options.
   - Select icon, then click **Create Link**.
5. Search-and-open workflow:
   - In admin search box, enter description/keyword.
   - Click **Find And Open First Match**.

## Branding Notes

- UI uses a DIB-inspired color style (blue/gold accents) for branding direction.
- Replace text/logo assets in `CETPortal/Site.Master` and styling in `CETPortal/Content/site.css` as needed for your official brand kit.

## Extending For Your Final Keyword Matrix

When you provide complete keyword mappings, update:

- Seed data in `CETPortal/Database/CETPortal.sql`
- Icon token rules in `CETPortal/Services/IconSuggestionService.cs`

This allows icon suggestions and filtering to exactly match your business taxonomy.
