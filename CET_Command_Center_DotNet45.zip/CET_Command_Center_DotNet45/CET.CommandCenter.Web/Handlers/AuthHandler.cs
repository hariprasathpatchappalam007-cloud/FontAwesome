using System;
using System.Web;
using System.Web.SessionState;
using CET.CommandCenter.Web.Infrastructure;
using CET.CommandCenter.Web.Security;

namespace CET.CommandCenter.Web.Handlers
{
    public sealed class AuthHandler : IHttpHandler, IRequiresSessionState
    {
        public bool IsReusable { get { return false; } }

        public void ProcessRequest(HttpContext context)
        {
            try
            {
                var path = Convert.ToString(context.Request.RequestContext.RouteData.Values["path"] ?? string.Empty).Trim('/').ToLowerInvariant();
                if (path == "login" && context.Request.HttpMethod == "GET")
                {
                    if (PortalSecurity.AuthMode == "demo") PortalSecurity.LoginDemo(context);
                    else if (PortalSecurity.AuthMode == "windows") PortalSecurity.LoginWindows(context);
                    else throw new ApiException(500, "AUTH_CONFIGURATION_ERROR", "AuthMode must be Demo or Windows.");
                    context.Response.Redirect(AppPaths.Resolve(context.Request), false);
                    context.ApplicationInstance.CompleteRequest();
                    return;
                }

                if (path == "callback" && context.Request.HttpMethod == "GET")
                {
                    context.Response.Redirect(AppPaths.Resolve(context.Request), false);
                    context.ApplicationInstance.CompleteRequest();
                    return;
                }

                if (path == "logout" && context.Request.HttpMethod == "POST")
                {
                    PortalSecurity.Logout(context);
                    JsonHttp.Write(context, JsonHttp.Object("redirectUrl", AppPaths.Resolve(context.Request)), 200);
                    return;
                }

                JsonHttp.WriteError(context, 404, "NOT_FOUND", "Authentication endpoint not found.");
            }
            catch (ApiException error)
            {
                JsonHttp.WriteError(context, error.StatusCode, error.Code, error.Message, error.Details);
            }
            catch (Exception error)
            {
                context.Trace.Warn("Authentication", error.Message, error);
                JsonHttp.WriteError(context, 500, "INTERNAL_ERROR", "An unexpected error occurred.");
            }
        }
    }
}