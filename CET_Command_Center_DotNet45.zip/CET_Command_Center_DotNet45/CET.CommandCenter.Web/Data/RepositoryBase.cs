using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using CET.CommandCenter.Web.Infrastructure;

namespace CET.CommandCenter.Web.Data
{
    public abstract class RepositoryBase
    {
        protected RepositoryBase(SqlStore store)
        {
            Store = store;
        }

        protected SqlStore Store { get; private set; }

        protected static IDictionary<string, object> Normalize(
            IDictionary<string, object> payload,
            IEnumerable<string> allowedFields,
            IEnumerable<string> integerFields,
            IEnumerable<string> booleanFields)
        {
            var integers = new HashSet<string>(integerFields ?? new string[0], StringComparer.OrdinalIgnoreCase);
            var booleans = new HashSet<string>(booleanFields ?? new string[0], StringComparer.OrdinalIgnoreCase);
            var record = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            foreach (var field in allowedFields)
            {
                if (!payload.ContainsKey(field)) continue;
                var value = payload[field];
                if (value is string)
                {
                    value = ((string)value).Trim();
                    if (((string)value).Length == 0) value = null;
                }
                if (value != null && integers.Contains(field))
                {
                    int converted;
                    value = int.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), NumberStyles.Integer, CultureInfo.InvariantCulture, out converted)
                        ? (object)converted
                        : null;
                }
                if (value != null && booleans.Contains(field)) value = ToBoolean(value);
                record[field] = value;
            }
            return record;
        }

        protected static int Insert(SqlConnection connection, SqlTransaction transaction, string table, IDictionary<string, object> record)
        {
            var columns = record.Keys.ToList();
            var sql = string.Format(
                CultureInfo.InvariantCulture,
                "INSERT INTO [{0}] ({1}) OUTPUT INSERTED.id VALUES ({2})",
                table,
                string.Join(",", columns.Select(column => "[" + column + "]")),
                string.Join(",", columns.Select((column, index) => "@v" + index)));
            var parameters = columns.Select((column, index) => SqlStore.Parameter("@v" + index, record[column])).ToArray();
            using (var command = SqlStore.CreateCommand(connection, transaction, sql, parameters))
            {
                return Convert.ToInt32(command.ExecuteScalar(), CultureInfo.InvariantCulture);
            }
        }

        protected static int Update(SqlConnection connection, SqlTransaction transaction, string table, int id, IDictionary<string, object> record)
        {
            if (record.Count == 0) return 0;
            var columns = record.Keys.ToList();
            var assignments = string.Join(",", columns.Select((column, index) => "[" + column + "]=@v" + index));
            var parameters = columns.Select((column, index) => SqlStore.Parameter("@v" + index, record[column])).ToList();
            parameters.Add(SqlStore.Parameter("@id", id));
            using (var command = SqlStore.CreateCommand(connection, transaction,
                string.Format(CultureInfo.InvariantCulture, "UPDATE [{0}] SET {1} WHERE id=@id", table, assignments), parameters.ToArray()))
            {
                return command.ExecuteNonQuery();
            }
        }

        protected static void Audit(
            SqlConnection connection,
            SqlTransaction transaction,
            string actorEmail,
            string action,
            string entityType,
            object entityId,
            object details)
        {
            const string sql = @"INSERT INTO audit_logs (actor_email, action, entity_type, entity_id, details, created_at)
VALUES (@actor_email, @action, @entity_type, @entity_id, @details, SYSUTCDATETIME())";
            using (var command = SqlStore.CreateCommand(connection, transaction, sql,
                SqlStore.Parameter("@actor_email", actorEmail),
                SqlStore.Parameter("@action", action),
                SqlStore.Parameter("@entity_type", entityType),
                SqlStore.Parameter("@entity_id", Convert.ToString(entityId, CultureInfo.InvariantCulture)),
                SqlStore.Parameter("@details", new JavaScriptSerializer().Serialize(details))))
            {
                command.ExecuteNonQuery();
            }
        }

        protected static string AddInParameters(ICollection<SqlParameter> parameters, IEnumerable<int> values, string prefix)
        {
            var names = new List<string>();
            var index = 0;
            foreach (var value in values.Distinct())
            {
                var name = "@" + prefix + index++;
                names.Add(name);
                parameters.Add(SqlStore.Parameter(name, value));
            }
            return names.Count == 0 ? "NULL" : string.Join(",", names);
        }

        protected static IList<int> CollectDescendants(int managerId, IEnumerable<IDictionary<string, object>> people)
        {
            var descendants = new List<int>();
            var queue = new Queue<int>();
            queue.Enqueue(managerId);
            while (queue.Count > 0)
            {
                var parentId = queue.Dequeue();
                foreach (var person in people)
                {
                    var id = RowInt(person, "id");
                    var candidateParent = RowNullableInt(person, "manager_id");
                    if (!candidateParent.HasValue || candidateParent.Value != parentId || id == managerId || descendants.Contains(id)) continue;
                    descendants.Add(id);
                    queue.Enqueue(id);
                }
            }
            return descendants;
        }

        protected static int RowInt(IDictionary<string, object> row, string key)
        {
            object value;
            return row != null && row.TryGetValue(key, out value) && value != null
                ? Convert.ToInt32(value, CultureInfo.InvariantCulture)
                : 0;
        }

        protected static int? RowNullableInt(IDictionary<string, object> row, string key)
        {
            object value;
            return row != null && row.TryGetValue(key, out value) && value != null
                ? (int?)Convert.ToInt32(value, CultureInfo.InvariantCulture)
                : null;
        }

        protected static string RowString(IDictionary<string, object> row, string key)
        {
            object value;
            return row != null && row.TryGetValue(key, out value) && value != null
                ? Convert.ToString(value, CultureInfo.InvariantCulture)
                : null;
        }

        private static bool ToBoolean(object value)
        {
            if (value is bool) return (bool)value;
            var text = Convert.ToString(value, CultureInfo.InvariantCulture);
            return string.Equals(text, "true", StringComparison.OrdinalIgnoreCase)
                || string.Equals(text, "on", StringComparison.OrdinalIgnoreCase)
                || text == "1";
        }
    }
}