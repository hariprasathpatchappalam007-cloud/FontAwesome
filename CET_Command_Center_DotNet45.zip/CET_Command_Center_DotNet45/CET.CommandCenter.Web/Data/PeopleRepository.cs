using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using CET.CommandCenter.Web.Infrastructure;

namespace CET.CommandCenter.Web.Data
{
    public sealed class PeopleRepository : RepositoryBase
    {
        private const string PersonColumns = @"p.id,p.employee_id,p.entra_object_id,p.full_name,p.display_name,p.email,p.phone,
p.designation,p.functional_role,p.employment_type,p.employer,p.grade,p.location,p.cost_center,p.joining_date,p.contract_end_date,
p.gender,p.manager_id,p.vertical_id,p.photo_url,p.profile_summary,p.skills,p.certifications,p.is_vertical_head,p.is_active,
p.created_at,p.updated_at,m.display_name AS manager_name,v.name AS vertical_name,v.color AS vertical_color";

        private static readonly string[] PersonFields =
        {
            "employee_id", "entra_object_id", "full_name", "display_name", "email", "phone", "designation",
            "functional_role", "employment_type", "employer", "grade", "location", "cost_center", "joining_date", "gender",
            "contract_end_date", "manager_id", "vertical_id", "photo_url", "profile_summary", "skills", "certifications",
            "is_vertical_head", "is_active"
        };

        public PeopleRepository(SqlStore store) : base(store)
        {
        }

        public IList<IDictionary<string, object>> List(string search, int? verticalId, string employmentType, bool? active)
        {
            var sql = new System.Text.StringBuilder(BaseQuery()).Append(" WHERE 1=1");
            var parameters = new List<SqlParameter>();
            if (!string.IsNullOrWhiteSpace(search))
            {
                sql.Append(" AND (p.full_name LIKE @search OR p.employee_id LIKE @search OR p.email LIKE @search OR p.designation LIKE @search)");
                parameters.Add(SqlStore.Parameter("@search", "%" + search.Trim() + "%"));
            }
            if (verticalId.HasValue)
            {
                sql.Append(" AND p.vertical_id=@vertical_id");
                parameters.Add(SqlStore.Parameter("@vertical_id", verticalId.Value));
            }
            if (!string.IsNullOrWhiteSpace(employmentType))
            {
                sql.Append(" AND p.employment_type=@employment_type");
                parameters.Add(SqlStore.Parameter("@employment_type", employmentType));
            }
            if (active.HasValue)
            {
                sql.Append(" AND p.is_active=@is_active");
                parameters.Add(SqlStore.Parameter("@is_active", active.Value));
            }
            sql.Append(" ORDER BY p.display_name");
            return Store.Query(sql.ToString(), parameters.ToArray());
        }

        public IDictionary<string, object> GetById(int id)
        {
            var person = Store.QueryOne(BaseQuery() + " WHERE p.id=@id", SqlStore.Parameter("@id", id));
            if (person == null) return null;
            person["portfolios"] = Store.Query("SELECT id,name,code,status FROM portfolios WHERE owner_person_id=@id ORDER BY name", SqlStore.Parameter("@id", id));
            person["programs"] = Store.Query("SELECT id,name,code,status FROM programs WHERE owner_person_id=@id ORDER BY name", SqlStore.Parameter("@id", id));
            person["squads"] = Store.Query(@"SELECT s.id,s.name,s.code,s.status,sm.role,sm.is_primary FROM squad_members sm
INNER JOIN squads s ON sm.squad_id=s.id WHERE sm.person_id=@id ORDER BY s.name", SqlStore.Parameter("@id", id));
            return person;
        }

        public IDictionary<string, object> Create(IDictionary<string, object> payload, string actorEmail)
        {
            var record = PersonRecord(payload);
            if (!record.ContainsKey("display_name") || record["display_name"] == null) record["display_name"] = record["full_name"];
            if (record.ContainsKey("manager_id")) record["is_vertical_head"] = record["manager_id"] == null;
            if (!record.ContainsKey("is_active")) record["is_active"] = true;
            if (!record.ContainsKey("is_vertical_head")) record["is_vertical_head"] = false;
            record["created_by"] = actorEmail;
            record["updated_by"] = actorEmail;
            record["created_at"] = DateTime.UtcNow;
            record["updated_at"] = DateTime.UtcNow;
            var id = Store.Transaction((connection, transaction) =>
            {
                var savedId = Insert(connection, transaction, "people", record);
                Audit(connection, transaction, actorEmail, "CREATE", "person", savedId,
                    JsonHttp.Object("employee_id", record["employee_id"], "full_name", record["full_name"]));
                return savedId;
            });
            return GetById(id);
        }

        public IDictionary<string, object> UpdatePerson(int id, IDictionary<string, object> payload, string actorEmail)
        {
            var record = PersonRecord(payload);
            if (record.ContainsKey("manager_id")) record["is_vertical_head"] = record["manager_id"] == null;
            record["updated_by"] = actorEmail;
            record["updated_at"] = DateTime.UtcNow;
            var updated = Store.Transaction((connection, transaction) =>
            {
                var count = Update(connection, transaction, "people", id, record);
                if (count == 0) return false;
                Audit(connection, transaction, actorEmail, "UPDATE", "person", id,
                    JsonHttp.Object("changed_fields", record.Keys.ToList()));
                return true;
            });
            return updated ? GetById(id) : null;
        }

        public IList<IDictionary<string, object>> Organization()
        {
            var people = List(null, null, null, true);
            var byId = new Dictionary<int, IDictionary<string, object>>();
            foreach (var person in people)
            {
                person["children"] = new List<IDictionary<string, object>>();
                byId[RowInt(person, "id")] = person;
            }
            var roots = new List<IDictionary<string, object>>();
            foreach (var person in people)
            {
                var managerId = RowNullableInt(person, "manager_id");
                IDictionary<string, object> manager;
                if (managerId.HasValue && managerId.Value != RowInt(person, "id") && byId.TryGetValue(managerId.Value, out manager))
                {
                    ((IList<IDictionary<string, object>>)manager["children"]).Add(person);
                }
                else roots.Add(person);
            }
            return roots;
        }

        public IList<IDictionary<string, object>> ActiveUnits()
        {
            return Store.Query("SELECT * FROM verticals WHERE is_active=1 ORDER BY name");
        }

        public IDictionary<string, object> Stats()
        {
            return Store.QueryOne(@"SELECT
(SELECT COUNT(*) FROM people WHERE is_active=1) AS people,
(SELECT COUNT(*) FROM people WHERE is_active=1 AND employment_type='Staff') AS staff,
(SELECT COUNT(*) FROM people WHERE is_active=1 AND employment_type='Consultant') AS consultants,
(SELECT COUNT(*) FROM verticals WHERE is_active=1) AS verticals,
(SELECT COUNT(*) FROM platforms WHERE is_active=1) AS platforms,
(SELECT COUNT(*) FROM portfolios WHERE status='Active') AS portfolios,
(SELECT COUNT(*) FROM demands WHERE is_active=1) AS demands,
(SELECT COUNT(*) FROM programs WHERE status='In Progress') AS programs,
(SELECT COUNT(*) FROM squads WHERE status='Active') AS squads");
        }

        public IList<IDictionary<string, object>> DashboardOwnership()
        {
            var leaders = Store.Query(BaseQuery() + @" WHERE p.is_active=1 AND p.manager_id IN
(SELECT id FROM people WHERE manager_id IS NULL AND is_active=1) ORDER BY p.display_name");
            foreach (var leader in leaders)
            {
                var id = RowInt(leader, "id");
                leader["direct_reports"] = Convert.ToInt32(Store.Scalar("SELECT COUNT(*) FROM people WHERE manager_id=@id AND is_active=1", SqlStore.Parameter("@id", id)), CultureInfo.InvariantCulture);
                leader["platforms"] = Store.Query("SELECT id,name,code,status FROM platforms WHERE manager_person_id=@id AND is_active=1 ORDER BY name", SqlStore.Parameter("@id", id));
                leader["portfolios"] = Store.Query("SELECT id,name,code,status FROM portfolios WHERE owner_person_id=@id ORDER BY name", SqlStore.Parameter("@id", id));
                leader["programs"] = Store.Query("SELECT id,name,code,status FROM programs WHERE owner_person_id=@id ORDER BY name", SqlStore.Parameter("@id", id));
                leader["squads"] = Store.Query(@"SELECT id,name,code,status FROM squads WHERE is_active=1
AND (manager_person_id=@id OR lead_person_id=@id) ORDER BY name", SqlStore.Parameter("@id", id));
            }
            return leaders;
        }

        private static string BaseQuery()
        {
            return "SELECT " + PersonColumns + @" FROM people p
LEFT JOIN people m ON p.manager_id=m.id LEFT JOIN verticals v ON p.vertical_id=v.id";
        }

        private static IDictionary<string, object> PersonRecord(IDictionary<string, object> payload)
        {
            return Normalize(payload, PersonFields, new[] { "manager_id", "vertical_id" }, new[] { "is_vertical_head", "is_active" });
        }
    }
}