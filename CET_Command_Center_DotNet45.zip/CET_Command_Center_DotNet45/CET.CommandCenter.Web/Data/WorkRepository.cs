using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using CET.CommandCenter.Web.Infrastructure;

namespace CET.CommandCenter.Web.Data
{
    public sealed class WorkRepository : RepositoryBase
    {
        private static readonly string[] UnitFields = { "name", "code", "description", "color", "is_active" };
        private static readonly string[] PlatformFields = { "name", "code", "description", "category", "vendor", "manager_person_id", "status", "criticality", "is_active" };
        private static readonly string[] PortfolioFields =
        {
            "name", "code", "description", "business_area", "owner_person_id", "vertical_id", "status", "health",
            "start_date", "target_end_date", "strategic_objectives", "is_active"
        };
        private static readonly string[] DemandFields =
        {
            "demand_id", "title", "description", "category", "classification", "priority", "stage", "status",
            "requesting_department", "requestor_name", "owner_person_id", "accountable_manager_id", "portfolio_id",
            "program_id", "squad_id", "planned_start_date", "planned_end_date", "health", "progress_percent", "is_active"
        };

        public WorkRepository(SqlStore store) : base(store)
        {
        }

        public IList<IDictionary<string, object>> ListUnits(bool? active)
        {
            if (!active.HasValue) return Store.Query("SELECT * FROM verticals ORDER BY name");
            return Store.Query("SELECT * FROM verticals WHERE is_active=@active ORDER BY name", SqlStore.Parameter("@active", active.Value));
        }

        public IDictionary<string, object> GetUnit(int id)
        {
            return Store.QueryOne("SELECT * FROM verticals WHERE id=@id", SqlStore.Parameter("@id", id));
        }

        public IDictionary<string, object> SaveUnit(int? id, IDictionary<string, object> payload, string actorEmail)
        {
            var record = Normalize(payload, UnitFields, null, new[] { "is_active" });
            record["code"] = (Convert.ToString(record["code"], CultureInfo.InvariantCulture) ?? string.Empty).ToUpperInvariant();
            if (!record.ContainsKey("color") || record["color"] == null) record["color"] = "#087a59";
            record["updated_at"] = DateTime.UtcNow;
            var savedId = Store.Transaction((connection, transaction) =>
            {
                if (id.HasValue)
                {
                    if (Update(connection, transaction, "verticals", id.Value, record) == 0) return 0;
                    Audit(connection, transaction, actorEmail, "UPDATE", "unit", id.Value,
                        JsonHttp.Object("changed_fields", record.Keys.ToList()));
                    return id.Value;
                }
                record["created_at"] = DateTime.UtcNow;
                if (!record.ContainsKey("is_active")) record["is_active"] = true;
                var createdId = Insert(connection, transaction, "verticals", record);
                Audit(connection, transaction, actorEmail, "CREATE", "unit", createdId,
                    JsonHttp.Object("code", record["code"], "name", record["name"]));
                return createdId;
            });
            return savedId == 0 ? null : GetUnit(savedId);
        }

        public IList<IDictionary<string, object>> ListPlatforms(bool? active, int? managerPersonId, IEnumerable<int> personIds)
        {
            var sql = new StringBuilder("SELECT plt.* FROM platforms plt WHERE 1=1");
            var parameters = new List<SqlParameter>();
            if (active.HasValue)
            {
                sql.Append(" AND plt.is_active=@active");
                parameters.Add(SqlStore.Parameter("@active", active.Value));
            }
            if (managerPersonId.HasValue)
            {
                sql.Append(" AND plt.manager_person_id=@manager_person_id");
                parameters.Add(SqlStore.Parameter("@manager_person_id", managerPersonId.Value));
            }
            var scopedPeople = personIds == null ? new List<int>() : personIds.Distinct().ToList();
            if (scopedPeople.Count > 0)
            {
                var names = AddInParameters(parameters, scopedPeople, "platform_person_");
                sql.Append(" AND EXISTS (SELECT 1 FROM platform_assignments pa WHERE pa.platform_id=plt.id AND pa.person_id IN (").Append(names).Append("))");
            }
            sql.Append(" ORDER BY plt.name");
            var platforms = Store.Query(sql.ToString(), parameters.ToArray());
            foreach (var platform in platforms) platform["assignments"] = PlatformAssignments(RowInt(platform, "id"));
            return platforms;
        }

        public IDictionary<string, object> GetPlatform(int id)
        {
            var platform = Store.QueryOne("SELECT * FROM platforms WHERE id=@id", SqlStore.Parameter("@id", id));
            if (platform != null) platform["assignments"] = PlatformAssignments(id);
            return platform;
        }

        public bool PlatformAssignmentsWithinManager(int managerId, IEnumerable<int> personIds)
        {
            var manager = Store.QueryOne("SELECT id,manager_id FROM people WHERE id=@id AND is_active=1", SqlStore.Parameter("@id", managerId));
            var parentId = RowNullableInt(manager, "manager_id");
            if (manager == null || !parentId.HasValue) return false;
            var parent = Store.QueryOne("SELECT manager_id FROM people WHERE id=@id AND is_active=1", SqlStore.Parameter("@id", parentId.Value));
            if (parent == null || RowNullableInt(parent, "manager_id").HasValue) return false;
            var people = Store.Query("SELECT id,manager_id FROM people WHERE is_active=1");
            var allowed = new HashSet<int>(CollectDescendants(managerId, people));
            allowed.Add(managerId);
            var assignments = personIds == null ? new List<int>() : personIds.Distinct().ToList();
            return assignments.Count > 0 && assignments.All(allowed.Contains);
        }

        public IDictionary<string, object> SavePlatform(int? id, IDictionary<string, object> payload, string actorEmail)
        {
            var record = Normalize(payload, PlatformFields, new[] { "manager_person_id" }, new[] { "is_active" });
            record["code"] = (Convert.ToString(record["code"], CultureInfo.InvariantCulture) ?? string.Empty).ToUpperInvariant();
            record["manager_person_id"] = JsonHttp.Integer(payload, "manager_context_id");
            record["is_active"] = !string.Equals(JsonHttp.String(payload, "status"), "Retired", StringComparison.Ordinal);
            record["updated_by"] = actorEmail;
            record["updated_at"] = DateTime.UtcNow;
            var ownerId = JsonHttp.Integer(payload, "owner_person_id");
            var supporterIds = JsonHttp.IntegerList(payload, "support_person_ids").Distinct().Where(personId => !ownerId.HasValue || personId != ownerId.Value).ToList();
            var savedId = Store.Transaction((connection, transaction) =>
            {
                int platformId;
                if (id.HasValue)
                {
                    if (Update(connection, transaction, "platforms", id.Value, record) == 0) return 0;
                    platformId = id.Value;
                    using (var delete = SqlStore.CreateCommand(connection, transaction, "DELETE FROM platform_assignments WHERE platform_id=@id", SqlStore.Parameter("@id", platformId))) delete.ExecuteNonQuery();
                }
                else
                {
                    record["created_by"] = actorEmail;
                    record["created_at"] = DateTime.UtcNow;
                    platformId = Insert(connection, transaction, "platforms", record);
                }
                if (ownerId.HasValue) InsertPlatformAssignment(connection, transaction, platformId, ownerId.Value, "Owned");
                foreach (var supporterId in supporterIds) InsertPlatformAssignment(connection, transaction, platformId, supporterId, "Supported");
                Audit(connection, transaction, actorEmail, id.HasValue ? "UPDATE" : "CREATE", "platform", platformId,
                    JsonHttp.Object("code", record["code"], "assignment_count", supporterIds.Count + (ownerId.HasValue ? 1 : 0), "manager_context_id", record["manager_person_id"]));
                return platformId;
            });
            return savedId == 0 ? null : GetPlatform(savedId);
        }

        public IList<IDictionary<string, object>> ListPortfolios(string search, string status, string health, int? ownerPersonId, bool? active)
        {
            var sql = new StringBuilder(PortfolioQuery()).Append(" WHERE 1=1");
            var parameters = new List<SqlParameter>();
            if (!string.IsNullOrWhiteSpace(search))
            {
                sql.Append(" AND (pf.name LIKE @search OR pf.code LIKE @search OR pf.business_area LIKE @search)");
                parameters.Add(SqlStore.Parameter("@search", "%" + search.Trim() + "%"));
            }
            AddStringFilter(sql, parameters, "pf.status", "@status", status);
            AddStringFilter(sql, parameters, "pf.health", "@health", health);
            if (ownerPersonId.HasValue)
            {
                sql.Append(" AND pf.owner_person_id=@owner_person_id");
                parameters.Add(SqlStore.Parameter("@owner_person_id", ownerPersonId.Value));
            }
            if (active.HasValue)
            {
                sql.Append(" AND pf.is_active=@active");
                parameters.Add(SqlStore.Parameter("@active", active.Value));
            }
            sql.Append(" ORDER BY pf.name");
            return Store.Query(sql.ToString(), parameters.ToArray());
        }

        public IDictionary<string, object> GetPortfolio(int id)
        {
            var portfolio = Store.QueryOne(PortfolioQuery() + " WHERE pf.id=@id", SqlStore.Parameter("@id", id));
            if (portfolio == null) return null;
            portfolio["demands"] = Store.Query(DemandQuery() + " WHERE d.portfolio_id=@id AND d.is_active=1 ORDER BY d.priority,d.title", SqlStore.Parameter("@id", id));
            portfolio["demand_count"] = RowInt(portfolio, "demand_count");
            return portfolio;
        }

        public IDictionary<string, object> SavePortfolio(int? id, IDictionary<string, object> payload, string actorEmail)
        {
            var record = Normalize(payload, PortfolioFields, new[] { "owner_person_id", "vertical_id" }, new[] { "is_active" });
            record["updated_by"] = actorEmail;
            record["updated_at"] = DateTime.UtcNow;
            var savedId = Store.Transaction((connection, transaction) =>
            {
                if (id.HasValue)
                {
                    if (Update(connection, transaction, "portfolios", id.Value, record) == 0) return 0;
                    Audit(connection, transaction, actorEmail, "UPDATE", "portfolio", id.Value, JsonHttp.Object("changed_fields", record.Keys.ToList()));
                    return id.Value;
                }
                record["created_by"] = actorEmail;
                record["created_at"] = DateTime.UtcNow;
                if (!record.ContainsKey("is_active")) record["is_active"] = true;
                var createdId = Insert(connection, transaction, "portfolios", record);
                Audit(connection, transaction, actorEmail, "CREATE", "portfolio", createdId, JsonHttp.Object("code", record["code"], "name", record["name"]));
                return createdId;
            });
            return savedId == 0 ? null : GetPortfolio(savedId);
        }

        public IList<IDictionary<string, object>> ListDemands(string search, string status, string health, string priority, int? portfolioId, int? ownerPersonId, bool? active)
        {
            var sql = new StringBuilder(DemandQuery()).Append(" WHERE 1=1");
            var parameters = new List<SqlParameter>();
            if (!string.IsNullOrWhiteSpace(search))
            {
                sql.Append(" AND (d.demand_id LIKE @search OR d.title LIKE @search OR d.category LIKE @search)");
                parameters.Add(SqlStore.Parameter("@search", "%" + search.Trim() + "%"));
            }
            AddStringFilter(sql, parameters, "d.status", "@status", status);
            AddStringFilter(sql, parameters, "d.health", "@health", health);
            AddStringFilter(sql, parameters, "d.priority", "@priority", priority);
            if (portfolioId.HasValue)
            {
                sql.Append(" AND d.portfolio_id=@portfolio_id");
                parameters.Add(SqlStore.Parameter("@portfolio_id", portfolioId.Value));
            }
            if (ownerPersonId.HasValue)
            {
                sql.Append(" AND d.owner_person_id=@owner_person_id");
                parameters.Add(SqlStore.Parameter("@owner_person_id", ownerPersonId.Value));
            }
            if (active.HasValue)
            {
                sql.Append(" AND d.is_active=@active");
                parameters.Add(SqlStore.Parameter("@active", active.Value));
            }
            sql.Append(" ORDER BY d.updated_at DESC,d.demand_id");
            return Store.Query(sql.ToString(), parameters.ToArray());
        }

        public IDictionary<string, object> GetDemand(int id)
        {
            return Store.QueryOne(DemandQuery() + " WHERE d.id=@id", SqlStore.Parameter("@id", id));
        }

        public IDictionary<string, object> SaveDemand(int? id, IDictionary<string, object> payload, string actorEmail)
        {
            var record = Normalize(payload, DemandFields,
                new[] { "owner_person_id", "accountable_manager_id", "portfolio_id", "program_id", "squad_id", "progress_percent" },
                new[] { "is_active" });
            record["updated_by"] = actorEmail;
            record["updated_at"] = DateTime.UtcNow;
            var savedId = Store.Transaction((connection, transaction) =>
            {
                if (id.HasValue)
                {
                    if (Update(connection, transaction, "demands", id.Value, record) == 0) return 0;
                    Audit(connection, transaction, actorEmail, "UPDATE", "demand", id.Value, JsonHttp.Object("changed_fields", record.Keys.ToList()));
                    return id.Value;
                }
                record["created_by"] = actorEmail;
                record["created_at"] = DateTime.UtcNow;
                if (!record.ContainsKey("is_active")) record["is_active"] = true;
                var createdId = Insert(connection, transaction, "demands", record);
                Audit(connection, transaction, actorEmail, "CREATE", "demand", createdId, JsonHttp.Object("demand_id", record["demand_id"], "title", record["title"]));
                return createdId;
            });
            return savedId == 0 ? null : GetDemand(savedId);
        }

        public IDictionary<string, object> WorkSummary()
        {
            return Store.QueryOne(@"SELECT
(SELECT COUNT(*) FROM platforms WHERE is_active=1) AS platforms,
(SELECT COUNT(*) FROM portfolios WHERE is_active=1) AS portfolios,
(SELECT COUNT(*) FROM demands WHERE is_active=1) AS demands,
(SELECT COUNT(*) FROM demands WHERE is_active=1 AND health='Green') AS green,
(SELECT COUNT(*) FROM demands WHERE is_active=1 AND health='Amber') AS amber,
(SELECT COUNT(*) FROM demands WHERE is_active=1 AND health='Red') AS red,
(SELECT COUNT(*) FROM demands WHERE is_active=1 AND priority='Critical') AS critical");
        }

        public IList<IDictionary<string, object>> ListPortfolioManagers()
        {
            var managers = Store.Query(ManagerQuery() + @" WHERE p.is_active=1 AND p.manager_id IN
(SELECT id FROM people WHERE manager_id IS NULL AND is_active=1) ORDER BY p.display_name");
            var results = new List<IDictionary<string, object>>();
            foreach (var manager in managers) results.Add(BuildManagerAdministration(manager, false));
            return results;
        }

        public IDictionary<string, object> GetPortfolioManager(int id)
        {
            var manager = Store.QueryOne(ManagerQuery() + " WHERE p.id=@id AND p.is_active=1", SqlStore.Parameter("@id", id));
            if (manager == null) return null;
            var managerParentId = RowNullableInt(manager, "manager_id");
            if (!managerParentId.HasValue) return null;
            var parent = Store.QueryOne("SELECT manager_id FROM people WHERE id=@id", SqlStore.Parameter("@id", managerParentId.Value));
            if (parent == null || RowNullableInt(parent, "manager_id").HasValue) return null;
            return BuildManagerAdministration(manager, true);
        }

        private IDictionary<string, object> BuildManagerAdministration(IDictionary<string, object> manager, bool includeDetails)
        {
            var managerId = RowInt(manager, "id");
            var people = Store.Query(@"SELECT id,employee_id,display_name,designation,employment_type,gender,photo_url,manager_id
FROM people WHERE is_active=1");
            var descendantIds = CollectDescendants(managerId, people).ToList();
            var administrationIds = new List<int> { managerId };
            administrationIds.AddRange(descendantIds);
            var team = people.Where(person => descendantIds.Contains(RowInt(person, "id"))).ToList();
            var directReports = team.Where(person => RowNullableInt(person, "manager_id") == managerId).ToList();
            var portfolios = ListPortfolios(null, null, null, managerId, true);
            var programs = ManagerPrograms(administrationIds);
            var squads = ManagerSquads(managerId, administrationIds);
            var platforms = ListPlatforms(true, managerId, administrationIds);
            var demands = ManagerDemands(managerId, administrationIds, portfolios.Select(portfolio => RowInt(portfolio, "id")));

            manager["workforce"] = JsonHttp.Object(
                "total_resources", team.Count,
                "direct_reports", directReports.Count,
                "staff", team.Count(person => string.Equals(RowString(person, "employment_type"), "Staff", StringComparison.Ordinal)),
                "consultants", team.Count(person => string.Equals(RowString(person, "employment_type"), "Consultant", StringComparison.Ordinal)),
                "male", team.Count(person => string.Equals(RowString(person, "gender"), "Male", StringComparison.Ordinal)),
                "female", team.Count(person => string.Equals(RowString(person, "gender"), "Female", StringComparison.Ordinal)),
                "not_specified", team.Count(person => !string.Equals(RowString(person, "gender"), "Male", StringComparison.Ordinal) && !string.Equals(RowString(person, "gender"), "Female", StringComparison.Ordinal)));
            manager["health"] = JsonHttp.Object(
                "green", demands.Count(demand => string.Equals(RowString(demand, "health"), "Green", StringComparison.Ordinal)),
                "amber", demands.Count(demand => string.Equals(RowString(demand, "health"), "Amber", StringComparison.Ordinal)),
                "red", demands.Count(demand => string.Equals(RowString(demand, "health"), "Red", StringComparison.Ordinal)));
            manager["portfolio_count"] = portfolios.Count;
            manager["platform_count"] = platforms.Count;
            manager["platform_owned_count"] = CountPlatformsByRelationship(platforms, administrationIds, "Owned");
            manager["platform_supported_count"] = CountPlatformsByRelationship(platforms, administrationIds, "Supported");
            manager["demand_count"] = demands.Count;
            manager["program_count"] = programs.Count;
            manager["squad_count"] = squads.Count;
            manager["platforms"] = platforms;
            manager["portfolios"] = includeDetails ? portfolios : portfolios.Select(CompactPortfolio).ToList();
            manager["demands"] = includeDetails ? demands : demands.Take(4).Select(CompactDemand).ToList();
            manager["programs"] = includeDetails ? programs : programs.Select(CompactRecord).ToList();
            manager["squads"] = includeDetails ? squads : squads.Select(CompactRecord).ToList();
            manager["team"] = includeDetails ? team : directReports;
            return manager;
        }

        private IList<IDictionary<string, object>> ManagerPrograms(IList<int> administrationIds)
        {
            var parameters = new List<SqlParameter>();
            var names = AddInParameters(parameters, administrationIds, "program_owner_");
            return Store.Query(@"SELECT prg.*,owner.display_name AS owner_name FROM programs prg
LEFT JOIN people owner ON prg.owner_person_id=owner.id WHERE prg.owner_person_id IN (" + names + ") AND prg.status<>'Archived' ORDER BY prg.name", parameters.ToArray());
        }

        private IList<IDictionary<string, object>> ManagerSquads(int managerId, IList<int> administrationIds)
        {
            var parameters = new List<SqlParameter> { SqlStore.Parameter("@manager_id", managerId) };
            var names = AddInParameters(parameters, administrationIds, "squad_lead_");
            return Store.Query(@"SELECT sq.*,lead.display_name AS lead_name,plt.name AS platform_name,plt.code AS platform_code FROM squads sq
LEFT JOIN people lead ON sq.lead_person_id=lead.id LEFT JOIN platforms plt ON sq.platform_id=plt.id
WHERE (sq.manager_person_id=@manager_id OR sq.lead_person_id IN (" + names + ")) AND sq.status<>'Archived' ORDER BY sq.name", parameters.ToArray());
        }

        private IList<IDictionary<string, object>> ManagerDemands(int managerId, IList<int> administrationIds, IEnumerable<int> portfolioIds)
        {
            var parameters = new List<SqlParameter> { SqlStore.Parameter("@manager_id", managerId) };
            var ownerNames = AddInParameters(parameters, administrationIds, "demand_owner_");
            var portfolios = portfolioIds.Distinct().ToList();
            var condition = "(d.accountable_manager_id=@manager_id OR d.owner_person_id IN (" + ownerNames + ")";
            if (portfolios.Count > 0) condition += " OR d.portfolio_id IN (" + AddInParameters(parameters, portfolios, "demand_portfolio_") + ")";
            condition += ")";
            return Store.Query(DemandQuery() + " WHERE d.is_active=1 AND " + condition + " ORDER BY d.priority,d.demand_id", parameters.ToArray());
        }

        private IList<IDictionary<string, object>> PlatformAssignments(int platformId)
        {
            return Store.Query(@"SELECT pa.id,pa.person_id,pa.relationship,p.display_name,p.designation,p.photo_url
FROM platform_assignments pa INNER JOIN people p ON pa.person_id=p.id WHERE pa.platform_id=@id
ORDER BY CASE WHEN pa.relationship='Owned' THEN 0 ELSE 1 END,p.display_name", SqlStore.Parameter("@id", platformId));
        }

        private static void InsertPlatformAssignment(SqlConnection connection, SqlTransaction transaction, int platformId, int personId, string relationship)
        {
            using (var command = SqlStore.CreateCommand(connection, transaction,
                "INSERT INTO platform_assignments (platform_id,person_id,relationship,created_at,updated_at) VALUES (@platform_id,@person_id,@relationship,SYSUTCDATETIME(),SYSUTCDATETIME())",
                SqlStore.Parameter("@platform_id", platformId), SqlStore.Parameter("@person_id", personId), SqlStore.Parameter("@relationship", relationship)))
            {
                command.ExecuteNonQuery();
            }
        }

        private static string PortfolioQuery()
        {
            return @"SELECT pf.*,owner.display_name AS owner_name,owner.designation AS owner_designation,owner.photo_url AS owner_photo_url,
v.name AS vertical_name,v.color AS vertical_color,
(SELECT COUNT(*) FROM demands d WHERE d.portfolio_id=pf.id AND d.is_active=1) AS demand_count
FROM portfolios pf LEFT JOIN people owner ON pf.owner_person_id=owner.id LEFT JOIN verticals v ON pf.vertical_id=v.id";
        }

        private static string DemandQuery()
        {
            return @"SELECT d.*,owner.display_name AS owner_name,manager.display_name AS accountable_manager_name,
pf.name AS portfolio_name,pf.code AS portfolio_code,prg.name AS program_name,sq.name AS squad_name
FROM demands d LEFT JOIN people owner ON d.owner_person_id=owner.id LEFT JOIN people manager ON d.accountable_manager_id=manager.id
LEFT JOIN portfolios pf ON d.portfolio_id=pf.id LEFT JOIN programs prg ON d.program_id=prg.id LEFT JOIN squads sq ON d.squad_id=sq.id";
        }

        private static string ManagerQuery()
        {
            return @"SELECT p.id,p.employee_id,p.display_name,p.designation,p.functional_role,p.employment_type,p.photo_url,p.profile_summary,
p.manager_id,p.vertical_id,v.name AS vertical_name,v.color AS vertical_color FROM people p LEFT JOIN verticals v ON p.vertical_id=v.id";
        }

        private static void AddStringFilter(StringBuilder sql, ICollection<SqlParameter> parameters, string column, string parameterName, string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return;
            sql.Append(" AND ").Append(column).Append("=").Append(parameterName);
            parameters.Add(SqlStore.Parameter(parameterName, value));
        }

        private static int CountPlatformsByRelationship(IEnumerable<IDictionary<string, object>> platforms, ICollection<int> people, string relationship)
        {
            return platforms.Count(platform =>
            {
                var assignments = platform["assignments"] as IEnumerable<IDictionary<string, object>>;
                return assignments != null && assignments.Any(assignment => people.Contains(RowInt(assignment, "person_id")) && string.Equals(RowString(assignment, "relationship"), relationship, StringComparison.Ordinal));
            });
        }

        private static IDictionary<string, object> CompactPortfolio(IDictionary<string, object> row)
        {
            return JsonHttp.Object("id", row["id"], "code", row["code"], "name", row["name"], "status", row["status"], "health", row["health"], "demand_count", RowInt(row, "demand_count"));
        }

        private static IDictionary<string, object> CompactDemand(IDictionary<string, object> row)
        {
            return JsonHttp.Object("id", row["id"], "demand_id", row["demand_id"], "title", row["title"], "status", row["status"], "health", row["health"],
                "priority", row["priority"], "progress_percent", RowInt(row, "progress_percent"));
        }

        private static IDictionary<string, object> CompactRecord(IDictionary<string, object> row)
        {
            object ownerName;
            object leadName;
            row.TryGetValue("owner_name", out ownerName);
            row.TryGetValue("lead_name", out leadName);
            return JsonHttp.Object("id", row["id"], "code", row["code"], "name", row["name"], "status", row["status"], "owner_name", ownerName, "lead_name", leadName);
        }
    }
}