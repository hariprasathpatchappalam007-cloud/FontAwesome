using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using CET.CommandCenter.Web.Infrastructure;

namespace CET.CommandCenter.Web.Data
{
    public sealed class SquadRepository : RepositoryBase
    {
        private static readonly string[] SquadFields =
        {
            "code", "name", "description", "platform_id", "manager_person_id", "lead_person_id", "vertical_id",
            "track_type", "status", "display_order", "is_active"
        };
        private static readonly string[] RoleFields = { "code", "name", "description", "category", "display_order", "is_active" };

        public SquadRepository(SqlStore store) : base(store)
        {
        }

        public IList<IDictionary<string, object>> ListSquads(string search, bool? active, int? platformId, int? managerPersonId)
        {
            var sql = new StringBuilder(BaseQuery()).Append(" WHERE 1=1");
            var parameters = new List<SqlParameter>();
            if (active.HasValue)
            {
                sql.Append(" AND sq.is_active=@active");
                parameters.Add(SqlStore.Parameter("@active", active.Value));
            }
            if (platformId.HasValue)
            {
                sql.Append(" AND sq.platform_id=@platform_id");
                parameters.Add(SqlStore.Parameter("@platform_id", platformId.Value));
            }
            if (managerPersonId.HasValue)
            {
                sql.Append(" AND sq.manager_person_id=@manager_person_id");
                parameters.Add(SqlStore.Parameter("@manager_person_id", managerPersonId.Value));
            }
            if (!string.IsNullOrWhiteSpace(search))
            {
                sql.Append(" AND (sq.name LIKE @search OR sq.code LIKE @search OR plt.name LIKE @search)");
                parameters.Add(SqlStore.Parameter("@search", "%" + search.Trim() + "%"));
            }
            sql.Append(" ORDER BY plt.name,sq.display_order,sq.name");
            var squads = Store.Query(sql.ToString(), parameters.ToArray());
            foreach (var squad in squads) Hydrate(squad);
            return squads;
        }

        public IDictionary<string, object> GetSquad(int id)
        {
            var squad = Store.QueryOne(BaseQuery() + " WHERE sq.id=@id", SqlStore.Parameter("@id", id));
            if (squad != null) Hydrate(squad);
            return squad;
        }

        public IDictionary<string, object> Summary()
        {
            var squads = ListSquads(null, true, null, null);
            var assignedPeople = new HashSet<int>();
            var platforms = new HashSet<int>();
            var required = 0;
            decimal allocated = 0;
            foreach (var squad in squads)
            {
                required += RowInt(squad, "required_total");
                allocated += Convert.ToDecimal(squad["allocated_fte"], CultureInfo.InvariantCulture);
                var platformId = RowNullableInt(squad, "platform_id");
                if (platformId.HasValue) platforms.Add(platformId.Value);
                var assignments = squad["assignments"] as IEnumerable<IDictionary<string, object>>;
                if (assignments != null)
                {
                    foreach (var assignment in assignments) assignedPeople.Add(RowInt(assignment, "person_id"));
                }
            }
            allocated = decimal.Round(allocated, 2);
            return JsonHttp.Object(
                "squads", squads.Count,
                "platforms", platforms.Count,
                "required_headcount", required,
                "assigned_resources", assignedPeople.Count,
                "allocated_fte", allocated,
                "capacity_gap", decimal.Round(Math.Max(0, required - allocated), 2));
        }

        public IDictionary<string, object> SaveSquad(int? id, IDictionary<string, object> payload, string actorEmail)
        {
            var record = Normalize(payload, SquadFields,
                new[] { "platform_id", "manager_person_id", "lead_person_id", "vertical_id", "display_order" },
                new[] { "is_active" });
            record["code"] = (Convert.ToString(record["code"], CultureInfo.InvariantCulture) ?? string.Empty).ToUpperInvariant();
            record["is_active"] = !string.Equals(JsonHttp.String(payload, "status"), "Archived", StringComparison.Ordinal);
            record["updated_by"] = actorEmail;
            record["updated_at"] = DateTime.UtcNow;
            var staffingPlan = JsonHttp.ObjectList(payload, "staffing_plan")
                .Where(row => (JsonHttp.Integer(row, "required_count") ?? 0) > 0).ToList();
            var assignments = JsonHttp.ObjectList(payload, "assignments").ToList();
            var savedId = Store.Transaction((connection, transaction) =>
            {
                int squadId;
                if (id.HasValue)
                {
                    if (Update(connection, transaction, "squads", id.Value, record) == 0) return 0;
                    squadId = id.Value;
                    DeleteChildren(connection, transaction, squadId);
                }
                else
                {
                    record["created_by"] = actorEmail;
                    record["created_at"] = DateTime.UtcNow;
                    squadId = Insert(connection, transaction, "squads", record);
                }
                foreach (var row in staffingPlan) InsertStaffingPlan(connection, transaction, squadId, row);
                foreach (var row in assignments) InsertAssignment(connection, transaction, squadId, row);
                Audit(connection, transaction, actorEmail, id.HasValue ? "UPDATE" : "CREATE", "squad", squadId,
                    JsonHttp.Object("code", record["code"], "required_roles", staffingPlan.Count, "assignment_count", assignments.Count));
                return squadId;
            });
            return savedId == 0 ? null : GetSquad(savedId);
        }

        public IDictionary<string, object> ArchiveSquad(int id, string actorEmail)
        {
            var archived = Store.Transaction((connection, transaction) =>
            {
                string code;
                using (var select = SqlStore.CreateCommand(connection, transaction, "SELECT code FROM squads WHERE id=@id", SqlStore.Parameter("@id", id)))
                {
                    var value = select.ExecuteScalar();
                    if (value == null || value == DBNull.Value) return false;
                    code = Convert.ToString(value, CultureInfo.InvariantCulture);
                }
                using (var update = SqlStore.CreateCommand(connection, transaction, @"UPDATE squads SET status='Archived',is_active=0,
updated_by=@actor,updated_at=SYSUTCDATETIME() WHERE id=@id", SqlStore.Parameter("@actor", actorEmail), SqlStore.Parameter("@id", id))) update.ExecuteNonQuery();
                Audit(connection, transaction, actorEmail, "ARCHIVE", "squad", id, JsonHttp.Object("code", code));
                return true;
            });
            return archived ? GetSquad(id) : null;
        }

        public IList<IDictionary<string, object>> ListRoles(bool? active)
        {
            if (!active.HasValue) return Store.Query("SELECT * FROM squad_roles ORDER BY display_order,name");
            return Store.Query("SELECT * FROM squad_roles WHERE is_active=@active ORDER BY display_order,name", SqlStore.Parameter("@active", active.Value));
        }

        public IDictionary<string, object> GetRole(int id)
        {
            return Store.QueryOne("SELECT * FROM squad_roles WHERE id=@id", SqlStore.Parameter("@id", id));
        }

        public IDictionary<string, object> SaveRole(int? id, IDictionary<string, object> payload, string actorEmail)
        {
            var record = Normalize(payload, RoleFields, new[] { "display_order" }, new[] { "is_active" });
            record["code"] = (Convert.ToString(record["code"], CultureInfo.InvariantCulture) ?? string.Empty).ToUpperInvariant();
            record["updated_by"] = actorEmail;
            record["updated_at"] = DateTime.UtcNow;
            var savedId = Store.Transaction((connection, transaction) =>
            {
                if (id.HasValue)
                {
                    if (Update(connection, transaction, "squad_roles", id.Value, record) == 0) return 0;
                    Audit(connection, transaction, actorEmail, "UPDATE", "squad_role", id.Value, JsonHttp.Object("changed_fields", record.Keys.ToList()));
                    return id.Value;
                }
                record["created_by"] = actorEmail;
                record["created_at"] = DateTime.UtcNow;
                if (!record.ContainsKey("is_active")) record["is_active"] = true;
                var createdId = Insert(connection, transaction, "squad_roles", record);
                Audit(connection, transaction, actorEmail, "CREATE", "squad_role", createdId, JsonHttp.Object("code", record["code"], "name", record["name"]));
                return createdId;
            });
            return savedId == 0 ? null : GetRole(savedId);
        }

        public IDictionary<string, object> ArchiveRole(int id, string actorEmail)
        {
            var archived = Store.Transaction((connection, transaction) =>
            {
                string code;
                using (var select = SqlStore.CreateCommand(connection, transaction, "SELECT code FROM squad_roles WHERE id=@id", SqlStore.Parameter("@id", id)))
                {
                    var value = select.ExecuteScalar();
                    if (value == null || value == DBNull.Value) return false;
                    code = Convert.ToString(value, CultureInfo.InvariantCulture);
                }
                using (var update = SqlStore.CreateCommand(connection, transaction, @"UPDATE squad_roles SET is_active=0,
updated_by=@actor,updated_at=SYSUTCDATETIME() WHERE id=@id", SqlStore.Parameter("@actor", actorEmail), SqlStore.Parameter("@id", id))) update.ExecuteNonQuery();
                Audit(connection, transaction, actorEmail, "ARCHIVE", "squad_role", id, JsonHttp.Object("code", code));
                return true;
            });
            return archived ? GetRole(id) : null;
        }

        public bool ValidateScope(int managerId, int platformId, IEnumerable<int> personIds)
        {
            var manager = Store.QueryOne("SELECT id,manager_id FROM people WHERE id=@id AND is_active=1", SqlStore.Parameter("@id", managerId));
            var parentId = RowNullableInt(manager, "manager_id");
            if (manager == null || !parentId.HasValue) return false;
            var parent = Store.QueryOne("SELECT manager_id FROM people WHERE id=@id AND is_active=1", SqlStore.Parameter("@id", parentId.Value));
            if (parent == null || RowNullableInt(parent, "manager_id").HasValue) return false;
            var platform = Store.QueryOne("SELECT id FROM platforms WHERE id=@id AND manager_person_id=@manager_id AND is_active=1",
                SqlStore.Parameter("@id", platformId), SqlStore.Parameter("@manager_id", managerId));
            if (platform == null) return false;
            var people = Store.Query("SELECT id,manager_id FROM people WHERE is_active=1");
            var allowed = new HashSet<int>(CollectDescendants(managerId, people));
            allowed.Add(managerId);
            return (personIds ?? new int[0]).All(allowed.Contains);
        }

        private void Hydrate(IDictionary<string, object> squad)
        {
            var id = RowInt(squad, "id");
            var staffingPlan = Store.Query(@"SELECT sp.id,sp.role_id,sp.required_count,sr.code AS role_code,sr.name AS role_name,sr.display_order
FROM squad_staffing_plan sp INNER JOIN squad_roles sr ON sp.role_id=sr.id WHERE sp.squad_id=@id ORDER BY sr.display_order,sr.name",
                SqlStore.Parameter("@id", id));
            var assignments = Store.Query(@"SELECT sa.id,sa.person_id,sa.role_id,sa.allocation_percent,sa.is_primary,sa.start_date,sa.end_date,
sr.code AS role_code,sr.name AS role_name,p.display_name,p.designation,p.employment_type,p.photo_url
FROM squad_assignments sa INNER JOIN squad_roles sr ON sa.role_id=sr.id INNER JOIN people p ON sa.person_id=p.id
WHERE sa.squad_id=@id ORDER BY sr.display_order,p.display_name", SqlStore.Parameter("@id", id));
            var required = staffingPlan.Sum(row => RowInt(row, "required_count"));
            var assignedPeople = new HashSet<int>(assignments.Select(row => RowInt(row, "person_id")));
            var allocationPercent = assignments.Sum(row => RowInt(row, "allocation_percent"));
            var allocated = decimal.Round(allocationPercent / 100m, 2);
            squad["staffing_plan"] = staffingPlan;
            squad["assignments"] = assignments;
            squad["required_total"] = required;
            squad["assigned_resources"] = assignedPeople.Count;
            squad["allocated_fte"] = allocated;
            squad["capacity_gap"] = decimal.Round(Math.Max(0, required - allocated), 2);
        }

        private static string BaseQuery()
        {
            return @"SELECT sq.*,plt.name AS platform_name,plt.code AS platform_code,plt.category AS platform_category,
manager.display_name AS manager_name,lead.display_name AS lead_name FROM squads sq
LEFT JOIN platforms plt ON sq.platform_id=plt.id LEFT JOIN people manager ON sq.manager_person_id=manager.id
LEFT JOIN people lead ON sq.lead_person_id=lead.id";
        }

        private static void DeleteChildren(SqlConnection connection, SqlTransaction transaction, int squadId)
        {
            using (var command = SqlStore.CreateCommand(connection, transaction,
                "DELETE FROM squad_staffing_plan WHERE squad_id=@id; DELETE FROM squad_assignments WHERE squad_id=@id;",
                SqlStore.Parameter("@id", squadId))) command.ExecuteNonQuery();
        }

        private static void InsertStaffingPlan(SqlConnection connection, SqlTransaction transaction, int squadId, IDictionary<string, object> row)
        {
            using (var command = SqlStore.CreateCommand(connection, transaction, @"INSERT INTO squad_staffing_plan
(squad_id,role_id,required_count,created_at,updated_at) VALUES (@squad_id,@role_id,@required_count,SYSUTCDATETIME(),SYSUTCDATETIME())",
                SqlStore.Parameter("@squad_id", squadId), SqlStore.Parameter("@role_id", JsonHttp.Integer(row, "role_id")),
                SqlStore.Parameter("@required_count", JsonHttp.Integer(row, "required_count")))) command.ExecuteNonQuery();
        }

        private static void InsertAssignment(SqlConnection connection, SqlTransaction transaction, int squadId, IDictionary<string, object> row)
        {
            using (var command = SqlStore.CreateCommand(connection, transaction, @"INSERT INTO squad_assignments
(squad_id,person_id,role_id,allocation_percent,is_primary,start_date,end_date,created_at,updated_at)
VALUES (@squad_id,@person_id,@role_id,@allocation_percent,@is_primary,@start_date,@end_date,SYSUTCDATETIME(),SYSUTCDATETIME())",
                SqlStore.Parameter("@squad_id", squadId), SqlStore.Parameter("@person_id", JsonHttp.Integer(row, "person_id")),
                SqlStore.Parameter("@role_id", JsonHttp.Integer(row, "role_id")), SqlStore.Parameter("@allocation_percent", JsonHttp.Integer(row, "allocation_percent")),
                SqlStore.Parameter("@is_primary", JsonHttp.Boolean(row, "is_primary") ?? false), SqlStore.Parameter("@start_date", JsonHttp.String(row, "start_date")),
                SqlStore.Parameter("@end_date", JsonHttp.String(row, "end_date")))) command.ExecuteNonQuery();
        }
    }
}