using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using CET.CommandCenter.Web.Infrastructure;

namespace CET.CommandCenter.Web.Validation
{
    public static class RequestValidator
    {
        private static readonly Regex EmailPattern = new Regex(@"^[^\s@]+@[^\s@]+\.[^\s@]+$", RegexOptions.Compiled);
        private static readonly Regex UnitCodePattern = new Regex(@"^[A-Z0-9][A-Z0-9-]{1,29}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private static readonly Regex LongCodePattern = new Regex(@"^[A-Z0-9][A-Z0-9-]{1,39}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private static readonly Regex ColorPattern = new Regex(@"^#[0-9A-F]{6}$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        public static IList<IDictionary<string, object>> Person(IDictionary<string, object> payload, bool partial)
        {
            var errors = NewErrors();
            if (!partial) Require(payload, errors, "employee_id", "full_name", "email", "designation", "employment_type");
            var email = JsonHttp.String(payload, "email");
            if (!string.IsNullOrEmpty(email) && !EmailPattern.IsMatch(email)) Add(errors, "email", "Enter a valid email address.");
            Enum(payload, errors, "employment_type", "Staff", "Consultant");
            Enum(payload, errors, "gender", "Male", "Female");
            var managerId = JsonHttp.Integer(payload, "manager_id");
            var id = JsonHttp.Integer(payload, "id");
            if (managerId.HasValue && id.HasValue && managerId.Value == id.Value) Add(errors, "manager_id", "A person cannot report to themselves.");
            return errors;
        }

        public static IList<IDictionary<string, object>> Unit(IDictionary<string, object> payload)
        {
            var errors = NewErrors();
            Require(payload, errors, "name", "code");
            var code = JsonHttp.String(payload, "code");
            if (!string.IsNullOrEmpty(code) && !UnitCodePattern.IsMatch(code)) Add(errors, "code", "Use 2-30 letters, numbers or hyphens.");
            var color = JsonHttp.String(payload, "color");
            if (!string.IsNullOrEmpty(color) && !ColorPattern.IsMatch(color)) Add(errors, "color", "Choose a valid six-digit colour.");
            return errors;
        }

        public static IList<IDictionary<string, object>> Platform(IDictionary<string, object> payload)
        {
            var errors = NewErrors();
            Require(payload, errors, "name", "code", "status", "criticality", "manager_context_id");
            ValidateLongCode(payload, errors);
            Enum(payload, errors, "status", "Active", "Planned", "Under Review", "Retiring", "Retired");
            Enum(payload, errors, "criticality", "Low", "Medium", "High", "Critical");
            var supporters = JsonHttp.IntegerList(payload, "support_person_ids");
            if (!JsonHttp.Integer(payload, "owner_person_id").HasValue && supporters.Count == 0) Add(errors, "assignments", "Choose an owner or at least one supporting person.");
            if (JsonHttp.Get(payload, "owner_person_id") != null && !JsonHttp.Integer(payload, "owner_person_id").HasValue) Add(errors, "owner_person_id", "Choose a valid platform owner.");
            return errors;
        }

        public static IList<IDictionary<string, object>> Portfolio(IDictionary<string, object> payload)
        {
            var errors = NewErrors();
            Require(payload, errors, "name", "code", "owner_person_id", "vertical_id", "status", "health");
            Enum(payload, errors, "status", "Active", "On Hold", "Completed", "Archived");
            Enum(payload, errors, "health", "Green", "Amber", "Red");
            ValidateDateOrder(payload, errors, "start_date", "target_end_date", "Target end date must be after the start date.");
            return errors;
        }

        public static IList<IDictionary<string, object>> Demand(IDictionary<string, object> payload)
        {
            var errors = NewErrors();
            Require(payload, errors, "demand_id", "title", "classification", "priority", "stage", "status", "owner_person_id", "accountable_manager_id", "portfolio_id", "health");
            Enum(payload, errors, "classification", "Strategic", "Fast Track", "Regulatory", "Mandatory", "Operational");
            Enum(payload, errors, "priority", "Low", "Medium", "High", "Critical");
            Enum(payload, errors, "status", "New", "In Progress", "At Risk", "On Hold", "Completed", "Cancelled", "Archived");
            Enum(payload, errors, "health", "Green", "Amber", "Red");
            var progressValue = JsonHttp.Get(payload, "progress_percent");
            decimal progress;
            if (progressValue != null && (!decimal.TryParse(Convert.ToString(progressValue, CultureInfo.InvariantCulture), NumberStyles.Number, CultureInfo.InvariantCulture, out progress) || progress < 0 || progress > 100))
            {
                Add(errors, "progress_percent", "Progress must be between 0 and 100.");
            }
            ValidateDateOrder(payload, errors, "planned_start_date", "planned_end_date", "Planned end date must be after the start date.");
            return errors;
        }

        public static IList<IDictionary<string, object>> Squad(IDictionary<string, object> payload)
        {
            var errors = NewErrors();
            Require(payload, errors, "code", "name", "platform_id", "manager_person_id", "track_type", "status");
            ValidateLongCode(payload, errors);
            Enum(payload, errors, "track_type", "Delivery Squad", "Track", "Supporting Squad");
            Enum(payload, errors, "status", "Active", "Planned", "On Hold", "Archived");
            var roles = new HashSet<int>();
            foreach (var row in JsonHttp.ObjectList(payload, "staffing_plan"))
            {
                var roleId = JsonHttp.Integer(row, "role_id");
                var required = JsonHttp.Integer(row, "required_count");
                if (!roleId.HasValue) Add(errors, "staffing_plan", "Every staffing requirement needs a valid role.");
                if (!required.HasValue || required.Value < 0 || required.Value > 999) Add(errors, "staffing_plan", "Required headcount must be between 0 and 999.");
                if (roleId.HasValue && !roles.Add(roleId.Value)) Add(errors, "staffing_plan", "A role can appear only once in the staffing plan.");
            }
            var assignments = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var row in JsonHttp.ObjectList(payload, "assignments"))
            {
                var personId = JsonHttp.Integer(row, "person_id");
                var roleId = JsonHttp.Integer(row, "role_id");
                var allocation = JsonHttp.Integer(row, "allocation_percent");
                if (!personId.HasValue || !roleId.HasValue) Add(errors, "assignments", "Every assignment needs a person and role.");
                if (!allocation.HasValue || allocation.Value < 1 || allocation.Value > 100) Add(errors, "assignments", "Allocation must be between 1 and 100 percent.");
                ValidateDateOrder(row, errors, "start_date", "end_date", "Assignment end date must be after the start date.", "assignments");
                if (personId.HasValue && roleId.HasValue && !assignments.Add(personId.Value + ":" + roleId.Value)) Add(errors, "assignments", "The same person and role cannot be assigned twice.");
            }
            return errors;
        }

        public static IList<IDictionary<string, object>> SquadRole(IDictionary<string, object> payload)
        {
            var errors = NewErrors();
            Require(payload, errors, "code", "name", "category");
            var code = JsonHttp.String(payload, "code");
            if (!string.IsNullOrEmpty(code) && !UnitCodePattern.IsMatch(code)) Add(errors, "code", "Use 2-30 letters, numbers or hyphens.");
            Enum(payload, errors, "category", "Leadership", "Delivery", "Engineering", "Quality", "Functional", "Support");
            return errors;
        }

        private static IList<IDictionary<string, object>> NewErrors()
        {
            return new List<IDictionary<string, object>>();
        }

        private static void Require(IDictionary<string, object> payload, IList<IDictionary<string, object>> errors, params string[] fields)
        {
            foreach (var field in fields)
            {
                var value = JsonHttp.Get(payload, field);
                if (value == null || string.IsNullOrWhiteSpace(Convert.ToString(value, CultureInfo.InvariantCulture))) Add(errors, field, "Required field.");
            }
        }

        private static void Enum(IDictionary<string, object> payload, IList<IDictionary<string, object>> errors, string field, params string[] values)
        {
            if (!payload.ContainsKey(field) || JsonHttp.Get(payload, field) == null) return;
            var value = JsonHttp.String(payload, field);
            if (!values.Contains(value)) Add(errors, field, "Choose a valid " + field.Replace('_', ' ') + ".");
        }

        private static void ValidateLongCode(IDictionary<string, object> payload, IList<IDictionary<string, object>> errors)
        {
            var code = JsonHttp.String(payload, "code");
            if (!string.IsNullOrEmpty(code) && !LongCodePattern.IsMatch(code)) Add(errors, "code", "Use 2-40 letters, numbers or hyphens.");
        }

        private static void ValidateDateOrder(IDictionary<string, object> payload, IList<IDictionary<string, object>> errors, string startField, string endField, string message)
        {
            ValidateDateOrder(payload, errors, startField, endField, message, endField);
        }

        private static void ValidateDateOrder(IDictionary<string, object> payload, IList<IDictionary<string, object>> errors, string startField, string endField, string message, string errorField)
        {
            var start = JsonHttp.String(payload, startField);
            var end = JsonHttp.String(payload, endField);
            if (!string.IsNullOrEmpty(start) && !string.IsNullOrEmpty(end) && string.CompareOrdinal(start, end) > 0) Add(errors, errorField, message);
        }

        private static void Add(IList<IDictionary<string, object>> errors, string field, string message)
        {
            errors.Add(JsonHttp.Object("field", field, "message", message));
        }
    }
}