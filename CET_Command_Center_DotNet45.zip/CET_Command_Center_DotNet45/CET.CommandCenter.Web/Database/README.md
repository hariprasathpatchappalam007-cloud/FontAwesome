# SQL Server deployment

The scripts target SQL Server 2012 or later and preserve the current portal records from `data/cet-portal.db`.

1. Back up the source SQLite database and the SQL Server target.
2. Create an empty SQL Server database named `CETPortal`, or use an approved database name.
3. Run `001_CreateSchema.sql` in the empty database.
4. Run `002_MigrateCurrentData.sql` once. It preserves source identity values and refuses to run when core target data already exists.
5. Run `003_Verify.sql`. It prints all table counts and fails when core relationships are orphaned.
6. Set the `CETPortal` connection string in `Web.config` using the approved deployment transform or secret-management process.

The validated source snapshot has these key counts: 21 people, 9 Platforms, 6 Squads, and 71 audit records. Re-export the data if the original portal changes after this migration package was prepared.

Do not run the current-data script in an existing production database. For a populated target, use a reviewed merge migration keyed by stable business codes instead.