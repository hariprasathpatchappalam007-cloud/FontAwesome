SET NOCOUNT ON;

SELECT 'verticals' AS table_name, COUNT(*) AS row_count FROM dbo.verticals
UNION ALL SELECT 'people', COUNT(*) FROM dbo.people
UNION ALL SELECT 'application_users', COUNT(*) FROM dbo.application_users
UNION ALL SELECT 'platforms', COUNT(*) FROM dbo.platforms
UNION ALL SELECT 'platform_assignments', COUNT(*) FROM dbo.platform_assignments
UNION ALL SELECT 'portfolios', COUNT(*) FROM dbo.portfolios
UNION ALL SELECT 'programs', COUNT(*) FROM dbo.programs
UNION ALL SELECT 'squads', COUNT(*) FROM dbo.squads
UNION ALL SELECT 'squad_members', COUNT(*) FROM dbo.squad_members
UNION ALL SELECT 'squad_roles', COUNT(*) FROM dbo.squad_roles
UNION ALL SELECT 'squad_staffing_plan', COUNT(*) FROM dbo.squad_staffing_plan
UNION ALL SELECT 'squad_assignments', COUNT(*) FROM dbo.squad_assignments
UNION ALL SELECT 'demands', COUNT(*) FROM dbo.demands
UNION ALL SELECT 'audit_logs', COUNT(*) FROM dbo.audit_logs
ORDER BY table_name;

IF EXISTS
(
    SELECT 1
    FROM dbo.people person_record
    LEFT JOIN dbo.people manager_record ON person_record.manager_id = manager_record.id
    WHERE person_record.manager_id IS NOT NULL AND manager_record.id IS NULL
)
    THROW 50002, 'Orphaned reporting relationships were found.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.platform_assignments assignment_record
    LEFT JOIN dbo.platforms platform_record ON assignment_record.platform_id = platform_record.id
    LEFT JOIN dbo.people person_record ON assignment_record.person_id = person_record.id
    WHERE platform_record.id IS NULL OR person_record.id IS NULL
)
    THROW 50003, 'Orphaned platform assignments were found.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.squad_assignments assignment_record
    LEFT JOIN dbo.squads squad_record ON assignment_record.squad_id = squad_record.id
    LEFT JOIN dbo.people person_record ON assignment_record.person_id = person_record.id
    LEFT JOIN dbo.squad_roles role_record ON assignment_record.role_id = role_record.id
    WHERE squad_record.id IS NULL OR person_record.id IS NULL OR role_record.id IS NULL
)
    THROW 50004, 'Orphaned squad assignments were found.', 1;

PRINT 'CET database verification passed.';