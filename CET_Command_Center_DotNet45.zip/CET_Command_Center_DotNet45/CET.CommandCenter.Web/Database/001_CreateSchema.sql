SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;

BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.verticals', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.verticals
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_verticals PRIMARY KEY,
            name NVARCHAR(120) NOT NULL,
            code NVARCHAR(30) NOT NULL,
            description NVARCHAR(600) NULL,
            color NVARCHAR(20) NOT NULL CONSTRAINT DF_verticals_color DEFAULT ('#20c997'),
            is_active BIT NOT NULL CONSTRAINT DF_verticals_is_active DEFAULT (1),
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_verticals_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_verticals_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_verticals_name UNIQUE (name),
            CONSTRAINT UQ_verticals_code UNIQUE (code)
        );
    END;

    IF OBJECT_ID(N'dbo.people', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.people
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_people PRIMARY KEY,
            employee_id NVARCHAR(50) NOT NULL,
            entra_object_id NVARCHAR(80) NULL,
            full_name NVARCHAR(160) NOT NULL,
            display_name NVARCHAR(120) NOT NULL,
            email NVARCHAR(180) NOT NULL,
            phone NVARCHAR(40) NULL,
            designation NVARCHAR(140) NOT NULL,
            functional_role NVARCHAR(140) NULL,
            employment_type NVARCHAR(20) NOT NULL,
            employer NVARCHAR(160) NULL,
            grade NVARCHAR(40) NULL,
            location NVARCHAR(100) NULL,
            gender NVARCHAR(20) NULL,
            cost_center NVARCHAR(50) NULL,
            joining_date DATE NULL,
            contract_end_date DATE NULL,
            manager_id INT NULL,
            vertical_id INT NULL,
            photo_url NVARCHAR(500) NULL,
            profile_summary NVARCHAR(MAX) NULL,
            skills NVARCHAR(MAX) NULL,
            certifications NVARCHAR(MAX) NULL,
            is_vertical_head BIT NOT NULL CONSTRAINT DF_people_is_vertical_head DEFAULT (0),
            is_active BIT NOT NULL CONSTRAINT DF_people_is_active DEFAULT (1),
            created_by NVARCHAR(180) NULL,
            updated_by NVARCHAR(180) NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_people_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_people_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_people_employee_id UNIQUE (employee_id),
            CONSTRAINT UQ_people_email UNIQUE (email),
            CONSTRAINT CK_people_employment_type CHECK (employment_type IN ('Staff', 'Consultant')),
            CONSTRAINT CK_people_gender CHECK (gender IS NULL OR gender IN ('Male', 'Female')),
            CONSTRAINT FK_people_manager FOREIGN KEY (manager_id) REFERENCES dbo.people(id),
            CONSTRAINT FK_people_vertical FOREIGN KEY (vertical_id) REFERENCES dbo.verticals(id) ON DELETE SET NULL
        );
        CREATE INDEX IX_people_manager_id ON dbo.people(manager_id);
        CREATE INDEX IX_people_vertical_id ON dbo.people(vertical_id);
        CREATE INDEX IX_people_employment_type ON dbo.people(employment_type);
        CREATE UNIQUE INDEX UX_people_entra_object_id ON dbo.people(entra_object_id) WHERE entra_object_id IS NOT NULL;
    END;

    IF OBJECT_ID(N'dbo.application_users', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.application_users
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_application_users PRIMARY KEY,
            entra_object_id NVARCHAR(80) NULL,
            email NVARCHAR(180) NOT NULL,
            display_name NVARCHAR(160) NOT NULL,
            role NVARCHAR(40) NOT NULL CONSTRAINT DF_application_users_role DEFAULT ('viewer'),
            person_id INT NULL,
            is_active BIT NOT NULL CONSTRAINT DF_application_users_is_active DEFAULT (1),
            last_login_at DATETIME2(0) NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_application_users_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_application_users_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_application_users_email UNIQUE (email),
            CONSTRAINT FK_application_users_person FOREIGN KEY (person_id) REFERENCES dbo.people(id) ON DELETE SET NULL
        );
        CREATE UNIQUE INDEX UX_application_users_entra_object_id ON dbo.application_users(entra_object_id) WHERE entra_object_id IS NOT NULL;
    END;

    IF OBJECT_ID(N'dbo.platforms', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.platforms
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_platforms PRIMARY KEY,
            code NVARCHAR(40) NOT NULL,
            name NVARCHAR(180) NOT NULL,
            description NVARCHAR(MAX) NULL,
            category NVARCHAR(100) NULL,
            vendor NVARCHAR(140) NULL,
            manager_person_id INT NULL,
            status NVARCHAR(30) NOT NULL CONSTRAINT DF_platforms_status DEFAULT ('Active'),
            criticality NVARCHAR(20) NOT NULL CONSTRAINT DF_platforms_criticality DEFAULT ('Medium'),
            is_active BIT NOT NULL CONSTRAINT DF_platforms_is_active DEFAULT (1),
            created_by NVARCHAR(180) NULL,
            updated_by NVARCHAR(180) NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_platforms_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_platforms_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_platforms_code UNIQUE (code),
            CONSTRAINT FK_platforms_manager FOREIGN KEY (manager_person_id) REFERENCES dbo.people(id) ON DELETE SET NULL
        );
        CREATE INDEX IX_platforms_manager_person_id ON dbo.platforms(manager_person_id);
        CREATE INDEX IX_platforms_status_criticality ON dbo.platforms(status, criticality);
    END;

    IF OBJECT_ID(N'dbo.platform_assignments', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.platform_assignments
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_platform_assignments PRIMARY KEY,
            platform_id INT NOT NULL,
            person_id INT NOT NULL,
            relationship NVARCHAR(20) NOT NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_platform_assignments_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_platform_assignments_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_platform_assignments_platform_person UNIQUE (platform_id, person_id),
            CONSTRAINT CK_platform_assignments_relationship CHECK (relationship IN ('Owned', 'Supported')),
            CONSTRAINT FK_platform_assignments_platform FOREIGN KEY (platform_id) REFERENCES dbo.platforms(id) ON DELETE CASCADE,
            CONSTRAINT FK_platform_assignments_person FOREIGN KEY (person_id) REFERENCES dbo.people(id) ON DELETE CASCADE
        );
        CREATE INDEX IX_platform_assignments_person_relationship ON dbo.platform_assignments(person_id, relationship);
    END;

    IF OBJECT_ID(N'dbo.portfolios', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.portfolios
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_portfolios PRIMARY KEY,
            name NVARCHAR(160) NOT NULL,
            code NVARCHAR(40) NOT NULL,
            description NVARCHAR(MAX) NULL,
            business_area NVARCHAR(120) NULL,
            owner_person_id INT NULL,
            vertical_id INT NULL,
            status NVARCHAR(30) NOT NULL CONSTRAINT DF_portfolios_status DEFAULT ('Active'),
            health NVARCHAR(20) NOT NULL CONSTRAINT DF_portfolios_health DEFAULT ('Green'),
            start_date DATE NULL,
            target_end_date DATE NULL,
            strategic_objectives NVARCHAR(MAX) NULL,
            is_active BIT NOT NULL CONSTRAINT DF_portfolios_is_active DEFAULT (1),
            created_by NVARCHAR(180) NULL,
            updated_by NVARCHAR(180) NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_portfolios_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_portfolios_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_portfolios_code UNIQUE (code),
            CONSTRAINT FK_portfolios_owner FOREIGN KEY (owner_person_id) REFERENCES dbo.people(id) ON DELETE SET NULL,
            CONSTRAINT FK_portfolios_vertical FOREIGN KEY (vertical_id) REFERENCES dbo.verticals(id) ON DELETE SET NULL
        );
        CREATE INDEX IX_portfolios_owner_person_id ON dbo.portfolios(owner_person_id);
        CREATE INDEX IX_portfolios_vertical_id ON dbo.portfolios(vertical_id);
        CREATE INDEX IX_portfolios_status_health ON dbo.portfolios(status, health);
    END;

    IF OBJECT_ID(N'dbo.programs', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.programs
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_programs PRIMARY KEY,
            name NVARCHAR(180) NOT NULL,
            code NVARCHAR(40) NOT NULL,
            owner_person_id INT NULL,
            status NVARCHAR(30) NOT NULL CONSTRAINT DF_programs_status DEFAULT ('In Progress'),
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_programs_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_programs_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_programs_code UNIQUE (code),
            CONSTRAINT FK_programs_owner FOREIGN KEY (owner_person_id) REFERENCES dbo.people(id) ON DELETE SET NULL
        );
    END;

    IF OBJECT_ID(N'dbo.squads', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.squads
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_squads PRIMARY KEY,
            name NVARCHAR(160) NOT NULL,
            code NVARCHAR(40) NOT NULL,
            description NVARCHAR(MAX) NULL,
            platform_id INT NULL,
            manager_person_id INT NULL,
            lead_person_id INT NULL,
            vertical_id INT NULL,
            track_type NVARCHAR(30) NOT NULL CONSTRAINT DF_squads_track_type DEFAULT ('Delivery Squad'),
            status NVARCHAR(30) NOT NULL CONSTRAINT DF_squads_status DEFAULT ('Active'),
            display_order INT NOT NULL CONSTRAINT DF_squads_display_order DEFAULT (0),
            is_active BIT NOT NULL CONSTRAINT DF_squads_is_active DEFAULT (1),
            created_by NVARCHAR(180) NULL,
            updated_by NVARCHAR(180) NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_squads_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_squads_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_squads_code UNIQUE (code),
            CONSTRAINT FK_squads_platform FOREIGN KEY (platform_id) REFERENCES dbo.platforms(id) ON DELETE SET NULL,
            CONSTRAINT FK_squads_manager FOREIGN KEY (manager_person_id) REFERENCES dbo.people(id),
            CONSTRAINT FK_squads_lead FOREIGN KEY (lead_person_id) REFERENCES dbo.people(id),
            CONSTRAINT FK_squads_vertical FOREIGN KEY (vertical_id) REFERENCES dbo.verticals(id) ON DELETE SET NULL
        );
        CREATE INDEX IX_squads_platform_order ON dbo.squads(platform_id, display_order);
        CREATE INDEX IX_squads_manager_person_id ON dbo.squads(manager_person_id);
    END;

    IF OBJECT_ID(N'dbo.squad_members', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.squad_members
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_squad_members PRIMARY KEY,
            squad_id INT NOT NULL,
            person_id INT NOT NULL,
            role NVARCHAR(100) NULL,
            is_primary BIT NOT NULL CONSTRAINT DF_squad_members_is_primary DEFAULT (1),
            CONSTRAINT UQ_squad_members_squad_person UNIQUE (squad_id, person_id),
            CONSTRAINT FK_squad_members_squad FOREIGN KEY (squad_id) REFERENCES dbo.squads(id) ON DELETE CASCADE,
            CONSTRAINT FK_squad_members_person FOREIGN KEY (person_id) REFERENCES dbo.people(id) ON DELETE CASCADE
        );
    END;

    IF OBJECT_ID(N'dbo.squad_roles', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.squad_roles
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_squad_roles PRIMARY KEY,
            code NVARCHAR(30) NOT NULL,
            name NVARCHAR(120) NOT NULL,
            description NVARCHAR(400) NULL,
            category NVARCHAR(50) NOT NULL CONSTRAINT DF_squad_roles_category DEFAULT ('Delivery'),
            display_order INT NOT NULL CONSTRAINT DF_squad_roles_display_order DEFAULT (0),
            is_active BIT NOT NULL CONSTRAINT DF_squad_roles_is_active DEFAULT (1),
            created_by NVARCHAR(180) NULL,
            updated_by NVARCHAR(180) NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_squad_roles_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_squad_roles_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_squad_roles_code UNIQUE (code),
            CONSTRAINT UQ_squad_roles_name UNIQUE (name)
        );
    END;

    IF OBJECT_ID(N'dbo.squad_staffing_plan', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.squad_staffing_plan
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_squad_staffing_plan PRIMARY KEY,
            squad_id INT NOT NULL,
            role_id INT NOT NULL,
            required_count INT NOT NULL CONSTRAINT DF_squad_staffing_plan_required_count DEFAULT (0),
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_squad_staffing_plan_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_squad_staffing_plan_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_squad_staffing_plan_squad_role UNIQUE (squad_id, role_id),
            CONSTRAINT CK_squad_staffing_plan_required_count CHECK (required_count BETWEEN 0 AND 999),
            CONSTRAINT FK_squad_staffing_plan_squad FOREIGN KEY (squad_id) REFERENCES dbo.squads(id) ON DELETE CASCADE,
            CONSTRAINT FK_squad_staffing_plan_role FOREIGN KEY (role_id) REFERENCES dbo.squad_roles(id) ON DELETE CASCADE
        );
    END;

    IF OBJECT_ID(N'dbo.squad_assignments', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.squad_assignments
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_squad_assignments PRIMARY KEY,
            squad_id INT NOT NULL,
            person_id INT NOT NULL,
            role_id INT NOT NULL,
            allocation_percent INT NOT NULL CONSTRAINT DF_squad_assignments_allocation DEFAULT (100),
            is_primary BIT NOT NULL CONSTRAINT DF_squad_assignments_is_primary DEFAULT (1),
            start_date DATE NULL,
            end_date DATE NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_squad_assignments_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_squad_assignments_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_squad_assignments_squad_person_role UNIQUE (squad_id, person_id, role_id),
            CONSTRAINT CK_squad_assignments_allocation CHECK (allocation_percent BETWEEN 1 AND 100),
            CONSTRAINT CK_squad_assignments_dates CHECK (end_date IS NULL OR start_date IS NULL OR end_date >= start_date),
            CONSTRAINT FK_squad_assignments_squad FOREIGN KEY (squad_id) REFERENCES dbo.squads(id) ON DELETE CASCADE,
            CONSTRAINT FK_squad_assignments_person FOREIGN KEY (person_id) REFERENCES dbo.people(id) ON DELETE CASCADE,
            CONSTRAINT FK_squad_assignments_role FOREIGN KEY (role_id) REFERENCES dbo.squad_roles(id)
        );
        CREATE INDEX IX_squad_assignments_person_role ON dbo.squad_assignments(person_id, role_id);
    END;

    IF OBJECT_ID(N'dbo.demands', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.demands
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_demands PRIMARY KEY,
            demand_id NVARCHAR(50) NOT NULL,
            title NVARCHAR(220) NOT NULL,
            description NVARCHAR(MAX) NULL,
            category NVARCHAR(80) NULL,
            classification NVARCHAR(40) NOT NULL CONSTRAINT DF_demands_classification DEFAULT ('Strategic'),
            priority NVARCHAR(20) NOT NULL CONSTRAINT DF_demands_priority DEFAULT ('Medium'),
            stage NVARCHAR(50) NOT NULL CONSTRAINT DF_demands_stage DEFAULT ('Intake'),
            status NVARCHAR(40) NOT NULL CONSTRAINT DF_demands_status DEFAULT ('New'),
            requesting_department NVARCHAR(140) NULL,
            requestor_name NVARCHAR(160) NULL,
            owner_person_id INT NULL,
            accountable_manager_id INT NULL,
            portfolio_id INT NULL,
            program_id INT NULL,
            squad_id INT NULL,
            planned_start_date DATE NULL,
            planned_end_date DATE NULL,
            health NVARCHAR(20) NOT NULL CONSTRAINT DF_demands_health DEFAULT ('Green'),
            progress_percent INT NOT NULL CONSTRAINT DF_demands_progress DEFAULT (0),
            is_active BIT NOT NULL CONSTRAINT DF_demands_is_active DEFAULT (1),
            created_by NVARCHAR(180) NULL,
            updated_by NVARCHAR(180) NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_demands_created_at DEFAULT (SYSUTCDATETIME()),
            updated_at DATETIME2(0) NOT NULL CONSTRAINT DF_demands_updated_at DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_demands_demand_id UNIQUE (demand_id),
            CONSTRAINT CK_demands_progress CHECK (progress_percent BETWEEN 0 AND 100),
            CONSTRAINT CK_demands_dates CHECK (planned_end_date IS NULL OR planned_start_date IS NULL OR planned_end_date >= planned_start_date),
            CONSTRAINT FK_demands_owner FOREIGN KEY (owner_person_id) REFERENCES dbo.people(id),
            CONSTRAINT FK_demands_manager FOREIGN KEY (accountable_manager_id) REFERENCES dbo.people(id),
            CONSTRAINT FK_demands_portfolio FOREIGN KEY (portfolio_id) REFERENCES dbo.portfolios(id) ON DELETE SET NULL,
            CONSTRAINT FK_demands_program FOREIGN KEY (program_id) REFERENCES dbo.programs(id) ON DELETE SET NULL,
            CONSTRAINT FK_demands_squad FOREIGN KEY (squad_id) REFERENCES dbo.squads(id) ON DELETE SET NULL
        );
        CREATE INDEX IX_demands_portfolio_id ON dbo.demands(portfolio_id);
        CREATE INDEX IX_demands_owner_person_id ON dbo.demands(owner_person_id);
        CREATE INDEX IX_demands_accountable_manager_id ON dbo.demands(accountable_manager_id);
        CREATE INDEX IX_demands_status_health ON dbo.demands(status, health);
    END;

    IF OBJECT_ID(N'dbo.audit_logs', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.audit_logs
        (
            id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_audit_logs PRIMARY KEY,
            actor_email NVARCHAR(180) NOT NULL,
            action NVARCHAR(60) NOT NULL,
            entity_type NVARCHAR(60) NOT NULL,
            entity_id NVARCHAR(80) NOT NULL,
            details NVARCHAR(MAX) NULL,
            created_at DATETIME2(0) NOT NULL CONSTRAINT DF_audit_logs_created_at DEFAULT (SYSUTCDATETIME())
        );
        CREATE INDEX IX_audit_logs_entity ON dbo.audit_logs(entity_type, entity_id);
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;