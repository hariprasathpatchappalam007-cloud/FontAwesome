using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;

namespace CET.CommandCenter.Web.Infrastructure
{
    public static class JsonHttp
    {
        public static IDictionary<string, object> ReadObject(HttpRequest request)
        {
            request.InputStream.Position = 0;
            using (var reader = new StreamReader(request.InputStream))
            {
                var text = reader.ReadToEnd();
                if (string.IsNullOrWhiteSpace(text))
                {
                    return new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                }

                var value = CreateSerializer().DeserializeObject(text) as IDictionary<string, object>;
                if (value == null)
                {
                    throw new ApiException(400, "INVALID_JSON", "The request body must be a JSON object.");
                }

                return new Dictionary<string, object>(value, StringComparer.OrdinalIgnoreCase);
            }
        }

        public static void Write(HttpContext context, object value, int statusCode)
        {
            context.Response.Clear();
            context.Response.StatusCode = statusCode;
            context.Response.TrySkipIisCustomErrors = true;
            context.Response.ContentType = "application/json";
            context.Response.ContentEncoding = System.Text.Encoding.UTF8;
            context.Response.Write(CreateSerializer().Serialize(Normalize(value)));
        }

        public static void WriteError(HttpContext context, int statusCode, string code, string message)
        {
            WriteError(context, statusCode, code, message, null);
        }

        public static void WriteError(HttpContext context, int statusCode, string code, string message, object details)
        {
            var error = new Dictionary<string, object>
            {
                { "code", code },
                { "message", message }
            };
            if (details != null) error["details"] = details;
            Write(context, new Dictionary<string, object> { { "error", error } }, statusCode);
        }

        public static IDictionary<string, object> Object(params object[] values)
        {
            var result = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            for (var index = 0; index + 1 < values.Length; index += 2)
            {
                result[Convert.ToString(values[index], CultureInfo.InvariantCulture)] = values[index + 1];
            }
            return result;
        }

        public static object Get(IDictionary<string, object> payload, string key)
        {
            object value;
            return payload != null && payload.TryGetValue(key, out value) ? value : null;
        }

        public static string String(IDictionary<string, object> payload, string key)
        {
            var value = Get(payload, key);
            return value == null ? null : Convert.ToString(value, CultureInfo.InvariantCulture).Trim();
        }

        public static int? Integer(IDictionary<string, object> payload, string key)
        {
            var value = Get(payload, key);
            int converted;
            return value != null && int.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), NumberStyles.Integer, CultureInfo.InvariantCulture, out converted)
                ? (int?)converted
                : null;
        }

        public static bool? Boolean(IDictionary<string, object> payload, string key)
        {
            var value = Get(payload, key);
            if (value == null) return null;
            if (value is bool) return (bool)value;
            bool converted;
            return bool.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out converted) ? (bool?)converted : null;
        }

        public static IList<IDictionary<string, object>> ObjectList(IDictionary<string, object> payload, string key)
        {
            var result = new List<IDictionary<string, object>>();
            var values = Get(payload, key) as IEnumerable;
            if (values == null || values is string) return result;
            foreach (var value in values)
            {
                var row = value as IDictionary<string, object>;
                if (row != null) result.Add(new Dictionary<string, object>(row, StringComparer.OrdinalIgnoreCase));
            }
            return result;
        }

        public static IList<int> IntegerList(IDictionary<string, object> payload, string key)
        {
            var result = new List<int>();
            var values = Get(payload, key) as IEnumerable;
            if (values == null || values is string) return result;
            foreach (var value in values)
            {
                int converted;
                if (int.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out converted)) result.Add(converted);
            }
            return result;
        }

        private static JavaScriptSerializer CreateSerializer()
        {
            return new JavaScriptSerializer { MaxJsonLength = 16 * 1024 * 1024, RecursionLimit = 128 };
        }

        private static object Normalize(object value)
        {
            if (value == null || value == DBNull.Value) return null;
            if (value is DateTime)
            {
                var date = (DateTime)value;
                return date.TimeOfDay == TimeSpan.Zero
                    ? date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
                    : date.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture);
            }

            var dictionary = value as IDictionary<string, object>;
            if (dictionary != null)
            {
                var normalized = new Dictionary<string, object>();
                foreach (var item in dictionary) normalized[item.Key] = Normalize(item.Value);
                return normalized;
            }

            var enumerable = value as IEnumerable;
            if (enumerable != null && !(value is string))
            {
                var normalized = new List<object>();
                foreach (var item in enumerable) normalized.Add(Normalize(item));
                return normalized;
            }

            return value;
        }
    }

    public sealed class ApiException : Exception
    {
        public ApiException(int statusCode, string code, string message)
            : this(statusCode, code, message, null)
        {
        }

        public ApiException(int statusCode, string code, string message, object details)
            : base(message)
        {
            StatusCode = statusCode;
            Code = code;
            Details = details;
        }

        public int StatusCode { get; private set; }
        public string Code { get; private set; }
        public object Details { get; private set; }
    }
}