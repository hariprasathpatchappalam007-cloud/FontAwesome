using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace CET.CommandCenter.Web.Infrastructure
{
    public sealed class SqlStore
    {
        private readonly string connectionString;

        public SqlStore()
        {
            var setting = ConfigurationManager.ConnectionStrings["CETPortal"];
            if (setting == null || string.IsNullOrWhiteSpace(setting.ConnectionString))
            {
                throw new ConfigurationErrorsException("Connection string 'CETPortal' is required.");
            }
            connectionString = setting.ConnectionString;
        }

        public SqlConnection Open()
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        public IList<IDictionary<string, object>> Query(string sql, params SqlParameter[] parameters)
        {
            using (var connection = Open())
            using (var command = CreateCommand(connection, null, sql, parameters))
            using (var reader = command.ExecuteReader())
            {
                return ReadRows(reader);
            }
        }

        public IDictionary<string, object> QueryOne(string sql, params SqlParameter[] parameters)
        {
            var rows = Query(sql, parameters);
            return rows.Count == 0 ? null : rows[0];
        }

        public object Scalar(string sql, params SqlParameter[] parameters)
        {
            using (var connection = Open())
            using (var command = CreateCommand(connection, null, sql, parameters))
            {
                var value = command.ExecuteScalar();
                return value == DBNull.Value ? null : value;
            }
        }

        public int Execute(string sql, params SqlParameter[] parameters)
        {
            using (var connection = Open())
            using (var command = CreateCommand(connection, null, sql, parameters))
            {
                return command.ExecuteNonQuery();
            }
        }

        public T Transaction<T>(Func<SqlConnection, SqlTransaction, T> action)
        {
            using (var connection = Open())
            using (var transaction = connection.BeginTransaction(IsolationLevel.ReadCommitted))
            {
                try
                {
                    var result = action(connection, transaction);
                    transaction.Commit();
                    return result;
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public static SqlCommand CreateCommand(SqlConnection connection, SqlTransaction transaction, string sql, params SqlParameter[] parameters)
        {
            var command = connection.CreateCommand();
            command.CommandText = sql;
            command.CommandType = CommandType.Text;
            command.CommandTimeout = 60;
            command.Transaction = transaction;
            if (parameters != null && parameters.Length > 0) command.Parameters.AddRange(parameters);
            return command;
        }

        public static SqlParameter Parameter(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        public static int Int(object value)
        {
            return value == null || value == DBNull.Value ? 0 : Convert.ToInt32(value, CultureInfo.InvariantCulture);
        }

        public static decimal Decimal(object value)
        {
            return value == null || value == DBNull.Value ? 0 : Convert.ToDecimal(value, CultureInfo.InvariantCulture);
        }

        public static IList<IDictionary<string, object>> ReadRows(SqlDataReader reader)
        {
            var rows = new List<IDictionary<string, object>>();
            while (reader.Read())
            {
                var row = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                for (var index = 0; index < reader.FieldCount; index++)
                {
                    var value = reader.IsDBNull(index) ? null : reader.GetValue(index);
                    if (value is DateTime)
                    {
                        var date = (DateTime)value;
                        value = reader.GetDataTypeName(index).Equals("date", StringComparison.OrdinalIgnoreCase)
                            ? date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
                            : date.ToUniversalTime().ToString("o", CultureInfo.InvariantCulture);
                    }
                    row[reader.GetName(index)] = value;
                }
                rows.Add(row);
            }
            return rows;
        }
    }
}