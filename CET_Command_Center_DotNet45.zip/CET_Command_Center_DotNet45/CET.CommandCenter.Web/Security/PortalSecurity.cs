using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Web;
using CET.CommandCenter.Web.Infrastructure;

namespace CET.CommandCenter.Web.Security
{
    public static class PortalSecurity
    {
        private const string SessionKey = "CET.User";
        private static readonly HashSet<string> EditorRoles = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "super_admin", "profile_admin", "governance_editor"
        };

        public static string AuthMode
        {
            get
            {
                var configured = ConfigurationManager.AppSettings["AuthMode"] ?? "Demo";
                return configured.Trim().ToLowerInvariant();
            }
        }

        public static IDictionary<string, object> CurrentUser(HttpContext context)
        {
            return context.Session == null ? null : context.Session[SessionKey] as IDictionary<string, object>;
        }

        public static IDictionary<string, object> RequireAuthenticated(HttpContext context)
        {
            var user = CurrentUser(context);
            if (user == null) throw new ApiException(401, "AUTH_REQUIRED", "Sign in is required.");
            return user;
        }

        public static void RequireEditor(IDictionary<string, object> user)
        {
            object role;
            if (user == null || !user.TryGetValue("role", out role) || !EditorRoles.Contains(Convert.ToString(role, CultureInfo.InvariantCulture)))
                throw new ApiException(403, "FORBIDDEN", "You do not have permission for this action.");
        }

        public static void LoginDemo(HttpContext context)
        {
            context.Session[SessionKey] = JsonHttp.Object(
                "id", "demo-admin",
                "email", "admin@cet.local",
                "displayName", "CET Local Administrator",
                "role", "super_admin",
                "authMode", "demo");
        }

        public static void LoginWindows(HttpContext context)
        {
            if (context.User == null || context.User.Identity == null || !context.User.Identity.IsAuthenticated)
                throw new ApiException(401, "AUTH_REQUIRED", "IIS Windows Authentication is required.");
            var identity = context.User.Identity.Name ?? string.Empty;
            var separator = identity.LastIndexOf('\\');
            var account = separator >= 0 ? identity.Substring(separator + 1) : identity;
            var domain = ConfigurationManager.AppSettings["WindowsEmailDomain"] ?? string.Empty;
            var email = account.IndexOf('@') >= 0 ? account : account + "@" + domain;
            email = email.ToLowerInvariant();
            var displayName = account.Replace('.', ' ');
            var store = new SqlStore();
            var record = store.QueryOne("SELECT id,email,display_name,role,is_active FROM application_users WHERE LOWER(email)=@email",
                SqlStore.Parameter("@email", email));
            string role;
            int id;
            if (record == null)
            {
                id = Convert.ToInt32(store.Scalar(@"INSERT INTO application_users
(email,display_name,role,is_active,last_login_at,created_at,updated_at) OUTPUT INSERTED.id
VALUES (@email,@display_name,'viewer',1,SYSUTCDATETIME(),SYSUTCDATETIME(),SYSUTCDATETIME())",
                    SqlStore.Parameter("@email", email), SqlStore.Parameter("@display_name", displayName)), CultureInfo.InvariantCulture);
                role = "viewer";
            }
            else
            {
                id = Convert.ToInt32(record["id"], CultureInfo.InvariantCulture);
                role = Convert.ToBoolean(record["is_active"], CultureInfo.InvariantCulture)
                    ? Convert.ToString(record["role"], CultureInfo.InvariantCulture)
                    : "viewer";
                displayName = Convert.ToString(record["display_name"], CultureInfo.InvariantCulture);
                store.Execute("UPDATE application_users SET last_login_at=SYSUTCDATETIME(),updated_at=SYSUTCDATETIME() WHERE id=@id", SqlStore.Parameter("@id", id));
            }
            context.Session[SessionKey] = JsonHttp.Object("id", id, "email", email, "displayName", displayName, "role", role, "authMode", "windows");
        }

        public static void Logout(HttpContext context)
        {
            if (context.Session != null)
            {
                context.Session.Clear();
                context.Session.Abandon();
            }
            var cookie = new HttpCookie("cet.sid", string.Empty) { Expires = DateTime.UtcNow.AddYears(-1), HttpOnly = true };
            context.Response.Cookies.Add(cookie);
        }
    }
}