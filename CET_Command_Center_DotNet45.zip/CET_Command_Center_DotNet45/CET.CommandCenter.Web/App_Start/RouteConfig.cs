using System.Web;
using System.Web.Routing;
using CET.CommandCenter.Web.Handlers;

namespace CET.CommandCenter.Web
{
    public static class RouteConfig
    {
        public static void RegisterRoutes()
        {
            RouteTable.Routes.Add("Authentication", new Route("auth/{*path}", new HttpHandlerRouteHandler<AuthHandler>()));
            RouteTable.Routes.Add("Api", new Route("api/v1/{*path}", new HttpHandlerRouteHandler<ApiHandler>()));
        }

        private sealed class HttpHandlerRouteHandler<THandler> : IRouteHandler
            where THandler : IHttpHandler, new()
        {
            public IHttpHandler GetHttpHandler(RequestContext requestContext)
            {
                return new THandler();
            }
        }
    }
}