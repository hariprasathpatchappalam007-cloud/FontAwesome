# JIRA integration boundary

The portal does not call JIRA yet. `IJiraIntegration` is the application boundary for the future module, and `DisabledJiraIntegration` keeps that capability explicitly off until the JIRA deployment, authentication, project, issue-type, field-mapping, and synchronization rules are supplied.

Future implementation steps:

1. Add a .NET 4.5-compatible `IJiraIntegration` adapter in this folder.
2. Keep credentials outside source control in the approved secret store.
3. Add normalized external identifiers and synchronization audit records through a reviewed database migration.
4. Replace the disabled adapter registration only after connection, authorization, retry, and idempotency tests pass.

Authenticated clients can inspect `GET /api/v1/integrations/jira/status`; it currently reports `enabled: false`.