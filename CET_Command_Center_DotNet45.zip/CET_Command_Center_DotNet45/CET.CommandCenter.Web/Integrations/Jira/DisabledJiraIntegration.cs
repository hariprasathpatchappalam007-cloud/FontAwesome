using System.Collections.Generic;
using CET.CommandCenter.Web.Infrastructure;

namespace CET.CommandCenter.Web.Integrations.Jira
{
    public sealed class DisabledJiraIntegration : IJiraIntegration
    {
        public IDictionary<string, object> GetStatus()
        {
            return JsonHttp.Object(
                "provider", "jira",
                "enabled", false,
                "configured", false,
                "message", "JIRA integration is reserved for a future enhancement.");
        }
    }
}