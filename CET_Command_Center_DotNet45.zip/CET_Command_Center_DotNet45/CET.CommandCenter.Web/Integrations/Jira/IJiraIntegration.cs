using System.Collections.Generic;

namespace CET.CommandCenter.Web.Integrations.Jira
{
    public interface IJiraIntegration
    {
        IDictionary<string, object> GetStatus();
    }

    public static class JiraIntegration
    {
        private static readonly IJiraIntegration Adapter = new DisabledJiraIntegration();
        public static IJiraIntegration Current { get { return Adapter; } }
    }
}