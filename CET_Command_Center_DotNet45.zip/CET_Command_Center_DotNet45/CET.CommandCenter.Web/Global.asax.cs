using System;
using System.Web;

namespace CET.CommandCenter.Web
{
    public class WebApplication : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            RouteConfig.RegisterRoutes();
        }

        protected void Application_PreSendRequestHeaders(object sender, EventArgs e)
        {
            // Check if headers have already been sent to prevent exceptions
            if (HttpContext.Current != null && HttpContext.Current.Response != null)
            {
                Response.Headers["X-Content-Type-Options"] = "nosniff";
                Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
                Response.Headers["Referrer-Policy"] = "same-origin";
                if (Request.Path.StartsWith(AppPaths.Resolve(Request, "api/"), StringComparison.OrdinalIgnoreCase))
                {
                    Response.Headers["Cache-Control"] = "no-store";
                }

            }
        }
    }

    internal static class AppPaths
    {
        public static string Resolve(HttpRequest request, string relativePath = "")
        {
            var applicationPath = request != null ? request.ApplicationPath : "/";
            if (string.IsNullOrEmpty(applicationPath) || applicationPath == "/")
            {
                applicationPath = "/";
            }
            else
            {
                applicationPath = applicationPath.TrimEnd('/');
            }

            relativePath = (relativePath ?? string.Empty).TrimStart('/');
            if (string.IsNullOrEmpty(relativePath))
            {
                return applicationPath;
            }

            return applicationPath == "/" ? "/" + relativePath : applicationPath + "/" + relativePath;
        }
    }
}