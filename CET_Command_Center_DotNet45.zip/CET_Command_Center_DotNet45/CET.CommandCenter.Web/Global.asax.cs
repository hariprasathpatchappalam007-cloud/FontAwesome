using System;
using System.Web;

namespace CET.CommandCenter.Web
{
    public class WebApplication : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            RouteConfig.RegisterRoutes();
        }

        protected void Application_EndRequest(object sender, EventArgs e)
        {
            Response.Headers["X-Content-Type-Options"] = "nosniff";
            Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
            Response.Headers["Referrer-Policy"] = "same-origin";
            if (Request.Path.StartsWith("/api/", StringComparison.OrdinalIgnoreCase))
            {
                Response.Headers["Cache-Control"] = "no-store";
            }
        }
    }
}