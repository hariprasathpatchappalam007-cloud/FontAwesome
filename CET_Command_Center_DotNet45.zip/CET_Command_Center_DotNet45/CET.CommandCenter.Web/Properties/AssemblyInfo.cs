using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CET Command Center")]
[assembly: AssemblyDescription("CET Command Center ASP.NET 4.5 application")]
[assembly: AssemblyCompany("CET")]
[assembly: AssemblyProduct("CET Command Center")]
[assembly: ComVisible(false)]
[assembly: Guid("5d0b10d9-25cb-42b0-bfaf-884db996c937")]
[assembly: AssemblyVersion("2.3.6.0")]
[assembly: AssemblyFileVersion("2.3.6.0")]