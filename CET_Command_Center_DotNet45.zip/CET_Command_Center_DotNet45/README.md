# CET Command Center - ASP.NET 4.5

This folder is the Node-free conversion of CET Command Center v2.3.6. It is a Visual Studio 2012 Web Application targeting .NET Framework 4.5 and Microsoft SQL Server 2012 or later.

## Technology

- ASP.NET on .NET Framework 4.5
- C# 5 and `System.Data.SqlClient` with parameterized SQL
- SQL Server 2012-compatible schema and migration scripts
- Existing HTML/CSS/browser JavaScript interface, with no npm or Node runtime
- IIS session authentication with role-based API authorization

AngularJS is not required by the retained interface. AngularJS 1.8.3 can be introduced later as a checked-in browser asset if a future UI module needs it; no JavaScript build server is required.

## Open in Visual Studio 2012

1. Install Visual Studio 2012 with ASP.NET and .NET Framework 4.5 development tools.
2. Install SQL Server 2012 or later. Local development can use SQL Server LocalDB and IIS Express.
3. Open `CET.CommandCenter.sln`.
4. Set `CET.CommandCenter.Web` as the startup project.
5. Run the database scripts in `CET.CommandCenter.Web\Database` as described there.
6. Update the `CETPortal` connection string in `Web.config` for the target SQL Server.
7. Run with IIS Express.

For this machine, double-click `start-local.bat`. It creates the named `CETLocalDb` instance and isolated `CETCommandCenterLocal` database only when absent, imports the preserved source snapshot, verifies it, starts IIS Express, and opens `http://localhost:52345`.

## Authentication

`AuthMode=Demo` is local-only and creates the same `super_admin` test session as the original project. A release transform switches to `AuthMode=Windows`; production IIS must enable Windows Authentication and disable Anonymous Authentication. Set `WindowsEmailDomain` to the corporate email suffix. Portal roles continue to come from `application_users`.

The Node MSAL dependency is not present. If production must use Microsoft Entra OpenID Connect instead of IIS Windows Authentication, add an approved .NET 4.5 OIDC middleware package and deployment-specific app registration before release.

## Deployment controls

- Publish the Web Application to an IIS application at the site root because browser routes are root-relative.
- Use HTTPS, a trusted SQL Server certificate, and an approved secret/configuration transform.
- Grant the application pool identity least-privilege access to the CET database and write access only to `uploads` when local file storage is approved.
- Use an evergreen Edge or Chrome browser. The retained interface uses modern JavaScript and is not compatible with Internet Explorer 11.
- Replace in-process session state before running multiple IIS instances.

## JIRA enhancement

The future integration boundary is under `CET.CommandCenter.Web\Integrations\Jira`. It is deliberately disabled and exposed as `GET /api/v1/integrations/jira/status`. JIRA credentials, project mappings, issue types, custom fields, synchronization direction, and retry/idempotency rules can be added later without coupling JIRA to the core repositories.