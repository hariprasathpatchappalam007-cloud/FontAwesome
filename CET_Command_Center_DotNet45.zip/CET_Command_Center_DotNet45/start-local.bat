@echo off
setlocal

set "ROOT=%~dp0"
set "WEB_ROOT=%ROOT%CET.CommandCenter.Web"
set "INSTANCE=CETLocalDb"
set "SERVER=(localdb)\%INSTANCE%"
set "DATABASE=CETCommandCenterLocal"
set "IIS_EXPRESS=%ProgramFiles%\IIS Express\iisexpress.exe"

where SqlLocalDB.exe >nul 2>nul
if errorlevel 1 (
  echo SQL Server LocalDB is required.
  exit /b 1
)

where sqlcmd.exe >nul 2>nul
if errorlevel 1 (
  echo SQL Server command-line utilities are required.
  exit /b 1
)

if not exist "%IIS_EXPRESS%" (
  echo IIS Express is required at "%IIS_EXPRESS%".
  exit /b 1
)

SqlLocalDB.exe create "%INSTANCE%" >nul 2>nul
SqlLocalDB.exe start "%INSTANCE%" >nul
if errorlevel 1 (
  echo Unable to start LocalDB instance "%INSTANCE%".
  exit /b 1
)

set "DATABASE_EXISTS=0"
for /f %%A in ('sqlcmd.exe -S "%SERVER%" -E -W -h -1 -Q "SET NOCOUNT ON; SELECT CASE WHEN DB_ID('%DATABASE%') IS NULL THEN 0 ELSE 1 END"') do set "DATABASE_EXISTS=%%A"
if not "%DATABASE_EXISTS%"=="1" (
  sqlcmd.exe -S "%SERVER%" -E -Q "CREATE DATABASE [%DATABASE%]" -b || exit /b 1
  sqlcmd.exe -S "%SERVER%" -E -d "%DATABASE%" -i "%WEB_ROOT%\Database\001_CreateSchema.sql" -b || exit /b 1
  sqlcmd.exe -S "%SERVER%" -E -d "%DATABASE%" -i "%WEB_ROOT%\Database\002_MigrateCurrentData.sql" -b || exit /b 1
)

sqlcmd.exe -S "%SERVER%" -E -d "%DATABASE%" -i "%WEB_ROOT%\Database\003_Verify.sql" -b || exit /b 1
start "" http://localhost:52345
"%IIS_EXPRESS%" /path:"%WEB_ROOT%" /port:52345

endlocal