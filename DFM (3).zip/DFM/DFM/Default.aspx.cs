using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM
{
    public partial class DefaultPage : System.Web.UI.Page
    {
        public string JsCapexBudget { get; private set; }
        public string JsOpexBudget  { get; private set; }
        public string JsUtilized    { get; private set; }
        public string JsAvailable   { get; private set; }
        public string JsLocked      { get; private set; }
        public string JsPending     { get; private set; }
        public string JsApproved    { get; private set; }
        public string JsRejected    { get; private set; }
        public string JsDraft       { get; private set; }

        // JIRA chart datasets (serialised inline into the page)
        public string JsRagLabels       { get; private set; }
        public string JsRagData         { get; private set; }
        public string JsRagColors       { get; private set; }
        public string JsDemandLabels    { get; private set; }
        public string JsDemandData      { get; private set; }
        public string JsTechLeadLabels  { get; private set; }
        public string JsTechLeadData    { get; private set; }
        public string JsManagerLabels   { get; private set; }
        public string JsManagerData     { get; private set; }
        public string JsDemandStatusLabels { get; private set; }
        public string JsDemandStatusData   { get; private set; }
        public string JsDemandStatusColors { get; private set; }
        public string JsPlatformLabels  { get; private set; }
        public string JsPlatformData    { get; private set; }
        public string JsPlatformColors  { get; private set; }

        // New Req 4: Demands by Chief, Manager, TechTeam, Aging
        public string JsChiefLabels     { get; private set; }
        public string JsChiefData       { get; private set; }
        public string JsChiefColors     { get; private set; }
        public string JsByMgrLabels     { get; private set; }
        public string JsByMgrData       { get; private set; }
        public string JsByMgrColors     { get; private set; }
        public string JsByTechLabels    { get; private set; }
        public string JsByTechData      { get; private set; }
        public string JsByTechColors    { get; private set; }
        public string JsAgingLabels     { get; private set; }
        public string JsAgingData       { get; private set; }
        public string JsAgingColors     { get; private set; }
        public string JsGanttJson       { get; private set; }
        // Visibility KPIs
        public string JsOnHoldCount     { get; private set; }
        public string JsDeferredCount   { get; private set; }
        public string JsConvertedCount  { get; private set; }
        public string JsMissedCount     { get; private set; }
        public string JsAgingCount      { get; private set; }
        // Req5: drill-down series (DMGT -> DIBITP children)
        public string JsHierDrillJson   { get; private set; }

        // New chart dimensions (Dashboard Redesign)
        public string JsPlatVertLabels      { get; private set; }
        public string JsPlatVertData        { get; private set; }
        public string JsPlatVertColors      { get; private set; }
        public string JsOverallStatusLabels { get; private set; }
        public string JsOverallStatusData   { get; private set; }
        public string JsOverallStatusColors { get; private set; }
        public string JsSchedRagLabels      { get; private set; }
        public string JsSchedRagData        { get; private set; }
        public string JsSchedRagColors      { get; private set; }
        public string JsDemandOwnerLabels   { get; private set; }
        public string JsDemandOwnerData     { get; private set; }
        public string JsDemandOwnerColors   { get; private set; }
        public string JsIssueTypeLabels     { get; private set; }
        public string JsIssueTypeData       { get; private set; }
        public string JsIssueTypeColors     { get; private set; }
        public string JsAssignedPMLabels    { get; private set; }
        public string JsAssignedPMData      { get; private set; }
        public string JsAssignedPMColors    { get; private set; }

        public DefaultPage()
        {
            JsCapexBudget = "0"; JsOpexBudget = "0"; JsUtilized = "0";
            JsAvailable = "0"; JsLocked = "0";
            JsPending = "0"; JsApproved = "0"; JsRejected = "0"; JsDraft = "0";
            JsRagLabels = "[]"; JsRagData = "[]"; JsRagColors = "[]";
            JsDemandLabels = "[]"; JsDemandData = "[]";
            JsTechLeadLabels = "[]"; JsTechLeadData = "[]";
            JsManagerLabels = "[]"; JsManagerData = "[]";
            JsDemandStatusLabels = "[]"; JsDemandStatusData = "[]"; JsDemandStatusColors = "[]";
            JsPlatformLabels = "[]"; JsPlatformData = "[]"; JsPlatformColors = "[]";
            JsChiefLabels = "[]"; JsChiefData = "[]"; JsChiefColors = "[]";
            JsByMgrLabels = "[]"; JsByMgrData = "[]"; JsByMgrColors = "[]";
            JsByTechLabels = "[]"; JsByTechData = "[]"; JsByTechColors = "[]";
            JsAgingLabels = "[]"; JsAgingData = "[]"; JsAgingColors = "[]";
            JsGanttJson = "[]";
            JsOnHoldCount = "0"; JsDeferredCount = "0"; JsConvertedCount = "0";
            JsMissedCount = "0"; JsAgingCount = "0";
            JsHierDrillJson = "{\"chief\":[],\"manager\":[],\"tech\":[]}";
            JsPlatVertLabels = "[]"; JsPlatVertData = "[]"; JsPlatVertColors = "[]";
            JsOverallStatusLabels = "[]"; JsOverallStatusData = "[]"; JsOverallStatusColors = "[]";
            JsSchedRagLabels = "[]"; JsSchedRagData = "[]"; JsSchedRagColors = "[]";
            JsDemandOwnerLabels = "[]"; JsDemandOwnerData = "[]"; JsDemandOwnerColors = "[]";
            JsIssueTypeLabels = "[]"; JsIssueTypeData = "[]"; JsIssueTypeColors = "[]";
            JsAssignedPMLabels = "[]"; JsAssignedPMData = "[]"; JsAssignedPMColors = "[]";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindFilterLists();
                LoadDashboard();
            }
        }

        private void BindFilterLists()
        {
            // Req6: populate filter dropdowns from the pre-aggregated DashboardFilterValues
            // table (back-filled by sp_RefreshDashboardReport) with a safe fall-back to
            // distinct values from JiraIssues. Ensures Vertical / Platform are NEVER blank.
            BindFilter(lbPlatform, "platform");
            BindFilter(lbVertical, "vertical");
            BindFilter(lbManager,  "manager");
            BindFilter(lbTechLead, "techlead");
        }

        private static void BindFilter(ListBox lb, string filterType)
        {
            try
            {
                lb.Items.Clear();
                foreach (string v in ReportRepo.GetFilterValues(filterType))
                    if (!string.IsNullOrEmpty(v)) lb.Items.Add(new ListItem(v, v));
            }
            catch { /* fall back silently */ }
        }

        private static void BindList(ListBox lb, string sql)
        {
            try
            {
                DataTable dt = Db.Query(sql);
                lb.Items.Clear();
                foreach (DataRow r in dt.Rows)
                {
                    string v = r[0] == DBNull.Value ? "" : r[0].ToString();
                    if (!string.IsNullOrEmpty(v)) lb.Items.Add(new ListItem(v, v));
                }
            }
            catch { /* table/column may not exist yet */ }
        }

        protected void Filter_Changed(object sender, EventArgs e)
        {
            DashboardLog.Log("FilterApplied", BuildFilterDetail());
            LoadDashboard();
        }

        private string BuildFilterDetail()
        {
            var sb = new StringBuilder();
            sb.Append("Platform=").Append(SelectedCsv(lbPlatform));
            sb.Append("; Vertical=").Append(SelectedCsv(lbVertical));
            sb.Append("; Manager=").Append(SelectedCsv(lbManager));
            sb.Append("; TechLead=").Append(SelectedCsv(lbTechLead));
            sb.Append("; RAG=").Append(SelectedCsv(lbRag));
            sb.Append("; Priority=").Append(SelectedCsv(lbPriority));
            return sb.ToString();
        }

        private static string SelectedCsv(ListBox lb)
        {
            var sb = new StringBuilder();
            foreach (ListItem i in lb.Items)
                if (i.Selected) { if (sb.Length > 0) sb.Append(','); sb.Append(i.Value); }
            return sb.Length == 0 ? "*" : sb.ToString();
        }

        private void LoadDashboard()
        {
            var swDash = System.Diagnostics.Stopwatch.StartNew();
            DashboardLog.Log("DashboardLoad", "Begin", null);
            DataRow s = ProjectsDAL.GetDashboardSummary();
            decimal capexBudget = ToDec(s, "TotalCapexBudget");
            decimal opexBudget  = ToDec(s, "TotalOpexBudget");
            decimal utilized    = ToDec(s, "TotalUtilized");
            decimal available   = ToDec(s, "TotalAvailable");
            decimal locked      = ToDec(s, "TotalLocked");

            int total    = ToInt(s, "TotalProjects");
            int pending  = ToInt(s, "PendingApproval");
            int approved = ToInt(s, "Approved");
            int rejected = ToInt(s, "Rejected");

            kTotalProjects.Text = total.ToString("N0");
            kCapexBudget.Text   = capexBudget.ToString("N0");
            kOpexBudget.Text    = opexBudget.ToString("N0");
            kUtilized.Text      = utilized.ToString("N0");
            kAvailable.Text     = available.ToString("N0");
            kLocked.Text        = locked.ToString("N0");
            kPending.Text       = pending.ToString("N0");
            kApproved.Text      = approved.ToString("N0");
            kRejected.Text      = rejected.ToString("N0");

            decimal totalBudget = capexBudget + opexBudget;
            int pct = totalBudget > 0 ? Math.Min(100, (int)Math.Round((utilized / totalBudget) * 100m)) : 0;
            litMeterPct.Text = pct.ToString() + "%";

            JsCapexBudget = capexBudget.ToString(CultureInfo.InvariantCulture);
            JsOpexBudget  = opexBudget.ToString(CultureInfo.InvariantCulture);
            JsUtilized    = utilized.ToString(CultureInfo.InvariantCulture);
            JsAvailable   = available.ToString(CultureInfo.InvariantCulture);
            JsLocked      = locked.ToString(CultureInfo.InvariantCulture);
            JsPending     = pending.ToString();
            JsApproved    = approved.ToString();
            JsRejected    = rejected.ToString();
            JsDraft       = (total - pending - approved - rejected).ToString();

            // ===== JIRA dashboard + charts =====
            // Optimised: only select the columns needed for in-memory aggregation
            DataTable jira = Db.Query("SELECT ISNULL(OverallStatus,'') AS OverallStatus, ISNULL(ProjectRAG,'') AS ProjectRAG, ISNULL(DemandType,'') AS DemandType, ISNULL(TechLead,'') AS TechLead, ISNULL(Manager,'') AS Manager FROM JiraIssues");
            int jt = jira.Rows.Count, jActive = 0;

            // Aggregations
            var ragCounts      = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var demandCounts   = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var techLeadCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var managerCounts  = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            foreach (DataRow r in jira.Rows)
            {
                string st = ColStr(r, "OverallStatus");
                if (!string.IsNullOrEmpty(st) && !st.Equals("Closed", StringComparison.OrdinalIgnoreCase)) jActive++;
                Bump(ragCounts,      Normalize(ColStr(r, "ProjectRAG"), "Unspecified"));
                Bump(demandCounts,   Normalize(ColStr(r, "DemandType"), "Unspecified"));
                Bump(techLeadCounts, Normalize(ColStr(r, "TechLead"),   "Unassigned"));
                Bump(managerCounts,  Normalize(ColStr(r, "Manager"),    "Unassigned"));
            }

            int jAmber = ragCounts.ContainsKey("Amber") ? ragCounts["Amber"] : 0;
            int jRed   = ragCounts.ContainsKey("Red")   ? ragCounts["Red"]   : 0;

            kJiraTotal.Text  = jt.ToString();
            kJiraActive.Text = jActive.ToString();
            kJiraAmber.Text  = jAmber.ToString();
            kJiraRed.Text    = jRed.ToString();

            // RAG ordered + color-mapped
            string[] ragOrder = new[] { "Red", "Amber", "Green", "Blue", "Unspecified" };
            var ragLbl = new List<string>(); var ragVal = new List<int>(); var ragClr = new List<string>();
            foreach (string rg in ragOrder)
                if (ragCounts.ContainsKey(rg)) { ragLbl.Add(rg); ragVal.Add(ragCounts[rg]); ragClr.Add(RagColor(rg)); }
            // Any unexpected RAG values land at the end
            foreach (var kv in ragCounts)
                if (Array.IndexOf(ragOrder, kv.Key) < 0) { ragLbl.Add(kv.Key); ragVal.Add(kv.Value); ragClr.Add("#94a3b8"); }
            JsRagLabels = ToJsArray(ragLbl);
            JsRagData   = ToJsIntArray(ragVal);
            JsRagColors = ToJsArray(ragClr);

            string dLbl, dVal, tLbl, tVal, mLbl, mVal;
            BuildTopN(demandCounts,   10, out dLbl, out dVal); JsDemandLabels   = dLbl; JsDemandData   = dVal;
            BuildTopN(techLeadCounts, 8,  out tLbl, out tVal); JsTechLeadLabels = tLbl; JsTechLeadData = tVal;
            BuildTopN(managerCounts,  8,  out mLbl, out mVal); JsManagerLabels  = mLbl; JsManagerData  = mVal;

            // SQL-driven bar charts (Demand Status + Platform-wise)
            var dsBars = JiraDashboardHelper.GetDemandStatusBars();
            JsDemandStatusLabels = JiraDashboardHelper.LabelsJs(dsBars);
            JsDemandStatusData   = JiraDashboardHelper.DataJs(dsBars);
            JsDemandStatusColors = JiraDashboardHelper.ColorsJs(dsBars);

            var plBars = JiraDashboardHelper.GetPlatformBars();
            JsPlatformLabels = JiraDashboardHelper.LabelsJs(plBars);
            JsPlatformData   = JiraDashboardHelper.DataJs(plBars);
            JsPlatformColors = JiraDashboardHelper.ColorsJs(plBars);

            // Req 4: Demands by Chief
            var chiefBars = JiraDashboardHelper.GetDemandsByChief();
            JsChiefLabels = JiraDashboardHelper.LabelsJs(chiefBars);
            JsChiefData   = JiraDashboardHelper.DataJs(chiefBars);
            JsChiefColors = JiraDashboardHelper.ColorsJs(chiefBars);

            // Req 4: Demands by Project Manager
            var mgrBars = JiraDashboardHelper.GetDemandsByManager();
            JsByMgrLabels = JiraDashboardHelper.LabelsJs(mgrBars);
            JsByMgrData   = JiraDashboardHelper.DataJs(mgrBars);
            JsByMgrColors = JiraDashboardHelper.ColorsJs(mgrBars);

            // Req 4: Demands by Technical Team
            var techBars = JiraDashboardHelper.GetDemandsByTechTeam();
            JsByTechLabels = JiraDashboardHelper.LabelsJs(techBars);
            JsByTechData   = JiraDashboardHelper.DataJs(techBars);
            JsByTechColors = JiraDashboardHelper.ColorsJs(techBars);

            // Req 4: Aging histogram
            var agingBars = JiraDashboardHelper.GetAgingHistogram();
            JsAgingLabels = JiraDashboardHelper.LabelsJs(agingBars);
            JsAgingData   = JiraDashboardHelper.DataJs(agingBars);
            JsAgingColors = JiraDashboardHelper.ColorsJs(agingBars);

            // Req 4: Visibility KPIs
            try { JsOnHoldCount  = JiraDashboardHelper.GetOnHoldDemands().Rows.Count.ToString(); } catch { }
            try { JsDeferredCount = JiraDashboardHelper.GetDeferredDemands().Rows.Count.ToString(); } catch { }
            try { JsConvertedCount = JiraDashboardHelper.GetConvertedDemands().Rows.Count.ToString(); } catch { }
            try { JsMissedCount  = JiraDashboardHelper.GetMissedDeliverables().Rows.Count.ToString(); } catch { }
            try { JsAgingCount   = JiraDashboardHelper.GetAgingDemands().Rows.Count.ToString(); } catch { }

            // New chart dimensions (Dashboard Redesign)
            var platVertBars = JiraDashboardHelper.GetPlatformVerticalBars();
            JsPlatVertLabels = JiraDashboardHelper.LabelsJs(platVertBars);
            JsPlatVertData   = JiraDashboardHelper.DataJs(platVertBars);
            JsPlatVertColors = JiraDashboardHelper.ColorsJs(platVertBars);

            var overallStatusBars = JiraDashboardHelper.GetOverallStatusBars();
            JsOverallStatusLabels = JiraDashboardHelper.LabelsJs(overallStatusBars);
            JsOverallStatusData   = JiraDashboardHelper.DataJs(overallStatusBars);
            JsOverallStatusColors = JiraDashboardHelper.ColorsJs(overallStatusBars);

            var schedRagBars = JiraDashboardHelper.GetScheduleRagBars();
            JsSchedRagLabels = JiraDashboardHelper.LabelsJs(schedRagBars);
            JsSchedRagData   = JiraDashboardHelper.DataJs(schedRagBars);
            JsSchedRagColors = JiraDashboardHelper.ColorsJs(schedRagBars);

            var demandOwnerBars = JiraDashboardHelper.GetDemandOwnerBars();
            JsDemandOwnerLabels = JiraDashboardHelper.LabelsJs(demandOwnerBars);
            JsDemandOwnerData   = JiraDashboardHelper.DataJs(demandOwnerBars);
            JsDemandOwnerColors = JiraDashboardHelper.ColorsJs(demandOwnerBars);

            var issueTypeBars = JiraDashboardHelper.GetIssueTypeBars();
            JsIssueTypeLabels = JiraDashboardHelper.LabelsJs(issueTypeBars);
            JsIssueTypeData   = JiraDashboardHelper.DataJs(issueTypeBars);
            JsIssueTypeColors = JiraDashboardHelper.ColorsJs(issueTypeBars);

            var assignedPMBars = JiraDashboardHelper.GetAssignedPMBars();
            JsAssignedPMLabels = JiraDashboardHelper.LabelsJs(assignedPMBars);
            JsAssignedPMData   = JiraDashboardHelper.DataJs(assignedPMBars);
            JsAssignedPMColors = JiraDashboardHelper.ColorsJs(assignedPMBars);

            // SQL-driven RAG distribution (replaces in-memory RAG for charts)
            var ragBarsSql = JiraDashboardHelper.GetProjectRagBars();
            JsRagLabels = JiraDashboardHelper.LabelsJs(ragBarsSql);
            JsRagData   = JiraDashboardHelper.DataJs(ragBarsSql);
            JsRagColors = JiraDashboardHelper.ColorsJs(ragBarsSql);

            // Req5: Build DMGT -> DIBITP drilldown series for Chief / Manager / Tech charts
            BuildHierarchyDrilldown();

            // Req5: Last refreshed timestamp - prefer Req6 DashboardReport timestamp
            try
            {
                DateTime? rpt = ReportRepo.GetLastRefreshed();
                if (rpt.HasValue)
                {
                    litLastRefreshed.Text = rpt.Value.ToString("dd-MMM-yyyy hh:mm tt") + " (pre-aggregated)";
                }
                else
                {
                    DataRow ts = Db.QueryRow("SELECT MAX(LastSyncDate) AS LastSync FROM DashboardSummary");
                    DateTime when = (ts != null && ts["LastSync"] != DBNull.Value)
                        ? Convert.ToDateTime(ts["LastSync"]) : DateTime.Now;
                    litLastRefreshed.Text = when.ToString("dd-MMM-yyyy hh:mm tt");
                }
            }
            catch
            {
                litLastRefreshed.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt");
            }

            swDash.Stop();
            DashboardLog.Log("DashboardLoad", "Completed", (int)swDash.ElapsedMilliseconds);
            if (jt == 0) DashboardLog.Log("SectionEmpty", "JiraIssues empty - dashboard rendered with zeroes", null);
        }
        public static string RemoveSpecialCharacters(string input)
        {
            return Regex.Replace(input, @"[^a-zA-Z0-9,\- ]", "");
        }
        // Req5: Build Highcharts drilldown series mapping DMGT parent -> DIBITP children
        private void BuildHierarchyDrilldown()
        {
            try
            {
                StringBuilder chief = new StringBuilder("[");
                StringBuilder mgr = new StringBuilder("[");
                StringBuilder tech = new StringBuilder("[");

                // Pull all DMGT->DIBITP child mappings grouped by category
                string sql = @"
SELECT ISNULL(p.ChiefNameMapping,'Unassigned') AS Chief,
       ISNULL(p.Manager,'Unassigned') AS Manager,
       ISNULL(p.TechLead,'Unassigned') AS TechLead,
       c.JiraKey AS ChildKey, ISNULL(c.Summary,'') AS ChildSummary
FROM JiraIssues p
LEFT JOIN JiraIssues c ON c.ParentJiraID = p.JiraKey AND c.ProjectKey='DIBITP'
WHERE p.ProjectKey='DMGT'
ORDER BY p.JiraKey";
                DataTable dt = Db.Query(sql);

                // Group children by parent category
                var chiefMap = new Dictionary<string, List<KeyValuePair<string, string>>>();
                var mgrMap = new Dictionary<string, List<KeyValuePair<string, string>>>();
                var techMap = new Dictionary<string, List<KeyValuePair<string, string>>>();

                foreach (DataRow r in dt.Rows)
                {
                    string chiefName = r["Chief"].ToString();
                    string mgrName = r["Manager"].ToString();
                    string techName = r["TechLead"].ToString();
                    string childKey = r["ChildKey"] == DBNull.Value ? "" : r["ChildKey"].ToString();
                    string childSum = r["ChildSummary"].ToString();
                    if (string.IsNullOrEmpty(childKey)) continue;

                    AddDrill(chiefMap, chiefName, childKey, childSum);
                    AddDrill(mgrMap, mgrName, childKey, childSum);
                    AddDrill(techMap, techName, childKey, childSum);
                }

                JsHierDrillJson = "{\"chief\":" + SerializeDrill(JsChiefLabels, chiefMap, "chief_") +
                                 ",\"manager\":" + SerializeDrill(JsByMgrLabels, mgrMap, "mgr_") +
                                 ",\"tech\":" + SerializeDrill(JsByTechLabels, techMap, "tech_") + "}";
            }
            catch
            {
                JsHierDrillJson = "{\"chief\":[],\"manager\":[],\"tech\":[]}";
            }
        }

        private static void AddDrill(Dictionary<string, List<KeyValuePair<string, string>>> map,
            string parent, string key, string summary)
        {
            if (!map.ContainsKey(parent)) map[parent] = new List<KeyValuePair<string, string>>();
            map[parent].Add(new KeyValuePair<string, string>(key, summary));
        }

        private static string SerializeDrill(string labelsJsArray,
            Dictionary<string, List<KeyValuePair<string, string>>> map, string idPrefix)
        {
            // labelsJsArray is e.g. ["A","B"] — parse back so index aligns with chart drilldown id
            List<string> labels = new List<string>();
            string trimmed = (labelsJsArray ?? "[]").Trim();
            if (trimmed.Length > 2)
            {
                string inside = trimmed.Substring(1, trimmed.Length - 2);
                // naive split: labels are pure strings; quotes already escaped by JsArr
                int i = 0;
                while (i < inside.Length)
                {
                    if (inside[i] != '"') { i++; continue; }
                    int j = i + 1;
                    StringBuilder cur = new StringBuilder();
                    while (j < inside.Length && inside[j] != '"')
                    {
                        if (inside[j] == '\\' && j + 1 < inside.Length) { cur.Append(inside[j + 1]); j += 2; }
                        else { cur.Append(inside[j]); j++; }
                    }
                    labels.Add(cur.ToString());
                    i = j + 1;
                }
            }

            StringBuilder sb = new StringBuilder("[");
            for (int idx = 0; idx < labels.Count; idx++)
            {
                if (idx > 0) sb.Append(",");
                string name = labels[idx];
                sb.Append("{\"id\":\"").Append(idPrefix).Append(idx).Append("\",");
                sb.Append("\"name\":\"").Append(JsEscape(name)).Append("\",\"data\":[");
                if (map.ContainsKey(name))
                {
                    var list = map[name];
                    for (int k = 0; k < list.Count; k++)
                    {
                        if (k > 0) sb.Append(",");
                        string label = list[k].Key + ": " +
                            (list[k].Value.Length > 40 ? list[k].Value.Substring(0, 40) + "..." : list[k].Value);
                        sb.Append("[\"").Append(JsEscape(label)).Append("\",1]");
                    }
                }
                sb.Append("]}");
            }
            sb.Append("]");
            return sb.ToString();
        }

        // ===== Helpers =====
        private static string ColStr(DataRow r, string c)
        {
            return (!r.Table.Columns.Contains(c) || r[c] == DBNull.Value) ? "" : r[c].ToString().Trim();
        }
        private static string Normalize(string v, string fallback)
        {
            return string.IsNullOrWhiteSpace(v) ? fallback : v;
        }
        private static void Bump(Dictionary<string, int> d, string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            if (d.ContainsKey(key)) d[key]++; else d[key] = 1;
        }
        private static string RagColor(string rag)
        {
            if (string.Equals(rag, "Red",   StringComparison.OrdinalIgnoreCase)) return "#dc2626";
            if (string.Equals(rag, "Amber", StringComparison.OrdinalIgnoreCase)) return "#f59e0b";
            if (string.Equals(rag, "Green", StringComparison.OrdinalIgnoreCase)) return "#16a34a";
            if (string.Equals(rag, "Blue",  StringComparison.OrdinalIgnoreCase)) return "#0b6efd";
            return "#94a3b8";
        }
        private static void BuildTopN(Dictionary<string, int> source, int top, out string labels, out string values)
        {
            var list = new List<KeyValuePair<string, int>>(source);
            list.Sort((a, b) => b.Value.CompareTo(a.Value));
            var lbl = new List<string>(); var val = new List<int>();
            int n = Math.Min(top, list.Count);
            for (int i = 0; i < n; i++) { lbl.Add(list[i].Key); val.Add(list[i].Value); }
            if (list.Count > n)
            {
                int other = 0;
                for (int i = n; i < list.Count; i++) other += list[i].Value;
                if (other > 0) { lbl.Add("Other"); val.Add(other); }
            }
            labels = ToJsArray(lbl);
            values = ToJsIntArray(val);
        }
        private static string ToJsArray(List<string> items)
        {
            var sb = new StringBuilder("[");
            for (int i = 0; i < items.Count; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append('"').Append(JsEscape(items[i])).Append('"');
            }
            sb.Append(']');
            return sb.ToString();
        }
        private static string ToJsIntArray(List<int> items)
        {
            var sb = new StringBuilder("[");
            for (int i = 0; i < items.Count; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append(items[i]);
            }
            sb.Append(']');
            return sb.ToString();
        }
        private static string JsEscape(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", " ").Replace("\n", " ");
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            string ptype = ddlType.SelectedValue;
            string status = ddlStatus.SelectedValue;
            DataTable dt = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype,
                                                   status == "ALL" ? null : status);
            ExcelHelper.ExportToExcel(Response, dt, "DFM_Dashboard_Projects_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        private static int ToInt(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return 0;
            return Convert.ToInt32(r[col]);
        }
        private static decimal ToDec(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return 0m;
            return Convert.ToDecimal(r[col]);
        }
    }
}
