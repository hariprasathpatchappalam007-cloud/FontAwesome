<%@ Page Title="Dashboard" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true"
    CodeBehind="Default.aspx.cs" Inherits="DFM.DefaultPage" %>

<asp:Content ID="HeadCt" ContentPlaceHolderID="HeadContent" runat="server">
</asp:Content>

<asp:Content ID="MainCt" ContentPlaceHolderID="MainContent" runat="server">
    <h1 class="page-title">
        <span class="glyphicon glyphicon-dashboard"></span> Dashboard
        <span class="dashboard-timestamp">
            <span class="glyphicon glyphicon-refresh"></span>
            Data Last Updated: <asp:Literal ID="litLastRefreshed" runat="server" />
        </span>
    </h1>

    <!-- Req5: horizontal multi-select filter panel -->
    <div class="horizontal-filter-panel">
        <div class="filter-grid">
            <div class="form-group">
                <label>Project Type</label>
                <asp:DropDownList ID="ddlType" runat="server" CssClass="form-control no-select2" AutoPostBack="true"
                    OnSelectedIndexChanged="Filter_Changed">
                    <asp:ListItem Text="All" Value="ALL" />
                    <asp:ListItem Text="CAPEX" Value="CAPEX" />
                    <asp:ListItem Text="OPEX" Value="OPEX" />
                    <asp:ListItem Text="AMC" Value="AMC" />
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>Workflow Status</label>
                <asp:DropDownList ID="ddlStatus" runat="server" CssClass="form-control no-select2" AutoPostBack="true"
                    OnSelectedIndexChanged="Filter_Changed">
                    <asp:ListItem Text="All" Value="ALL" />
                    <asp:ListItem Text="Draft" Value="Draft" />
                    <asp:ListItem Text="Pending" Value="Pending" />
                    <asp:ListItem Text="Approved" Value="Approved" />
                    <asp:ListItem Text="Rejected" Value="Rejected" />
                </asp:DropDownList>
            </div>
            <div class="form-group">
                <label>Platform</label>
                <asp:ListBox ID="lbPlatform" runat="server" CssClass="form-control multi-select" SelectionMode="Multiple" />
            </div>
            <div class="form-group">
                <label>Vertical</label>
                <asp:ListBox ID="lbVertical" runat="server" CssClass="form-control multi-select" SelectionMode="Multiple" />
            </div>
            <div class="form-group">
                <label>Project Manager</label>
                <asp:ListBox ID="lbManager" runat="server" CssClass="form-control multi-select" SelectionMode="Multiple" />
            </div>
            <div class="form-group">
                <label>Tech / SME Lead</label>
                <asp:ListBox ID="lbTechLead" runat="server" CssClass="form-control multi-select" SelectionMode="Multiple" />
            </div>
            <div class="form-group">
                <label>RAG Status</label>
                <asp:ListBox ID="lbRag" runat="server" CssClass="form-control multi-select" SelectionMode="Multiple">
                    <asp:ListItem Text="Green" Value="Green" />
                    <asp:ListItem Text="Amber" Value="Amber" />
                    <asp:ListItem Text="Red" Value="Red" />
                </asp:ListBox>
            </div>
            <div class="form-group">
                <label>Priority</label>
                <asp:ListBox ID="lbPriority" runat="server" CssClass="form-control multi-select" SelectionMode="Multiple">
                    <asp:ListItem Text="Highest" Value="Highest" />
                    <asp:ListItem Text="High"    Value="High" />
                    <asp:ListItem Text="Medium"  Value="Medium" />
                    <asp:ListItem Text="Low"     Value="Low" />
                    <asp:ListItem Text="Lowest"  Value="Lowest" />
                </asp:ListBox>
            </div>
            <div class="form-group">
                <label>From Date</label>
                <asp:TextBox ID="txtFromDate" runat="server" CssClass="form-control" TextMode="Date" />
            </div>
            <div class="form-group">
                <label>To Date</label>
                <asp:TextBox ID="txtToDate" runat="server" CssClass="form-control" TextMode="Date" />
            </div>
        </div>
        <div class="filter-actions">
            <asp:Button ID="btnApply" runat="server" Text="Apply Filters" CssClass="btn btn-primary"
                OnClick="Filter_Changed" OnClientClick="DFM.showLoader('Applying filters...'); DFM.logScenario('FilterApplied','user clicked Apply');" />
            <asp:Button ID="btnRefresh" runat="server" Text="Refresh" CssClass="btn btn-secondary"
                OnClick="Filter_Changed" OnClientClick="DFM.showLoader('Refreshing...'); DFM.logScenario('DashboardRefresh','user clicked Refresh');" />
            <asp:Button ID="btnExport" runat="server" Text="Export Excel" CssClass="btn btn-success"
                OnClick="btnExport_Click" OnClientClick="DFM.showLoader('Exporting...'); DFM.logScenario('ExportClicked','user clicked Export');" />
        </div>
    </div>

    <div>


    <!-- Req 47, 50: smaller KPI cards -->
    <div class="kpi-grid">
        <div class="kpi-card kpi-blue">
            <span class="glyphicon glyphicon-folder-open kpi-icon"></span>
            <div class="kpi-label">Projects</div>
            <div class="kpi-value"><asp:Literal ID="kTotalProjects" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="glyphicon glyphicon-briefcase kpi-icon"></span>
            <div class="kpi-label">CAPEX Budget</div>
            <div class="kpi-value"><asp:Literal ID="kCapexBudget" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-teal">
            <span class="glyphicon glyphicon-usd kpi-icon"></span>
            <div class="kpi-label">OPEX Budget</div>
            <div class="kpi-value"><asp:Literal ID="kOpexBudget" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-orange">
            <span class="glyphicon glyphicon-stats kpi-icon"></span>
            <div class="kpi-label">Utilized</div>
            <div class="kpi-value"><asp:Literal ID="kUtilized" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-purple">
            <span class="glyphicon glyphicon-lock kpi-icon"></span>
            <div class="kpi-label">Locked</div>
            <div class="kpi-value"><asp:Literal ID="kLocked" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-pink">
            <span class="glyphicon glyphicon-ok kpi-icon"></span>
            <div class="kpi-label">Available</div>
            <div class="kpi-value"><asp:Literal ID="kAvailable" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-slate">
            <span class="glyphicon glyphicon-hourglass kpi-icon"></span>
            <div class="kpi-label">Pending</div>
            <div class="kpi-value"><asp:Literal ID="kPending" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-green">
            <span class="glyphicon glyphicon-thumbs-up kpi-icon"></span>
            <div class="kpi-label">Approved</div>
            <div class="kpi-value"><asp:Literal ID="kApproved" runat="server" /></div>
        </div>
        <div class="kpi-card kpi-red">
            <span class="glyphicon glyphicon-thumbs-down kpi-icon"></span>
            <div class="kpi-label">Rejected</div>
            <div class="kpi-value"><asp:Literal ID="kRejected" runat="server" /></div>
        </div>
    </div>

    <!-- Issue 5: 3-column chart row (slim bar + meter gauge + status mix) -->
    <div class="chart-row-3">
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-tasks"></span> Budget vs Utilization</h3>
            <div style="height:200px;"><canvas id="chartBudget"></canvas></div>
        </div>
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-dashboard"></span> Budget Utilization</h3>
            <div class="meter-gauge-wrap" style="height:200px;">
                <canvas id="meterGauge"></canvas>
                <div class="meter-gauge-label"><asp:Literal ID="litMeterPct" runat="server" /></div>
                <div class="meter-gauge-sub">utilized of total budget</div>
            </div>
        </div>
        <div class="card-panel">
            <h3><span class="glyphicon glyphicon-list-alt"></span> Status Mix</h3>
            <div style="height:200px;"><canvas id="chartStatus"></canvas></div>
        </div>
    </div>

    <!-- ====== JIRA Analytics Dashboard (Redesigned) ====== -->
    <div class="jira-analytics">

        <%-- Section: JIRA Overview KPIs --%>
        <div class="jira-section-title">
            <span class="glyphicon glyphicon-link"></span> JIRA Analytics Overview
        </div>
        <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(130px,1fr));">
            <div class="kpi-card kpi-blue">
                <span class="glyphicon glyphicon-th-list kpi-icon"></span>
                <div class="kpi-label">Total Issues</div>
                <div class="kpi-value"><asp:Literal ID="kJiraTotal" runat="server" /></div>
            </div>
            <div class="kpi-card kpi-green">
                <span class="glyphicon glyphicon-play kpi-icon"></span>
                <div class="kpi-label">Active</div>
                <div class="kpi-value"><asp:Literal ID="kJiraActive" runat="server" /></div>
            </div>
            <div class="kpi-card kpi-red">
                <span class="glyphicon glyphicon-exclamation-sign kpi-icon"></span>
                <div class="kpi-label">Red RAG</div>
                <div class="kpi-value"><asp:Literal ID="kJiraRed" runat="server" /></div>
            </div>
            <div class="kpi-card kpi-orange">
                <span class="glyphicon glyphicon-warning-sign kpi-icon"></span>
                <div class="kpi-label">Amber RAG</div>
                <div class="kpi-value"><asp:Literal ID="kJiraAmber" runat="server" /></div>
            </div>
            <div class="kpi-card kpi-slate">
                <span class="glyphicon glyphicon-pause kpi-icon"></span>
                <div class="kpi-label">On Hold</div>
                <div class="kpi-value"><%= JsOnHoldCount %></div>
            </div>
            <div class="kpi-card kpi-purple">
                <span class="glyphicon glyphicon-time kpi-icon"></span>
                <div class="kpi-label">Deferred</div>
                <div class="kpi-value"><%= JsDeferredCount %></div>
            </div>
            <div class="kpi-card kpi-pink">
                <span class="glyphicon glyphicon-hourglass kpi-icon"></span>
                <div class="kpi-label">Aging (3m+)</div>
                <div class="kpi-value"><%= JsAgingCount %></div>
            </div>
            <div class="kpi-card kpi-teal">
                <span class="glyphicon glyphicon-alert kpi-icon"></span>
                <div class="kpi-label">Missed</div>
                <div class="kpi-value"><%= JsMissedCount %></div>
            </div>
            <div class="kpi-card kpi-green">
                <span class="glyphicon glyphicon-transfer kpi-icon"></span>
                <div class="kpi-label">Converted</div>
                <div class="kpi-value"><%= JsConvertedCount %></div>
            </div>
        </div>

        <%-- Section: Status & Schedule Analysis --%>
        <div class="jira-section-title">
            <span class="glyphicon glyphicon-tasks"></span> Status &amp; Schedule Analysis
        </div>
        <div class="jira-row-3">
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-stats"></span> Demand Status Summary</div>
                <div class="jira-chart-container" style="height:300px;"><canvas id="chartDemandStatus"></canvas></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-list-alt"></span> Overall Status Distribution</div>
                <div class="jira-chart-container" style="height:300px;"><canvas id="chartOverallStatus"></canvas></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-hourglass"></span> Demand Aging Analysis</div>
                <div id="hcAging" style="height:300px;"></div>
            </div>
        </div>

        <%-- Section: Platform & Technology --%>
        <div class="jira-section-title">
            <span class="glyphicon glyphicon-th-large"></span> Platform &amp; Technology
        </div>
        <div class="jira-row-2">
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-hdd"></span> Platform-wise Demand</div>
                <div class="jira-chart-container" style="height:380px;"><canvas id="chartPlatform"></canvas></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-tower"></span> Platform Vertical</div>
                <div class="jira-chart-container" style="height:380px;"><canvas id="chartPlatVert"></canvas></div>
            </div>
        </div>

        <%-- Section: RAG & Issue Analysis --%>
        <div class="jira-section-title">
            <span class="glyphicon glyphicon-signal"></span> RAG &amp; Issue Analysis
        </div>
        <div class="jira-grid-4">
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-alert"></span> Project RAG</div>
                <div class="jira-chart-container" style="height:240px;"><canvas id="chartRag"></canvas></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-time"></span> Schedule RAG</div>
                <div class="jira-chart-container" style="height:240px;"><canvas id="chartSchedRag"></canvas></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-tag"></span> Issue Type</div>
                <div class="jira-chart-container" style="height:240px;"><canvas id="chartIssueType"></canvas></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-flag"></span> Demand Type</div>
                <div class="jira-chart-container" style="height:240px;"><canvas id="chartDemand"></canvas></div>
            </div>
        </div>

        <%-- Section: Team Workload --%>
        <div class="jira-section-title">
            <span class="glyphicon glyphicon-user"></span> Team Workload
        </div>
        <div class="jira-row-2">
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-wrench"></span> Tech Lead Workload</div>
                <div class="jira-chart-container" style="height:350px;"><canvas id="chartTechLead"></canvas></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-briefcase"></span> Manager Workload</div>
                <div class="jira-chart-container" style="height:350px;"><canvas id="chartManager"></canvas></div>
            </div>
        </div>
        <div class="jira-row-2">
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-screenshot"></span> Assigned Project Manager</div>
                <div class="jira-chart-container" style="height:350px;"><canvas id="chartAssignedPM"></canvas></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-bullhorn"></span> Demand Owner</div>
                <div class="jira-chart-container" style="height:350px;"><canvas id="chartDemandOwner"></canvas></div>
            </div>
        </div>

        <%-- Section: Drill-down Analysis --%>
        <div class="jira-section-title">
            <span class="glyphicon glyphicon-zoom-in"></span> Drill-down Analysis
        </div>
        <div class="jira-row-2">
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-king"></span> Demands by Chief (Drill-down)</div>
                <div id="hcChief" style="height:350px;"></div>
            </div>
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-briefcase"></span> Demands by Project Manager (Drill-down)</div>
                <div id="hcManager" style="height:350px;"></div>
            </div>
        </div>
        <div class="jira-row-2">
            <div class="jira-panel">
                <div class="jira-panel-title"><span class="glyphicon glyphicon-wrench"></span> Demands by Technical Team (Drill-down)</div>
                <div id="hcTechTeam" style="height:350px;"></div>
            </div>
            <div class="jira-panel">&nbsp;</div>
        </div>

    </div>

    </div><!-- end main dashboard content -->

    <script>
        (function () {
            var capexBudget = <%= JsCapexBudget %>;
            var opexBudget  = <%= JsOpexBudget %>;
            var utilized    = <%= JsUtilized %>;
            var available   = <%= JsAvailable %>;
            var locked      = <%= JsLocked %>;
            var totalBudget = capexBudget + opexBudget;
            var pct = totalBudget > 0 ? Math.min(100, Math.round((utilized / totalBudget) * 100)) : 0;

            var c1 = document.getElementById('chartBudget');
            if (c1 && window.Chart) {
                new Chart(c1, {
                    type: 'bar',
                    data: {
                        labels: ['CAPEX','OPEX','Utilized','Locked','Available'],
                        datasets: [{
                            label: 'Amount',
                            data: [capexBudget, opexBudget, utilized, locked, available],
                            backgroundColor: ['#1e40af','#0e7490','#b45309','#6b21a8','#15803d'],
                            barThickness: 14,
                            maxBarThickness: 16,
                            borderRadius: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { grid: { color: 'rgba(0,0,0,0.05)' } },
                            y: { grid: { display: false } }
                        }
                    }
                });
            }
            var cs = document.getElementById('chartStatus');
            var draftCnt    = <%= JsDraft %>;
            var pendingCnt  = <%= JsPending %>;
            var approvedCnt = <%= JsApproved %>;
            var rejectedCnt = <%= JsRejected %>;
            if (cs && window.Chart) {
                new Chart(cs, {
                    type: 'doughnut',
                    data: {
                        labels: ['Draft','Pending','Approved','Rejected'],
                        datasets: [{
                            data: [draftCnt, pendingCnt, approvedCnt, rejectedCnt],
                            backgroundColor: ['#94a3b8','#b45309','#15803d','#b91c1c'],
                            borderWidth: 1, borderColor: '#fff'
                        }]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false, cutout: '55%',
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            }

            // ===== JIRA Analytics Charts (Redesigned) =====
            var ragLabels    = <%= JsRagLabels %>;
            var ragData      = <%= JsRagData %>;
            var ragColors    = <%= JsRagColors %>;
            var demandLabels = <%= JsDemandLabels %>;
            var demandData   = <%= JsDemandData %>;
            var techLabels   = <%= JsTechLeadLabels %>;
            var techData     = <%= JsTechLeadData %>;
            var mgrLabels    = <%= JsManagerLabels %>;
            var mgrData      = <%= JsManagerData %>;

            var paletteBar = ['#1e40af','#0e7490','#15803d','#b45309','#6b21a8','#be185d','#0891b2','#dc2626','#475569','#7c3aed'];
            var paletteSlice = ['#3b82f6','#06b6d4','#22c55e','#f97316','#a855f7','#ec4899','#0ea5e9','#ef4444','#64748b','#8b5cf6','#fbbf24','#10b981'];
            function ensureColors(arr, base) {
                var out = [];
                for (var i = 0; i < arr.length; i++) out.push(base[i % base.length]);
                return out;
            }

            // --- Demand Status bar ---
            var dsLabels = <%= JsDemandStatusLabels %>;
            var dsData   = <%= JsDemandStatusData %>;
            var dsColors = <%= JsDemandStatusColors %>;
            (function(el) {
                if (!el || !window.Chart || !dsLabels.length) return;
                new Chart(el, {
                    type: 'bar',
                    data: { labels: dsLabels, datasets: [{ label: 'Issues', data: dsData, backgroundColor: dsColors, borderColor: '#0d1b3d', borderWidth: 1, barThickness: 28, maxBarThickness: 36 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { grid: { display: false }, ticks: { font: { size: 11, weight: 'bold' } } },
                            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { precision: 0 } }
                        }
                    }
                });
            })(document.getElementById('chartDemandStatus'));

            // --- Overall Status horizontal bar ---
            var osLabels = <%= JsOverallStatusLabels %>;
            var osData   = <%= JsOverallStatusData %>;
            var osColors = <%= JsOverallStatusColors %>;
            (function(el) {
                if (!el || !window.Chart || !osLabels.length) return;
                new Chart(el, {
                    type: 'bar',
                    data: { labels: osLabels, datasets: [{ label: 'Issues', data: osData, backgroundColor: osColors, borderColor: '#0d1b3d', borderWidth: 1, barThickness: 16, maxBarThickness: 20 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { precision: 0 } },
                            y: { grid: { display: false }, ticks: { font: { size: 10 } } }
                        }
                    }
                });
            })(document.getElementById('chartOverallStatus'));

            // --- Platform-wise horizontal bar ---
            var plLabels = <%= JsPlatformLabels %>;
            var plData   = <%= JsPlatformData %>;
            var plColors = <%= JsPlatformColors %>;
            (function(el) {
                if (!el || !window.Chart || !plLabels.length) return;
                new Chart(el, {
                    type: 'bar',
                    data: { labels: plLabels, datasets: [{ label: 'Issues', data: plData, backgroundColor: plColors, borderColor: '#0d1b3d', borderWidth: 1, barThickness: 18, maxBarThickness: 22 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { precision: 0 } },
                            y: { grid: { display: false }, ticks: { font: { size: 11, weight: 'bold' } } }
                        }
                    }
                });
            })(document.getElementById('chartPlatform'));

            // --- Platform Vertical horizontal bar ---
            var pvLabels = <%= JsPlatVertLabels %>;
            var pvData   = <%= JsPlatVertData %>;
            var pvColors = <%= JsPlatVertColors %>;
            (function(el) {
                if (!el || !window.Chart || !pvLabels.length) return;
                new Chart(el, {
                    type: 'bar',
                    data: { labels: pvLabels, datasets: [{ label: 'Issues', data: pvData, backgroundColor: pvColors, borderColor: '#0d1b3d', borderWidth: 1, barThickness: 18, maxBarThickness: 22 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { precision: 0 } },
                            y: { grid: { display: false }, ticks: { font: { size: 11, weight: 'bold' } } }
                        }
                    }
                });
            })(document.getElementById('chartPlatVert'));

            // --- RAG doughnut ---
            (function(el) {
                if (!el || !window.Chart || !ragLabels.length) return;
                new Chart(el, {
                    type: 'doughnut',
                    data: { labels: ragLabels, datasets: [{ data: ragData, backgroundColor: ragColors, borderWidth: 2, borderColor: '#fff' }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, cutout: '55%',
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            })(document.getElementById('chartRag'));

            // --- Schedule RAG doughnut ---
            var srLabels = <%= JsSchedRagLabels %>;
            var srData   = <%= JsSchedRagData %>;
            var srColors = <%= JsSchedRagColors %>;
            (function(el) {
                if (!el || !window.Chart || !srLabels.length) return;
                new Chart(el, {
                    type: 'doughnut',
                    data: { labels: srLabels, datasets: [{ data: srData, backgroundColor: srColors, borderWidth: 2, borderColor: '#fff' }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, cutout: '55%',
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            })(document.getElementById('chartSchedRag'));

            // --- Issue Type doughnut ---
            var itLabels = <%= JsIssueTypeLabels %>;
            var itData   = <%= JsIssueTypeData %>;
            var itColors = <%= JsIssueTypeColors %>;
            (function(el) {
                if (!el || !window.Chart || !itLabels.length) return;
                new Chart(el, {
                    type: 'doughnut',
                    data: { labels: itLabels, datasets: [{ data: itData, backgroundColor: itColors, borderWidth: 2, borderColor: '#fff' }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, cutout: '55%',
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            })(document.getElementById('chartIssueType'));

            // --- Demand Type pie ---
            (function(el) {
                if (!el || !window.Chart || !demandLabels.length) return;
                new Chart(el, {
                    type: 'pie',
                    data: { labels: demandLabels, datasets: [{ data: demandData, backgroundColor: ensureColors(demandLabels, paletteSlice), borderWidth: 2, borderColor: '#fff' }] },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } }
                    }
                });
            })(document.getElementById('chartDemand'));

            // --- Tech Lead horizontal bar ---
            (function(el) {
                if (!el || !window.Chart || !techLabels.length) return;
                new Chart(el, {
                    type: 'bar',
                    data: { labels: techLabels, datasets: [{ label: 'Issues', data: techData, backgroundColor: ensureColors(techLabels, paletteBar), barThickness: 14, maxBarThickness: 16 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: { x: { grid: { color: 'rgba(0,0,0,0.05)' } }, y: { grid: { display: false }, ticks: { font: { size: 10 } } } }
                    }
                });
            })(document.getElementById('chartTechLead'));

            // --- Manager horizontal bar ---
            (function(el) {
                if (!el || !window.Chart || !mgrLabels.length) return;
                new Chart(el, {
                    type: 'bar',
                    data: { labels: mgrLabels, datasets: [{ label: 'Issues', data: mgrData, backgroundColor: ensureColors(mgrLabels, paletteBar), barThickness: 14, maxBarThickness: 16 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: { x: { grid: { color: 'rgba(0,0,0,0.05)' } }, y: { grid: { display: false }, ticks: { font: { size: 10 } } } }
                    }
                });
            })(document.getElementById('chartManager'));

            // --- Assigned PM horizontal bar ---
            var apmLabels = <%= JsAssignedPMLabels %>;
            var apmData   = <%= JsAssignedPMData %>;
            var apmColors = <%= JsAssignedPMColors %>;
            (function(el) {
                if (!el || !window.Chart || !apmLabels.length) return;
                new Chart(el, {
                    type: 'bar',
                    data: { labels: apmLabels, datasets: [{ label: 'Issues', data: apmData, backgroundColor: apmColors, barThickness: 14, maxBarThickness: 16 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: { x: { grid: { color: 'rgba(0,0,0,0.05)' } }, y: { grid: { display: false }, ticks: { font: { size: 10 } } } }
                    }
                });
            })(document.getElementById('chartAssignedPM'));

            // --- Demand Owner horizontal bar ---
            var doLabels = <%= JsDemandOwnerLabels %>;
            var doData   = <%= JsDemandOwnerData %>;
            var doColors = <%= JsDemandOwnerColors %>;
            (function(el) {
                if (!el || !window.Chart || !doLabels.length) return;
                new Chart(el, {
                    type: 'bar',
                    data: { labels: doLabels, datasets: [{ label: 'Issues', data: doData, backgroundColor: doColors, barThickness: 14, maxBarThickness: 16 }] },
                    options: {
                        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
                        plugins: { legend: { display: false } },
                        scales: { x: { grid: { color: 'rgba(0,0,0,0.05)' } }, y: { grid: { display: false }, ticks: { font: { size: 10 } } } }
                    }
                });
            })(document.getElementById('chartDemandOwner'));

            // Req 49: Meter Gauge for budget utilization (half-doughnut)
            var c2 = document.getElementById('meterGauge');
            if (c2 && window.Chart) {
                var gaugeColor = pct < 60 ? '#15803d' : (pct < 85 ? '#b45309' : '#b91c1c');
                new Chart(c2, {
                    type: 'doughnut',
                    data: {
                        labels: ['Utilized','Remaining'],
                        datasets: [{
                            data: [pct, 100 - pct],
                            backgroundColor: [gaugeColor, '#e5e7eb'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        rotation: -90, circumference: 180, cutout: '72%',
                        plugins: { legend: { display: false }, tooltip: { enabled: false } }
                    }
                });
            }

            // ===== Highcharts Drill-down Charts =====
            if (window.Highcharts) {
                Highcharts.setOptions({
                    chart: { style: { fontFamily: "'Segoe UI', 'Inter', Arial, sans-serif" } },
                    credits: { enabled: false },
                    accessibility: { enabled: true, announceNewData: { enabled: true } },
                    lang: { drillUpText: '◁ Back to {series.name}' }
                });

                var hierDrill = <%= JsHierDrillJson %>;

                // Demands by Chief - drill-down
                var chiefLabels = <%= JsChiefLabels %>;
                var chiefData   = <%= JsChiefData %>;
                var chiefColors = <%= JsChiefColors %>;
                if (chiefLabels.length && document.getElementById('hcChief')) {
                    var chiefSeries = [];
                    for (var i = 0; i < chiefLabels.length; i++) {
                        chiefSeries.push({ name: chiefLabels[i], y: chiefData[i], color: chiefColors[i], drilldown: 'chief_' + i });
                    }
                    Highcharts.chart('hcChief', {
                        chart: { type: 'column' },
                        title: { text: null },
                        xAxis: { type: 'category', labels: { style: { fontSize: '11px', fontWeight: 'bold' } } },
                        yAxis: { title: { text: 'Demands' }, allowDecimals: false },
                        legend: { enabled: false },
                        plotOptions: { series: { borderWidth: 1, borderColor: '#0d1b3d', dataLabels: { enabled: true, format: '{point.y}', style: { fontWeight: 'bold' } }, cursor: 'pointer' } },
                        series: [{ name: 'DMGT Demands', data: chiefSeries, colorByPoint: true }],
                        drilldown: { series: (hierDrill && hierDrill.chief) ? hierDrill.chief : [] }
                    });
                }

                // Demands by Project Manager - drill-down
                var byMgrLabels = <%= JsByMgrLabels %>;
                var byMgrData   = <%= JsByMgrData %>;
                var byMgrColors = <%= JsByMgrColors %>;
                if (byMgrLabels.length && document.getElementById('hcManager')) {
                    var mgrSeries2 = [];
                    for (var i = 0; i < byMgrLabels.length; i++) {
                        mgrSeries2.push({ name: byMgrLabels[i], y: byMgrData[i], color: byMgrColors[i], drilldown: 'mgr_' + i });
                    }
                    Highcharts.chart('hcManager', {
                        chart: { type: 'bar' },
                        title: { text: null },
                        xAxis: { type: 'category', labels: { style: { fontSize: '11px' } } },
                        yAxis: { title: { text: 'Demands' }, allowDecimals: false },
                        legend: { enabled: false },
                        plotOptions: { series: { borderWidth: 1, borderColor: '#0d1b3d', dataLabels: { enabled: true, format: '{point.y}' }, cursor: 'pointer' } },
                        series: [{ name: 'DMGT Demands', data: mgrSeries2, colorByPoint: true }],
                        drilldown: { series: (hierDrill && hierDrill.manager) ? hierDrill.manager : [] }
                    });
                }

                // Demands by Technical Team - drill-down
                var byTechLabels = <%= JsByTechLabels %>;
                var byTechData   = <%= JsByTechData %>;
                var byTechColors = <%= JsByTechColors %>;
                if (byTechLabels.length && document.getElementById('hcTechTeam')) {
                    var techSeries2 = [];
                    for (var i = 0; i < byTechLabels.length; i++) {
                        techSeries2.push({ name: byTechLabels[i], y: byTechData[i], color: byTechColors[i], drilldown: 'tech_' + i });
                    }
                    Highcharts.chart('hcTechTeam', {
                        chart: { type: 'bar' },
                        title: { text: null },
                        xAxis: { type: 'category', labels: { style: { fontSize: '11px' } } },
                        yAxis: { title: { text: 'Demands' }, allowDecimals: false },
                        legend: { enabled: false },
                        plotOptions: { series: { borderWidth: 1, borderColor: '#0d1b3d', dataLabels: { enabled: true, format: '{point.y}' }, cursor: 'pointer' } },
                        series: [{ name: 'DMGT Demands', data: techSeries2, colorByPoint: true }],
                        drilldown: { series: (hierDrill && hierDrill.tech) ? hierDrill.tech : [] }
                    });
                }

                // Demand Aging Analysis
                var agingLabels = <%= JsAgingLabels %>;
                var agingData   = <%= JsAgingData %>;
                var agingColors = <%= JsAgingColors %>;
                if (agingLabels.length && document.getElementById('hcAging')) {
                    var agingSeries = [];
                    for (var i = 0; i < agingLabels.length; i++) {
                        agingSeries.push({ name: agingLabels[i], y: agingData[i], color: agingColors[i] });
                    }
                    Highcharts.chart('hcAging', {
                        chart: { type: 'column' },
                        title: { text: null },
                        xAxis: { type: 'category' },
                        yAxis: { title: { text: 'Open Demands' }, allowDecimals: false },
                        legend: { enabled: false },
                        plotOptions: { series: { borderWidth: 1, borderColor: '#0d1b3d', dataLabels: { enabled: true, format: '{point.y}', style: { fontWeight: 'bold' } } } },
                        series: [{ name: 'Demands', data: agingSeries, colorByPoint: true }]
                    });
                }
            }
        })();

        $(function () {
            try { DFM.hideLoader(); } catch (e) { }
            try {
                var t = (window.performance && performance.timing)
                    ? (performance.timing.domContentLoadedEventEnd - performance.timing.navigationStart)
                    : 0;
                DFM.logScenario('DashboardLoad', 'page rendered', t);
                if ((parseInt('<%= JsAgingCount %>',10) || 0) > 0)
                    DFM.logScenario('SectionRender', 'Aging KPI populated');
                if ((parseInt('<%= JsMissedCount %>',10) || 0) > 0)
                    DFM.logScenario('SectionRender', 'Missed deliverables populated');
            } catch (e) { }
        });
    </script>
</asp:Content>
