using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using A = DocumentFormat.OpenXml.Drawing;
using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
using PIC = DocumentFormat.OpenXml.Drawing.Pictures;

namespace DocGenerator.Services;

public class HflmsDocumentGenerator
{
    private const string PrimaryColor = "1B3A5C";
    private const string AccentColor = "C4A035";
    private const string HeaderBg = "2C3E50";
    private const string LightBg = "ECF0F1";
    private const string White = "FFFFFF";
    private const string TableBorder = "BDC3C7";
    private const string GreenNode = "27AE60";
    private const string BlueNode = "2980B9";
    private const string OrangeNode = "E67E22";
    private const string RedNode = "C0392B";
    private const string PurpleNode = "8E44AD";
    private const string TealNode = "16A085";

    private readonly string _logoPath;

    public HflmsDocumentGenerator(string logoPath)
    {
        _logoPath = logoPath;
    }

    public byte[] GenerateDocument()
    {
        using var ms = new MemoryStream();
        using (var doc = WordprocessingDocument.Create(ms, WordprocessingDocumentType.Document, true))
        {
            var mainPart = doc.AddMainDocumentPart();
            mainPart.Document = new Document();
            var body = mainPart.Document.AppendChild(new Body());

            AddStyles(mainPart);
            AddNumbering(mainPart);

            var sectionProps = new SectionProperties(
                new PageSize { Width = 12240, Height = 15840 },
                new PageMargin { Top = 1080, Right = 1080, Bottom = 1080, Left = 1080, Header = 720, Footer = 720 }
            );

            // --- COVER PAGE ---
            AddCoverPage(body, mainPart);
            AddPageBreak(body);

            // --- INDEX PAGE ---
            AddIndexPage(body);
            AddPageBreak(body);

            // --- WORKFLOWS WITH DIAGRAMS ---
            AddWorkflowSection(body, "1. New Origination Workflow",
                "The New Origination Workflow covers the complete lifecycle of a Home Finance application from lead creation to final lodgement. This workflow involves multiple departments including Sales, Operations, RCD (Risk & Credit Department), and HR for staff cases.",
                GetNewOriginationDiagramNodes(), GetNewOriginationSteps());

            AddWorkflowSection(body, "2. CPV Module Workflow",
                "The Customer Point Verification (CPV) Module is used for updating CPV details and closing the verification process. For applications with multiple applicants, CPV is updated individually for each applicant.",
                GetCpvDiagramNodes(), GetCpvSteps());

            AddWorkflowSection(body, "3. PMU Tracking Workflow",
                "PMU (Property Mortgage Unit) Tracking is used for activating contracts and performing multiple activities like booking transfer slots, canceling, reassigning, updating transfer status, and changing booking status to active.",
                GetPmuDiagramNodes(), GetPmuSteps());

            AddWorkflowSection(body, "4. OPS Post Booking Workflow",
                "The OPS Post Booking workflow manages applications after the initial booking stage. It follows a maker-checker pattern to ensure quality and compliance.",
                GetOpsPostBookingDiagramNodes(), GetOpsPostBookingSteps());

            AddWorkflowSection(body, "5. Documents Handover Workflow",
                "The Documents Handover workflow starts when a transfer is booked and marked as completed from the PMU Tracker booking stage. It manages the pre-transfer security handover process across Credit, Operations, and Lodgment teams.",
                GetDocHandoverDiagramNodes(), GetDocHandoverSteps());

            AddWorkflowSection(body, "6. RSU Workflow",
                "The RSU (Restructuring Unit) workflow handles restructuring requests from customers. It involves customer contact, document collection, credit analysis, and operations processing.",
                GetRsuDiagramNodes(), GetRsuSteps());

            AddWorkflowSection(body, "7. HF After Sales Workflow",
                "The Home Finance After Sales workflow manages service requests post-disbursement. It covers credit analysis, deviation approvals through multiple levels, and operations processing.",
                GetHfAfterSalesDiagramNodes(), GetHfAfterSalesSteps());

            // Complaint Management (two sub-flows)
            AddHeading(body, "8. Complaint Management Workflow", 1);
            AddParagraph(body, "The Complaint Management workflow handles customer complaints through two parallel flows: Customer Service for complaint intake and the Complaint Management team for resolution and tracking.");
            AddWorkflowDiagram(body, GetComplaintDiagramNodes());
            AddHeading(body, "Customer Service Flow", 2);
            AddWorkflowTable(body, GetComplaintCustomerServiceSteps());
            AddHeading(body, "Complaint Management Flow", 2);
            AddWorkflowTable(body, GetComplaintManagementSteps());
            AddPageBreak(body);

            // --- SETUP SCREENS ---
            AddHeading(body, "9. Setup Screens in HFLMS", 1);
            AddParagraph(body, "Setup screens provide configuration capabilities for various masters and system parameters used across the HFLMS platform.");
            AddSetupScreens(body);
            AddPageBreak(body);

            // --- MODULES ---
            AddHeading(body, "10. Modules in HFLMS", 1);
            AddParagraph(body, "HFLMS comprises multiple integrated modules, each serving a specific business function in the Home Finance lifecycle.");
            AddModules(body);
            AddPageBreak(body);

            // --- REPORTS ---
            AddHeading(body, "11. Reports", 1);
            AddParagraph(body, "The following reports are available across various modules in HFLMS for monitoring, tracking, and analysis purposes.");
            AddGroupedTable(body, GetReports(), "Report Name");
            AddPageBreak(body);

            // --- MASTERS ---
            AddHeading(body, "12. Masters", 1);
            AddParagraph(body, "Master screens provide configuration and maintenance capabilities for reference data used throughout the system.");
            AddGroupedTable(body, GetMasters(), "Master Name");

            body.AppendChild(sectionProps);
        }
        return ms.ToArray();
    }

    private void AddWorkflowSection(Body body, string title, string description,
        List<(string Label, string Color, string Type)> diagramNodes,
        List<(string Step, string Stage, string Description)> steps)
    {
        AddHeading(body, title, 1);
        AddParagraph(body, description);
        AddWorkflowDiagram(body, diagramNodes);
        AddHeading(body, "Workflow Steps Detail", 2);
        AddWorkflowTable(body, steps);
        AddPageBreak(body);
    }

    #region Styles

    private void AddStyles(MainDocumentPart mainPart)
    {
        var stylesPart = mainPart.AddNewPart<StyleDefinitionsPart>();
        var styles = new Styles();

        styles.AppendChild(new DocDefaults(
            new RunPropertiesDefault(new RunPropertiesBaseStyle(
                new RunFonts { Ascii = "Segoe UI", HighAnsi = "Segoe UI", ComplexScript = "Segoe UI" },
                new FontSize { Val = "22" }, new Color { Val = "333333" }
            )),
            new ParagraphPropertiesDefault(new ParagraphPropertiesBaseStyle(
                new SpacingBetweenLines { After = "120", Line = "276" }
            ))
        ));

        styles.AppendChild(CreateParagraphStyle("Normal", "22", "333333", false));

        // Heading 1 - dark blue background white text
        var h1 = new Style { Type = StyleValues.Paragraph, StyleId = "Heading1", CustomStyle = true };
        h1.AppendChild(new StyleName { Val = "Heading 1" });
        h1.AppendChild(new BasedOn { Val = "Normal" });
        h1.AppendChild(new NextParagraphStyle { Val = "Normal" });
        h1.AppendChild(new StyleParagraphProperties(
            new SpacingBetweenLines { Before = "360", After = "200" },
            new KeepNext(), new KeepLines(),
            new Shading { Val = ShadingPatternValues.Clear, Color = "auto", Fill = PrimaryColor }
        ));
        h1.AppendChild(new StyleRunProperties(
            new RunFonts { Ascii = "Segoe UI", HighAnsi = "Segoe UI" },
            new Bold(), new FontSize { Val = "36" }, new FontSizeComplexScript { Val = "36" },
            new Color { Val = White }
        ));
        styles.AppendChild(h1);

        // Heading 2 - gold underline
        var h2 = new Style { Type = StyleValues.Paragraph, StyleId = "Heading2", CustomStyle = true };
        h2.AppendChild(new StyleName { Val = "Heading 2" });
        h2.AppendChild(new BasedOn { Val = "Normal" });
        h2.AppendChild(new NextParagraphStyle { Val = "Normal" });
        h2.AppendChild(new StyleParagraphProperties(
            new SpacingBetweenLines { Before = "240", After = "120" },
            new KeepNext(), new KeepLines(),
            new ParagraphBorders(new BottomBorder { Val = BorderValues.Single, Size = 12, Color = AccentColor, Space = 4 })
        ));
        h2.AppendChild(new StyleRunProperties(
            new RunFonts { Ascii = "Segoe UI", HighAnsi = "Segoe UI" },
            new Bold(), new FontSize { Val = "28" }, new FontSizeComplexScript { Val = "28" },
            new Color { Val = PrimaryColor }
        ));
        styles.AppendChild(h2);

        // Heading 3 - gold text
        var h3 = new Style { Type = StyleValues.Paragraph, StyleId = "Heading3", CustomStyle = true };
        h3.AppendChild(new StyleName { Val = "Heading 3" });
        h3.AppendChild(new BasedOn { Val = "Normal" });
        h3.AppendChild(new NextParagraphStyle { Val = "Normal" });
        h3.AppendChild(new StyleParagraphProperties(
            new SpacingBetweenLines { Before = "200", After = "80" }, new KeepNext()
        ));
        h3.AppendChild(new StyleRunProperties(
            new RunFonts { Ascii = "Segoe UI", HighAnsi = "Segoe UI" },
            new Bold(), new FontSize { Val = "24" }, new FontSizeComplexScript { Val = "24" },
            new Color { Val = AccentColor }
        ));
        styles.AppendChild(h3);

        stylesPart.Styles = styles;
    }

    private Style CreateParagraphStyle(string id, string fontSize, string color, bool bold)
    {
        var style = new Style { Type = StyleValues.Paragraph, StyleId = id };
        style.AppendChild(new StyleName { Val = id });
        style.AppendChild(new StyleRunProperties(
            new RunFonts { Ascii = "Segoe UI", HighAnsi = "Segoe UI" },
            new FontSize { Val = fontSize }, new FontSizeComplexScript { Val = fontSize },
            new Color { Val = color }
        ));
        if (bold)
        {
            var rp = style.Elements<StyleRunProperties>().First();
            rp.AppendChild(new Bold());
        }
        return style;
    }

    private void AddNumbering(MainDocumentPart mainPart)
    {
        var numberingPart = mainPart.AddNewPart<NumberingDefinitionsPart>();
        var numbering = new Numbering();
        numbering.AppendChild(new AbstractNum(
            new Level(
                new StartNumberingValue { Val = 1 },
                new NumberingFormat { Val = NumberFormatValues.Bullet },
                new LevelText { Val = "\u2022" },
                new LevelJustification { Val = LevelJustificationValues.Left },
                new PreviousParagraphProperties(new Indentation { Left = "720", Hanging = "360" }),
                new NumberingSymbolRunProperties(new RunFonts { Ascii = "Symbol", HighAnsi = "Symbol" })
            ) { LevelIndex = 0 }
        ) { AbstractNumberId = 1 });
        numbering.AppendChild(new NumberingInstance(new AbstractNumId { Val = 1 }) { NumberID = 1 });
        numberingPart.Numbering = numbering;
    }

    #endregion

    #region Cover Page

    private void AddCoverPage(Body body, MainDocumentPart mainPart)
    {
        // Logo
        if (File.Exists(_logoPath))
            AddLogo(body, mainPart);

        // Spacer
        for (int i = 0; i < 3; i++)
            body.AppendChild(new Paragraph());

        // Title block
        AddCenteredShadedPara(body, "HFLMS", "72", White, PrimaryColor);
        AddCenteredShadedPara(body, "Home Finance Loan Management System", "36", AccentColor, PrimaryColor);
        AddCenteredShadedPara(body, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", "24", AccentColor, PrimaryColor);
        AddCenteredShadedPara(body, "System Documentation & Workflow Reference", "28", "BDC3C7", PrimaryColor);

        for (int i = 0; i < 5; i++)
            body.AppendChild(new Paragraph());

        // Footer info
        foreach (var line in new[] { "Dubai Islamic Bank", "Home Finance Division", $"Document Version 1.0 — {DateTime.Now:MMMM yyyy}" })
        {
            var fp = new Paragraph(new Run(
                new RunProperties(new Color { Val = "777777" }, new FontSize { Val = "20" }),
                new Text(line)
            ));
            fp.PrependChild(new ParagraphProperties(
                new Justification { Val = JustificationValues.Center },
                new SpacingBetweenLines { After = "40" }
            ));
            body.AppendChild(fp);
        }
    }

    private void AddCenteredShadedPara(Body body, string text, string fontSize, string textColor, string bgColor)
    {
        var para = new Paragraph(new Run(
            new RunProperties(
                new RunFonts { Ascii = "Segoe UI", HighAnsi = "Segoe UI" },
                new Bold(), new FontSize { Val = fontSize }, new FontSizeComplexScript { Val = fontSize },
                new Color { Val = textColor }
            ),
            new Text(text) { Space = SpaceProcessingModeValues.Preserve }
        ));
        para.PrependChild(new ParagraphProperties(
            new Justification { Val = JustificationValues.Center },
            new SpacingBetweenLines { Before = "0", After = "100" },
            new Shading { Val = ShadingPatternValues.Clear, Color = "auto", Fill = bgColor }
        ));
        body.AppendChild(para);
    }

    private void AddLogo(Body body, MainDocumentPart mainPart)
    {
        var ext = Path.GetExtension(_logoPath).ToLowerInvariant();
        var imageType = ext == ".png" ? ImagePartType.Png : ImagePartType.Jpeg;
        var imagePart = mainPart.AddImagePart(imageType);

        using (var stream = new FileStream(_logoPath, FileMode.Open, FileAccess.Read))
            imagePart.FeedData(stream);

        string relId = mainPart.GetIdOfPart(imagePart);

        // 2.5 inches wide, proportional height
        long widthEmu = 2286000; // 2.5 inches
        long heightEmu = 762000; // ~0.83 inches default

        var element = new Drawing(
            new DW.Inline(
                new DW.Extent { Cx = widthEmu, Cy = heightEmu },
                new DW.EffectExtent { LeftEdge = 0, TopEdge = 0, RightEdge = 0, BottomEdge = 0 },
                new DW.DocProperties { Id = 1U, Name = "DIB Logo" },
                new DW.NonVisualGraphicFrameDrawingProperties(
                    new A.GraphicFrameLocks { NoChangeAspect = true }
                ),
                new A.Graphic(new A.GraphicData(
                    new PIC.Picture(
                        new PIC.NonVisualPictureProperties(
                            new PIC.NonVisualDrawingProperties { Id = 0U, Name = "DIB-Logo-Website.jpg" },
                            new PIC.NonVisualPictureDrawingProperties()
                        ),
                        new PIC.BlipFill(
                            new A.Blip { Embed = relId },
                            new A.Stretch(new A.FillRectangle())
                        ),
                        new PIC.ShapeProperties(
                            new A.Transform2D(
                                new A.Offset { X = 0, Y = 0 },
                                new A.Extents { Cx = widthEmu, Cy = heightEmu }
                            ),
                            new A.PresetGeometry(new A.AdjustValueList()) { Preset = A.ShapeTypeValues.Rectangle }
                        )
                    )
                ) { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" })
            ) { DistanceFromTop = 0, DistanceFromBottom = 0, DistanceFromLeft = 0, DistanceFromRight = 0 }
        );

        var logoPara = new Paragraph(new Run(element));
        logoPara.PrependChild(new ParagraphProperties(
            new Justification { Val = JustificationValues.Center },
            new SpacingBetweenLines { Before = "400", After = "200" }
        ));
        body.AppendChild(logoPara);
    }

    #endregion

    #region Index Page

    private void AddIndexPage(Body body)
    {
        AddHeading(body, "Document Index", 1);
        body.AppendChild(new Paragraph());

        var table = new Table();
        table.AppendChild(new TableProperties(
            new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct },
            new TableBorders(
                new TopBorder { Val = BorderValues.None },
                new BottomBorder { Val = BorderValues.None },
                new LeftBorder { Val = BorderValues.None },
                new RightBorder { Val = BorderValues.None },
                new InsideHorizontalBorder { Val = BorderValues.Single, Size = 2, Color = "EEEEEE" },
                new InsideVerticalBorder { Val = BorderValues.None }
            )
        ));

        // Workflows header
        table.AppendChild(CreateIndexSectionHeader("WORKFLOWS"));

        var workflows = new (string Num, string Title, string Desc)[]
        {
            ("1", "New Origination Workflow", "Lead creation to final lodgement — 23 steps"),
            ("2", "CPV Module Workflow", "Customer Point Verification — 4 steps"),
            ("3", "PMU Tracking Workflow", "Property Mortgage Unit tracking — 13 steps"),
            ("4", "OPS Post Booking Workflow", "Post-booking operations — 5 steps"),
            ("5", "Documents Handover Workflow", "Pre-transfer security handover — 3 steps"),
            ("6", "RSU Workflow", "Restructuring Unit processing — 11 steps"),
            ("7", "HF After Sales Workflow", "Post-disbursement service requests — 16 steps"),
            ("8", "Complaint Management Workflow", "Customer complaint handling — 10 steps")
        };

        foreach (var (num, title, desc) in workflows)
            table.AppendChild(CreateIndexRow(num, title, desc));

        // Config header
        table.AppendChild(CreateIndexSectionHeader("CONFIGURATION & REFERENCE"));

        var configs = new (string Num, string Title, string Desc)[]
        {
            ("9", "Setup Screens", "10 configuration screens for system setup"),
            ("10", "Modules in HFLMS", "12 integrated business modules"),
            ("11", "Reports", "45+ reports across all modules"),
            ("12", "Masters", "30+ master configuration screens")
        };

        foreach (var (num, title, desc) in configs)
            table.AppendChild(CreateIndexRow(num, title, desc));

        body.AppendChild(table);
    }

    private TableRow CreateIndexSectionHeader(string text)
    {
        var row = new TableRow();
        var cell = new TableCell();
        cell.AppendChild(new TableCellProperties(
            new TableCellWidth { Width = "10000", Type = TableWidthUnitValues.Dxa },
            new GridSpan { Val = 3 },
            new Shading { Val = ShadingPatternValues.Clear, Fill = PrimaryColor },
            new TableCellMargin(
                new TopMargin { Width = "80", Type = TableWidthUnitValues.Dxa },
                new BottomMargin { Width = "80", Type = TableWidthUnitValues.Dxa },
                new LeftMargin { Width = "160", Type = TableWidthUnitValues.Dxa }
            )
        ));
        var para = new Paragraph(new Run(
            new RunProperties(new Bold(), new Color { Val = AccentColor },
                new FontSize { Val = "22" }, new FontSizeComplexScript { Val = "22" }),
            new Text(text)
        ));
        para.PrependChild(new ParagraphProperties(new SpacingBetweenLines { After = "0" }));
        cell.AppendChild(para);
        row.AppendChild(cell);
        return row;
    }

    private TableRow CreateIndexRow(string num, string title, string desc)
    {
        var row = new TableRow();
        row.AppendChild(CreateIndexCell(num, PrimaryColor, true, "600", JustificationValues.Center));
        row.AppendChild(CreateIndexCell(title, PrimaryColor, true, "4400", JustificationValues.Left));
        row.AppendChild(CreateIndexCell(desc, "888888", false, "5000", JustificationValues.Left));
        return row;
    }

    private TableCell CreateIndexCell(string text, string color, bool bold, string width, JustificationValues justify)
    {
        var cell = new TableCell();
        cell.AppendChild(new TableCellProperties(
            new TableCellWidth { Width = width, Type = TableWidthUnitValues.Dxa },
            new TableCellMargin(
                new TopMargin { Width = "60", Type = TableWidthUnitValues.Dxa },
                new BottomMargin { Width = "60", Type = TableWidthUnitValues.Dxa },
                new LeftMargin { Width = "120", Type = TableWidthUnitValues.Dxa },
                new RightMargin { Width = "80", Type = TableWidthUnitValues.Dxa }
            ),
            new TableCellVerticalAlignment { Val = TableVerticalAlignmentValues.Center }
        ));
        var rProps = new RunProperties(
            new Color { Val = color }, new FontSize { Val = "22" }, new FontSizeComplexScript { Val = "22" }
        );
        if (bold) rProps.AppendChild(new Bold());
        var para = new Paragraph(new Run(rProps, new Text(text) { Space = SpaceProcessingModeValues.Preserve }));
        para.PrependChild(new ParagraphProperties(
            new Justification { Val = justify }, new SpacingBetweenLines { After = "0" }
        ));
        cell.AppendChild(para);
        return cell;
    }

    #endregion

    #region Helpers

    private void AddHeading(Body body, string text, int level)
    {
        var styleId = level switch { 1 => "Heading1", 2 => "Heading2", 3 => "Heading3", _ => "Normal" };
        var pProps = new ParagraphProperties(new ParagraphStyleId { Val = styleId });
        if (level == 1) pProps.AppendChild(new Indentation { Left = "180", Right = "180" });
        var para = new Paragraph(new Run(new Text(text) { Space = SpaceProcessingModeValues.Preserve }));
        para.PrependChild(pProps);
        body.AppendChild(para);
    }

    private void AddParagraph(Body body, string text)
    {
        if (string.IsNullOrEmpty(text)) { body.AppendChild(new Paragraph()); return; }
        body.AppendChild(new Paragraph(
            new ParagraphProperties(new ParagraphStyleId { Val = "Normal" }),
            new Run(new Text(text) { Space = SpaceProcessingModeValues.Preserve })
        ));
    }

    private void AddPageBreak(Body body)
    {
        body.AppendChild(new Paragraph(new Run(new Break { Type = BreakValues.Page })));
    }

    #endregion

    #region Workflow Diagrams

    private void AddWorkflowDiagram(Body body, List<(string Label, string Color, string Type)> nodes)
    {
        // Each row shows up to 3 colored boxes connected by arrows
        // Rows are connected by down-arrows
        int perRow = 3;

        for (int i = 0; i < nodes.Count; i += perRow)
        {
            int count = Math.Min(perRow, nodes.Count - i);

            // Node row
            var nodeTable = new Table();
            nodeTable.AppendChild(MakeNoBorderTableProps());

            var nodeRow = new TableRow();
            for (int j = 0; j < count; j++)
            {
                if (j > 0)
                    nodeRow.AppendChild(MakeArrowCell("→", "500"));

                var (label, color, type) = nodes[i + j];
                nodeRow.AppendChild(MakeFlowNodeCell(label, color, type));
            }
            // Pad to keep alignment
            int totalCells = count * 2 - 1;
            int maxCells = perRow * 2 - 1; // 5
            for (int p = totalCells; p < maxCells; p++)
                nodeRow.AppendChild(MakeEmptyCell("500"));

            nodeTable.AppendChild(nodeRow);
            body.AppendChild(nodeTable);

            // Down arrow between rows
            if (i + perRow < nodes.Count)
            {
                // Put down arrow centered under last node of this row
                var arrowPara = new Paragraph(new Run(
                    new RunProperties(new Bold(), new Color { Val = AccentColor },
                        new FontSize { Val = "32" }, new FontSizeComplexScript { Val = "32" }),
                    new Text("▼") { Space = SpaceProcessingModeValues.Preserve }
                ));
                arrowPara.PrependChild(new ParagraphProperties(
                    new Justification { Val = JustificationValues.Center },
                    new SpacingBetweenLines { Before = "40", After = "40" }
                ));
                body.AppendChild(arrowPara);
            }
        }
        body.AppendChild(new Paragraph()); // spacing after diagram
    }

    private TableProperties MakeNoBorderTableProps()
    {
        return new TableProperties(
            new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct },
            new TableBorders(
                new TopBorder { Val = BorderValues.None },
                new BottomBorder { Val = BorderValues.None },
                new LeftBorder { Val = BorderValues.None },
                new RightBorder { Val = BorderValues.None },
                new InsideHorizontalBorder { Val = BorderValues.None },
                new InsideVerticalBorder { Val = BorderValues.None }
            ),
            new TableJustification { Val = TableRowAlignmentValues.Center }
        );
    }

    private TableCell MakeFlowNodeCell(string label, string bgColor, string type)
    {
        string icon = type switch
        {
            "start" => "▶ ",
            "decision" => "◆ ",
            "end" => "■ ",
            _ => ""
        };

        var cell = new TableCell();
        cell.AppendChild(new TableCellProperties(
            new TableCellWidth { Width = "3000", Type = TableWidthUnitValues.Dxa },
            new Shading { Val = ShadingPatternValues.Clear, Fill = bgColor },
            new TableCellMargin(
                new TopMargin { Width = "50", Type = TableWidthUnitValues.Dxa },
                new BottomMargin { Width = "50", Type = TableWidthUnitValues.Dxa },
                new LeftMargin { Width = "60", Type = TableWidthUnitValues.Dxa },
                new RightMargin { Width = "60", Type = TableWidthUnitValues.Dxa }
            ),
            new TableCellVerticalAlignment { Val = TableVerticalAlignmentValues.Center },
            new TableCellBorders(
                new TopBorder { Val = BorderValues.Single, Size = 6, Color = bgColor },
                new BottomBorder { Val = BorderValues.Single, Size = 6, Color = bgColor },
                new LeftBorder { Val = BorderValues.Single, Size = 6, Color = bgColor },
                new RightBorder { Val = BorderValues.Single, Size = 6, Color = bgColor }
            )
        ));

        var para = new Paragraph(new Run(
            new RunProperties(new Bold(), new Color { Val = White },
                new FontSize { Val = "18" }, new FontSizeComplexScript { Val = "18" }),
            new Text(icon + label) { Space = SpaceProcessingModeValues.Preserve }
        ));
        para.PrependChild(new ParagraphProperties(
            new Justification { Val = JustificationValues.Center },
            new SpacingBetweenLines { After = "0", Before = "0" }
        ));
        cell.AppendChild(para);
        return cell;
    }

    private TableCell MakeArrowCell(string arrow, string width)
    {
        var cell = new TableCell();
        cell.AppendChild(new TableCellProperties(
            new TableCellWidth { Width = width, Type = TableWidthUnitValues.Dxa },
            new TableCellVerticalAlignment { Val = TableVerticalAlignmentValues.Center },
            new TableCellBorders(
                new TopBorder { Val = BorderValues.None },
                new BottomBorder { Val = BorderValues.None },
                new LeftBorder { Val = BorderValues.None },
                new RightBorder { Val = BorderValues.None }
            )
        ));
        var para = new Paragraph(new Run(
            new RunProperties(new Bold(), new Color { Val = AccentColor },
                new FontSize { Val = "28" }, new FontSizeComplexScript { Val = "28" }),
            new Text(arrow)
        ));
        para.PrependChild(new ParagraphProperties(
            new Justification { Val = JustificationValues.Center },
            new SpacingBetweenLines { After = "0", Before = "0" }
        ));
        cell.AppendChild(para);
        return cell;
    }

    private TableCell MakeEmptyCell(string width)
    {
        var cell = new TableCell();
        cell.AppendChild(new TableCellProperties(
            new TableCellWidth { Width = width, Type = TableWidthUnitValues.Dxa },
            new TableCellBorders(
                new TopBorder { Val = BorderValues.None },
                new BottomBorder { Val = BorderValues.None },
                new LeftBorder { Val = BorderValues.None },
                new RightBorder { Val = BorderValues.None }
            )
        ));
        cell.AppendChild(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { After = "0" })));
        return cell;
    }

    #endregion

    #region Workflow Tables

    private void AddWorkflowTable(Body body, List<(string Step, string Stage, string Description)> steps)
    {
        var table = new Table();
        table.AppendChild(new TableProperties(
            new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct },
            new TableBorders(
                new TopBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                new BottomBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                new LeftBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                new RightBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                new InsideHorizontalBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                new InsideVerticalBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder }
            ), new TableLook { Val = "04A0" }
        ));

        var hdr = new TableRow();
        hdr.AppendChild(StyledCell("Step", HeaderBg, White, true, "800"));
        hdr.AppendChild(StyledCell("Stage", HeaderBg, White, true, "2600"));
        hdr.AppendChild(StyledCell("Description", HeaderBg, White, true, "6600"));
        table.AppendChild(hdr);

        bool alt = false;
        foreach (var (step, stage, desc) in steps)
        {
            var row = new TableRow();
            string bg = alt ? LightBg : White;
            row.AppendChild(StyledCell(step, bg, PrimaryColor, true, "800"));
            row.AppendChild(StyledCell(stage, bg, "333333", true, "2600"));
            row.AppendChild(StyledCell(desc, bg, "555555", false, "6600"));
            table.AppendChild(row);
            alt = !alt;
        }

        body.AppendChild(table);
        body.AppendChild(new Paragraph());
    }

    private TableCell StyledCell(string text, string bg, string fg, bool bold, string width)
    {
        var cell = new TableCell();
        cell.AppendChild(new TableCellProperties(
            new TableCellWidth { Width = width, Type = TableWidthUnitValues.Dxa },
            new Shading { Val = ShadingPatternValues.Clear, Color = "auto", Fill = bg },
            new TableCellMargin(
                new TopMargin { Width = "60", Type = TableWidthUnitValues.Dxa },
                new BottomMargin { Width = "60", Type = TableWidthUnitValues.Dxa },
                new LeftMargin { Width = "120", Type = TableWidthUnitValues.Dxa },
                new RightMargin { Width = "120", Type = TableWidthUnitValues.Dxa }
            ),
            new TableCellVerticalAlignment { Val = TableVerticalAlignmentValues.Center }
        ));
        var rp = new RunProperties(new Color { Val = fg },
            new FontSize { Val = "20" }, new FontSizeComplexScript { Val = "20" });
        if (bold) rp.AppendChild(new Bold());
        var para = new Paragraph(new Run(rp, new Text(text) { Space = SpaceProcessingModeValues.Preserve }));
        para.PrependChild(new ParagraphProperties(new SpacingBetweenLines { After = "0" }));
        cell.AppendChild(para);
        return cell;
    }

    #endregion

    #region Setup Screens

    private void AddSetupScreens(Body body)
    {
        foreach (var (name, desc) in GetSetupScreens())
        {
            var table = new Table();
            table.AppendChild(new TableProperties(
                new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct },
                new TableBorders(
                    new TopBorder { Val = BorderValues.Single, Size = 6, Color = PrimaryColor },
                    new BottomBorder { Val = BorderValues.Single, Size = 2, Color = TableBorder },
                    new LeftBorder { Val = BorderValues.Single, Size = 6, Color = PrimaryColor },
                    new RightBorder { Val = BorderValues.Single, Size = 2, Color = TableBorder },
                    new InsideHorizontalBorder { Val = BorderValues.Single, Size = 2, Color = TableBorder }
                )
            ));

            // Title
            var tCell = new TableCell();
            tCell.AppendChild(new TableCellProperties(
                new TableCellWidth { Width = "10000", Type = TableWidthUnitValues.Dxa },
                new Shading { Val = ShadingPatternValues.Clear, Fill = PrimaryColor },
                new TableCellMargin(
                    new TopMargin { Width = "80", Type = TableWidthUnitValues.Dxa },
                    new BottomMargin { Width = "80", Type = TableWidthUnitValues.Dxa },
                    new LeftMargin { Width = "160", Type = TableWidthUnitValues.Dxa }
                )
            ));
            var tp = new Paragraph(new Run(
                new RunProperties(new Bold(), new Color { Val = White }, new FontSize { Val = "24" }),
                new Text(name)
            ));
            tp.PrependChild(new ParagraphProperties(new SpacingBetweenLines { After = "0" }));
            tCell.AppendChild(tp);
            var tRow = new TableRow();
            tRow.AppendChild(tCell);
            table.AppendChild(tRow);

            // Description
            var dCell = new TableCell();
            dCell.AppendChild(new TableCellProperties(
                new TableCellWidth { Width = "10000", Type = TableWidthUnitValues.Dxa },
                new Shading { Val = ShadingPatternValues.Clear, Fill = "F8F9FA" },
                new TableCellMargin(
                    new TopMargin { Width = "100", Type = TableWidthUnitValues.Dxa },
                    new BottomMargin { Width = "100", Type = TableWidthUnitValues.Dxa },
                    new LeftMargin { Width = "160", Type = TableWidthUnitValues.Dxa },
                    new RightMargin { Width = "160", Type = TableWidthUnitValues.Dxa }
                )
            ));
            var dp = new Paragraph(new Run(
                new RunProperties(new Color { Val = "555555" }, new FontSize { Val = "20" }),
                new Text(desc) { Space = SpaceProcessingModeValues.Preserve }
            ));
            dp.PrependChild(new ParagraphProperties(new SpacingBetweenLines { After = "0" }));
            dCell.AppendChild(dp);
            var dRow = new TableRow();
            dRow.AppendChild(dCell);
            table.AppendChild(dRow);

            body.AppendChild(table);
            body.AppendChild(new Paragraph());
        }
    }

    #endregion

    #region Modules

    private void AddModules(Body body)
    {
        int idx = 1;
        foreach (var (name, desc) in GetModules())
        {
            AddHeading(body, $"10.{idx}  {name}", 3);
            var para = new Paragraph(new Run(
                new RunProperties(new FontSize { Val = "21" }, new Color { Val = "555555" }),
                new Text(desc) { Space = SpaceProcessingModeValues.Preserve }
            ));
            para.PrependChild(new ParagraphProperties(
                new Indentation { Left = "240" },
                new SpacingBetweenLines { After = "200" },
                new ParagraphBorders(new LeftBorder { Val = BorderValues.Single, Size = 12, Color = AccentColor, Space = 8 })
            ));
            body.AppendChild(para);
            idx++;
        }
    }

    #endregion

    #region Grouped Tables (Reports / Masters)

    private void AddGroupedTable(Body body, List<(string Module, string Name)> items, string colHeader)
    {
        foreach (var group in items.GroupBy(x => x.Module).OrderBy(g => g.Key))
        {
            AddHeading(body, group.Key, 3);

            var table = new Table();
            table.AppendChild(new TableProperties(
                new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct },
                new TableBorders(
                    new TopBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                    new BottomBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                    new LeftBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                    new RightBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                    new InsideHorizontalBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder },
                    new InsideVerticalBorder { Val = BorderValues.Single, Size = 4, Color = TableBorder }
                )
            ));

            var hdr = new TableRow();
            hdr.AppendChild(StyledCell("#", HeaderBg, White, true, "600"));
            hdr.AppendChild(StyledCell(colHeader, HeaderBg, White, true, "9400"));
            table.AppendChild(hdr);

            int n = 1; bool alt = false;
            foreach (var item in group)
            {
                var row = new TableRow();
                string bg = alt ? LightBg : White;
                row.AppendChild(StyledCell(n.ToString(), bg, PrimaryColor, true, "600"));
                row.AppendChild(StyledCell(item.Name, bg, "333333", false, "9400"));
                table.AppendChild(row);
                n++; alt = !alt;
            }

            body.AppendChild(table);
            body.AppendChild(new Paragraph());
        }
    }

    #endregion

    #region Diagram Node Data

    private List<(string Label, string Color, string Type)> GetNewOriginationDiagramNodes() => new()
    {
        ("CRM Lead Creation", GreenNode, "start"),
        ("VyMo Form Submit", BlueNode, "step"),
        ("App Data Entry", BlueNode, "step"),
        ("Data Entry Approval", TealNode, "step"),
        ("Credit Login HelpDesk", PurpleNode, "step"),
        ("Level 6 (RCD)", PurpleNode, "step"),
        ("Staff?", OrangeNode, "decision"),
        ("HR Maker / Checker", OrangeNode, "step"),
        ("Level 4 → 1", PurpleNode, "step"),
        ("Affordability Check", BlueNode, "step"),
        ("Digital Case?", OrangeNode, "decision"),
        ("Offer Letter Print", PurpleNode, "step"),
        ("Offer Letter Accept", BlueNode, "step"),
        ("OPS Scrutinizer 1", TealNode, "step"),
        ("OPS Help Desk", TealNode, "step"),
        ("OPS Scrutinizer 2", TealNode, "step"),
        ("OPS Authorizer", TealNode, "step"),
        ("OPS PMU", TealNode, "step"),
        ("OPS Lodgement", RedNode, "end")
    };

    private List<(string Label, string Color, string Type)> GetCpvDiagramNodes() => new()
    {
        ("CPV Helpdesk", GreenNode, "start"),
        ("CPV Reassignment", BlueNode, "step"),
        ("CPV Update Status", TealNode, "step"),
        ("CPV Report", RedNode, "end")
    };

    private List<(string Label, string Color, string Type)> GetPmuDiagramNodes() => new()
    {
        ("Book Transfer", GreenNode, "start"),
        ("Reassign Booking", BlueNode, "step"),
        ("View Schedule", BlueNode, "step"),
        ("Update Transfer Status", TealNode, "step"),
        ("Update PSA/NOC", TealNode, "step"),
        ("Change to Active", TealNode, "step"),
        ("Approve Transfer", PurpleNode, "step"),
        ("Update Booking Details", BlueNode, "step"),
        ("Update Attributes", BlueNode, "step"),
        ("Update Location", BlueNode, "step"),
        ("Update FRL Details", BlueNode, "step"),
        ("Title Deed Maker", OrangeNode, "step"),
        ("Title Deed Checker", RedNode, "end")
    };

    private List<(string Label, string Color, string Type)> GetOpsPostBookingDiagramNodes() => new()
    {
        ("OPS PB Helpdesk", GreenNode, "start"),
        ("OPS PB Maker", BlueNode, "step"),
        ("OPS PB Checker", TealNode, "step"),
        ("OPS PB Reassignment", OrangeNode, "step"),
        ("Review Completed", RedNode, "end")
    };

    private List<(string Label, string Color, string Type)> GetDocHandoverDiagramNodes() => new()
    {
        ("PTSH To Lodgment", GreenNode, "start"),
        ("PTSH To Credit", BlueNode, "step"),
        ("PTSH To Customer", RedNode, "end")
    };

    private List<(string Label, string Color, string Type)> GetRsuDiagramNodes() => new()
    {
        ("New Request", GreenNode, "start"),
        ("Contact & Doc Collection", BlueNode, "step"),
        ("Security Questions", TealNode, "step"),
        ("RSU Decision", OrangeNode, "decision"),
        ("Credit Login Helpdesk", PurpleNode, "step"),
        ("Credit Processing", PurpleNode, "step"),
        ("RSU App Processing", PurpleNode, "step"),
        ("Offer Letter", BlueNode, "step"),
        ("Doc Collection OPS", TealNode, "step"),
        ("OPS Helpdesk", TealNode, "step"),
        ("OPS App Process", RedNode, "end")
    };

    private List<(string Label, string Color, string Type)> GetHfAfterSalesDiagramNodes() => new()
    {
        ("Customer Search", GreenNode, "start"),
        ("Service Request", BlueNode, "step"),
        ("Create SR", BlueNode, "step"),
        ("Submit", BlueNode, "step"),
        ("Credit Helpdesk", PurpleNode, "step"),
        ("Credit Analysis", PurpleNode, "step"),
        ("Deviations?", OrangeNode, "decision"),
        ("L4 → L1 Approval", OrangeNode, "step"),
        ("Credit Letter Gen", PurpleNode, "step"),
        ("OPS Helpdesk", TealNode, "step"),
        ("OPS Maker", TealNode, "step"),
        ("OPS Checker", TealNode, "step"),
        ("OPS Letter Printing", RedNode, "end")
    };

    private List<(string Label, string Color, string Type)> GetComplaintDiagramNodes() => new()
    {
        ("Customer Search", GreenNode, "start"),
        ("Service Request", BlueNode, "step"),
        ("New Complaint", BlueNode, "step"),
        ("Submit", BlueNode, "step"),
        ("Case Assignment", PurpleNode, "step"),
        ("Case Action", TealNode, "step"),
        ("Resolution", RedNode, "end")
    };

    #endregion

    #region Workflow Step Data

    private List<(string Step, string Stage, string Description)> GetNewOriginationSteps() => new()
    {
        ("1", "CRM Lead Creation (Sales)", "Lead is created in the CRM system by the sales team and synced to HFLMS."),
        ("2", "VyMo App Form Submission (Sales)", "Sales team submits the application form through VyMo mobile application."),
        ("3", "Application Data Entry (Sales)", "Sales user enters detailed application data including customer information, property details, and financial data."),
        ("4", "Data Entry Approval (Operations)", "Operations team reviews and approves the data entered by the sales team."),
        ("5", "Credit Login Help Desk (RCD)", "Risk & Credit Department helpdesk receives the application for credit processing."),
        ("6", "Level 6 (RCD)", "Initial credit assessment at Level 6 by RCD analyst."),
        ("7", "Staff Check (Decision)", "Decision point: Is this a staff funding case? If Yes → HR Maker/Checker flow."),
        ("8", "Level 6 HR Maker", "HR Maker reviews staff applicant details entered by sales user."),
        ("9", "Level 6 HR Checker", "HR Checker approves the details reviewed by HR Maker."),
        ("10", "Level 4", "Credit assessment at Level 4 approval authority."),
        ("11", "Level 3", "Credit assessment at Level 3 approval authority."),
        ("12", "Level 2", "Credit assessment at Level 2 approval authority."),
        ("13", "Level 1", "Credit assessment at Level 1 (highest) approval authority."),
        ("14", "Affordability Check", "System performs affordability check on the applicant based on income and obligations."),
        ("15", "Digital Case Check (Decision)", "Decision point: Is this a digital case? Determines offer letter printing flow."),
        ("16", "Credit Offer Letter Printing (RCD)", "RCD prints the credit offer letter for non-digital cases."),
        ("17", "Credit Offer Letter Acceptance (Sales)", "Sales team obtains customer acceptance of the offer letter."),
        ("18", "OPS Scrutinizer 1 (Sales)", "Sales team forwards application to operations with Takaful checklist, repayment details, and scrutinizer check."),
        ("19", "OPS Help Desk (OPS)", "Operations helpdesk receives and assigns the application for processing."),
        ("20", "OPS Scrutinizer 2 (OPS)", "Operations creates customer ID, performs due diligence, dedupe check, and document verification."),
        ("21", "OPS Authorizer 1", "Operations authorizer reviews and approves the processed application."),
        ("22", "OPS PMU", "Property Mortgage Unit processes the transfer and registration activities."),
        ("23", "OPS Lodgement", "Final lodgement of the application with all completed documentation.")
    };

    private List<(string Step, string Stage, string Description)> GetCpvSteps() => new()
    {
        ("1", "CPV Helpdesk", "All CPV requests are received here, and team member assignments are managed from this screen."),
        ("2", "CPV Reassignment", "Once a case is assigned to a team member, users can reassign it to another team member if needed."),
        ("3", "CPV Update Status", "Update CPV details and close the CPV. Different CPV types include Home Country CPV, Office CPV etc."),
        ("4", "CPV Report", "Contains details about CPV Logs and Activities.")
    };

    private List<(string Step, string Stage, string Description)> GetPmuSteps() => new()
    {
        ("1", "Book a Transfer", "Initiate the tracker for transfer booking. Option for booking on any available date."),
        ("2", "Reassign a Booking", "Reassign the booked transfer to another user."),
        ("3", "View Schedule", "Check the booked property on a selected date. Works as a report."),
        ("4", "Update Transfer Status", "Update the status of transfer (completed, pending, cancel, etc.). Maker screen — updates go to Approve Transfer Status Update for checker approval."),
        ("5", "Update PSA/NOC Status", "If Tracker is booked for NOC, this option needs to be selected; otherwise not required."),
        ("6", "Change Booking Status to Active", "If Booking Status is not active, it can be made active from this option."),
        ("7", "Approve Transfer Status Update", "Checker screen. Transfers updated in Update Transfer Status come here for approval."),
        ("8", "Update Booking Details", "Update booking details like Booking Time, Transfer Officer, etc."),
        ("9", "Update Booking Attributes", "View and change existing booking attributes. For example, change from Transfer to NOC."),
        ("10", "Update Transfer Location", "Update the transfer location. Changes apply to all trackers."),
        ("11", "Update FRL Details", "Report showing fund recall details."),
        ("12", "Update Title Deed (Maker)", "Maker changes title deed details (address, etc.) and submits to checker. Maker and Checker must be different users."),
        ("13", "Update Title Deed (Checker)", "Checker approves title deed details submitted by maker. Maker and Checker must be different users.")
    };

    private List<(string Step, string Stage, string Description)> GetOpsPostBookingSteps() => new()
    {
        ("1", "OPS Post Booking Helpdesk", "Send the applications to respective OPS users for post-booking processing."),
        ("2", "OPS Post Booking Maker", "OPS maker actions the application to move it forward in the post-booking process."),
        ("3", "OPS Post Booking Checker", "Has all the screens as OPS Post Booking Maker. Used by OPS checker users to approve the application."),
        ("4", "OPS Post Booking Reassignment", "Reassign post-booking cases to different OPS users."),
        ("5", "OPS Post Booking Review Completed", "Check applications for which review has been completed.")
    };

    private List<(string Step, string Stage, string Description)> GetDocHandoverSteps() => new()
    {
        ("1", "PTSH To Lodgment (Credit)", "The Credit Queue displays applications from Operations for the credit team to review. Credit can retain applications or send them back. When ready, applications are forwarded to the Lodgment queue."),
        ("2", "PTSH To Credit (OPS)", "Centralized dashboard for the sales team showing Completed Transfers and Rollbacked Applications returned from the PTSH Credit stage."),
        ("3", "PTSH To Customer (Lodgment)", "Final stage where the Credit team marks the application as dispatched (closure) or rolls back to Credit stage for further review.")
    };

    private List<(string Step, string Stage, string Description)> GetRsuSteps() => new()
    {
        ("1", "Customer Search / New Request", "Create a new RSU request by searching for the customer."),
        ("2", "Customer Contact & Doc Collection", "RSU team performs operations, contacts customer, and collects required documents."),
        ("3", "Operations Update Security Questions", "Operations fill the security questions/checklist for the RSU request."),
        ("4", "RSU Decision on Request", "RSU Team Leader reviews and makes a decision on the restructuring request."),
        ("5", "Credit Login Helpdesk", "Assign the restructuring request to the Credit user for analysis."),
        ("6", "Credit RSU Application Processing", "Credit officer checks the application assigned for RSU processing."),
        ("7", "RSU Application Processing – CM", "Process the particular restructuring application."),
        ("8", "Offer Letter", "Generate the restructuring offer letter for the customer."),
        ("9", "RSU Document Collection for OPS", "RSU Officer collects all documents listed in the Document Checklist."),
        ("10", "OPS Helpdesk", "Operations Helpdesk reviews documents and assigns an Operations Officer for verification."),
        ("11", "OPS App Process", "Operations Officer verifies the document checklist for accuracy and completeness.")
    };

    private List<(string Step, string Stage, string Description)> GetHfAfterSalesSteps() => new()
    {
        ("1", "Customer Search", "Search the customer using Customer ID, Application ID, etc."),
        ("2", "Service Request", "Navigate to the service request creation page."),
        ("3", "Create Service Request", "Create a new service request for the customer."),
        ("4", "Submit", "Submit the service request for processing."),
        ("5", "Credit Helpdesk", "Assign the request to a Credit Analyst (CA)."),
        ("6", "Credit Analysis", "Credit analyst reviews and actions the service request."),
        ("7", "Deviations Check (Decision)", "Decision point: Are deviations involved? If Yes → multi-level approval flow."),
        ("8", "Level 4 Approval", "Action on the service request based on deviations at Level 4."),
        ("9", "Level 3 Approval", "Action on the service request based on deviations at Level 3."),
        ("10", "Level 2 Approval", "Action on the service request based on deviations at Level 2."),
        ("11", "Level 1 Approval", "Action on the service request based on deviations at Level 1."),
        ("12", "Credit Letter Generation", "Print letters related to credit decision."),
        ("13", "OPS Helpdesk", "Assign the case to an OPS user for processing."),
        ("14", "OPS Maker", "Operations maker actions the request."),
        ("15", "OPS Checker", "Operations checker reviews and approves the request."),
        ("16", "OPS Letter Printing", "Final letter printing and dispatch.")
    };

    private List<(string Step, string Stage, string Description)> GetComplaintCustomerServiceSteps() => new()
    {
        ("1", "Customer Search", "Search the customer using Customer ID, Application ID, etc."),
        ("2", "Service Request", "Navigate to the desired stage to raise a complaint."),
        ("3", "New Complaint", "Raise a new complaint with all required details."),
        ("4", "Submit", "Submit the already raised complaint for processing.")
    };

    private List<(string Step, string Stage, string Description)> GetComplaintManagementSteps() => new()
    {
        ("5", "Category Master", "Define the Category and Subcategory masters used in dropdown menus."),
        ("6", "Subcategory Master", "Define the Subcategory masters with Assign Users for user assignment dropdowns."),
        ("7", "New Request", "Submit a new request with Customer ID, name, application ID, phone, email, description, and documents."),
        ("8", "Case Assignment", "Check incoming complaints, distribute between team members, assign Category/Subcategory and Status."),
        ("9", "Case Action", "Act on assigned complaints — add remarks, tentative finishing date, reason and documents. Option for higher management approval."),
        ("10", "Complaint Agent Master", "Mapping between department and users for the Reassignment screen dropdowns.")
    };

    #endregion

    #region Reference Data

    private List<(string Name, string Description)> GetSetupScreens() => new()
    {
        ("Project Master (Maker/Checker)", "Project master page is used to add/update project master list. Users can fill in details like project name, developer name, master developer, off plan project, completion date, location country, location city, property address, ownership type, registration type, land type, status, sustainability along with payment details and can upload the required document like engineering report, building completion certificate, title deed etc."),
        ("Contract Mapping – Maker", "Contract mapping master screen is used to define various types of product combinations and associated documents required to create a lending contract between DIB bank and customers."),
        ("Deviation Master", "Deviation master screen enables product team to add/delete/update certain type of listed deviations which can be taken based on business call post analyzing probable risk associated with the application after running deviation/condition via score card policy engine."),
        ("Developer Master", "Developer master maker screen is used for onboarding of new developers where we provide unique developer ID and captures basic details like Developer name, contact person name, address, developer's tier, email address, contact no, city, country etc. This page incorporates check list documents like Engineering Report, Building Completion Certificate, Title Deed etc."),
        ("TL Master", "Team lead master is a screen where functionality of add/update is given where team lead can be associated with respective sales manager, sales head and business channel. It contains dynamic fields with drop down list to select from multiple options. These team leaders may receive sales leads from several channels like branches, auto department, Call Center, Cards department, Personal finance, Web channel etc."),
        ("Evaluator Master", "Lead Evaluator master screen is designed to onboard new evaluators where we can select type of evaluation whether it is for Freehold or Non-Freehold properties, it captures min/max value of the property, evaluators name, email id, managers details and provision to generate security code, select developers and change the status of it i.e. activate/deactivate."),
        ("Valuation Master", "Lead valuation master screen is used to capture data related to project ID, property type, valuation date, min/max PSF, Avg PSF, Avg_QoQ, Avg_YoY values."),
        ("Subvention Master", "Subvention master screen allows to capture the term, percentage and subvention account at contract level. On EMI date a local API will calculate the government contribution on the profit component and raise the accounting entry. Upon full settlement of the EMI by customer, the interim account will be debited and credited to customer CASA account."),
        ("Audit Master – Maker", "Audit master maker screen is used for new auditor onboarding and managing status of auditors. This screen provides new auditor ID, name, category with provision to enable, disable, hold, blacklist, suspend etc. options."),
        ("Rate Review Master – Maker", "Rate review master screen helps in controlling the rates for HF step up product through master maker checker screen to maintain the rates prior implementation date to avoid early morning maintenance job and to help implement the new approved rates by GCEO in faster way.")
    };

    private List<(string Name, string Description)> GetModules() => new()
    {
        ("Complaint Management", "This module is used by Customer Service Team for post-sale activities. User will raise the Complaint by going through Customer Service Module → Customer Search → Service Request → New Complaint button."),
        ("DDA (Direct Debit Authorization)", "The DDA module facilitates contract activation. In cases where a customer does not have a Repayment Account Number, a DDA will be created and registered within the core banking system. This module helps in DDA registration and cancellation which helps in setting up mandates in the customer's account for autopay of EMI against the disbursed loan amount."),
        ("DMS (Document Management System)", "All the scanned documents are stored in DMS. Before storing documents in DMS, QC Team will approve the documents, only approved documents are stored in DMS. User has an option to search the documents using different parameters like Customer Id, Application Id, Customer Name, DOB, Passport No, Mobile No. DMS only supports PDF format documents."),
        ("Documents Handover", "The workflow starts when the Transfer is booked and marked as completed from the PMU Tracker booking stage. PTSH (Pre Transfer Security Handover) provides a centralized dashboard for completed transfers and rollbacked applications."),
        ("Engineering Help Desk", "Engineering Help Desk module is used by the Engineering Team to view, assign and act on service requests. This screen is used for creating new requests with details like Category, Subcategory, Location, Assign Username, Description, and related documents."),
        ("PMU Tracking", "PMU (Property Mortgage Unit) Module is used for activating the contract and performing multiple activities like booking a transfer slot for property, canceling, reassigning, transfer status update and changing booking status to active."),
        ("CPV Module", "This module is used for updating the CPV (Customer Point Verification) details and closing the CPV. Different CPV types include Home Country CPV, Office CPV etc. Application will further be processed if and only if status is positive CPV."),
        ("Underwriting Process – Credit", "The credit module is one of the most crucial ones. Credit analyst takes a decision over customers' credit worthiness with the help of financial documents and AECB score. Score card engine measures risk involved in processing the loan amount, and user can raise the request for evaluation of property."),
        ("Credit HR", "Implemented for staff funding cases with screens like HR Helpdesk, HR Re-assignment, Report, Enquiry, HR Maker, HR Checker. HR reviews staff applicant details and can revert back to HR Helpdesk or CA if updates are needed."),
        ("Underwriting Process – Master", "Multiple master screens for controlling different functionalities and access across various verticals and users. Follows the maker and checker concept for implementing changes."),
        ("Underwriting Process – Operations", "Covers OPS Scrutinizer 1 (Sales) and OPS Scrutinizer 2 (Operations). Includes customer ID creation, due diligence, CIF management, dedupe, and document verification. Users can raise discrepancies related to Takaful checklist, Repayment, Scrutinizer check, PMU check and PDC handover."),
        ("Underwriting Process – Sales", "The HF application PDF form is uploaded using PDF Form - Lead Initiate menu. After uploading, Generate Lead creates a lead number and redirects to Application Data Entry Screen. Enables creation of evaluation requests, affordability checks, offer letter acceptance, and cooling period waivers.")
    };

    private List<(string Module, string Name)> GetReports() => new()
    {
        ("RSU", "RSU Report"), ("RSU", "RSU Doc Security Update Report"), ("RSU", "RSU Ops Checklist Report"),
        ("UTILITY", "SMS Report"), ("UTILITY", "Emails Report"), ("UTILITY", "Letter Printing Report"),
        ("DMS", "DMS Scanned Report"), ("DMS", "Admin DMS Scanned Report"),
        ("Customer Service", "Daily Call Log Report"), ("Customer Service", "Address Change Report"),
        ("BPA Helpdesk", "Reports / My Case Status"),
        ("Complaint Management", "Reports / My Case Status"),
        ("Engineering Helpdesk", "Reports / My Case Status"),
        ("Land Registration", "Reports"),
        ("Property Handover", "Property Handover Report"),
        ("Underwriting Process - Sales", "Report"), ("Underwriting Process - Sales", "Evaluation Report"),
        ("Underwriting Process - Sales", "RM - Report"), ("Underwriting Process - Sales", "Sales Projection Report"),
        ("Underwriting Process - Credit", "Report"), ("Underwriting Process - Credit", "Evaluation Report (ReOpened Cases)"),
        ("Underwriting Process - Credit", "Evaluation Tax Invoice Report"), ("Underwriting Process - Credit", "Evaluation Report (External)"),
        ("Underwriting Process - Credit", "Report - Credit Condition Due Date"),
        ("Underwriting Process - Operation", "Report"), ("Underwriting Process - Operation", "Digital Diary Report"),
        ("Underwriting Process - Operation", "eTitle Deed Report"),
        ("Underwriting Process - CPV", "CPV Report"), ("Underwriting Process - CPV", "CPV QC Report"),
        ("Underwriting Process - Masters", "Audit Master - Report"), ("Underwriting Process - Masters", "Developer Report"),
        ("Underwriting Process - Masters", "Project Report"),
        ("PMU Tracking", "Active Booking - Report"), ("PMU Tracking", "All Booking(Period) - Report"),
        ("PMU Tracking", "All Booking Complete Details - Report"), ("PMU Tracking", "Urgent Bookings - Report"),
        ("PMU Tracking", "View Schedule - Report"), ("PMU Tracking", "Report - Contract Activation"),
        ("DDA", "Active DDA Report"), ("DDA", "DDA Report"),
        ("DDA", "DDA Legacy Cancellation Report"), ("DDA", "DDA Legacy Registration Report"),
        ("Documents Handover", "Report"),
        ("HF - After Sales", "Service Request Report"),
        ("Underwriting Process - Credit HR", "Report")
    };

    private List<(string Module, string Name)> GetMasters() => new()
    {
        ("Complaint Management", "Category Master"), ("Complaint Management", "Subcategory Master"),
        ("Complaint Management", "Complaint - Agent Master"),
        ("Customer Service", "Call Log Category Master"), ("Customer Service", "Service Category Master"),
        ("Customer Service", "Service SubCategory Master"), ("Customer Service", "Service SubCategory Master - Operation"),
        ("Land Registration", "Developer Master"),
        ("Engineering Helpdesk", "Category Master"), ("Engineering Helpdesk", "SubCategory Master"),
        ("Property Handover", "Project Master"),
        ("ADMIN", "Document Printing - Template Master"),
        ("Lead Management", "Survey Master"),
        ("Underwriting Process - Sales", "Lead Allocation MA Master"),
        ("Underwriting Process - Masters", "Eligibility Master (Maker/Checker)"),
        ("Underwriting Process - Masters", "Collaterals Master (Maker/Checker)"),
        ("Underwriting Process - Masters", "Pricing Master"),
        ("Underwriting Process - Masters", "Land Registration Master (Maker/Checker)"),
        ("Underwriting Process - Masters", "Arrangement Fee Master (Maker/Checker)"),
        ("Underwriting Process - Masters", "Project Master (Maker)"),
        ("Underwriting Process - Masters", "Condition For Approval Master"),
        ("Underwriting Process - Masters", "Developer Master (Maker)"),
        ("Underwriting Process - Masters", "Deviation Master"),
        ("Underwriting Process - Masters", "Company / Employer Master (Maker/Checker)"),
        ("Underwriting Process - Masters", "TL Master"),
        ("Underwriting Process - Masters", "Evaluator Master (Maker/Checker)"),
        ("Underwriting Process - Masters", "Valuation Master (Maker/Checker)"),
        ("Underwriting Process - Masters", "Subvention Master"),
        ("Underwriting Process - Masters", "Audit Master (Maker/Checker/Report)"),
        ("Underwriting Process - Masters", "Rate Review Master (Maker/Checker)")
    };

    #endregion
}
