﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using DocGenerator.Services;

namespace DocGenerator.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {
    }

    public IActionResult OnPost()
    {
        // Find the DIB logo in the workspace root
        var baseDir = Directory.GetCurrentDirectory();
        var logoPath = Path.GetFullPath(Path.Combine(baseDir, "..", "..", "DIB-Logo-Website.jpg"));
        if (!System.IO.File.Exists(logoPath))
            logoPath = Path.GetFullPath(Path.Combine(baseDir, "..", "..", "..", "DIB-Logo-Website.jpg"));
        
        var generator = new HflmsDocumentGenerator(logoPath);
        var docBytes = generator.GenerateDocument();

        return File(docBytes,
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "HFLMS_Documentation.docx");
    }
}
