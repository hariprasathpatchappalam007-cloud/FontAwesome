using System;
using System.Data;
using System.Globalization;
using System.Text;
using DFM.App_Code.DAL;
using DFM.App_Code.Helpers;

namespace DFM
{
    public partial class DefaultPage : System.Web.UI.Page
    {
        // Budget/financial KPI chart data
        public string JsCapexBudget { get; private set; }
        public string JsOpexBudget  { get; private set; }
        public string JsUtilized    { get; private set; }
        public string JsAvailable   { get; private set; }
        public string JsLocked      { get; private set; }
        public string JsPending     { get; private set; }
        public string JsApproved    { get; private set; }
        public string JsRejected    { get; private set; }
        public string JsDraft       { get; private set; }

        public DefaultPage()
        {
            JsCapexBudget = "0"; JsOpexBudget = "0"; JsUtilized = "0";
            JsAvailable = "0"; JsLocked = "0";
            JsPending = "0"; JsApproved = "0"; JsRejected = "0"; JsDraft = "0";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindRequestedByFilter();
                LoadDashboard();
            }
        }

        private void BindRequestedByFilter()
        {
            ddlRequestedBy.Items.Clear();
            ddlRequestedBy.Items.Add(new System.Web.UI.WebControls.ListItem("All", "ALL"));
            try
            {
                DataTable dt = Db.Query("SELECT DISTINCT CreatedBy FROM Projects WHERE CreatedBy IS NOT NULL ORDER BY CreatedBy");
                foreach (DataRow r in dt.Rows)
                {
                    string user = r["CreatedBy"].ToString();
                    if (!string.IsNullOrEmpty(user))
                        ddlRequestedBy.Items.Add(new System.Web.UI.WebControls.ListItem(user, user));
                }
            }
            catch { }
        }

        protected void Filter_Changed(object sender, EventArgs e)
        {
            LoadDashboard();
        }

        private void LoadDashboard()
        {
            DataRow s = ProjectsDAL.GetDashboardSummary();
            decimal capexBudget = ToDec(s, "TotalCapexBudget");
            decimal opexBudget  = ToDec(s, "TotalOpexBudget");
            decimal utilized    = ToDec(s, "TotalUtilized");
            decimal available   = ToDec(s, "TotalAvailable");
            decimal locked      = ToDec(s, "TotalLocked");

            int total    = ToInt(s, "TotalProjects");
            int pending  = ToInt(s, "PendingApproval");
            int approved = ToInt(s, "Approved");
            int rejected = ToInt(s, "Rejected");

            kTotalProjects.Text = total.ToString("N0");
            kCapexBudget.Text   = capexBudget.ToString("N0");
            kOpexBudget.Text    = opexBudget.ToString("N0");
            kUtilized.Text      = utilized.ToString("N0");
            kAvailable.Text     = available.ToString("N0");
            kLocked.Text        = locked.ToString("N0");
            kPending.Text       = pending.ToString("N0");
            kApproved.Text      = approved.ToString("N0");
            kRejected.Text      = rejected.ToString("N0");

            decimal totalBudget = capexBudget + opexBudget;
            int pct = totalBudget > 0 ? Math.Min(100, (int)Math.Round((utilized / totalBudget) * 100m)) : 0;
            litMeterPct.Text = pct.ToString() + "%";

            JsCapexBudget = capexBudget.ToString(CultureInfo.InvariantCulture);
            JsOpexBudget  = opexBudget.ToString(CultureInfo.InvariantCulture);
            JsUtilized    = utilized.ToString(CultureInfo.InvariantCulture);
            JsAvailable   = available.ToString(CultureInfo.InvariantCulture);
            JsLocked      = locked.ToString(CultureInfo.InvariantCulture);
            JsPending     = pending.ToString();
            JsApproved    = approved.ToString();
            JsRejected    = rejected.ToString();
            JsDraft       = (total - pending - approved - rejected).ToString();

            // Last refreshed
            litLastRefreshed.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt");

            // Budget source utilization cards
            BindBudgetCards();

            // Pending actions tree view
            BindProjectTree();
        }

        private void BindBudgetCards()
        {
            try
            {
                DataTable dt = ProjectsDAL.GetBudgetSourceCards();
                if (dt == null || dt.Rows.Count == 0)
                {
                    litBudgetCards.Text = "<p class='text-muted' style='padding:8px;'>No budget sources configured.</p>";
                    return;
                }

                var sb = new StringBuilder();
                foreach (string section in new[] { "CAPEX", "OPEX" })
                {
                    var rows = dt.Select("BudgetType='" + section + "'");
                    if (rows.Length == 0) continue;

                    sb.AppendFormat("<div class='budget-section-header'><span class='glyphicon glyphicon-{0}'></span> {1}</div>",
                        section == "CAPEX" ? "signal" : "refresh", section);
                    sb.Append("<div class='budget-card-list'>");
                    foreach (DataRow r in rows)
                    {
                        decimal budget = ToDec(r, "Budget");
                        decimal used   = ToDec(r, "Utilization");
                        decimal locked = ToDec(r, "LockedAmount");
                        decimal pct    = budget > 0 ? Math.Min(100m, Math.Round(used / budget * 100m, 1)) : 0m;
                        string btype   = r["BudgetType"].ToString();
                        string code    = r["SourceCode"].ToString();
                        string desc    = HtmlEnc(r["Description"].ToString());
                        string badgeCss = btype == "CAPEX" ? "info" : "ok";

                        // Req 2.6: CAPEX cards open SourceHistory in new tab
                        if (btype == "CAPEX")
                        {
                            string href = "/forms/SourceHistory.aspx?type=CAPEX&amp;id=" + System.Web.HttpUtility.UrlEncode(code);
                            sb.AppendFormat("<div class='budget-card budget-card-link' onclick=\"window.open('{0}','_blank');\">", href);
                        }
                        else
                        {
                            sb.Append("<div class='budget-card'>");
                        }
                        sb.AppendFormat("<div class='bc-type'><span class='tree-badge {0}'>{1}</span></div>", badgeCss, HtmlEnc(btype));
                        sb.AppendFormat("<div class='bc-header'><span>{0}</span><span>AED {1} M</span></div>", HtmlEnc(code), (budget / 1000000m).ToString("N2"));
                        sb.AppendFormat("<div class='bc-desc'>{0}</div>", desc);
                        sb.AppendFormat("<div class='bc-used'>Used AED {0} M &bull; Locked AED {1} M</div>",
                            (used / 1000000m).ToString("N2"), (locked / 1000000m).ToString("N2"));
                        sb.AppendFormat("<div class='bc-bar'><span style='width:{0}%'></span></div>", pct);
                        sb.Append("</div>");
                    }
                    sb.Append("</div>");
                }
                litBudgetCards.Text = sb.ToString();
            }
            catch { litBudgetCards.Text = ""; }
        }

        private void BindProjectTree()
        {
            string ptype = ddlType.SelectedValue;
            string status = ddlStatus.SelectedValue;
            string requestedBy = ddlRequestedBy.SelectedValue;
            DateTime? fromDate = null, toDate = null;
            DateTime dt2;
            if (DateTime.TryParse(txtFromDate.Text, out dt2)) fromDate = dt2;
            if (DateTime.TryParse(txtToDate.Text, out dt2)) toDate = dt2;

            try
            {
                DataSet ds = ProjectsDAL.GetProjectTreeData(ptype, status, requestedBy, fromDate, toDate);
                DataTable projects = ds.Tables["Projects"];
                DataTable petTotals = ds.Tables["PETTotals"];
                DataTable memos     = ds.Tables["Memos"];
                DataTable invoices  = ds.Tables["Invoices"];

                if (projects.Rows.Count == 0)
                {
                    litTree.Text = "<p class='text-muted' style='padding:8px;'>No projects match the selected filters.</p>";
                    return;
                }

                var sb = new StringBuilder();
                sb.Append("<table class='tree-table'>");
                sb.Append("<thead><tr>");
                sb.Append("<th>Node</th><th>Type</th><th>Amount (AED)</th><th>Status</th><th>Pending With</th><th>Details</th><th></th>");
                sb.Append("</tr></thead><tbody>");

                foreach (DataRow prj in projects.Rows)
                {
                    int pid = Convert.ToInt32(prj["ProjectID"]);
                    string pcode = HtmlEnc(prj["ProjectCode"].ToString());
                    string pname = HtmlEnc(prj["ProjectName"].ToString());
                    string ptype2 = prj["ProjectType"].ToString();
                    string pstatus = prj["Status"].ToString();
                    decimal pamt = ToDec(prj, "RequestedAmount");
                    string stage = prj["CurrentStage"] == DBNull.Value ? "" : prj["CurrentStage"].ToString();
                    string approver = prj["ApproverName"] == DBNull.Value ? "" : prj["ApproverName"].ToString();
                    string petApprStatus = prj["PetApprovalStatus"] == DBNull.Value ? "" : prj["PetApprovalStatus"].ToString();
                    // Show pending-with only when genuinely pending approval
                    string pendingWith = string.Equals(petApprStatus, "Pending", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(approver)
                        ? "<span class='pending-with-label'><span class='glyphicon glyphicon-user'></span> " + HtmlEnc(approver) + "</span>"
                        : "&mdash;";
                    string togId = "p" + pid;

                    // Determine if this project has children
                    DataRow[] petRows  = petTotals.Select("ProjectID=" + pid);
                    DataRow[] memoRows = memos.Select("ProjectID=" + pid);
                    bool hasChildren = petRows.Length > 0 || memoRows.Length > 0;

                    // Project row
                    sb.Append("<tr>");
                    sb.Append("<td>");
                    if (hasChildren)
                        sb.AppendFormat("<span class='tree-toggle' data-tog='{0}' onclick=\"dfmTog('{0}')\">&#9658;</span>", togId);
                    sb.AppendFormat("<strong>{0}</strong> {1}", pcode, pname);
                    sb.Append("</td>");
                    sb.AppendFormat("<td><span class='chip chip-{0}'>{0}</span></td>", ptype2.ToLower());
                    sb.AppendFormat("<td>AED {0} M</td>", (pamt / 1000000m).ToString("N2"));
                    sb.AppendFormat("<td>{0}</td>", StatusBadge(pstatus));
                    sb.AppendFormat("<td>{0}</td>", pendingWith);
                    sb.AppendFormat("<td>{0}</td>", HtmlEnc(stage));
                    sb.AppendFormat("<td><a class='btn btn-xs btn-primary' href='Forms/Workflow.aspx?id={0}'>Open</a></td>", pid);
                    sb.Append("</tr>");

                    // PET child row
                    if (petRows.Length > 0)
                    {
                        DataRow pet = petRows[0];
                        decimal petAmt = ToDec(pet, "TotalAED");
                        int lineCount  = Convert.ToInt32(pet["LineCount"]);
                        string petAppr = pet["PetApprovalStatus"] == DBNull.Value ? "Pending" : pet["PetApprovalStatus"].ToString();
                        string petPendingWith = string.Equals(petAppr, "Pending", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(approver)
                            ? "<span class='pending-with-label'><span class='glyphicon glyphicon-user'></span> " + HtmlEnc(approver) + "</span>"
                            : "&mdash;";
                        sb.AppendFormat("<tr class='tree-row {0} tree-hidden'>", togId);
                        sb.Append("<td class='indent1'>&#128196; PET Sheet</td>");
                        sb.Append("<td>PET</td>");
                        sb.AppendFormat("<td>AED {0} M</td>", (petAmt / 1000000m).ToString("N2"));
                        sb.AppendFormat("<td>{0}</td>", StatusBadge(petAppr));
                        sb.AppendFormat("<td>{0}</td>", petPendingWith);
                        sb.AppendFormat("<td>{0} line item{1}</td><td></td>", lineCount, lineCount == 1 ? "" : "s");
                        sb.Append("</tr>");
                    }

                    // Memo child rows
                    foreach (DataRow memo in memoRows)
                    {
                        int mid = Convert.ToInt32(memo["MemoID"]);
                        string mnum  = HtmlEnc(memo["MemoNumber"].ToString());
                        string mvend = HtmlEnc(memo["VendorName"].ToString());
                        decimal mamt = ToDec(memo, "ApprovedAmountAED");
                        decimal mdis = ToDec(memo, "AmountDisbursed");
                        string mstatus = memo["CAMStatus"].ToString();
                        string mTogId = "m" + mid;
                        DataRow[] invRows = invoices.Select("MemoID=" + mid);
                        bool hasInv = invRows.Length > 0;

                        // Memo row
                        sb.AppendFormat("<tr class='tree-row {0} tree-hidden'>", togId);
                        sb.Append("<td class='indent1'>");
                        if (hasInv)
                            sb.AppendFormat("<span class='tree-toggle' data-tog='{0}' onclick=\"dfmTog('{1} {0}')\">&#9658;</span>", mTogId, togId);
                        sb.AppendFormat("&#129534; {0} &mdash; {1}", mnum, mvend);
                        sb.Append("</td>");
                        sb.Append("<td>Memo</td>");
                        sb.AppendFormat("<td>AED {0} M</td>", (mamt / 1000000m).ToString("N2"));
                        sb.AppendFormat("<td>{0}</td>", StatusBadge(mstatus));
                        sb.Append("<td>&mdash;</td>");  // Pending With (n/a for memos)
                        string lpo = HtmlEnc(memo["LPO_SO_Number"].ToString());
                        sb.AppendFormat("<td>LPO: {0} &bull; Disbursed: AED {1} M</td><td></td>",
                            string.IsNullOrEmpty(lpo) ? "&mdash;" : lpo,
                            (mdis / 1000000m).ToString("N2"));
                        sb.Append("</tr>");

                        // Invoice rows
                        foreach (DataRow inv in invRows)
                        {
                            string inum   = HtmlEnc(inv["InvoiceNumber"].ToString());
                            decimal iamt  = ToDec(inv, "InvoiceAmountAED");
                            string istatus = inv["InvoiceStatus"].ToString();
                            string idate  = inv["InvoiceDate"] == DBNull.Value ? "" :
                                Convert.ToDateTime(inv["InvoiceDate"]).ToString("MMM-yyyy");

                            sb.AppendFormat("<tr class='tree-row {0} {1} tree-hidden'>", togId, mTogId);
                            sb.AppendFormat("<td class='indent2'>&#128176; {0}</td>", inum);
                            sb.Append("<td>Invoice</td>");
                            sb.AppendFormat("<td>AED {0} M</td>", (iamt / 1000000m).ToString("N2"));
                            sb.AppendFormat("<td>{0}</td>", StatusBadge(istatus));
                            sb.AppendFormat("<td>{0}</td><td></td>", idate);
                            sb.Append("</tr>");
                        }
                    }
                }

                sb.Append("</tbody></table>");
                litTree.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                litTree.Text = "<p class='text-muted' style='padding:8px;'>Unable to load tree data. " + HtmlEnc(ex.Message) + "</p>";
            }
        }

        private static string StatusBadge(string s)
        {
            if (string.IsNullOrEmpty(s)) s = "Pending";
            string css;
            switch (s.ToLower())
            {
                case "approved": css = "ok"; break;
                case "paid": css = "ok"; break;
                case "issued": css = "ok"; break;
                case "closed": css = "ok"; break;
                case "pending": css = "warn"; break;
                case "submitted": css = "info"; break;
                case "open": css = "info"; break;
                case "rejected": css = "danger"; break;
                case "draft": css = "muted"; break;
                default: css = "muted"; break;
            }
            return string.Format("<span class='tree-badge {0}'>{1}</span>", css, HtmlEnc(s));
        }

        private static string HtmlEnc(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return System.Web.HttpUtility.HtmlEncode(s);
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            string ptype = ddlType.SelectedValue;
            string status = ddlStatus.SelectedValue;
            DataTable dt = ProjectsDAL.GetProjects(ptype == "ALL" ? null : ptype,
                                                   status == "ALL" ? null : status);
            ExcelHelper.ExportToExcel(Response, dt, "DFM_Dashboard_Projects_" + DateTime.Now.ToString("yyyyMMdd_HHmm"));
        }

        private static int ToInt(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return 0;
            return Convert.ToInt32(r[col]);
        }
        private static decimal ToDec(DataRow r, string col)
        {
            if (r == null || r[col] == DBNull.Value) return 0m;
            return Convert.ToDecimal(r[col]);
        }
    }
}
