// Shared sidebar navigation — included by every page
(function () {
  const nav = [
    { label: 'Home', icon: '🏠', href: 'index.html', section: 'GUIDE' },
    { label: 'Introduction', icon: '📖', href: 'introduction.html' },
    { label: 'Dashboard', icon: '📊', href: 'dashboard.html' },
    { label: 'Filtering Profiles', icon: '🔍', href: 'dashboard.html#filtering', sub: true },
    { label: 'Profile Grid', icon: '📋', href: 'dashboard.html#grid', sub: true },
    { label: 'Profile Management', icon: '👤', href: 'profiles.html', section: 'FEATURES' },
    { label: 'Load Profile', icon: '📂', href: 'profiles.html#load', sub: true },
    { label: 'New Profile', icon: '➕', href: 'profiles.html#new', sub: true },
    { label: 'Clone Profile', icon: '🔁', href: 'profiles.html#clone', sub: true },
    { label: 'Save to Database', icon: '💾', href: 'save-db.html' },
    { label: 'Export Data', icon: '⬇️', href: 'export.html' },
    { label: 'Upload Data', icon: '⬆️', href: 'upload.html' },
    { label: 'View Raw Data', icon: '🧾', href: 'raw-data.html' },
    { label: 'Navigation Menu', icon: '🗂️', href: 'navigation.html', section: 'REFERENCE' },
    { label: 'Tips & Best Practices', icon: '💡', href: 'tips.html' },
  ];

  const currentPage = location.pathname.split('/').pop() || 'index.html';

  let html = '';
  for (const item of nav) {
    if (item.section) {
      html += `<div class="sidebar-section-title">${item.section}</div>`;
    }
    const active = currentPage === item.href.split('#')[0] ? 'active' : '';
    const sub    = item.sub ? 'sub-item' : '';
    html += `<li class="${sub}"><a href="${item.href}" class="${active}">
               <span class="nav-icon">${item.icon}</span>${item.label}
             </a></li>`;
  }

  document.querySelectorAll('.sidebar nav ul').forEach(el => {
    el.innerHTML = html;
  });
})();
