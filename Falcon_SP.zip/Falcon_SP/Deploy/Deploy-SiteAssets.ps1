<#
.SYNOPSIS
    Falcon PET – Deploy SiteAssets to SharePoint using CSOM / PnP PowerShell.
.DESCRIPTION
    Uploads the entire SiteAssets/PET folder to the SharePoint site's
    SiteAssets library, preserving the folder structure.

.PARAMETER SiteUrl
    Full URL of the SharePoint site, e.g. https://your-tenant.sharepoint.com/sites/PET
.PARAMETER Username
    SharePoint Online username (UPN) or leave blank for interactive login.
.PARAMETER Password
    Password (plain text; use only for automation – prefer interactive auth).
.PARAMETER LocalSource
    Path to the SiteAssets\PET folder on the local machine.
    Defaults to $PSScriptRoot\..\SiteAssets\PET
.PARAMETER TargetFolder
    Target folder name inside the SiteAssets library. Default: PET

.EXAMPLE
    .\Deploy-SiteAssets.ps1 -SiteUrl "https://contoso.sharepoint.com/sites/PET" `
                             -Username "admin@contoso.com"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SiteUrl,

    [string]$Username = "",
    [string]$Password = "",

    [string]$LocalSource = "",
    [string]$TargetFolder = "PET"
)

# ── Resolve source path ───────────────────────────────────────────────────────
if (-not $LocalSource) {
    $LocalSource = Join-Path $PSScriptRoot "..\SiteAssets\PET"
}
$LocalSource = Resolve-Path $LocalSource -ErrorAction Stop

Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  Falcon PET – SiteAssets Deployment" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  Source : $LocalSource"
Write-Host "  Target : $SiteUrl/SiteAssets/$TargetFolder"

# ── Require PnP.PowerShell module ─────────────────────────────────────────────
if (-not (Get-Module -ListAvailable -Name PnP.PowerShell)) {
    Write-Host "`n[!] PnP.PowerShell module not found. Installing..." -ForegroundColor Yellow
    Install-Module PnP.PowerShell -Scope CurrentUser -Force -AllowClobber
}
Import-Module PnP.PowerShell -ErrorAction Stop

# ── Connect ───────────────────────────────────────────────────────────────────
Write-Host "`n[1/3] Connecting to SharePoint..." -ForegroundColor White
try {
    if ($Username -and $Password) {
        $secPwd = ConvertTo-SecureString $Password -AsPlainText -Force
        $cred   = New-Object System.Management.Automation.PSCredential($Username, $secPwd)
        Connect-PnPOnline -Url $SiteUrl -Credentials $cred
    } else {
        Connect-PnPOnline -Url $SiteUrl -Interactive
    }
    Write-Host "  Connected." -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Connection failed: $_" -ForegroundColor Red
    exit 1
}

# ── Ensure SiteAssets/PET folder exists ───────────────────────────────────────
Write-Host "`n[2/3] Ensuring target folder structure..." -ForegroundColor White
function Ensure-SPFolder {
    param([string]$LibraryName, [string]$FolderPath)
    try {
        Resolve-PnPFolder -SiteRelativePath "$LibraryName/$FolderPath" -ErrorAction SilentlyContinue | Out-Null
        Add-PnPFolder -Name (Split-Path $FolderPath -Leaf) `
                      -Folder "$LibraryName/$(Split-Path $FolderPath -Parent)" `
                      -ErrorAction SilentlyContinue | Out-Null
        Write-Host "  Folder: $LibraryName/$FolderPath" -ForegroundColor DarkGray
    } catch {}
}
Ensure-SPFolder -LibraryName "SiteAssets" -FolderPath $TargetFolder

# ── Upload files recursively ──────────────────────────────────────────────────
Write-Host "`n[3/3] Uploading files..." -ForegroundColor White
$allFiles = Get-ChildItem -Path $LocalSource -Recurse -File
$total    = $allFiles.Count
$count    = 0

foreach ($file in $allFiles) {
    $count++
    $relativePath  = $file.FullName.Substring($LocalSource.Length + 1)
    $relativeDir   = Split-Path $relativePath -Parent
    $targetLibPath = if ($relativeDir) { "SiteAssets/$TargetFolder/$relativeDir" } else { "SiteAssets/$TargetFolder" }

    # Ensure subfolder
    if ($relativeDir) {
        $parts = $relativeDir -split [regex]::Escape([IO.Path]::DirectorySeparatorChar)
        $built = ""
        foreach ($part in $parts) {
            $built = if ($built) { "$built/$part" } else { $part }
            Ensure-SPFolder -LibraryName "SiteAssets" -FolderPath "$TargetFolder/$built"
        }
    }

    try {
        Add-PnPFile -Path $file.FullName -Folder $targetLibPath -ErrorAction Stop | Out-Null
        Write-Host "  [$count/$total] $relativePath" -ForegroundColor Green
    } catch {
        Write-Host "  [FAIL] $relativePath – $_" -ForegroundColor Red
    }
}

Write-Host "`n═══════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  Deployment complete! $count of $total files uploaded." -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan

Disconnect-PnPOnline
