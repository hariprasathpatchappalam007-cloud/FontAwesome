# Falcon PET – Download Third-Party JS/CSS Libraries
# Run this script from the Deploy folder to fetch all vendor libraries
# into SiteAssets\PET\JS and SiteAssets\PET\Libraries.

$root    = Split-Path $PSScriptRoot
$libDir  = Join-Path $root "SiteAssets\PET\JS"
$extDir  = Join-Path $root "SiteAssets\PET\Libraries"
$cssDir  = Join-Path $root "SiteAssets\PET\CSS"

New-Item -ItemType Directory -Force -Path $libDir  | Out-Null
New-Item -ItemType Directory -Force -Path $extDir  | Out-Null
New-Item -ItemType Directory -Force -Path $cssDir  | Out-Null

$libraries = @(
    # AngularJS core + modules (1.8.3 – last stable 1.x)
    @{ Url = "https://ajax.googleapis.com/ajax/libs/angularjs/1.8.3/angular.min.js";           Dest = "$libDir\angular.min.js"            },
    @{ Url = "https://ajax.googleapis.com/ajax/libs/angularjs/1.8.3/angular-route.min.js";     Dest = "$libDir\angular-route.min.js"      },
    @{ Url = "https://ajax.googleapis.com/ajax/libs/angularjs/1.8.3/angular-resource.min.js";  Dest = "$libDir\angular-resource.min.js"   },
    @{ Url = "https://ajax.googleapis.com/ajax/libs/angularjs/1.8.3/angular-sanitize.min.js";  Dest = "$libDir\angular-sanitize.min.js"   },

    # jQuery 3.7
    @{ Url = "https://code.jquery.com/jquery-3.7.1.min.js";                                   Dest = "$libDir\jquery.min.js"             },

    # Bootstrap 4.6
    @{ Url = "https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js";         Dest = "$libDir\bootstrap.min.js"          },
    @{ Url = "https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css";       Dest = "$cssDir\bootstrap.min.css"            },

    # Moment.js
    @{ Url = "https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js";                      Dest = "$extDir\moment.min.js"             },

    # PapaParse (CSV)
    @{ Url = "https://cdn.jsdelivr.net/npm/papaparse@5.4.1/papaparse.min.js";                 Dest = "$extDir\PapaParse.min.js"          },

    # SheetJS / XLSX
    @{ Url = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";                Dest = "$extDir\xlsx.full.min.js"          },

    # Chart.js 3
    @{ Url = "https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js";                 Dest = "$extDir\Chart.min.js"              },

    # SweetAlert2
    @{ Url = "https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js";       Dest = "$extDir\sweetalert2.all.min.js"    },

    # Font Awesome 5 (webfont kit)
    @{ Url = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css";    Dest = "$cssDir\font-awesome.min.css"         }
)

Write-Host "Downloading $($libraries.Count) libraries..." -ForegroundColor Cyan
$i = 0
foreach ($lib in $libraries) {
    $i++
    $fileName = Split-Path $lib.Dest -Leaf
    Write-Host "  [$i/$($libraries.Count)] $fileName" -NoNewline
    try {
        $dir = Split-Path $lib.Dest
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        Invoke-WebRequest -Uri $lib.Url -OutFile $lib.Dest -UseBasicParsing -ErrorAction Stop
        Write-Host " OK" -ForegroundColor Green
    } catch {
        Write-Host " FAIL: $_" -ForegroundColor Red
    }
}

Write-Host "`nDone. Libraries saved to SiteAssets\PET\JS and SiteAssets\PET\Libraries" -ForegroundColor Green
