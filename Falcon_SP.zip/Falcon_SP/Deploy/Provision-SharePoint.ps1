<#
.SYNOPSIS
    Falcon PET – Run CSOM provisioning (create all SharePoint lists, libraries, columns).
.DESCRIPTION
    Builds and runs the Falcon_SP.Provision .NET console application, which provisions
    all required SharePoint lists, document libraries, site columns and content types.

.PARAMETER SiteUrl     Target SharePoint site URL.
.PARAMETER Username    SharePoint Online UPN (leave blank for Windows auth).
.PARAMETER Password    Password in plain text (automation only).

.EXAMPLE
    .\Provision-SharePoint.ps1 -SiteUrl "https://contoso.sharepoint.com/sites/PET" `
                                -Username "admin@contoso.com" -Password "P@ssw0rd"
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$SiteUrl,
    [string]$Username = "",
    [string]$Password = "",
    [string]$Domain   = ""
)

$provisionDir  = Join-Path $PSScriptRoot "..\Provision"
$configFile    = Join-Path $provisionDir "App.config"
$csproj        = Join-Path $provisionDir "Falcon_SP.Provision.csproj"

Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  Falcon PET – SharePoint Provisioning" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan

# ── Patch App.config ──────────────────────────────────────────────────────────
Write-Host "`n[1/3] Updating App.config..." -ForegroundColor White
[xml]$config = Get-Content $configFile
function Set-AppSetting { param($name, $value)
    $node = $config.configuration.appSettings.add | Where-Object { $_.key -eq $name }
    if ($node) { $node.value = $value }
}
Set-AppSetting "SiteUrl"   $SiteUrl
Set-AppSetting "Username"  $Username
Set-AppSetting "Password"  $Password
Set-AppSetting "Domain"    $Domain
$config.Save($configFile)
Write-Host "  App.config updated." -ForegroundColor Green

# ── NuGet restore ─────────────────────────────────────────────────────────────
Write-Host "`n[2/3] Restoring NuGet packages..." -ForegroundColor White
$nuget = Get-Command nuget -ErrorAction SilentlyContinue
if ($nuget) {
    & nuget restore $csproj -Verbosity quiet
    Write-Host "  Packages restored." -ForegroundColor Green
} else {
    Write-Host "  [WARN] nuget.exe not found – ensure packages are already restored." -ForegroundColor Yellow
}

# ── Build & run ───────────────────────────────────────────────────────────────
Write-Host "`n[3/3] Building and running provisioner..." -ForegroundColor White
$msbuild = & "${env:ProgramFiles(x86)}\Microsoft Visual Studio\*\*\MSBuild\Current\Bin\MSBuild.exe" `
            $csproj /p:Configuration=Release /nologo /v:m 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Build failed." -ForegroundColor Red
    $msbuild | ForEach-Object { Write-Host $_ }
    exit 1
}

$exe = Join-Path $provisionDir "bin\Release\Falcon_SP.Provision.exe"
if (-not (Test-Path $exe)) {
    Write-Host "[ERROR] Executable not found at $exe" -ForegroundColor Red
    exit 1
}

& $exe
if ($LASTEXITCODE -eq 0) {
    Write-Host "`n[SUCCESS] Provisioning completed." -ForegroundColor Green
} else {
    Write-Host "`n[ERROR] Provisioning failed with exit code $LASTEXITCODE" -ForegroundColor Red
}
