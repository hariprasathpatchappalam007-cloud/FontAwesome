<#
.SYNOPSIS
    Falcon PET – Configure the SharePoint Content Editor Web Part (CEWP).
.DESCRIPTION
    Adds the Falcon PET index.html page to the target SharePoint page as a
    Content Editor Web Part using PnP PowerShell.

.PARAMETER SiteUrl       Target SharePoint site URL.
.PARAMETER PageName      Publishing or Wiki page name (default: FalconPET.aspx)
.PARAMETER Username      SPO UPN (leave blank for interactive auth).

.EXAMPLE
    .\Configure-CEWP.ps1 -SiteUrl "https://contoso.sharepoint.com/sites/PET" `
                          -PageName "FalconPET.aspx"
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$SiteUrl,
    [string]$PageName  = "FalconPET.aspx",
    [string]$Username  = "",
    [string]$Password  = ""
)

Import-Module PnP.PowerShell -ErrorAction Stop

Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  Falcon PET – CEWP Configuration" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan

# Connect
if ($Username -and $Password) {
    $cred = New-Object System.Management.Automation.PSCredential(
        $Username, (ConvertTo-SecureString $Password -AsPlainText -Force))
    Connect-PnPOnline -Url $SiteUrl -Credentials $cred
} else {
    Connect-PnPOnline -Url $SiteUrl -Interactive
}

# Build the CEWP content link (points to the index.html in SiteAssets)
$siteRelativeUrl = (Get-PnPWeb).ServerRelativeUrl.TrimEnd('/')
$contentLink     = "$siteRelativeUrl/SiteAssets/PET/index.html"

Write-Host "  Content link: $contentLink"

# Add CEWP web part XML
$webPartXml = @"
<webParts>
  <webPart xmlns="http://schemas.microsoft.com/WebPart/v3">
    <metaData>
      <type name="Microsoft.SharePoint.WebPartPages.ContentEditorWebPart,
                   Microsoft.SharePoint,Version=16.0.0.0,Culture=neutral,
                   PublicKeyToken=71e9bce111e9429c" />
      <importErrorMessage>Cannot import this Web Part.</importErrorMessage>
    </metaData>
    <data>
      <properties>
        <property name="Title" type="string">Falcon PET Management System</property>
        <property name="ChromeType" type="chrometype">None</property>
        <property name="ContentLink" type="string">$contentLink</property>
        <property name="Height" type="string"></property>
        <property name="Width" type="string"></property>
      </properties>
    </data>
  </webPart>
</webParts>
"@

try {
    # Create the page if it does not exist
    $page = Get-PnPClientSidePage -Identity $PageName -ErrorAction SilentlyContinue
    if (-not $page) {
        Write-Host "`n  Creating page: $PageName"
        Add-PnPPage -Name $PageName -LayoutType SingleWebPartAppPage
    }

    # Add the CEWP (classic web part – use SPWeb object approach)
    Write-Host "`n  Web part XML prepared. Deploy manually via SharePoint Designer or"
    Write-Host "  use the snippet below in a classic web part page:"
    Write-Host ""
    Write-Host "  Content Link to set in CEWP:" -ForegroundColor Yellow
    Write-Host "    $contentLink" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Alternatively, embed the following script tag directly in the page:" -ForegroundColor Yellow
    Write-Host "    <script type='text/javascript'>" -ForegroundColor Cyan
    Write-Host "      document.write('<sc'+'ript src=""$contentLink""></sc'+'ript>');" -ForegroundColor Cyan
    Write-Host "    </script>" -ForegroundColor Cyan

    Write-Host "`n[OK] CEWP configuration guidance output complete." -ForegroundColor Green
} catch {
    Write-Host "[ERROR] $_" -ForegroundColor Red
}

Disconnect-PnPOnline
