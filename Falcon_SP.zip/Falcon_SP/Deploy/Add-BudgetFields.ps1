# ═══════════════════════════════════════════════════════════════
# Add-BudgetFields.ps1
# Adds missing budget columns to CAPEX Master and OPEX Master lists.
# Run this ONCE on the SharePoint server if the lists only have:
#   Title, CAPEXCode, CAPEXName, Description, IsActive
# ═══════════════════════════════════════════════════════════════

param(
    [string]$SiteUrl = "http://10.240.176.204:5050/sites/CET"
)

Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

$web = Get-SPWeb $SiteUrl

function Add-NumberField($list, $internalName, $displayName) {
    if ($list.Fields.ContainsField($internalName)) {
        Write-Host "  [SKIP] $internalName already exists" -ForegroundColor DarkGray
        return
    }
    $list.Fields.Add($internalName, [Microsoft.SharePoint.SPFieldType]::Number, $false)
    $field = $list.Fields[$internalName]
    $field.Title = $displayName
    $field.Update()
    Write-Host "  [ADD] $internalName ($displayName)" -ForegroundColor Green
}

function Add-NoteField($list, $internalName, $displayName) {
    if ($list.Fields.ContainsField($internalName)) {
        Write-Host "  [SKIP] $internalName already exists" -ForegroundColor DarkGray
        return
    }
    $list.Fields.Add($internalName, [Microsoft.SharePoint.SPFieldType]::Note, $false)
    $field = $list.Fields[$internalName]
    $field.Title = $displayName
    $field.Update()
    Write-Host "  [ADD] $internalName ($displayName)" -ForegroundColor Green
}

function Add-DateField($list, $internalName, $displayName) {
    if ($list.Fields.ContainsField($internalName)) {
        Write-Host "  [SKIP] $internalName already exists" -ForegroundColor DarkGray
        return
    }
    $list.Fields.Add($internalName, [Microsoft.SharePoint.SPFieldType]::DateTime, $false)
    $field = $list.Fields[$internalName]
    $field.Title = $displayName
    $field.Update()
    Write-Host "  [ADD] $internalName ($displayName)" -ForegroundColor Green
}

# ── CAPEX Master ──────────────────────────────────────────────────
Write-Host "`n=== CAPEX Master ===" -ForegroundColor Cyan
$capexList = $web.Lists["CAPEX Master"]
if ($capexList) {
    Add-NumberField $capexList "BudgetedAmount" "Budget"
    Add-NumberField $capexList "UtilizedAmount" "Utilization"
    Add-NumberField $capexList "AvailableAmount" "Available Budget"
    Add-NumberField $capexList "LockedAmount" "Locked Amt"
    Add-NumberField $capexList "BudgetAfterLocked" "Budget After Locked"
    Add-NumberField $capexList "ClaimAmount" "Claim Amt"
    Add-NumberField $capexList "NetBalance" "Net Balance"
    Add-NoteField   $capexList "GLNumbers" "GL Numbers"
    Add-DateField   $capexList "LastSyncDate" "Last Sync Date"
    $capexList.Update()
    Write-Host "CAPEX Master updated." -ForegroundColor Green
} else {
    Write-Host "CAPEX Master list not found!" -ForegroundColor Red
}

# ── OPEX Master ───────────────────────────────────────────────────
Write-Host "`n=== OPEX Master ===" -ForegroundColor Cyan
$opexList = $web.Lists["OPEX Master"]
if ($opexList) {
    Add-NumberField $opexList "BudgetedAmount" "Budget"
    Add-NumberField $opexList "UtilizedAmount" "Utilization"
    Add-NumberField $opexList "AvailableAmount" "Available Budget"
    Add-NumberField $opexList "LockedAmount" "Locked Amt"
    Add-NumberField $opexList "BudgetAfterLocked" "Budget After Locked"
    Add-NumberField $opexList "ClaimAmount" "Claim Amt"
    Add-NumberField $opexList "NetBalance" "Net Balance"
    Add-NoteField   $opexList "Contracts" "Contracts"
    Add-DateField   $opexList "LastSyncDate" "Last Sync Date"
    $opexList.Update()
    Write-Host "OPEX Master updated." -ForegroundColor Green
} else {
    Write-Host "OPEX Master list not found!" -ForegroundColor Red
}

$web.Dispose()
Write-Host "`nDone. Re-upload CAPEX/OPEX CSV data to populate budget values." -ForegroundColor Yellow
