using System;
using Falcon_SP.Provision.Helpers;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.Provision.Provisioners
{
    /// <summary>
    /// Provisions reusable Site Columns (fields) in the SharePoint root web.
    /// These columns are shared across multiple lists.
    /// </summary>
    public class SiteColumnsProvisioner
    {
        private readonly ClientContext _ctx;
        private const string GroupName = "Falcon PET Columns";

        public SiteColumnsProvisioner(ClientContext ctx)
        {
            if (ctx == null) throw new ArgumentNullException("ctx");
            _ctx = ctx;
        }

        public void Provision()
        {
            _ctx.Load(_ctx.Web.Fields, flds => flds.Include(f => f.InternalName, f => f.Group));
            _ctx.ExecuteQuery();

            var columns = new[]
            {
                "<Field Type='Text'     Name='PETRefNo'         StaticName='PETRefNo'         DisplayName='PET Ref No'          Group='" + GroupName + "' MaxLength='50'  />",
                "<Field Type='Choice'   Name='PETStatus'        StaticName='PETStatus'        DisplayName='PET Status'          Group='" + GroupName + "'><CHOICES><CHOICE>Draft</CHOICE><CHOICE>Submitted</CHOICE><CHOICE>Under Review</CHOICE><CHOICE>CAPEX Approval</CHOICE><CHOICE>OPEX Approval</CHOICE><CHOICE>PET Approval</CHOICE><CHOICE>Approved</CHOICE><CHOICE>Rejected</CHOICE><CHOICE>Sent Back</CHOICE><CHOICE>Cancelled</CHOICE></CHOICES><Default>Draft</Default></Field>",
                "<Field Type='Choice'   Name='ProjectType'      StaticName='ProjectType'      DisplayName='Project Type'        Group='" + GroupName + "'><CHOICES><CHOICE>CAPEX</CHOICE><CHOICE>OPEX</CHOICE></CHOICES></Field>",
                "<Field Type='Number'   Name='RequestedAmtAED'  StaticName='RequestedAmtAED'  DisplayName='Requested Amount AED' Group='" + GroupName + "' />",
                "<Field Type='User'     Name='RequestorUser'    StaticName='RequestorUser'    DisplayName='Requestor'           Group='" + GroupName + "' />",
                "<Field Type='User'     Name='ReviewerUser'     StaticName='ReviewerUser'     DisplayName='Reviewer'            Group='" + GroupName + "' />",
                "<Field Type='Boolean'  Name='IsActiveFlag'     StaticName='IsActiveFlag'     DisplayName='Is Active'           Group='" + GroupName + "'><Default>1</Default></Field>",
            };

            foreach (string xml in columns)
            {
                string internalName = ExtractName(xml);
                bool exists = false;
                foreach (Field f in _ctx.Web.Fields)
                {
                    if (f.InternalName.Equals(internalName, StringComparison.OrdinalIgnoreCase) &&
                        f.Group == GroupName)
                    { exists = true; break; }
                }

                if (!exists)
                {
                    _ctx.Web.Fields.AddFieldAsXml(xml, false, AddFieldOptions.AddFieldInternalNameHint);
                    _ctx.ExecuteQuery();
                    ProvisionLogger.Success("  Site column created: " + internalName);
                }
                else
                {
                    ProvisionLogger.Skip("  Site column exists: " + internalName);
                }
            }
        }

        private static string ExtractName(string xml)
        {
            // Extracts Name='...' from field XML
            int i = xml.IndexOf("Name='", StringComparison.Ordinal);
            if (i < 0) return "Unknown";
            int start = i + 6;
            int end   = xml.IndexOf("'", start);
            return end > start ? xml.Substring(start, end - start) : "Unknown";
        }
    }
}
