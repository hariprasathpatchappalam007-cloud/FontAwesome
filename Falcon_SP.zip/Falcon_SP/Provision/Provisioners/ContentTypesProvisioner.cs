using System;
using Falcon_SP.Provision.Helpers;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.Provision.Provisioners
{
    /// <summary>
    /// Provisions Content Types for the Falcon PET application.
    /// Content types extend the base Document / Item content types to provide
    /// consistent column sets across lists and libraries.
    /// </summary>
    public class ContentTypesProvisioner
    {
        private readonly ClientContext _ctx;
        private const string CtGroup = "Falcon PET";

        public ContentTypesProvisioner(ClientContext ctx)
        {
            if (ctx == null) throw new ArgumentNullException("ctx");
            _ctx = ctx;
        }

        public void Provision()
        {
            EnsureContentType(
                name:        "PET Request",
                description: "Content type for PET project requests",
                parentId:    "0x01",   // Item
                id:          "0x0100FALCON000000000001"
            );

            EnsureContentType(
                name:        "PET Document",
                description: "Content type for PET supporting documents",
                parentId:    "0x0101", // Document
                id:          "0x010100FALCON000000000001"
            );

            EnsureContentType(
                name:        "PET Email Template",
                description: "Content type for PET email templates",
                parentId:    "0x0101",
                id:          "0x010100FALCON000000000002"
            );
        }

        private void EnsureContentType(string name, string description, string parentId, string id)
        {
            _ctx.Load(_ctx.Web.ContentTypes, cts => cts.Include(ct => ct.Name, ct => ct.StringId));
            _ctx.ExecuteQuery();

            foreach (ContentType ct in _ctx.Web.ContentTypes)
            {
                if (ct.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    ProvisionLogger.Skip("  Content type exists: " + name);
                    return;
                }
            }

            // Find parent
            ContentType parent = null;
            foreach (ContentType ct in _ctx.Web.ContentTypes)
            {
                if (ct.StringId.StartsWith(parentId, StringComparison.OrdinalIgnoreCase))
                { parent = ct; break; }
            }

            if (parent == null)
            {
                ProvisionLogger.Warning("  Parent content type '" + parentId + "' not found for '" + name + "'");
                return;
            }

            var ctInfo = new ContentTypeCreationInformation
            {
                Name        = name,
                Description = description,
                Group       = CtGroup,
                ParentContentType = parent
            };

            _ctx.Web.ContentTypes.Add(ctInfo);
            _ctx.ExecuteQuery();
            ProvisionLogger.Success("  Content type created: " + name);
        }
    }
}
