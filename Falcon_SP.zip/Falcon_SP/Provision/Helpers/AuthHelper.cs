using System;
using System.Net;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.Provision.Helpers
{
    /// <summary>
    /// Builds a ClientContext for SharePoint Server Subscription Edition (on-premises).
    /// Auth priority:
    ///   1. Username + Password + Domain  – NTLM with explicit credentials
    ///   2. Username + Password (no Domain) – NTLM, domain inferred from UPN
    ///   3. No credentials  – current Windows process identity (pass-through)
    /// </summary>
    public static class AuthHelper
    {
        public static ClientContext GetContext(
            string siteUrl,
            string username,
            string password,
            string domain)
        {
            if (string.IsNullOrEmpty(siteUrl))
                throw new ArgumentNullException("siteUrl");

            var ctx = new ClientContext(siteUrl);

            bool hasUser = !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password);

            if (hasUser && !string.IsNullOrEmpty(domain))
            {
                ProvisionLogger.Info("Auth: NTLM (" + domain + "\\" + username + ")");
                ctx.Credentials = new NetworkCredential(username, password, domain);
            }
            else if (hasUser)
            {
                ProvisionLogger.Info("Auth: NTLM (" + username + ")");
                ctx.Credentials = new NetworkCredential(username, password);
            }
            else
            {
                ProvisionLogger.Info("Auth: Current Windows identity (DefaultNetworkCredentials)");
                ctx.Credentials = CredentialCache.DefaultNetworkCredentials;
            }

            return ctx;
        }
    }
}
