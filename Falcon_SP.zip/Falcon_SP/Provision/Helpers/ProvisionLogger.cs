using System;

namespace Falcon_SP.Provision.Helpers
{
    /// <summary>Simple console logger with colour-coded levels.</summary>
    public static class ProvisionLogger
    {
        public static void Info(string message)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("  [INFO]  " + message);
            Console.ResetColor();
        }

        public static void Success(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("  [OK]    " + message);
            Console.ResetColor();
        }

        public static void Warning(string message)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("  [WARN]  " + message);
            Console.ResetColor();
        }

        public static void Skip(string message)
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("  [SKIP]  " + message);
            Console.ResetColor();
        }

        public static void Error(string message, Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("  [ERROR] " + message);
            if (ex != null) Console.WriteLine("          " + ex.Message);
            Console.ResetColor();
        }

        public static void Error(string message)
        {
            Error(message, null);
        }
    }
}
