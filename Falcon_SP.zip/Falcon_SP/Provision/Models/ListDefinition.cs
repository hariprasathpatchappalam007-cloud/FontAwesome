using System.Collections.Generic;

namespace Falcon_SP.Provision.Models
{
    /// <summary>Describes a SharePoint list or library to be provisioned.</summary>
    public class ListDefinition
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public int TemplateType { get; set; }   // 100 = Generic List, 101 = Document Library
        public bool EnableVersioning { get; set; }
        public bool EnableMinorVersions { get; set; }
        public List<FieldDefinition> Fields { get; set; }
        public ListDefinition()
        {
            EnableVersioning = false;
            EnableMinorVersions = false;

            Fields = new List<FieldDefinition>();

        }

    }

    /// <summary>Describes a field/column to add to a list.</summary>
    public class FieldDefinition
    {
        public string InternalName { get; set; }
        public string DisplayName { get; set; }
        public string FieldType { get; set; }   // Text, Note, Number, DateTime, Choice, Lookup, Boolean, User
        public bool Required { get; set; }
        public string DefaultValue { get; set; }
        /// <summary>Pipe-separated choices for Choice fields.</summary>
        public string Choices { get; set; }
        /// <summary>Target list title for Lookup fields.</summary>
        public string LookupList { get; set; }
        /// <summary>Target field name for Lookup fields (default: Title).</summary>
        public string LookupField { get; set; }
        public int MaxLength { get; set; }
        public FieldDefinition()
        {
            LookupField = "Title";
            MaxLength = 255;
            Required = false;

        }

    }
}
