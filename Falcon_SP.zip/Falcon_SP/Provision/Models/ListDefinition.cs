using System.Collections.Generic;

namespace Falcon_SP.Provision.Models
{
    /// <summary>Describes a SharePoint list or library to be provisioned.</summary>
    public class ListDefinition
    {
        public string Title          { get; set; }
        public string Description    { get; set; }
        public int    TemplateType   { get; set; }   // 100 = Generic List, 101 = Document Library
        public bool   EnableVersioning { get; set; } = false;
        public bool   EnableMinorVersions { get; set; } = false;
        public List<FieldDefinition> Fields { get; set; } = new List<FieldDefinition>();
    }

    /// <summary>Describes a field/column to add to a list.</summary>
    public class FieldDefinition
    {
        public string InternalName  { get; set; }
        public string DisplayName   { get; set; }
        public string FieldType     { get; set; }   // Text, Note, Number, DateTime, Choice, Lookup, Boolean, User
        public bool   Required      { get; set; } = false;
        public string DefaultValue  { get; set; }
        /// <summary>Pipe-separated choices for Choice fields.</summary>
        public string Choices       { get; set; }
        /// <summary>Target list title for Lookup fields.</summary>
        public string LookupList    { get; set; }
        /// <summary>Target field name for Lookup fields (default: Title).</summary>
        public string LookupField   { get; set; } = "Title";
        public int    MaxLength     { get; set; } = 255;
    }
}
