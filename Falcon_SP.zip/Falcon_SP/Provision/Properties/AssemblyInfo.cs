using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Falcon_SP.Provision")]
[assembly: AssemblyDescription("CSOM provisioning tool for Falcon PET on SharePoint Server Subscription Edition")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Falcon")]
[assembly: AssemblyProduct("Falcon PET")]
[assembly: AssemblyCopyright("Copyright © 2024")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("a1b2c3d4-e5f6-7890-abcd-ef1234567890")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
