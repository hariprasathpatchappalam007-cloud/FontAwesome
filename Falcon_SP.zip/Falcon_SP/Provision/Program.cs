using System;
using System.Configuration;
using Falcon_SP.Provision.Helpers;
using Falcon_SP.Provision.Provisioners;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.Provision
{
    /// <summary>
    /// Entry point for the Falcon PET SharePoint Provisioning Console.
    /// Provisions all lists, document libraries, site columns and content types
    /// required by the Falcon PET AngularJS CEWP application.
    /// </summary>
    class Program
    {
        static int Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("=================================================");
            Console.WriteLine("  Falcon PET – SharePoint Provisioning Tool");
            Console.WriteLine("=================================================");
            Console.ResetColor();

            string siteUrl  = ConfigurationManager.AppSettings["SiteUrl"];
            string username = ConfigurationManager.AppSettings["Username"];
            string password = ConfigurationManager.AppSettings["Password"];
            string domain   = ConfigurationManager.AppSettings["Domain"];

            if (string.IsNullOrWhiteSpace(siteUrl))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[ERROR] SiteUrl is missing in App.config.");
                Console.ResetColor();
                return 1;
            }

            ProvisionLogger.Info("Target site: " + siteUrl);

            try
            {
                using (ClientContext ctx = AuthHelper.GetContext(
                    siteUrl, username, password, domain))
                {
                    ctx.Load(ctx.Web, w => w.Title, w => w.Url);
                    ctx.ExecuteQuery();
                    ProvisionLogger.Info("Connected to: " + ctx.Web.Title + "  (" + ctx.Web.Url + ")");

                    // ── 1. Site Columns ─────────────────────────────────────
                    Console.WriteLine("\n[Step 1/4] Provisioning Site Columns...");
                    var colProv = new SiteColumnsProvisioner(ctx);
                    colProv.Provision();

                    // ── 2. Content Types ────────────────────────────────────
                    Console.WriteLine("\n[Step 2/4] Provisioning Content Types...");
                    var ctProv = new ContentTypesProvisioner(ctx);
                    ctProv.Provision();

                    // ── 3. Lists ─────────────────────────────────────────────
                    Console.WriteLine("\n[Step 3/4] Provisioning SharePoint Lists...");
                    var listProv = new ListProvisioner(ctx);
                    listProv.ProvisionAll();

                    // ── 4. Document Libraries ────────────────────────────────
                    Console.WriteLine("\n[Step 4/4] Provisioning Document Libraries...");
                    var libProv = new LibraryProvisioner(ctx);
                    libProv.ProvisionAll();

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\n=================================================");
                    Console.WriteLine("  Provisioning completed successfully!");
                    Console.WriteLine("=================================================");
                    Console.ResetColor();
                    return 0;
                }
            }
            catch (Exception ex)
            {
                ProvisionLogger.Error("Provisioning failed", ex);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n[FATAL] " + ex.Message);
                Console.ResetColor();
                return 2;
            }
        }
    }
}
