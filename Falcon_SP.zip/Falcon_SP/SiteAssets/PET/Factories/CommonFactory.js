/**
 * CommonFactory.js – Shared objects, enums and helper data used across controllers.
 */
(function () {
    'use strict';
    angular.module('PETApp.factories')
        .factory('CommonFactory', ['APP_CONST', function (APP_CONST) {
            return {
                statusOptions: Object.values(APP_CONST.STATUS),
                roleOptions:   Object.values(APP_CONST.ROLES),
                currencies:    APP_CONST.CURRENCIES,
                pageSizes:     APP_CONST.PAGE_SIZE_OPTIONS,

                statusColors: {
                    'Draft':          'secondary',
                    'Submitted':      'primary',
                    'Under Review':   'info',
                    'CAPEX Approval': 'warning',
                    'OPEX Approval':  'warning',
                    'PET Approval':   'warning',
                    'Approved':       'success',
                    'Rejected':       'danger',
                    'Sent Back':      'warning',
                    'Cancelled':      'dark'
                },

                getStatusBadge: function (status) {
                    return 'badge badge-' + (this.statusColors[status] || 'secondary');
                }
            };
        }]);
}());
