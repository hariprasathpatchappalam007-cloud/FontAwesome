/**
 * AppFactory.js – Application-wide shared variables and state.
 */
(function () {
    'use strict';
    angular.module('PETApp.factories')
        .factory('AppFactory', ['APP_CONST', function (APP_CONST) {
            var state = {
                currentPET:    null,
                currentStep:   1,
                breadcrumbs:   [],
                sidebarOpen:   true,
                appTitle:      APP_CONST.APP_NAME,
                appVersion:    APP_CONST.APP_VERSION
            };

            return {
                getState:    function ()      { return state; },
                setCurrentPET: function (pet) { state.currentPET  = pet; },
                getCurrentPET: function ()    { return state.currentPET; },
                setBreadcrumbs: function (bc) { state.breadcrumbs = bc; },
                getBreadcrumbs: function ()   { return state.breadcrumbs; },
                toggleSidebar:  function ()   { state.sidebarOpen = !state.sidebarOpen; }
            };
        }]);
}());
