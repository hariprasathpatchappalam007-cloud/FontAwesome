/**
 * CacheFactory.js – Simple in-memory key/value cache for lookup data.
 */
(function () {
    'use strict';
    angular.module('PETApp.factories')
        .factory('CacheFactory', [function () {
            var _store = {};
            return {
                get:    function (key)        { return _store[key] || null; },
                set:    function (key, value) { _store[key] = value; },
                remove: function (key)        { delete _store[key]; },
                clear:  function ()           { _store = {}; },
                has:    function (key)        { return key in _store; }
            };
        }]);
}());
