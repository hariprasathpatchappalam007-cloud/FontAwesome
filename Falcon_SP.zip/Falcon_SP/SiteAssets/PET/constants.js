/**
 * constants.js – Application-wide constants
 * Defined before config.js and routes.js so all modules can inject APP_CONST.
 */
(function () {
    'use strict';

    angular.module('PETApp.constants')
        .constant('APP_CONST', {

            // ── Application ────────────────────────────────────────────────
            APP_NAME:    'Falcon PET Management System',
            APP_VERSION: '1.0.0',

            // ── SharePoint List Names ───────────────────────────────────────
            LISTS: {
                PET_PROJECTS:        'PET Projects',
                PROJECT_DETAILS:     'Project Details',
                PROJECT_SIZING:      'Project Sizing',
                BUDGET_DETAILS:      'Budget Details',
                PET_WORKFLOW:        'PET Workflow',
                APPROVAL_HISTORY:    'Approval History',
                PROJECT_SIZING_SCORE:'Project Sizing Score',
                CAPEX_MASTER:        'CAPEX Master',
                OPEX_MASTER:         'OPEX Master',
                VENDOR_MASTER:       'Vendor Master',
                GL_MASTER:           'GL Master',
                BUDGET_SOURCE:       'Budget Source',
                ROLE_MANAGEMENT:     'Role Management',
                ROLE_PERMISSIONS:    'Role Permissions',
                EMAIL_LOGS:          'Email Logs',
                JIRA_SYNC_LOGS:      'JIRA Sync Logs',
                NOTIFICATIONS:       'Notifications',
                APP_SETTINGS:        'Application Settings'
            },

            // ── Document Libraries ──────────────────────────────────────────
            LIBRARIES: {
                PROJECT_DOCS:    'Project Documents',
                PET_ATTACHMENTS: 'PET Attachments',
                CSV_IMPORTS:     'CSV Imports',
                EMAIL_TEMPLATES: 'Email Templates',
                APP_LOGS:        'Application Logs'
            },

            // ── Application Roles ───────────────────────────────────────────
            ROLES: {
                ADMINISTRATOR:   'Administrator',
                PET_APPROVER:    'PET Approver',
                CAPEX_APPROVER:  'CAPEX Approver',
                OPEX_APPROVER:   'OPEX Approver',
                REVIEWER:        'Reviewer',
                REQUESTOR:       'Requestor'
            },

            // ── PET Status Values ───────────────────────────────────────────
            STATUS: {
                DRAFT:           'Draft',
                SUBMITTED:       'Submitted',
                UNDER_REVIEW:    'Under Review',
                CAPEX_APPROVAL:  'CAPEX Approval',
                OPEX_APPROVAL:   'OPEX Approval',
                PET_APPROVAL:    'PET Approval',
                APPROVED:        'Approved',
                REJECTED:        'Rejected',
                SENT_BACK:       'Sent Back',
                CANCELLED:       'Cancelled'
            },

            // ── Workflow Steps ──────────────────────────────────────────────
            WORKFLOW_STEPS: {
                SUBMIT:          1,
                REVIEW:          2,
                CAPEX_APPROVE:   3,
                OPEX_APPROVE:    4,
                PET_APPROVE:     5,
                COMPLETE:        6
            },

            // ── Pagination ──────────────────────────────────────────────────
            PAGE_SIZE:           15,
            PAGE_SIZE_OPTIONS:  [10, 15, 25, 50, 100],

            // ── Currency ────────────────────────────────────────────────────
            BASE_CURRENCY:      'AED',
            CURRENCIES:         ['AED', 'USD', 'EUR', 'GBP', 'INR'],

            // ── Date Formats ────────────────────────────────────────────────
            DATE_FORMAT:        'DD/MM/YYYY',
            DATE_TIME_FORMAT:   'DD/MM/YYYY HH:mm',
            SP_DATE_FORMAT:     'YYYY-MM-DDTHH:mm:ssZ',

            // ── JIRA ─────────────────────────────────────────────────────────
            JIRA_BASE_URL:      '',   // Set via Application Settings list at runtime

            // ── Notification auto-dismiss (ms) ──────────────────────────────
            NOTIFICATION_TIMEOUT: 5000,

            // ── REST API ────────────────────────────────────────────────────
            REST_BATCH_SIZE:    100,
            REST_EXPAND_FIELDS: 'Author,Editor,Requestor,Reviewer,PETProject'
        });

}());
