﻿(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('MyApprovalsController', [
            '$rootScope', 'CRUDService', 'WorkflowService', 'NotificationService', 'APP_CONST',
            function ($rootScope, CRUDService, WorkflowService, NotificationService, APP_CONST) {
                var vm = this, LISTS = APP_CONST.LISTS;
                vm.pending = []; vm.stats = { approved:0, rejected:0, reviewed:0 };
                vm.actionModal = { show:false, pet:null, type:'', title:'', comments:'' };

                vm.$onInit = function () { _load(); };

                function _load() {
                    var userId = $rootScope.currentUser && $rootScope.currentUser.Id;
                    if (!userId) return;

                    // Items pending my review
                    var reviewFilter = "ReviewerId eq " + userId + " and Status eq 'Submitted'";
                    var approveFilter = "ApproverId eq " + userId + " and Status eq 'Reviewed'";

                    var selectFields = 'Id,PETCode,ProjectName,PETType,BudgetSource,TotalAmountLCY,' +
                        'Status,SubmittedDate,Requestor/Title,ReviewerId,ApproverId';

                    CRUDService.getAll(LISTS.PET_REQUESTS, {
                        select: selectFields, expand: 'Requestor',
                        filter: reviewFilter, orderby: 'SubmittedDate desc', top: 200
                    }).then(function (reviewItems) {
                        reviewItems.forEach(function (i) { i._myRole = 'Reviewer'; });
                        return CRUDService.getAll(LISTS.PET_REQUESTS, {
                            select: selectFields, expand: 'Requestor',
                            filter: approveFilter, orderby: 'SubmittedDate desc', top: 200
                        }).then(function (approveItems) {
                            approveItems.forEach(function (i) { i._myRole = 'Approver'; });
                            vm.pending = reviewItems.concat(approveItems);
                            $rootScope.pendingCount = vm.pending.length;
                        });
                    });

                    // Stats (last 30 days)
                    var since = new Date(); since.setDate(since.getDate() - 30);
                    var sinceStr = since.toISOString();
                    CRUDService.getAll(LISTS.WORKFLOW_HISTORY, {
                        select: 'Id,Action,ActionById', top: 5000,
                        filter: "ActionById eq " + userId + " and ActionDate ge datetime'" + sinceStr + "'"
                    }).then(function (hist) {
                        vm.stats.approved = hist.filter(function(h){return h.Action==='Approved';}).length;
                        vm.stats.rejected = hist.filter(function(h){return h.Action==='Rejected';}).length;
                        vm.stats.reviewed = hist.filter(function(h){return h.Action==='Reviewed';}).length;
                    });
                }

                vm.fmt = function (n) {
                    if (!n && n !== 0) return '0.00';
                    return parseFloat(n).toLocaleString('en-AE', {minimumFractionDigits:2, maximumFractionDigits:2});
                };

                vm.approve = function (p) { _openAction(p, 'approve', 'Approve PET'); };
                vm.reject  = function (p) { _openAction(p, 'reject', 'Reject PET'); };
                vm.review  = function (p) { _openAction(p, 'review', 'Review PET'); };

                function _openAction(pet, type, title) {
                    vm.actionModal = { show:true, pet:pet, type:type, title:title, comments:'' };
                }

                vm.submitAction = function () {
                    var m = vm.actionModal, action;
                    if (m.type === 'approve') action = 'Approved';
                    else if (m.type === 'reject') action = 'Rejected';
                    else action = 'Reviewed';

                    WorkflowService.performAction(m.pet.Id, action, m.comments).then(function () {
                        NotificationService.success(action + ' successfully.');
                        vm.actionModal.show = false;
                        _load();
                    }).catch(function (e) { NotificationService.error('Failed: ' + (e.data||e)); });
                };
            }
        ]);
}());
