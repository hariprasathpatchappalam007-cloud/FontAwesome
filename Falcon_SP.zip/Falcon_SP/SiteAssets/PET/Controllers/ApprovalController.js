/**
 * ApprovalController.js – Handles the PET Approval screen for approvers.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('ApprovalController', [
            '$routeParams', '$location', 'CRUDService', 'WorkflowService',
            'HistoryService', 'NotificationService', 'APP_CONST',
            function ($routeParams, $location, CRUDService, WorkflowService,
                      HistoryService, NotificationService, APP_CONST) {
                var vm    = this;
                var LISTS = APP_CONST.LISTS;

                vm.loading  = false;
                vm.saving   = false;
                vm.pet      = null;
                vm.sizing   = [];
                vm.history  = [];
                vm.comments = '';
                vm.petId    = parseInt($routeParams.id, 10);

                vm.$onInit = function () {
                    vm.loading = true;
                    Promise.all([
                        CRUDService.getById(LISTS.PET_PROJECTS, vm.petId, {
                            select: 'Id,PETRefNo,ProjectTitle,ProjectType,PETStatus,' +
                                    'RequestedAmountAED,Requestor/Title,Reviewer/Title',
                            expand: 'Requestor,Reviewer'
                        }),
                        CRUDService.getByFilter(LISTS.PROJECT_SIZING, 'PETProjectId eq ' + vm.petId),
                        HistoryService.getHistory(vm.petId)
                    ]).then(function (r) {
                        vm.pet     = r[0];
                        vm.sizing  = r[1];
                        vm.history = r[2];
                    }).catch(function () {
                        NotificationService.error('Failed to load approval data.');
                    }).finally(function () { vm.loading = false; });
                };

                vm.approve   = function () { _act('Approve'); };
                vm.reject    = function () { _act('Reject'); };
                vm.sendBack  = function () { _act('SendBack'); };

                function _act(action) {
                    if (!vm.comments && action !== 'Approve') {
                        NotificationService.warning('Please enter comments.');
                        return;
                    }
                    vm.saving = true;
                    WorkflowService.review(vm.petId, action, vm.comments, vm.pet.ProjectType)
                        .then(function () {
                            NotificationService.success('Action recorded: ' + action);
                            $location.path('/myapprovals');
                        })
                        .catch(function () { NotificationService.error('Action failed.'); })
                        .finally(function () { vm.saving = false; });
                }
            }
        ]);
}());
