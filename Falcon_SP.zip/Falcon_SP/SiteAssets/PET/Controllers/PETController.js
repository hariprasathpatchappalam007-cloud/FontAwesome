﻿/**
 * PETController.js – PET Workflow form controller
 * JIRA ID is text/autocomplete (auto-populated from Project Details list).
 * Line items in PET tab. Budget loaded on type+source change.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('PETController', [
            '$scope', '$routeParams', '$location', '$q',
            'CRUDService', 'WorkflowService', 'LookupService',
            'NotificationService', 'UtilityService', 'CSVService', 'APP_CONST',
            function ($scope, $routeParams, $location, $q,
                      CRUDService, WorkflowService, LookupService,
                      NotificationService, UtilityService, CSVService, APP_CONST) {

                var vm    = this;
                var LISTS = APP_CONST.LISTS;
                var isNew = !$routeParams.id;

                // Tabs
                vm.activeTab = 'pet';
                vm.setTab    = function (t) { vm.activeTab = t; };

                // State
                vm.loading          = false;
                vm.saving           = false;
                vm.isNew            = isNew;
                vm.pet              = _emptyPET();
                vm.validationErrors = [];
                vm.successMsg       = '';
                vm.workflowHistory  = [];

                // Project picker (JIRA text autocomplete)
                vm.projectList      = [];
                vm.projectSearch    = '';
                vm.filteredProjects = [];
                vm.showProjectDrop  = false;
                vm.selectedProject  = null;

                // Budget
                vm.typeSourceList   = [];
                vm.budgetDetail     = null;

                // People
                vm.reviewers = [];
                vm.approvers = [];

                // Line items
                vm.lineItems  = [];
                vm.totals     = { count:0, totalLCY:0, totalFinal:0 };
                vm.lineModal  = { show:false, isNew:true, line:{} };
                vm.currencies = ['AED','USD','EUR','GBP','INR','SGD','CHF','JPY'];

                // CSV
                vm.csvFile = null; vm.csvRows = []; vm.csvErrors = [];
                vm.importRunning = false; vm.importProgress = 0; vm.importResult = null;

                // ── Init ──
                vm.$onInit = function () {
                    var promises = [
                        LookupService.getReviewers().then(function (r) { vm.reviewers = r; }),
                        LookupService.getApprovers().then(function (a) { vm.approvers = a; }),
                        _loadProjectDetails()
                    ];
                    if (!isNew) {
                        vm.loading = true;
                        $q.all(promises).then(function () {
                            return CRUDService.getById(LISTS.PET_PROJECTS, $routeParams.id, {
                                select: 'Id,Title,PETRefNo,PETStatus,ProjectType,BudgetSourceCode,' +
                                        'JIRAProjectKey,ProjectDetailsId,ReviewerUserId,ApproverUserId,' +
                                        'RequestedAmountAED,Remarks,Subject,Version,' +
                                        'Requestor/Id,Requestor/Title',
                                expand: 'Requestor'
                            });
                        }).then(function (pet) {
                            vm.pet = pet;
                            vm.projectSearch = pet.JIRAProjectKey || pet.Title || '';
                            // Find project in list
                            vm.selectedProject = vm.projectList.filter(function(p){ return p.JiraKey === pet.JIRAProjectKey; })[0] || null;
                            if (pet.ProjectType) _loadTypeSourceList(pet.ProjectType);
                            if (pet.BudgetSourceCode) _loadBudgetDetail(pet.ProjectType, pet.BudgetSourceCode);
                            return _loadLineItems(pet.Id);
                        }).then(function () {
                            return WorkflowService.getWorkflowHistory($routeParams.id);
                        }).then(function (h) { vm.workflowHistory = h; })
                        .catch(function () { NotificationService.error('Failed to load PET.'); })
                        .finally(function () { vm.loading = false; });
                    } else {
                        $q.all(promises).catch(angular.noop);
                    }
                };

                // ── Project picker (text autocomplete) ──
                function _loadProjectDetails() {
                    return CRUDService.getAll(LISTS.PROJECT_DETAILS, {
                        select: 'Id,Title,JiraKey,ProjectName,ProjectKey,IsActive',
                        filter: 'IsActive eq 1', orderby: 'JiraKey', top: 5000
                    }).then(function (items) { vm.projectList = items; })
                    .catch(angular.noop);
                }

                vm.onProjectSearch = function () {
                    var q = (vm.projectSearch || '').toLowerCase().trim();
                    if (!q) { vm.filteredProjects = []; vm.showProjectDrop = false; return; }
                    vm.filteredProjects = vm.projectList.filter(function (p) {
                        return (p.JiraKey && p.JiraKey.toLowerCase().indexOf(q) >= 0) ||
                               (p.Title   && p.Title.toLowerCase().indexOf(q)   >= 0);
                    }).slice(0, 20);
                    vm.showProjectDrop = vm.filteredProjects.length > 0;
                };

                vm.selectProject = function (p) {
                    vm.selectedProject      = p;
                    vm.projectSearch        = p.JiraKey + ' - ' + p.Title;
                    vm.pet.Title            = p.Title;
                    vm.pet.JIRAProjectKey   = p.JiraKey;
                    vm.pet.ProjectDetailsId = p.Id;
                    vm.showProjectDrop      = false;
                };

                // ── Type / Budget source ──
                vm.onTypeChange = function () {
                    vm.budgetDetail = null;
                    vm.pet.BudgetSourceCode = '';
                    vm.typeSourceList = [];
                    _loadTypeSourceList(vm.pet.ProjectType);
                };

                function _loadTypeSourceList(type) {
                    if (type === 'CAPEX') {
                        LookupService.getCapexList().then(function (list) {
                            vm.typeSourceList = list.map(function (c) {
                                return { Code: c.CAPEXCode || c.Title, Name: c.CAPEXName || c.Description || c.Title, _raw: c };
                            });
                        });
                    } else if (type === 'OPEX') {
                        LookupService.getOpexList().then(function (list) {
                            vm.typeSourceList = list.map(function (o) {
                                return { Code: o.OPEXCode || o.Title, Name: o.OPEXName || o.Description || o.Title, _raw: o };
                            });
                        });
                    }
                }

                vm.onBudgetSourceChange = function () {
                    // Try to get budget detail from the already-loaded list first
                    var found = vm.typeSourceList.filter(function(s){ return s.Code === vm.pet.BudgetSourceCode; })[0];
                    if (found && found._raw) {
                        vm.budgetDetail = found._raw;
                    } else {
                        _loadBudgetDetail(vm.pet.ProjectType, vm.pet.BudgetSourceCode);
                    }
                };

                function _loadBudgetDetail(type, code) {
                    if (!type || !code) { vm.budgetDetail = null; return; }
                    var fn = type === 'CAPEX' ? LookupService.getCapexDetail(code) : LookupService.getOpexDetail(code);
                    fn.then(function (d) { vm.budgetDetail = d; }).catch(angular.noop);
                }

                vm.fmt = function (n) {
                    if (!n && n !== 0) return '0.00';
                    return parseFloat(n).toLocaleString('en-AE', {minimumFractionDigits:2, maximumFractionDigits:2});
                };

                // ── Line items ──
                function _loadLineItems(petId) {
                    return CRUDService.getAll(LISTS.PROJECT_SIZING, {
                        select: 'Id,LineItemNo,ExpHead,Topic,VendorName,CostType,Quantity,UnitPrice,' +
                                'Currency,ExchangeRate,FCYAmount,LCYAmount,Contingency,FinalAmountLCY,GLNumber,Comments',
                        filter: 'PETProjectId eq ' + petId,
                        orderby: 'LineItemNo'
                    }).then(function (items) { vm.lineItems = items; _calcTotals(); });
                }

                function _calcTotals() {
                    var t = { count:vm.lineItems.length, totalLCY:0, totalFinal:0 };
                    vm.lineItems.forEach(function (l) {
                        t.totalLCY   += parseFloat(l.LCYAmount || 0);
                        t.totalFinal += parseFloat(l.FinalAmountLCY || 0);
                    });
                    vm.totals = t;
                    vm.pet.RequestedAmountAED = t.totalFinal;
                }

                vm.calcLine = function (line) {
                    var u = parseFloat(line.Quantity || 0), p = parseFloat(line.UnitPrice || 0);
                    var r = parseFloat(line.ExchangeRate || 1), c = parseFloat(line.Contingency || 0) / 100;
                    line.FCYAmount = u * p;
                    line.LCYAmount = line.FCYAmount * r;
                    line.FinalAmountLCY = line.LCYAmount * (1 + c);
                };

                vm.openLineModal = function (line) {
                    if (line) {
                        vm.lineModal = { show:true, isNew:false, line:angular.copy(line), orig:line };
                    } else {
                        vm.lineModal = { show:true, isNew:true, line:{
                            ExpHead:vm.pet.ProjectType||'CAPEX', Topic:'', VendorName:'', CostType:'',
                            Quantity:1, UnitPrice:0, Currency:'AED', ExchangeRate:1,
                            FCYAmount:0, LCYAmount:0, Contingency:0, FinalAmountLCY:0, GLNumber:''
                        }};
                    }
                };
                vm.closeLineModal = function () { vm.lineModal.show = false; };

                vm.saveLine = function () {
                    var line = vm.lineModal.line;
                    vm.calcLine(line);
                    if (vm.lineModal.isNew) {
                        line.LineItemNo = vm.lineItems.length + 1;
                        CRUDService.insert(LISTS.PROJECT_SIZING, angular.extend({PETProjectId:vm.pet.Id}, line))
                            .then(function (s) {
                                vm.lineItems.push(angular.extend({}, line, {Id:s.Id}));
                                _calcTotals(); vm.lineModal.show = false;
                                NotificationService.success('Line added.');
                            }).catch(function (e) { NotificationService.error('Failed: ' + _errMsg(e)); });
                    } else {
                        CRUDService.update(LISTS.PROJECT_SIZING, line.Id, line).then(function () {
                            angular.extend(vm.lineModal.orig, line);
                            _calcTotals(); vm.lineModal.show = false;
                            NotificationService.success('Line updated.');
                        }).catch(function (e) { NotificationService.error('Failed: ' + _errMsg(e)); });
                    }
                };

                vm.deleteLine = function (line) {
                    UtilityService.confirm('Delete this line item?', 'Delete Line').then(function () {
                        CRUDService.delete(LISTS.PROJECT_SIZING, line.Id).then(function () {
                            var i = vm.lineItems.indexOf(line);
                            if (i >= 0) vm.lineItems.splice(i, 1);
                            _calcTotals();
                        });
                    });
                };

                // ── CRUD ──
                vm.save = function (submit) {
                    vm.validationErrors = _validate(vm.pet);
                    if (vm.validationErrors.length) { vm.setTab('pet'); return; }
                    vm.saving = true;
                    var payload = _payload(vm.pet);
                    var promise = isNew
                        ? CRUDService.insert(LISTS.PET_PROJECTS, payload)
                        : CRUDService.update(LISTS.PET_PROJECTS, vm.pet.Id, payload);
                    promise.then(function (saved) {
                        if (isNew && saved) {
                            vm.pet.Id = saved.Id; isNew = false; vm.isNew = false;
                            $location.path('/pet/edit/' + saved.Id).replace();
                        }
                        if (submit) return WorkflowService.submit(vm.pet.Id, vm.pet.ReviewerUserId, vm.pet.ApproverUserId);
                    }).then(function () {
                        if (submit) {
                            NotificationService.success('PET submitted for approval.');
                            $location.path('/dashboard');
                        } else {
                            NotificationService.success('PET saved as draft.');
                        }
                    }).catch(function (e) { NotificationService.error('Save failed: ' + _errMsg(e)); })
                    .finally(function () { vm.saving = false; });
                };

                vm.recall = function () {
                    UtilityService.confirm('Recall this PET?', 'Recall').then(function () {
                        WorkflowService.recall(vm.pet.Id, 'Recalled').then(function () {
                            NotificationService.success('Recalled.'); vm.$onInit();
                        });
                    });
                };
                vm.cancel = function () {
                    UtilityService.confirm('Cancel this PET?', 'Cancel PET', 'Yes, Cancel').then(function () {
                        WorkflowService.cancel(vm.pet.Id, 'Cancelled').then(function () {
                            NotificationService.success('Cancelled.'); $location.path('/dashboard');
                        });
                    });
                };

                // ── CSV Import ──
                vm.onCSVFileChange = function (files) {
                    if (!files || !files.length) return;
                    vm.csvFile = files[0]; vm.csvRows = []; vm.csvErrors = []; vm.importResult = null;
                    CSVService.parseFile(vm.csvFile).then(function (result) {
                        var m = _mapCSV(result.data); vm.csvRows = m.valid; vm.csvErrors = m.invalid;
                    });
                    if (!$scope.$$phase) $scope.$apply();
                };
                vm.runImport = function () {
                    if (!vm.csvRows.length) return;
                    if (!vm.pet.Id) { NotificationService.warning('Save PET first.'); return; }
                    vm.importRunning = true; vm.importProgress = 0;
                    var done=0, failed=0, chain=$q.resolve();
                    vm.csvRows.forEach(function (line) {
                        chain = chain.then(function () {
                            return CRUDService.insert(LISTS.PROJECT_SIZING, angular.extend({PETProjectId:vm.pet.Id}, line))
                                .then(function(){done++;}).catch(function(){failed++;});
                        }).then(function () { vm.importProgress = Math.round(((done+failed)/vm.csvRows.length)*100); });
                    });
                    chain.finally(function () {
                        vm.importRunning = false;
                        vm.importResult = {success:done, failed:failed};
                        _loadLineItems(vm.pet.Id);
                        NotificationService.success('Import: ' + done + ' added, ' + failed + ' failed.');
                    });
                };

                vm.downloadTemplate = function () {
                    var header = 'Department,ID,Exp. Head,Topic,Vendor,Description,Cost Type,Unit Type,Unit(s),Unit Price,Base CY,Amt. FCY,Amt. LCY,Cont. %,Final Amt LCY,Yearly Recurrence';
                    var blob = new Blob([header + '\n'], {type:'text/csv;charset=utf-8;'});
                    var url = URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url; a.download = 'PET_LineItems_Template.csv';
                    document.body.appendChild(a); a.click(); document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                };

                // ── Helpers ──
                function _emptyPET() {
                    return { Title:'', JIRAProjectKey:'', ProjectDetailsId:null, ProjectType:'',
                             BudgetSourceCode:'', ReviewerUserId:'', ApproverUserId:'',
                             Subject:'', Remarks:'', PETStatus:'Draft', RequestedAmountAED:0, Version:1 };
                }
                function _payload(p) {
                    var data = { Title:p.Title||p.JIRAProjectKey, JIRAProjectKey:p.JIRAProjectKey||'',
                             ProjectDetailsId:p.ProjectDetailsId||null, ProjectType:p.ProjectType||'',
                             BudgetSourceCode:p.BudgetSourceCode||'', Subject:p.Subject||'',
                             Remarks:p.Remarks||'', PETStatus:p.PETStatus||'Draft',
                             RequestedAmountAED:parseFloat(p.RequestedAmountAED)||0 };
                    if (p.ReviewerUserId) data.ReviewerId = p.ReviewerUserId;
                    if (p.ApproverUserId) data.ApproverId = p.ApproverUserId;
                    return data;
                }
                function _validate(p) {
                    var e = [];
                    if (!p.JIRAProjectKey) e.push('Select a JIRA project.');
                    if (!p.ProjectType)    e.push('Select CAPEX or OPEX.');
                    if (!p.BudgetSourceCode) e.push('Select a budget source.');
                    if (!p.ApproverUserId) e.push('Select an approver.');
                    return e;
                }
                function _mapCSV(rows) {
                    var valid=[], invalid=[];
                    rows.forEach(function (r, i) {
                        if (!r['Exp. Head'] && !r['Topic']) return;
                        var l = { LineItemNo:i+1, ExpHead:r['Exp. Head']||'CAPEX', Topic:r['Topic']||'',
                                  VendorName:r['Vendor']||'', CostType:r['Cost Type']||'',
                                  Quantity:_n(r['Unit(s)']), UnitPrice:_n(r['Unit Price']),
                                  Currency:r['Base CY']||'AED', ExchangeRate:1,
                                  FCYAmount:_n(r['Amt. FCY']), LCYAmount:_n(r['Amt. LCY']),
                                  Contingency:_n(r['Cont. %']), FinalAmountLCY:_n(r['Final Amt LCY']),
                                  GLNumber:'', Comments:'' };
                        if (!l.Topic) invalid.push({row:i+2, reason:'Missing Topic'});
                        else valid.push(l);
                    });
                    return {valid:valid, invalid:invalid};
                }
                function _n(v) { return v ? (parseFloat(String(v).replace(/,/g,''))||0) : 0; }
                function _errMsg(e) { return e&&e.data&&e.data.error ? (e.data.error.message.value||e.data.error.message) : String(e); }
            }
        ]);
}());
