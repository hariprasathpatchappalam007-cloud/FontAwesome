/**
 * DashboardController.js
 * Manages the PET dashboard – KPI tiles, filters, grid and charts.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('DashboardController', [
            '$rootScope', '$location', 'DashboardService', 'NotificationService',
            'CommonFactory', 'UtilityService', 'APP_CONST',
            function ($rootScope, $location, DashboardService, NotificationService,
                      CommonFactory, UtilityService, APP_CONST) {
                var vm = this;

                // ── State ─────────────────────────────────────────────────────
                vm.loading      = false;
                vm.kpis         = {};
                vm.petList      = [];
                vm.totalItems   = 0;
                vm.page         = 1;
                vm.pageSize     = APP_CONST.PAGE_SIZE;
                vm.statusColors = CommonFactory.statusColors;

                vm.filters = {
                    project:  '',
                    type:     '',
                    status:   '',
                    fromDate: '',
                    toDate:   '',
                    view:     'ALL'
                };

                vm.statusOptions = APP_CONST.STATUS;
                vm.typeOptions   = ['CAPEX', 'OPEX'];
                vm.viewOptions   = ['ALL', 'MINE'];

                vm.gridColumns = [
                    { header: 'PET Ref',        field: 'PETRefNo' },
                    { header: 'Project Title',  field: 'ProjectTitle' },
                    { header: 'Type',           field: 'ProjectType' },
                    { header: 'Status',         field: 'PETStatus',
                      template: function (v) {
                          return '<span class="badge badge-' + (CommonFactory.statusColors[v] || 'secondary') + '">' + (v || '') + '</span>';
                      }
                    },
                    { header: 'Amount (AED)',   field: 'RequestedAmountAED', align: 'right',
                      template: function (v) { return UtilityService.formatAED(v); }
                    },
                    { header: 'Requestor',      field: 'Requestor.Title' },
                    { header: 'Submitted',      field: 'SubmittedDate',
                      template: function (v) { return UtilityService.formatDate(v); }
                    }
                ];

                // ── Init ──────────────────────────────────────────────────────
                vm.$onInit = function () {
                    vm.loadKPIs();
                    vm.loadList();
                    vm.loadCharts();
                };

                vm.loadKPIs = function () {
                    DashboardService.getKPIs().then(function (kpis) {
                        vm.kpis = kpis;
                    }).catch(function () { NotificationService.error('Failed to load KPIs.'); });
                };

                vm.loadList = function (page) {
                    vm.loading  = true;
                    vm.page     = page || 1;
                    var filters = angular.extend({}, vm.filters, {
                        userId: $rootScope.currentUser ? $rootScope.currentUser.Id : null
                    });
                    DashboardService.getPETList(filters, vm.page, vm.pageSize)
                        .then(function (result) {
                            vm.petList    = result.results || result;
                            vm.totalItems = result.__count || (result.results ? result.results.length : 0);
                        })
                        .catch(function () { NotificationService.error('Failed to load PET list.'); })
                        .finally(function () { vm.loading = false; });
                };

                vm.applyFilters = function () { vm.loadList(1); };
                vm.clearFilters = function () {
                    vm.filters = { project: '', type: '', status: '', fromDate: '', toDate: '', view: 'ALL' };
                    vm.loadList(1);
                };

                vm.openPET = function (row) { $location.path('/pet/edit/' + row.Id); };

                vm.loadCharts = function () {
                    DashboardService.getStatusDistribution().then(function (counts) {
                        _renderDoughnut(counts);
                    });
                    DashboardService.getMonthlyTrend().then(function (monthly) {
                        _renderLineChart(monthly);
                    });
                };

                // ── Chart rendering ───────────────────────────────────────────
                function _renderDoughnut(counts) {
                    var ctx = document.getElementById('statusChart');
                    if (!ctx || typeof Chart === 'undefined') return;
                    new Chart(ctx.getContext('2d'), {
                        type: 'doughnut',
                        data: {
                            labels:   Object.keys(counts),
                            datasets: [{ data: Object.values(counts),
                                backgroundColor: ['#007bff','#28a745','#dc3545','#ffc107','#17a2b8','#6c757d'] }]
                        },
                        options: { responsive: true, maintainAspectRatio: false }
                    });
                }

                function _renderLineChart(monthly) {
                    var ctx = document.getElementById('trendChart');
                    if (!ctx || typeof Chart === 'undefined') return;
                    var labels = Object.keys(monthly).sort();
                    new Chart(ctx.getContext('2d'), {
                        type: 'line',
                        data: {
                            labels:   labels,
                            datasets: [{
                                label:           'PET Submissions',
                                data:            labels.map(function (k) { return monthly[k]; }),
                                borderColor:     '#007bff',
                                backgroundColor: 'rgba(0,123,255,0.1)',
                                fill:            true
                            }]
                        },
                        options: { responsive: true, maintainAspectRatio: false }
                    });
                }
            }
        ]);
}());
