﻿/**
 * DashboardController.js
 * Groups PET items by JIRA project (tree view), provides KPIs, filtering, delete.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('DashboardController', [
            '$rootScope', '$location', 'CRUDService', 'LookupService',
            'NotificationService', 'UtilityService', 'APP_CONST',
            function ($rootScope, $location, CRUDService, LookupService,
                      NotificationService, UtilityService, APP_CONST) {

                var vm    = this;
                var LISTS = APP_CONST.LISTS;

                vm.loading     = false;
                vm.filtersOpen = true;
                vm.pendingOpen = true;
                vm.lastSync    = new Date().toLocaleString('en-GB');
                vm.kpis        = {};
                vm.petList     = [];
                vm.groupedList = [];
                vm.totalItems  = 0;
                vm.projectList = [];

                vm.filters = { project:'', type:'', status:'', view:'', fromDate:'', toDate:'' };

                // ── Init ──
                vm.$onInit = function () {
                    _loadProjects();
                    vm.loadData();
                };

                function _loadProjects() {
                    CRUDService.getAll(LISTS.PROJECT_DETAILS, {
                        select: 'Id,Title,JiraKey',
                        filter: 'IsActive eq 1',
                        orderby: 'JiraKey', top: 2000
                    }).then(function (items) { vm.projectList = items; });
                }

                vm.loadData = function () {
                    vm.loading = true;
                    var filter = _buildFilter();
                    CRUDService.getAll(LISTS.PET_PROJECTS, {
                        select: 'Id,PETRefNo,Title,JIRAProjectKey,ProjectType,PETStatus,BudgetSourceCode,' +
                                'RequestedAmountAED,Version,SubmittedDate,' +
                                'Requestor/Id,Requestor/Title,Approver/Title',
                        expand: 'Requestor,Approver',
                        filter: filter || undefined,
                        orderby: 'JIRAProjectKey,PETRefNo',
                        top: 5000
                    }).then(function (items) {
                        vm.petList = items.map(function (p) {
                            p.RequestorName = p.Requestor ? p.Requestor.Title : '';
                            p.RequestorId   = p.Requestor ? p.Requestor.Id : 0;
                            p.ApproverName  = p.Approver  ? p.Approver.Title  : '';
                            return p;
                        });
                        _buildGroups();
                        _calcKPIs();
                    }).catch(function () {
                        NotificationService.error('Failed to load dashboard data.');
                    }).finally(function () { vm.loading = false; });
                };

                function _buildFilter() {
                    var parts = ["PETStatus ne 'Deleted'"];
                    if (vm.filters.project) parts.push("JIRAProjectKey eq '" + vm.filters.project + "'");
                    if (vm.filters.type)    parts.push("ProjectType eq '" + vm.filters.type + "'");
                    if (vm.filters.status)  parts.push("PETStatus eq '" + vm.filters.status + "'");
                    if (vm.filters.view === 'MINE' && $rootScope.currentUser)
                        parts.push("RequestorId eq " + $rootScope.currentUser.Id);
                    if (vm.filters.view === 'PENDING' && $rootScope.currentUser)
                        parts.push("(PETStatus eq 'PendingReview' or PETStatus eq 'PendingApproval')");
                    return parts.length ? parts.join(' and ') : null;
                }

                function _buildGroups() {
                    var map = {};
                    vm.petList.forEach(function (p) {
                        var key = p.JIRAProjectKey || '(No Project)';
                        if (!map[key]) map[key] = { projectKey: key, projectTitle: p.Title || '', items: [], totalAED: 0 };
                        map[key].items.push(p);
                        map[key].totalAED += parseFloat(p.RequestedAmountAED) || 0;
                    });
                    vm.groupedList = Object.keys(map).sort().map(function (k) { return map[k]; });
                    vm.totalItems  = vm.petList.length;
                }

                function _calcKPIs() {
                    var k = { totalProjects: vm.projectList.length, totalPET: vm.petList.length,
                              pending: 0, approved: 0, rejected: 0, capexBudget: '0', opexBudget: '0' };
                    vm.petList.forEach(function (p) {
                        if (p.PETStatus === 'PendingReview' || p.PETStatus === 'PendingApproval') k.pending++;
                        if (p.PETStatus === 'Approved') k.approved++;
                        if (p.PETStatus === 'Rejected') k.rejected++;
                    });
                    // Budget totals from master lists
                    LookupService.getCapexList().then(function (list) {
                        var total = 0;
                        list.forEach(function (c) { total += parseFloat(c.BudgetedAmount) || 0; });
                        k.capexBudget = _fmtM(total);
                        vm.kpis = k;
                    });
                    LookupService.getOpexList().then(function (list) {
                        var total = 0;
                        list.forEach(function (o) { total += parseFloat(o.BudgetedAmount) || 0; });
                        k.opexBudget = _fmtM(total);
                        vm.kpis = k;
                    });
                    vm.kpis = k;
                }

                function _fmtM(n) {
                    if (n >= 1000000) return (n / 1000000).toFixed(2) + 'M';
                    if (n >= 1000) return (n / 1000).toFixed(2) + 'K';
                    return n.toFixed(2);
                }

                vm.fmt = function (n) {
                    if (!n && n !== 0) return '0.00';
                    return parseFloat(n).toLocaleString('en-AE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                };

                vm.statusClass = function (s) {
                    var map = { Draft:'st-draft', PendingReview:'st-review', PendingApproval:'st-pending',
                                Approved:'st-approved', Rejected:'st-rejected', 'Sent Back':'st-sent', SentBack:'st-sent' };
                    return map[s] || 'st-draft';
                };

                vm.applyFilters = function () { vm.loadData(); };
                vm.clearFilters = function () {
                    vm.filters = { project:'', type:'', status:'', view:'', fromDate:'', toDate:'' };
                    vm.loadData();
                };

                vm.exportExcel = function () { NotificationService.info('Excel export coming soon.'); };

                vm.deletePET = function (pet) {
                    UtilityService.confirm(
                        'Are you sure you want to delete PET',
                        'Confirm Delete PET',
                        'Yes, Delete',
                        pet.PETRefNo
                    ).then(function () {
                        CRUDService.update(LISTS.PET_PROJECTS, pet.Id, { PETStatus: 'Deleted' }).then(function () {
                            NotificationService.success('PET ' + pet.PETRefNo + ' deleted.');
                            vm.loadData();
                        });
                    });
                };

                vm.openPET = function (pet) { $location.path('/pet/edit/' + pet.Id); };
            }
        ]);
}());
