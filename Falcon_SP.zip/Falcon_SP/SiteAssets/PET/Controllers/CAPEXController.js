﻿(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('CAPEXController', [
            'CRUDService', 'NotificationService', 'UtilityService', 'CSVService', 'APP_CONST',
            function (CRUDService, NotificationService, UtilityService, CSVService, APP_CONST) {
                var vm = this, LISTS = APP_CONST.LISTS;
                vm.items = []; vm.filteredItems = []; vm.searchTerm = '';
                vm.importOpen = false; vm.csvRows = []; vm.importResult = null;
                vm.modal = { show:false, isNew:true, item:{} };

                vm.$onInit = function () { _load(); };

                function _load() {
                    CRUDService.getAll(LISTS.CAPEX_MASTER, {
                        select: 'Id,CAPEXCode,CAPEXName,Description,BudgetedAmount,UtilizedAmount,' +
                                'AvailableAmount,LockedAmount,BudgetAfterLocked,ClaimAmount,NetBalance,' +
                                'IsActive,Modified,Editor/Title',
                        expand: 'Editor', orderby: 'CAPEXCode', top: 5000
                    }).then(function (items) { vm.items = items; vm.filteredItems = items; });
                }

                vm.search = function () {
                    var q = (vm.searchTerm || '').toLowerCase();
                    vm.filteredItems = vm.items.filter(function (i) {
                        return (i.CAPEXCode && i.CAPEXCode.toLowerCase().indexOf(q) >= 0) ||
                               (i.Description && i.Description.toLowerCase().indexOf(q) >= 0);
                    });
                };

                vm.fmt = function (n) {
                    if (!n && n !== 0) return '0.00';
                    return parseFloat(n).toLocaleString('en-AE', {minimumFractionDigits:2, maximumFractionDigits:2});
                };

                vm.openModal = function (item) {
                    if (item) { vm.modal = { show:true, isNew:false, item:angular.copy(item), orig:item }; }
                    else { vm.modal = { show:true, isNew:true, item:{ CAPEXCode:'', Description:'', IsActive:true,
                           BudgetedAmount:0, UtilizedAmount:0, AvailableAmount:0, LockedAmount:0 } }; }
                };

                vm.saveItem = function () {
                    var payload = vm.modal.item;
                    var promise = vm.modal.isNew
                        ? CRUDService.insert(LISTS.CAPEX_MASTER, payload)
                        : CRUDService.update(LISTS.CAPEX_MASTER, payload.Id, payload);
                    promise.then(function () {
                        NotificationService.success('Saved.'); vm.modal.show = false; _load();
                    }).catch(function (e) { NotificationService.error('Failed: ' + (e.data||e)); });
                };

                vm.deleteItem = function (item) {
                    UtilityService.confirm('Delete CAPEX ' + item.CAPEXCode + '?', 'Confirm Delete').then(function () {
                        CRUDService.delete(LISTS.CAPEX_MASTER, item.Id).then(function () {
                            NotificationService.success('Deleted.'); _load();
                        });
                    });
                };

                vm.onCSVFile = function (files) {
                    if (!files||!files.length) return;
                    CSVService.parseFile(files[0]).then(function (r) {
                        vm.csvRows = r.data.filter(function(row){ return row['ID']; });
                    });
                };
                vm.runCSVImport = function () {
                    var done=0, failed=0;
                    var chain = Promise.resolve();
                    vm.csvRows.forEach(function (r) {
                        chain = chain.then(function () {
                            return CRUDService.insert(LISTS.CAPEX_MASTER, {
                                CAPEXCode:r['ID'], Description:r['Description']||'',
                                BudgetedAmount:parseFloat(r['Budget'])||0,
                                UtilizedAmount:parseFloat(r['Utilization'])||0,
                                AvailableAmount:parseFloat(r['Available Budget'])||0,
                                LockedAmount:parseFloat(r['Locked Amt'])||0,
                                BudgetAfterLocked:parseFloat(r['Budget after Locked Amt'])||0,
                                ClaimAmount:parseFloat(r['Claim Amt'])||0,
                                NetBalance:parseFloat(r['Net Balance'])||0,
                                IsActive:true
                            }).then(function(){done++;}).catch(function(){failed++;});
                        });
                    });
                    chain.then(function () {
                        vm.importResult = {success:done, failed:failed}; _load();
                        NotificationService.success(done + ' imported.');
                    });
                };
                vm.exportExcel = function () { NotificationService.info('Excel export coming soon.'); };
            }
        ]);
}());
