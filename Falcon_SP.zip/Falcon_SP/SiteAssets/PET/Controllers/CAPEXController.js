/**
 * CAPEXController.js – CRUD for CAPEX Master.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('CAPEXController', [
            'CRUDService', 'NotificationService', 'APP_CONST',
            function (CRUDService, NotificationService, APP_CONST) {
                var vm    = this;
                var LIST  = APP_CONST.LISTS.CAPEX_MASTER;

                vm.loading  = false;
                vm.saving   = false;
                vm.items    = [];
                vm.editItem = null;
                vm.form     = _empty();

                vm.$onInit = function () { vm.load(); };

                vm.load = function () {
                    vm.loading = true;
                    CRUDService.getAll(LIST, { orderby: 'CAPEXName' })
                        .then(function (d) { vm.items = d; })
                        .catch(function () { NotificationService.error('Failed to load CAPEX.'); })
                        .finally(function () { vm.loading = false; });
                };

                vm.edit   = function (item) { vm.editItem = item; vm.form = angular.copy(item); };
                vm.cancel = function ()     { vm.editItem = null; vm.form = _empty(); };

                vm.save = function () {
                    if (!vm.form.CAPEXCode || !vm.form.CAPEXName) {
                        NotificationService.warning('Code and Name are required.');
                        return;
                    }
                    vm.saving = true;
                    var p = vm.editItem
                        ? CRUDService.update(LIST, vm.editItem.Id, vm.form)
                        : CRUDService.insert(LIST, angular.extend(vm.form, { IsActive: true }));
                    p.then(function () {
                        NotificationService.success('Saved.');
                        vm.cancel();
                        vm.load();
                    }).catch(function () { NotificationService.error('Save failed.'); })
                      .finally(function () { vm.saving = false; });
                };

                vm.toggleActive = function (item) {
                    CRUDService.update(LIST, item.Id, { IsActive: !item.IsActive })
                        .then(function () { item.IsActive = !item.IsActive; });
                };

                function _empty() { return { CAPEXCode: '', CAPEXName: '', Description: '', IsActive: true }; }
            }
        ]);
}());
