/**
 * JiraSyncController.js – JIRA synchronization monitoring and manual trigger.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('JiraSyncController', [
            'CRUDService', 'JIRAService', 'NotificationService', 'APP_CONST',
            function (CRUDService, JIRAService, NotificationService, APP_CONST) {
                var vm = this;

                vm.loading   = false;
                vm.syncing   = false;
                vm.syncLogs  = [];
                vm.lastSync  = null;

                vm.$onInit = function () { vm.loadLogs(); };

                vm.loadLogs = function () {
                    vm.loading = true;
                    CRUDService.getAll(APP_CONST.LISTS.JIRA_SYNC_LOGS, {
                        orderby: 'SyncDate desc', top: 50,
                        select:  'Id,SyncDate,SyncType,RecordsTotal,RecordsNew,RecordsUpdated,RecordsFailed,SyncStatus,TriggeredBy/Title',
                        expand:  'TriggeredBy'
                    }).then(function (d) {
                        vm.syncLogs = d;
                        vm.lastSync = d.length ? d[0] : null;
                    }).catch(function () { NotificationService.error('Failed to load sync logs.'); })
                      .finally(function () { vm.loading = false; });
                };

                vm.runSync = function () {
                    vm.syncing = true;
                    JIRAService.syncProjects()
                        .then(function (stats) {
                            NotificationService.success(
                                'Sync complete. Total: ' + stats.total +
                                ', New: ' + stats.newItems +
                                ', Updated: ' + stats.updated +
                                ', Failed: ' + stats.failed
                            );
                            vm.loadLogs();
                        })
                        .catch(function () { NotificationService.error('JIRA sync failed.'); })
                        .finally(function () { vm.syncing = false; });
                };
            }
        ]);
}());
