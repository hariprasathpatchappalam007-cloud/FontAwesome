/**
 * HomeController.js – Landing page and shell controller.
 * Manages sidebar state, user greeting and navigation menu visibility.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('HomeController', [
            '$rootScope', '$location', 'AppFactory', 'AuthenticationService', 'ApprovalService',
            function ($rootScope, $location, AppFactory, AuthenticationService, ApprovalService) {
                var vm = this;

                vm.user          = $rootScope.currentUser;
                vm.sidebarOpen   = true;
                vm.pendingCount  = 0;
                vm.menuItems     = [];

                vm.$onInit = function () {
                    AuthenticationService.getCurrentUser().then(function (user) {
                        vm.user = user;
                        vm.menuItems = _buildMenu(user.roles);
                    });
                    ApprovalService.getPendingCounts().then(function (counts) {
                        vm.pendingCount = (counts.review || 0) + (counts.capex || 0) +
                                          (counts.opex || 0) + (counts.pet || 0);
                    }).catch(angular.noop);
                };

                vm.toggleSidebar = function () {
                    vm.sidebarOpen = !vm.sidebarOpen;
                    AppFactory.toggleSidebar();
                };

                vm.navigate = function (path) { $location.path(path); };

                function _buildMenu(roles) {
                    var menu = [
                        { label: 'Dashboard',    icon: 'fa-tachometer-alt', path: '/dashboard',    roles: [] },
                        { label: 'PET Workflow', icon: 'fa-file-alt',       path: '/pet/new',      roles: ['Administrator', 'Requestor'] },
                        { label: 'My Approvals', icon: 'fa-check-circle',   path: '/myapprovals',  roles: ['Administrator', 'PET Approver', 'CAPEX Approver', 'OPEX Approver', 'Reviewer'] },
                        {
                            label: 'Masters', icon: 'fa-database', roles: ['Administrator'],
                            children: [
                                { label: 'CAPEX',   path: '/masters/capex' },
                                { label: 'OPEX',    path: '/masters/opex'  },
                                { label: 'Vendor',  path: '/masters/vendor'},
                                { label: 'GL',      path: '/masters/gl'    }
                            ]
                        },
                        {
                            label: 'Administration', icon: 'fa-cogs', roles: ['Administrator'],
                            children: [
                                { label: 'Role Management', path: '/admin/roles'     },
                                { label: 'Email Logs',      path: '/admin/emaillogs' },
                                { label: 'JIRA Sync',       path: '/admin/jirasync'  }
                            ]
                        }
                    ];

                    return menu.filter(function (item) {
                        if (!item.roles || item.roles.length === 0) return true;
                        return item.roles.some(function (r) { return roles && roles.indexOf(r) !== -1; });
                    });
                }
            }
        ]);
}());
