/**
 * AdminController.js – Stub included via ProjectController.js.
 * Kept as a separate file reference in index.html for clarity.
 */
// AdminController is declared in ProjectController.js
