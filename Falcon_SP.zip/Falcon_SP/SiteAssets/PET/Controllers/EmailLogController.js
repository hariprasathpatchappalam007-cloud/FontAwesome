/**
 * EmailLogController.js – View email audit logs.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('EmailLogController', [
            'CRUDService', 'NotificationService', 'APP_CONST',
            function (CRUDService, NotificationService, APP_CONST) {
                var vm = this;

                vm.loading    = false;
                vm.logs       = [];
                vm.searchText = '';
                vm.statusFilter = '';
                vm.page       = 1;
                vm.pageSize   = APP_CONST.PAGE_SIZE;
                vm.totalItems = 0;

                vm.$onInit = function () { vm.load(); };

                vm.load = function (page) {
                    vm.loading = true;
                    vm.page    = page || 1;
                    var filter = vm.statusFilter ? "SentStatus eq '" + vm.statusFilter + "'" : '';
                    CRUDService.getPaged(APP_CONST.LISTS.EMAIL_LOGS, vm.page, vm.pageSize, {
                        select:  'Id,ToAddress,Subject,SentDate,SentStatus,PETRef/PETRefNo',
                        expand:  'PETRef',
                        filter:  filter,
                        orderby: 'SentDate desc'
                    }).then(function (result) {
                        vm.logs       = result.results || result;
                        vm.totalItems = result.__count || 0;
                    }).catch(function () { NotificationService.error('Failed to load email logs.'); })
                      .finally(function () { vm.loading = false; });
                };
            }
        ]);
}());
