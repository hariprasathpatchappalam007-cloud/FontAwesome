/**
 * RoleController.js – Manage application role assignments.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('RoleController', [
            'CRUDService', 'NotificationService', 'LookupService',
            'AuthenticationService', 'APP_CONST',
            function (CRUDService, NotificationService, LookupService,
                      AuthenticationService, APP_CONST) {
                var vm   = this;
                var LIST = APP_CONST.LISTS.ROLE_MANAGEMENT;

                vm.loading   = false; vm.saving = false;
                vm.roles     = []; vm.editItem = null; vm.form = _empty();
                vm.roleOptions = Object.values(APP_CONST.ROLES);

                vm.$onInit = function () { vm.load(); };

                vm.load = function () {
                    vm.loading = true;
                    CRUDService.getAll(LIST, {
                        select: 'Id,AppRole,Department,IsActive,ValidFrom,ValidTo,UserRef/Title,UserRef/EMail,UserRef/LoginName',
                        expand: 'UserRef',
                        orderby: 'AppRole'
                    }).then(function (d) { vm.roles = d; })
                      .catch(function () { NotificationService.error('Failed to load roles.'); })
                      .finally(function () { vm.loading = false; });
                };

                vm.edit   = function (i) { vm.editItem = i; vm.form = angular.copy(i); };
                vm.cancel = function ()  { vm.editItem = null; vm.form = _empty(); };

                vm.save = function () {
                    if (!vm.form.AppRole || !vm.form.userPicker) { NotificationService.warning('User and Role are required.'); return; }
                    vm.saving = true;
                    AuthenticationService.getCurrentUser().then(function () {
                        var payload = {
                            AppRole:    vm.form.AppRole,
                            Department: vm.form.Department || '',
                            IsActive:   true,
                            ValidFrom:  vm.form.ValidFrom || null,
                            ValidTo:    vm.form.ValidTo   || null
                        };
                        if (vm.form.userPicker && vm.form.userPicker.Key) {
                            // Will be resolved to SP user ID
                        }
                        var p = vm.editItem
                            ? CRUDService.update(LIST, vm.editItem.Id, payload)
                            : CRUDService.insert(LIST, payload);
                        return p;
                    }).then(function () {
                        NotificationService.success('Role saved.');
                        vm.cancel(); vm.load();
                    }).catch(function () { NotificationService.error('Save failed.'); })
                      .finally(function () { vm.saving = false; });
                };

                vm.deactivate = function (item) {
                    CRUDService.update(LIST, item.Id, { IsActive: false })
                        .then(function () { item.IsActive = false; NotificationService.success('Deactivated.'); });
                };

                function _empty() { return { AppRole: '', Department: '', IsActive: true, userPicker: null }; }
            }
        ]);
}());
