﻿(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('RoleController', [
            'CRUDService', 'NotificationService', 'UtilityService', 'APP_CONST',
            function (CRUDService, NotificationService, UtilityService, APP_CONST) {
                var vm = this, LISTS = APP_CONST.LISTS;
                vm.tab = 'users'; vm.formOpen = false; vm.editingUser = null;
                vm.users = []; vm.roles = [];
                vm.form = {}; vm.roleModal = { show:false, user:null };

                vm.$onInit = function () { _loadUsers(); _loadRoles(); };

                function _loadUsers() {
                    CRUDService.getAll(LISTS.PET_USERS, {
                        select: 'Id,WindowsUsername,DisplayName,Email,Department,PrimaryRole,' +
                                'IsRequestor,IsReviewer,IsApprover,IsAdmin,IsActive,LastLogin',
                        orderby: 'DisplayName', top: 5000
                    }).then(function (u) { vm.users = u; });
                }
                function _loadRoles() {
                    CRUDService.getAll(LISTS.ROLES, {
                        select: 'Id,Title,Description', orderby: 'Title'
                    }).then(function (r) { vm.roles = r; });
                }

                vm.resetForm = function () {
                    vm.form = {}; vm.editingUser = null; vm.formOpen = false;
                };
                vm.editUser = function (u) {
                    vm.form = angular.copy(u); vm.editingUser = u; vm.formOpen = true;
                };
                vm.saveUser = function () {
                    var payload = vm.form;
                    var promise = vm.editingUser
                        ? CRUDService.update(LISTS.PET_USERS, payload.Id, payload)
                        : CRUDService.insert(LISTS.PET_USERS, payload);
                    promise.then(function () {
                        NotificationService.success('User saved.'); vm.resetForm(); _loadUsers();
                    }).catch(function (e) { NotificationService.error('Failed: ' + (e.data||e)); });
                };
                vm.toggleActive = function (u) {
                    CRUDService.update(LISTS.PET_USERS, u.Id, { IsActive: !u.IsActive })
                        .then(function () { u.IsActive = !u.IsActive; NotificationService.success('Updated.'); });
                };
                vm.deleteUser = function (u) {
                    UtilityService.confirm('Delete user ' + u.DisplayName + '?', 'Confirm Delete', 'Yes, Delete')
                        .then(function () {
                            CRUDService.delete(LISTS.PET_USERS, u.Id).then(function () {
                                NotificationService.success('Deleted.'); _loadUsers();
                            });
                        });
                };
                vm.openRoleModal = function (u) {
                    vm.roleModal = { show:true, user: angular.copy(u), orig: u };
                };
                vm.saveRoles = function () {
                    var u = vm.roleModal.user;
                    CRUDService.update(LISTS.PET_USERS, u.Id, {
                        IsRequestor: u.IsRequestor, IsReviewer: u.IsReviewer,
                        IsApprover: u.IsApprover, IsAdmin: u.IsAdmin
                    }).then(function () {
                        angular.extend(vm.roleModal.orig, { IsRequestor:u.IsRequestor, IsReviewer:u.IsReviewer,
                            IsApprover:u.IsApprover, IsAdmin:u.IsAdmin });
                        vm.roleModal.show = false; NotificationService.success('Roles updated.');
                    });
                };
            }
        ]);
}());
