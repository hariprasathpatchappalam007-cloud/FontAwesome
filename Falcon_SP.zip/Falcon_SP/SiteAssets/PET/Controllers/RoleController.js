﻿(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('RoleController', [
            'CRUDService', 'NotificationService', 'UtilityService', 'APP_CONST',
            function (CRUDService, NotificationService, UtilityService, APP_CONST) {
                var vm = this, LISTS = APP_CONST.LISTS;
                vm.formOpen = false; vm.editItem = null;
                vm.items = []; vm.form = {};

                vm.$onInit = function () { _load(); };

                function _load() {
                    CRUDService.getAll(LISTS.ROLE_MANAGEMENT, {
                        select: 'Id,AppRole,Department,IsActive,ValidFrom,ValidTo,UserRef/Id,UserRef/Title,UserRef/EMail',
                        expand: 'UserRef',
                        orderby: 'AppRole', top: 500
                    }).then(function (items) {
                        vm.items = items.map(function (i) {
                            i.UserTitle = i.UserRef ? i.UserRef.Title : '';
                            i.UserEmail = i.UserRef ? i.UserRef.EMail : '';
                            i.UserId    = i.UserRef ? i.UserRef.Id    : 0;
                            return i;
                        });
                    });
                }

                vm.resetForm = function () {
                    vm.form = { AppRole: '', Department: '', IsActive: true };
                    vm.editItem = null; vm.formOpen = false;
                };
                vm.editRole = function (item) {
                    vm.form = angular.copy(item);
                    vm.form.UserRefId = item.UserId;
                    vm.editItem = item; vm.formOpen = true;
                };
                vm.saveRole = function () {
                    var payload = {
                        AppRole: vm.form.AppRole,
                        Department: vm.form.Department || '',
                        IsActive: vm.form.IsActive !== false
                    };
                    if (vm.form.UserRefId) payload.UserRefId = vm.form.UserRefId;
                    var promise = vm.editItem
                        ? CRUDService.update(LISTS.ROLE_MANAGEMENT, vm.form.Id, payload)
                        : CRUDService.insert(LISTS.ROLE_MANAGEMENT, payload);
                    promise.then(function () {
                        NotificationService.success('Role saved.'); vm.resetForm(); _load();
                    }).catch(function (e) { NotificationService.error('Failed: ' + (e.data||e)); });
                };
                vm.toggleActive = function (item) {
                    CRUDService.update(LISTS.ROLE_MANAGEMENT, item.Id, { IsActive: !item.IsActive })
                        .then(function () { item.IsActive = !item.IsActive; NotificationService.success('Updated.'); });
                };
                vm.deleteRole = function (item) {
                    UtilityService.confirm('Delete role for ' + item.UserTitle + '?', 'Confirm Delete', 'Yes, Delete')
                        .then(function () {
                            CRUDService.delete(LISTS.ROLE_MANAGEMENT, item.Id).then(function () {
                                NotificationService.success('Deleted.'); _load();
                            });
                        });
                };
            }
        ]);
}());
