/**
 * OPEXController.js – CRUD for OPEX Master.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('OPEXController', [
            'CRUDService', 'NotificationService', 'APP_CONST',
            function (CRUDService, NotificationService, APP_CONST) {
                var vm   = this;
                var LIST = APP_CONST.LISTS.OPEX_MASTER;

                vm.loading = false; vm.saving = false;
                vm.items = []; vm.editItem = null; vm.form = _empty();

                vm.$onInit = function () { vm.load(); };

                vm.load = function () {
                    vm.loading = true;
                    CRUDService.getAll(LIST, { orderby: 'OPEXName' })
                        .then(function (d) { vm.items = d; })
                        .catch(function () { NotificationService.error('Failed to load OPEX.'); })
                        .finally(function () { vm.loading = false; });
                };

                vm.edit   = function (i) { vm.editItem = i; vm.form = angular.copy(i); };
                vm.cancel = function ()  { vm.editItem = null; vm.form = _empty(); };

                vm.save = function () {
                    if (!vm.form.OPEXCode || !vm.form.OPEXName) { NotificationService.warning('Code and Name required.'); return; }
                    vm.saving = true;
                    var p = vm.editItem
                        ? CRUDService.update(LIST, vm.editItem.Id, vm.form)
                        : CRUDService.insert(LIST, angular.extend(vm.form, { IsActive: true }));
                    p.then(function () { NotificationService.success('Saved.'); vm.cancel(); vm.load(); })
                     .catch(function () { NotificationService.error('Save failed.'); })
                     .finally(function () { vm.saving = false; });
                };

                vm.toggleActive = function (item) {
                    CRUDService.update(LIST, item.Id, { IsActive: !item.IsActive })
                        .then(function () { item.IsActive = !item.IsActive; });
                };

                function _empty() { return { OPEXCode: '', OPEXName: '', Description: '', IsActive: true }; }
            }
        ]);
}());
