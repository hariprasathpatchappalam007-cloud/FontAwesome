/**
 * ProjectController.js – Project master CRUD.
 * AdminController.js – Administration shell controller.
 */
(function () {
    'use strict';

    angular.module('PETApp.controllers')
        .controller('ProjectController', [
            'CRUDService', 'NotificationService', 'APP_CONST',
            function (CRUDService, NotificationService, APP_CONST) {
                var vm = this;
                var LIST = APP_CONST.LISTS.PROJECT_DETAILS;

                vm.loading = false; vm.saving = false;
                vm.items = []; vm.editItem = null; vm.form = _empty();

                vm.$onInit = function () { vm.load(); };

                vm.load = function () {
                    vm.loading = true;
                    CRUDService.getAll(LIST, { orderby: 'ProjectName' })
                        .then(function (d) { vm.items = d; })
                        .catch(function () { NotificationService.error('Failed to load projects.'); })
                        .finally(function () { vm.loading = false; });
                };

                vm.edit   = function (i) { vm.editItem = i; vm.form = angular.copy(i); };
                vm.cancel = function ()  { vm.editItem = null; vm.form = _empty(); };

                vm.save = function () {
                    if (!vm.form.ProjectCode || !vm.form.ProjectName) {
                        NotificationService.warning('Code and Name required.');
                        return;
                    }
                    vm.saving = true;
                    var p = vm.editItem
                        ? CRUDService.update(LIST, vm.editItem.Id, vm.form)
                        : CRUDService.insert(LIST, vm.form);
                    p.then(function () { NotificationService.success('Saved.'); vm.cancel(); vm.load(); })
                     .catch(function () { NotificationService.error('Save failed.'); })
                     .finally(function () { vm.saving = false; });
                };

                function _empty() {
                    return { ProjectCode: '', ProjectName: '', Department: '', ProjectStatus: 'Active', IsActive: true };
                }
            }
        ])

        .controller('AdminController', ['$location', function ($location) {
            var vm = this;
            vm.navigate = function (path) { $location.path(path); };
        }]);

}());
