/**
 * MyApprovalController.js – Shows all pending approvals for the current user.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('MyApprovalController', [
            '$location', 'ApprovalService', 'NotificationService', 'APP_CONST',
            function ($location, ApprovalService, NotificationService, APP_CONST) {
                var vm = this;

                vm.loading      = false;
                vm.pendingList  = [];
                vm.historyList  = [];
                vm.activeTab    = 'pending';
                vm.pendingCount = 0;

                vm.$onInit = function () {
                    vm.loading = true;
                    ApprovalService.getMyPendingApprovals()
                        .then(function (list) {
                            vm.pendingList  = list;
                            vm.pendingCount = list.length;
                        })
                        .catch(function () { NotificationService.error('Failed to load approvals.'); })
                        .finally(function () { vm.loading = false; });

                    ApprovalService.getApprovalHistory()
                        .then(function (h) { vm.historyList = h; })
                        .catch(angular.noop);
                };

                vm.openApproval = function (item) { $location.path('/pet/approval/' + item.Id); };
                vm.setTab       = function (tab)  { vm.activeTab = tab; };
            }
        ]);
}());
