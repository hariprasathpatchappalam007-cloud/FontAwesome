/**
 * GLController.js – CRUD for GL Master.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('GLController', [
            'CRUDService', 'NotificationService', 'APP_CONST',
            function (CRUDService, NotificationService, APP_CONST) {
                var vm   = this;
                var LIST = APP_CONST.LISTS.GL_MASTER;

                vm.loading = false; vm.saving = false;
                vm.items = []; vm.editItem = null; vm.form = _empty();
                vm.glTypes = ['CAPEX', 'OPEX'];

                vm.$onInit = function () { vm.load(); };

                vm.load = function () {
                    vm.loading = true;
                    CRUDService.getAll(LIST, { orderby: 'GLNumber' })
                        .then(function (d) { vm.items = d; })
                        .catch(function () { NotificationService.error('Failed to load GL Master.'); })
                        .finally(function () { vm.loading = false; });
                };

                vm.edit   = function (i) { vm.editItem = i; vm.form = angular.copy(i); };
                vm.cancel = function ()  { vm.editItem = null; vm.form = _empty(); };

                vm.save = function () {
                    if (!vm.form.GLNumber || !vm.form.GLDescription) { NotificationService.warning('GL Number and Description required.'); return; }
                    vm.saving = true;
                    var p = vm.editItem
                        ? CRUDService.update(LIST, vm.editItem.Id, vm.form)
                        : CRUDService.insert(LIST, angular.extend(vm.form, { IsActive: true }));
                    p.then(function () { NotificationService.success('Saved.'); vm.cancel(); vm.load(); })
                     .catch(function () { NotificationService.error('Save failed.'); })
                     .finally(function () { vm.saving = false; });
                };

                vm.toggleActive = function (item) {
                    CRUDService.update(LIST, item.Id, { IsActive: !item.IsActive })
                        .then(function () { item.IsActive = !item.IsActive; });
                };

                function _empty() {
                    return { GLNumber: '', GLDescription: '', GLType: '', BudgetedAmount: 0, IsActive: true };
                }
            }
        ]);
}());
