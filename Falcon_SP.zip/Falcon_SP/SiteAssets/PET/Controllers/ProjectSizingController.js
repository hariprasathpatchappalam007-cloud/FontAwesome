/**
 * ProjectSizingController.js
 * Manages line item grid for project sizing / budget calculation.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('ProjectSizingController', [
            '$routeParams', '$location', 'CRUDService', 'LookupService',
            'ValidationService', 'NotificationService', 'UtilityService', 'APP_CONST',
            function ($routeParams, $location, CRUDService, LookupService,
                      ValidationService, NotificationService, UtilityService, APP_CONST) {
                var vm    = this;
                var LISTS = APP_CONST.LISTS;

                vm.loading    = false;
                vm.saving     = false;
                vm.petId      = $routeParams.id;
                vm.pet        = null;
                vm.lineItems  = [];
                vm.editLine   = null;
                vm.newLine    = _emptyLine();
                vm.capexList  = [];
                vm.opexList   = [];
                vm.vendorList = [];
                vm.glList     = [];
                vm.totalAED   = 0;
                vm.currencies = APP_CONST.CURRENCIES;

                vm.$onInit = function () {
                    vm.loading = true;
                    var loads = [
                        CRUDService.getById(LISTS.PET_PROJECTS, vm.petId),
                        CRUDService.getByFilter(LISTS.PROJECT_SIZING, 'PETProjectId eq ' + vm.petId,
                            { orderby: 'LineItemNo' }),
                        LookupService.getCapexList(),
                        LookupService.getOpexList(),
                        LookupService.getVendorList(),
                        LookupService.getGLList()
                    ];
                    Promise.all(loads).then(function (results) {
                        vm.pet       = results[0];
                        vm.lineItems = results[1];
                        vm.capexList = results[2];
                        vm.opexList  = results[3];
                        vm.vendorList= results[4];
                        vm.glList    = results[5];
                        _calcTotal();
                    }).catch(function () {
                        NotificationService.error('Failed to load sizing data.');
                    }).finally(function () { vm.loading = false; });
                };

                vm.calcLine = function (line) {
                    UtilityService.calcLine(line);
                    _calcTotal();
                };

                vm.addLine = function () {
                    var errors = ValidationService.validateLineItem(vm.newLine);
                    if (errors.length) { NotificationService.warning(errors.join(' ')); return; }
                    vm.saving = true;
                    vm.newLine.PETProjectId = vm.petId;
                    vm.newLine.LineItemNo   = vm.lineItems.length + 1;
                    UtilityService.calcLine(vm.newLine);
                    CRUDService.insert(LISTS.PROJECT_SIZING, vm.newLine)
                        .then(function (saved) {
                            vm.lineItems.push(saved);
                            vm.newLine = _emptyLine();
                            _calcTotal();
                            NotificationService.success('Line item added.');
                        })
                        .catch(function () { NotificationService.error('Failed to add line item.'); })
                        .finally(function () { vm.saving = false; });
                };

                vm.deleteLine = function (line) {
                    CRUDService.delete(LISTS.PROJECT_SIZING, line.Id)
                        .then(function () {
                            vm.lineItems = vm.lineItems.filter(function (l) { return l.Id !== line.Id; });
                            _calcTotal();
                            NotificationService.success('Line item removed.');
                        })
                        .catch(function () { NotificationService.error('Failed to remove line item.'); });
                };

                vm.next  = function () { $location.path('/pet/approval/' + vm.petId); };
                vm.back  = function () { $location.path('/pet/edit/'     + vm.petId); };

                function _calcTotal() {
                    vm.totalAED = vm.lineItems.reduce(function (sum, l) {
                        return sum + (parseFloat(l.FinalAmountLCY) || 0);
                    }, 0);
                    // Sync total back to PET Projects list
                    if (vm.pet && vm.pet.Id) {
                        CRUDService.update(LISTS.PET_PROJECTS, vm.pet.Id,
                            { RequestedAmountAED: vm.totalAED }).catch(angular.noop);
                    }
                }

                function _emptyLine() {
                    return {
                        Description: '', Quantity: 1, UnitPrice: 0,
                        Currency: 'AED', ExchangeRate: 1, Contingency: 0,
                        FCYAmount: 0, LCYAmount: 0, FinalAmountLCY: 0,
                        VendorRefId: null, GLRefId: null, CAPEXRefId: null, OPEXRefId: null
                    };
                }
            }
        ]);
}());
