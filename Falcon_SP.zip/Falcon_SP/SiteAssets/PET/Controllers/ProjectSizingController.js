﻿/**
 * ProjectSizingController.js – Scoring assessment (7 criteria)
 * Used both as standalone route /pet/sizing/:id AND as ng-include in PET form.
 * When used inline, vm.sizing is set on the parent PETController.
 */
(function () {
    'use strict';
    angular.module('PETApp.controllers')
        .controller('ProjectSizingController', [
            '$routeParams', 'CRUDService', 'NotificationService', 'APP_CONST',
            function ($routeParams, CRUDService, NotificationService, APP_CONST) {
                var vm    = this;
                var LISTS = APP_CONST.LISTS;
                var petId = $routeParams.id;

                vm.sizing = _initSizing();

                vm.$onInit = function () {
                    if (!petId) return;
                    CRUDService.getAll(LISTS.PROJECT_SIZING_SCORE || 'Project Sizing Score', {
                        filter: 'PETProjectId eq ' + petId,
                        orderby: 'Modified desc', top: 1
                    }).then(function (items) {
                        if (items.length) _loadSaved(items[0]);
                    }).catch(angular.noop);
                };

                vm.calcSizing = function () {
                    var total = 0;
                    vm.sizing.criteria.forEach(function (c) { total += (c.value || 0) * c.weight; });
                    vm.sizing.score = total;
                    vm.sizing.sizeLabel = _sizeFromScore(total);
                };

                vm.saveSizing = function () {
                    vm.calcSizing();
                    vm.sizing.saving = true;
                    var payload = { PETProjectId: petId, Score: vm.sizing.score, SizeLabel: vm.sizing.sizeLabel };
                    vm.sizing.criteria.forEach(function (c, i) { payload['C' + (i+1)] = c.value || 0; });

                    CRUDService.insert(LISTS.PROJECT_SIZING_SCORE || 'Project Sizing Score', payload)
                        .then(function () {
                            vm.sizing.saved = true;
                            NotificationService.success('Assessment saved. Size: ' + vm.sizing.sizeLabel);
                        }).catch(function () { NotificationService.error('Failed to save assessment.'); })
                        .finally(function () { vm.sizing.saving = false; });
                };

                vm.resetSizing = function () {
                    vm.sizing.criteria.forEach(function (c) { c.value = 0; });
                    vm.sizing.score = 0;
                    vm.sizing.sizeLabel = '';
                    vm.sizing.saved = false;
                };

                function _initSizing() {
                    return {
                        score: 0, sizeLabel: '', saved: false, saving: false,
                        criteria: [
                            { name:'Technical / Service Complexity', weight:0.20, value:0,
                              lowDesc:'Existing platforms, proven tech',
                              medDesc:'Some custom design, limited novelty',
                              highDesc:'New/unproven tech, complex integrations' },
                            { name:'Regulatory / Compliance / Security', weight:0.20, value:0,
                              lowDesc:'No regulated data, standard security',
                              medDesc:'Compliance / privacy requirements',
                              highDesc:'High regulatory/audit exposure' },
                            { name:'Stakeholder Complexity', weight:0.15, value:0,
                              lowDesc:'Single business owner, aligned',
                              medDesc:'Multiple BUs, competing priorities',
                              highDesc:'Many stakeholders, divergent interests' },
                            { name:'Resource / Capability Dependency', weight:0.15, value:0,
                              lowDesc:'Skills available internally',
                              medDesc:'Some external specialists',
                              highDesc:'Critical niche skills, major hiring' },
                            { name:'Scale / Reliability / Performance', weight:0.15, value:0,
                              lowDesc:'Low volume, standard SLA',
                              medDesc:'Moderate load, failover needed',
                              highDesc:'Mission-critical, extreme performance' },
                            { name:'Interdependencies / Portfolio', weight:0.10, value:0,
                              lowDesc:'Standalone initiative',
                              medDesc:'Some shared dependencies',
                              highDesc:'Heavy cross-programme dependencies' },
                            { name:'Budget / Contract Complexity', weight:0.05, value:0,
                              lowDesc:'Simple procurement, internal',
                              medDesc:'Multi-vendor, standard contracts',
                              highDesc:'Complex commercial, regulatory procurement' }
                        ]
                    };
                }

                function _loadSaved(item) {
                    for (var i = 0; i < 7; i++) {
                        vm.sizing.criteria[i].value = item['C' + (i+1)] || 0;
                    }
                    vm.sizing.score = item.Score || 0;
                    vm.sizing.sizeLabel = item.SizeLabel || _sizeFromScore(vm.sizing.score);
                    vm.sizing.saved = true;
                }

                function _sizeFromScore(s) {
                    if (s <= 1.5) return 'XS';
                    if (s <= 2.3) return 'S';
                    if (s <= 3.2) return 'M';
                    if (s <= 4.1) return 'L';
                    return 'XL';
                }
            }
        ]);
}());
