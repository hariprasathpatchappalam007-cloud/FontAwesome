/**
 * EmailService.js
 * Sends SharePoint workflow email notifications and logs them to the Email Logs list.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('EmailService', ['$http', '$q', 'CRUDService', 'SharePointService', 'APP_CONST',
            function ($http, $q, CRUDService, SharePointService, APP_CONST) {

                var self     = this;
                var LISTS    = APP_CONST.LISTS;
                var siteUrl  = SharePointService.getSiteUrl();

                /**
                 * Sends an email using the SharePoint /_api/SP.Utilities.Utility.SendEmail endpoint.
                 * Falls back gracefully if the email cannot be sent.
                 */
                self.send = function (toAddresses, subject, body, ccAddresses) {
                    var payload = {
                        properties: {
                            __metadata: { type: 'SP.Utilities.EmailProperties' },
                            To:   { results: Array.isArray(toAddresses) ? toAddresses : [toAddresses] },
                            Subject: subject,
                            Body:    body
                        }
                    };
                    if (ccAddresses && ccAddresses.length) {
                        payload.properties.CC = { results: Array.isArray(ccAddresses) ? ccAddresses : [ccAddresses] };
                    }

                    return $http.post(siteUrl + '/_api/SP.Utilities.Utility.SendEmail', payload)
                        .then(function () { return { success: true }; })
                        .catch(function (err) {
                            console.error('EmailService.send failed:', err);
                            return { success: false, error: err };
                        });
                };

                /**
                 * Sends a workflow-triggered email based on the event type.
                 * Loads the template from the Email Templates library and substitutes tokens.
                 */
                self.sendWorkflowEmail = function (petId, eventType) {
                    return $q.all({
                        pet:      CRUDService.getById(LISTS.PET_PROJECTS, petId, {
                            select:  'Id,PETRefNo,ProjectTitle,PETStatus,RequestedAmountAED,' +
                                     'Requestor/Title,Requestor/EMail,Reviewer/Title,Reviewer/EMail',
                            expand:  'Requestor,Reviewer'
                        }),
                        template: _getEmailTemplate(eventType)
                    }).then(function (data) {
                        if (!data.template) return $q.resolve(null); // No template configured

                        var body    = _applyTokens(data.template.body, data.pet);
                        var subject = _applyTokens(data.template.subject, data.pet);
                        var to      = _getRecipients(eventType, data.pet);

                        return self.send(to, subject, body)
                            .then(function (result) {
                                return _logEmail(petId, to, subject, body, result);
                            });
                    });
                };

                // ── Private ──────────────────────────────────────────────────
                function _getEmailTemplate(eventType) {
                    return CRUDService.getByFilter(
                        LISTS.APP_SETTINGS,
                        "SettingKey eq 'EmailTemplate_" + eventType + "' and IsActive eq 1"
                    ).then(function (items) {
                        return items.length ? items[0] : null;
                    });
                }

                function _applyTokens(text, pet) {
                    if (!text || !pet) return text;
                    return text
                        .replace(/\{PETRefNo\}/g,           pet.PETRefNo         || '')
                        .replace(/\{ProjectTitle\}/g,       pet.ProjectTitle      || '')
                        .replace(/\{PETStatus\}/g,          pet.PETStatus         || '')
                        .replace(/\{RequestorName\}/g,      pet.Requestor ? pet.Requestor.Title  : '')
                        .replace(/\{RequestedAmountAED\}/g, pet.RequestedAmountAED || '0');
                }

                function _getRecipients(eventType, pet) {
                    switch (eventType) {
                        case 'SUBMIT':           return pet.Reviewer   ? [pet.Reviewer.EMail]   : [];
                        case 'REVIEW_APPROVE':   return pet.Requestor  ? [pet.Requestor.EMail]  : [];
                        case 'REVIEW_SENDBACK':  return pet.Requestor  ? [pet.Requestor.EMail]  : [];
                        case 'PET_APPROVED':     return pet.Requestor  ? [pet.Requestor.EMail]  : [];
                        case 'PET_REJECTED':     return pet.Requestor  ? [pet.Requestor.EMail]  : [];
                        default:                 return [];
                    }
                }

                function _logEmail(petId, to, subject, body, result) {
                    return CRUDService.insert(LISTS.EMAIL_LOGS, {
                        ToAddress:    Array.isArray(to) ? to.join(';') : to,
                        Subject:      subject,
                        Body:         body,
                        SentDate:     new Date().toISOString(),
                        SentStatus:   result.success ? 'Sent' : 'Failed',
                        PETRefId:     petId || null,
                        ErrorMessage: result.error ? String(result.error) : null
                    });
                }
            }
        ]);

}());
