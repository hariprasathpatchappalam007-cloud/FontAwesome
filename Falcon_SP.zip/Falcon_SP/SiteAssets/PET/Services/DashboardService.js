/**
 * DashboardService.js
 * Provides KPI tiles, chart data and summary statistics for the dashboard.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('DashboardService', ['$q', 'CRUDService', 'APP_CONST',
            function ($q, CRUDService, APP_CONST) {

                var self  = this;
                var LISTS = APP_CONST.LISTS;

                /**
                 * Returns all KPI tile counts in a single parallel call.
                 */
                self.getKPIs = function () {
                    return $q.all({
                        total:       CRUDService.getCount(LISTS.PET_PROJECTS),
                        pending:     CRUDService.getCount(LISTS.PET_PROJECTS, "PETStatus ne 'Approved' and PETStatus ne 'Rejected' and PETStatus ne 'Cancelled'"),
                        approved:    CRUDService.getCount(LISTS.PET_PROJECTS, "PETStatus eq 'Approved'"),
                        rejected:    CRUDService.getCount(LISTS.PET_PROJECTS, "PETStatus eq 'Rejected'"),
                        longPending: CRUDService.getCount(LISTS.PET_PROJECTS,
                            "PETStatus ne 'Approved' and PETStatus ne 'Rejected' and " +
                            "SubmittedDate le datetime'" + _daysAgo(14) + "'")
                    });
                };

                /**
                 * Returns PET project list with optional filters for the dashboard grid.
                 * @param {Object} filters – {project, type, status, fromDate, toDate, view, viewUser}
                 * @param {number} page
                 * @param {number} pageSize
                 */
                self.getPETList = function (filters, page, pageSize) {
                    var filter = _buildFilter(filters);
                    return CRUDService.getPaged(LISTS.PET_PROJECTS, page, pageSize, {
                        select:  'Id,PETRefNo,ProjectTitle,ProjectType,PETStatus,RequestedAmountAED,' +
                                 'SubmittedDate,ApprovedDate,Requestor/Title,JIRAProjectKey',
                        expand:  'Requestor',
                        filter:  filter,
                        orderby: 'Id desc'
                    });
                };

                /**
                 * Returns status distribution for the doughnut chart.
                 */
                self.getStatusDistribution = function () {
                    return CRUDService.getAll(LISTS.PET_PROJECTS, {
                        select: 'PETStatus',
                        top:    5000
                    }).then(function (items) {
                        var counts = {};
                        items.forEach(function (i) {
                            counts[i.PETStatus] = (counts[i.PETStatus] || 0) + 1;
                        });
                        return counts;
                    });
                };

                /**
                 * Returns monthly submission trend for the line chart.
                 */
                self.getMonthlyTrend = function () {
                    var from = _daysAgo(365);
                    return CRUDService.getByFilter(LISTS.PET_PROJECTS,
                        "SubmittedDate ge datetime'" + from + "'",
                        { select: 'SubmittedDate', top: 5000 }
                    ).then(function (items) {
                        var monthly = {};
                        items.forEach(function (i) {
                            if (!i.SubmittedDate) return;
                            var m = i.SubmittedDate.substring(0, 7);
                            monthly[m] = (monthly[m] || 0) + 1;
                        });
                        return monthly;
                    });
                };

                // ── Private ──────────────────────────────────────────────────
                function _buildFilter(f) {
                    if (!f) return '';
                    var parts = [];
                    if (f.project)  parts.push("JIRAProjectKey eq '" + f.project + "'");
                    if (f.type)     parts.push("ProjectType eq '" + f.type + "'");
                    if (f.status)   parts.push("PETStatus eq '" + f.status + "'");
                    if (f.fromDate) parts.push("SubmittedDate ge datetime'" + new Date(f.fromDate).toISOString() + "'");
                    if (f.toDate)   parts.push("SubmittedDate le datetime'" + new Date(f.toDate).toISOString() + "'");
                    if (f.view === 'MINE' && f.userId)
                        parts.push("RequestorId eq " + f.userId);
                    return parts.join(' and ');
                }

                function _daysAgo(days) {
                    var d = new Date();
                    d.setDate(d.getDate() - days);
                    return d.toISOString();
                }
            }
        ]);

}());
