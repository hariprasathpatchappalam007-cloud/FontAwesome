/**
 * AutoCompleteService.js – Provides project auto-complete search via SharePoint REST.
 */
(function () {
    'use strict';
    angular.module('PETApp.services')
        .service('AutoCompleteService', ['CRUDService', 'APP_CONST', function (CRUDService, APP_CONST) {
            var self = this;
            self.searchProjects = function (term) {
                if (!term || term.length < 2) return Promise.resolve([]);
                return CRUDService.getByFilter(
                    APP_CONST.LISTS.PROJECT_DETAILS,
                    "substringof('" + term.replace(/'/g, "''") + "',ProjectName) and IsActive eq 1",
                    { select: 'Id,ProjectCode,ProjectName', top: 15 }
                );
            };
        }]);
}());
