/**
 * LookupService.js
 * Retrieves master data lookup values for dropdowns and auto-complete.
 * Results are cached in CacheFactory to minimize REST calls.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('LookupService', ['$q', 'CRUDService', 'CacheFactory', 'APP_CONST',
            function ($q, CRUDService, CacheFactory, APP_CONST) {

                var self  = this;
                var LISTS = APP_CONST.LISTS;

                function cached(key, fetchFn) {
                    var cached = CacheFactory.get(key);
                    if (cached) return $q.resolve(cached);
                    return fetchFn().then(function (data) {
                        CacheFactory.set(key, data);
                        return data;
                    });
                }

                self.getCapexList = function () {
                    return cached('capex', function () {
                        return CRUDService.getByFilter(LISTS.CAPEX_MASTER, 'IsActive eq 1',
                            { select: 'Id,CAPEXCode,CAPEXName', orderby: 'CAPEXName' });
                    });
                };

                self.getOpexList = function () {
                    return cached('opex', function () {
                        return CRUDService.getByFilter(LISTS.OPEX_MASTER, 'IsActive eq 1',
                            { select: 'Id,OPEXCode,OPEXName', orderby: 'OPEXName' });
                    });
                };

                self.getVendorList = function () {
                    return cached('vendors', function () {
                        return CRUDService.getByFilter(LISTS.VENDOR_MASTER, 'IsActive eq 1',
                            { select: 'Id,VendorCode,VendorName', orderby: 'VendorName' });
                    });
                };

                self.getGLList = function () {
                    return cached('gl', function () {
                        return CRUDService.getByFilter(LISTS.GL_MASTER, 'IsActive eq 1',
                            { select: 'Id,GLNumber,GLDescription,GLType', orderby: 'GLNumber' });
                    });
                };

                self.getBudgetSources = function () {
                    return cached('budgetSources', function () {
                        return CRUDService.getByFilter(LISTS.BUDGET_SOURCE, 'IsActive eq 1',
                            { select: 'Id,SourceCode,SourceName,FiscalYear', orderby: 'SourceName' });
                    });
                };

                self.getRoles = function () {
                    return cached('roles', function () {
                        return CRUDService.getByFilter(LISTS.ROLE_MANAGEMENT, 'IsActive eq 1',
                            { select: 'Id,AppRole,UserRef/Title,UserRef/EMail,Department',
                              expand: 'UserRef', orderby: 'AppRole' });
                    });
                };

                self.clearAll = function () {
                    ['capex', 'opex', 'vendors', 'gl', 'budgetSources', 'roles']
                        .forEach(function (k) { CacheFactory.remove(k); });
                };
            }
        ]);

}());
