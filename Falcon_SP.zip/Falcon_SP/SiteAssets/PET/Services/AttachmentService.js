/**
 * AttachmentService.js
 * Upload and download file attachments from SharePoint document libraries.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('AttachmentService', ['$http', '$q', 'SharePointService', 'APP_CONST',
            function ($http, $q, SharePointService, APP_CONST) {

                var self     = this;
                var siteUrl  = SharePointService.getSiteUrl();
                var LIBS     = APP_CONST.LIBRARIES;

                /**
                 * Upload a file to a SharePoint document library folder.
                 * @param {File}   file       – HTML5 File object
                 * @param {string} library    – Library title
                 * @param {string} folderPath – Server-relative folder path (e.g. '/sites/PET/PET Attachments/123')
                 * @param {Object} metadata   – Optional field values to set after upload
                 */
                self.upload = function (file, library, folderPath, metadata) {
                    if (!file) return $q.reject('No file provided.');

                    var fileName   = _sanitizeFileName(file.name);
                    var uploadUrl  = siteUrl + "/_api/web/GetFolderByServerRelativeUrl('" +
                        encodeURIComponent(folderPath) + "')/Files/add(url='" +
                        encodeURIComponent(fileName) + "',overwrite=true)";

                    return _readFileAsArrayBuffer(file)
                        .then(function (buffer) {
                            return $http({
                                method:  'POST',
                                url:     uploadUrl,
                                data:    buffer,
                                headers: { 'Content-Type': undefined },
                                transformRequest: angular.identity
                            });
                        })
                        .then(function (res) {
                            var uploadedFile = res.data.d;
                            if (metadata) {
                                return _updateFileMetadata(uploadedFile.ListItemAllFields.__deferred.uri, metadata)
                                    .then(function () { return uploadedFile; });
                            }
                            return uploadedFile;
                        });
                };

                /**
                 * Ensure a folder exists in a document library; create it if not.
                 */
                self.ensureFolder = function (library, folderName) {
                    var libRelUrl = _getSiteRelativePath() + library;
                    var folderUrl = libRelUrl + '/' + folderName;
                    var endpoint  = siteUrl + "/_api/web/folders/add('" + encodeURIComponent(folderUrl) + "')";
                    return $http.post(endpoint, {}).catch(function () { /* Folder may already exist */ });
                };

                /**
                 * Returns all files in a library folder.
                 */
                self.getFiles = function (library, folderPath) {
                    var endpoint = siteUrl + "/_api/web/GetFolderByServerRelativeUrl('" +
                        encodeURIComponent(folderPath) + "')/Files?" +
                        "$select=Name,ServerRelativeUrl,TimeCreated,Author/Title&$expand=Author";
                    return $http.get(endpoint).then(function (res) { return res.data.d.results; });
                };

                /**
                 * Deletes a file by its server-relative URL.
                 */
                self.deleteFile = function (serverRelativeUrl) {
                    return $http({
                        method:  'POST',
                        url:     siteUrl + "/_api/web/GetFileByServerRelativeUrl('" +
                                 encodeURIComponent(serverRelativeUrl) + "')",
                        headers: { 'X-HTTP-Method': 'DELETE', 'IF-MATCH': '*' }
                    });
                };

                // ── Private ───────────────────────────────────────────────────
                function _readFileAsArrayBuffer(file) {
                    var deferred = $q.defer();
                    var reader   = new FileReader();
                    reader.onload  = function (e) { deferred.resolve(e.target.result); };
                    reader.onerror = function (e) { deferred.reject(e); };
                    reader.readAsArrayBuffer(file);
                    return deferred.promise;
                }

                function _updateFileMetadata(listItemUri, fields) {
                    fields.__metadata = { type: 'SP.ListItem' };
                    return $http({
                        method:  'POST',
                        url:     listItemUri,
                        data:    fields,
                        headers: { 'X-HTTP-Method': 'MERGE', 'IF-MATCH': '*' }
                    });
                }

                function _getSiteRelativePath() {
                    var url = new URL(siteUrl);
                    return url.pathname.replace(/\/$/, '') + '/';
                }

                function _sanitizeFileName(name) {
                    return name.replace(/[~#%&*{}\\:<>?/|"]/g, '_');
                }
            }
        ]);

}());
