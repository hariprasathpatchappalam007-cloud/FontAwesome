/**
 * CRUDService.js
 * Generic SharePoint REST API CRUD operations.
 * All list operations go through this service for consistency and testability.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('CRUDService', ['$http', '$q', 'SharePointService', 'APP_CONST',
            function ($http, $q, SharePointService, APP_CONST) {

                var self    = this;
                var apiBase = SharePointService.getSiteUrl() + '/_api/web/lists/getbytitle(\'';

                // ── HELPERS ─────────────────────────────────────────────────
                function listEndpoint(listName) {
                    return apiBase + encodeURIComponent(listName) + '\')';
                }

                function itemsEndpoint(listName) {
                    return listEndpoint(listName) + '/items';
                }

                function itemEndpoint(listName, id) {
                    return itemsEndpoint(listName) + '(' + id + ')';
                }

                function buildODataQuery(options) {
                    var parts = [];
                    if (options.select)  parts.push('$select='  + options.select);
                    if (options.expand)  parts.push('$expand='  + options.expand);
                    if (options.filter)  parts.push('$filter='  + options.filter);
                    if (options.orderby) parts.push('$orderby=' + options.orderby);
                    if (options.top)     parts.push('$top='     + options.top);
                    if (options.skip)    parts.push('$skip='    + options.skip);
                    return parts.length ? '?' + parts.join('&') : '';
                }

                // ── GET ALL (with optional OData options) ────────────────────
                self.getAll = function (listName, options) {
                    var query = buildODataQuery(options || {});
                    return $http.get(itemsEndpoint(listName) + query)
                        .then(function (res) { return res.data.d.results; });
                };

                // ── GET ALL PAGED ─────────────────────────────────────────────
                self.getPaged = function (listName, pageNum, pageSize, options) {
                    var opts  = angular.extend({}, options || {});
                    opts.top  = pageSize  || APP_CONST.PAGE_SIZE;
                    opts.skip = ((pageNum || 1) - 1) * opts.top;
                    return $http.get(itemsEndpoint(listName) + buildODataQuery(opts))
                        .then(function (res) { return res.data.d; });
                };

                // ── GET BY ID ─────────────────────────────────────────────────
                self.getById = function (listName, id, options) {
                    var query = buildODataQuery(options || {});
                    return $http.get(itemEndpoint(listName, id) + query)
                        .then(function (res) { return res.data.d; });
                };

                // ── GET BY FILTER ─────────────────────────────────────────────
                self.getByFilter = function (listName, filter, options) {
                    var opts   = angular.extend({}, options || {});
                    opts.filter = filter;
                    return self.getAll(listName, opts);
                };

                // ── GET ITEM COUNT ─────────────────────────────────────────────
                self.getCount = function (listName, filter) {
                    var query = filter ? '?$filter=' + filter : '';
                    return $http.get(listEndpoint(listName) + '/ItemCount' + query)
                        .then(function (res) { return res.data.d.ItemCount; });
                };

                // ── INSERT ────────────────────────────────────────────────────
                self.insert = function (listName, item) {
                    return self.getListType(listName).then(function (type) {
                        item.__metadata = { type: type };
                        return $http.post(itemsEndpoint(listName), item)
                            .then(function (res) { return res.data.d; });
                    });
                };

                // ── UPDATE ────────────────────────────────────────────────────
                self.update = function (listName, id, item) {
                    return self.getListType(listName).then(function (type) {
                        item.__metadata = { type: type };
                        return $http({
                            method:  'POST',
                            url:     itemEndpoint(listName, id),
                            data:    item,
                            headers: {
                                'X-HTTP-Method': 'MERGE',
                                'IF-MATCH':      '*'
                            }
                        });
                    });
                };

                // ── DELETE ────────────────────────────────────────────────────
                self.delete = function (listName, id) {
                    return $http({
                        method:  'POST',
                        url:     itemEndpoint(listName, id),
                        headers: {
                            'X-HTTP-Method': 'DELETE',
                            'IF-MATCH':      '*'
                        }
                    });
                };

                // ── SOFT DELETE (set IsActive = false) ────────────────────────
                self.softDelete = function (listName, id) {
                    return self.update(listName, id, { IsActive: false });
                };

                // ── BATCH INSERT ──────────────────────────────────────────────
                self.batchInsert = function (listName, items) {
                    var promises = items.map(function (item) {
                        return self.insert(listName, item);
                    });
                    return $q.all(promises);
                };

                // ── BATCH UPDATE ──────────────────────────────────────────────
                self.batchUpdate = function (listName, items) {
                    var promises = items.map(function (item) {
                        return self.update(listName, item.Id, item);
                    });
                    return $q.all(promises);
                };

                // ── LIST TYPE CACHE ───────────────────────────────────────────
                var _typeCache = {};
                self.getListType = function (listName) {
                    if (_typeCache[listName]) return $q.resolve(_typeCache[listName]);
                    return $http.get(listEndpoint(listName) + '?$select=ListItemEntityTypeFullName')
                        .then(function (res) {
                            _typeCache[listName] = res.data.d.ListItemEntityTypeFullName;
                            return _typeCache[listName];
                        });
                };
            }
        ]);

}());
