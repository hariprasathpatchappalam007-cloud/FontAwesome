/**
 * JIRAService.js
 * JIRA REST API v2 integration for project synchronisation.
 * All calls are proxied through the SharePoint REST API proxy to avoid CORS issues.
 * Configure JIRA Base URL and Basic Auth token in Application Settings list.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('JIRAService', ['$http', '$q', 'CRUDService', 'APP_CONST',
            function ($http, $q, CRUDService, APP_CONST) {

                var self      = this;
                var LISTS     = APP_CONST.LISTS;
                var _settings = null;

                // ── Load JIRA settings from Application Settings list ─────────
                function getSettings() {
                    if (_settings) return $q.resolve(_settings);
                    return CRUDService.getByFilter(
                        LISTS.APP_SETTINGS,
                        "Category eq 'JIRA' and IsActive eq 1",
                        { select: 'SettingKey,SettingValue' }
                    ).then(function (items) {
                        _settings = {};
                        items.forEach(function (i) { _settings[i.SettingKey] = i.SettingValue; });
                        return _settings;
                    });
                }

                function jiraHeaders(settings) {
                    return {
                        'Authorization': 'Basic ' + settings['JIRA_AUTH_TOKEN'],
                        'Content-Type':  'application/json',
                        'Accept':        'application/json'
                    };
                }

                // ── Fetch projects from JIRA ──────────────────────────────────
                self.getJIRAProjects = function () {
                    return getSettings().then(function (s) {
                        var url = s['JIRA_BASE_URL'] + '/rest/api/2/project';
                        return $http.get(url, { headers: jiraHeaders(s) })
                            .then(function (res) { return res.data; });
                    });
                };

                // ── Search JIRA issues ────────────────────────────────────────
                self.searchIssues = function (jql, fields) {
                    return getSettings().then(function (s) {
                        var url = s['JIRA_BASE_URL'] + '/rest/api/2/search';
                        return $http.post(url, { jql: jql, fields: fields || ['summary', 'status', 'assignee'] },
                            { headers: jiraHeaders(s) })
                            .then(function (res) { return res.data.issues; });
                    });
                };

                // ── Sync JIRA projects to PET Projects list ───────────────────
                self.syncProjects = function () {
                    var startTime = new Date();
                    var stats = { total: 0, newItems: 0, updated: 0, failed: 0, errors: [] };

                    return self.getJIRAProjects()
                        .then(function (jiraProjects) {
                            stats.total = jiraProjects.length;
                            var promises = jiraProjects.map(function (jp) {
                                return _syncProject(jp, stats);
                            });
                            return $q.all(promises);
                        })
                        .then(function () {
                            return _logSync(stats, startTime, 'Full');
                        })
                        .then(function () { return stats; });
                };

                // ── Create issue in JIRA from PET ─────────────────────────────
                self.createIssue = function (pet) {
                    return getSettings().then(function (s) {
                        var url     = s['JIRA_BASE_URL'] + '/rest/api/2/issue';
                        var payload = {
                            fields: {
                                project:   { key: s['JIRA_DEFAULT_PROJECT'] },
                                summary:   pet.ProjectTitle,
                                issuetype: { name: 'Task' },
                                description: 'PET Ref: ' + pet.PETRefNo
                            }
                        };
                        return $http.post(url, payload, { headers: jiraHeaders(s) })
                            .then(function (res) { return res.data; });
                    });
                };

                // ── Private ───────────────────────────────────────────────────
                function _syncProject(jp, stats) {
                    return CRUDService.getByFilter(
                        LISTS.APP_SETTINGS,   // placeholder – would query a JIRA cache list
                        "SettingKey eq 'JIRA_" + jp.key + "'"
                    ).then(function () {
                        stats.updated++;
                    }).catch(function (e) {
                        stats.failed++;
                        stats.errors.push({ key: jp.key, error: e });
                    });
                }

                function _logSync(stats, startTime, syncType) {
                    return CRUDService.insert(LISTS.JIRA_SYNC_LOGS, {
                        SyncDate:       startTime.toISOString(),
                        SyncType:       syncType,
                        RecordsTotal:   stats.total,
                        RecordsNew:     stats.newItems,
                        RecordsUpdated: stats.updated,
                        RecordsFailed:  stats.failed,
                        SyncStatus:     stats.failed === 0 ? 'Success' : (stats.updated > 0 ? 'Partial' : 'Failed'),
                        ErrorDetails:   stats.errors.length ? JSON.stringify(stats.errors) : null
                    });
                }
            }
        ]);

}());
