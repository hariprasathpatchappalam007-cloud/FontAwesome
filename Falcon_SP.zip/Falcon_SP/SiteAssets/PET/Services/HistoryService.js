/**
 * HistoryService.js – Retrieves approval history for a given PET item.
 */
(function () {
    'use strict';
    angular.module('PETApp.services')
        .service('HistoryService', ['CRUDService', 'APP_CONST', function (CRUDService, APP_CONST) {
            var self = this;
            self.getHistory = function (petId) {
                return CRUDService.getByFilter(
                    APP_CONST.LISTS.APPROVAL_HISTORY,
                    'PETProjectId eq ' + petId,
                    { select: 'Id,ApprovalStep,Action,ActionDate,Comments,ActionBy/Title',
                      expand: 'ActionBy', orderby: 'ActionDate asc' }
                );
            };
        }]);
}());
