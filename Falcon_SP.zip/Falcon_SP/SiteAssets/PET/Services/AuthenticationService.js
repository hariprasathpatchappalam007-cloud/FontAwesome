/**
 * AuthenticationService.js
 * Handles current user retrieval, role resolution and route-level authorization.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('AuthenticationService', ['$q', '$http', 'SharePointService', 'CRUDService', 'APP_CONST',
            function ($q, $http, SharePointService, CRUDService, APP_CONST) {

                var self         = this;
                var _userPromise = null;   // Cache to avoid repeat calls

                /**
                 * Returns the current user with their application roles resolved.
                 * Result is cached for the session lifetime.
                 * @returns {Promise<{id, title, email, loginName, roles[]}>}
                 */
                self.getCurrentUser = function () {
                    if (_userPromise) return _userPromise;

                    _userPromise = SharePointService.getCurrentUser()
                        .then(function (spUser) {
                            return self.getUserRoles(spUser.Id)
                                .then(function (roles) {
                                    return angular.extend(spUser, { roles: roles });
                                });
                        })
                        .catch(function (err) {
                            _userPromise = null;
                            return $q.reject(err);
                        });

                    return _userPromise;
                };

                /**
                 * Loads roles for the given SP user ID from the Role Management list.
                 * Uses $expand=UserRef and client-side filter for maximum compatibility
                 * with SharePoint Subscription Edition REST API (avoids server-side
                 * Boolean/UserRef filter issues).
                 */
                self.getUserRoles = function (userId) {
                    return CRUDService.getAll(
                        APP_CONST.LISTS.ROLE_MANAGEMENT,
                        {
                            select: 'Id,AppRole,Department,IsActive,UserRef/Id,UserRef/Title',
                            expand: 'UserRef',
                            top: 500
                        }
                    ).then(function (items) {
                        var roles = items
                            .filter(function (i) {
                                return i.UserRef && i.UserRef.Id === userId && i.IsActive !== false;
                            })
                            .map(function (i) { return i.AppRole; });
                        // Any authenticated SP user with no explicit role gets Requestor
                        // so they can at least access Dashboard and PET Workflow.
                        return roles.length > 0 ? roles : ['Requestor'];
                    }).catch(function () {
                        // Fallback: if list doesn't exist or REST call fails,
                        // grant Requestor so the app is still usable.
                        return ['Requestor'];
                    });
                };

                /**
                 * Checks whether the current user has a specific application role.
                 */
                self.hasRole = function (role) {
                    return self.getCurrentUser().then(function (user) {
                        return user.roles && user.roles.indexOf(role) !== -1;
                    });
                };

                /**
                 * Checks whether the current user has any of the provided roles.
                 */
                self.hasAnyRole = function (roles) {
                    return self.getCurrentUser().then(function (user) {
                        if (!user.roles) return false;
                        return roles.some(function (r) {
                            return user.roles.indexOf(r) !== -1;
                        });
                    });
                };

                /**
                 * Used in route resolve to ensure the user is authenticated before entering a route.
                 */
                self.ensureAuthenticated = function () {
                    return self.getCurrentUser().then(function (user) {
                        if (!user || !user.Id) return $q.reject('unauthenticated');
                        return user;
                    });
                };

                /**
                 * Clears the cached user (e.g. after role assignment changes).
                 */
                self.clearCache = function () {
                    _userPromise = null;
                };

                /**
                 * Returns true if the supplied role is in the administrator set.
                 */
                self.isAdmin = function () {
                    return self.hasRole(APP_CONST.ROLES.ADMINISTRATOR);
                };
            }
        ]);

}());
