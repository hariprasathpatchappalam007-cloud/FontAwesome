/**
 * NotificationService.js
 * In-app toast notifications and global alert management.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('NotificationService', ['$rootScope', '$timeout', 'APP_CONST',
            function ($rootScope, $timeout, APP_CONST) {

                var self         = this;
                var _timeout     = APP_CONST.NOTIFICATION_TIMEOUT || 5000;
                var _cancelTimer = null;

                $rootScope.notification = null;

                function _show(type, message, persist) {
                    if (_cancelTimer) { $timeout.cancel(_cancelTimer); _cancelTimer = null; }
                    $rootScope.notification = { type: type, message: message, visible: true };
                    if (!persist) {
                        _cancelTimer = $timeout(function () {
                            $rootScope.notification.visible = false;
                        }, _timeout);
                    }
                }

                self.success = function (message, persist) { _show('success', message, persist); };
                self.error   = function (message, persist) { _show('danger',  message, persist); };
                self.warning = function (message, persist) { _show('warning', message, persist); };
                self.info    = function (message, persist) { _show('info',    message, persist); };

                self.dismiss = function () {
                    if (_cancelTimer) { $timeout.cancel(_cancelTimer); _cancelTimer = null; }
                    if ($rootScope.notification) $rootScope.notification.visible = false;
                };

                /**
                 * SweetAlert2-based confirmation dialog.
                 * @returns {Promise<boolean>}
                 */
                self.confirm = function (title, text, confirmText, type) {
                    if (typeof Swal === 'undefined') {
                        return { then: function (cb) { if (window.confirm(text)) cb(true); else cb(false); } };
                    }
                    return Swal.fire({
                        title:              title || 'Confirm',
                        text:               text  || 'Are you sure?',
                        icon:               type  || 'warning',
                        showCancelButton:   true,
                        confirmButtonText:  confirmText || 'Yes',
                        cancelButtonText:   'Cancel',
                        confirmButtonColor: '#007bff',
                        cancelButtonColor:  '#6c757d'
                    }).then(function (result) { return result.isConfirmed; });
                };
            }
        ]);

}());
