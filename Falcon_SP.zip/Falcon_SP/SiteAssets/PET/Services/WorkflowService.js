/**
 * WorkflowService.js
 * Manages PET workflow routing, status transitions and step assignments.
 *
 * Workflow steps:
 *   1 – Requestor submits  → status: Submitted
 *   2 – Reviewer reviews   → status: Under Review / Sent Back
 *   3 – CAPEX Approver     → status: CAPEX Approval / Rejected
 *   4 – OPEX Approver      → status: OPEX Approval  / Rejected
 *   5 – PET Approver       → status: PET Approval   / Approved / Rejected
 *   6 – System             → status: Completed (notification)
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('WorkflowService', [
            '$q', 'CRUDService', 'EmailService', 'NotificationService',
            'AuthenticationService', 'APP_CONST',
            function ($q, CRUDService, EmailService, NotificationService,
                      AuthenticationService, APP_CONST) {

                var self   = this;
                var LISTS  = APP_CONST.LISTS;
                var STATUS = APP_CONST.STATUS;
                var STEPS  = APP_CONST.WORKFLOW_STEPS;

                // ── SUBMIT ────────────────────────────────────────────────────
                self.submit = function (petId, reviewerLoginName) {
                    return AuthenticationService.getCurrentUser()
                        .then(function (user) {
                            var updates = {
                                PETStatusId:    STATUS.SUBMITTED,
                                PETStatus:      STATUS.SUBMITTED,
                                SubmittedDate:  new Date().toISOString(),
                                ReviewerId:     null  // filled after ensureUser
                            };
                            return CRUDService.update(LISTS.PET_PROJECTS, petId, updates);
                        })
                        .then(function () {
                            return self._addWorkflowStep(petId, STEPS.REVIEW, 'Reviewer Review', STATUS.SUBMITTED);
                        })
                        .then(function () {
                            return self._addHistory(petId, 'Submit', 'Submitted for Review', STATUS.SUBMITTED);
                        })
                        .then(function () {
                            return EmailService.sendWorkflowEmail(petId, 'SUBMIT');
                        });
                };

                // ── REVIEW ─────────────────────────────────────────────────────
                self.review = function (petId, action, comments, petType) {
                    var newStatus = action === 'Approve'
                        ? (petType === 'CAPEX' ? STATUS.CAPEX_APPROVAL : STATUS.OPEX_APPROVAL)
                        : STATUS.SENT_BACK;

                    return CRUDService.update(LISTS.PET_PROJECTS, petId, { PETStatus: newStatus })
                        .then(function () {
                            return self._addHistory(petId, 'Review', comments, action);
                        })
                        .then(function () {
                            return EmailService.sendWorkflowEmail(petId, action === 'Approve' ? 'REVIEW_APPROVE' : 'REVIEW_SENDBACK');
                        });
                };

                // ── CAPEX APPROVE ──────────────────────────────────────────────
                self.capexApprove = function (petId, action, comments) {
                    var newStatus = action === 'Approve' ? STATUS.OPEX_APPROVAL : STATUS.REJECTED;
                    return CRUDService.update(LISTS.PET_PROJECTS, petId, { PETStatus: newStatus })
                        .then(function () { return self._addHistory(petId, 'CAPEX Approval', comments, action); })
                        .then(function () { return EmailService.sendWorkflowEmail(petId, 'CAPEX_' + action.toUpperCase()); });
                };

                // ── OPEX APPROVE ───────────────────────────────────────────────
                self.opexApprove = function (petId, action, comments) {
                    var newStatus = action === 'Approve' ? STATUS.PET_APPROVAL : STATUS.REJECTED;
                    return CRUDService.update(LISTS.PET_PROJECTS, petId, { PETStatus: newStatus })
                        .then(function () { return self._addHistory(petId, 'OPEX Approval', comments, action); })
                        .then(function () { return EmailService.sendWorkflowEmail(petId, 'OPEX_' + action.toUpperCase()); });
                };

                // ── FINAL PET APPROVE ──────────────────────────────────────────
                self.petApprove = function (petId, action, comments) {
                    var newStatus = action === 'Approve' ? STATUS.APPROVED : STATUS.REJECTED;
                    var extraFields = action === 'Approve'
                        ? { ApprovedDate: new Date().toISOString() } : {};

                    return CRUDService.update(LISTS.PET_PROJECTS, petId,
                        angular.extend({ PETStatus: newStatus }, extraFields))
                        .then(function () { return self._addHistory(petId, 'PET Approval', comments, action); })
                        .then(function () {
                            return EmailService.sendWorkflowEmail(petId,
                                action === 'Approve' ? 'PET_APPROVED' : 'PET_REJECTED');
                        });
                };

                // ── RECALL ────────────────────────────────────────────────────
                self.recall = function (petId, comments) {
                    return CRUDService.update(LISTS.PET_PROJECTS, petId, { PETStatus: STATUS.DRAFT })
                        .then(function () { return self._addHistory(petId, 'Recall', comments, 'Recalled'); });
                };

                // ── CANCEL ────────────────────────────────────────────────────
                self.cancel = function (petId, comments) {
                    return CRUDService.update(LISTS.PET_PROJECTS, petId, { PETStatus: STATUS.CANCELLED })
                        .then(function () { return self._addHistory(petId, 'Cancel', comments, 'Cancelled'); });
                };

                // ── Get workflow history for a PET ────────────────────────────
                self.getWorkflowHistory = function (petId) {
                    return CRUDService.getByFilter(
                        LISTS.APPROVAL_HISTORY,
                        'PETProjectId eq ' + petId,
                        { select: 'Id,ApprovalStep,ActionBy/Title,Action,ActionDate,Comments',
                          expand: 'ActionBy', orderby: 'ActionDate desc' }
                    );
                };

                // ── Private helpers ───────────────────────────────────────────
                self._addWorkflowStep = function (petId, step, stepName, action) {
                    return CRUDService.insert(LISTS.PET_WORKFLOW, {
                        PETProjectId:  petId,
                        WorkflowStep:  step,
                        StepName:      stepName,
                        ActionTaken:   action,
                        ActionDate:    new Date().toISOString(),
                        IsCurrent:     true
                    });
                };

                self._addHistory = function (petId, step, comments, action) {
                    return AuthenticationService.getCurrentUser().then(function (user) {
                        return CRUDService.insert(LISTS.APPROVAL_HISTORY, {
                            PETProjectId:  petId,
                            ApprovalStep:  step,
                            Action:        action,
                            ActionDate:    new Date().toISOString(),
                            Comments:      comments || ''
                        });
                    });
                };
            }
        ]);

}());
