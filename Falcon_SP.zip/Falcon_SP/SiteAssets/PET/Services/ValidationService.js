/**
 * ValidationService.js – Client-side form validation helpers.
 */
(function () {
    'use strict';
    angular.module('PETApp.services')
        .service('ValidationService', [function () {
            var self = this;

            self.isRequired = function (v) { return v !== null && v !== undefined && String(v).trim() !== ''; };
            self.isPositive = function (v) { return !isNaN(v) && parseFloat(v) > 0; };
            self.isEmail    = function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); };
            self.isDate     = function (v) { return v instanceof Date ? !isNaN(v) : !isNaN(Date.parse(v)); };

            self.validatePET = function (pet) {
                var errors = [];
                if (!self.isRequired(pet.ProjectTitle))      errors.push('Project Title is required.');
                if (!self.isRequired(pet.ProjectType))       errors.push('Project Type is required.');
                if (!self.isRequired(pet.BudgetSourceId))    errors.push('Budget Source is required.');
                if (!self.isPositive(pet.RequestedAmountAED))errors.push('Requested Amount must be greater than 0.');
                return errors;
            };

            self.validateLineItem = function (line) {
                var errors = [];
                if (!self.isRequired(line.Description)) errors.push('Description is required.');
                if (!self.isPositive(line.Quantity))    errors.push('Quantity must be > 0.');
                if (!self.isPositive(line.UnitPrice))   errors.push('Unit Price must be > 0.');
                return errors;
            };
        }]);
}());
