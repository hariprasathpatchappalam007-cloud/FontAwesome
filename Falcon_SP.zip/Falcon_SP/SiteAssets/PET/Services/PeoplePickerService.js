/**
 * PeoplePickerService.js
 * Wraps SharePoint People Picker REST API for user search/selection.
 */
(function () {
    'use strict';
    angular.module('PETApp.services')
        .service('PeoplePickerService', ['$q', 'SharePointService', function ($q, SharePointService) {
            var self = this;

            self.search = function (queryText) {
                if (!queryText || queryText.length < 2) return $q.resolve([]);
                return SharePointService.resolveUser(queryText)
                    .then(function (results) {
                        return (results || []).map(function (u) {
                            return {
                                Key:         u.Key,
                                DisplayText: u.DisplayText,
                                Email:       u.EntityData ? u.EntityData.Email : '',
                                Department:  u.EntityData ? u.EntityData.Department : ''
                            };
                        });
                    });
            };

            self.ensureUser = function (loginName) {
                return SharePointService.ensureUser(loginName);
            };
        }]);
}());
