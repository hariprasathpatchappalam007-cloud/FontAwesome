/**
 * ApprovalService.js
 * Business logic for the approval workflow – approve, reject, send back, recall.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('ApprovalService', [
            '$q', 'CRUDService', 'WorkflowService', 'AuthenticationService', 'APP_CONST',
            function ($q, CRUDService, WorkflowService, AuthenticationService, APP_CONST) {

                var self  = this;
                var LISTS = APP_CONST.LISTS;

                /**
                 * Returns the list of PETs pending action for the current user.
                 */
                self.getMyPendingApprovals = function () {
                    return AuthenticationService.getCurrentUser()
                        .then(function (user) {
                            var filter = "(ReviewerId eq " + user.Id +
                                " and PETStatus eq 'Submitted') or " +
                                "(CAPEXApproverId eq " + user.Id +
                                " and PETStatus eq 'CAPEX Approval') or " +
                                "(OPEXApproverId eq " + user.Id +
                                " and PETStatus eq 'OPEX Approval') or " +
                                "(PETApproverId eq " + user.Id +
                                " and PETStatus eq 'PET Approval')";
                            return CRUDService.getByFilter(LISTS.PET_PROJECTS, filter, {
                                select:  'Id,PETRefNo,ProjectTitle,PETStatus,SubmittedDate,Requestor/Title',
                                expand:  'Requestor',
                                orderby: 'SubmittedDate asc'
                            });
                        });
                };

                /**
                 * Returns the full approval history for all PETs.
                 */
                self.getApprovalHistory = function (filter) {
                    return CRUDService.getByFilter(LISTS.APPROVAL_HISTORY, filter || '', {
                        select:  'Id,ApprovalStep,Action,ActionDate,Comments,ActionBy/Title,PETProject/PETRefNo',
                        expand:  'ActionBy,PETProject',
                        orderby: 'ActionDate desc',
                        top:     200
                    });
                };

                /**
                 * Delegate approval action to WorkflowService based on current step.
                 */
                self.processAction = function (petId, stepName, action, comments) {
                    switch (stepName) {
                        case 'Review':          return WorkflowService.review(petId, action, comments);
                        case 'CAPEX Approval':  return WorkflowService.capexApprove(petId, action, comments);
                        case 'OPEX Approval':   return WorkflowService.opexApprove(petId, action, comments);
                        case 'PET Approval':    return WorkflowService.petApprove(petId, action, comments);
                        default: return $q.reject('Unknown workflow step: ' + stepName);
                    }
                };

                /**
                 * Returns pending approval counts grouped by step.
                 */
                self.getPendingCounts = function () {
                    return AuthenticationService.getCurrentUser()
                        .then(function (user) {
                            return $q.all({
                                review: CRUDService.getCount(LISTS.PET_PROJECTS,
                                    "ReviewerId eq " + user.Id + " and PETStatus eq 'Submitted'"),
                                capex:  CRUDService.getCount(LISTS.PET_PROJECTS,
                                    "CAPEXApproverId eq " + user.Id + " and PETStatus eq 'CAPEX Approval'"),
                                opex:   CRUDService.getCount(LISTS.PET_PROJECTS,
                                    "OPEXApproverId eq " + user.Id + " and PETStatus eq 'OPEX Approval'"),
                                pet:    CRUDService.getCount(LISTS.PET_PROJECTS,
                                    "PETApproverId eq " + user.Id + " and PETStatus eq 'PET Approval'")
                            });
                        });
                };
            }
        ]);

}());
