/**
 * SharePointService.js
 * Core service for SharePoint REST API and JSOM interactions.
 * Provides site context, list/library access and request digest management.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('SharePointService', ['$http', '$q', function ($http, $q) {

            var self     = this;
            var _siteUrl = _spPageContextInfo ? _spPageContextInfo.webAbsoluteUrl : window.location.origin;
            var _apiBase = _siteUrl + '/_api/web';

            // ── Site context ─────────────────────────────────────────────────
            self.getSiteUrl = function () { return _siteUrl; };
            self.getApiBase = function () { return _apiBase; };

            /**
             * Get current logged-in SharePoint user.
             * @returns {Promise<{id, title, email, loginName}>}
             */
            self.getCurrentUser = function () {
                return $http.get(_siteUrl + '/_api/web/currentuser?$select=Id,Title,Email,LoginName')
                    .then(function (res) { return res.data.d; });
            };

            /**
             * Get all groups the current user belongs to.
             */
            self.getCurrentUserGroups = function () {
                return $http.get(_siteUrl + '/_api/web/currentuser/groups?$select=Id,Title')
                    .then(function (res) { return res.data.d.results; });
            };

            /**
             * Retrieve site title and URL.
             */
            self.getSiteInfo = function () {
                return $http.get(_apiBase + '?$select=Title,Url')
                    .then(function (res) { return res.data.d; });
            };

            /**
             * Retrieve list metadata by title.
             */
            self.getList = function (listTitle) {
                return $http.get(_apiBase + '/lists/getbytitle(\'' + encodeURIComponent(listTitle) + '\')')
                    .then(function (res) { return res.data.d; });
            };

            /**
             * Retrieve the schema fields of a list.
             */
            self.getListFields = function (listTitle) {
                return $http.get(
                    _apiBase + '/lists/getbytitle(\'' + encodeURIComponent(listTitle) +
                    '\')/fields?$filter=Hidden eq false and ReadOnlyField eq false'
                ).then(function (res) { return res.data.d.results; });
            };

            /**
             * Get the request digest token for write operations.
             * The SPHttpInterceptor in config.js injects this automatically,
             * but this method allows manual use when needed.
             */
            self.getRequestDigest = function () {
                return $http.post(_siteUrl + '/_api/contextinfo', {})
                    .then(function (res) {
                        return res.data.d.GetContextWebInformation.FormDigestValue;
                    });
            };

            /**
             * Resolve a SharePoint user by login name or display name.
             * Used by the PeoplePicker directive.
             */
            self.resolveUser = function (queryText) {
                var endpoint = _siteUrl + '/_api/SP.UI.ApplicationPages.ClientPeoplePickerWebServiceInterface' +
                    '.clientPeoplePickerSearchUser';
                var payload = {
                    queryParams: {
                        __metadata:           { type: 'SP.UI.ApplicationPages.ClientPeoplePickerQueryParameters' },
                        AllowEmailAddresses:  true,
                        AllowMultipleEntities: false,
                        AllUrlZones:          false,
                        MaximumEntitySuggestions: 15,
                        PrincipalSource:      15,
                        PrincipalType:        1,  // Users only
                        QueryString:          queryText
                    }
                };
                return $http.post(endpoint, payload)
                    .then(function (res) {
                        return angular.fromJson(res.data.d.ClientPeoplePickerSearchUser);
                    });
            };

            /**
             * Ensure a user exists in the site's user information list and return their ID.
             */
            self.ensureUser = function (loginName) {
                return $http.post(
                    _apiBase + '/ensureuser',
                    { logonName: loginName }
                ).then(function (res) { return res.data.d; });
            };
        }]);

}());
