/**
 * CSVService.js
 * CSV import and export using PapaParse and SharePoint REST API.
 * Supports PET bulk import with validation and error reporting.
 */
(function () {
    'use strict';

    angular.module('PETApp.services')
        .service('CSVService', ['$q', 'CRUDService', 'ValidationService', 'APP_CONST',
            function ($q, CRUDService, ValidationService, APP_CONST) {

                var self  = this;
                var LISTS = APP_CONST.LISTS;

                // ── PARSE ─────────────────────────────────────────────────────
                /**
                 * Parses a File object using PapaParse. Returns a promise resolving
                 * to { data: [], errors: [], meta: {} }.
                 */
                self.parseFile = function (file) {
                    var deferred = $q.defer();
                    Papa.parse(file, {
                        header:         true,
                        skipEmptyLines: true,
                        dynamicTyping:  false,
                        complete: function (results) { deferred.resolve(results); },
                        error:    function (err)     { deferred.reject(err);      }
                    });
                    return deferred.promise;
                };

                // ── VALIDATE ──────────────────────────────────────────────────
                /**
                 * Validates parsed CSV rows against expected PET import columns.
                 * Returns { valid: [], invalid: [] } where invalid items have an errors[] property.
                 */
                self.validate = function (rows) {
                    var required = ['ProjectTitle', 'ProjectType', 'BudgetSource',
                                    'RequestedAmountAED', 'ReviewerEmail', 'Description'];
                    var valid    = [];
                    var invalid  = [];

                    rows.forEach(function (row, idx) {
                        var errors = [];
                        required.forEach(function (col) {
                            if (!row[col] || String(row[col]).trim() === '') {
                                errors.push('Row ' + (idx + 1) + ': "' + col + '" is required.');
                            }
                        });
                        if (row.RequestedAmountAED && isNaN(parseFloat(row.RequestedAmountAED))) {
                            errors.push('Row ' + (idx + 1) + ': RequestedAmountAED must be a number.');
                        }
                        if (row.ProjectType && ['CAPEX', 'OPEX'].indexOf(row.ProjectType) === -1) {
                            errors.push('Row ' + (idx + 1) + ': ProjectType must be CAPEX or OPEX.');
                        }
                        if (errors.length) {
                            row._errors = errors;
                            invalid.push(row);
                        } else {
                            valid.push(row);
                        }
                    });

                    return { valid: valid, invalid: invalid };
                };

                // ── IMPORT ────────────────────────────────────────────────────
                /**
                 * Imports validated rows into the PET Projects list.
                 * Processes in batches of 10 to avoid throttling.
                 */
                self.importRows = function (rows, onProgress) {
                    var batchSize = 10;
                    var total     = rows.length;
                    var success   = 0;
                    var failed    = 0;
                    var errors    = [];

                    function processBatch(start) {
                        if (start >= total) return $q.resolve({ success: success, failed: failed, errors: errors });

                        var batch    = rows.slice(start, start + batchSize);
                        var promises = batch.map(function (row) {
                            return CRUDService.insert(LISTS.PET_PROJECTS, _mapRowToItem(row))
                                .then(function ()  { success++; })
                                .catch(function (e) {
                                    failed++;
                                    errors.push({ row: row, error: e.data ? e.data.error : e });
                                });
                        });

                        return $q.all(promises).then(function () {
                            if (angular.isFunction(onProgress)) {
                                onProgress(Math.min(start + batchSize, total), total);
                            }
                            return processBatch(start + batchSize);
                        });
                    }

                    return processBatch(0);
                };

                // ── EXPORT ────────────────────────────────────────────────────
                /**
                 * Converts an array of objects to a CSV and triggers a browser download.
                 */
                self.exportToCSV = function (data, fileName) {
                    var csv = Papa.unparse(data);
                    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                    var url  = URL.createObjectURL(blob);
                    var a    = document.createElement('a');
                    a.href       = url;
                    a.download   = (fileName || 'export') + '.csv';
                    a.style.display = 'none';
                    document.body.appendChild(a);
                    a.click();
                    setTimeout(function () {
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                    }, 100);
                };

                // ── PRIVATE ───────────────────────────────────────────────────
                function _mapRowToItem(row) {
                    return {
                        Title:               row.ProjectTitle,
                        ProjectTitle:        row.ProjectTitle,
                        ProjectType:         row.ProjectType,
                        RequestedAmountAED:  parseFloat(row.RequestedAmountAED) || 0,
                        PETStatus:           'Draft',
                        Remarks:             row.Description || ''
                    };
                }
            }
        ]);

}());
