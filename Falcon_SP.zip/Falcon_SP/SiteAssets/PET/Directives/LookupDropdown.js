/**
 * Directives/LookupDropdown.js
 * Generic lookup dropdown directive that loads items from a SharePoint list.
 * Usage: <lookup-dropdown list="'CAPEX Master'" value-field="'Id'" label-field="'CAPEXName'"
 *           ng-model="vm.capexId" label="CAPEX Category" required></lookup-dropdown>
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('lookupDropdown', ['CRUDService',
            function (CRUDService) {
                return {
                    restrict: 'E',
                    require:  'ngModel',
                    scope: {
                        list:       '=',
                        valueField: '=',
                        labelField: '=',
                        filter:     '=',
                        label:      '@',
                        required:   '=',
                        disabled:   '='
                    },
                    template:
                        '<div class="form-group">' +
                        '  <label ng-if="label">{{label}} <span ng-if="required" class="text-danger">*</span></label>' +
                        '  <select class="form-control" ng-model="selectedValue"' +
                        '          ng-options="item[valueField] as item[labelField] for item in items"' +
                        '          ng-change="onChange()" ng-disabled="disabled || loading">' +
                        '    <option value="">-- Select --</option>' +
                        '  </select>' +
                        '  <small class="text-muted" ng-if="loading">Loading...</small>' +
                        '</div>',
                    link: function (scope, elem, attrs, ngModel) {
                        scope.items         = [];
                        scope.selectedValue = null;
                        scope.loading       = false;

                        function load() {
                            if (!scope.list) return;
                            scope.loading = true;
                            var opts = { select: 'Id,' + scope.labelField, orderby: scope.labelField };
                            if (scope.filter) opts.filter = scope.filter;
                            CRUDService.getAll(scope.list, opts)
                                .then(function (items) { scope.items = items; })
                                .finally(function () { scope.loading = false; });
                        }

                        scope.onChange = function () { ngModel.$setViewValue(scope.selectedValue); };

                        ngModel.$render = function () { scope.selectedValue = ngModel.$viewValue; };

                        scope.$watch('list', function (v) { if (v) load(); });
                    }
                };
            }
        ]);
}());
