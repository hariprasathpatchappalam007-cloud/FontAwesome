/**
 * Directives/Modal.js – Reusable Bootstrap modal wrapper.
 * Usage: <pet-modal id="confirmModal" title="Confirm" size="sm" on-confirm="vm.save()">
 *           <p>Are you sure?</p>
 *        </pet-modal>
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('petModal', [function () {
            return {
                restrict:    'E',
                transclude:  true,
                scope: {
                    id:        '@',
                    title:     '@',
                    size:      '@',
                    onConfirm: '&',
                    onCancel:  '&',
                    confirmText: '@',
                    cancelText:  '@'
                },
                template:
                    '<div class="modal fade" id="{{id}}" tabindex="-1" role="dialog" aria-labelledby="{{id}}Label" aria-hidden="true">' +
                    '  <div class="modal-dialog modal-{{size || \'md\'}}" role="document">' +
                    '    <div class="modal-content">' +
                    '      <div class="modal-header">' +
                    '        <h5 class="modal-title" id="{{id}}Label">{{title}}</h5>' +
                    '        <button type="button" class="close" data-dismiss="modal">' +
                    '          <span aria-hidden="true">&times;</span></button>' +
                    '      </div>' +
                    '      <div class="modal-body" ng-transclude></div>' +
                    '      <div class="modal-footer">' +
                    '        <button type="button" class="btn btn-secondary" data-dismiss="modal" ng-click="onCancel()">' +
                    '          {{cancelText || "Cancel"}}</button>' +
                    '        <button type="button" class="btn btn-primary" ng-click="onConfirm()">' +
                    '          {{confirmText || "Confirm"}}</button>' +
                    '      </div>' +
                    '    </div>' +
                    '  </div>' +
                    '</div>'
            };
        }]);
}());
