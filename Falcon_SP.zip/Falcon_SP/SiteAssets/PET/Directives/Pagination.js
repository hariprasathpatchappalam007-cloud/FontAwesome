/**
 * Directives/Pagination.js
 * Reusable pagination bar directive.
 * Usage: <pet-pagination total="vm.totalItems" page="vm.page" page-size="vm.pageSize"
 *           on-page-change="vm.loadPage(page)"></pet-pagination>
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('petPagination', [function () {
            return {
                restrict: 'E',
                scope: {
                    total:        '=',
                    page:         '=',
                    pageSize:     '=',
                    onPageChange: '&'
                },
                template:
                    '<nav aria-label="Page navigation" ng-if="totalPages > 1">' +
                    '  <ul class="pagination pagination-sm mb-0">' +
                    '    <li class="page-item" ng-class="{disabled: page <= 1}">' +
                    '      <a class="page-link" href="" ng-click="goTo(1)">&laquo;</a></li>' +
                    '    <li class="page-item" ng-class="{disabled: page <= 1}">' +
                    '      <a class="page-link" href="" ng-click="goTo(page - 1)">&lsaquo;</a></li>' +
                    '    <li class="page-item" ng-repeat="p in pages" ng-class="{active: p === page}">' +
                    '      <a class="page-link" href="" ng-click="goTo(p)">{{p}}</a></li>' +
                    '    <li class="page-item" ng-class="{disabled: page >= totalPages}">' +
                    '      <a class="page-link" href="" ng-click="goTo(page + 1)">&rsaquo;</a></li>' +
                    '    <li class="page-item" ng-class="{disabled: page >= totalPages}">' +
                    '      <a class="page-link" href="" ng-click="goTo(totalPages)">&raquo;</a></li>' +
                    '  </ul>' +
                    '  <small class="text-muted ml-2">Page {{page}} of {{totalPages}} ({{total}} items)</small>' +
                    '</nav>',
                link: function (scope) {
                    scope.$watchGroup(['total', 'pageSize', 'page'], function () {
                        scope.totalPages = Math.ceil((scope.total || 0) / (scope.pageSize || 15));
                        var start = Math.max(1, scope.page - 2);
                        var end   = Math.min(scope.totalPages, start + 4);
                        scope.pages = [];
                        for (var i = start; i <= end; i++) scope.pages.push(i);
                    });

                    scope.goTo = function (p) {
                        if (p < 1 || p > scope.totalPages || p === scope.page) return;
                        scope.page = p;
                        scope.onPageChange({ page: p });
                    };
                }
            };
        }]);
}());
