/**
 * Directives/DatePicker.js – Bootstrap-compatible date input wrapper.
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('petDatePicker', ['APP_CONST', function (APP_CONST) {
            return {
                restrict: 'E',
                require:  'ngModel',
                scope:    { label: '@', required: '=', disabled: '=', minDate: '=', maxDate: '=' },
                template:
                    '<div class="form-group">' +
                    '  <label ng-if="label">{{label}} <span ng-if="required" class="text-danger">*</span></label>' +
                    '  <input type="date" class="form-control" ng-model="value" ng-change="onChange()"' +
                    '         ng-disabled="disabled" ng-required="required"' +
                    '         min="{{minDate}}" max="{{maxDate}}" />' +
                    '</div>',
                link: function (scope, elem, attrs, ngModel) {
                    scope.value = '';
                    scope.onChange = function () { ngModel.$setViewValue(scope.value); };
                    ngModel.$render = function () {
                        var v = ngModel.$viewValue;
                        if (v) {
                            // Convert ISO to YYYY-MM-DD for input[type=date]
                            scope.value = v.substring(0, 10);
                        }
                    };
                }
            };
        }]);
}());
