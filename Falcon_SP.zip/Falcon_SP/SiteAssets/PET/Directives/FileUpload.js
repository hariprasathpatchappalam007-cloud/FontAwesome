/**
 * Directives/FileUpload.js
 * Attachment upload directive with progress feedback.
 * Usage: <file-upload on-upload="vm.handleFile($file)" accept=".pdf,.docx,.xlsx" label="Attach Document">
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('fileUpload', ['AttachmentService', '$rootScope',
            function (AttachmentService, $rootScope) {
                return {
                    restrict: 'E',
                    scope: {
                        onUpload:  '&',
                        library:   '=',
                        folderId:  '=',
                        accept:    '@',
                        label:     '@',
                        multiple:  '=',
                        maxSizeMb: '='
                    },
                    template:
                        '<div class="file-upload-container">' +
                        '  <label class="btn btn-outline-primary btn-sm" for="fileInput_{{$id}}">' +
                        '    <i class="fa fa-upload"></i> {{label || "Upload File"}}' +
                        '  </label>' +
                        '  <input type="file" id="fileInput_{{$id}}" class="d-none"' +
                        '         accept="{{accept}}" ng-multiple="multiple"' +
                        '         onchange="angular.element(this).scope().onFileChange(this.files)" />' +
                        '  <div class="mt-2" ng-if="uploading">' +
                        '    <div class="progress">' +
                        '      <div class="progress-bar progress-bar-striped progress-bar-animated"' +
                        '           style="width: {{progress}}%">{{progress}}%</div>' +
                        '    </div>' +
                        '  </div>' +
                        '  <div class="text-danger mt-1" ng-if="error">{{error}}</div>' +
                        '</div>',
                    link: function (scope) {
                        scope.uploading = false;
                        scope.progress  = 0;
                        scope.error     = null;
                        var maxMB       = scope.maxSizeMb || 50;

                        scope.onFileChange = function (files) {
                            if (!files || !files.length) return;
                            scope.$apply(function () {
                                scope.error = null;
                                var file = files[0];
                                if (file.size > maxMB * 1024 * 1024) {
                                    scope.error = 'File exceeds ' + maxMB + ' MB limit.';
                                    return;
                                }
                                scope.uploading = true;
                                scope.progress  = 10;
                                var lib     = scope.library    || 'PET Attachments';
                                var folder  = scope.folderId   ? lib + '/' + scope.folderId : lib;

                                AttachmentService.ensureFolder(lib, scope.folderId || '')
                                    .then(function () {
                                        scope.progress = 40;
                                        return AttachmentService.upload(file, lib,
                                            '/' + folder, { Title: file.name });
                                    })
                                    .then(function (uploaded) {
                                        scope.progress  = 100;
                                        scope.uploading = false;
                                        scope.onUpload({ $file: uploaded });
                                    })
                                    .catch(function (e) {
                                        scope.uploading = false;
                                        scope.error = 'Upload failed: ' + (e.data ? e.data.error.message : e);
                                    });
                            });
                        };
                    }
                };
            }
        ]);
}());
