/**
 * Directives/ConfirmationDialog.js
 * Inline confirmation popup directive.
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('petConfirm', ['NotificationService', function (NotificationService) {
            return {
                restrict: 'A',
                scope: {
                    petConfirmMessage: '@',
                    petConfirmTitle:   '@',
                    petConfirmAction:  '&'
                },
                link: function (scope, elem) {
                    elem.on('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        NotificationService.confirm(
                            scope.petConfirmTitle   || 'Confirm',
                            scope.petConfirmMessage || 'Are you sure?'
                        ).then(function (confirmed) {
                            if (confirmed) scope.$apply(function () { scope.petConfirmAction(); });
                        });
                    });
                }
            };
        }]);
}());
