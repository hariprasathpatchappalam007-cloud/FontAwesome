/**
 * Directives/AutoComplete.js – Generic auto-complete text field.
 * Usage: <auto-complete ng-model="vm.project" source="vm.searchProjects" label="Project" display-field="ProjectName">
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('autoComplete', ['$timeout', function ($timeout) {
            return {
                restrict: 'E',
                require:  'ngModel',
                scope: {
                    source:       '=',   // Function returning a promise
                    displayField: '@',
                    label:        '@',
                    placeholder:  '@',
                    required:     '=',
                    disabled:     '='
                },
                template:
                    '<div class="form-group autocomplete-wrapper">' +
                    '  <label ng-if="label">{{label}} <span ng-if="required" class="text-danger">*</span></label>' +
                    '  <input type="text" class="form-control" ng-model="inputText"' +
                    '         placeholder="{{placeholder}}" ng-change="onInput()"' +
                    '         ng-disabled="disabled" autocomplete="off" />' +
                    '  <ul class="autocomplete-results list-group" ng-if="results.length">' +
                    '    <li class="list-group-item list-group-item-action" ng-repeat="r in results"' +
                    '        ng-click="pick(r)">{{r[displayField] || r}}</li>' +
                    '  </ul>' +
                    '</div>',
                link: function (scope, elem, attrs, ngModel) {
                    scope.results   = [];
                    scope.inputText = '';
                    var _t          = null;

                    scope.onInput = function () {
                        if (_t) $timeout.cancel(_t);
                        _t = $timeout(function () {
                            if (!scope.inputText || scope.inputText.length < 2) {
                                scope.results = [];
                                return;
                            }
                            scope.source(scope.inputText).then(function (r) { scope.results = r || []; });
                        }, 300);
                    };

                    scope.pick = function (item) {
                        scope.inputText = item[scope.displayField] || item;
                        scope.results   = [];
                        ngModel.$setViewValue(item);
                    };

                    ngModel.$render = function () {
                        var v = ngModel.$viewValue;
                        scope.inputText = v ? (v[scope.displayField] || v) : '';
                    };
                }
            };
        }]);
}());
