/**
 * Directives/Grid.js
 * Reusable sortable data grid directive.
 * Usage: <pet-grid columns="vm.cols" rows="vm.rows" on-row-click="vm.openRow(row)"></pet-grid>
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('petGrid', [function () {
            return {
                restrict: 'E',
                scope: {
                    columns:    '=',
                    rows:       '=',
                    loading:    '=',
                    emptyText:  '@',
                    onRowClick: '&'
                },
                template:
                    '<div class="pet-grid-wrapper">' +
                    '  <pet-loader show="loading"></pet-loader>' +
                    '  <div class="table-responsive" ng-if="!loading">' +
                    '    <table class="table table-hover table-bordered table-sm">' +
                    '      <thead class="thead-dark">' +
                    '        <tr>' +
                    '          <th ng-repeat="col in columns" ng-click="sort(col)"' +
                    '              class="cursor-pointer" ng-class="{\'text-right\': col.align === \'right\'}">' +
                    '            {{col.header}}' +
                    '            <i ng-if="sortCol === col.field"' +
                    '               class="fa" ng-class="{\'fa-sort-up\': !sortReverse, \'fa-sort-down\': sortReverse}"></i>' +
                    '          </th>' +
                    '        </tr>' +
                    '      </thead>' +
                    '      <tbody>' +
                    '        <tr ng-repeat="row in rows | orderBy:sortCol:sortReverse"' +
                    '            ng-click="rowClick(row)" class="cursor-pointer">' +
                    '          <td ng-repeat="col in columns"' +
                    '              ng-class="{\'text-right\': col.align === \'right\'}"' +
                    '              ng-bind-html="renderCell(col, row)"></td>' +
                    '        </tr>' +
                    '        <tr ng-if="!rows || rows.length === 0">' +
                    '          <td colspan="{{columns.length}}" class="text-center text-muted py-4">' +
                    '            {{emptyText || "No records found."}}</td>' +
                    '        </tr>' +
                    '      </tbody>' +
                    '    </table>' +
                    '  </div>' +
                    '</div>',
                link: function (scope) {
                    scope.sortCol     = null;
                    scope.sortReverse = false;

                    scope.sort = function (col) {
                        if (!col.field) return;
                        if (scope.sortCol === col.field) {
                            scope.sortReverse = !scope.sortReverse;
                        } else {
                            scope.sortCol     = col.field;
                            scope.sortReverse = false;
                        }
                    };

                    scope.rowClick = function (row) { scope.onRowClick({ row: row }); };

                    scope.renderCell = function (col, row) {
                        var val = row[col.field];
                        if (col.template) return col.template(val, row);
                        return val !== null && val !== undefined ? String(val) : '';
                    };
                }
            };
        }]);
}());
