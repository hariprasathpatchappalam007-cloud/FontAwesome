/**
 * Directives/Notification.js – Toast notification bar.
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('petNotification', ['NotificationService', function (NotificationService) {
            return {
                restrict:    'E',
                templateUrl: 'Templates/Partials/Notification.html',
                link: function (scope) {
                    scope.dismiss = function () { NotificationService.dismiss(); };
                }
            };
        }]);
}());
