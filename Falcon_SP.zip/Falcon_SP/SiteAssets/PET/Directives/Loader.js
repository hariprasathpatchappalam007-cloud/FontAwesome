/**
 * Directives/Loader.js – Global loading overlay directive.
 * Usage: <pet-loader show="vm.loading"></pet-loader>
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('petLoader', [function () {
            return {
                restrict: 'E',
                scope:    { show: '=' },
                template:
                    '<div class="pet-loader-overlay" ng-if="show">' +
                    '  <div class="pet-loader-spinner">' +
                    '    <div class="spinner-border text-primary" role="status">' +
                    '      <span class="sr-only">Loading...</span>' +
                    '    </div>' +
                    '    <p class="mt-2 text-muted">Please wait...</p>' +
                    '  </div>' +
                    '</div>'
            };
        }]);
}());
