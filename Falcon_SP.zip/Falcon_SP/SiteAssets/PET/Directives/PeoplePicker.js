/**
 * Directives/PeoplePicker.js
 * Reusable SharePoint People Picker directive with auto-complete.
 * Usage: <people-picker ng-model="vm.reviewer" label="Reviewer" required></people-picker>
 */
(function () {
    'use strict';
    angular.module('PETApp.directives')
        .directive('peoplePicker', ['PeoplePickerService', '$timeout',
            function (PeoplePickerService, $timeout) {
                return {
                    restrict:   'E',
                    require:    'ngModel',
                    scope: {
                        label:       '@',
                        placeholder: '@',
                        required:    '=',
                        disabled:    '='
                    },
                    template:
                        '<div class="form-group people-picker">' +
                        '  <label ng-if="label">{{label}} <span ng-if="required" class="text-danger">*</span></label>' +
                        '  <div class="input-group">' +
                        '    <input type="text" class="form-control" ng-model="displayText"' +
                        '           placeholder="{{placeholder || \'Search for a person...\'}}"' +
                        '           ng-change="onSearch()" ng-disabled="disabled" autocomplete="off" />' +
                        '    <div class="input-group-append">' +
                        '      <button class="btn btn-outline-secondary" ng-click="clear()" ng-if="selected" type="button">' +
                        '        <span>&times;</span>' +
                        '      </button>' +
                        '    </div>' +
                        '  </div>' +
                        '  <ul class="dropdown-menu people-picker-results" ng-if="results.length > 0">' +
                        '    <li class="dropdown-item" ng-repeat="r in results" ng-click="select(r)">' +
                        '      <strong>{{r.DisplayText}}</strong>' +
                        '      <small class="text-muted d-block">{{r.Email}}</small>' +
                        '    </li>' +
                        '  </ul>' +
                        '  <div class="people-picker-selected text-success mt-1" ng-if="selected">' +
                        '    <i class="fa fa-check-circle"></i> {{selected.DisplayText}}' +
                        '  </div>' +
                        '</div>',
                    link: function (scope, elem, attrs, ngModel) {
                        scope.results     = [];
                        scope.selected    = null;
                        scope.displayText = '';
                        var _timer        = null;

                        scope.onSearch = function () {
                            if (_timer) $timeout.cancel(_timer);
                            if (!scope.displayText || scope.displayText.length < 2) {
                                scope.results = [];
                                return;
                            }
                            _timer = $timeout(function () {
                                PeoplePickerService.search(scope.displayText)
                                    .then(function (r) { scope.results = r || []; });
                            }, 300);
                        };

                        scope.select = function (user) {
                            scope.selected    = user;
                            scope.displayText = user.DisplayText;
                            scope.results     = [];
                            ngModel.$setViewValue(user);
                        };

                        scope.clear = function () {
                            scope.selected    = null;
                            scope.displayText = '';
                            ngModel.$setViewValue(null);
                        };

                        // Render if model is pre-populated
                        ngModel.$render = function () {
                            var val = ngModel.$viewValue;
                            if (val) {
                                scope.selected    = val;
                                scope.displayText = val.DisplayText || val.Title || '';
                            }
                        };
                    }
                };
            }
        ]);
}());
