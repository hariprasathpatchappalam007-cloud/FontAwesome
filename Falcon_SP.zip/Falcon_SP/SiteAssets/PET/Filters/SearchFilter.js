/**
 * Filters/SearchFilter.js – Generic client-side search filter across object fields.
 */
(function () {
    'use strict';
    angular.module('PETApp.filters')
        .filter('petSearch', [function () {
            return function (items, searchText, fields) {
                if (!searchText || !items) return items;
                var lower = searchText.toLowerCase();
                return items.filter(function (item) {
                    if (!fields || !fields.length) {
                        return JSON.stringify(item).toLowerCase().indexOf(lower) !== -1;
                    }
                    return fields.some(function (f) {
                        var val = item[f];
                        return val && String(val).toLowerCase().indexOf(lower) !== -1;
                    });
                });
            };
        }]);
}());
