/**
 * Filters/DateFilter.js – Formats ISO date strings for display.
 */
(function () {
    'use strict';
    angular.module('PETApp.filters')
        .filter('petDate', ['UtilityService', function (UtilityService) {
            return function (input) { return UtilityService.formatDate(input); };
        }])
        .filter('petDateTime', [function () {
            return function (input) {
                if (!input) return '';
                var d = new Date(input);
                if (isNaN(d)) return '';
                return ('0' + d.getDate()).slice(-2) + '/' +
                       ('0' + (d.getMonth() + 1)).slice(-2) + '/' +
                       d.getFullYear() + ' ' +
                       ('0' + d.getHours()).slice(-2) + ':' +
                       ('0' + d.getMinutes()).slice(-2);
            };
        }]);
}());
