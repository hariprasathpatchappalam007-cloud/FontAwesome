/**
 * Filters/CurrencyFilter.js – Formats numbers as AED currency.
 */
(function () {
    'use strict';
    angular.module('PETApp.filters')
        .filter('aed', ['UtilityService', function (UtilityService) {
            return function (value) { return UtilityService.formatAED(value); };
        }]);
}());
