/**
 * Filters/StatusFilter.js – Maps PET status to Bootstrap badge class.
 */
(function () {
    'use strict';
    angular.module('PETApp.filters')
        .filter('statusBadge', ['CommonFactory', function (CommonFactory) {
            return function (status) { return CommonFactory.getStatusBadge(status); };
        }]);
}());
