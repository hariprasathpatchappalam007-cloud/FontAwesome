using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Falcon_SP.JiraSync")]
[assembly: AssemblyDescription("Synchronises JIRA issues into the SharePoint Project Details list")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Falcon")]
[assembly: AssemblyProduct("Falcon PET")]
[assembly: AssemblyCopyright("Copyright © 2024")]
[assembly: ComVisible(false)]
[assembly: Guid("c3d4e5f6-a7b8-9012-cdef-123456789012")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
