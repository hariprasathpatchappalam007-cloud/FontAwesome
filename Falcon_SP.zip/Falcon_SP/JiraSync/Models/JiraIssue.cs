using System;

namespace Falcon_SP.JiraSync.Models
{
    /// <summary>
    /// Flat representation of a JIRA issue mapped to the SharePoint
    /// "Project Details" list columns. All custom field IDs resolved from
    /// the original DFM_BPM.JiraSync field mapping.
    /// C# 5 / .NET 4.5 compatible (no auto-property initializers).
    /// </summary>
    public class JiraIssue
    {
        // Identity
        public string   JiraKey             { get; set; }
        public string   ProjectKey          { get; set; }
        public string   Summary             { get; set; }  // → SharePoint Title field
        public string   JiraStatus          { get; set; }
        public string   Priority            { get; set; }
        public string   IssueType           { get; set; }
        public string   ProjectName         { get; set; }
        public string   ParentJiraKey       { get; set; }

        // Platform (customfield_12609 / 12604 / 11610 / 13380)
        public string   Platform            { get; set; }
        public string   PlatformVertical    { get; set; }
        public string   PlatformName        { get; set; }
        public string   SecondaryPlatform   { get; set; }

        // RAG (customfield_13419 / 13511 / 13510 / 13505 / 13509)
        public string   ActivityRagStatus   { get; set; }
        public string   ScheduleRag         { get; set; }
        public string   BudgetRag           { get; set; }
        public string   RaidRag             { get; set; }
        public string   OverallProjectRag   { get; set; }
        public string   ProjectRAG          { get; set; }  // computed from TargetCompletionDate

        // People
        public string   ChiefNameMapping    { get; set; }  // customfield_14001
        public string   Manager             { get; set; }  // = AssignedProjectMgr
        public string   TechLead            { get; set; }  // = SmeLead
        public string   AccountableExecLead { get; set; }  // customfield_13357
        public string   SmeLead             { get; set; }  // customfield_13358
        public string   AccountableExec     { get; set; }  // customfield_13379
        public string   Assignee            { get; set; }
        public string   Reporter            { get; set; }
        public string   AssignedProjectMgr  { get; set; }  // customfield_12603
        public string   IdhPortfolioHead    { get; set; }  // customfield_13376
        public string   DemandOwner         { get; set; }  // customfield_13317
        public string   EmployeeEmail       { get; set; }  // assignee.emailAddress

        // Classification / Department
        public string   DemandType          { get; set; }  // customfield_13339
        public string   PrimaryClassification { get; set; } // customfield_13307
        public string   Classification      { get; set; }
        public string   Department          { get; set; }  // customfield_13308
        public string   ProjectPerformingDept { get; set; } // customfield_10911
        public string   ProjectSponsorDept  { get; set; }  // customfield_10916
        public string   DemandDepartment    { get; set; }  // customfield_13310
        public string   RequesterDept       { get; set; }  // customfield_10909
        public string   ProjectDept         { get; set; }  // customfield_13101
        public string   DemandSegment       { get; set; }  // customfield_13600
        public string   DemandTitle         { get; set; }  // customfield_13304
        public string   RegulatoryObservation { get; set; } // customfield_13314

        // Dates
        public DateTime? JiraCreated         { get; set; }
        public DateTime? JiraUpdated         { get; set; }
        public DateTime? TargetCompletionDate { get; set; } // customfield_13306
        public DateTime? ProposedDemandPickup { get; set; } // customfield_13359
        public DateTime? ActualGoLiveDate    { get; set; }  // customfield_10964
        public DateTime? PB0EndDate          { get; set; }  // customfield_13375
        public DateTime? PB0StartDate        { get; set; }  // customfield_13374
        public DateTime? PB0SubmitDate       { get; set; }  // customfield_13362
        public DateTime? BaselineStartDate   { get; set; }  // customfield_10605
        public DateTime? BaselineEndDate     { get; set; }  // customfield_10606
        public DateTime? BL1ActualStart      { get; set; }  // customfield_14125
        public DateTime? BL0PlannedStart     { get; set; }  // customfield_14131
        public DateTime? BL0PlannedEnd       { get; set; }  // customfield_14132
        public DateTime? BL0ActualEnd        { get; set; }  // customfield_14130
        public DateTime? BL1ActualGoLive     { get; set; }  // customfield_14128
        public DateTime? BL0ActualStart      { get; set; }  // customfield_14129
        public DateTime? BL1ActualEnd        { get; set; }  // customfield_14126

        // Status flags
        public string   RolloutStatus        { get; set; }  // customfield_10966
        public string   EpicStatus           { get; set; }  // customfield_10102
        public string   BrdStatus            { get; set; }  // customfield_13818
        public string   ScriptStatus         { get; set; }  // customfield_11627
        public string   StatusGrey           { get; set; }  // customfield_13405
        public string   StatusReason         { get; set; }  // customfield_13406
        public string   InitiativeStatus     { get; set; }  // customfield_11208
        public string   ProjectOverallStatus { get; set; }  // customfield_13513
        public string   CbtpBrdStatus        { get; set; }  // customfield_13007
        public string   FsdStatus            { get; set; }  // customfield_13006
    }
}
