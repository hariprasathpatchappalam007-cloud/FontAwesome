using System;
using System.Collections.Generic;
using Falcon_SP.JiraSync.Helpers;
using Falcon_SP.JiraSync.Models;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.JiraSync.Sync
{
    /// <summary>
    /// Writes (upserts) JiraIssue objects into the SharePoint "Project Details" list
    /// using CSOM. Idempotent: matches on JiraKey, updates if found, inserts if new.
    ///
    /// SharePoint column names match the Provisioner's InternalName values.
    /// C# 5 / .NET 4.5 compatible.
    /// </summary>
    public class ProjectDetailsSync
    {
        private readonly ClientContext _ctx;
        private readonly string        _listName;
        private readonly int           _writeBatchSize;

        private int _inserted;
        private int _updated;
        private int _failed;

        public int Inserted { get { return _inserted; } }
        public int Updated  { get { return _updated;  } }
        public int Failed   { get { return _failed;   } }

        public ProjectDetailsSync(ClientContext ctx, string listName, int writeBatchSize)
        {
            if (ctx      == null) throw new ArgumentNullException("ctx");
            if (listName == null) throw new ArgumentNullException("listName");
            _ctx           = ctx;
            _listName      = listName;
            _writeBatchSize = writeBatchSize > 0 ? writeBatchSize : 50;
        }

        /// <summary>
        /// Upserts a collection of JIRA issues into the SP list.
        /// Issues are matched by the JiraKey column.
        /// </summary>
        public void Sync(IList<JiraIssue> issues)
        {
            SyncLogger.Info("Syncing " + issues.Count + " issues to '" + _listName + "'...");

            // Load all existing JiraKey values in one call for efficient lookup
            var existingIds = LoadExistingKeys();

            int count = 0;
            foreach (JiraIssue issue in issues)
            {
                count++;
                try
                {
                    if (existingIds.ContainsKey(issue.JiraKey))
                        UpdateItem(existingIds[issue.JiraKey], issue);
                    else
                        InsertItem(issue);
                }
                catch (Exception ex)
                {
                    _failed++;
                    SyncLogger.Error("  Error syncing " + issue.JiraKey + ": " + ex.Message);
                }

                // Batch execute
                if (count % _writeBatchSize == 0)
                {
                    try
                    {
                        _ctx.ExecuteQuery();
                        SyncLogger.Info("  Batch committed (" + count + "/" + issues.Count + ")");
                    }
                    catch (Exception ex)
                    {
                        SyncLogger.Error("  Batch ExecuteQuery failed: " + ex.Message);
                    }
                }
            }

            // Final batch
            try { _ctx.ExecuteQuery(); }
            catch (Exception ex) { SyncLogger.Error("  Final batch ExecuteQuery failed: " + ex.Message); }

            SyncLogger.Success("Sync complete. Inserted=" + _inserted + " Updated=" + _updated + " Failed=" + _failed);
        }

        // ---- Private helpers -----------------------------------------------

        /// <summary>Loads a dictionary of JiraKey → SP ListItem.Id for all existing items.</summary>
        private Dictionary<string, int> LoadExistingKeys()
        {
            var result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            var list = _ctx.Web.Lists.GetByTitle(_listName);
            var query = new CamlQuery();
            query.ViewXml = "<View><ViewFields><FieldRef Name='ID'/><FieldRef Name='JiraKey'/></ViewFields><RowLimit>5000</RowLimit></View>";

            ListItemCollection items = list.GetItems(query);
            _ctx.Load(items, ii => ii.Include(i => i.Id, i => i["JiraKey"]));
            _ctx.ExecuteQuery();

            foreach (ListItem item in items)
            {
                string key = item["JiraKey"] != null ? Convert.ToString(item["JiraKey"]) : null;
                if (!string.IsNullOrEmpty(key) && !result.ContainsKey(key))
                    result.Add(key, item.Id);
            }

            SyncLogger.Info("Loaded " + result.Count + " existing keys from '" + _listName + "'");
            return result;
        }

        private void InsertItem(JiraIssue ji)
        {
            var list = _ctx.Web.Lists.GetByTitle(_listName);
            var itemInfo = new ListItemCreationInformation();
            ListItem item = list.AddItem(itemInfo);

            SetFields(item, ji);
            item["LastSyncDate"] = DateTime.UtcNow;
            item["SyncStatus"]   = "Success";
            item.Update();

            _inserted++;
        }

        private void UpdateItem(int spId, JiraIssue ji)
        {
            var list = _ctx.Web.Lists.GetByTitle(_listName);
            ListItem item = list.GetItemById(spId);

            SetFields(item, ji);
            item["LastSyncDate"] = DateTime.UtcNow;
            item["SyncStatus"]   = "Success";
            item.Update();

            _updated++;
        }

        private static void SetFields(ListItem item, JiraIssue ji)
        {
            // Title = display name / summary
            item["Title"]               = Clip(ji.Summary ?? ji.JiraKey, 255);
            item["JiraKey"]             = Clip(ji.JiraKey,              50);
            item["JiraStatus"]          = Clip(ji.JiraStatus,           100);
            item["JiraPriority"]        = Clip(ji.Priority,             50);
            item["IssueType"]           = Clip(ji.IssueType,            100);
            item["ProjectKey"]          = Clip(ji.ProjectKey,           20);
            item["ProjectName"]         = Clip(ji.ProjectName,          300);
            item["ParentJiraKey"]       = Clip(ji.ParentJiraKey,        50);

            // Platform
            item["Platform"]            = Clip(ji.Platform,             200);
            item["PlatformVertical"]    = Clip(ji.PlatformVertical,     200);
            item["PlatformName"]        = Clip(ji.PlatformName,         200);
            item["SecondaryPlatform"]   = Clip(ji.SecondaryPlatform,    200);

            // RAG
            item["ActivityRagStatus"]   = Clip(ji.ActivityRagStatus,    50);
            item["ScheduleRag"]         = Clip(ji.ScheduleRag,          50);
            item["BudgetRag"]           = Clip(ji.BudgetRag,            50);
            item["RaidRag"]             = Clip(ji.RaidRag,              50);
            item["OverallProjectRag"]   = Clip(ji.OverallProjectRag,    50);
            item["ProjectRAG"]          = Clip(ji.ProjectRAG,           50);

            // People
            item["ChiefNameMapping"]    = Clip(ji.ChiefNameMapping,     200);
            item["Manager"]             = Clip(ji.Manager,              200);
            item["TechLead"]            = Clip(ji.TechLead,             200);
            item["AccountableExecLead"] = Clip(ji.AccountableExecLead,  200);
            item["SmeLead"]             = Clip(ji.SmeLead,              200);
            item["AccountableExec"]     = Clip(ji.AccountableExec,      200);
            item["Assignee"]            = Clip(ji.Assignee,             200);
            item["Reporter"]            = Clip(ji.Reporter,             200);
            item["AssignedProjectMgr"]  = Clip(ji.AssignedProjectMgr,   200);
            item["IdhPortfolioHead"]    = Clip(ji.IdhPortfolioHead,     200);
            item["DemandOwner"]         = Clip(ji.DemandOwner,          200);
            item["EmployeeEmail"]       = Clip(ji.EmployeeEmail,        200);

            // Classification
            item["DemandType"]              = Clip(ji.DemandType,             100);
            item["PrimaryClassification"]   = Clip(ji.PrimaryClassification,  200);
            item["Classification"]          = Clip(ji.Classification,          200);
            item["Department"]              = Clip(ji.Department,              200);
            item["ProjectPerformingDept"]   = Clip(ji.ProjectPerformingDept,   200);
            item["ProjectSponsorDept"]      = Clip(ji.ProjectSponsorDept,      200);
            item["DemandDepartment"]        = Clip(ji.DemandDepartment,        200);
            item["RequesterDept"]           = Clip(ji.RequesterDept,           200);
            item["ProjectDept"]             = Clip(ji.ProjectDept,             200);
            item["DemandSegment"]           = Clip(ji.DemandSegment,           200);
            item["DemandTitle"]             = Clip(ji.DemandTitle,             500);
            item["RegulatoryObservation"]   = ji.RegulatoryObservation;  // Note field – no max length

            // Dates
            item["JiraCreated"]         = ji.JiraCreated.HasValue         ? (object)ji.JiraCreated.Value         : null;
            item["JiraUpdated"]         = ji.JiraUpdated.HasValue         ? (object)ji.JiraUpdated.Value         : null;
            item["TargetCompletionDate"] = ji.TargetCompletionDate.HasValue ? (object)ji.TargetCompletionDate.Value : null;
            item["ProposedDemandPickup"] = ji.ProposedDemandPickup.HasValue ? (object)ji.ProposedDemandPickup.Value : null;
            item["ActualGoLiveDate"]    = ji.ActualGoLiveDate.HasValue    ? (object)ji.ActualGoLiveDate.Value    : null;
            item["PB0EndDate"]          = ji.PB0EndDate.HasValue          ? (object)ji.PB0EndDate.Value          : null;
            item["PB0StartDate"]        = ji.PB0StartDate.HasValue        ? (object)ji.PB0StartDate.Value        : null;
            item["PB0SubmitDate"]       = ji.PB0SubmitDate.HasValue       ? (object)ji.PB0SubmitDate.Value       : null;
            item["BaselineStartDate"]   = ji.BaselineStartDate.HasValue   ? (object)ji.BaselineStartDate.Value   : null;
            item["BaselineEndDate"]     = ji.BaselineEndDate.HasValue     ? (object)ji.BaselineEndDate.Value     : null;
            item["BL1ActualStart"]      = ji.BL1ActualStart.HasValue      ? (object)ji.BL1ActualStart.Value      : null;
            item["BL0PlannedStart"]     = ji.BL0PlannedStart.HasValue     ? (object)ji.BL0PlannedStart.Value     : null;
            item["BL0PlannedEnd"]       = ji.BL0PlannedEnd.HasValue       ? (object)ji.BL0PlannedEnd.Value       : null;
            item["BL0ActualEnd"]        = ji.BL0ActualEnd.HasValue        ? (object)ji.BL0ActualEnd.Value        : null;
            item["BL1ActualGoLive"]     = ji.BL1ActualGoLive.HasValue     ? (object)ji.BL1ActualGoLive.Value     : null;
            item["BL0ActualStart"]      = ji.BL0ActualStart.HasValue      ? (object)ji.BL0ActualStart.Value      : null;
            item["BL1ActualEnd"]        = ji.BL1ActualEnd.HasValue        ? (object)ji.BL1ActualEnd.Value        : null;

            // Status flags
            item["RolloutStatus"]        = Clip(ji.RolloutStatus,        100);
            item["EpicStatus"]           = Clip(ji.EpicStatus,           100);
            item["BrdStatus"]            = Clip(ji.BrdStatus,            100);
            item["ScriptStatus"]         = Clip(ji.ScriptStatus,         100);
            item["StatusGrey"]           = Clip(ji.StatusGrey,           100);
            item["StatusReason"]         = Clip(ji.StatusReason,         200);
            item["InitiativeStatus"]     = Clip(ji.InitiativeStatus,     100);
            item["ProjectOverallStatus"] = Clip(ji.ProjectOverallStatus, 100);
            item["CbtpBrdStatus"]        = Clip(ji.CbtpBrdStatus,        100);
            item["FsdStatus"]            = Clip(ji.FsdStatus,            100);

            item["IsActive"] = true;
        }

        /// <summary>Clips a string to the given max length (returns null when input is null).</summary>
        private static string Clip(string s, int max)
        {
            if (s == null) return null;
            return s.Length > max ? s.Substring(0, max) : s;
        }
    }
}
