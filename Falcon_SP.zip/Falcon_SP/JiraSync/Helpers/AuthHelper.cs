using System;
using System.Net;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.JiraSync.Helpers
{
    /// <summary>
    /// Returns an authenticated ClientContext for SharePoint Server Subscription Edition.
    /// </summary>
    public static class AuthHelper
    {
        public static ClientContext GetContext(
            string siteUrl,
            string username,
            string password,
            string domain)
        {
            if (string.IsNullOrEmpty(siteUrl))
                throw new ArgumentNullException("siteUrl");

            var ctx = new ClientContext(siteUrl);
            bool hasUser = !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password);

            if (hasUser && !string.IsNullOrEmpty(domain))
            {
                SyncLogger.Info("SP Auth: NTLM (" + domain + "\\" + username + ")");
                ctx.Credentials = new NetworkCredential(username, password, domain);
            }
            else if (hasUser)
            {
                SyncLogger.Info("SP Auth: NTLM (" + username + ")");
                ctx.Credentials = new NetworkCredential(username, password);
            }
            else
            {
                SyncLogger.Info("SP Auth: Current Windows identity");
                ctx.Credentials = CredentialCache.DefaultNetworkCredentials;
            }

            return ctx;
        }
    }
}
