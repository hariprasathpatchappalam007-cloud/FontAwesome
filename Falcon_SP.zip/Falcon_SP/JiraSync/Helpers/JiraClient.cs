using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;
using Falcon_SP.JiraSync.Helpers;
using Falcon_SP.JiraSync.Models;

namespace Falcon_SP.JiraSync.Helpers
{
    /// <summary>
    /// HTTP client for the JIRA REST API v2.
    /// Fetches issues via POST /rest/api/2/search (JQL) with pagination.
    /// C# 5 / .NET 4.5 compatible – no async.
    /// </summary>
    public class JiraClient
    {
        private readonly string _baseUrl;
        private readonly string _user;
        private readonly string _password;
        private readonly int    _httpTimeoutMs;
        private readonly int    _maxRetries;

        // JIRA custom fields to fetch (from original DFM_BPM.JiraSync mapping)
        private const string Fields =
            "summary,status,issuetype,priority,project,created,updated,duedate,assignee,reporter,issuelinks," +
            "customfield_12609,customfield_12604,customfield_11610,customfield_13380," +
            "customfield_13419,customfield_13511,customfield_13510,customfield_13505,customfield_13509," +
            "customfield_13317,customfield_13358,customfield_13357,customfield_14001," +
            "customfield_12603,customfield_13339,customfield_13379,customfield_13376," +
            "customfield_13306,customfield_13359,customfield_10964," +
            "customfield_13375,customfield_13374,customfield_13362," +
            "customfield_13307,customfield_13308," +
            "customfield_10911,customfield_10916,customfield_13310,customfield_10909,customfield_13101,customfield_13600," +
            "customfield_13304,customfield_13314,customfield_10605,customfield_10606," +
            "customfield_14125,customfield_14131,customfield_14132,customfield_14130,customfield_14128,customfield_14129,customfield_14126," +
            "customfield_10966,customfield_10102,customfield_13818,customfield_11627," +
            "customfield_13405,customfield_13406,customfield_11208,customfield_13513,customfield_13007,customfield_13006";

        public JiraClient(string baseUrl, string user, string password, int httpTimeoutMs, int maxRetries)
        {
            if (string.IsNullOrEmpty(baseUrl)) throw new ArgumentNullException("baseUrl");
            _baseUrl       = baseUrl.TrimEnd('/');
            _user          = user;
            _password      = password;
            _httpTimeoutMs = httpTimeoutMs;
            _maxRetries    = maxRetries;
        }

        /// <summary>
        /// Fetches all issues for a JIRA project and returns them as parsed JiraIssue objects.
        /// </summary>
        public IList<JiraIssue> FetchProject(string projectKey, int batchSize, int minBatchSize)
        {
            var result    = new List<JiraIssue>();
            int startAt   = 0;
            int total     = int.MaxValue;
            int current   = batchSize;
            string jql    = "project=" + projectKey + " ORDER BY updated DESC";

            SyncLogger.Info("Fetching JIRA project: " + projectKey);

            while (startAt < total)
            {
                string body = FetchBatch(jql, startAt, current, ref current, minBatchSize);
                if (body == null)
                {
                    SyncLogger.Warning("Skipping remaining batches for " + projectKey + " after repeated failures.");
                    break;
                }

                var ser = new JavaScriptSerializer();
                ser.MaxJsonLength = int.MaxValue;
                Dictionary<string, object> obj;
                try { obj = ser.Deserialize<Dictionary<string, object>>(body); }
                catch (Exception ex)
                {
                    SyncLogger.Error("Parse failed at startAt=" + startAt + ": " + ex.Message);
                    break;
                }

                if (obj == null || !obj.ContainsKey("issues")) break;

                var issues = obj["issues"] as ArrayList;
                if (issues == null || issues.Count == 0) break;

                total = obj.ContainsKey("total") ? Convert.ToInt32(obj["total"]) : issues.Count;

                SyncLogger.Info("  Batch startAt=" + startAt + " fetched=" + issues.Count + " total=" + total);

                foreach (Dictionary<string, object> issue in issues)
                {
                    try
                    {
                        JiraIssue parsed = ParseIssue(issue, projectKey);
                        if (parsed != null) result.Add(parsed);
                    }
                    catch (Exception ex)
                    {
                        string k = issue.ContainsKey("key") ? Convert.ToString(issue["key"]) : "?";
                        SyncLogger.Warning("  Parse error for issue " + k + ": " + ex.Message);
                    }
                }

                startAt += issues.Count;
                if (issues.Count < current) break;
            }

            SyncLogger.Success("Fetched " + result.Count + " issues from " + projectKey);
            return result;
        }

        // ---- Private: HTTP -------------------------------------------------

        private string FetchBatch(string jql, int startAt, int maxResults, ref int current, int minBatchSize)
        {
            for (int attempt = 1; attempt <= _maxRetries; attempt++)
            {
                try
                {
                    string url  = _baseUrl + "/rest/api/2/search";
                    string json = "{\"jql\":\"" + jql.Replace("\"", "\\\"") + "\",\"startAt\":" + startAt +
                                  ",\"maxResults\":" + maxResults + ",\"fields\":[\"" +
                                  Fields.Replace(",", "\",\"") + "\"]}";

                    var req = (HttpWebRequest)WebRequest.Create(url);
                    req.Method      = "POST";
                    req.ContentType = "application/json";
                    req.Accept      = "application/json";
                    req.Timeout     = _httpTimeoutMs;
                    req.KeepAlive   = false;

                    // Basic authentication
                    string creds = Convert.ToBase64String(
                        Encoding.ASCII.GetBytes(_user + ":" + _password));
                    req.Headers.Add("Authorization", "Basic " + creds);

                    byte[] bodyBytes = Encoding.UTF8.GetBytes(json);
                    req.ContentLength = bodyBytes.Length;
                    using (Stream s = req.GetRequestStream())
                        s.Write(bodyBytes, 0, bodyBytes.Length);

                    using (var resp = (HttpWebResponse)req.GetResponse())
                    using (var sr   = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                        return sr.ReadToEnd();
                }
                catch (WebException wex)
                {
                    bool isTimeout = wex.Status == WebExceptionStatus.Timeout
                                  || wex.Status == WebExceptionStatus.ReceiveFailure
                                  || wex.Status == WebExceptionStatus.ConnectFailure;

                    SyncLogger.Warning("  Attempt " + attempt + "/" + _maxRetries + " failed (" + wex.Status + "): " + wex.Message);

                    if (attempt < _maxRetries)
                    {
                        if (isTimeout && current > minBatchSize)
                        {
                            int shrunk = Math.Max(minBatchSize, current / 2);
                            SyncLogger.Info("  Shrinking batch " + current + " -> " + shrunk);
                            current = shrunk;
                        }
                        System.Threading.Thread.Sleep(2000 * attempt);
                    }
                }
                catch (Exception ex)
                {
                    SyncLogger.Error("  Non-retryable error: " + ex.Message);
                    break;
                }
            }
            return null;
        }

        // ---- Private: Issue Mapping ----------------------------------------

        private JiraIssue ParseIssue(Dictionary<string, object> issue, string projectKey)
        {
            string key = issue.ContainsKey("key") ? Convert.ToString(issue["key"]) : null;
            if (string.IsNullOrEmpty(key)) return null;

            var fields = issue["fields"] as Dictionary<string, object>;
            if (fields == null) return null;

            var ji = new JiraIssue();
            ji.JiraKey    = key;
            ji.ProjectKey = projectKey;

            ji.Summary    = GetStr(fields, "summary");
            ji.JiraStatus = GetNested(fields, "status", "name");
            ji.Priority   = GetNested(fields, "priority", "name");
            ji.IssueType  = GetNested(fields, "issuetype", "name");
            ji.ProjectName = GetNested(fields, "project", "name");
            ji.ParentJiraKey = ExtractParentKey(fields);

            // Platform fields
            ji.Platform          = GetNestedAny(fields, "customfield_12609", new[] { "value", "name" });
            ji.PlatformVertical  = GetNestedAny(fields, "customfield_12604", new[] { "value", "name" });
            ji.PlatformName      = GetNestedAny(fields, "customfield_11610", new[] { "value", "name" });
            ji.SecondaryPlatform = GetNestedAny(fields, "customfield_13380", new[] { "value", "name" });
            if (string.IsNullOrEmpty(ji.Platform))
                ji.Platform = GetNestedAny(fields, "customfield_10043", new[] { "value", "name" });
            if (string.IsNullOrEmpty(ji.Platform))
                ji.Platform = GetNestedAny(fields, "customfield_10044", new[] { "value", "name" });

            // RAG
            ji.ActivityRagStatus  = GetNestedAny(fields, "customfield_13419", new[] { "value", "name" });
            ji.ScheduleRag        = GetNestedAny(fields, "customfield_13511", new[] { "value", "name" });
            ji.BudgetRag          = GetNestedAny(fields, "customfield_13510", new[] { "value", "name" });
            ji.RaidRag            = GetNestedAny(fields, "customfield_13505", new[] { "value", "name" });
            ji.OverallProjectRag  = GetNestedAny(fields, "customfield_13509", new[] { "value", "name" });

            // People
            ji.AccountableExecLead = GetNested(fields, "customfield_13357", "displayName");
            ji.SmeLead             = GetNested(fields, "customfield_13358", "displayName");
            ji.AccountableExec     = GetNested(fields, "customfield_13379", "displayName");
            ji.IdhPortfolioHead    = GetNested(fields, "customfield_13376", "displayName");
            ji.AssignedProjectMgr  = GetNested(fields, "customfield_12603", "displayName");
            ji.DemandOwner         = GetNested(fields, "customfield_13317", "displayName");
            ji.ChiefNameMapping    = GetNested(fields, "customfield_14001", "displayName");
            ji.Assignee            = GetNested(fields, "assignee", "displayName");
            ji.EmployeeEmail       = GetNested(fields, "assignee", "emailAddress");
            ji.Reporter            = GetNested(fields, "reporter", "displayName");

            // Demand / classification
            ji.DemandType           = GetNestedAny(fields, "customfield_13339", new[] { "value", "name" });
            ji.PrimaryClassification = GetNestedAny(fields, "customfield_13307", new[] { "value", "name" });
            ji.Classification       = ji.PrimaryClassification;
            ji.Department           = GetNestedAny(fields, "customfield_13308", new[] { "value", "name" });
            ji.ProjectPerformingDept = GetNestedAny(fields, "customfield_10911", new[] { "value", "name" });
            ji.ProjectSponsorDept   = GetNestedAny(fields, "customfield_10916", new[] { "value", "name" });
            ji.DemandDepartment     = GetNestedAny(fields, "customfield_13310", new[] { "value", "name" });
            ji.RequesterDept        = GetNestedAny(fields, "customfield_10909", new[] { "value", "name" });
            ji.ProjectDept          = GetNestedAny(fields, "customfield_13101", new[] { "value", "name" });
            ji.DemandSegment        = GetNestedAny(fields, "customfield_13600", new[] { "value", "name" });
            ji.DemandTitle          = GetStr(fields, "customfield_13304");
            ji.RegulatoryObservation = GetStr(fields, "customfield_13314");

            // Manager = AssignedProjectManager; TechLead = SmeLead
            ji.Manager  = ji.AssignedProjectMgr;
            ji.TechLead = ji.SmeLead;

            // Dates
            ji.JiraCreated          = ParseDate(GetStr(fields, "created"));
            ji.JiraUpdated          = ParseDate(GetStr(fields, "updated"));
            ji.TargetCompletionDate = ParseDate(GetStr(fields, "customfield_13306"));
            ji.ProposedDemandPickup = ParseDate(GetStr(fields, "customfield_13359"));
            ji.ActualGoLiveDate     = ParseDate(GetStr(fields, "customfield_10964"));
            ji.PB0EndDate           = ParseDate(GetStr(fields, "customfield_13375"));
            ji.PB0StartDate         = ParseDate(GetStr(fields, "customfield_13374"));
            ji.PB0SubmitDate        = ParseDate(GetStr(fields, "customfield_13362"));
            ji.BaselineStartDate    = ParseDate(GetStr(fields, "customfield_10605"));
            ji.BaselineEndDate      = ParseDate(GetStr(fields, "customfield_10606"));
            ji.BL1ActualStart       = ParseDate(GetStr(fields, "customfield_14125"));
            ji.BL0PlannedStart      = ParseDate(GetStr(fields, "customfield_14131"));
            ji.BL0PlannedEnd        = ParseDate(GetStr(fields, "customfield_14132"));
            ji.BL0ActualEnd         = ParseDate(GetStr(fields, "customfield_14130"));
            ji.BL1ActualGoLive      = ParseDate(GetStr(fields, "customfield_14128"));
            ji.BL0ActualStart       = ParseDate(GetStr(fields, "customfield_14129"));
            ji.BL1ActualEnd         = ParseDate(GetStr(fields, "customfield_14126"));

            // Status flags
            ji.RolloutStatus       = GetNestedAny(fields, "customfield_10966", new[] { "value", "name" });
            ji.EpicStatus          = GetNestedAny(fields, "customfield_10102", new[] { "value", "name" });
            ji.BrdStatus           = GetNestedAny(fields, "customfield_13818", new[] { "value", "name" });
            ji.ScriptStatus        = GetNestedAny(fields, "customfield_11627", new[] { "value", "name" });
            ji.StatusGrey          = GetNestedAny(fields, "customfield_13405", new[] { "value", "name" });
            ji.StatusReason        = GetNestedAny(fields, "customfield_13406", new[] { "value", "name" });
            ji.InitiativeStatus    = GetNestedAny(fields, "customfield_11208", new[] { "value", "name" });
            ji.ProjectOverallStatus = GetNestedAny(fields, "customfield_13513", new[] { "value", "name" });
            ji.CbtpBrdStatus       = GetNestedAny(fields, "customfield_13007", new[] { "value", "name" });
            ji.FsdStatus           = GetNestedAny(fields, "customfield_13006", new[] { "value", "name" });

            // Computed RAG from target completion date
            ji.ProjectRAG = ComputeRag(ji.TargetCompletionDate);

            return ji;
        }

        // ---- Utility -------------------------------------------------------

        private static string GetStr(Dictionary<string, object> fields, string key)
        {
            if (fields == null || !fields.ContainsKey(key)) return null;
            var v = fields[key];
            return v != null ? Convert.ToString(v) : null;
        }

        private static string GetNested(Dictionary<string, object> fields, string key, string subKey)
        {
            if (fields == null || !fields.ContainsKey(key)) return null;
            var obj = fields[key] as Dictionary<string, object>;
            if (obj == null || !obj.ContainsKey(subKey)) return null;
            var v = obj[subKey];
            return v != null ? Convert.ToString(v) : null;
        }

        private static string GetNestedAny(Dictionary<string, object> fields, string key, string[] subKeys)
        {
            if (fields == null || !fields.ContainsKey(key)) return null;
            var obj = fields[key] as Dictionary<string, object>;
            if (obj == null) return null;
            foreach (string sub in subKeys)
            {
                if (obj.ContainsKey(sub) && obj[sub] != null)
                    return Convert.ToString(obj[sub]);
            }
            return null;
        }

        private static string ExtractParentKey(Dictionary<string, object> fields)
        {
            if (!fields.ContainsKey("issuelinks") || fields["issuelinks"] == null) return null;
            var links = fields["issuelinks"] as ArrayList;
            if (links == null) return null;
            foreach (Dictionary<string, object> link in links)
            {
                var type = link.ContainsKey("type") ? link["type"] as Dictionary<string, object> : null;
                string typeName = type != null && type.ContainsKey("name") ? Convert.ToString(type["name"]) : "";
                string inward   = type != null && type.ContainsKey("inward") ? Convert.ToString(type["inward"]) : "";
                bool isParent   = typeName.IndexOf("Parent", StringComparison.OrdinalIgnoreCase) >= 0
                               || inward.IndexOf("child of", StringComparison.OrdinalIgnoreCase) >= 0;
                if (isParent)
                {
                    var outIssue = link.ContainsKey("outwardIssue") ? link["outwardIssue"] as Dictionary<string, object> : null;
                    if (outIssue != null && outIssue.ContainsKey("key"))
                        return Convert.ToString(outIssue["key"]);
                }
            }
            return null;
        }

        private static DateTime? ParseDate(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            DateTime dt;
            if (DateTime.TryParse(s, out dt)) return dt;
            return null;
        }

        private static string ComputeRag(DateTime? targetDate)
        {
            if (!targetDate.HasValue) return "Grey";
            int daysLeft = (int)(targetDate.Value.Date - DateTime.Today).TotalDays;
            if (daysLeft < 0)  return "Red";
            if (daysLeft <= 14) return "Amber";
            return "Green";
        }
    }
}
