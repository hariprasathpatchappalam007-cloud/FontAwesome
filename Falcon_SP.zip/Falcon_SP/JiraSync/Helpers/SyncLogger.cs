using System;
using System.IO;

namespace Falcon_SP.JiraSync.Helpers
{
    /// <summary>
    /// Thread-safe console + file logger for the JIRA sync process.
    /// Writes to both the console and an optional log file.
    /// C# 5 / .NET 4.5 compatible.
    /// </summary>
    public static class SyncLogger
    {
        private static string _logFile;

        public static void Init(string logPath)
        {
            if (!string.IsNullOrEmpty(logPath))
            {
                _logFile = Path.Combine(
                    logPath,
                    "JiraSync_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".log");

                if (!Directory.Exists(logPath))
                    Directory.CreateDirectory(logPath);
            }
        }

        public static void Info(string msg)
        {
            Write(ConsoleColor.White, "[INFO]  " + msg);
        }

        public static void Success(string msg)
        {
            Write(ConsoleColor.Green, "[OK]    " + msg);
        }

        public static void Warning(string msg)
        {
            Write(ConsoleColor.Yellow, "[WARN]  " + msg);
        }

        public static void Error(string msg)
        {
            Write(ConsoleColor.Red, "[ERROR] " + msg);
        }

        public static void Error(string msg, Exception ex)
        {
            Write(ConsoleColor.Red, "[ERROR] " + msg);
            if (ex != null)
                Write(ConsoleColor.Red, "        " + ex.Message);
        }

        public static void Header(string msg)
        {
            Write(ConsoleColor.Cyan, msg);
        }

        private static void Write(ConsoleColor color, string msg)
        {
            string line = DateTime.Now.ToString("HH:mm:ss") + " " + msg;
            lock (typeof(SyncLogger))
            {
                Console.ForegroundColor = color;
                Console.WriteLine(line);
                Console.ResetColor();

                if (_logFile != null)
                {
                    try { File.AppendAllText(_logFile, line + Environment.NewLine); }
                    catch { /* never let logging kill the sync */ }
                }
            }
        }
    }
}
