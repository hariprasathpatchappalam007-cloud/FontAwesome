using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net;
using Falcon_SP.JiraSync.Helpers;
using Falcon_SP.JiraSync.Models;
using Falcon_SP.JiraSync.Sync;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.JiraSync
{
    /// <summary>
    /// Falcon PET – JIRA to SharePoint Sync
    /// Fetches issues from JIRA REST API and upserts them into the SharePoint
    /// "Project Details" list using CSOM.
    ///
    /// Designed to run as a Windows Scheduled Task (e.g. every 2 hours).
    /// C# 5 / .NET 4.5 / Visual Studio 2012 compatible.
    /// </summary>
    class Program
    {
        static int Main(string[] args)
        {
            DateTime start = DateTime.Now;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("=====================================================");
            Console.WriteLine("  Falcon PET – JIRA to SharePoint Sync");
            Console.WriteLine("  Started: " + start.ToString("yyyy-MM-dd HH:mm:ss"));
            Console.WriteLine("=====================================================");
            Console.ResetColor();

            // ── Read configuration ─────────────────────────────────────────
            string jiraBaseUrl    = ConfigurationManager.AppSettings["JiraBaseUrl"];
            string jiraUser       = ConfigurationManager.AppSettings["JiraUser"];
            string jiraPassword   = ConfigurationManager.AppSettings["JiraPassword"];
            string projectsCsv    = ConfigurationManager.AppSettings["JiraProjects"] ?? "DMGT,DIBITP";
            int    batchSize      = Parse(ConfigurationManager.AppSettings["JiraBatchSize"],      200);
            int    minBatchSize   = Parse(ConfigurationManager.AppSettings["JiraMinBatchSize"],    50);
            int    httpTimeout    = Parse(ConfigurationManager.AppSettings["JiraHttpTimeout"],    120) * 1000;
            int    maxRetries     = Parse(ConfigurationManager.AppSettings["JiraMaxRetries"],       3);

            string siteUrl        = ConfigurationManager.AppSettings["SiteUrl"];
            string spUsername     = ConfigurationManager.AppSettings["SpUsername"];
            string spPassword     = ConfigurationManager.AppSettings["SpPassword"];
            string spDomain       = ConfigurationManager.AppSettings["SpDomain"];
            string listName       = ConfigurationManager.AppSettings["ProjectDetailsList"] ?? "Project Details";
            int    writeBatch     = Parse(ConfigurationManager.AppSettings["SpWriteBatchSize"],    50);
            string logPath        = ConfigurationManager.AppSettings["LogPath"];

            SyncLogger.Init(logPath);

            // Validate required settings
            if (string.IsNullOrEmpty(jiraBaseUrl))
            {
                SyncLogger.Error("JiraBaseUrl is not configured in App.config.");
                return 1;
            }
            if (string.IsNullOrEmpty(siteUrl))
            {
                SyncLogger.Error("SiteUrl is not configured in App.config.");
                return 1;
            }

            // Enable TLS 1.2 for JIRA connections
            ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Tls12 |
                SecurityProtocolType.Tls11 |
                SecurityProtocolType.Tls;

            string[] projects = projectsCsv.Split(',');
            int totalInserted = 0, totalUpdated = 0, totalFailed = 0;

            try
            {
                // ── Initialise JIRA client ─────────────────────────────────
                var jiraClient = new JiraClient(
                    jiraBaseUrl, jiraUser, jiraPassword, httpTimeout, maxRetries);

                // ── Connect to SharePoint ──────────────────────────────────
                SyncLogger.Info("Connecting to SharePoint: " + siteUrl);
                using (ClientContext ctx = AuthHelper.GetContext(siteUrl, spUsername, spPassword, spDomain))
                {
                    ctx.Load(ctx.Web, w => w.Title, w => w.Url);
                    ctx.ExecuteQuery();
                    SyncLogger.Success("Connected to: " + ctx.Web.Title + "  (" + ctx.Web.Url + ")");

                    var syncer = new ProjectDetailsSync(ctx, listName, writeBatch);

                    // ── Sync each project ──────────────────────────────────
                    foreach (string proj in projects)
                    {
                        string projectKey = proj.Trim();
                        if (string.IsNullOrEmpty(projectKey)) continue;

                        SyncLogger.Header("\n--- Syncing project: " + projectKey + " ---");

                        try
                        {
                            IList<JiraIssue> issues = jiraClient.FetchProject(
                                projectKey, batchSize, minBatchSize);

                            syncer.Sync(issues);

                            totalInserted += syncer.Inserted;
                            totalUpdated  += syncer.Updated;
                            totalFailed   += syncer.Failed;
                        }
                        catch (Exception ex)
                        {
                            SyncLogger.Error("Project sync failed (" + projectKey + "): " + ex.Message);
                            totalFailed++;
                        }
                    }
                }

                TimeSpan elapsed = DateTime.Now - start;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n=====================================================");
                Console.WriteLine("  Sync complete. Inserted=" + totalInserted
                    + " Updated=" + totalUpdated
                    + " Failed=" + totalFailed
                    + " Duration=" + elapsed.ToString(@"hh\:mm\:ss"));
                Console.WriteLine("=====================================================");
                Console.ResetColor();
                return totalFailed == 0 ? 0 : 2;
            }
            catch (Exception ex)
            {
                SyncLogger.Error("Fatal error: " + ex.Message, ex);
                return 1;
            }
        }

        private static int Parse(string s, int fallback)
        {
            int v;
            return (s != null && int.TryParse(s, out v)) ? v : fallback;
        }
    }
}
