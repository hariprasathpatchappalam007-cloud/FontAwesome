# Falcon PET Management System
## SharePoint Content Editor WebPart + AngularJS Application

---

## Project Overview

Falcon PET is a Project Expenditure Tracking system built as a **SharePoint Classic Content Editor WebPart (CEWP)** AngularJS SPA. All data is stored in **SharePoint Lists and Document Libraries** provisioned via **CSOM**.

---

## Repository Structure

```
Falcon_SP/
├── Provision/                  C# CSOM Console App – provisions SP lists & libraries
│   ├── Program.cs
│   ├── Provisioners/
│   │   ├── ListProvisioner.cs      All 17 SharePoint Lists
│   │   ├── LibraryProvisioner.cs   5 Document Libraries
│   │   ├── SiteColumnsProvisioner.cs
│   │   └── ContentTypesProvisioner.cs
│   ├── Helpers/
│   │   ├── AuthHelper.cs           SPO / On-Prem auth
│   │   └── ProvisionLogger.cs
│   ├── Models/ListDefinition.cs
│   └── App.config                  ← configure SiteUrl, credentials here
│
├── SiteAssets/PET/             AngularJS SPA (deployed to SharePoint SiteAssets)
│   ├── index.html              CEWP entry page
│   ├── app.js                  Module declaration + run block
│   ├── routes.js               ngRoute configuration
│   ├── config.js               HTTP interceptor, provider config
│   ├── constants.js            List names, roles, status values
│   ├── Controllers/            14 controllers
│   ├── Services/               16 services (SharePoint REST, CRUD, Workflow...)
│   ├── Factories/              AppFactory, CacheFactory, CommonFactory
│   ├── Directives/             11 directives (PeoplePicker, Grid, FileUpload...)
│   ├── Filters/                4 filters (date, status, currency, search)
│   ├── Templates/              All HTML views
│   │   ├── Partials/           Sidebar, Header, Footer, Notifications
│   │   ├── PET/                Dashboard, ProjectDetails, Sizing, Approval, CSVImport
│   │   ├── Approvals/          MyApprovals
│   │   ├── Masters/            CAPEX, OPEX, Vendor, GLMaster
│   │   └── Admin/              RoleManagement, EmailLog, JiraSync
│   ├── CSS/                    Bootstrap + custom styles
│   ├── JS/                     Vendor JS (download via Deploy-Libraries.ps1)
│   └── Libraries/              3rd-party libs (PapaParse, Chart.js, etc.)
│
└── Deploy/
    ├── Deploy-SiteAssets.ps1       Upload SiteAssets to SharePoint via PnP PS
    ├── Provision-SharePoint.ps1    Build & run CSOM provisioning
    ├── Configure-CEWP.ps1          Guidance for wiring the CEWP
    └── Download-Libraries.ps1      Download all vendor JS/CSS locally
```

---

## Quick Start

### Step 1 – Download vendor libraries
```powershell
cd Deploy
.\Download-Libraries.ps1
```

### Step 2 – Configure provisioning
Edit `Provision\App.config`:
```xml
<add key="SiteUrl"   value="https://your-tenant.sharepoint.com/sites/PET" />
<add key="Username"  value="admin@your-tenant.com" />
<add key="Password"  value="YourPassword" />
```

### Step 3 – Provision SharePoint (lists, libraries, columns)
```powershell
cd Deploy
.\Provision-SharePoint.ps1 -SiteUrl "https://your-tenant.sharepoint.com/sites/PET" `
                            -Username "admin@your-tenant.com" -Password "YourPassword"
```

### Step 4 – Deploy SiteAssets
```powershell
.\Deploy-SiteAssets.ps1 -SiteUrl "https://your-tenant.sharepoint.com/sites/PET"
```

### Step 5 – Configure Content Editor Web Part
1. Navigate to your target SharePoint page.
2. Add a **Content Editor Web Part**.
3. Set the **Content Link** to:
   ```
   /sites/PET/SiteAssets/PET/index.html
   ```
4. Save the page.

---

## SharePoint Lists Provisioned

| List | Purpose |
|------|---------|
| PET Projects | Main PET request store |
| Project Details | Project master |
| Project Sizing | Line items & budget calculations |
| Budget Details | Budget source allocation |
| PET Workflow | Workflow routing & status |
| Approval History | Approval audit trail |
| CAPEX Master | CAPEX categories |
| OPEX Master | OPEX categories |
| Vendor Master | Approved vendor list |
| GL Master | General Ledger accounts |
| Budget Source | Budget source master |
| Role Management | User ↔ Role assignments |
| Role Permissions | Module access matrix |
| Email Logs | Email notification audit |
| JIRA Sync Logs | JIRA synchronisation history |
| Notifications | In-app user notifications |
| Application Settings | Key-value config store |

## Document Libraries Provisioned

| Library | Purpose |
|---------|---------|
| Project Documents | PET supporting files |
| PET Attachments | Request attachments |
| CSV Imports | Bulk import uploads |
| Email Templates | HTML email templates |
| Application Logs | Error / diagnostic logs |

---

## Workflow

```
Requestor → Submit → Reviewer → CAPEX Approver → OPEX Approver → PET Approver → Approved
                     ↓ (Send Back)
                   Requestor (revise & resubmit)
```

## Roles & Permissions

| Role | Dashboard | PET | Approvals | Masters | Admin |
|------|-----------|-----|-----------|---------|-------|
| Administrator | ✔ | ✔ | ✔ | ✔ | ✔ |
| PET Approver | ✔ | ✔ | ✔ | Read | – |
| CAPEX Approver | ✔ | ✔ | ✔ | Read | – |
| OPEX Approver | ✔ | ✔ | ✔ | Read | – |
| Reviewer | ✔ | ✔ | ✔ | – | – |
| Requestor | ✔ | ✔ (own) | – | – | – |

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | AngularJS 1.8.3 (SPA via CEWP) |
| Styling | Bootstrap 4.6 + Custom CSS |
| SP Integration | SharePoint REST API (/_api/) |
| Provisioning | C# CSOM (.NET 4.7.2) |
| JIRA Sync | JIRA REST API v2 |
| CSV Import | PapaParse |
| Charts | Chart.js 3 |
| Alerts | SweetAlert2 |
| Deployment | PnP PowerShell |
