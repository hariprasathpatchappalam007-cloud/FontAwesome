CSOM DLLs for SharePoint Server Subscription Edition
======================================================

All three projects (Falcon_SP.Provision, Falcon_SP.CsomDeploy, Falcon_SP.JiraSync)
reference the SharePoint Client Object Model (CSOM) DLLs from this folder.

Instructions
------------
1. On your SharePoint Server, locate the DLLs at:
   %CommonProgramFiles%\microsoft shared\Web Server Extensions\16\ISAPI\

2. Copy these two files into THIS folder (lib\net45\):
     Microsoft.SharePoint.Client.dll
     Microsoft.SharePoint.Client.Runtime.dll

3. The projects reference these files via the HintPath:
   ..\lib\net45\Microsoft.SharePoint.Client.dll
   ..\lib\net45\Microsoft.SharePoint.Client.Runtime.dll

Note: You do NOT need the NuGet package Microsoft.SharePointOnline.CSOM.
      The on-premises DLLs from the SP server hive are used directly.
      The version should be 16.x.x (SharePoint 2019 / Subscription Edition).

Alternative: Install the SharePoint Server 2019 Client SDK on the build machine.
             The DLLs will be placed in:
             C:\Program Files\Common Files\microsoft shared\Web Server Extensions\16\ISAPI\
