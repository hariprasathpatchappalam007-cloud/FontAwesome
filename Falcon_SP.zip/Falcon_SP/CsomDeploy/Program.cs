using System;
using System.Configuration;
using System.IO;
using Falcon_SP.CsomDeploy.Deployer;
using Falcon_SP.CsomDeploy.Helpers;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.CsomDeploy
{
    /// <summary>
    /// Falcon PET – CSOM Deployment Tool
    /// Uploads the entire SiteAssets/PET folder to SharePoint Server Subscription Edition
    /// using the CSOM FileCreationInformation API (no PowerShell / PnP required).
    ///
    /// Usage: Falcon_SP.CsomDeploy.exe [sourceFolder]
    ///   sourceFolder : optional override for App.config LocalSourcePath
    /// </summary>
    class Program
    {
        static int Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("=================================================");
            Console.WriteLine("  Falcon PET – CSOM Deployment Tool");
            Console.WriteLine("=================================================");
            Console.ResetColor();

            string siteUrl       = ConfigurationManager.AppSettings["SiteUrl"];
            string username      = ConfigurationManager.AppSettings["Username"];
            string password      = ConfigurationManager.AppSettings["Password"];
            string domain        = ConfigurationManager.AppSettings["Domain"];
            string targetLibrary = ConfigurationManager.AppSettings["TargetLibrary"] ?? "SiteAssets";
            string targetFolder  = ConfigurationManager.AppSettings["TargetFolder"]  ?? "PET";
            string localSource   = args.Length > 0 ? args[0] : ConfigurationManager.AppSettings["LocalSourcePath"];

            if (string.IsNullOrEmpty(siteUrl))
            {
                DeployLogger.Error("SiteUrl is not configured in App.config.");
                return 1;
            }

            // Resolve relative source path from the executable location
            if (!Path.IsPathRooted(localSource))
            {
                string exeDir = Path.GetDirectoryName(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);
                localSource = Path.GetFullPath(Path.Combine(exeDir, localSource));
            }

            DeployLogger.Info("Site URL     : " + siteUrl);
            DeployLogger.Info("Source folder: " + localSource);
            DeployLogger.Info("Target       : " + targetLibrary + "/" + targetFolder);

            if (!Directory.Exists(localSource))
            {
                DeployLogger.Error("Source folder does not exist: " + localSource);
                return 1;
            }

            try
            {
                using (ClientContext ctx = AuthHelper.GetContext(siteUrl, username, password, domain))
                {
                    ctx.Load(ctx.Web, w => w.Title, w => w.Url);
                    ctx.ExecuteQuery();
                    DeployLogger.Info("Connected to : " + ctx.Web.Title + "  (" + ctx.Web.Url + ")");

                    var deployer = new SiteAssetsDeployer(ctx, targetLibrary, targetFolder);
                    deployer.Deploy(localSource);

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\n=================================================");
                    Console.WriteLine("  Deployment completed successfully!");
                    Console.WriteLine("=================================================");
                    Console.ResetColor();
                    return 0;
                }
            }
            catch (Exception ex)
            {
                DeployLogger.Error("Deployment failed: " + ex.Message, ex);
                return 2;
            }
        }
    }
}
