using System;

namespace Falcon_SP.CsomDeploy.Helpers
{
    /// <summary>Simple colour-coded console logger (C# 5 / .NET 4.5 compatible).</summary>
    public static class DeployLogger
    {
        public static void Info(string msg)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("  [INFO]  " + msg);
            Console.ResetColor();
        }

        public static void Success(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("  [OK]    " + msg);
            Console.ResetColor();
        }

        public static void Skip(string msg)
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("  [SKIP]  " + msg);
            Console.ResetColor();
        }

        public static void Warning(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("  [WARN]  " + msg);
            Console.ResetColor();
        }

        public static void Error(string msg, Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("  [ERROR] " + msg);
            if (ex != null) Console.WriteLine("          " + ex.Message);
            Console.ResetColor();
        }

        public static void Error(string msg)
        {
            Error(msg, null);
        }
    }
}
