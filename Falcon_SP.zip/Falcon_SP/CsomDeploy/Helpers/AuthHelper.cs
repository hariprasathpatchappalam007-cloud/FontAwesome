using System;
using System.Net;
using Microsoft.SharePoint.Client;

namespace Falcon_SP.CsomDeploy.Helpers
{
    /// <summary>
    /// Returns an authenticated ClientContext for SharePoint Server Subscription Edition.
    /// Auth: explicit NTLM credentials or current Windows identity.
    /// </summary>
    public static class AuthHelper
    {
        public static ClientContext GetContext(
            string siteUrl,
            string username,
            string password,
            string domain)
        {
            if (string.IsNullOrEmpty(siteUrl))
                throw new ArgumentNullException("siteUrl");

            var ctx = new ClientContext(siteUrl);

            bool hasUser = !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password);

            if (hasUser && !string.IsNullOrEmpty(domain))
            {
                DeployLogger.Info("Auth: NTLM (" + domain + "\\" + username + ")");
                ctx.Credentials = new NetworkCredential(username, password, domain);
            }
            else if (hasUser)
            {
                DeployLogger.Info("Auth: NTLM (" + username + ")");
                ctx.Credentials = new NetworkCredential(username, password);
            }
            else
            {
                DeployLogger.Info("Auth: Current Windows identity (DefaultNetworkCredentials)");
                ctx.Credentials = CredentialCache.DefaultNetworkCredentials;
            }

            return ctx;
        }
    }
}
