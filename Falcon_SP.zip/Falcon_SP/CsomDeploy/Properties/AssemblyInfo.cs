using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Falcon_SP.CsomDeploy")]
[assembly: AssemblyDescription("CSOM-based deployment tool – uploads SiteAssets to SharePoint Server Subscription Edition")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Falcon")]
[assembly: AssemblyProduct("Falcon PET")]
[assembly: AssemblyCopyright("Copyright © 2024")]
[assembly: ComVisible(false)]
[assembly: Guid("b2c3d4e5-f6a7-8901-bcde-f12345678901")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
