using System;

public partial class WindowsLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string windowsUser = AuthHelper.GetWindowsUserName(Request);

        if (String.IsNullOrWhiteSpace(windowsUser))
        {
            MessageLabel.Text = "Windows authentication did not return a user name. Check IIS authentication settings for this page.";
            return;
        }

        if (!IsAuthorizedApplicationUser(windowsUser))
        {
            Response.Redirect("~/AccessDenied.aspx", true);
            return;
        }

        AuthHelper.SignIn(Context, windowsUser, false);
        Response.Redirect("~/Default.aspx", true);
    }

    private static bool IsAuthorizedApplicationUser(string windowsUser)
    {
        // Replace this with your existing SQL Server user/role validation.
        return !String.IsNullOrWhiteSpace(windowsUser);
    }
}