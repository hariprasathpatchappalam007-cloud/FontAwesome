using System;

public partial class Default : HflmsBasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UserNameLiteral.Text = Convert.ToString(Session[AuthHelper.SessionUserIdKey]);
    }
}