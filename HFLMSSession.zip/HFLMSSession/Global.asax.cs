using System;
using System.Diagnostics;
using System.Web;

namespace HFLMSSession
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            Application["AppStartUtc"] = DateTime.UtcNow;
            Application["AppStartMachine"] = Environment.MachineName;
            Application["AppStartProcessId"] = Process.GetCurrentProcess().Id;
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            Session["SessionStartUtc"] = DateTime.UtcNow;
            Session["SessionStartMachine"] = Environment.MachineName;
            Session["SessionStartProcessId"] = Process.GetCurrentProcess().Id;
        }
    }
}