using System;

public partial class Logout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        AuthHelper.SignOut(Context);
        Response.Redirect("~/LoggedOut.aspx", true);
    }
}