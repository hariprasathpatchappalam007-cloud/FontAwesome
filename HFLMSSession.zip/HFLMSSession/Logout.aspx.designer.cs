public partial class Logout
{
}