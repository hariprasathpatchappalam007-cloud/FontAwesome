<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WindowsLogin.aspx.cs" Inherits="WindowsLogin" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HFLMS Login</title>
</head>
<body>
    <form id="form1" runat="server">
        <asp:Label ID="MessageLabel" runat="server" />
    </form>
</body>
</html>