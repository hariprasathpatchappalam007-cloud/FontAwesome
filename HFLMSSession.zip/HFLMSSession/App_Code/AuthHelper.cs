using System;
using System.Web;
using System.Web.Security;

public static class AuthHelper
{
    public const string SessionUserIdKey = "UserID";
    private const string LoggedOutCookieName = "HFLMSLoggedOut";

    public static string GetWindowsUserName(HttpRequest request)
    {
        string userName = request.ServerVariables["LOGON_USER"];

        if (String.IsNullOrWhiteSpace(userName))
        {
            userName = request.ServerVariables["AUTH_USER"];
        }

        return userName;
    }

    public static void SignIn(HttpContext context, string userName, bool rememberMe)
    {
        if (String.IsNullOrWhiteSpace(userName))
        {
            throw new InvalidOperationException("Windows user name was not available from IIS.");
        }

        FormsAuthentication.SetAuthCookie(userName, rememberMe);
        context.Session[SessionUserIdKey] = userName;

        ExpireCookie(context.Response, LoggedOutCookieName);
    }

    public static void SignOut(HttpContext context)
    {
        FormsAuthentication.SignOut();

        if (context.Session != null)
        {
            context.Session.Clear();
            context.Session.Abandon();
        }

        ExpireCookie(context.Response, FormsAuthentication.FormsCookieName);
        ExpireCookie(context.Response, "ASP.NET_SessionId");

        HttpCookie loggedOutCookie = new HttpCookie(LoggedOutCookieName, "1");
        loggedOutCookie.HttpOnly = true;
        loggedOutCookie.Secure = context.Request.IsSecureConnection;
        loggedOutCookie.Expires = DateTime.Now.AddMinutes(5);
        context.Response.Cookies.Add(loggedOutCookie);

        context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        context.Response.Cache.SetNoStore();
        context.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
    }

    public static bool IsApplicationAuthenticated(HttpContext context)
    {
        return context.User != null
            && context.User.Identity != null
            && context.User.Identity.IsAuthenticated;
    }

    private static void ExpireCookie(HttpResponse response, string cookieName)
    {
        HttpCookie cookie = new HttpCookie(cookieName, String.Empty);
        cookie.Expires = DateTime.Now.AddDays(-1);
        cookie.HttpOnly = true;
        response.Cookies.Add(cookie);
    }
}