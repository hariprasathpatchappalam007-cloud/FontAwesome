using System;
using System.Web;
using System.Web.UI;

public class HflmsBasePage : Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);

        if (!AuthHelper.IsApplicationAuthenticated(Context))
        {
            Response.Redirect("~/WindowsLogin.aspx", true);
            return;
        }

        if (Session[AuthHelper.SessionUserIdKey] == null)
        {
            Session[AuthHelper.SessionUserIdKey] = Context.User.Identity.Name;
        }

        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }
}