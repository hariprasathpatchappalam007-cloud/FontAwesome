<%@ Page Language="C#" AutoEventWireup="true" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Access Denied</title>
</head>
<body>
    <form id="form1" runat="server">
        <h1>Access denied</h1>
        <p>Your Windows account is not authorized for HFLMS.</p>
    </form>
</body>
</html>