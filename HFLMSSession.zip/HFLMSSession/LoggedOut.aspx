<%@ Page Language="C#" AutoEventWireup="true" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Logged Out</title>
</head>
<body>
    <form id="form1" runat="server">
        <h1>You are logged out of HFLMS</h1>
        <p>Close the browser to clear cached NTLM credentials, or click login to start a new application session.</p>
        <asp:HyperLink ID="LoginLink" runat="server" NavigateUrl="~/WindowsLogin.aspx" Text="Login again" />
    </form>
</body>
</html>