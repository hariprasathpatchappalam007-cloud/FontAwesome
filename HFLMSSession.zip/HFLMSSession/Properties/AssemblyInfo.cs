using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HFLMSSession")]
[assembly: AssemblyDescription("HFLMS NTLM and application logout sample")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HFLMSSession")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("87a6cb7a-72bb-42d9-bc69-455048c1eaba")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]