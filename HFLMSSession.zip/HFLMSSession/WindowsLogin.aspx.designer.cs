public partial class WindowsLogin
{
    protected global::System.Web.UI.HtmlControls.HtmlForm form1;

    protected global::System.Web.UI.WebControls.Label MessageLabel;
}