<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AuthDiagnostics.aspx.cs" Inherits="AuthDiagnostics" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HFLMS Auth Diagnostics</title>
</head>
<body>
    <form id="form1" runat="server">
        <h1>HFLMS Auth Diagnostics</h1>
        <asp:Literal ID="DiagnosticsLiteral" runat="server" />
    </form>
</body>
</html>