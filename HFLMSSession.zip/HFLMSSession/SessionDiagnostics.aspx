<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="SessionDiagnostics.aspx.cs" Inherits="SessionDiagnostics" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HFLMS Session Diagnostics</title>
</head>
<body>
    <form id="form1" runat="server">
        <h1>HFLMS Session Diagnostics</h1>
        <p>Refresh this page every 30 seconds. If logout/session loss happens, compare the values before and after.</p>
        <asp:Literal ID="DiagnosticsLiteral" runat="server" />
    </form>
</body>
</html>