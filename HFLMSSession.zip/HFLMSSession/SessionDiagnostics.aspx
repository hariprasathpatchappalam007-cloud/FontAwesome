<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="SessionDiagnostics.aspx.cs" Inherits="SessionDiagnostics" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HFLMS Session Diagnostics</title>
    <style type="text/css">
        body {
            margin: 0;
            background: #f3f6f8;
            color: #1f2933;
            font-family: Segoe UI, Verdana, Arial, sans-serif;
            font-size: 14px;
        }

        .page {
            max-width: 1120px;
            margin: 0 auto;
            padding: 28px;
        }

        .header {
            background: #ffffff;
            border: 1px solid #d9e2ec;
            border-left: 6px solid #116466;
            padding: 20px 22px;
            margin-bottom: 18px;
        }

        h1 {
            margin: 0 0 8px 0;
            font-size: 26px;
            font-weight: 600;
        }

        h2 {
            margin-top: 24px;
            font-size: 18px;
        }

        .actions {
            margin-top: 16px;
        }

        .button {
            display: inline-block;
            padding: 9px 14px;
            margin-right: 8px;
            background: #116466;
            color: #ffffff;
            text-decoration: none;
            border-radius: 4px;
            font-weight: 600;
        }

        .button.secondary {
            background: #52616b;
        }

        .panel {
            background: #ffffff;
            border: 1px solid #d9e2ec;
            padding: 18px 22px;
            margin-bottom: 18px;
        }

        .diagnostics-table {
            width: 100%;
            border-collapse: collapse;
            background: #ffffff;
        }

        .diagnostics-table th,
        .diagnostics-table td {
            border-bottom: 1px solid #e6edf3;
            padding: 9px 10px;
            text-align: left;
            vertical-align: top;
            word-break: break-word;
        }

        .diagnostics-table th {
            width: 34%;
            background: #f8fafc;
            color: #334e68;
            font-weight: 600;
        }

        .hint-list li {
            margin-bottom: 7px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="page">
            <div class="header">
                <h1>HFLMS Session Diagnostics</h1>
                <p>Refresh this page every 30 seconds. If logout/session loss happens, compare the values before and after.</p>
                <div class="actions">
                    <a class="button" href="SessionDiagnostics.aspx?export=csv">Export Current Snapshot to CSV</a>
                    <a class="button secondary" href="SessionDiagnostics.aspx">Refresh Snapshot</a>
                </div>
            </div>
            <asp:Literal ID="DiagnosticsLiteral" runat="server" />
        </div>
    </form>
</body>
</html>