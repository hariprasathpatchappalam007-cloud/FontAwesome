using System;
using System.Text;
using System.Web;

public partial class AuthDiagnostics : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        StringBuilder html = new StringBuilder();

        html.Append("<table border=\"1\" cellpadding=\"6\" cellspacing=\"0\">");
        AppendRow(html, "Request.IsAuthenticated", Request.IsAuthenticated.ToString());
        AppendRow(html, "Context.User.Identity.Name", Context.User != null && Context.User.Identity != null ? Context.User.Identity.Name : String.Empty);
        AppendRow(html, "Context.User.Identity.AuthenticationType", Context.User != null && Context.User.Identity != null ? Context.User.Identity.AuthenticationType : String.Empty);
        AppendRow(html, "Request.LogonUserIdentity.Name", Request.LogonUserIdentity != null ? Request.LogonUserIdentity.Name : String.Empty);
        AppendRow(html, "Request.LogonUserIdentity.AuthenticationType", Request.LogonUserIdentity != null ? Request.LogonUserIdentity.AuthenticationType : String.Empty);
        AppendRow(html, "ServerVariables[LOGON_USER]", Request.ServerVariables["LOGON_USER"]);
        AppendRow(html, "ServerVariables[AUTH_USER]", Request.ServerVariables["AUTH_USER"]);
        AppendRow(html, "ServerVariables[REMOTE_USER]", Request.ServerVariables["REMOTE_USER"]);
        AppendRow(html, "ServerVariables[AUTH_TYPE]", Request.ServerVariables["AUTH_TYPE"]);
        html.Append("</table>");

        DiagnosticsLiteral.Text = html.ToString();
    }

    private static void AppendRow(StringBuilder html, string name, string value)
    {
        html.Append("<tr><th align=\"left\">");
        html.Append(HttpUtility.HtmlEncode(name));
        html.Append("</th><td>");
        html.Append(HttpUtility.HtmlEncode(value));
        html.Append("</td></tr>");
    }
}