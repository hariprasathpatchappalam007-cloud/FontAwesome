using System;
using System.Text;
using System.Web;

public partial class AuthDiagnostics : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        StringBuilder html = new StringBuilder();

        string authType = Request.ServerVariables["AUTH_TYPE"];
        string logonUser = Request.ServerVariables["LOGON_USER"];
        string logonIdentityName = Request.LogonUserIdentity != null ? Request.LogonUserIdentity.Name : String.Empty;
        bool logonIdentityAuthenticated = Request.LogonUserIdentity != null && Request.LogonUserIdentity.IsAuthenticated;

        if (String.IsNullOrWhiteSpace(authType) && String.IsNullOrWhiteSpace(logonUser))
        {
            html.Append("<p><strong>Result:</strong> IIS did not authenticate the browser user for this request. ");
            html.Append("If Request.LogonUserIdentity.Name shows a service account, do not use it as the HFLMS user.</p>");
        }
        else
        {
            html.Append("<p><strong>Result:</strong> IIS authentication information is available for this request.</p>");
        }

        html.Append("<table border=\"1\" cellpadding=\"6\" cellspacing=\"0\">");
        AppendRow(html, "Request.IsAuthenticated", Request.IsAuthenticated.ToString());
        AppendRow(html, "Context.User.Identity.Name", Context.User != null && Context.User.Identity != null ? Context.User.Identity.Name : String.Empty);
        AppendRow(html, "Context.User.Identity.AuthenticationType", Context.User != null && Context.User.Identity != null ? Context.User.Identity.AuthenticationType : String.Empty);
        AppendRow(html, "Request.LogonUserIdentity.Name", logonIdentityName);
        AppendRow(html, "Request.LogonUserIdentity.IsAuthenticated", logonIdentityAuthenticated.ToString());
        AppendRow(html, "Request.LogonUserIdentity.AuthenticationType", Request.LogonUserIdentity != null ? Request.LogonUserIdentity.AuthenticationType : String.Empty);
        AppendRow(html, "ServerVariables[LOGON_USER]", logonUser);
        AppendRow(html, "ServerVariables[AUTH_USER]", Request.ServerVariables["AUTH_USER"]);
        AppendRow(html, "ServerVariables[REMOTE_USER]", Request.ServerVariables["REMOTE_USER"]);
        AppendRow(html, "ServerVariables[AUTH_TYPE]", authType);
        html.Append("</table>");

        DiagnosticsLiteral.Text = html.ToString();
    }

    private static void AppendRow(StringBuilder html, string name, string value)
    {
        html.Append("<tr><th align=\"left\">");
        html.Append(HttpUtility.HtmlEncode(name));
        html.Append("</th><td>");
        html.Append(HttpUtility.HtmlEncode(value));
        html.Append("</td></tr>");
    }
}