using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Web;

public partial class SessionDiagnostics : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int hitCount = 0;
        if (Session["SessionDiagnosticsHitCount"] != null)
        {
            Int32.TryParse(Convert.ToString(Session["SessionDiagnosticsHitCount"]), out hitCount);
        }

        hitCount++;
        Session["SessionDiagnosticsHitCount"] = hitCount;
        Session["SessionDiagnosticsLastHitUtc"] = DateTime.UtcNow;

        List<KeyValuePair<string, string>> report = BuildReport(hitCount);

        if (String.Equals(Request.QueryString["export"], "csv", StringComparison.OrdinalIgnoreCase))
        {
            ExportCsv(report);
            return;
        }

        StringBuilder html = new StringBuilder();
        html.Append("<div class=\"panel\">");
        html.Append("<table class=\"diagnostics-table\">");
        for (int index = 0; index < report.Count; index++)
        {
            AppendRow(html, report[index].Key, report[index].Value);
        }
        html.Append("</table>");
        html.Append("</div>");

        html.Append("<div class=\"panel\">");
        html.Append("<h2>How to read this</h2>");
        html.Append("<ul class=\"hint-list\">");
        html.Append("<li>If MachineName changes, F5 persistence is not keeping the user on the same server.</li>");
        html.Append("<li>If ProcessId or Application[AppStartUtc] changes, the app pool/app domain is recycling.</li>");
        html.Append("<li>If ASP.NET_SessionId changes, the browser/proxy is losing or replacing the session cookie.</li>");
        html.Append("<li>If Session[USERID] or Session[UserID] becomes blank while the cookie stays the same, application code is clearing the user session value.</li>");
        html.Append("<li>If hit count resets while MachineName and ProcessId stay the same, ASP.NET InProc session is being abandoned or cleared by code.</li>");
        html.Append("</ul>");
        html.Append("</div>");

        DiagnosticsLiteral.Text = html.ToString();
    }

    private List<KeyValuePair<string, string>> BuildReport(int hitCount)
    {
        List<KeyValuePair<string, string>> report = new List<KeyValuePair<string, string>>();

        Add(report, "Report generated local time", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        Add(report, "Report generated UTC", DateTime.UtcNow.ToString("u"));
        Add(report, "MachineName", Environment.MachineName);
        Add(report, "ProcessId", Process.GetCurrentProcess().Id.ToString());
        Add(report, "AppDomainId", AppDomain.CurrentDomain.Id.ToString());
        Add(report, "Application[AppStartUtc]", Convert.ToString(Application["AppStartUtc"]));
        Add(report, "Application[AppStartMachine]", Convert.ToString(Application["AppStartMachine"]));
        Add(report, "Application[AppStartProcessId]", Convert.ToString(Application["AppStartProcessId"]));
        Add(report, "Session.SessionID", Session.SessionID);
        Add(report, "Session.Timeout", Session.Timeout.ToString());
        Add(report, "Session[USERID]", Convert.ToString(Session["USERID"]));
        Add(report, "Session[UserID]", Convert.ToString(Session["UserID"]));
        Add(report, "Session[SessionStartUtc]", Convert.ToString(Session["SessionStartUtc"]));
        Add(report, "Session[SessionStartMachine]", Convert.ToString(Session["SessionStartMachine"]));
        Add(report, "Session[SessionStartProcessId]", Convert.ToString(Session["SessionStartProcessId"]));
        Add(report, "SessionDiagnosticsHitCount", hitCount.ToString());
        Add(report, "SessionDiagnosticsLastHitUtc", Convert.ToString(Session["SessionDiagnosticsLastHitUtc"]));
        Add(report, "Session key count", Session.Keys.Count.ToString());
        Add(report, "Session key names", GetSessionKeyNames());
        Add(report, "ASP.NET_SessionId cookie", Request.Cookies["ASP.NET_SessionId"] != null ? Request.Cookies["ASP.NET_SessionId"].Value : String.Empty);
        Add(report, ".HFLMSAUTH cookie exists", Request.Cookies[".HFLMSAUTH"] != null ? "True" : "False");
        Add(report, "Cookie names", GetCookieNames());
        Add(report, "Forms auth user", Context.User != null && Context.User.Identity != null ? Context.User.Identity.Name : String.Empty);
        Add(report, "Request.IsAuthenticated", Request.IsAuthenticated.ToString());
        Add(report, "ServerVariables[LOGON_USER]", Request.ServerVariables["LOGON_USER"]);
        Add(report, "ServerVariables[AUTH_USER]", Request.ServerVariables["AUTH_USER"]);
        Add(report, "ServerVariables[REMOTE_USER]", Request.ServerVariables["REMOTE_USER"]);
        Add(report, "ServerVariables[AUTH_TYPE]", Request.ServerVariables["AUTH_TYPE"]);
        Add(report, "Request.LogonUserIdentity.Name", Request.LogonUserIdentity != null ? Request.LogonUserIdentity.Name : String.Empty);
        Add(report, "Request.LogonUserIdentity.IsAuthenticated", Request.LogonUserIdentity != null ? Request.LogonUserIdentity.IsAuthenticated.ToString() : String.Empty);
        Add(report, "Client IP/UserHostAddress", Request.UserHostAddress);
        Add(report, "X-Forwarded-For", Request.ServerVariables["HTTP_X_FORWARDED_FOR"]);
        Add(report, "Host", Request.Url.Host);
        Add(report, "Application path", Request.ApplicationPath);
        Add(report, "Raw URL", Request.RawUrl);
        Add(report, "IsSecureConnection", Request.IsSecureConnection.ToString());
        Add(report, "User Agent", Request.UserAgent);

        return report;
    }

    private static void Add(List<KeyValuePair<string, string>> report, string name, string value)
    {
        report.Add(new KeyValuePair<string, string>(name, value ?? String.Empty));
    }

    private string GetSessionKeyNames()
    {
        StringBuilder names = new StringBuilder();
        for (int index = 0; index < Session.Keys.Count; index++)
        {
            if (index > 0)
            {
                names.Append("; ");
            }

            names.Append(Session.Keys[index]);
        }

        return names.ToString();
    }

    private string GetCookieNames()
    {
        StringBuilder names = new StringBuilder();
        for (int index = 0; index < Request.Cookies.Count; index++)
        {
            if (index > 0)
            {
                names.Append("; ");
            }

            names.Append(Request.Cookies[index].Name);
        }

        return names.ToString();
    }

    private void ExportCsv(List<KeyValuePair<string, string>> report)
    {
        string fileName = "HFLMS_SessionDiagnostics_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv";

        Response.Clear();
        Response.Buffer = true;
        Response.ContentType = "text/csv";
        Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);
        Response.ContentEncoding = Encoding.UTF8;
        Response.Write("Property,Value\r\n");

        for (int index = 0; index < report.Count; index++)
        {
            Response.Write(ToCsv(report[index].Key));
            Response.Write(",");
            Response.Write(ToCsv(report[index].Value));
            Response.Write("\r\n");
        }

        Response.End();
    }

    private static string ToCsv(string value)
    {
        if (value == null)
        {
            value = String.Empty;
        }

        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }

    private static void AppendRow(StringBuilder html, string name, string value)
    {
        html.Append("<tr><th align=\"left\">");
        html.Append(HttpUtility.HtmlEncode(name));
        html.Append("</th><td>");
        html.Append(HttpUtility.HtmlEncode(value));
        html.Append("</td></tr>");
    }
}