using System;
using System.Diagnostics;
using System.Text;
using System.Web;

public partial class SessionDiagnostics : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int hitCount = 0;
        if (Session["SessionDiagnosticsHitCount"] != null)
        {
            Int32.TryParse(Convert.ToString(Session["SessionDiagnosticsHitCount"]), out hitCount);
        }

        hitCount++;
        Session["SessionDiagnosticsHitCount"] = hitCount;
        Session["SessionDiagnosticsLastHitUtc"] = DateTime.UtcNow;

        StringBuilder html = new StringBuilder();
        html.Append("<table border=\"1\" cellpadding=\"6\" cellspacing=\"0\">");
        AppendRow(html, "UtcNow", DateTime.UtcNow.ToString("u"));
        AppendRow(html, "MachineName", Environment.MachineName);
        AppendRow(html, "ProcessId", Process.GetCurrentProcess().Id.ToString());
        AppendRow(html, "AppDomainId", AppDomain.CurrentDomain.Id.ToString());
        AppendRow(html, "Application[AppStartUtc]", Convert.ToString(Application["AppStartUtc"]));
        AppendRow(html, "Application[AppStartMachine]", Convert.ToString(Application["AppStartMachine"]));
        AppendRow(html, "Application[AppStartProcessId]", Convert.ToString(Application["AppStartProcessId"]));
        AppendRow(html, "Session.SessionID", Session.SessionID);
        AppendRow(html, "Session.Timeout", Session.Timeout.ToString());
        AppendRow(html, "Session[SessionStartUtc]", Convert.ToString(Session["SessionStartUtc"]));
        AppendRow(html, "Session[SessionStartMachine]", Convert.ToString(Session["SessionStartMachine"]));
        AppendRow(html, "Session[SessionStartProcessId]", Convert.ToString(Session["SessionStartProcessId"]));
        AppendRow(html, "SessionDiagnosticsHitCount", hitCount.ToString());
        AppendRow(html, "ASP.NET_SessionId cookie", Request.Cookies["ASP.NET_SessionId"] != null ? Request.Cookies["ASP.NET_SessionId"].Value : String.Empty);
        AppendRow(html, ".HFLMSAUTH cookie exists", Request.Cookies[".HFLMSAUTH"] != null ? "True" : "False");
        AppendRow(html, "Forms auth user", Context.User != null && Context.User.Identity != null ? Context.User.Identity.Name : String.Empty);
        html.Append("</table>");

        html.Append("<h2>How to read this</h2>");
        html.Append("<ul>");
        html.Append("<li>If MachineName changes, F5 persistence is not keeping the user on the same server.</li>");
        html.Append("<li>If ProcessId or Application[AppStartUtc] changes, the app pool/app domain is recycling.</li>");
        html.Append("<li>If ASP.NET_SessionId changes, the browser/proxy is losing or replacing the session cookie.</li>");
        html.Append("<li>If hit count resets while MachineName and ProcessId stay the same, ASP.NET InProc session is being abandoned or cleared by code.</li>");
        html.Append("</ul>");

        DiagnosticsLiteral.Text = html.ToString();
    }

    private static void AppendRow(StringBuilder html, string name, string value)
    {
        html.Append("<tr><th align=\"left\">");
        html.Append(HttpUtility.HtmlEncode(name));
        html.Append("</th><td>");
        html.Append(HttpUtility.HtmlEncode(value));
        html.Append("</td></tr>");
    }
}