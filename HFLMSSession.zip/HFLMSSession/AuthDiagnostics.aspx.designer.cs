public partial class AuthDiagnostics
{
    protected global::System.Web.UI.HtmlControls.HtmlForm form1;

    protected global::System.Web.UI.WebControls.Literal DiagnosticsLiteral;
}