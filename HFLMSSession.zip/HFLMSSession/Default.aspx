<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Default" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HFLMS</title>
</head>
<body>
    <form id="form1" runat="server">
        <h1>HFLMS</h1>
        <p>Authenticated application user: <asp:Literal ID="UserNameLiteral" runat="server" /></p>
        <asp:HyperLink ID="LogoutLink" runat="server" NavigateUrl="~/Logout.aspx" Text="Logout" />
    </form>
</body>
</html>